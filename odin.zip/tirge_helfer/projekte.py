"""
Projekte: jeder legt eigene Projekte an und holt einzelne Personen dazu.

Aufbau wie bei bekannten Aufgaben-Werkzeugen: Spalten (Board), Aufgaben mit Zuständigen, Fälligkeit,
Priorität, Checkliste und Kommentaren, dazu „Meine Aufgaben“ über alle Projekte.

Gespeichert wird im Ordner „Fahrzeuge“ unter _ODIN/ (per OneDrive auf allen Rechnern gleich):
- _ODIN/personen.json        wer mitarbeitet (Name, Kürzel, Farbe)
- _ODIN/Projekte/<id>.json   je Projekt eine Datei – zwei Leute an zwei Projekten kommen sich nie in die Quere
Vor jeder Änderung wird die Datei frisch gelesen, damit Änderungen von anderen Rechnern erhalten bleiben.

Wer „ich“ bin, legt der Anmeldebildschirm fest (tresor.py): Person wählen, PIN eingeben – oder die
Microsoft-Anmeldung, dann ist man die Person mit derselben E-Mail-Adresse (Feld „email“ in personen.json – daran
sollen später auch Rollen hängen). Ein freies Setzen ohne PIN gibt es an der Oberfläche nicht. Projekte sieht nur, wer
Mitglied ist – das regelt bis dahin nur die Anzeige; wer die Dateien öffnen kann, kann sie lesen.

Quartalsziele („Rocks“ nach EOS): ein Projekt kann für ein Quartal als Ziel markiert werden („2027-Q1“), mit einer
Definition („Erledigt heißt …“) und einem Zielstatus. Während des Quartals wird wöchentlich „auf Kurs“ oder
„nicht auf Kurs“ gemeldet (vorzeitig fertig: „erledigt“), nach Quartalsende gibt es nur noch „erledigt“ oder
„nicht erledigt“ – keine Prozente. Verantwortlich ist, wer das Projekt angelegt hat. Ziel: 3–7 Ziele je Quartal,
mindestens 80 % davon erledigt.
"""

import datetime as dt
import json
import os
import re
import secrets

FARBEN = ["#2F6DB3", "#0F8F78", "#B4532A", "#7A4FB5", "#C2185B", "#5B7083", "#8A6D00", "#D0141C"]
PRIORITAETEN = ("hoch", "normal", "niedrig")
STANDARD_SPALTEN = [("Offen", False), ("In Arbeit", False), ("Warten auf …", False), ("Erledigt", True)]
VERLAUF_MAX = 300
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")
ZIEL_STATUS = ("auf Kurs", "nicht auf Kurs", "erledigt", "nicht erledigt")
ZIEL_STATUS_LAUFEND = ("auf Kurs", "nicht auf Kurs", "erledigt")      # während des Quartals (wöchentlich)
ZIEL_STATUS_ENDE = ("erledigt", "nicht erledigt")                     # nach Quartalsende: nur noch das
ZIEL_STATUS_ALT = {"gefährdet": "nicht auf Kurs"}                     # frühere Bezeichnung
ZIELQUOTE = 80                                                        # Prozent erledigte Ziele je Quartal
QUARTAL = re.compile(r"(20\d\d)-Q([1-4])")

from .speicher import personen_form, projekt_form


class ProjektFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


def quartal_von(datum=None) -> str:
    """Datum (date oder ISO-Text) → „2027-Q1“; ohne Datum das laufende Quartal."""
    if datum in (None, ""):
        d = dt.date.today()
    elif isinstance(datum, dt.date):
        d = datum
    else:
        d = dt.date.fromisoformat(str(datum)[:10])
    return f"{d.year}-Q{(d.month - 1) // 3 + 1}"


def quartal_verschieben(quartal: str, schritte: int) -> str:
    """„2026-Q4“ + 1 → „2027-Q1“."""
    jahr, q = int(quartal[:4]), int(quartal[-1])
    n = jahr * 4 + (q - 1) + schritte
    return f"{n // 4}-Q{n % 4 + 1}"


def quartal_ende(quartal: str) -> dt.date:
    """Letzter Tag des Quartals."""
    naechstes = quartal_verschieben(quartal, 1)
    return dt.date(int(naechstes[:4]), 3 * (int(naechstes[-1]) - 1) + 1, 1) - dt.timedelta(days=1)


def quartal_vorbei(quartal: str, heute: dt.date = None) -> bool:
    return (heute or dt.date.today()) > quartal_ende(quartal)


def _ziel_status(wert, quartal: str) -> str:
    """Zielstatus prüfen: im laufenden (oder künftigen) Quartal auf Kurs/nicht auf Kurs/erledigt, danach nur
    erledigt/nicht erledigt."""
    wert = ZIEL_STATUS_ALT.get(wert, wert)
    if wert not in ZIEL_STATUS:
        raise ProjektFehler("Unbekannter Zielstatus – möglich sind „auf Kurs“, „nicht auf Kurs“, „erledigt“ und „nicht erledigt“.")
    if quartal_vorbei(quartal) and wert not in ZIEL_STATUS_ENDE:
        raise ProjektFehler(f"{quartal} ist vorbei – jetzt zählt nur noch „erledigt“ oder „nicht erledigt“.")
    if not quartal_vorbei(quartal) and wert not in ZIEL_STATUS_LAUFEND:
        raise ProjektFehler("„nicht erledigt“ gibt es erst nach Quartalsende – bis dahin „auf Kurs“ oder „nicht auf Kurs“.")
    return wert


def _quartal(wert):
    """Eingabe → „2027-Q1“ (auch „2027-q1“, „Q1 2027“, „Q1/2027“); leer → None."""
    if wert in (None, ""):
        return None
    text = re.sub(r"\s+", "", str(wert)).upper()
    m = QUARTAL.fullmatch(text)
    if m:
        return f"{m.group(1)}-Q{m.group(2)}"
    m = re.fullmatch(r"Q([1-4])[-/]?(20\d\d)", text)
    if m:
        return f"{m.group(2)}-Q{m.group(1)}"
    raise ProjektFehler("Das Quartal bitte so angeben: „2027-Q1“.")


def _neue_id(laenge: int = 10) -> str:
    """Zufällige ID: zwei Rechner, die gleichzeitig etwas anlegen, vergeben nie dieselbe."""
    return secrets.token_hex(laenge // 2)


def _jetzt() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def _text(wert, laenge: int) -> str:
    return " ".join(str(wert or "").split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    """Mehrzeilig erlaubt (Beschreibung, Kommentar), nur Leerraum am Rand weg."""
    return str(wert or "").replace("\r\n", "\n").strip()[:laenge]


def _datum(wert):
    if wert in (None, ""):
        return None
    wert = str(wert).strip()[:10]
    if not ISO_DATUM.fullmatch(wert):
        raise ProjektFehler("Bitte ein Datum wählen.")
    try:
        dt.date.fromisoformat(wert)
    except ValueError:
        raise ProjektFehler("Dieses Datum gibt es nicht.") from None
    return wert


def _email(wert, pflicht: bool = False) -> str:
    """E-Mail-Adresse in Kleinbuchstaben; leer erlaubt, solange sie keine Pflicht ist."""
    email = str(wert or "").strip().casefold()
    if not email and not pflicht:
        return ""
    if len(email) > 254 or not EMAIL.fullmatch(email):
        raise ProjektFehler("Bitte eine gültige E-Mail-Adresse eingeben.")
    return email


def _kuerzel(name: str) -> str:
    teile = [t for t in re.split(r"[\s\-]+", name) if t]
    if len(teile) >= 2:
        return (teile[0][0] + teile[-1][0]).upper()
    return name[:2].upper()


def _lies(pfad: str, form=None):
    """form: Funktion, die den Inhalt in feste Form bringt (speicher.personen_form / projekt_form)."""
    from .speicher import lies_json
    try:
        daten = lies_json(pfad)
        return form(daten) if form else daten
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as e:
        raise ProjektFehler(f"„{os.path.basename(pfad)}“ ist gerade nicht lesbar ({e}). "
                            "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise ProjektFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


class Projekte:
    """'wurzel()' liefert den Ordner „Fahrzeuge“ (oder ""), 'ich()'/'setze_ich(id)' die Person dieses Rechners,
    'ersatz_ordner' wird ohne Fahrzeuge-Ordner benutzt (dann nur auf diesem Rechner)."""

    def __init__(self, wurzel, ich, setze_ich, ersatz_ordner: str, ich_fest=None):
        self._wurzel = wurzel
        self._ich = ich
        self._setze_ich = setze_ich
        self._ersatz = ersatz_ordner
        self._ich_fest = ich_fest or (lambda: False)     # True: „ich“ kommt aus der Microsoft-Anmeldung
        from .pin import PinSpeicher                     # (hier: pin.py braucht ProjektFehler aus diesem Modul)
        self.pins = PinSpeicher(lambda: os.path.join(self._basis()[0], "Zugang"))

    # ---------------- Orte ----------------
    def _basis(self):
        w = self._wurzel() or ""
        if w and os.path.isdir(w):
            return os.path.join(w, "_ODIN"), False
        return os.path.join(self._ersatz, "_ODIN"), True

    def _personen_pfad(self) -> str:
        return os.path.join(self._basis()[0], "personen.json")

    def _projekt_ordner(self) -> str:
        return os.path.join(self._basis()[0], "Projekte")

    def _projekt_pfad(self, pid: str) -> str:
        if not re.fullmatch(r"[0-9a-f]{6,32}", str(pid or "")):
            raise ProjektFehler("Unbekanntes Projekt.")
        return os.path.join(self._projekt_ordner(), f"{pid}.json")

    # ---------------- Personen ----------------
    def personen(self) -> list:
        daten = _lies(self._personen_pfad(), personen_form) or {}
        return [p for p in daten.get("personen", []) if isinstance(p, dict) and p.get("id")]

    def person_anlegen(self, eingabe: dict) -> dict:
        name = _text((eingabe or {}).get("name"), 60)
        if len(name) < 2:
            raise ProjektFehler("Bitte den Namen eingeben (mindestens 2 Zeichen).")
        email = _email(eingabe.get("email"))
        daten = _lies(self._personen_pfad(), personen_form) or {"version": 1, "personen": []}
        personen = daten.setdefault("personen", [])
        if any(p.get("name", "").casefold() == name.casefold() for p in personen):
            raise ProjektFehler(f"„{name}“ gibt es schon.")
        if email and any((p.get("email") or "").casefold() == email for p in personen):
            raise ProjektFehler(f"Die Adresse {email} gehört schon zu einer anderen Person.")
        farbe = eingabe.get("farbe") if eingabe.get("farbe") in FARBEN else FARBEN[len(personen) % len(FARBEN)]
        person = {"id": _neue_id(), "name": name, "kuerzel": _text(eingabe.get("kuerzel"), 3).upper() or _kuerzel(name),
                  "farbe": farbe, "aktiv": True, "angelegt_am": _jetzt()}
        if email:
            person["email"] = email
        personen.append(person)
        _schreibe(self._personen_pfad(), daten)
        return person

    def person_email_setzen(self, person_id: str, email: str) -> dict:
        """E-Mail-Adresse (aus der Microsoft-Anmeldung) bei einer Person eintragen. Stand sie bei einer anderen Person,
        zieht sie um – die Anmeldung bei Microsoft ist der Nachweis. Hat die Person schon eine andere Adresse, bleibt
        es dabei (zwei Konten für eine Person gibt es nicht)."""
        email = _email(email, pflicht=True)
        daten = _lies(self._personen_pfad(), personen_form) or {"version": 1, "personen": []}
        personen = [p for p in daten.get("personen", []) if isinstance(p, dict)]
        person = next((p for p in personen if p.get("id") == person_id), None)
        if not person:
            raise ProjektFehler("Diese Person gibt es nicht.")
        eigene = (person.get("email") or "").casefold()
        if eigene and eigene != email:
            raise ProjektFehler(f"{person.get('name', 'Diese Person')} ist schon mit {eigene} verknüpft.")
        for p in personen:
            if p is not person and (p.get("email") or "").casefold() == email:
                p.pop("email", None)
        person["email"] = email
        _schreibe(self._personen_pfad(), daten)
        return person

    def person_zur_anmeldung(self, name: str, email: str) -> dict:
        """Wer sich mit Microsoft angemeldet hat: zuerst die Person mit derselben E-Mail, sonst genau eine Person mit
        demselben Namen (ohne eigene Adresse – dort wird die E-Mail eingetragen). Sonst {"person": None}."""
        email = _email(email, pflicht=True)
        personen = self.personen()
        person = next((p for p in personen if (p.get("email") or "").casefold() == email), None)
        if person:
            return {"person": person, "wie": "email"}
        name = _text(name, 60).casefold()
        # Nie automatisch über den Namen: den Anzeigenamen eines Microsoft-Kontos kann man frei wählen.
        # Passt nur der Name, schlägt die Oberfläche die Person vor – verknüpfen muss ein Mensch.
        gleich = [p for p in personen if name and p.get("name", "").casefold() == name and not p.get("email")]
        return {"person": None, "wie": "", "vorschlag": gleich[0]["id"] if len(gleich) == 1 else ""}

    def ich(self) -> str:
        ich = self._ich() or ""
        return ich if any(p["id"] == ich for p in self.personen()) else ""

    def ich_setzen(self, person_id: str) -> dict:
        """Nur noch intern (Tests, Selbsttest, Ersteinrichtung ohne Oberfläche) – an der Oberfläche gibt es das nicht,
        dort meldet man sich mit PIN an (tresor.py). Für eine Person mit PIN wird es auch intern abgelehnt."""
        if not any(p["id"] == person_id for p in self.personen()):
            raise ProjektFehler("Diese Person gibt es nicht.")
        if self.pins.hat_pin(self.pins.eintrag(person_id)):
            raise ProjektFehler("Für diese Person gilt eine PIN – bitte über den Anmeldebildschirm anmelden.")
        self._setze_ich(person_id)
        return self.start()

    def abmelden(self) -> dict:
        """Abmelden (Anmeldebildschirm): dieser Rechner (bzw. das Gerät im Browser) vergisst, wer hier arbeitet. Ist
        die Person über die Microsoft-Anmeldung festgelegt, lehnt 'setze_ich' das ab – dann zuerst dort abmelden."""
        self._setze_ich("")
        return self.start()

    def _ich_pflicht(self) -> str:
        ich = self.ich()
        if not ich:
            raise ProjektFehler("Bitte zuerst auswählen, wer du bist.")
        return ich

    # ---------------- Projekte lesen ----------------
    def _alle(self) -> list:
        ordner = self._projekt_ordner()
        try:
            namen = sorted(n for n in os.listdir(ordner) if n.endswith(".json"))
        except OSError:
            return []
        projekte = []
        for n in namen:
            try:
                p = _lies(os.path.join(ordner, n), projekt_form)
            except ProjektFehler:
                continue                                  # eine gerade gesperrte Datei hält die Übersicht nicht auf
            if isinstance(p, dict) and p.get("id"):
                projekte.append(p)
        return projekte

    @staticmethod
    def _darf_sehen(p: dict, ich: str) -> bool:
        return ich == p.get("besitzer") or ich in (p.get("mitglieder") or [])

    @staticmethod
    def _erledigt_spalten(p: dict) -> set:
        return {s["id"] for s in p.get("spalten", []) if s.get("erledigt")}

    def _zusammenfassung(self, p: dict) -> dict:
        fertig = self._erledigt_spalten(p)
        aufgaben = p.get("aufgaben", [])
        offen = [a for a in aufgaben if a.get("spalte") not in fertig]
        heute = dt.date.today().isoformat()
        faellig = sorted(a["faellig"] for a in offen if a.get("faellig"))
        return {"id": p["id"], "name": p.get("name", ""), "beschreibung": p.get("beschreibung", ""),
                "farbe": p.get("farbe") or FARBEN[0], "besitzer": p.get("besitzer"),
                "mitglieder": p.get("mitglieder", []), "archiviert": bool(p.get("archiviert")),
                "aufgaben": len(aufgaben), "erledigt": len(aufgaben) - len(offen),
                "ueberfaellig": sum(1 for d in faellig if d < heute), "naechste_frist": faellig[0] if faellig else None,
                "quartalsziel": p.get("quartalsziel"),
                "ziel_status": ZIEL_STATUS_ALT.get(p.get("ziel_status"), p.get("ziel_status")) if p.get("quartalsziel") else None,
                "ziel_definition": p.get("ziel_definition", "") if p.get("quartalsziel") else "",
                "geaendert_am": p.get("geaendert_am") or p.get("erstellt_am")}

    def start(self) -> dict:
        """Alles für die Übersicht: wer ich bin, alle Personen, meine Projekte (ohne Aufgaben)."""
        basis, lokal = self._basis()
        ich = self.ich()
        projekte = [self._zusammenfassung(p) for p in self._alle() if ich and self._darf_sehen(p, ich)]
        projekte.sort(key=lambda p: (p["archiviert"], (p["name"] or "").casefold()))
        return {"ich": ich, "personen": self.personen(), "projekte": projekte, "farben": FARBEN,
                "speicher": {"lokal": lokal, "ordner": basis}, "ich_fest": bool(ich and self._ich_fest())}

    def projekt(self, pid: str) -> dict:
        ich = self._ich_pflicht()
        p = _lies(self._projekt_pfad(pid), projekt_form)
        if not p:
            raise ProjektFehler("Dieses Projekt gibt es nicht mehr.")
        if not self._darf_sehen(p, ich):
            raise ProjektFehler("Du bist in diesem Projekt nicht Mitglied.")
        return p

    def meine_aufgaben(self) -> list:
        """Offene Aufgaben, für die ich zuständig bin – über alle Projekte."""
        return self.aufgaben_von(self._ich_pflicht())

    def aufgaben_von(self, ich: str) -> list:
        """Offene Aufgaben einer Person über alle Projekte, in denen sie Mitglied ist (z. B. für die Erinnerungsmail).
        Bewusst nicht in der Schnittstelle der Oberfläche – dort gibt es nur „meine“."""
        liste = []
        for p in self._alle():
            if not self._darf_sehen(p, ich) or p.get("archiviert"):
                continue
            fertig = self._erledigt_spalten(p)
            spalten = {s["id"]: s["name"] for s in p.get("spalten", [])}
            for a in p.get("aufgaben", []):
                if ich in (a.get("zustaendig") or []) and a.get("spalte") not in fertig:
                    liste.append({**a, "projekt_id": p["id"], "projekt": p.get("name", ""),
                                  "projekt_farbe": p.get("farbe"), "spalte_name": spalten.get(a.get("spalte"), "")})
        liste.sort(key=lambda a: (a.get("faellig") or "9999", {"hoch": 0, "normal": 1, "niedrig": 2}.get(a.get("prioritaet"), 1)))
        return liste

    def ziele(self, quartal=None) -> dict:
        """
        Quartalsziele: meine Projekte, die für das Quartal als Ziel markiert sind (ohne Angabe: das laufende) –
        mit Verantwortlichem (wer das Projekt angelegt hat), Definition „Erledigt heißt …“, Zielstatus und zur Info
        erledigten Aufgaben. Nach Quartalsende braucht jedes Ziel „erledigt“ oder „nicht erledigt“ (abschluss_noetig).
        Archivierte Projekte zählen mit: ein erreichtes Ziel bleibt in seinem Quartal stehen.
        """
        q = _quartal(quartal) or quartal_von()
        vorbei = quartal_vorbei(q)
        ich = self.ich()
        sichtbar = [p for p in self._alle() if ich and self._darf_sehen(p, ich)]
        reihenfolge = {"nicht auf Kurs": 0, None: 1, "auf Kurs": 2, "nicht erledigt": 3, "erledigt": 4}
        ziele = []
        for p in sichtbar:
            if p.get("quartalsziel") != q:
                continue
            z = self._zusammenfassung(p)
            status = z["ziel_status"] if z["ziel_status"] in ZIEL_STATUS else None
            if vorbei and status not in ZIEL_STATUS_ENDE:
                status = None                         # Quartal vorbei, aber noch nicht abgeschlossen
            z.update(ziel_status=status, verantwortlich=p.get("besitzer"), abschluss_noetig=vorbei and status is None)
            ziele.append(z)
        ziele.sort(key=lambda z: (reihenfolge[z["ziel_status"]], (z["name"] or "").casefold()))
        erledigt = sum(1 for z in ziele if z["ziel_status"] == "erledigt")
        quartale = sorted({p["quartalsziel"] for p in sichtbar if QUARTAL.fullmatch(str(p.get("quartalsziel") or ""))} | {q})
        return {"ich": ich, "quartal": q, "laufend": quartal_von(), "vorher": quartal_verschieben(q, -1),
                "nachher": quartal_verschieben(q, 1), "quartale": quartale, "vorbei": vorbei, "ende": quartal_ende(q).isoformat(),
                "status": list(ZIEL_STATUS_ENDE if vorbei else ZIEL_STATUS_LAUFEND), "ziele": ziele,
                "erledigt": erledigt, "zielquote": round(100 * erledigt / len(ziele)) if ziele else None,
                "zielquote_soll": ZIELQUOTE, "empfohlen": [3, 7]}

    def aufgaben_stand(self, paare) -> dict:
        """
        Stand einzelner Aufgaben für andere Bereiche (z. B. eine Besprechung, aus der die Aufgabe stammt):
        [(projekt_id, aufgabe_id), …] → {aufgabe_id: {erledigt, titel, faellig, zustaendig, projekt, …}}.
        Gelöschte Aufgaben fehlen. Ohne Mitgliedschaft gibt es nur diese Eckdaten, nicht das Projekt.
        """
        ich = self.ich()
        projekte, stand = {}, {}
        for pid, aid in paare or []:
            if not pid or not aid:
                continue
            if pid not in projekte:
                try:
                    projekte[pid] = _lies(self._projekt_pfad(pid), projekt_form)
                except ProjektFehler:
                    projekte[pid] = None
            p = projekte[pid]
            a = next((x for x in (p or {}).get("aufgaben", []) if x.get("id") == aid), None)
            if not a:
                continue
            spalten = {s["id"]: s.get("name", "") for s in p.get("spalten", [])}
            stand[aid] = {"erledigt": a.get("spalte") in self._erledigt_spalten(p), "erledigt_am": a.get("erledigt_am"),
                          "titel": a.get("titel", ""), "faellig": a.get("faellig"), "zustaendig": a.get("zustaendig") or [],
                          "spalte_name": spalten.get(a.get("spalte"), ""), "projekt": p.get("name", ""),
                          "projekt_farbe": p.get("farbe"), "mitglied": bool(ich) and self._darf_sehen(p, ich)}
        return stand

    # ---------------- Projekte ändern ----------------
    def _aendere(self, pid: str, aenderung, nur_besitzer: bool = False) -> dict:
        ich = self._ich_pflicht()
        pfad = self._projekt_pfad(pid)
        p = _lies(pfad, projekt_form)
        if not p:
            raise ProjektFehler("Dieses Projekt gibt es nicht mehr.")
        if not self._darf_sehen(p, ich):
            raise ProjektFehler("Du bist in diesem Projekt nicht Mitglied.")
        if nur_besitzer and p.get("besitzer") != ich:
            raise ProjektFehler("Das darf nur, wer das Projekt angelegt hat.")
        verlauf = aenderung(p, ich)
        p["geaendert_am"] = _jetzt()
        if verlauf:
            p.setdefault("verlauf", []).append({"am": p["geaendert_am"], "von": ich, "text": verlauf})
            p["verlauf"] = p["verlauf"][-VERLAUF_MAX:]
        _schreibe(pfad, p)
        return p

    def _personen_ids(self, ids) -> list:
        bekannt = {p["id"] for p in self.personen()}
        return [i for i in dict.fromkeys(ids or []) if i in bekannt]

    def projekt_anlegen(self, eingabe: dict) -> dict:
        ich = self._ich_pflicht()
        p = self._neues_projekt(ich, eingabe or {})
        _schreibe(self._projekt_pfad(p["id"]), p)
        return p

    def _neues_projekt(self, ich: str, e: dict) -> dict:
        name = _text(e.get("name"), 80)
        if not name:
            raise ProjektFehler("Bitte einen Projektnamen eingeben.")
        quartal = _quartal(e.get("quartalsziel"))
        status = None
        if quartal:
            status = _ziel_status(e["ziel_status"], quartal) if e.get("ziel_status") else (
                None if quartal_vorbei(quartal) else "auf Kurs")
        spalten = [{"id": _neue_id(8), "name": n, "erledigt": fertig} for n, fertig in STANDARD_SPALTEN]
        p = {"version": 1, "id": _neue_id(12), "name": name, "beschreibung": _langtext(e.get("beschreibung"), 2000),
             "farbe": e.get("farbe") if e.get("farbe") in FARBEN else FARBEN[0], "besitzer": ich,
             "mitglieder": [ich] + [i for i in self._personen_ids(e.get("mitglieder")) if i != ich],
             "archiviert": False, "erstellt_am": _jetzt(), "erstellt_von": ich, "geaendert_am": _jetzt(),
             "spalten": spalten, "aufgaben": [], "verlauf": [{"am": _jetzt(), "von": ich, "text": "hat das Projekt angelegt"}]}
        if quartal:
            p["quartalsziel"], p["ziel_status"] = quartal, status
            p["ziel_definition"] = _langtext(e.get("ziel_definition"), 500)
        return p

    def sammelprojekt(self, schluessel: str, name: str, mitglieder=None, beschreibung: str = "") -> dict:
        """
        Projekt, in dem ein anderer Bereich Aufgaben sammelt (z. B. „Aus Besprechungen“): gefunden über das Feld
        „sammel“, sonst neu angelegt. Wer es gerade braucht und 'mitglieder' werden Mitglied – auch ohne dass schon
        ein Mitglied sie dazuholt, denn ein Sammelprojekt gehört keinem einzelnen. Archivierte zählen nicht.
        """
        ich = self._ich_pflicht()
        gewuenscht = [ich] + [i for i in self._personen_ids(mitglieder) if i != ich]
        vorhanden = sorted((p for p in self._alle() if p.get("sammel") == schluessel and not p.get("archiviert")),
                           key=lambda p: p.get("erstellt_am") or "")
        if not vorhanden:
            p = self._neues_projekt(ich, {"name": name, "beschreibung": beschreibung, "mitglieder": gewuenscht})
            p["sammel"] = schluessel
            _schreibe(self._projekt_pfad(p["id"]), p)
            return p
        pfad = self._projekt_pfad(vorhanden[0]["id"])
        p = _lies(pfad, projekt_form) or vorhanden[0]                             # frisch: Änderungen anderer Rechner bleiben
        neu = [i for i in gewuenscht if i not in p.setdefault("mitglieder", [])]
        if neu:
            namen = {x["id"]: x["name"] for x in self.personen()}
            p["mitglieder"] += neu
            p["geaendert_am"] = _jetzt()
            p.setdefault("verlauf", []).append({"am": p["geaendert_am"], "von": ich,
                                                "text": "hat " + ", ".join(namen.get(i, "jemanden") for i in neu) + " hinzugefügt"})
            p["verlauf"] = p["verlauf"][-VERLAUF_MAX:]
            _schreibe(pfad, p)
        return p

    def projekt_aendern(self, pid: str, felder: dict) -> dict:
        f = felder or {}

        def aendern(p, ich):
            teile = []
            if "name" in f:
                name = _text(f["name"], 80)
                if not name:
                    raise ProjektFehler("Der Projektname darf nicht leer sein.")
                if name != p.get("name"):
                    p["name"] = name
                    teile.append(f"hat das Projekt in „{name}“ umbenannt")
            if "beschreibung" in f:
                p["beschreibung"] = _langtext(f["beschreibung"], 2000)
            if f.get("farbe") in FARBEN:
                p["farbe"] = f["farbe"]
            if "archiviert" in f:
                p["archiviert"] = bool(f["archiviert"])
                teile.append("hat das Projekt archiviert" if p["archiviert"] else "hat das Projekt wieder aktiviert")
            if "quartalsziel" in f:
                quartal = _quartal(f["quartalsziel"])
                if quartal != p.get("quartalsziel"):
                    p["quartalsziel"] = quartal
                    if not quartal:
                        p["ziel_status"] = None
                        teile.append("führt das Projekt nicht mehr als Quartalsziel")
                    else:
                        try:                              # bisheriger Status passt nicht mehr zum neuen Quartal?
                            p["ziel_status"] = _ziel_status(p.get("ziel_status"), quartal)
                        except ProjektFehler:
                            p["ziel_status"] = None if quartal_vorbei(quartal) else "auf Kurs"
                        teile.append(f"hat das Projekt als Quartalsziel {quartal} markiert")
            if "ziel_definition" in f:
                p["ziel_definition"] = _langtext(f["ziel_definition"], 500)
            if f.get("ziel_status") not in (None, ""):
                if not p.get("quartalsziel"):
                    raise ProjektFehler("Zuerst das Quartal wählen, für das dieses Projekt ein Ziel ist.")
                status = _ziel_status(f["ziel_status"], p["quartalsziel"])
                if status != p.get("ziel_status"):
                    p["ziel_status"] = status
                    teile.append(f"hat den Zielstatus auf „{status}“ gesetzt")
            return "; ".join(teile)
        return self._aendere(pid, aendern, nur_besitzer="archiviert" in f)

    def projekt_loeschen(self, pid: str) -> dict:
        ich = self._ich_pflicht()
        p = self.projekt(pid)
        if p.get("besitzer") != ich:
            raise ProjektFehler("Löschen darf nur, wer das Projekt angelegt hat.")
        try:
            os.remove(self._projekt_pfad(pid))
        except OSError as e:
            raise ProjektFehler(f"Löschen hat nicht geklappt ({e}).") from None
        return {"ok": True}

    def mitglied_hinzufuegen(self, pid: str, person_id: str) -> dict:
        if not self._personen_ids([person_id]):
            raise ProjektFehler("Diese Person gibt es nicht.")
        namen = {p["id"]: p["name"] for p in self.personen()}

        def dazu(p, ich):
            if person_id in p.setdefault("mitglieder", []):
                return ""
            p["mitglieder"].append(person_id)
            return f"hat {namen.get(person_id, 'jemanden')} hinzugefügt"
        return self._aendere(pid, dazu)

    def mitglied_entfernen(self, pid: str, person_id: str) -> dict:
        namen = {p["id"]: p["name"] for p in self.personen()}

        def weg(p, ich):
            if person_id == p.get("besitzer"):
                raise ProjektFehler("Wer das Projekt angelegt hat, bleibt Mitglied.")
            if person_id != ich and p.get("besitzer") != ich:
                raise ProjektFehler("Andere entfernen darf nur, wer das Projekt angelegt hat.")
            p["mitglieder"] = [m for m in p.get("mitglieder", []) if m != person_id]
            for a in p.get("aufgaben", []):
                a["zustaendig"] = [z for z in a.get("zustaendig") or [] if z != person_id]
            return "hat das Projekt verlassen" if person_id == ich else f"hat {namen.get(person_id, 'jemanden')} entfernt"
        return self._aendere(pid, weg)

    # ---------------- Spalten ----------------
    def spalte_anlegen(self, pid: str, name: str) -> dict:
        name = _text(name, 40)
        if not name:
            raise ProjektFehler("Bitte einen Spaltennamen eingeben.")

        def neu(p, ich):
            spalten = p.setdefault("spalten", [])
            if len(spalten) >= 12:
                raise ProjektFehler("Höchstens 12 Spalten.")
            einfuegen = next((i for i, s in enumerate(spalten) if s.get("erledigt")), len(spalten))   # vor „Erledigt“
            spalten.insert(einfuegen, {"id": _neue_id(8), "name": name, "erledigt": False})
            return f"hat die Spalte „{name}“ angelegt"
        return self._aendere(pid, neu)

    def spalte_umbenennen(self, pid: str, spalte_id: str, name: str) -> dict:
        name = _text(name, 40)
        if not name:
            raise ProjektFehler("Der Spaltenname darf nicht leer sein.")

        def um(p, ich):
            s = self._spalte(p, spalte_id)
            s["name"] = name
            return ""
        return self._aendere(pid, um)

    def spalte_loeschen(self, pid: str, spalte_id: str) -> dict:
        def weg(p, ich):
            s = self._spalte(p, spalte_id)
            if s.get("erledigt"):
                raise ProjektFehler("Die Erledigt-Spalte bleibt – dort landen abgehakte Aufgaben.")
            rest = [x for x in p["spalten"] if x["id"] != spalte_id]
            if not rest:
                raise ProjektFehler("Mindestens eine Spalte muss bleiben.")
            ziel = next(x for x in rest if not x.get("erledigt")) if any(not x.get("erledigt") for x in rest) else rest[0]
            for a in p.get("aufgaben", []):
                if a.get("spalte") == spalte_id:
                    a["spalte"] = ziel["id"]
            p["spalten"] = rest
            return f"hat die Spalte „{s['name']}“ gelöscht (Aufgaben nach „{ziel['name']}“)"
        return self._aendere(pid, weg)

    @staticmethod
    def _spalte(p: dict, spalte_id: str) -> dict:
        s = next((x for x in p.get("spalten", []) if x["id"] == spalte_id), None)
        if not s:
            raise ProjektFehler("Diese Spalte gibt es nicht mehr.")
        return s

    # ---------------- Aufgaben ----------------
    @staticmethod
    def _aufgabe(p: dict, aufgabe_id: str) -> dict:
        a = next((x for x in p.get("aufgaben", []) if x["id"] == aufgabe_id), None)
        if not a:
            raise ProjektFehler("Diese Aufgabe gibt es nicht mehr – vielleicht auf einem anderen Rechner gelöscht.")
        return a

    @staticmethod
    def _ende_der_spalte(p: dict, spalte_id: str) -> float:
        pos = [a.get("position", 0) for a in p.get("aufgaben", []) if a.get("spalte") == spalte_id]
        return (max(pos) if pos else 0) + 1024

    def aufgabe_anlegen(self, pid: str, eingabe: dict) -> dict:
        e = eingabe or {}
        titel = _text(e.get("titel"), 200)
        if not titel:
            raise ProjektFehler("Bitte einen Titel für die Aufgabe eingeben.")
        faellig = _datum(e.get("faellig"))
        prio = e.get("prioritaet") if e.get("prioritaet") in PRIORITAETEN else "normal"

        def neu(p, ich):
            spalte = e.get("spalte") or (p["spalten"][0]["id"] if p.get("spalten") else None)
            self._spalte(p, spalte)
            mitglieder = set(p.get("mitglieder", []))
            a = {"id": _neue_id(10), "titel": titel, "beschreibung": _langtext(e.get("beschreibung"), 5000),
                 "spalte": spalte, "zustaendig": [z for z in dict.fromkeys(e.get("zustaendig") or []) if z in mitglieder],
                 "faellig": faellig, "prioritaet": prio, "fahrzeug": _text(e.get("fahrzeug"), 20).upper() or None,
                 "checkliste": [], "kommentare": [], "position": self._ende_der_spalte(p, spalte),
                 "erstellt_am": _jetzt(), "erstellt_von": ich, "erledigt_am": None}
            if spalte in self._erledigt_spalten(p):
                a["erledigt_am"] = _jetzt()
            p.setdefault("aufgaben", []).append(a)
            return f"hat „{titel}“ angelegt"
        return self._aendere(pid, neu)

    def aufgabe_aendern(self, pid: str, aufgabe_id: str, felder: dict) -> dict:
        f = felder or {}

        def aendern(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            teile = []
            if "titel" in f:
                titel = _text(f["titel"], 200)
                if not titel:
                    raise ProjektFehler("Der Titel darf nicht leer sein.")
                a["titel"] = titel
            if "beschreibung" in f:
                a["beschreibung"] = _langtext(f["beschreibung"], 5000)
            if "faellig" in f:
                a["faellig"] = _datum(f["faellig"])
            if f.get("prioritaet") in PRIORITAETEN:
                a["prioritaet"] = f["prioritaet"]
            if "fahrzeug" in f:
                a["fahrzeug"] = _text(f["fahrzeug"], 20).upper() or None
            if "zustaendig" in f:
                mitglieder = set(p.get("mitglieder", []))
                neu = [z for z in dict.fromkeys(f["zustaendig"] or []) if z in mitglieder]
                if neu != a.get("zustaendig"):
                    a["zustaendig"] = neu
                    teile.append(f"hat die Zuständigkeit für „{a['titel']}“ geändert")
            if "spalte" in f and f["spalte"] != a.get("spalte"):
                teile.append(self._in_spalte(p, a, f["spalte"]))
            return "; ".join(t for t in teile if t)
        return self._aendere(pid, aendern)

    def _in_spalte(self, p: dict, a: dict, spalte_id: str) -> str:
        s = self._spalte(p, spalte_id)
        fertig = self._erledigt_spalten(p)
        war_fertig = a.get("spalte") in fertig
        a["spalte"] = spalte_id
        if spalte_id in fertig and not war_fertig:
            a["erledigt_am"] = _jetzt()
            return f"hat „{a['titel']}“ erledigt"
        if war_fertig and spalte_id not in fertig:
            a["erledigt_am"] = None
            return f"hat „{a['titel']}“ wieder geöffnet"
        return f"hat „{a['titel']}“ nach „{s['name']}“ verschoben"

    def aufgabe_verschieben(self, pid: str, aufgabe_id: str, spalte_id: str, vor_id: str = None) -> dict:
        """Board: in eine Spalte ziehen, vor die Aufgabe 'vor_id' (oder ans Ende)."""
        def schieben(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            text = self._in_spalte(p, a, spalte_id) if spalte_id != a.get("spalte") else ""
            andere = sorted((x for x in p["aufgaben"] if x.get("spalte") == spalte_id and x["id"] != aufgabe_id),
                            key=lambda x: x.get("position", 0))
            ziel = next((i for i, x in enumerate(andere) if x["id"] == vor_id), None)
            if ziel is None:
                a["position"] = (andere[-1].get("position", 0) if andere else 0) + 1024
            else:
                davor = andere[ziel - 1].get("position", 0) if ziel > 0 else andere[ziel].get("position", 0) - 1024
                a["position"] = (davor + andere[ziel].get("position", 0)) / 2
                if abs(a["position"] - davor) < 1e-6:                 # zu eng geworden: Spalte neu durchnummerieren
                    for i, x in enumerate(andere[:ziel] + [a] + andere[ziel:]):
                        x["position"] = (i + 1) * 1024
            return text
        return self._aendere(pid, schieben)

    def aufgabe_erledigen(self, pid: str, aufgabe_id: str, erledigt: bool = True) -> dict:
        """Abhaken: in die Erledigt-Spalte (bzw. zurück in die erste offene)."""
        def haken(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            fertig = [s for s in p.get("spalten", []) if s.get("erledigt")]
            offen = [s for s in p.get("spalten", []) if not s.get("erledigt")]
            ziel = (fertig or p["spalten"])[0] if erledigt else (offen or p["spalten"])[0]
            if ziel["id"] == a.get("spalte"):
                return ""
            text = self._in_spalte(p, a, ziel["id"])
            a["position"] = self._ende_der_spalte(p, ziel["id"])
            return text
        return self._aendere(pid, haken)

    def aufgabe_loeschen(self, pid: str, aufgabe_id: str) -> dict:
        def weg(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            p["aufgaben"] = [x for x in p["aufgaben"] if x["id"] != aufgabe_id]
            return f"hat „{a['titel']}“ gelöscht"
        return self._aendere(pid, weg)

    # ---------------- Checkliste und Kommentare ----------------
    def punkt_anlegen(self, pid: str, aufgabe_id: str, text: str) -> dict:
        text = _text(text, 200)
        if not text:
            raise ProjektFehler("Bitte einen Text für den Punkt eingeben.")

        def neu(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            if len(a.setdefault("checkliste", [])) >= 100:
                raise ProjektFehler("Höchstens 100 Punkte je Aufgabe.")
            a["checkliste"].append({"id": _neue_id(8), "text": text, "erledigt": False})
            return ""
        return self._aendere(pid, neu)

    def punkt_umschalten(self, pid: str, aufgabe_id: str, punkt_id: str) -> dict:
        def um(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            punkt = next((x for x in a.get("checkliste", []) if x["id"] == punkt_id), None)
            if not punkt:
                raise ProjektFehler("Diesen Punkt gibt es nicht mehr.")
            punkt["erledigt"] = not punkt.get("erledigt")
            return ""
        return self._aendere(pid, um)

    def punkt_loeschen(self, pid: str, aufgabe_id: str, punkt_id: str) -> dict:
        def weg(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            a["checkliste"] = [x for x in a.get("checkliste", []) if x["id"] != punkt_id]
            return ""
        return self._aendere(pid, weg)

    def kommentar_anlegen(self, pid: str, aufgabe_id: str, text: str) -> dict:
        text = _langtext(text, 4000)
        if not text:
            raise ProjektFehler("Der Kommentar ist leer.")

        def neu(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            a.setdefault("kommentare", []).append({"id": _neue_id(8), "von": ich, "am": _jetzt(), "text": text})
            return f"hat „{a['titel']}“ kommentiert"
        return self._aendere(pid, neu)

    def kommentar_loeschen(self, pid: str, aufgabe_id: str, kommentar_id: str) -> dict:
        def weg(p, ich):
            a = self._aufgabe(p, aufgabe_id)
            k = next((x for x in a.get("kommentare", []) if x["id"] == kommentar_id), None)
            if not k:
                return ""
            if k.get("von") != ich:
                raise ProjektFehler("Nur eigene Kommentare lassen sich löschen.")
            a["kommentare"] = [x for x in a["kommentare"] if x["id"] != kommentar_id]
            return ""
        return self._aendere(pid, weg)
