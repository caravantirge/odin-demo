"""
Tagesfragen: jeden Arbeitstag ein paar kurze Fragen – zu Teilen, Preisen, Fahrzeugen, Service, der Firma und ODIN
selbst. Wie bei einer Sprach-App: eine Frage nach der anderen, sofort die Auflösung, dazu eine Serie, ein Teamziel und
Lose für eine kleine Monatsverlosung. Mitmachen ist freiwillig; ausgewertet wird nichts für Beurteilung oder Lohn.

Woher die Fragen kommen (alle mit vier Antworten, genau eine richtig, dazu eine Erklärung und auf Wunsch eine Quelle):
- Aus den Daten (Teileliste, Bestand): Preis inkl. Montage, Arbeitswerte, Warengruppe, Stückliste, Nummernkreis.
  Sie entstehen bei jedem Laden neu und immer gleich (kein Zufall) – und nur aus echten Listen: mit den erfundenen
  Beispieldaten gibt es keine Datenfragen. Als Quelle steht der Stand der Liste dabei.
- Aus der eigenen Fragensammlung (fragen.json), gepflegt von den Verwaltern. Alle anderen dürfen Fragen vorschlagen
  (je Vorschlag eine Datei, Status „vorgeschlagen“); ein Verwalter gibt sie frei oder lehnt sie ab.
- Mitgeliefert: Fragen zur Bedienung von ODIN (ODIN_FRAGEN), damit sich alle zurechtfinden, und Fragen zu den
  Coaching-Modulen aus „Beirat & Coaching“ (BEIRAT_FRAGEN, Inhalte in beirat_inhalte.py) und zu den verbindlichen
  Hausregeln (HAUSREGEL_FRAGEN aus hausregeln.py – lassen sich nicht abschalten). Alle stehen im Programm,
  nicht im gemeinsamen Ordner: Mit einer neuen Fassung sind neue Fragen sofort für alle da – ohne Nachliefern und
  ohne etwas zu überschreiben. Ihre Kennungen bleiben fest, damit Verlauf und Wiederholung weiter passen.

Je Person und Arbeitstag bis zu fünf Fragen (die Verwalter stellen 1–5 ein, Standard 5), gemischt aus Datum und
Person (gleiche Eingabe – gleiche Auswahl). Vorn stehen fällige Wiederholungen – falsch Beantwortetes kommt nach
frühestens drei eigenen Arbeitstagen wieder –, dann Neues, dann am längsten nicht Gestelltes; die Quellen wechseln
sich ab. Beim ersten Abruf des Tages werden die Fragen samt Antwortreihenfolge in der Antwortdatei festgehalten –
ändern sich danach Listen, Sammlung oder Einstellungen, bleiben die Fragen des Tages, wie sie waren. Jede Frage lässt
sich nur einmal beantworten. „Heute überspringen“ geht mit einem Klick und zählt als nicht beantwortet.

Arbeitstage: Montag bis Freitag ohne gesetzliche Feiertage und ohne genehmigten Urlaub der Person (auch Betriebsurlaub,
beides aus den Urlaubsanträgen; ein halber Urlaubstag bleibt Arbeitstag). Gezählt wird ab dem ersten Tag, an dem
jemand im Team geantwortet hat – für später angelegte Personen ab ihrem Anlegetag.

Serie (nach der Regel „nie zweimal hintereinander auslassen“): aufeinanderfolgende Arbeitstage mit allen Fragen
beantwortet; richtig oder falsch ist egal, die Gewohnheit zählt. Ein ausgelassener Arbeitstag schadet nicht, zwei
in Folge beenden die Serie. Urlaub, Feiertage und Wochenenden pausieren sie, heute noch offen bricht nichts. Die
längste Serie wird zusätzlich in der Antwortdatei gemerkt.

Lose (nichts fürs Tempo): 1 je Tag mit allen Fragen beantwortet, 1 je richtige Antwort, 1 je „gelernt“ (eine Frage,
die zuletzt falsch war, jetzt richtig) und 3 je volle Woche (alle eigenen Arbeitstage erledigt; eine Woche zählt zum
Monat ihres Donnerstags). Bei der Verlosung dabei ist, wer an mindestens 80 % seiner Arbeitstage im Monat alles
beantwortet hat. Verlost wird gewichtet nach Losen mit dem Zufall des Betriebssystems.

Gespeichert wird wie bei Projekten und Urlaub im Ordner „Fahrzeuge“ unter _ODIN/Tagesfragen/:
- fragen.json                          eigene Fragensammlung (nur Verwalter ändern)
- vorschlaege/<id>.json                je Vorschlag eine Datei – zwei Rechner kommen sich nie in die Quere
- einstellungen.json                   Fragen je Tag, Preis und Teamziel je Monat, Rangliste an/aus,
                                       abgeschaltete Fragequellen
- antworten/<person>-<JJJJ-MM>.json    Antworten einer Person in einem Monat – so schreiben nie zwei Rechner
                                       dieselbe Datei
- verlosungen/<JJJJ-MM>.json           Ergebnis der Monatsverlosung mit Zeitpunkt, Teilnehmern, Losen und gezogenem
                                       Los. Wird nie überschrieben: erneut auslosen nur mit Begründung, die neue
                                       Ziehung kommt dazu.

Verwalter sind bis zu einer Rechteverwaltung die Urlaubs-Genehmiger. Statt einer Rangliste gibt es ein Teamziel
(richtige Antworten im Monat); die Rangliste ist aus, bis ein Verwalter sie einschaltet. Ohne sie sieht jeder nur
seine eigenen Werte und die des Teams. Wie bei Projekten und Urlaub regelt das nur die Oberfläche: wer die Dateien
öffnen kann, kann sie lesen.
"""

import bisect
import datetime as dt
import functools
import hashlib
import json
import math
import os
import random
import re
import secrets
import sqlite3
import threading

from . import beirat_inhalte, hausregeln
from .projekte import ProjektFehler
from .urlaub_antraege import UrlaubFehler, feiertag_namen

KATEGORIEN = ("Produkt", "Technik", "Verkauf", "Service", "Firma", "ODIN", "Beirat")
FRAGEN_JE_TAG = 5                       # Standard; Verwalter stellen 1–5 ein
LOSE_JE_TAG = 1                         # Tag mit allen Fragen beantwortet
LOSE_JE_RICHTIG = 1
LOSE_JE_GELERNT = 1                     # zuletzt falsch, jetzt richtig
LOSE_JE_WOCHE = 3
TEILNAHME_AB = 0.8                      # Anteil der Arbeitstage im Monat, an denen alles beantwortet sein muss
WIEDERHOLEN_NACH = 3                    # eigene Arbeitstage, nach denen falsch Beantwortetes wieder vorne steht
PREIS_ABSTAND = 0.10                    # Preis-Antworten liegen mindestens 10 % auseinander
AW_ABSTAND = 0.15                       # Arbeitswert-Antworten mindestens 15 % (und 1 AW)
ID_MUSTER = re.compile(r"[0-9a-f]{6,32}")
MODUL_MUSTER = re.compile(r"[a-z0-9]{6,32}")
MONAT_MUSTER = re.compile(r"\d{4}-(0[1-9]|1[0-2])")
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
FREIE_ARTEN = ("frei", "feiertag", "urlaub", "vor_beginn")
VERPASST_ARTEN = ("verpasst", "teilweise", "uebersprungen")

# Fragequellen, die Verwalter abschalten können (Schlüssel = Gruppe der Frage)
SCHALTBAR = {
    "daten-preis": "Preise inkl. Montage (Teileliste)",
    "daten-aw": "Arbeitswerte (Teileliste)",
    "daten-gruppe": "Warengruppen (Teileliste)",
    "daten-stueck": "Stücklisten (Teileliste)",
    "daten-praefix": "Nummernkreise der Fahrzeuge",
    "odin": "Bedienung von ODIN (mitgeliefert)",
    "beirat": "Beirat & Coaching: Verkaufstraining, Entscheiden, Struktur, Führung (mitgeliefert)",
}


class TagesfragenFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- Mitgelieferte Fragen zur Bedienung von ODIN
# Die richtige Antwort steht jeweils vorn; gezeigt wird in gemischter Reihenfolge. Nur Dinge, die in ODIN so sind –
# keine Fakten über Fahrzeuge oder Technik.

def _odin(fid, frage, antworten, erklaerung, kategorie="ODIN"):
    return {"id": "odin-" + fid, "frage": frage, "antworten": antworten, "richtig": 0, "erklaerung": erklaerung,
            "kategorie": kategorie, "quelle": "", "herkunft": "odin", "gruppe": "odin", "aktiv": True}


ODIN_FRAGEN = [
    _odin("urlaub", "Wo beantragst du Urlaub?",
          ["Team & Projekte → Urlaub", "Team & Projekte → To-dos", "Teile → Teile & Montage", "Übersicht"],
          "Unter Team & Projekte → Urlaub stellst du den Antrag. ODIN zählt die Arbeitstage selbst (ohne Wochenenden "
          "und Feiertage) – entscheiden tun die Genehmiger."),
    _odin("woche", "Wo stehen alle Termine der Woche – Übergaben, Sonderfahrten, Fristen und wer fehlt?",
          ["Heute & Woche", "Übersicht", "Fahrzeuge & Verkauf → Auslieferungen", "Team & Projekte → Meine Aufgaben"],
          "„Heute & Woche“ oben in der Seitenleiste sammelt alles mit einem Datum aus allen Listen – umschaltbar "
          "zwischen Heute, Diese Woche und Nächste Woche."),
    _odin("aufgaben", "Wo siehst du alle Aufgaben, für die du zuständig bist – über alle Projekte hinweg?",
          ["Team & Projekte → Meine Aufgaben", "Team & Projekte → To-dos", "Team & Projekte → Alle Projekte",
           "Heute & Woche"],
          "„Meine Aufgaben“ zeigt die offenen Aufgaben aus allen Projekten, in denen du zuständig bist. Die Zahl "
          "daneben sagt, wie viele es sind."),
    _odin("fragen", "Wo kannst du ODIN in normaler Sprache etwas fragen, z. B. „Was steht heute an?“",
          ["„Fragen“ oben in der Seitenleiste", "Datenquellen", "Team & Projekte → Tagesfragen", "Übersicht"],
          "Unter „Fragen“ beantwortet ODIN Fragen zu Bestand, Übergaben, Terminen und Teilen – Finanzzahlen nur für "
          "Berechtigte. Die Antworten kommen aus den eingelesenen Listen."),
    _odin("ab", "Wo prüft ODIN neue Auftragsbestätigungen gegen die vorherige AB?",
          ["Fahrzeuge & Verkauf → Auftragsbestätigungen", "Fahrzeuge & Verkauf → Bestand",
           "Finanzen → Linien & Bestellungen", "Fahrzeuge & Verkauf → Preisschilder & Texte"],
          "Unter „Auftragsbestätigungen“ holt „Eingang prüfen“ neue ABs, ordnet sie ihrem Fahrzeug zu und zeigt, was "
          "sich gegenüber der vorherigen AB geändert hat."),
    _odin("preisschild", "Wo macht ODIN aus Preisschild-PDFs den Fließtext für die Bestandsliste?",
          ["Fahrzeuge & Verkauf → Preisschilder & Texte", "Fahrzeuge & Verkauf → Fahrzeugordner",
           "Fahrzeuge & Verkauf → Ausstattungsvergleich", "Teile → Teile & Montage"],
          "PDFs unter „Preisschilder & Texte“ ins Fenster ziehen: ODIN liest Interne ID, Modell und Ausstattung. "
          "Strg+Enter kopiert den Text und springt zum nächsten Fahrzeug."),
    _odin("teile", "Wo findest du Arbeitswerte und Preise für Zubehör-Einbauten?",
          ["Teile → Teile & Montage", "Fahrzeuge & Verkauf → Auslieferungen", "Fahrzeuge & Verkauf → Bestand",
           "Finanzen → Provisionen"],
          "„Teile & Montage“ ist der Einbaukatalog aus der Teileliste: Preise, Arbeitswerte, Gewichte und der "
          "Lagerbestand aus der Artikelverwaltung."),
    _odin("datenquellen", "Wo legst du fest, welche Excel-Listen ODIN einliest?",
          ["Datenquellen – das Symbol unten in der Seitenleiste", "Fahrzeuge & Verkauf → Fahrzeugordner",
           "Übersicht", "Team & Projekte → Alle Projekte"],
          "Unter „Datenquellen“ wählst du je Liste die Excel-Datei. ODIN liest sie bei jedem Öffnen frisch ein und "
          "verändert sie nie."),
    _odin("aw", "Wie viele Minuten ist 1 AW (Arbeitswert) in ODIN und in der Teileliste?",
          ["6 Minuten", "10 Minuten", "12 Minuten", "15 Minuten"],
          "1 AW sind 6 Minuten, also 10 AW je Stunde. So rechnet ODIN Montagezeiten und den Lohnanteil.", "Service"),
    _odin("zinsfrei", "Wo siehst du, wie lange ein Fahrzeug bei der Bank noch zinsfrei ist?",
          ["Finanzen → Finanzierung", "Finanzen → Liquidität", "Finanzen → Provisionen",
           "Fahrzeuge & Verkauf → Bestand"],
          "„Finanzierung“ zeigt, welches Fahrzeug bei welcher Bank liegt – und wie lange noch zinsfrei."),
    _odin("vororder", "Wo siehst du, welche bestellten Fahrzeuge bis wann kommen und ob die Linie dafür reicht?",
          ["Finanzen → Linien & Bestellungen", "Finanzen → Liquidität", "Fahrzeuge & Verkauf → Auftragsbestätigungen",
           "Team & Projekte → To-dos"],
          "„Linien & Bestellungen“ zeigt die kommenden Fahrzeuge aus der Finanzaufstellung nach Monat und warnt, "
          "wenn eine Linie mit ihnen über das Limit läuft."),
    _odin("projekt", "Wo legst du ein neues Projekt an und holst Kolleginnen und Kollegen dazu?",
          ["Team & Projekte → Alle Projekte", "Team & Projekte → Meine Aufgaben", "Team & Projekte → To-dos",
           "Heute & Woche"],
          "Unter „Alle Projekte“ legst du ein Projekt an und fügst Mitglieder hinzu. Ein Projekt sehen nur seine "
          "Mitglieder."),
    _odin("fahrzeugordner", "Wo legst du einen Fahrzeugordner an, z. B. schon in der Bestellphase vor der ersten AB?",
          ["Fahrzeuge & Verkauf → Fahrzeugordner", "Fahrzeuge & Verkauf → Bestand",
           "Fahrzeuge & Verkauf → Auslieferungen", "Datenquellen"],
          "Unter „Fahrzeugordner“ → „Fahrzeug hinzufügen“ legt ODIN den Ordner mit Interner ID und Auftragsnummer "
          "an."),
    _odin("ausstattung", "Wo prüfst du, ob die Ausstattung in Syscara zur Auftragsbestätigung passt?",
          ["Fahrzeuge & Verkauf → Ausstattungsvergleich", "Fahrzeuge & Verkauf → Preisschilder & Texte",
           "Fahrzeuge & Verkauf → Bestand", "Teile → Teile & Montage"],
          "Der „Ausstattungsvergleich“ gleicht den Syscara-Export mit den ABs ab und sortiert nach Abweichung, "
          "Unsicher und Passt."),
    _odin("werkstatt", "Wo laufen die Werkstattaufträge?",
          ["In CaraCamp", "In ODIN unter Teile → Teile & Montage", "In ODIN unter Heute & Woche",
           "In der Auslieferungsliste"],
          "Werkstattaufträge laufen über CaraCamp. ODIN zeigt sie nicht – in „Heute & Woche“ stehen nur Übergaben, "
          "Sonderfahrten aus der Auslieferungsliste, Fristen und Aufgaben."),
    _odin("design", "Wie schaltest du zwischen hellem und dunklem Design um?",
          ["Mit dem Design-Knopf unten in der Seitenleiste", "Unter Datenquellen", "Unter Team & Projekte → Urlaub",
           "Gar nicht – ODIN gibt es nur hell"],
          "Der Knopf unten in der Seitenleiste wechselt zwischen automatisch (wie das Betriebssystem), hell und "
          "dunkel."),
    _odin("genehmiger", "Wer entscheidet über einen Urlaubsantrag?",
          ["Die Genehmiger", "ODIN automatisch nach den Regeln", "Wer zuerst beantragt hat",
           "Niemand – jeder Antrag gilt sofort"],
          "ODIN zeigt, was gegen einen Antrag spricht (Gruppen, Sperrzeiten, Resturlaub). Entscheiden tun Menschen: "
          "die Genehmiger."),
    _odin("serie", "Was passiert mit deiner Serie, wenn du einen Arbeitstag auslässt?",
          ["Nichts – erst zwei ausgelassene Tage hintereinander beenden sie", "Sie ist sofort weg",
           "Sie halbiert sich", "Du verlierst alle Lose des Monats"],
          "Einmal auslassen schadet nicht – nur nicht zweimal hintereinander. Urlaub, Feiertage und Wochenenden "
          "pausieren die Serie."),
    _odin("lose", "Wofür gibt es Lose für die Monatsverlosung?",
          ["Fürs Mitmachen und für richtige Antworten – nicht fürs Tempo", "Nur für die schnellsten Antworten",
           "Nur für die Besten des Monats", "Nur für Fragen ohne Fehler am ganzen Tag"],
          "1 Los je Tag mit allen Fragen, 1 je richtige Antwort, 1 extra, wenn eine früher falsche Frage jetzt "
          "sitzt, und 3 je volle Woche. Dabei ist, wer an mindestens 80 % seiner Arbeitstage mitgemacht hat."),
    _odin("ueberspringen", "Du hast heute keine Zeit für die Tagesfragen. Was tun?",
          ["„Heute überspringen“ – ein Tag schadet der Serie nicht", "Irgendwas anklicken, damit es erledigt ist",
           "Den Urlaub nachträglich beantragen", "Nichts – sonst gibt es Lose Abzug"],
          "Überspringen geht mit einem Klick und zählt als nicht beantwortet. Erst zwei ausgelassene Arbeitstage "
          "hintereinander beenden die Serie; Lose werden nie abgezogen."),
    _odin("freiwillig", "Wofür werden die Ergebnisse der Tagesfragen nie verwendet?",
          ["Für Beurteilung oder Lohn", "Für die Monatsverlosung", "Für deine Serie", "Für das Teamziel"],
          "Die Tagesfragen sind freiwillig und zum Lernen da. Eine Rangliste gibt es nur, wenn die Verwalter sie "
          "einschalten – sonst sieht jeder nur seine eigenen Werte und die des Teams."),
]


# ---------------------------------------------------------------- Mitgelieferte Fragen aus „Beirat & Coaching“
# Aus beirat_inhalte.FRAGEN (richtige Antwort vorn). Die Erklärung verweist auf das Modul; „modul“ führt in der
# Oberfläche nach der Antwort direkt dorthin (#/beirat/modul/<id>).

def _beirat_fragen() -> list:
    titel = {m["id"]: m["titel"] for m in beirat_inhalte.MODULE}
    fragen = []
    for fid, frage, antworten, erklaerung, modul in beirat_inhalte.FRAGEN:
        wo = f"Beirat & Coaching → {titel[modul]}"
        fragen.append({"id": "beirat-" + fid, "frage": frage, "antworten": list(antworten), "richtig": 0,
                       "erklaerung": f"{erklaerung} Mehr dazu: {wo}.", "kategorie": "Beirat", "quelle": wo,
                       "herkunft": "beirat", "gruppe": "beirat", "aktiv": True, "modul": modul})
    return fragen


BEIRAT_FRAGEN = _beirat_fragen()


# ---------------------------------------------------------------- Mitgelieferte Fragen zu den Hausregeln
# Aus hausregeln.FRAGEN (richtige Antwort = die Regel). Verbindlich – deshalb keine abschaltbare Quelle. „regel“
# führt nach der Antwort zu den Hausregeln (#/wissen/hausregeln).

def _hausregel_fragen() -> list:
    fragen = []
    for fid, frage, antworten, erklaerung, rid in hausregeln.FRAGEN:
        fragen.append({"id": "hausregel-" + fid, "frage": frage, "antworten": list(antworten), "richtig": 0,
                       "erklaerung": f"{erklaerung} Nachzulesen unter {hausregeln.WO}.", "kategorie": "Verkauf",
                       "quelle": f"Hausregel {rid}", "herkunft": "hausregel", "gruppe": "hausregeln", "aktiv": True,
                       "regel": rid})
    return fragen


HAUSREGEL_FRAGEN = _hausregel_fragen()


# ---------------------------------------------------------------- kleine Helfer

def _neue_id(laenge: int = 12) -> str:
    return secrets.token_hex(laenge // 2)


def _text(wert, laenge: int) -> str:
    return " ".join(str(wert or "").split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    return str(wert or "").replace("\r\n", "\n").strip()[:laenge]


def _norm(wert) -> str:
    """Zum Vergleichen von Antworten: ohne Groß/klein und doppelte Leerzeichen."""
    return " ".join(str(wert or "").split()).casefold()


def _hash(*teile) -> int:
    """Fester „Zufall“: gleiche Eingabe, gleiche Zahl – auf jedem Rechner und nach jedem Neustart."""
    return int(hashlib.sha256("|".join(str(t) for t in teile).encode("utf-8")).hexdigest()[:16], 16)


def _zahl(wert) -> str:
    """4.5 → „4,5“, 5.0 → „5“."""
    return f"{round(float(wert), 2):g}".replace(".", ",")


def _euro(betrag, cent: bool = True) -> str:
    """1234.5 → „1.234,50 €“, 1290 → „1.290 €“; cent=False rundet auf ganze Euro."""
    hundertstel = round(float(betrag) * 100) if cent else round(float(betrag)) * 100
    euro, rest = divmod(abs(hundertstel), 100)
    text = f"{euro:,}".replace(",", ".") + (f",{rest:02d}" if rest else "")
    return ("-" if hundertstel < 0 else "") + text + " €"


def _dauer(minuten) -> str:
    minuten = round(float(minuten))
    if minuten < 60:
        return f"{minuten} Min."
    stunden, rest = divmod(minuten, 60)
    return f"{stunden} Std." + (f" {rest} Min." if rest else "")


def _deutsches_datum(iso: str) -> str:
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if ISO_DATUM.fullmatch(str(iso)[:10]) else ""


def _vier_verschiedene(antworten) -> bool:
    return (isinstance(antworten, list) and len(antworten) == 4 and all(_norm(a) for a in antworten)
            and len({_norm(a) for a in antworten}) == 4)


def _datum(iso) -> dt.date:
    return dt.date.fromisoformat(iso) if isinstance(iso, str) else iso


def _monatstage(monat: str) -> list:
    jahr, m = int(monat[:4]), int(monat[5:7])
    d = dt.date(jahr, m, 1)
    tage = []
    while d.month == m:
        tage.append(d)
        d += dt.timedelta(days=1)
    return tage


def _lies(pfad: str):
    from .speicher import lies_json
    try:
        return lies_json(pfad)
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as e:
        raise TagesfragenFehler(f"„{os.path.basename(pfad)}“ ist gerade nicht lesbar ({e}). "
                                "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise TagesfragenFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


# ---------------------------------------------------------------- Fragen aus den Daten

def _gesamtpreis(t: dict) -> tuple:
    """(Gesamt brutto, Teil brutto, Montage brutto) – gerechnet wie die Spalte „Gesamt brutto“ in Teile & Montage."""
    teil = t.get("vk_brutto")
    if teil is None:
        teil = (t.get("sales_net") or 0) * 1.19
    lohn = t.get("lohn_vk")
    if lohn is None:
        lohn = (t.get("aw") or 0) * (t.get("vk_pro_aw") or 0)
    if t.get("set_preis") is not None:
        gesamt = t["set_preis"]
    elif t.get("stueckliste"):
        gesamt = teil + lohn + (t.get("stueckliste_vk") or 0)
    else:
        gesamt = teil + lohn
    return round(float(gesamt or 0), 2), round(float(teil or 0), 2), round(float(lohn or 0), 2)


def _nach_naehe(werte_sortiert: list, ziel: float):
    """Werte (aufsteigend sortiert, > 0) in der Reihenfolge ihres Abstands zu `ziel` (im Verhältnis)."""
    i = bisect.bisect_left(werte_sortiert, ziel)
    links, rechts = i - 1, i
    while links >= 0 or rechts < len(werte_sortiert):
        if rechts >= len(werte_sortiert) or (links >= 0 and ziel / werte_sortiert[links] <= werte_sortiert[rechts] / ziel):
            yield werte_sortiert[links]
            links -= 1
        else:
            yield werte_sortiert[rechts]
            rechts += 1


def _ablenker(richtig: float, quellen: list, unterscheidbar, ausser=()) -> list:
    """
    Drei falsche Werte: zuerst aus der ersten Quelle (z. B. derselben Warengruppe), dann aus den weiteren – jeweils die
    nächstgelegenen, die sich von der richtigen Antwort und untereinander deutlich unterscheiden.
    """
    gewaehlt = []
    for werte in quellen:
        for w in _nach_naehe(werte, richtig):
            if w in ausser or not all(unterscheidbar(w, x) for x in [richtig] + gewaehlt):
                continue
            gewaehlt.append(w)
            if len(gewaehlt) == 3:
                return gewaehlt
    return gewaehlt


def _preis_unterscheidbar(a: float, b: float) -> bool:
    return round(a) != round(b) and abs(a - b) >= PREIS_ABSTAND * max(a, b)


def _aw_unterscheidbar(a: float, b: float) -> bool:
    return abs(a - b) >= max(1.0, AW_ABSTAND * max(a, b))


def _aw_text(aw: float) -> str:
    return f"{_zahl(aw)} AW ({_dauer(aw * 6)})"


def _wortstamm(text: str) -> str:
    woerter = re.findall(r"[a-zäöüß]+", str(text or "").casefold())
    return woerter[0][:5] if woerter else ""


def _datenfrage(fid, gruppe, kategorie, frage, richtig, ablenker, erklaerung, quelle) -> dict:
    return {"id": fid, "frage": frage, "antworten": [richtig] + list(ablenker), "richtig": 0,
            "erklaerung": erklaerung, "kategorie": kategorie, "quelle": quelle, "herkunft": "daten",
            "gruppe": gruppe, "aktiv": True}


def _bezeichnung(t: dict) -> str:
    name = _text(t.get("name"), 140)
    typ = _text(t.get("fahrzeugtyp"), 60)
    return f"„{name}“" + (f" ({typ})" if typ else "")


def _preisfragen(teile: list, quelle: str) -> list:
    eintraege = []
    for t in teile:
        name = _text(t.get("name"), 140)
        gesamt, teil, lohn = _gesamtpreis(t)
        if name and t.get("sku") and gesamt > 0:
            eintraege.append((t, name, gesamt, teil, lohn))
    preise_je_name, je_gruppe = {}, {}
    for t, name, gesamt, _, _ in eintraege:
        preise_je_name.setdefault(name.casefold(), set()).add(round(gesamt))
        je_gruppe.setdefault(t.get("warengruppe") or "", set()).add(gesamt)
    alle = sorted({g for _, _, g, _, _ in eintraege})
    je_gruppe = {k: sorted(v) for k, v in je_gruppe.items()}
    fragen, gesehen = [], set()
    for t, name, gesamt, teil, lohn in eintraege:
        schluessel = (_norm(t.get("produkt") or name), _norm(t.get("fahrzeugtyp")), round(gesamt))
        if schluessel in gesehen:
            continue                                  # Farbvarianten zum selben Preis: eine Frage reicht
        gesehen.add(schluessel)
        # Preise derselben Bezeichnung (z. B. in einem anderen Abschnitt) taugen nicht als falsche Antwort
        eigene = {p for p in alle if round(p) in preise_je_name[name.casefold()]}
        abl = _ablenker(gesamt, [je_gruppe[t.get("warengruppe") or ""], alle], _preis_unterscheidbar, ausser=eigene)
        if len(abl) < 3:
            continue
        mit_montage = lohn > 0 or t.get("set_preis") is not None
        frage = f"Was kostet {_bezeichnung(t)}{' inklusive Montage' if mit_montage else ''} – brutto, gerundet?"
        if t.get("set_preis") is not None:
            erkl = f"{_bezeichnung(t)} kostet {_euro(gesamt)} brutto – der feste Preis aus der Teileliste."
        elif lohn > 0:
            aw = t.get("aw")
            stueck = t.get("stueckliste_vk") if t.get("stueckliste") else 0
            erkl = (f"{_bezeichnung(t)}: Teil {_euro(teil)} + Montage {_euro(lohn)}"
                    + (f" ({_zahl(aw)} AW)" if aw else "")
                    + (f" + Unterartikel {_euro(stueck)}" if stueck else "") + f" = {_euro(gesamt)} brutto.")
        else:
            erkl = f"{_bezeichnung(t)} kostet {_euro(gesamt)} brutto."
        fragen.append(_datenfrage(f"d-preis-{t['sku']}", "daten-preis", "Verkauf", frage, _euro(gesamt, cent=False),
                                  [_euro(x, cent=False) for x in abl],
                                  erkl + " Nachzuschlagen unter Teile → Teile & Montage.", quelle))
    return fragen


def _aw_fragen(teile: list, quelle: str) -> list:
    eintraege = [(t, float(t["aw"])) for t in teile
                 if t.get("sku") and _text(t.get("name"), 140) and isinstance(t.get("aw"), (int, float)) and t["aw"] > 0]
    je_gruppe = {}
    for t, aw in eintraege:
        je_gruppe.setdefault(t.get("warengruppe") or "", set()).add(aw)
    alle = sorted({aw for _, aw in eintraege})
    je_gruppe = {k: sorted(v) for k, v in je_gruppe.items()}
    fragen, gesehen = [], set()
    for t, aw in eintraege:
        schluessel = (_norm(t.get("produkt") or t.get("name")), _norm(t.get("fahrzeugtyp")), aw)
        if schluessel in gesehen:
            continue
        gesehen.add(schluessel)
        abl = _ablenker(aw, [je_gruppe[t.get("warengruppe") or ""], alle], _aw_unterscheidbar)
        if len(abl) < 3:
            continue
        minuten = t.get("install_minutes")
        erkl = (f"Für {_bezeichnung(t)} stehen {_zahl(aw)} AW in der Teileliste"
                + (f", als Zeit {_dauer(minuten)}" if minuten
                   else f" – bei 1 AW = 6 Minuten sind das {_dauer(aw * 6)}"))
        erkl = erkl + ("" if erkl.endswith(".") else ".") + " Nachzuschlagen unter Teile → Teile & Montage."
        fragen.append(_datenfrage(f"d-aw-{t['sku']}", "daten-aw", "Service",
                                  f"Wie viele Arbeitswerte (AW) stehen in der Teileliste für {_bezeichnung(t)}?",
                                  _aw_text(aw), [_aw_text(x) for x in abl], erkl, quelle))
    return fragen


def _gruppenfragen(teile: list, quelle: str) -> list:
    gruppen = sorted({_text(t.get("warengruppe"), 60) for t in teile if _text(t.get("warengruppe"), 60)})
    if len(gruppen) < 4:
        return []
    fragen, gesehen = [], set()
    for t in teile:
        name, wg = _text(t.get("name"), 140), _text(t.get("warengruppe"), 60)
        produkt = _norm(t.get("produkt") or name)
        if not name or not wg or not t.get("sku") or produkt in gesehen:
            continue
        gesehen.add(produkt)
        # Steckt die Warengruppe schon im Namen („Markise …“ → Markisen), wäre die Frage geschenkt
        if _wortstamm(wg) and _wortstamm(wg) in name.casefold():
            continue
        andere = sorted((g for g in gruppen if g != wg and not (_wortstamm(g) and _wortstamm(g) in name.casefold())),
                        key=lambda g: _hash("gruppe", t["sku"], g))
        if len(andere) < 3:
            continue
        fragen.append(_datenfrage(f"d-gruppe-{t['sku']}", "daten-gruppe", "Produkt",
                                  f"Zu welcher Warengruppe gehört {_bezeichnung(t)} in der Teileliste?", wg, andere[:3],
                                  f"{_bezeichnung(t)} steht in der Teileliste unter „{wg}“. Nachzuschlagen unter "
                                  "Teile → Teile & Montage.", quelle))
    return fragen


def _stuecklistenfragen(teile: list, quelle: str) -> list:
    sets = [t for t in teile if t.get("stueckliste") and t.get("sku") and _text(t.get("name"), 140)]
    if not sets:
        return []
    alle_positionen = sorted({_text(p.get("name"), 140) for t in sets for p in t["stueckliste"]
                              if _text(p.get("name"), 140)})
    je_gruppe = {}
    for t in teile:
        if _text(t.get("name"), 140):
            je_gruppe.setdefault(t.get("warengruppe") or "", set()).add(_text(t.get("name"), 140))
    fragen = []
    for t in sets:
        set_name = _text(t["name"], 140)
        positionen = list(dict.fromkeys(_text(p.get("name"), 140) for p in t["stueckliste"]
                                        if _text(p.get("name"), 140)))
        if not positionen:
            continue
        verboten = {_norm(p) for p in positionen} | {_norm(set_name)}
        kandidaten = sorted((n for n in alle_positionen if _norm(n) not in verboten),
                            key=lambda n: _hash("stueck", t["sku"], n))
        ersatz = sorted((n for n in je_gruppe.get(t.get("warengruppe") or "", ()) if _norm(n) not in verboten),
                        key=lambda n: _hash("stueck", t["sku"], n))
        abl = []
        for n in kandidaten + ersatz:
            if _norm(n) not in {_norm(x) for x in abl}:
                abl.append(n)
        if len(abl) < 3:
            continue
        fragen.append(_datenfrage(f"d-stueck-{t['sku']}", "daten-stueck", "Produkt",
                                  f"Welcher Unterartikel muss mit {_bezeichnung(t)} mitbestellt werden?",
                                  positionen[0], abl[:3],
                                  f"Zur Stückliste von {_bezeichnung(t)} gehören: {', '.join(positionen)}. Diese Teile "
                                  "werden mit dem Artikel bestellt (Teile & Montage → Stückliste aufklappen).", quelle))
    return fragen


def _praefixfragen(conn, praefixe: dict, quelle: str) -> list:
    beispiele = {}
    for (iid,) in conn.execute("SELECT internal_id FROM vehicles WHERE internal_id IS NOT NULL ORDER BY internal_id"):
        m = re.match(r"([A-Z]+)\d", str(iid).upper())
        if m:
            beispiele.setdefault(m.group(1), str(iid))
    bezeichnung = {p: " ".join(x for x in ((info or {}).get("marke"), (info or {}).get("kategorie")) if x)
                   for p, info in praefixe.items()}
    bezeichnung = {p: b for p, b in bezeichnung.items() if b}
    fragen = []
    for p in sorted(beispiele):
        richtig = bezeichnung.get(p)
        if not richtig or p.casefold() in richtig.casefold():
            continue                                  # „PKW“ steht für PKW – keine Frage
        woerter = set(richtig.casefold().split())
        andere = sorted({b for q, b in bezeichnung.items() if q != p and _norm(b) != _norm(richtig)},
                        key=lambda b: (not (woerter & set(b.casefold().split())), _hash("praefix", p, b)))
        if len(andere) < 3:
            continue
        fragen.append(_datenfrage(f"d-praefix-{p}", "daten-praefix", "Firma",
                                  f"Wofür steht „{p}“ in der internen Fahrzeugnummer (z. B. {beispiele[p]})?", richtig,
                                  andere[:3],
                                  f"{p} steht für {richtig}, z. B. {beispiele[p]}. Die interne Nummer ist das Präfix "
                                  "plus fünf Ziffern; die Nummernkreise kommen aus CaraCamp.", quelle))
    return fragen


def _quelle_aus_db(conn, tabelle: str, name: str) -> str:
    """„Teileliste „Datei.xlsx““ aus der Spalte source_file – wenn das Cockpit keinen Dateistand liefert."""
    try:
        zeile = conn.execute(f"SELECT source_file FROM {tabelle} WHERE source_file IS NOT NULL "
                             "GROUP BY source_file ORDER BY COUNT(*) DESC LIMIT 1").fetchone()
    except sqlite3.Error:
        zeile = None
    return f"{name} „{zeile[0]}“" if zeile and zeile[0] else name


def datenfragen(conn, stand: dict = None) -> list:
    """
    Alle Fragen, die sich aus der Cockpit-Datenbank bilden lassen – ohne Zufall: gleiche Daten ergeben gleiche Fragen.
    `stand` ({"teile": …, "fahrzeuge": …}) beschreibt die Datenbasis; er steht als Quelle an jeder Frage.
    """
    from .cockpit.auswertungen import teile_katalog
    from .cockpit.db import lade_vorlage
    stand = stand or {}
    quelle_teile = stand.get("teile") or _quelle_aus_db(conn, "parts", "Teileliste")
    quelle_fahrzeuge = stand.get("fahrzeuge") or _quelle_aus_db(conn, "vehicles", "Bestandsliste")
    try:
        teile = teile_katalog(conn)
    except sqlite3.Error:
        teile = []
    teile = sorted(teile, key=lambda t: str(t.get("sku") or ""))
    fragen = (_preisfragen(teile, quelle_teile) + _aw_fragen(teile, quelle_teile)
              + _gruppenfragen(teile, quelle_teile) + _stuecklistenfragen(teile, quelle_teile))
    try:
        fragen += _praefixfragen(conn, lade_vorlage("praefixe").get("praefixe") or {},
                                 f"Nummernkreise aus CaraCamp, Beispiel aus {quelle_fahrzeuge}")
    except (sqlite3.Error, OSError, ValueError):
        pass
    return [f for f in fragen if _vier_verschiedene(f["antworten"])]


# ---------------------------------------------------------------- Eigene Fragen prüfen

def _frage_pruefen(e: dict) -> dict:
    """Eingabe aus der Oberfläche → gespeicherte Form; Fehler als Meldung für Menschen."""
    e = e if isinstance(e, dict) else {}
    frage = _langtext(e.get("frage"), 300)
    if len(frage) < 5:
        raise TagesfragenFehler("Bitte die Frage eingeben.")
    antworten = e.get("antworten")
    if not isinstance(antworten, list) or len(antworten) != 4:
        raise TagesfragenFehler("Bitte genau vier Antworten eingeben.")
    antworten = [_text(a, 160) for a in antworten]
    if not all(antworten):
        raise TagesfragenFehler("Bitte alle vier Antworten ausfüllen.")
    if len({_norm(a) for a in antworten}) != 4:
        raise TagesfragenFehler("Zwei Antworten sind gleich – bitte vier verschiedene eingeben.")
    try:
        richtig = int(e.get("richtig"))
    except (TypeError, ValueError):
        raise TagesfragenFehler("Bitte die richtige Antwort markieren.") from None
    if not 0 <= richtig <= 3:
        raise TagesfragenFehler("Bitte die richtige Antwort markieren.")
    erklaerung = _langtext(e.get("erklaerung"), 600)
    if len(erklaerung) < 5:
        raise TagesfragenFehler("Bitte kurz erklären, warum die Antwort stimmt – das sehen alle nach dem Antworten.")
    kategorie = e.get("kategorie")
    if kategorie not in KATEGORIEN:
        raise TagesfragenFehler(f"Bitte eine Kategorie wählen ({', '.join(KATEGORIEN)}).")
    return {"frage": frage, "antworten": antworten, "richtig": richtig, "erklaerung": erklaerung,
            "kategorie": kategorie, "quelle": _text(e.get("quelle"), 160), "aktiv": e.get("aktiv", True) is not False}


def _eigene_lesbar(f) -> bool:
    return (isinstance(f, dict) and ID_MUSTER.fullmatch(str(f.get("id") or "")) is not None
            and isinstance(f.get("frage"), str) and _vier_verschiedene(f.get("antworten"))
            and isinstance(f.get("richtig"), int) and 0 <= f["richtig"] <= 3 and f.get("kategorie") in KATEGORIEN)


def _modul(f) -> str:
    """Kennung des Beirat-Moduls einer Frage – nur in sicherer Form (sie wird zur Adresse #/beirat/modul/<id>)."""
    m = f.get("modul") if isinstance(f, dict) else None
    return m if isinstance(m, str) and MODUL_MUSTER.fullmatch(m) else ""


def _regel(f) -> str:
    """Kennung der Hausregel einer Frage – nur in sicherer Form (BEREICH-NNN)."""
    r = f.get("regel") if isinstance(f, dict) else None
    return r if isinstance(r, str) and hausregeln.ID_MUSTER.fullmatch(r) else ""


def _schnappschuss_lesbar(f) -> bool:
    return (isinstance(f, dict) and isinstance(f.get("id"), str) and isinstance(f.get("frage"), str)
            and isinstance(f.get("antworten"), list) and len(f["antworten"]) >= 2
            and isinstance(f.get("richtig"), int) and 0 <= f["richtig"] < len(f["antworten"]))


# ---------------------------------------------------------------- Die Tagesfragen

def _gesperrt(methode):
    """Schreibende Aufrufe nacheinander: zwei schnelle Klicks verlieren so keine Antwort in der Antwortdatei."""
    @functools.wraps(methode)
    def huelle(self, *argumente, **schluessel):
        with self._sperre:
            return methode(self, *argumente, **schluessel)
    return huelle


class Tagesfragen:
    """
    `projekte` liefert Personen und „ich“, `urlaub_fabrik()` das Urlaub-Objekt (Genehmiger = Verwalter, genehmigte
    Abwesenheiten), `cockpit` die eingelesenen Listen (ein Cockpit oder – für Tests und Werkzeuge – direkt eine
    sqlite3-Verbindung, None ohne Datenfragen). `jetzt` und `zufall` lassen sich für Tests ersetzen.
    """

    def __init__(self, projekte, urlaub_fabrik, cockpit=None, jetzt=None, zufall=None, protokoll=None):
        self._projekte = projekte
        self._urlaub_fabrik = urlaub_fabrik
        self._cockpit = cockpit
        self._jetzt = jetzt or dt.datetime.now
        self._zufall = zufall or random.SystemRandom()
        self._protokoll = protokoll or (lambda text: None)
        self._daten_cache = (None, [])
        self._sperre = threading.RLock()

    # ---------------- Orte ----------------
    def _ordner(self) -> str:
        return os.path.join(self._projekte._basis()[0], "Tagesfragen")

    def _fragen_pfad(self) -> str:
        return os.path.join(self._ordner(), "fragen.json")

    def _einstellungen_pfad(self) -> str:
        return os.path.join(self._ordner(), "einstellungen.json")

    def _vorschlag_ordner(self) -> str:
        return os.path.join(self._ordner(), "vorschlaege")

    def _vorschlag_pfad(self, vid: str) -> str:
        if not ID_MUSTER.fullmatch(str(vid or "")):
            raise TagesfragenFehler("Unbekannter Vorschlag.")
        return os.path.join(self._vorschlag_ordner(), f"{vid}.json")

    def _antwort_ordner(self) -> str:
        return os.path.join(self._ordner(), "antworten")

    def _antwort_pfad(self, pid: str, monat: str) -> str:
        if not ID_MUSTER.fullmatch(str(pid or "")) or not MONAT_MUSTER.fullmatch(str(monat or "")):
            raise TagesfragenFehler("Unbekannte Person oder unbekannter Monat.")
        return os.path.join(self._antwort_ordner(), f"{pid}-{monat}.json")

    def _verlosung_ordner(self) -> str:
        return os.path.join(self._ordner(), "verlosungen")

    def _verlosung_pfad(self, monat: str) -> str:
        if not MONAT_MUSTER.fullmatch(str(monat or "")):
            raise TagesfragenFehler("Bitte einen Monat wählen.")
        return os.path.join(self._verlosung_ordner(), f"{monat}.json")

    def _zeit(self) -> str:
        return self._jetzt().isoformat(timespec="seconds")

    # ---------------- Personen und Rechte ----------------
    def _urlaub(self):
        return self._urlaub_fabrik()

    def _personen(self) -> dict:
        try:
            return {p["id"]: p for p in self._projekte.personen()}
        except ProjektFehler as e:
            raise TagesfragenFehler(str(e)) from None

    def _ich(self, personen: dict) -> str:
        try:
            ich = self._projekte.ich()
        except ProjektFehler as e:
            raise TagesfragenFehler(str(e)) from None
        return ich if ich in personen else ""

    def _verwalter(self, personen: dict, ich: str) -> tuple:
        """(bin ich Verwalter, fehlt noch jeder Verwalter) – Verwalter sind die Urlaubs-Genehmiger."""
        try:
            regeln = self._urlaub().regeln()
        except (UrlaubFehler, ProjektFehler) as e:
            raise TagesfragenFehler(str(e)) from None
        genehmiger = [g for g in regeln.get("genehmiger") or [] if g in personen]
        return bool(ich) and ich in genehmiger, not genehmiger

    def _lauf(self, ich_pflicht: bool = True) -> dict:
        """Was ein Aufruf einmal liest und dann wiederverwendet."""
        personen = self._personen()
        ich = self._ich(personen)
        if ich_pflicht and not ich:
            raise TagesfragenFehler("Bitte zuerst auswählen, wer du bist.")
        return {"personen": personen, "ich": ich, "heute": self._jetzt().date(), "abwesend": {}, "dateien": {},
                "hinweise": [], "auswertung": {}}

    def _verwalter_pflicht(self, lauf: dict):
        ist, _ = self._verwalter(lauf["personen"], lauf["ich"])
        if not ist:
            raise TagesfragenFehler("Das dürfen nur Verwalter (die Urlaubs-Genehmiger).")

    # ---------------- Einstellungen ----------------
    def _einstellungen(self) -> dict:
        roh = _lies(self._einstellungen_pfad())
        roh = roh if isinstance(roh, dict) else {}
        woerterbuch = lambda w: w if isinstance(w, dict) else {}
        zahl = roh.get("fragen_je_tag")
        ziele = {}
        for m, z in woerterbuch(roh.get("teamziele")).items():
            if MONAT_MUSTER.fullmatch(str(m)) and isinstance(z, int) and not isinstance(z, bool) and z > 0:
                ziele[m] = z
        return {"version": 1, "rangliste": roh.get("rangliste") is True,
                "fragen_je_tag": zahl if isinstance(zahl, int) and not isinstance(zahl, bool) and 1 <= zahl <= 5
                else FRAGEN_JE_TAG,
                "preise": {m: _text(t, 200) for m, t in woerterbuch(roh.get("preise")).items()
                           if MONAT_MUSTER.fullmatch(str(m)) and _text(t, 200)},
                "teamziele": ziele,
                "aus": [k for k in roh.get("aus") or [] if k in SCHALTBAR],
                "geaendert_am": roh.get("geaendert_am"), "geaendert_von": roh.get("geaendert_von")}

    def einstellungen_speichern(self, eingabe: dict) -> dict:
        """
        Verwalter: Fragen je Tag (1–5), Rangliste an/aus, Preis eines Monats ({monat, text}), Teamziel eines Monats
        ({monat, ziel} – richtige Antworten im Team), abgeschaltete Fragequellen.
        """
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        e = eingabe if isinstance(eingabe, dict) else {}
        einst = self._einstellungen()
        jetzt_monat = lauf["heute"].isoformat()[:7]

        def monat_aus(teil):
            monat = str(teil.get("monat") or jetzt_monat)
            if not MONAT_MUSTER.fullmatch(monat):
                raise TagesfragenFehler("Bitte einen Monat wählen.")
            return monat
        if "rangliste" in e:
            einst["rangliste"] = bool(e["rangliste"])
        if "fragen_je_tag" in e:
            try:
                zahl = int(e["fragen_je_tag"])
            except (TypeError, ValueError):
                zahl = 0
            if not 1 <= zahl <= 5:
                raise TagesfragenFehler("Fragen je Tag: bitte eine Zahl von 1 bis 5.")
            einst["fragen_je_tag"] = zahl
        if "preis" in e:
            p = e["preis"] if isinstance(e["preis"], dict) else {}
            monat, text = monat_aus(p), _text(p.get("text"), 200)
            if text:
                einst["preise"][monat] = text
            else:
                einst["preise"].pop(monat, None)
        if "teamziel" in e:
            z = e["teamziel"] if isinstance(e["teamziel"], dict) else {}
            monat = monat_aus(z)
            if z.get("ziel") in (None, "", 0, "0"):
                einst["teamziele"].pop(monat, None)
            else:
                try:
                    ziel = int(z["ziel"])
                except (TypeError, ValueError):
                    ziel = 0
                if not 1 <= ziel <= 100000:
                    raise TagesfragenFehler("Teamziel: bitte eine ganze Zahl richtiger Antworten (mindestens 1).")
                einst["teamziele"][monat] = ziel
        if "aus" in e:
            aus = e["aus"] if isinstance(e["aus"], list) else []
            einst["aus"] = [k for k in SCHALTBAR if k in aus]
        einst["geaendert_am"], einst["geaendert_von"] = self._zeit(), lauf["ich"]
        _schreibe(self._einstellungen_pfad(), einst)
        return self._oeffentliche_einstellungen(einst, lauf, True)

    def _oeffentliche_einstellungen(self, einst: dict, lauf: dict, verwalter: bool) -> dict:
        monat = lauf["heute"].isoformat()[:7]
        aus = {"monat": monat, "rangliste": einst["rangliste"], "preis": einst["preise"].get(monat, ""),
               "teamziel": einst["teamziele"].get(monat), "fragen_je_tag": einst["fragen_je_tag"]}
        if verwalter:
            aus.update(preise=einst["preise"], teamziele=einst["teamziele"], aus=einst["aus"], schaltbar=SCHALTBAR)
        return aus

    # ---------------- Fragensammlung und Vorschläge ----------------
    def _eigene(self) -> list:
        roh = _lies(self._fragen_pfad())
        liste = roh.get("fragen") if isinstance(roh, dict) else None
        return [{**f, "quelle": _text(f.get("quelle"), 160), "herkunft": "eigene", "gruppe": "eigene-" + f["kategorie"],
                 "aktiv": f.get("aktiv", True) is not False}
                for f in (liste or []) if _eigene_lesbar(f)]

    def _cockpit_stand(self, c) -> dict:
        """Datei und Stand von Teileliste und Bestandsliste, wie das Cockpit sie zuletzt gelesen hat."""
        stand = {}
        for q in (getattr(c, "_daten", None) or {}).get("quellen") or []:
            if q.get("datei") and q.get("art") in ("teilepreise", "bestandsliste"):
                text = f"{q.get('name') or ''} „{q['datei']}“".strip()
                if q.get("stand"):
                    text += f", Stand {_deutsches_datum(q['stand'])}"
                stand["teile" if q["art"] == "teilepreise" else "fahrzeuge"] = text
        return stand

    def _datenfragen(self) -> list:
        """Fragen aus den eingelesenen Listen – nie aus den Beispieldaten. Fehler halten die Tagesfragen nicht auf."""
        c = self._cockpit
        if c is None:
            return []
        try:
            if isinstance(c, sqlite3.Connection):
                schluessel = (id(c), c.total_changes)
                if self._daten_cache[0] != schluessel:
                    self._daten_cache = (schluessel, datenfragen(c))
                return self._daten_cache[1]
            if c._ist_beispiel():
                return []
            c.daten()
            with c._sperre:
                conn = c._conn
                if conn is None:
                    return []
                schluessel = (id(conn), c._signatur)
                if self._daten_cache[0] != schluessel:
                    self._daten_cache = (schluessel, datenfragen(conn, self._cockpit_stand(c)))
                return self._daten_cache[1]
        except Exception as e:                      # z. B. Liste gerade gesperrt – dann eben ohne Datenfragen
            self._protokoll(f"Tagesfragen: Datenfragen nicht möglich: {e!r}")
            return []

    def _pool(self, lauf: dict) -> list:
        if "pool" not in lauf:
            aus = set(self._einstellungen()["aus"])
            pool = [] if "odin" in aus else [dict(f) for f in ODIN_FRAGEN]
            pool += [] if "beirat" in aus else [dict(f) for f in BEIRAT_FRAGEN]
            pool += [dict(f) for f in HAUSREGEL_FRAGEN]                     # verbindlich: immer dabei
            pool += [f for f in self._eigene() if f["aktiv"]]
            pool += [f for f in self._datenfragen() if f["gruppe"] not in aus]
            lauf["pool"] = pool
        return lauf["pool"]

    def fragen_liste(self) -> dict:
        """Verwalter: eigene Fragen (auch abgeschaltete), offene Vorschläge, mitgelieferte, Datenfragen je Art."""
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        einst = self._einstellungen()
        daten, beispiele = {}, {}
        for f in self._datenfragen():
            daten[f["gruppe"]] = daten.get(f["gruppe"], 0) + 1
            beispiele.setdefault(f["gruppe"], {k: f[k] for k in ("frage", "antworten", "richtig", "quelle")})
        eigene = sorted(self._eigene(), key=lambda f: (not f["aktiv"], f.get("kategorie", ""), _norm(f["frage"])))
        return {"eigene": eigene, "vorschlaege": [v for v in self._vorschlaege_alle(lauf) if v["status"] == "vorgeschlagen"],
                "mitgeliefert": ODIN_FRAGEN, "beirat": BEIRAT_FRAGEN, "hausregeln": HAUSREGEL_FRAGEN,
                "datenfragen": daten, "beispiele": beispiele,
                "kategorien": list(KATEGORIEN), "aus": einst["aus"], "schaltbar": SCHALTBAR}

    def frage_speichern(self, eingabe: dict) -> dict:
        """Verwalter: neue Frage anlegen oder (mit `id`) ändern."""
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        neu = _frage_pruefen(eingabe)
        fid = (eingabe or {}).get("id")
        if fid and "aktiv" not in eingabe:
            neu.pop("aktiv")                        # Bearbeiten schaltet eine abgeschaltete Frage nicht wieder ein
        return self._in_sammlung(lauf, neu, fid)

    def _in_sammlung(self, lauf: dict, neu: dict, fid=None, mehr: dict = None) -> dict:
        roh = _lies(self._fragen_pfad())
        daten = roh if isinstance(roh, dict) and isinstance(roh.get("fragen"), list) else {"version": 1, "fragen": []}
        jetzt = self._zeit()
        f = next((x for x in daten["fragen"] if isinstance(x, dict) and x.get("id") == fid), None) if fid else None
        if fid and not f and not mehr:
            raise TagesfragenFehler("Diese Frage gibt es nicht mehr – vielleicht auf einem anderen Rechner geändert.")
        if f:
            f.update(neu, geaendert_am=jetzt, geaendert_von=lauf["ich"])
        else:
            f = {"id": fid or _neue_id(), **neu, "status": "frei", "angelegt_am": jetzt, "angelegt_von": lauf["ich"],
                 **(mehr or {})}
            daten["fragen"].append(f)
        _schreibe(self._fragen_pfad(), daten)
        return f

    def frage_aktiv(self, fid: str, aktiv) -> dict:
        """Verwalter: eigene Frage ab- oder wieder einschalten (gelöscht wird nie – alte Antworten zeigen auf sie)."""
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        roh = _lies(self._fragen_pfad())
        liste = roh.get("fragen") if isinstance(roh, dict) else None
        f = next((x for x in liste or [] if isinstance(x, dict) and x.get("id") == fid), None)
        if not f:
            raise TagesfragenFehler("Diese Frage gibt es nicht mehr.")
        f["aktiv"] = aktiv.strip().lower() in ("true", "1", "ja") if isinstance(aktiv, str) else bool(aktiv)
        f["geaendert_am"], f["geaendert_von"] = self._zeit(), lauf["ich"]
        _schreibe(self._fragen_pfad(), roh)
        return f

    def _vorschlaege_alle(self, lauf: dict) -> list:
        try:
            namen = sorted(n for n in os.listdir(self._vorschlag_ordner()) if n.endswith(".json"))
        except OSError:
            return []
        liste = []
        for n in namen:
            try:
                v = _lies(os.path.join(self._vorschlag_ordner(), n))
            except TagesfragenFehler:
                continue
            if isinstance(v, dict) and n == f"{v.get('id')}.json" and _eigene_lesbar(v) and v.get("status") in (
                    "vorgeschlagen", "freigegeben", "abgelehnt"):
                v["von_name"] = lauf["personen"].get(v.get("von"), {}).get("name") or "(unbekannt)"
                liste.append(v)
        liste.sort(key=lambda v: str(v.get("am") or ""), reverse=True)
        return liste

    def frage_vorschlagen(self, eingabe: dict) -> dict:
        """Jeder: eine Frage vorschlagen – ein Verwalter gibt sie frei (oder nicht)."""
        lauf = self._lauf()
        neu = _frage_pruefen(eingabe)
        v = {"version": 1, "id": _neue_id(), **neu, "status": "vorgeschlagen", "von": lauf["ich"], "am": self._zeit(),
             "entscheidung": None}
        _schreibe(self._vorschlag_pfad(v["id"]), v)
        return v

    def vorschlaege(self) -> list:
        """Verwalter: alle Vorschläge; alle anderen: die eigenen (mit Status)."""
        lauf = self._lauf()
        alle = self._vorschlaege_alle(lauf)
        if self._verwalter(lauf["personen"], lauf["ich"])[0]:
            return alle
        return [v for v in alle if v.get("von") == lauf["ich"]]

    def vorschlag_entscheiden(self, vid: str, freigeben, eingabe: dict = None, kommentar: str = "") -> dict:
        """
        Verwalter: Vorschlag freigeben (kommt in die Sammlung, auf Wunsch mit geänderter Fassung `eingabe`) oder
        ablehnen (mit Kommentar). Der Vorschlag bleibt mit Status stehen, damit die vorschlagende Person ihn sieht.
        """
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        pfad = self._vorschlag_pfad(vid)
        v = _lies(pfad)
        if not isinstance(v, dict) or not _eigene_lesbar(v):
            raise TagesfragenFehler("Diesen Vorschlag gibt es nicht mehr.")
        if v.get("status") != "vorgeschlagen":
            raise TagesfragenFehler(f"Über diesen Vorschlag ist schon entschieden ({v.get('status')}).")
        if isinstance(freigeben, str):
            freigeben = freigeben.strip().lower() in ("true", "1", "ja", "freigeben")
        kommentar = _langtext(kommentar, 500)
        if freigeben:
            fassung = _frage_pruefen(eingabe) if eingabe else _frage_pruefen(v)
            self._in_sammlung(lauf, fassung, v["id"], {"vorgeschlagen_von": v.get("von"), "vorgeschlagen_am": v.get("am")})
        v["status"] = "freigegeben" if freigeben else "abgelehnt"
        v["entscheidung"] = {"von": lauf["ich"], "am": self._zeit(), "kommentar": kommentar}
        _schreibe(pfad, v)
        return v

    # ---------------- Arbeitstage ----------------
    def _abwesend(self, lauf: dict, pid: str, jahr: int) -> set:
        """Genehmigte ganze Urlaubstage (auch Betriebsurlaub) einer Person in einem Jahr."""
        if jahr not in lauf["abwesend"]:
            je_person = {}
            try:
                for z in self._urlaub().abwesenheiten(jahr, mit_feiertagen=False):
                    if not z.get("halber_tag"):
                        je_person.setdefault(z.get("person"), set()).add(z.get("datum"))
            except (UrlaubFehler, ProjektFehler) as e:
                lauf["hinweise"].append(f"Urlaub gerade nicht lesbar – Urlaubstage zählen vorübergehend als "
                                        f"Arbeitstage ({e}).")
            lauf["abwesend"][jahr] = je_person
        return lauf["abwesend"][jahr].get(pid, set())

    def _tagesart(self, lauf: dict, pid: str, d: dt.date):
        """None für einen Arbeitstag der Person, sonst „frei“ (Wochenende), „feiertag“ oder „urlaub“."""
        if d.weekday() >= 5:
            return "frei"
        if feiertag_namen(d.year).get(d.isoformat()):
            return "feiertag"
        if d.isoformat() in self._abwesend(lauf, pid, d.year):
            return "urlaub"
        return None

    def _arbeitstage_seit(self, lauf: dict, pid: str, von: str, bis: str) -> int:
        """Eigene Arbeitstage nach `von` bis einschließlich `bis`."""
        n, d, ende = 0, _datum(von) + dt.timedelta(days=1), _datum(bis)
        while d <= ende and n < WIEDERHOLEN_NACH:      # mehr als die Schwelle muss niemand wissen
            n += self._tagesart(lauf, pid, d) is None
            d += dt.timedelta(days=1)
        return n

    def _beginn(self, lauf: dict):
        """Erster Tag, an dem im Team jemand geantwortet hat (date) – vorher zählt kein Arbeitstag."""
        if "beginn" not in lauf:
            lauf["beginn"] = None
            try:
                namen = os.listdir(self._antwort_ordner())
            except OSError:
                namen = []
            je_monat = {}
            for n in namen:
                m = re.fullmatch(r"([0-9a-f]{6,32})-(\d{4}-\d{2})\.json", n)
                if m and MONAT_MUSTER.fullmatch(m.group(2)):
                    je_monat.setdefault(m.group(2), []).append(m.group(1))
            for monat in sorted(je_monat):
                tage = []
                for pid in je_monat[monat]:
                    try:
                        daten = self._datei(pid, monat)
                    except TagesfragenFehler:
                        continue
                    tage += [t for t, e in daten["tage"].items() if e["antworten"]]
                if tage:
                    lauf["beginn"] = _datum(min(tage))
                    break
        return lauf["beginn"]

    def _start(self, lauf: dict, pid: str) -> dt.date:
        """Ab wann die Arbeitstage einer Person zählen: Teambeginn, frühestens ab dem Anlegen der Person."""
        start = self._beginn(lauf) or lauf["heute"]
        angelegt = str(lauf["personen"].get(pid, {}).get("angelegt_am") or "")[:10]
        if ISO_DATUM.fullmatch(angelegt):
            start = max(start, _datum(angelegt))
        return start

    # ---------------- Antwortdateien ----------------
    @staticmethod
    def _leere_datei(pid: str, monat: str) -> dict:
        return {"version": 1, "person": pid, "monat": monat, "tage": {}, "laengste_serie": 0}

    def _datei(self, pid: str, monat: str) -> dict:
        """Antwortdatei frisch gelesen und in fester Form; Unlesbares in einzelnen Tagen fällt still weg."""
        roh = _lies(self._antwort_pfad(pid, monat))
        daten = self._leere_datei(pid, monat)
        if not isinstance(roh, dict):
            return daten
        tage = roh.get("tage")
        for tag, e in (tage if isinstance(tage, dict) else {}).items():
            if not (ISO_DATUM.fullmatch(str(tag)) and str(tag).startswith(monat) and isinstance(e, dict)):
                continue
            fragen = [f for f in (e.get("fragen") if isinstance(e.get("fragen"), list) else []) if _schnappschuss_lesbar(f)]
            ids = {f["id"] for f in fragen}
            antworten = {k: v for k, v in (e.get("antworten") if isinstance(e.get("antworten"), dict) else {}).items()
                         if k in ids and isinstance(v, dict) and isinstance(v.get("wahl"), int)}
            daten["tage"][tag] = {**e, "fragen": fragen, "antworten": antworten}
        if isinstance(roh.get("laengste_serie"), int):
            daten["laengste_serie"] = roh["laengste_serie"]
        return daten

    def _dateien(self, lauf: dict, pid: str) -> dict:
        """Alle Antwortdateien einer Person: Monat → Inhalt (je Aufruf einmal gelesen)."""
        if pid not in lauf["dateien"]:
            monate = []
            try:
                for n in os.listdir(self._antwort_ordner()):
                    m = re.fullmatch(re.escape(pid) + r"-(\d{4}-\d{2})\.json", n)
                    if m and MONAT_MUSTER.fullmatch(m.group(1)):
                        monate.append(m.group(1))
            except OSError:
                pass
            dateien = {}
            for monat in sorted(monate):
                try:
                    dateien[monat] = self._datei(pid, monat)
                except TagesfragenFehler as e:
                    lauf["hinweise"].append(str(e))
            lauf["dateien"][pid] = dateien
        return lauf["dateien"][pid]

    def _merke_datei(self, lauf: dict, pid: str, daten: dict):
        """Geänderte Datei auch im Zwischenstand des Aufrufs, damit Auswertungen sie schon sehen."""
        self._dateien(lauf, pid)[daten["monat"]] = daten
        lauf["auswertung"].pop(pid, None)

    @staticmethod
    def _erledigt(eintrag) -> bool:
        return bool(eintrag and eintrag["fragen"]) and all(f["id"] in eintrag["antworten"] for f in eintrag["fragen"])

    # ---------------- Auswahl des Tages ----------------
    def _verlauf(self, lauf: dict, pid: str, vor: str) -> dict:
        """Frage-ID → {tag, richtig, faellig} der letzten Antwort vor `vor`; fällig = falsch und lange genug her."""
        letzte = {}
        for daten in self._dateien(lauf, pid).values():
            for tag, e in daten["tage"].items():
                if tag >= vor:
                    continue
                for fid, a in e["antworten"].items():
                    if fid not in letzte or letzte[fid]["tag"] < tag:
                        letzte[fid] = {"tag": tag, "richtig": bool(a.get("richtig"))}
        for z in letzte.values():
            z["faellig"] = not z["richtig"] and self._arbeitstage_seit(lauf, pid, z["tag"], vor) >= WIEDERHOLEN_NACH
        return letzte

    @staticmethod
    def _auswahl(pid: str, tag: str, pool: list, verlauf: dict, anzahl: int = FRAGEN_JE_TAG) -> list:
        """
        Die Fragen für Person und Tag. Vorn stehen fällige Wiederholungen (falsch beantwortet, seitdem mindestens drei
        eigene Arbeitstage), dann Fragen, die die Person noch nie hatte, dann die am längsten nicht gestellten; falsch
        Beantwortetes, das noch nicht fällig ist, ganz hinten. Gleichrangige mischt ein Hash aus Person, Tag und Frage.
        Je Runde höchstens eine Frage je Quelle, damit sich Daten, eigene und ODIN-Fragen abwechseln.
        """
        def rang(f):
            h = _hash(pid, tag, f["id"])
            z = verlauf.get(f["id"])
            if z is None:
                return (1, "", h)
            if not z["richtig"]:
                return (0 if z["faellig"] else 3, z["tag"], h)
            return (2, z["tag"], h)
        sortiert = sorted(pool, key=rang)
        gewaehlt, je_gruppe, ids = [], {}, set()
        for runde in range(1, anzahl + 1):
            for f in sortiert:
                if len(gewaehlt) == anzahl:
                    return gewaehlt
                if f["id"] in ids or je_gruppe.get(f["gruppe"], 0) >= runde:
                    continue
                gewaehlt.append(f)
                ids.add(f["id"])
                je_gruppe[f["gruppe"]] = je_gruppe.get(f["gruppe"], 0) + 1
        return gewaehlt

    @staticmethod
    def _schnappschuss(f: dict, pid: str, tag: str) -> dict:
        """Die Frage so, wie die Person sie an diesem Tag sieht – Antworten in fester, gemischter Reihenfolge."""
        reihenfolge = sorted(range(len(f["antworten"])), key=lambda i: _hash(pid, tag, f["id"], i))
        return {"id": f["id"], "frage": f["frage"], "antworten": [f["antworten"][i] for i in reihenfolge],
                "richtig": reihenfolge.index(f["richtig"]), "erklaerung": f.get("erklaerung") or "",
                "kategorie": f.get("kategorie") or "ODIN", "quelle": f.get("quelle") or "",
                "herkunft": f.get("herkunft") or "", **({"modul": f["modul"]} if f.get("modul") else {}),
                **({"regel": f["regel"]} if f.get("regel") else {})}

    def tagesauswahl(self, pid: str, tag: str) -> list:
        """Die Fragen, die `pid` am Tag `tag` bekäme (ohne festzuhalten) – für Tests und zum Nachvollziehen."""
        lauf = self._lauf(ich_pflicht=False)
        pool = self._pool(lauf)
        anzahl = self._einstellungen()["fragen_je_tag"]
        return [self._schnappschuss(f, pid, tag)
                for f in self._auswahl(pid, tag, pool, self._verlauf(lauf, pid, tag), anzahl)]

    def _tag_eintrag(self, lauf: dict, pid: str, tag: str) -> tuple:
        """(Eintrag des Tages, Antwortdatei) – beim ersten Abruf werden die Fragen ausgewählt und festgehalten."""
        monat = tag[:7]
        daten = self._datei(pid, monat)
        eintrag = daten["tage"].get(tag)
        if not eintrag or not eintrag["fragen"]:
            anzahl = self._einstellungen()["fragen_je_tag"]
            fragen = [self._schnappschuss(f, pid, tag)
                      for f in self._auswahl(pid, tag, self._pool(lauf), self._verlauf(lauf, pid, tag), anzahl)]
            eintrag = {"fragen": fragen, "antworten": {}, "festgehalten_am": self._zeit()}
            if fragen:
                daten["tage"][tag] = eintrag
                _schreibe(self._antwort_pfad(pid, monat), daten)
                self._merke_datei(lauf, pid, daten)
        return eintrag, daten

    @staticmethod
    def _ansicht(tag: str, eintrag: dict) -> dict:
        """Tag für die Oberfläche: die richtige Antwort und die Erklärung erst nach dem Antworten."""
        fragen = []
        for f in eintrag["fragen"]:
            x = {"id": f["id"], "frage": f["frage"], "antworten": f["antworten"], "kategorie": f["kategorie"],
                 "quelle": f.get("quelle", ""), "herkunft": f.get("herkunft", "")}
            a = eintrag["antworten"].get(f["id"])
            if a:
                x.update(gewaehlt=a["wahl"], richtig=f["richtig"], korrekt=bool(a.get("richtig")),
                         gelernt=bool(a.get("gelernt")), erklaerung=f.get("erklaerung", ""), modul=_modul(f),
                         regel=_regel(f))
            fragen.append(x)
        beantwortet = sum(1 for f in fragen if "gewaehlt" in f)
        fertig = bool(fragen) and beantwortet == len(fragen)
        return {"datum": tag, "arbeitstag": True, "grund": "", "fragen": fragen, "anzahl": len(fragen),
                "beantwortet": beantwortet, "offen": len(fragen) - beantwortet,
                "richtig": sum(1 for f in fragen if f.get("korrekt")), "fertig": fertig,
                "uebersprungen": bool(eintrag.get("uebersprungen")) and not fertig}

    def _kein_arbeitstag(self, lauf: dict, pid: str, d: dt.date):
        art = self._tagesart(lauf, pid, d)
        if not art:
            return None
        grund = {"frei": "Wochenende", "urlaub": "Urlaub",
                 "feiertag": feiertag_namen(d.year).get(d.isoformat(), "Feiertag")}[art]
        return {"datum": d.isoformat(), "arbeitstag": False, "grund": grund, "art": art, "fragen": [], "anzahl": 0,
                "beantwortet": 0, "offen": 0, "richtig": 0, "fertig": False, "uebersprungen": False}

    @_gesperrt
    def heute(self) -> dict:
        """Die Fragen von heute (beim ersten Abruf festgehalten); an freien Tagen keine."""
        return self._heute_ansicht(self._lauf())

    def _heute_ansicht(self, lauf: dict) -> dict:
        ich, d = lauf["ich"], lauf["heute"]
        frei = self._kein_arbeitstag(lauf, ich, d)
        if frei:
            return frei
        eintrag, _ = self._tag_eintrag(lauf, ich, d.isoformat())
        return self._ansicht(d.isoformat(), eintrag)

    def offen(self) -> int:
        """Für die Seitenleiste: Zahl der heute noch offenen Fragen (ohne etwas festzuhalten); übersprungen = 0."""
        lauf = self._lauf(ich_pflicht=False)
        ich, d = lauf["ich"], lauf["heute"]
        if not ich or self._tagesart(lauf, ich, d):
            return 0
        eintrag = self._datei(ich, d.isoformat()[:7])["tage"].get(d.isoformat())
        if eintrag and eintrag["fragen"]:
            if eintrag.get("uebersprungen"):
                return 0
            return sum(1 for f in eintrag["fragen"] if f["id"] not in eintrag["antworten"])
        einst = self._einstellungen()
        schnell = (0 if "odin" in einst["aus"] else len(ODIN_FRAGEN)) + (0 if "beirat" in einst["aus"] else len(BEIRAT_FRAGEN)) \
            + len(HAUSREGEL_FRAGEN) + sum(1 for f in self._eigene() if f["aktiv"])
        anzahl = einst["fragen_je_tag"]
        return anzahl if schnell >= anzahl else min(anzahl, len(self._pool(lauf)))

    # ---------------- Antworten und Überspringen ----------------
    def _heute_pflicht(self, lauf: dict) -> tuple:
        ich, d = lauf["ich"], lauf["heute"]
        frei = self._kein_arbeitstag(lauf, ich, d)
        if frei:
            raise TagesfragenFehler(f"Heute ist für dich kein Arbeitstag ({frei['grund']}) – keine Fragen.")
        return ich, d.isoformat()

    @_gesperrt
    def antworten(self, frage_id: str, wahl) -> dict:
        """Eine Frage von heute beantworten – jede nur einmal. Gibt Auflösung, Erklärung und neuen Stand zurück."""
        lauf = self._lauf()
        ich, tag = self._heute_pflicht(lauf)
        eintrag, daten = self._tag_eintrag(lauf, ich, tag)
        f = next((x for x in eintrag["fragen"] if x["id"] == frage_id), None)
        if not f:
            raise TagesfragenFehler("Diese Frage gehört nicht zu deinen heutigen Fragen – bitte neu laden.")
        if frage_id in eintrag["antworten"]:
            raise TagesfragenFehler("Diese Frage hast du schon beantwortet.")
        try:
            wahl = int(wahl)
        except (TypeError, ValueError):
            raise TagesfragenFehler("Bitte eine Antwort wählen.") from None
        if not 0 <= wahl < len(f["antworten"]):
            raise TagesfragenFehler("Bitte eine Antwort wählen.")
        richtig = wahl == f["richtig"]
        vorher = self._verlauf(lauf, ich, tag).get(frage_id)
        gelernt = richtig and vorher is not None and not vorher["richtig"]
        eintrag["antworten"][frage_id] = {"wahl": wahl, "richtig": richtig, "am": self._zeit(),
                                          **({"gelernt": True} if gelernt else {})}
        eintrag.pop("uebersprungen", None)               # wer antwortet, ist wieder dabei
        daten["tage"][tag] = eintrag
        self._merke_datei(lauf, ich, daten)
        ausw = self._auswertung(lauf, ich)
        daten["laengste_serie"] = max(daten.get("laengste_serie", 0), ausw["laengste"])
        _schreibe(self._antwort_pfad(ich, tag[:7]), daten)
        return {"richtig": richtig, "gelernt": gelernt, "richtige_antwort": f["richtig"],
                "erklaerung": f.get("erklaerung", ""), "quelle": f.get("quelle", ""), "modul": _modul(f),
                "regel": _regel(f),
                "heute": self._ansicht(tag, eintrag), "stand": self._stand(lauf, ich, tag[:7], ausw)}

    @_gesperrt
    def ueberspringen(self, zurueck=False) -> dict:
        """
        Heute überspringen – ein Klick, zählt als nicht beantwortet (Lose gibt es dann nur für schon Beantwortetes;
        die Serie hält, solange es nicht der zweite ausgelassene Arbeitstag in Folge ist). `zurueck` hebt es auf.
        """
        lauf = self._lauf()
        ich, tag = self._heute_pflicht(lauf)
        eintrag, daten = self._tag_eintrag(lauf, ich, tag)
        if self._erledigt(eintrag):
            raise TagesfragenFehler("Heute ist schon alles beantwortet.")
        if isinstance(zurueck, str):
            zurueck = zurueck.strip().lower() in ("true", "1", "ja")
        if zurueck:
            eintrag.pop("uebersprungen", None)
        else:
            eintrag["uebersprungen"] = self._zeit()
        daten["tage"][tag] = eintrag
        _schreibe(self._antwort_pfad(ich, tag[:7]), daten)
        self._merke_datei(lauf, ich, daten)
        return {"heute": self._ansicht(tag, eintrag), "stand": self._stand(lauf, ich, tag[:7])}

    # ---------------- Serie, Lose, Teilnahme ----------------
    def _auswertung(self, lauf: dict, pid: str) -> dict:
        """
        Je Tag ab dem Start der Person die Art (erledigt, teilweise, verpasst, übersprungen, offen, frei …), dazu die
        aktuelle und die längste Serie. Regel: ein ausgelassener Arbeitstag schadet nicht, zwei in Folge beenden die
        Serie; Urlaub, Feiertage und Wochenenden pausieren sie, heute noch offen bricht nichts.
        """
        if pid in lauf["auswertung"]:
            return lauf["auswertung"][pid]
        heute = lauf["heute"]
        start = self._start(lauf, pid)
        dateien = self._dateien(lauf, pid)
        tage = {}
        for daten in dateien.values():
            tage.update(daten["tage"])
        gemerkt = max([d.get("laengste_serie", 0) for d in dateien.values()] + [0])
        serie = laengste = 0
        luecke = False                 # der letzte Arbeitstag wurde ausgelassen – noch einer beendet die Serie
        art = {}
        d = start
        while d <= heute:
            iso = d.isoformat()
            e = tage.get(iso)
            frei = self._tagesart(lauf, pid, d)
            if frei:
                art[iso] = frei
            elif self._erledigt(e):
                art[iso] = "erledigt"
                serie += 1
                luecke = False
            elif d == heute and not (e and e.get("uebersprungen")):
                art[iso] = "offen"
            else:
                art[iso] = "uebersprungen" if e and e.get("uebersprungen") else \
                    "teilweise" if e and e["antworten"] else "verpasst"
                if luecke:
                    serie = 0
                luecke = True
            laengste = max(laengste, serie)
            d += dt.timedelta(days=1)
        ergebnis = {"start": start, "tage": tage, "art": art, "serie": serie, "laengste": max(laengste, gemerkt),
                    "luecke": luecke and serie > 0}
        lauf["auswertung"][pid] = ergebnis
        return ergebnis

    def _art(self, lauf: dict, pid: str, ausw: dict, d: dt.date) -> str:
        iso = d.isoformat()
        if iso in ausw["art"]:
            return ausw["art"][iso]
        frei = self._tagesart(lauf, pid, d)
        if frei:
            return frei
        return "vor_beginn" if d < ausw["start"] else "zukunft"

    def _monat(self, lauf: dict, pid: str, monat: str, ausw: dict) -> dict:
        """Lose, volle Wochen und Teilnahme einer Person in einem Monat, dazu der Kalender mit einem Punkt je Tag."""
        heute = lauf["heute"]
        kalender, arbeitstage, erledigt, offen_moeglich = [], 0, 0, 0
        richtig = beantwortet = gelernt = 0
        for d in _monatstage(monat):
            iso = d.isoformat()
            art = self._art(lauf, pid, ausw, d)
            e = ausw["tage"].get(iso)
            antworten = list(e["antworten"].values()) if e else []
            n_richtig = sum(1 for a in antworten if a.get("richtig"))
            richtig += n_richtig
            beantwortet += len(antworten)
            gelernt += sum(1 for a in antworten if a.get("gelernt") and a.get("richtig"))
            if art not in FREIE_ARTEN:
                arbeitstage += 1
                erledigt += art == "erledigt"
                offen_moeglich += art in ("offen", "zukunft")
            kalender.append({"datum": iso, "art": art, "fragen": len(e["fragen"]) if e else 0,
                             "beantwortet": len(antworten), "richtig": n_richtig,
                             "feiertag": feiertag_namen(d.year).get(iso) or ""})
        # Volle Wochen: alle eigenen Arbeitstage Mo–Fr erledigt; die Woche zählt zum Monat ihres Donnerstags
        wochen = []
        for d in _monatstage(monat):
            if d.weekday() != 3:
                continue
            montag = d - dt.timedelta(days=3)
            arten = [self._art(lauf, pid, ausw, montag + dt.timedelta(days=i)) for i in range(5)]
            zaehlen = [a for a in arten if a not in FREIE_ARTEN]
            if zaehlen and all(a == "erledigt" for a in zaehlen):
                wochen.append(montag.isoformat())
        noetig = math.ceil(TEILNAHME_AB * arbeitstage - 1e-9)
        lose = {"tage": erledigt * LOSE_JE_TAG, "richtig": richtig * LOSE_JE_RICHTIG,
                "gelernt": gelernt * LOSE_JE_GELERNT, "wochen": len(wochen) * LOSE_JE_WOCHE}
        return {"monat": monat, "kalender": kalender, "arbeitstage": arbeitstage, "erledigt": erledigt,
                "noetig": noetig, "richtig": richtig, "beantwortet": beantwortet, "gelernt": gelernt,
                "volle_wochen": len(wochen), "wochen": wochen, "lose": sum(lose.values()), "lose_aus": lose,
                "dabei": bool(arbeitstage) and erledigt >= noetig,
                "noch_moeglich": bool(arbeitstage) and erledigt + offen_moeglich >= noetig,
                "abgeschlossen": monat < heute.isoformat()[:7],
                "bisher": sum(1 for x in kalender if x["art"] in ("erledigt",) + VERPASST_ARTEN)}

    def _stand(self, lauf: dict, pid: str, monat: str, ausw: dict = None) -> dict:
        ausw = ausw or self._auswertung(lauf, pid)
        m = self._monat(lauf, pid, monat, ausw)
        return {**m, "serie": ausw["serie"], "laengste": ausw["laengste"], "luecke": ausw["luecke"],
                "start": ausw["start"].isoformat(), "preis": self._einstellungen()["preise"].get(monat, ""),
                "hinweise": list(dict.fromkeys(lauf["hinweise"]))}

    def stand(self, monat: str = None) -> dict:
        """Meine Werte: Serie, längste Serie, Lose und Teilnahme im Monat, Kalender mit einem Punkt je Tag."""
        lauf = self._lauf()
        monat = str(monat or lauf["heute"].isoformat()[:7])
        if not MONAT_MUSTER.fullmatch(monat):
            raise TagesfragenFehler("Bitte einen Monat wählen.")
        return self._stand(lauf, lauf["ich"], monat)

    def _aktive(self, lauf: dict) -> list:
        return [p for p in lauf["personen"].values() if p.get("aktiv", True)]

    def team(self) -> dict:
        """Teamwerte im laufenden Monat: Teamziel und Fortschritt, Teilnahme, Ø richtig – Rangliste nur, wenn an."""
        lauf = self._lauf()
        return self._team(lauf, self._einstellungen())

    def _team(self, lauf: dict, einst: dict) -> dict:
        monat = lauf["heute"].isoformat()[:7]
        heute = lauf["heute"].isoformat()
        tage_gesamt = tage_erledigt = richtig = beantwortet = heute_fertig = heute_dran = gelernt = 0
        zeilen = []
        for p in self._aktive(lauf):
            ausw = self._auswertung(lauf, p["id"])
            m = self._monat(lauf, p["id"], monat, ausw)
            tage_gesamt += m["bisher"]
            tage_erledigt += m["erledigt"]
            richtig += m["richtig"]
            beantwortet += m["beantwortet"]
            gelernt += m["gelernt"]
            heute_art = ausw["art"].get(heute)
            heute_dran += heute_art in ("erledigt", "offen", "uebersprungen")
            heute_fertig += heute_art == "erledigt"
            zeilen.append({"person": p["id"], "name": p.get("name", ""), "kuerzel": p.get("kuerzel", ""),
                           "farbe": p.get("farbe"), "lose": m["lose"], "serie": ausw["serie"],
                           "erledigt": m["erledigt"], "ich": p["id"] == lauf["ich"]})
        rangliste = None
        if einst["rangliste"]:
            rangliste = sorted((z for z in zeilen if z["lose"] or z["serie"]),
                               key=lambda z: (-z["lose"], -z["serie"], _norm(z["name"])))
        ziel = einst["teamziele"].get(monat)
        return {"monat": monat, "personen": len(zeilen),
                "teamziel": ziel, "teamziel_stand": richtig,
                "teamziel_anteil": round(min(1, richtig / ziel), 3) if ziel else None,
                "teilnahme_quote": round(tage_erledigt / tage_gesamt, 3) if tage_gesamt else None,
                "richtig_quote": round(richtig / beantwortet, 3) if beantwortet else None,
                "richtig": richtig, "beantwortet": beantwortet, "gelernt": gelernt,
                "heute_fertig": heute_fertig, "heute_dran": heute_dran,
                "rangliste_an": einst["rangliste"], "rangliste": rangliste}

    # ---------------- Verlosung ----------------
    def _teilnehmer(self, lauf: dict, monat: str) -> tuple:
        """(Teilnehmer mit Losen und Losnummern, Zahl der Nicht-Teilnehmer) eines Monats."""
        teilnehmer, nicht = [], 0
        for p in sorted(self._aktive(lauf), key=lambda p: (_norm(p.get("name")), p["id"])):
            m = self._monat(lauf, p["id"], monat, self._auswertung(lauf, p["id"]))
            if m["dabei"] and m["lose"] > 0:
                teilnehmer.append({"person": p["id"], "name": p.get("name", ""), "lose": m["lose"],
                                   "erledigt": m["erledigt"], "arbeitstage": m["arbeitstage"]})
            elif m["arbeitstage"]:
                nicht += 1
        los = 0
        for t in teilnehmer:
            t["los_von"], t["los_bis"] = los + 1, los + t["lose"]
            los += t["lose"]
        return teilnehmer, nicht

    def _verlosung_lesen(self, monat: str):
        roh = _lies(self._verlosung_pfad(monat))
        if not isinstance(roh, dict) or not isinstance(roh.get("ziehungen"), list) or not roh["ziehungen"]:
            return None
        return roh

    def verlosung(self, monat: str) -> dict:
        """Verwalter: Teilnehmer und Lose eines Monats und die bisherigen Ziehungen."""
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        if not MONAT_MUSTER.fullmatch(str(monat or "")):
            raise TagesfragenFehler("Bitte einen Monat wählen.")
        teilnehmer, nicht = self._teilnehmer(lauf, monat)
        gespeichert = self._verlosung_lesen(monat)
        return {"monat": monat, "abgeschlossen": monat < lauf["heute"].isoformat()[:7], "teilnehmer": teilnehmer,
                "nicht_dabei": nicht, "lose_gesamt": sum(t["lose"] for t in teilnehmer),
                "preis": self._einstellungen()["preise"].get(monat, ""),
                "ziehungen": gespeichert["ziehungen"] if gespeichert else []}

    def verlosen(self, monat: str, begruendung: str = "") -> dict:
        """
        Verwalter: einen abgeschlossenen Monat auslosen – gewichtet nach Losen, mit dem Zufall des Betriebssystems.
        Das Ergebnis bleibt gespeichert; wer erneut auslost, muss es begründen, und die neue Ziehung kommt dazu.
        """
        lauf = self._lauf()
        self._verwalter_pflicht(lauf)
        if not MONAT_MUSTER.fullmatch(str(monat or "")):
            raise TagesfragenFehler("Bitte einen Monat wählen.")
        if monat >= lauf["heute"].isoformat()[:7]:
            raise TagesfragenFehler("Ausgelost wird erst, wenn der Monat vorbei ist.")
        begruendung = _langtext(begruendung, 500)
        pfad = self._verlosung_pfad(monat)
        bisher = self._verlosung_lesen(monat)
        if bisher is None and os.path.exists(pfad):
            raise TagesfragenFehler("Die Verlosung dieses Monats ist gerade nicht lesbar – bitte später nochmal.")
        if bisher and len(begruendung) < 5:
            letzte = bisher["ziehungen"][-1]
            raise TagesfragenFehler(f"Für {monat} wurde schon ausgelost ({str(letzte.get('am', ''))[:16].replace('T', ' ')}, "
                                    f"gewonnen hat {letzte.get('gewinner_name', '?')}). Erneut auslosen nur mit "
                                    "Begründung.")
        teilnehmer, nicht = self._teilnehmer(lauf, monat)
        if not teilnehmer:
            raise TagesfragenFehler(f"Im {monat} war niemand an mindestens {round(TEILNAHME_AB * 100)} % seiner "
                                    "Arbeitstage dabei – es gibt nichts zu verlosen.")
        gesamt = sum(t["lose"] for t in teilnehmer)
        gezogen = self._zufall.randint(1, gesamt)
        gewinner = next(t for t in teilnehmer if t["los_von"] <= gezogen <= t["los_bis"])
        ziehung = {"am": self._zeit(), "von": lauf["ich"], "von_name": lauf["personen"][lauf["ich"]].get("name", ""),
                   "preis": self._einstellungen()["preise"].get(monat, ""), "begruendung": begruendung if bisher else "",
                   "regel": f"{LOSE_JE_TAG} Los je erledigtem Tag, {LOSE_JE_RICHTIG} je richtige Antwort, "
                            f"{LOSE_JE_GELERNT} je gelernter Frage, {LOSE_JE_WOCHE} je volle Woche; dabei ab "
                            f"{round(TEILNAHME_AB * 100)} % der Arbeitstage",
                   "teilnehmer": teilnehmer, "nicht_dabei": nicht, "lose_gesamt": gesamt, "gezogenes_los": gezogen,
                   "gewinner": gewinner["person"], "gewinner_name": gewinner["name"]}
        daten = bisher or {"version": 1, "monat": monat, "ziehungen": []}
        daten["ziehungen"].append(ziehung)
        _schreibe(pfad, daten)
        return {"monat": monat, "ziehung": ziehung, "ziehungen": daten["ziehungen"]}

    def _letzte_verlosung(self):
        """Das jüngste Ergebnis für alle: Monat, Gewinner, Preis."""
        try:
            namen = sorted((n[:7] for n in os.listdir(self._verlosung_ordner())
                            if re.fullmatch(r"\d{4}-\d{2}\.json", n) and MONAT_MUSTER.fullmatch(n[:7])), reverse=True)
        except OSError:
            return None
        for monat in namen:
            try:
                v = self._verlosung_lesen(monat)
            except TagesfragenFehler:
                continue
            if v:
                z = v["ziehungen"][-1]
                return {"monat": monat, "gewinner_name": z.get("gewinner_name", ""), "preis": z.get("preis", ""),
                        "am": z.get("am"), "ziehungen": len(v["ziehungen"])}
        return None

    # ---------------- Einstieg ----------------
    @_gesperrt
    def start(self) -> dict:
        """Alles für die Oberfläche: wer ich bin, Rechte, die Fragen von heute, meine Werte, Teamwerte, Preis."""
        basis, lokal = self._projekte._basis()
        lauf = self._lauf(ich_pflicht=False)
        personen, ich = lauf["personen"], lauf["ich"]
        speicher = {"lokal": lokal, "ordner": os.path.join(basis, "Tagesfragen")}
        if not ich:
            return {"ich": "", "personen": list(personen.values()), "ist_verwalter": False, "speicher": speicher}
        verwalter, fehlt = self._verwalter(personen, ich)
        einst = self._einstellungen()
        heute = self._heute_ansicht(lauf)
        meine = [v for v in self._vorschlaege_alle(lauf) if v.get("von") == ich]
        return {"ich": ich, "personen": list(personen.values()), "ist_verwalter": verwalter, "verwalter_fehlt": fehlt,
                "heute": heute, "stand": self._stand(lauf, ich, lauf["heute"].isoformat()[:7]),
                "team": self._team(lauf, einst), "einstellungen": self._oeffentliche_einstellungen(einst, lauf, verwalter),
                "letzte_verlosung": self._letzte_verlosung(), "kategorien": list(KATEGORIEN),
                "meine_vorschlaege": meine,
                "offene_vorschlaege": sum(1 for v in self._vorschlaege_alle(lauf) if v["status"] == "vorgeschlagen")
                if verwalter else 0,
                "regeln": {"lose_je_tag": LOSE_JE_TAG, "lose_je_richtig": LOSE_JE_RICHTIG,
                           "lose_je_gelernt": LOSE_JE_GELERNT, "lose_je_woche": LOSE_JE_WOCHE,
                           "teilnahme_ab": TEILNAHME_AB, "wiederholen_nach": WIEDERHOLEN_NACH},
                "speicher": speicher}
