"""
Fachinhalte der Rechtsfälle: Falltypen, Checklisten „Was jetzt zu tun ist“, Rechenhilfen für Fristen und
Textbausteine für Entwürfe.

Alles ist aus den Skills des Plugins „muster-recht“ abgeleitet (Einstieg: muster-recht-einstieg) – jede Zeile nennt
ihre Quelle. Was die Skills nicht hergeben, steht hier nicht. Für Vergleich und Verhandlung kommen wenige
Gestaltungshinweise aus dem Beirat (Übertragungen auf den Caravanhandel, keine Zitate).

Das ist keine Rechtsberatung: Checklisten und Entwürfe sind Arbeitshilfen. Gesetzesstand und Fristen im Einzelfall
prüfen, im Zweifel einen Anwalt einbinden oder den Fall mit dem Dossier in Claude (Skill muster-recht-einstieg)
weiterbearbeiten.
"""

HINWEIS_RECHT = ("Keine Rechtsberatung – Arbeitshilfe aus den muster-recht-Skills. Im Zweifel Anwalt einbinden "
                 "oder den Fall mit dem Dossier in Claude mit muster-recht-einstieg prüfen.")

# ---------------------------------------------------------------- Falltypen → passende Skills
# Reihenfolge der Skills: erster Fachskill zuerst, dann ergänzende (Routing-Tabelle in muster-recht-einstieg).
FALLTYPEN = {
    "reklamation": {
        "name": "Kundenreklamation Fahrzeug / Gewährleistung", "kurz": "Reklamation",
        "beschreibung": "Kunde meldet einen Mangel am gekauften Fahrzeug, will Nachbesserung, Rücktritt oder Minderung.",
        "skills": ["kfz-handel-paragraf-434-bgb", "kaufrecht-sachmangel-paragraph-434",
                   "kaufrecht-nacherfuellung-ruecktritt-minderung", "gewaehrleistung-und-garantie-trennen"]},
    "werkstatt": {
        "name": "Werkstatt-Mangel / Werkvertrag", "kurz": "Werkstatt",
        "beschreibung": "Reparatur mangelhaft, Rechnung bestritten oder von einer Versicherung gekürzt.",
        "skills": ["werkvertrag-maengelrechte", "werkstattrechnung-kuerzung-zahlungswege"]},
    "forderung": {
        "name": "Offene Forderung / Inkasso", "kurz": "Forderung",
        "beschreibung": "Rechnung offen, Mahnung, Mahnbescheid – oder eine Forderung gegen uns.",
        "skills": ["mahnung-aussergerichtlich-stufenmodell", "forderung-gegen-verbraucher", "inkasso-risikoampel",
                   "mahnbescheid-online"]},
    "abmahnung": {
        "name": "Abmahnung (UWG / Urheber)", "kurz": "Abmahnung",
        "beschreibung": "Abmahnung wegen Werbung, Preisangaben, Fotos, Musik oder Texten.",
        "skills": ["abmahnung-uwg", "abmahnung-97a-response", "workflow-red-team-gegenseite"]},
    "arbeitsrecht": {
        "name": "Arbeitsrecht", "kurz": "Arbeitsrecht",
        "beschreibung": "Abmahnung oder Kündigung eines Mitarbeiters, Kündigungsschutzklage, Aufhebungsvertrag.",
        "skills": ["personalmassnahme-pruefen-und-dokumentieren", "abmahnung-arbeitsrecht", "kuendigungs-pruefung",
                   "kuendigung-zugang-beweiswerkstatt"]},
    "datenschutz": {
        "name": "Datenschutz", "kurz": "Datenschutz",
        "beschreibung": "Auskunftsersuchen nach Art. 15 DSGVO oder Datenpanne (falsche Mail, Hack, verlorenes Gerät).",
        "skills": ["datenschutz-auskunftsersuchen-art-15-praxis", "datenschutz-datenpanne-art-33-34-72h-incident"]},
    "schaden": {
        "name": "Schadenfall / Versicherung", "kurz": "Schadenfall",
        "beschreibung": "Schaden auf dem Hof oder in der Werkstatt, Haftpflicht, Versicherung einschalten.",
        "skills": ["schadenfall-aufnehmen", "versicherung-einschalten", "haftungsweg-bestimmen"]},
    "lieferant": {
        "name": "Lieferant / Hersteller", "kurz": "Lieferant",
        "beschreibung": "Mangel an Hersteller oder Lieferant weitergeben, Mängelrüge, Streit um Lieferungen.",
        "skills": ["maengelruege-paragraph-377-hgb", "lieferforderung-und-maengeleinwand-bearbeiten"]},
    "finanzierung": {
        "name": "Finanzierung / Leasing", "kurz": "Finanzierung",
        "beschreibung": "Finanzierung über eine Bank, Widerruf, Leasingrückläufer, Restwert.",
        "skills": ["darlehen-und-finanzierung", "fahrzeugleasing-kilometervertrag-restwertvertrag-rueck",
                   "verbraucherleasing-widerruf-und-pflichtangaben"]},
    "sonstiges": {
        "name": "Sonstiges", "kurz": "Sonstiges",
        "beschreibung": "Passt in keine Gruppe – Claude ordnet mit muster-recht-einstieg ein.",
        "skills": ["muster-recht-einstieg"]},
}
# Für jeden Fall hilfreich (Workflows aus dem Plugin)
SKILLS_ALLGEMEIN = ["workflow-fristen-ruecktritt-kuendigung", "workflow-beweislast-und-belegmatrix",
                    "workflow-red-team-gegenseite"]

PHASEN = [("eingang", "Eingang"), ("pruefung", "Prüfung"), ("aussergerichtlich", "Außergerichtlich"),
          ("vergleich", "Vergleich / Verhandlung"), ("gerichtlich", "Gerichtlich"), ("erledigt", "Erledigt")]

# ---------------------------------------------------------------- Checklisten „Was jetzt zu tun ist“
# Je Eintrag: (Kennung, Text, Quelle, Rolle) – Rolle None gilt für beide Seiten. Kennungen nie ändern: an ihnen hängt,
# was in einer Akte schon abgehakt ist.
WIR, GEGEN = "wir_fordern", "gegen_uns"

ALLGEMEIN = {
    "eingang": [
        ("e-fristen", "Alle laufenden Fristen herausstellen und eintragen – bei Anwaltsschreiben, Klage, Mahnbescheid "
                      "oder Behördenpost sofort.", "muster-recht-einstieg", None),
        ("e-unterlagen", "Unterlagen vollständig sammeln: Vertrag oder Auftrag, Übergabeprotokoll, Rechnung, bisheriger "
                         "Schriftverkehr – alles unter „Dokumente“ ablegen.", "muster-recht-einstieg", None),
        ("e-gegenseite", "Gegenseite einordnen: Verbraucher oder Unternehmer, Hersteller, Behörde, Anwalt?",
         "muster-recht-einstieg", None),
    ],
    "pruefung": [
        ("p-belege", "Belegmatrix anlegen: jede wichtige Behauptung mit einem Beleg verbinden, Lücken markieren und "
                     "klären, wie der Beleg zu beschaffen ist.", "workflow-beweislast-und-belegmatrix", None),
        ("p-beweislast", "Klären, wer was beweisen muss – Grundregel: jede Partei die Tatsachen, die für sie günstig sind.",
         "workflow-beweislast-und-belegmatrix", None),
        ("p-gegenseite", "Die stärksten Argumente der Gegenseite aufschreiben (Gegenprüfung).",
         "workflow-red-team-gegenseite", None),
        ("p-einordnen", "Dossier erzeugen und mit muster-recht-einstieg einordnen lassen: Einordnung, Risikoampel, "
                        "Fristen, Empfehlung.", "muster-recht-einstieg", None),
    ],
    "aussergerichtlich": [
        ("a-anerkenntnis", "Antworten ohne Anerkenntnis einer Rechtspflicht formulieren; Kulanz ausdrücklich als Kulanz "
                           "bezeichnen.", "muster-recht-einstieg", None),
        ("a-zugang", "Zugang wichtiger Schreiben nachweisbar machen (z. B. Einschreiben, Bote, Empfangsbestätigung) und "
                     "in der Chronologie festhalten.", "mahnung-aussergerichtlich-stufenmodell", None),
        ("a-wiedervorlage", "Wiedervorlage für die Antwort der Gegenseite setzen.", "schadenfall-aufnehmen", None),
    ],
    "vergleich": [
        ("v-ziel", "Ziel und Grenze intern festlegen – die eigene Mindestposition gehört nicht ins Angebot.",
         "unternehmensvergleich-und-erfuellung-gestalten", None),
        ("v-befugnis", "Klären, wer den Vergleich abschließen darf – vorher nichts zusagen.",
         "unternehmensvergleich-und-erfuellung-gestalten", None),
        ("v-umfang", "Gegenstand genau abgrenzen: welche Rechnung, welches Fahrzeug, welcher Zeitraum – keine pauschale "
                     "Generalquittung.", "unternehmensvergleich-und-erfuellung-gestalten", None),
        ("v-erfuellung", "Zahlung, Termine, Zug um Zug und Folgen bei Ausfall regeln; ein privater Vergleich ist kein "
                         "Vollstreckungstitel.", "unternehmensvergleich-und-erfuellung-gestalten", None),
        ("vb-zusammenfassen", "Die Lage aus Sicht der Gegenseite so zusammenfassen, dass sie „Genau so ist es“ sagen würde.",
         "Beirat: Chris Voss (Übertragung)", None),
        ("vb-vorwuerfe", "Vorwürfe vorwegnehmen, die die Gegenseite gegen uns haben könnte („Sie denken vermutlich …“).",
         "Beirat: Chris Voss (Übertragung)", None),
        ("vb-fragen", "Drei bis fünf Wie- und Was-Fragen vorbereiten („Was müsste passieren, damit …?“).",
         "Beirat: Chris Voss (Übertragung)", None),
        ("vb-bausteine", "Bausteine sammeln, die uns wenig kosten und der Gegenseite viel wert sind (Termin, Service, "
                         "Abholung) – statt nur über Geld zu reden.", "Beirat: Chris Voss (Übertragung)", None),
        ("vb-mitte", "Nicht „in der Mitte treffen“: Zugeständnisse nur gegen Gegenleistung und kleiner werdend.",
         "Beirat: Chris Voss (Übertragung)", None),
        ("vb-invertieren", "Umgekehrt denken: Wie würde dieser Fall für uns sicher schiefgehen? Genau das vermeiden.",
         "Beirat: Charlie Munger (Übertragung)", None),
        ("vb-ruf", "Ruf prüfen: Könnten wir unser Vorgehen jedem Kunden offen erklären? Alles, was wir sagen, muss wahr "
                   "sein.", "Beirat: Charlie Munger / Chris Voss (Übertragung)", None),
    ],
    "gerichtlich": [
        ("g-anwalt", "Externen Anwalt einbinden (oben eintragen) und Dossier und Dokumente übergeben.",
         "muster-recht-einstieg", None),
        ("g-fristen", "Jede Frist aus der Gerichtspost eintragen – Prozessfristen laufen unabhängig von Gesprächen und "
                      "Versicherung weiter.", "versicherung-einschalten", None),
        ("g-versicherung", "Haftpflichtfall: gerichtliche Inanspruchnahme dem Versicherer unverzüglich anzeigen "
                           "(§ 104 VVG).", "versicherung-einschalten", GEGEN),
    ],
    "erledigt": [
        ("z-ergebnis", "Ergebnis in der Chronologie festhalten (Vergleich, Zahlung, Urteil, Rücknahme).",
         "schadenfall-aufnehmen", None),
        ("z-aufbewahrung", "„Aufbewahrung bis“ eintragen – Aufbewahrungspflichten (z. B. HGB, AO) beachten, danach "
                           "die Akte löschen.", "datenschutz-auskunftsersuchen-art-15-praxis", None),
    ],
}

JE_TYP = {
    "reklamation": {
        "eingang": [
            ("r-uebergabe", "Datum der Übergabe eintragen (Bezug) – davon hängen Beweislast und Verjährung ab.",
             "kaufrecht-sachmangel-paragraph-434", None),
            ("r-protokoll", "Kaufvertrag, Übergabeprotokoll und Einweisung heraussuchen – oft das wichtigste Beweismittel.",
             "muster-recht-einstieg", None),
            ("r-gebraucht", "Neu oder gebraucht? Bei Gebrauchten: Wurde die Gewährleistung wirksam verkürzt oder ein "
                            "bekannter Mangel vereinbart (Formerfordernisse)?", "muster-recht-einstieg", None),
            ("r-bestaetigen", "Eingang freundlich bestätigen – ohne Zusage zur Ursache (Entwurf „Eingangsbestätigung“).",
             "muster-recht-einstieg", None),
        ],
        "pruefung": [
            ("r-aufbau", "Aufbau oder Basisfahrzeug? Davon hängt ab, über welchen Hersteller eine Garantie läuft und wohin "
                         "der Rückgriff geht – gegenüber dem Kunden haften wir trotzdem.", "muster-recht-einstieg", None),
            ("r-garantie", "Gesetzliche Gewährleistung und Hersteller- oder Dichtigkeitsgarantie getrennt prüfen; "
                           "Garantiebedingungen nur für die Garantie heranziehen.", "gewaehrleistung-und-garantie-trennen",
             None),
            ("r-477", "Verbraucher und Mangel innerhalb eines Jahres nach Übergabe? Dann wird vermutet, dass er schon bei "
                      "Übergabe da war (§ 477 BGB) – bei Unternehmern nicht.", "kaufrecht-sachmangel-paragraph-434", None),
            ("r-befund", "Fahrzeug ansehen, Befund mit Fotos und Datum festhalten.", "workflow-beweislast-und-belegmatrix",
             None),
            ("r-verjaehrung", "Verjährung prüfen: Mängelansprüche regelmäßig zwei Jahre ab Übergabe (§ 438 Abs. 1 Nr. 3 "
                              "BGB), bei Gebrauchten gegebenenfalls verkürzt.", "kaufrecht-sachmangel-paragraph-434", None),
        ],
        "aussergerichtlich": [
            ("r-nacherfuellung", "Nacherfüllung ermöglichen: Termin zur Prüfung und Nachbesserung anbieten (Entwurf "
                                 "„Terminangebot Nacherfüllung“).", "kaufrecht-nacherfuellung-ruecktritt-minderung", None),
            ("r-frist", "Hat der Kunde eine Frist zur Nacherfüllung gesetzt? Eintragen – Rücktritt und Minderung setzen in "
                        "der Regel eine erfolglose angemessene Frist voraus.",
             "kaufrecht-nacherfuellung-ruecktritt-minderung", None),
            ("r-erheblich", "Rücktritt verlangt? Prüfen, ob der Mangel erheblich ist – sonst kommt nur Minderung in "
                            "Betracht (§ 323 Abs. 5 S. 2 BGB).", "kaufrecht-nacherfuellung-ruecktritt-minderung", None),
            ("r-rueckgriff", "Rückgriff vorbereiten: Mangel an Hersteller oder Lieferanten melden (unter Kaufleuten "
                             "unverzüglich rügen, § 377 HGB).", "muster-recht-einstieg", None),
        ],
        "vergleich": [
            ("r-kulanz", "Kulanz nur ausdrücklich ohne Anerkennung einer Rechtspflicht anbieten (Entwurf „Kulanzangebot“).",
             "muster-recht-einstieg", None),
        ],
    },
    "werkstatt": {
        "eingang": [
            ("w-auftrag", "Werkstattauftrag, Rechnung und Datum der Abnahme bzw. Abholung festhalten – die Verjährung "
                          "beginnt mit der Abnahme (§ 634a Abs. 2 BGB).", "werkvertrag-maengelrechte", None),
            ("w-mangel", "Mangel konkret beschreiben lassen: was, seit wann, wann angezeigt?", "werkvertrag-maengelrechte",
             None),
        ],
        "pruefung": [
            ("w-abnahme", "War der Mangel bei der Abnahme vorhanden? Befund mit Fotos und Prüfbericht sichern.",
             "werkvertrag-maengelrechte", None),
            ("w-recht", "Uns steht zuerst die Nacherfüllung zu; Selbstvornahme durch den Kunden erst nach fehlgeschlagener "
                        "oder verweigerter Nacherfüllung (§ 637 BGB).", "werkvertrag-maengelrechte", None),
            ("w-rechnung", "Gekürzte Unfallreparatur-Rechnung: jede Position mit Gutachten, Auftrag und Zahlungen "
                           "abgleichen und den Zahlungsempfänger klären.", "werkstattrechnung-kuerzung-zahlungswege", None),
        ],
        "aussergerichtlich": [
            ("w-termin", "Termin zur Nachbesserung anbieten (Entwurf „Terminangebot Nacherfüllung“).",
             "werkvertrag-maengelrechte", None),
            ("w-frist", "Vom Kunden gesetzte Frist eintragen – ohne Fristsetzung in der Regel kein Rücktritt, keine "
                        "Minderung, kein Schadensersatz statt der Leistung.", "werkvertrag-maengelrechte", None),
            ("w-zahlung", "Zahlungen von Versicherungen mit Zahler, Empfänger, Datum und Zweck festhalten; keine Zahlung "
                          "doppelt anrechnen.", "werkstattrechnung-kuerzung-zahlungswege", None),
        ],
    },
    "forderung": {
        "eingang": [
            ("f-belege", "Auftrag oder Vertrag, Lieferschein bzw. Übergabe, Rechnung und Zahlungen zusammenstellen – eine "
                         "Rechnung allein beweist weder Auftrag noch Leistung.",
             "lieferforderung-und-maengeleinwand-bearbeiten", None),
            ("f-verbraucher", "Verbraucher oder Unternehmer? Davon hängen Verzug, Zinsen und Pauschalen ab.",
             "forderung-gegen-verbraucher", None),
            ("f-verzug", "Fälligkeit und Verzug klären: festes Zahlungsziel? Bei Verbrauchern gilt die 30-Tage-Regel nur "
                         "mit Hinweis in der Rechnung (§ 286 Abs. 3 BGB).", "mahnung-aussergerichtlich-stufenmodell", WIR),
            ("f-pruefen", "Forderung gegen uns prüfen: Leistung erhalten, Rechnung richtig, Gegenrechte (Mangel, "
                          "Aufrechnung)? Zurückbehalten ist kein Erlöschen der Forderung.",
             "lieferforderung-und-maengeleinwand-bearbeiten", GEGEN),
        ],
        "pruefung": [
            ("f-einwand", "Einwände (Mangel, Gegenforderung, Teilzahlung) getrennt von den unstreitigen Teilen darstellen.",
             "lieferforderung-und-maengeleinwand-bearbeiten", None),
            ("f-ampel", "Realitätscheck vor Mahnbescheid oder Klage: Schuldnertyp, Zahlungsfähigkeit, Belege, Verjährung, "
                        "Streitlage.", "inkasso-risikoampel", WIR),
            ("f-verjaehrung", "Verjährung im Blick: Eine außergerichtliche Mahnung hemmt sie nicht – erst z. B. "
                              "Mahnbescheid oder Klage (§ 204 BGB).", "mahnung-aussergerichtlich-stufenmodell", WIR),
        ],
        "aussergerichtlich": [
            ("f-erinnerung", "Stufe 1: freundliche Zahlungserinnerung (Entwurf „Zahlungserinnerung“).",
             "mahnung-aussergerichtlich-stufenmodell", WIR),
            ("f-mahnung", "Stufe 2: Mahnung mit bestimmter Zahlungsaufforderung und Frist – Verzug ab Zugang (Entwurf "
                          "„Mahnung“).", "mahnung-aussergerichtlich-stufenmodell", WIR),
            ("f-letzte", "Stufe 3: letzte Mahnung mit Ankündigung gerichtlicher Schritte – nur ankündigen, was wir auch "
                         "tun.", "mahnung-aussergerichtlich-stufenmodell", WIR),
        ],
        "gerichtlich": [
            ("f-mahnbescheid", "Mahnbescheid nur bei bezifferter Forderung ohne offene Gegenleistung; ist Widerspruch zu "
                               "erwarten, eher gleich Klage.", "mahnbescheid-online", WIR),
            ("f-vollstreckung", "Kein Widerspruch binnen zwei Wochen nach Zustellung: Vollstreckungsbescheid beantragen – "
                                "spätestens nach sechs Monaten (§ 701 ZPO).", "mahnbescheid-online", WIR),
            ("f-widerspruch", "Mahnbescheid gegen uns: Widerspruch binnen zwei Wochen ab Zustellung – Frist sofort "
                              "eintragen.", "mahnbescheid-online", GEGEN),
        ],
    },
    "abmahnung": {
        "eingang": [
            ("ab-frist", "Frist aus der Abmahnung eintragen und Anwalt einbinden – keine Unterlassungserklärung ungeprüft "
                         "unterschreiben.", "muster-recht-einstieg", GEGEN),
            ("ab-sichern", "Beanstandeten Inhalt mit Datum und Fundstelle dokumentieren (Screenshot).",
             "workflow-beweislast-und-belegmatrix", None),
            ("ab-art", "Einordnen: Wettbewerbsrecht (UWG) oder Urheberrecht (Foto, Musik, Text – § 97a UrhG)?",
             "muster-recht-einstieg", None),
        ],
        "pruefung": [
            ("ab-berechtigt", "Ist der Abmahnende berechtigt – Mitbewerber oder qualifizierter Verband (§ 8 Abs. 3 UWG) "
                              "bzw. Rechteinhaber?", "abmahnung-uwg", None),
            ("ab-missbrauch", "Hinweise auf Missbrauch prüfen (§ 8c UWG), z. B. Massenabmahnungen oder überhöhte "
                              "Vertragsstrafe.", "abmahnung-uwg", GEGEN),
            ("ab-erklaerung", "Unterlassungserklärung nie blind unterschreiben: zu weit gefasst? Gegebenenfalls "
                              "modifizierte Erklärung über den Anwalt.", "abmahnung-97a-response", GEGEN),
            ("ab-kosten", "Geforderte Kosten und Streitwert prüfen lassen.", "abmahnung-uwg", GEGEN),
        ],
        "aussergerichtlich": [
            ("ab-antwort", "Antwort nur abgestimmt mit dem Anwalt und vor Fristablauf.", "muster-recht-einstieg", None),
        ],
    },
    "arbeitsrecht": {
        "eingang": [
            ("ar-was", "Worum geht es: Abmahnung, Kündigung, Aufhebungsvertrag, Zeugnis oder Arbeitszeit?",
             "muster-recht-einstieg", None),
            ("ar-form", "Kündigung: Schriftform mit eigenhändiger Unterschrift – keine E-Mail, kein Scan (§ 623 BGB); "
                        "Zugang nachweisbar machen.", "kuendigung-zugang-beweiswerkstatt", None),
            ("ar-klagefrist", "Kündigungsschutzklage nur binnen drei Wochen ab Zugang (§ 4 KSchG) – Zugangsdatum "
                              "festhalten.", "kuendigung-zugang-beweiswerkstatt", None),
        ],
        "pruefung": [
            ("ar-sonderschutz", "Sonderkündigungsschutz zuerst prüfen: Schwangerschaft, Elternzeit, Schwerbehinderung, "
                                "Betriebsrat, Datenschutzbeauftragter.", "kuendigungs-pruefung", None),
            ("ar-kschg", "Gilt das Kündigungsschutzgesetz (mehr als zehn Arbeitnehmer, länger als sechs Monate "
                         "beschäftigt)?", "kuendigungs-pruefung", None),
            ("ar-betriebsrat", "Betriebsrat vorhanden? Dann vor jeder Kündigung anhören (§ 102 BetrVG).",
             "kuendigungs-pruefung", None),
            ("ar-abmahnung", "Verhaltensbedingt: Gibt es eine einschlägige Abmahnung mit konkretem Vorwurf, Rüge und "
                             "Warnung?", "abmahnung-arbeitsrecht", None),
            ("ar-kuendigungsfrist", "Kündigungsfrist nach Beschäftigungsdauer (§ 622 BGB) und Tarifvertrag prüfen.",
             "kuendigungs-pruefung", None),
        ],
        "aussergerichtlich": [
            ("ar-abmahnung-form", "Abmahnung: Vorfall mit Datum, Uhrzeit und Ort benennen, verletzte Pflicht nennen, "
                                  "Folgen androhen; Übergabe gegen Empfangsbestätigung, Kopie zur Personalakte.",
             "abmahnung-arbeitsrecht", None),
            ("ar-auskunft", "Auskunftsersuchen nach Art. 15 DSGVO im Zusammenhang? Monatsfrist eintragen.",
             "kuendigungs-pruefung", None),
        ],
    },
    "datenschutz": {
        "eingang": [
            ("ds-art", "Auskunftsersuchen (Art. 15) oder Datenpanne (Art. 33/34)? Eingang bzw. Kenntnis mit Uhrzeit "
                       "festhalten.", "datenschutz-auskunftsersuchen-art-15-praxis", None),
            ("ds-72h", "Datenpanne: Meldung an die Aufsichtsbehörde unverzüglich, möglichst binnen 72 Stunden ab "
                       "Kenntnis – eine Stufenmeldung ist zulässig (Art. 33 DSGVO).",
             "datenschutz-datenpanne-art-33-34-72h-incident", None),
            ("ds-monat", "Auskunft: Frist ein Monat ab Eingang (Art. 12 Abs. 3 DSGVO); Verlängerung nur mit Begründung "
                         "innerhalb des ersten Monats.", "datenschutz-auskunftsersuchen-art-15-praxis", None),
            ("ds-identitaet", "Identität der anfragenden Person prüfen, bevor Daten herausgehen (Art. 12 Abs. 6 DSGVO).",
             "datenschutz-auskunftsersuchen-art-15-praxis", None),
        ],
        "pruefung": [
            ("ds-systeme", "Wo liegen Daten? Verkaufs- und Werkstattsystem, Mails, Buchhaltung, Cloud, Backups – bei den "
                           "Zuständigen mit Frist abfragen.", "datenschutz-auskunftsersuchen-art-15-praxis", None),
            ("ds-dritte", "Daten Dritter (andere Kunden, Mitarbeiter) schwärzen (Art. 15 Abs. 4 DSGVO).",
             "datenschutz-auskunftsersuchen-art-15-praxis", None),
            ("ds-loeschen", "Nichts vorschnell löschen, um die Auskunft zu vermeiden; Aufbewahrungspflichten beachten.",
             "datenschutz-auskunftsersuchen-art-15-praxis", None),
            ("ds-risiko", "Datenpanne: Risiko für Betroffene bewerten und dokumentieren; Betroffene nur bei voraussichtlich "
                          "hohem Risiko benachrichtigen (Art. 34 DSGVO).",
             "datenschutz-datenpanne-art-33-34-72h-incident", None),
            ("ds-intern", "Intern sachlich schreiben – keine pauschalen Selbstvorwürfe in Mails.",
             "datenschutz-datenpanne-art-33-34-72h-incident", None),
        ],
        "aussergerichtlich": [
            ("ds-antwort", "Auskunft mit Zwecken, Datenkategorien, Empfängern, Speicherdauer und Kopie der Daten "
                           "vorbereiten und vor dem Versand freigeben.", "datenschutz-auskunftsersuchen-art-15-praxis",
             None),
            ("ds-register", "Jede Datenpanne intern dokumentieren – auch ohne Meldung (Art. 33 Abs. 5 DSGVO).",
             "datenschutz-datenpanne-art-33-34-72h-incident", None),
        ],
    },
    "schaden": {
        "eingang": [
            ("s-gefahr", "Besteht noch Gefahr? Erst sichern (Betrieb, Notdienst), dann dokumentieren.",
             "schadenfall-aufnehmen", None),
            ("s-rollen", "Rollen trennen: Geschädigter, Anspruchsgegner, Halter, Hersteller, Versicherer.",
             "schadenfall-aufnehmen", None),
            ("s-naechste-frist", "Die nächste tatsächliche Frist zuerst setzen: Videoüberschreibung, "
                                 "Versicherungsanzeige, Termine.", "schadenfall-aufnehmen", None),
        ],
        "pruefung": [
            ("s-versicherer", "Versicherer nach dem Risiko wählen (Betriebs-, Kfz-, Produkthaftpflicht oder eigene "
                              "Sachversicherung) und die Police heraussuchen.", "versicherung-einschalten", None),
            ("s-anzeige", "Haftpflicht: mögliche Verantwortlichkeit und spätere Ansprüche binnen einer Woche anzeigen "
                          "(§ 104 VVG) – auch wenn die Höhe noch unklar ist (Entwurf „Meldung an die Versicherung“).",
             "versicherung-einschalten", GEGEN),
            ("s-selbstbehalt", "Auch Schäden unter dem Selbstbehalt melden – der Selbstbehalt ist keine Haftungsgrenze.",
             "versicherung-einschalten", GEGEN),
        ],
        "aussergerichtlich": [
            ("s-anerkenntnis", "Kein Anerkenntnis und keine Zahlung ohne Abstimmung mit dem Versicherer.",
             "versicherung-einschalten", GEGEN),
            ("s-deckung", "Schadennummer, Ansprechpartner und Deckungsstand erfragen; „Meldung eingegangen“, „Deckung unter "
                          "Vorbehalt“ und „Deckung bestätigt“ unterscheiden.", "versicherung-einschalten", None),
        ],
    },
    "lieferant": {
        "eingang": [
            ("l-handelskauf", "Beidseitiger Handelskauf? Dann gilt die Untersuchungs- und Rügeobliegenheit (§ 377 HGB).",
             "maengelruege-paragraph-377-hgb", None),
            ("l-ruege", "Offene Mängel unverzüglich nach der Untersuchung, verdeckte unverzüglich nach Entdeckung rügen – "
                        "konkret (Fahrgestellnummer, Bauteil, Befund). Absendung belegen.",
             "maengelruege-paragraph-377-hgb", None),
            ("l-wareneingang", "Wareneingang belegen: Lieferdatum, Lieferschein, Prüfung, Fotos, Prüfer.",
             "maengelruege-paragraph-377-hgb", None),
        ],
        "pruefung": [
            ("l-beweis", "Im Handelskauf hilft § 477 BGB nicht: Der Mangel bei Gefahrübergang muss belegt werden.",
             "maengelruege-paragraph-377-hgb", None),
            ("l-betraege", "Rechnung, Gutschriften, Teilzahlungen und streitige Abzüge getrennt darstellen.",
             "lieferforderung-und-maengeleinwand-bearbeiten", None),
        ],
        "aussergerichtlich": [
            ("l-nacherfuellung", "Nacherfüllung mit genauer Abweichung, Prüfzugang und angemessenem Endtermin verlangen "
                                 "(Entwurf „Mängelrüge“).", "lieferforderung-und-maengeleinwand-bearbeiten", None),
            ("l-beziehung", "Laufende Lieferungen von der streitigen Altposition trennen; keine ungeprüften Abzüge.",
             "lieferforderung-und-maengeleinwand-bearbeiten", None),
        ],
    },
    "finanzierung": {
        "eingang": [
            ("fi-art", "Verbraucherdarlehen, Leasing oder Finanzierung über eine Bank (verbundenes Geschäft)? Vertrag und "
                       "Pflichtangaben heraussuchen.", "darlehen-und-finanzierung", None),
            ("fi-widerruf", "Widerruf erklärt? Frist und Belehrung prüfen – eine fehlerhafte Belehrung verlängert die "
                            "Widerrufsfrist.", "darlehen-und-finanzierung", None),
        ],
        "pruefung": [
            ("fi-verzug", "Zahlungsverzug beim Verbraucherdarlehen: Kündigungsvoraussetzungen streng prüfen (§ 498 BGB).",
             "darlehen-und-finanzierung", None),
            ("fi-rueckgabe", "Leasingrückgabe: Protokoll mit Fotos und Kilometerstand; normale Abnutzung von übermäßigem "
                             "Verschleiß trennen.", "fahrzeugleasing-kilometervertrag-restwertvertrag-rueck", None),
        ],
    },
    "sonstiges": {
        "pruefung": [
            ("so-einordnen", "Mit muster-recht-einstieg einordnen lassen – passt kein Fachskill, wird nach allgemeinem "
                             "deutschem Recht gearbeitet und das offen gesagt.", "muster-recht-einstieg", None),
        ],
    },
}


def schritte(falltyp: str, rolle: str) -> list:
    """Alle Schritte eines Falls in der Reihenfolge der Phasen: [{id, phase, text, quelle}]."""
    liste = []
    for phase, _ in PHASEN:
        for kennung, text, quelle, nur in JE_TYP.get(falltyp, {}).get(phase, []) + ALLGEMEIN.get(phase, []):
            if nur is None or nur == rolle:
                liste.append({"id": kennung, "phase": phase, "text": text, "quelle": quelle})
    return liste


# ---------------------------------------------------------------- Rechenhilfen für Fristen
# (Kennung, Bezeichnung, Ausgangsdatum, Anzahl, Einheit, Norm/Hinweis, Quelle, Rolle) – nur Rechenhilfe, nie „sicher“.
RECHENHILFEN = {
    "reklamation": [
        ("r477", "Ende der Vermutung nach § 477 BGB (Verbraucher)", "Übergabe", 1, "jahre", "§ 477 Abs. 1 BGB",
         "kaufrecht-sachmangel-paragraph-434", None),
        ("r438", "Verjährung der Mängelansprüche", "Übergabe", 2, "jahre",
         "§ 438 Abs. 1 Nr. 3 BGB – bei Gebrauchten gegebenenfalls verkürzt", "kaufrecht-sachmangel-paragraph-434", None),
    ],
    "werkstatt": [
        ("w634a", "Verjährung der Mängelansprüche (Werkvertrag)", "Abnahme", 2, "jahre", "§ 634a BGB",
         "werkvertrag-maengelrechte", None),
    ],
    "forderung": [
        ("f286", "Verzug 30 Tage nach Fälligkeit und Zugang der Rechnung", "Zugang der Rechnung", 30, "tage",
         "§ 286 Abs. 3 BGB – bei Verbrauchern nur mit Hinweis in der Rechnung", "mahnung-aussergerichtlich-stufenmodell",
         WIR),
        ("f694", "Widerspruch gegen einen Mahnbescheid", "Zustellung", 2, "wochen", "§ 692, § 694 ZPO",
         "mahnbescheid-online", GEGEN),
        ("f701", "Vollstreckungsbescheid spätestens beantragen", "Zustellung des Mahnbescheids", 6, "monate", "§ 701 ZPO",
         "mahnbescheid-online", WIR),
    ],
    "abmahnung": [
        ("ab11", "Verjährung des Unterlassungsanspruchs (UWG)", "Kenntnis vom Verstoß", 6, "monate", "§ 11 Abs. 1 UWG",
         "abmahnung-uwg", None),
    ],
    "arbeitsrecht": [
        ("ar4", "Klagefrist Kündigungsschutzklage", "Zugang der Kündigung", 3, "wochen", "§ 4 KSchG",
         "kuendigung-zugang-beweiswerkstatt", None),
        ("ar12", "Antwort auf ein Auskunftsersuchen", "Eingang", 1, "monate", "Art. 12 Abs. 3 DSGVO",
         "kuendigungs-pruefung", None),
    ],
    "datenschutz": [
        ("ds33", "Meldung einer Datenpanne (72 Stunden)", "Kenntnis", 3, "tage",
         "Art. 33 Abs. 1 DSGVO – die 72 Stunden laufen ab der Uhrzeit der Kenntnis",
         "datenschutz-datenpanne-art-33-34-72h-incident", None),
        ("ds12", "Antwort auf ein Auskunftsersuchen", "Eingang", 1, "monate", "Art. 12 Abs. 3 DSGVO",
         "datenschutz-auskunftsersuchen-art-15-praxis", None),
    ],
    "schaden": [
        ("s104", "Anzeige an den Haftpflichtversicherer", "Kenntnis", 1, "wochen", "§ 104 VVG", "versicherung-einschalten",
         None),
    ],
    "lieferant": [
        ("l438", "Verjährung der Mängelansprüche", "Ablieferung", 2, "jahre", "§ 438 Abs. 1 Nr. 3 BGB",
         "kaufrecht-sachmangel-paragraph-434", None),
    ],
    "finanzierung": [
        ("fi355", "Widerrufsfrist", "Vertragsschluss bzw. Belehrung", 14, "tage",
         "§ 355 BGB – der Beginn hängt von der Belehrung ab", "darlehen-und-finanzierung", None),
    ],
}
EINHEITEN = {"tage": ("Tag", "Tage"), "wochen": ("Woche", "Wochen"), "monate": ("Monat", "Monate"),
             "jahre": ("Jahr", "Jahre")}
RECHEN_HINWEIS = ("Rechenhilfe – bitte prüfen: Beginn (Zugang, Zustellung, Kenntnis), Wochenende und Feiertage "
                  "(§ 193 BGB) und Sonderregeln. Keine sichere Fristberechnung.")


def rechenhilfen(falltyp: str, rolle: str) -> list:
    return [{"id": k, "titel": t, "ab": ab, "anzahl": n, "einheit": e, "norm": norm, "quelle": q}
            for k, t, ab, n, e, norm, q, nur in RECHENHILFEN.get(falltyp, []) if nur is None or nur == rolle]


# ---------------------------------------------------------------- Entwürfe
# Nach den Regeln aus muster-recht-einstieg („Antwortentwürfe nach außen“): Absender ist das Unternehmen („wir“), ruhig,
# freundlich, sachlich, keine Gedankenstriche, kein Fettdruck, kein Anerkenntnis, keine Zusagen, die niemand nachhält.
# Platzhalter in {geschweiften Klammern} füllt die Akte; was fehlt, bleibt als [eckige Klammer] stehen.
# Felder: id, titel, falltypen (None = alle), rolle (None = beide), betreff, text, quelle, hinweis, frist_tage

ENTWUERFE = [
    {"id": "eingang_reklamation", "titel": "Eingangsbestätigung Reklamation", "falltypen": ["reklamation", "werkstatt"],
     "rolle": None, "frist_tage": None,
     "betreff": "Ihre Nachricht vom {datum_schreiben}",
     "text": "{anrede}\n\nvielen Dank für Ihre Nachricht vom {datum_schreiben}. Wir haben Ihre Schilderung erhalten und "
             "sehen uns die Sache genau an.\n\nDamit wir den Punkt richtig einordnen können, möchten wir das Fahrzeug gern "
             "bei uns in der Werkstatt ansehen. Bitte schicken Sie uns dafür, soweit vorhanden, Fotos und eine kurze "
             "Beschreibung, seit wann Ihnen der Punkt auffällt. Etwas zur Ursache können wir erst nach der Prüfung sagen."
             "\n\nEinen Termin vereinbaren Sie mit unserem Service unter {kontakt_service}.\n\nFreundliche Grüße\n"
             "{absender}\nCaravan Muster",
     "quelle": "muster-recht-einstieg (Antwortentwürfe nach außen)",
     "hinweis": "Keine Aussage zur Ursache und kein Anerkenntnis. Du oder Sie aus der eingehenden Nachricht übernehmen."},
    {"id": "termin_nacherfuellung", "titel": "Terminangebot Nacherfüllung", "falltypen": ["reklamation", "werkstatt"],
     "rolle": None, "frist_tage": None,
     "betreff": "Termin zur Prüfung {fahrzeug}",
     "text": "{anrede}\n\nwir möchten uns den von Ihnen gemeldeten Punkt an Ihrem Fahrzeug ansehen und ihn, soweit ein "
             "Mangel vorliegt, beheben. Dafür bieten wir Ihnen folgenden Termin in unserer Werkstatt an: [Datum und "
             "Uhrzeit].\n\nBitte planen Sie dafür [Dauer] ein. Passt Ihnen der Termin nicht, nennen Sie uns bitte zwei "
             "andere Termine, die für Sie gehen.\n\nFreundliche Grüße\n{absender}\nCaravan Muster",
     "quelle": "kaufrecht-nacherfuellung-ruecktritt-minderung; werkvertrag-maengelrechte",
     "hinweis": "Das Angebot zur Nacherfüllung ist noch keine Aussage, dass ein Mangel vorliegt. Angebot und Termin in "
                "der Chronologie festhalten."},
    {"id": "kulanz", "titel": "Kulanzangebot ohne Anerkennung einer Rechtspflicht",
     "falltypen": ["reklamation", "werkstatt"], "rolle": None, "frist_tage": 14,
     "betreff": "Ihr Anliegen zu {fahrzeug}",
     "text": "{anrede}\n\nwir haben uns Ihr Anliegen angesehen. Unabhängig von der Frage, ob ein Mangel vorliegt, und ohne "
             "Anerkennung einer Rechtspflicht bieten wir Ihnen aus Kulanz Folgendes an: [Angebot].\n\nDas Angebot gilt "
             "bis zum {frist}. Bitte geben Sie uns bis dahin Bescheid, ob Sie es annehmen möchten.\n\nFreundliche Grüße\n"
             "{absender}\nCaravan Muster",
     "quelle": "muster-recht-einstieg (Stoppschilder: Kulanz ausdrücklich ohne Anerkennung einer Rechtspflicht)",
     "hinweis": "Vorher klären, wer das Angebot freigeben darf."},
    {"id": "zahlungserinnerung", "titel": "Zahlungserinnerung (Stufe 1)", "falltypen": ["forderung"], "rolle": WIR,
     "frist_tage": 7,
     "betreff": "Zahlungserinnerung Rechnung [Rechnungsnummer]",
     "text": "{anrede}\n\nsicher ist es Ihrer Aufmerksamkeit entgangen: Unsere Rechnung [Rechnungsnummer] vom "
             "[Rechnungsdatum] über {betrag} ist seit dem [Fälligkeitsdatum] fällig. Bitte überweisen Sie den Betrag bis "
             "zum {frist} auf unser Konto [IBAN].\n\nHat sich Ihre Zahlung mit diesem Schreiben überschnitten, ist diese "
             "Erinnerung gegenstandslos.\n\nFreundliche Grüße\n{absender}\nCaravan Muster",
     "quelle": "mahnung-aussergerichtlich-stufenmodell (Stufe 1)",
     "hinweis": "Noch keine Mahnung im Rechtssinne, keine Kosten. Erinnerung mit Datum in der Chronologie vermerken."},
    {"id": "mahnung", "titel": "Mahnung (Stufe 2)", "falltypen": ["forderung"], "rolle": WIR, "frist_tage": 10,
     "betreff": "Mahnung Rechnung [Rechnungsnummer]",
     "text": "{anrede}\n\ntrotz unserer Rechnung [Rechnungsnummer] vom [Rechnungsdatum] über {betrag} haben wir bis heute "
             "keine Zahlung erhalten. Wir fordern Sie auf, den fälligen Betrag bis zum {frist} auf unser Konto [IBAN] zu "
             "zahlen.\n\nNach Ablauf dieser Frist berechnen wir Verzugszinsen in Höhe von {zinssatz} Prozentpunkten über "
             "dem Basiszinssatz.\n\nFreundliche Grüße\n{absender}\nCaravan Muster",
     "quelle": "mahnung-aussergerichtlich-stufenmodell (Stufe 2); forderung-gegen-verbraucher",
     "hinweis": "Erst nach Fälligkeit mahnen. Verzug tritt mit Zugang ein: Zugang nachweisbar machen. Für die erste Mahnung "
                "keine Mahnkosten. Zinssatz prüfen (Verbraucher 5, Unternehmer nicht ungeprüft 9 Prozentpunkte)."},
    {"id": "letzte_mahnung", "titel": "Letzte Mahnung (Stufe 3)", "falltypen": ["forderung"], "rolle": WIR,
     "frist_tage": 7,
     "betreff": "Letzte Mahnung Rechnung [Rechnungsnummer]",
     "text": "{anrede}\n\nleider ist unsere Rechnung [Rechnungsnummer] über {betrag} trotz unserer Mahnung vom [Datum der "
             "Mahnung] weiterhin offen. Wir fordern Sie letztmalig auf, den Betrag bis zum {frist} zu zahlen.\n\nGeht die "
             "Zahlung bis dahin nicht ein, werden wir ohne weitere Ankündigung gerichtliche Schritte einleiten. Die Kosten "
             "der Rechtsverfolgung hätten Sie dann zu tragen.\n\nFreundliche Grüße\n{absender}\nCaravan Muster",
     "quelle": "mahnung-aussergerichtlich-stufenmodell (Stufe 3)",
     "hinweis": "Nur ankündigen, was wir auch tun. Vorher Realitätscheck (Inkasso-Risikoampel) und Verjährung prüfen."},
    {"id": "fristverlaengerung", "titel": "Bitte um Fristverlängerung", "falltypen": None, "rolle": GEGEN,
     "frist_tage": None,
     "betreff": "Ihr Schreiben vom {datum_schreiben}",
     "text": "{anrede_schriftlich}\n\nwir bestätigen den Eingang Ihres Schreibens vom {datum_schreiben}. Für eine sorgfältige "
             "Prüfung benötigen wir noch Unterlagen und etwas Zeit. Wir bitten Sie daher, die Frist bis zum "
             "{frist_vorschlag} zu verlängern, und um eine kurze Bestätigung.\n\nDiese Bitte ist kein Anerkenntnis der "
             "geltend gemachten Ansprüche.\n\nFreundliche Grüße\n{absender}\nEubo Caravan Muster GmbH",
     "quelle": "muster-recht-einstieg (Stoppschilder); workflow-fristen-ruecktritt-kuendigung",
     "hinweis": "Die Verlängerung gilt erst, wenn die Gegenseite sie bestätigt – bis dahin die alte Frist im Kalender "
                "lassen. Gesetzliche und gerichtliche Fristen lassen sich so in der Regel nicht verlängern: im Zweifel "
                "Anwalt."},
    {"id": "versicherung", "titel": "Meldung an die Versicherung", "falltypen": ["schaden", "werkstatt", "reklamation"],
     "rolle": GEGEN, "frist_tage": None,
     "betreff": "Schadenmeldung, Versicherungsnummer [Versicherungsnummer]",
     "text": "Sehr geehrte Damen und Herren,\n\nwir melden Ihnen vorsorglich folgenden Vorgang, aus dem Ansprüche gegen uns "
             "geltend gemacht werden oder werden könnten.\n\nVersicherungsnehmer: Eubo Caravan Muster GmbH, Am Walde 2, "
             "30916 Isernhagen\nEreignis: [Datum, Ort, kurze Beschreibung]\nAnspruchsteller: {gegenseite}\n"
             "Betroffenes Fahrzeug: {fahrzeug}\nArt des Schadens: [Sachschaden oder Personenschaden]\nHöhe: {hoehe}\n"
             "Vorhandene Unterlagen:\n{dokumentliste}\nBisherige Erklärungen gegenüber dem Anspruchsteller: [keine oder "
             "Inhalt]\n\nBitte bestätigen Sie uns den Eingang dieser Meldung und teilen Sie uns die Schadennummer, Ihren "
             "Ansprechpartner und den Stand der Deckung mit. Bitte sagen Sie uns auch, wie wir mit eventuellen "
             "Sofortkosten verfahren sollen.\n\nFreundliche Grüße\n{absender}\nEubo Caravan Muster GmbH",
     "quelle": "versicherung-einschalten",
     "hinweis": "Haftpflicht: binnen einer Woche anzeigen (§ 104 VVG), auch unter dem Selbstbehalt. Unbekannte Höhe offen "
                "lassen. Bisherige Erklärungen ehrlich angeben; kein Anerkenntnis und keine Zahlung ohne Abstimmung."},
    {"id": "anwalt", "titel": "Weiterleitung an den Anwalt", "falltypen": None, "rolle": None, "frist_tage": None,
     "betreff": "Neuer Fall {aktenzeichen}: {titel}",
     "text": "{anrede_anwalt}\n\nwir bitten Sie, uns in folgender Angelegenheit zu beraten und gegebenenfalls zu vertreten."
             "\n\nWorum es geht: {sachverhalt}\nGegenseite: {gegenseite_voll}\nUnsere Rolle: {rolle}\nStreitwert nach "
             "unserer Einschätzung: {betrag}\nOffene Fristen:\n{fristenliste}\n\nIm Anhang finden Sie die Unterlagen und "
             "eine Übersicht mit Chronologie und Belegen. Bitte bestätigen Sie uns, ob Sie das Mandat übernehmen, und "
             "nennen Sie uns, was Sie noch benötigen.\n\nFreundliche Grüße\n{absender}\nEubo Caravan Muster GmbH",
     "quelle": "muster-recht-einstieg (Stoppschilder: Anwalt einbinden)",
     "hinweis": "Das Dossier (Reiter „Dossier“, ohne Namenskürzung) und die Dokumente beifügen. Fristen selbst im Blick "
                "behalten, bis der Anwalt sie bestätigt."},
    {"id": "maengelruege", "titel": "Mängelrüge an Hersteller oder Lieferant", "falltypen": ["lieferant", "reklamation"],
     "rolle": None, "frist_tage": 14,
     "betreff": "Mängelrüge {fahrzeug}, Lieferung vom [Lieferdatum]",
     "text": "Sehr geehrte Damen und Herren,\n\nbei der Untersuchung des am [Lieferdatum] gelieferten Fahrzeugs {fahrzeug}, "
             "Fahrgestellnummer [Fahrgestellnummer], haben wir am [Datum der Entdeckung] folgenden Mangel festgestellt: "
             "[konkrete Beschreibung mit Bauteil, Befund und Messwerten].\n\nWir rügen diesen Mangel hiermit. Fotos und "
             "Prüfbericht fügen wir bei. Wir fordern Sie auf, den Mangel bis zum {frist} zu beseitigen oder uns bis dahin "
             "mitzuteilen, wie die Nacherfüllung erfolgen soll. Das Fahrzeug steht für eine Prüfung bei uns bereit.\n\n"
             "Weitere Rechte behalten wir uns vor.\n\nFreundliche Grüße\n{absender}\nEubo Caravan Muster GmbH",
     "quelle": "maengelruege-paragraph-377-hgb; lieferforderung-und-maengeleinwand-bearbeiten",
     "hinweis": "Unverzüglich absenden und die Absendung belegen (§ 377 Abs. 4 HGB: rechtzeitige Absendung genügt). "
                "Mangel so konkret beschreiben, dass der Lieferant prüfen kann."},
    {"id": "auskunft_eingang", "titel": "Eingangsbestätigung Auskunftsersuchen", "falltypen": ["datenschutz"],
     "rolle": None, "frist_tage": None,
     "betreff": "Ihr Auskunftsersuchen vom {datum_schreiben}",
     "text": "{anrede}\n\nIhr Auskunftsersuchen nach Art. 15 DSGVO vom {datum_schreiben} ist am [Eingangsdatum] bei uns "
             "eingegangen. Wir bearbeiten es innerhalb der Frist nach Art. 12 Abs. 3 DSGVO.\n\nAus Datenschutzgründen "
             "erteilen wir Auskünfte erst, wenn wir sicher sind, dass sie die richtige Person erreichen. Sollten wir dafür "
             "weitere Angaben benötigen, melden wir uns.\n\nFreundliche Grüße\n{absender}\nEubo Caravan Muster GmbH",
     "quelle": "datenschutz-auskunftsersuchen-art-15-praxis (Mustertexte)",
     "hinweis": "Nichts zusagen, was über die gesetzliche Pflicht hinausgeht. Monatsfrist als Frist eintragen."},
    {"id": "auskunft_verlaengerung", "titel": "Fristverlängerung Auskunft (Art. 12 Abs. 3 DSGVO)",
     "falltypen": ["datenschutz"], "rolle": None, "frist_tage": None,
     "betreff": "Ihr Auskunftsersuchen vom {datum_schreiben}",
     "text": "{anrede}\n\nIhr Auskunftsersuchen vom {datum_schreiben} bearbeiten wir mit Sorgfalt. Wegen des Umfangs der "
             "Anfrage [betroffene Systeme, zum Beispiel Mails, Werkstattsystem, Buchhaltung] verlängern wir die Frist nach "
             "Art. 12 Abs. 3 Satz 2 DSGVO um zwei weitere Monate bis zum [Datum]. Wir bitten um Verständnis.\n\n"
             "Freundliche Grüße\n{absender}\nEubo Caravan Muster GmbH",
     "quelle": "datenschutz-auskunftsersuchen-art-15-praxis (Mustertexte)",
     "hinweis": "Nur innerhalb des ersten Monats und nur mit konkreter Begründung."},
    {"id": "abmahnung_mitarbeiter", "titel": "Abmahnung eines Mitarbeiters", "falltypen": ["arbeitsrecht"],
     "rolle": None, "frist_tage": None,
     "betreff": "Abmahnung",
     "text": "{anrede}\n\nwir rügen folgendes Verhalten: Am [Datum] um [Uhrzeit] haben Sie [konkrete Handlung oder "
             "Unterlassung]. Damit haben Sie gegen Ihre Pflicht aus [Arbeitsvertrag, Regelung oder Dienstanweisung vom] "
             "verstoßen.\n\nWir fordern Sie auf, dieses Verhalten künftig zu unterlassen und [konkrete Anforderung].\n\n"
             "Wir weisen Sie ausdrücklich darauf hin, dass wir im Wiederholungsfall arbeitsrechtliche Konsequenzen bis hin "
             "zur Kündigung des Arbeitsverhältnisses in Betracht ziehen werden.\n\n[Ort, Datum, Unterschrift]\n\n"
             "Erhalten am: [Datum, Unterschrift]",
     "quelle": "abmahnung-arbeitsrecht (Muster-Gliederung)",
     "hinweis": "Konkret und zeitnah zum Vorfall. Übergabe gegen Empfangsbestätigung, Kopie zur Personalakte. Vor einer "
                "Kündigung immer den Anwalt fragen."},
]
