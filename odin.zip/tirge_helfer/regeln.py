"""
Stumm geschaltete Änderungen: Arten von Änderungen, die bei einem Hersteller nicht mehr als wichtig zählen,
z. B. „Hersteller1 · Bestelltext geändert“ oder „Hersteller2 · Artikel 40281 · Einzelpreis geändert“.

Die Regeln liegen im Ordner „Fahrzeuge“ (_odin-regeln.json), damit alle, die mit derselben Ablage arbeiten,
dieselben Regeln haben. Eine stumm geschaltete Änderung wird weiter angezeigt – als Info, nicht als wichtig.

Außerdem gelernte Zuordnungen für den Abgleich mit Syscara, ebenfalls pro Hersteller:
- syscara: „Expedition Grau“ ist in der AB Artikel 25048 (artikel leer: steht nie in der AB, z. B. Verkaufsaktion);
           mehrere Zuordnungen für denselben Namen sind Alternativen (andere Fahrzeuge, andere Artikel),
- nur_ab:  Artikel 40098 steht nie in Syscara (z. B. eine Gebühr, die ODIN nicht als Gebühr erkennt).
"""

import copy
import datetime as dt
import getpass
import hashlib
import json
import os
import secrets
import uuid

DATEI = "_odin-regeln.json"
_GELESEN = {}


class NichtLesbar(Exception):
    """_odin-regeln.json ist da, aber nicht lesbar – und es gibt keinen zuletzt gelesenen Stand."""

    def __init__(self, beschaedigt: bool = False):
        super().__init__(
            "Die Datei „_odin-regeln.json“ im Ordner „Fahrzeuge“ ist beschädigt. Bitte in OneDrive/SharePoint über "
            "„Versionsverlauf“ die letzte gute Version wiederherstellen." if beschaedigt else
            "Die Regeln sind gerade nicht lesbar (z. B. von OneDrive gesperrt) – gleich noch einmal versuchen.")


def schluessel(bereich: str) -> str:
    """Positionen über die Artikelnummer, Kopffelder über ihren Namen:
    'Pos. 14 · 40281' -> 'Artikel 40281', 'Liefertermin' -> 'Liefertermin'."""
    if bereich.startswith("Pos.") and " · " in bereich:
        return "Artikel " + bereich.split(" · ", 1)[1].strip()
    return bereich.strip()


def wurzel_von(fahrzeug_pfad: str) -> str:
    """Fahrzeuge/<Jahr>/<Hersteller>/<Fahrzeug> -> Fahrzeuge"""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(fahrzeug_pfad))))


def _pfad(wurzel: str) -> str:
    return os.path.join(wurzel, DATEI)


def _lies(pfad: str) -> dict:
    with open(pfad, encoding="utf-8") as f:
        daten = json.load(f)
    if not isinstance(daten, dict) or any(not isinstance(daten.get(k, []), list) for k in ("stumm", "syscara", "nur_ab")):
        raise ValueError("Regeldatei beschädigt")
    return daten


def _alles(wurzel: str) -> dict:
    """Zum Lesen: der aktuelle Stand, {} wenn es noch keine Regeln gibt. Ist die Datei gerade gesperrt oder kaputt,
    gilt der zuletzt gelesene Stand – ein Fehlversuch wird nicht gemerkt. Gibt es keinen: NichtLesbar (mit „keine
    Regeln“ würden stumm geschaltete Änderungen wieder wichtig und Zuordnungen fehlen)."""
    pfad = _pfad(wurzel)
    zuletzt = _GELESEN.get(pfad)
    try:
        stempel_datei = os.stat(pfad).st_mtime_ns
        if zuletzt and zuletzt[0] == stempel_datei:
            return zuletzt[1]
        daten = _lies(pfad)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as e:
        if zuletzt:
            return zuletzt[1]
        raise NichtLesbar(beschaedigt=isinstance(e, ValueError)) from e
    _GELESEN[pfad] = (stempel_datei, daten)
    return daten


def lade(wurzel: str) -> list:
    """Stummschalt-Regeln."""
    return _alles(wurzel).get("stumm", [])


def _aendere(wurzel: str, aenderung):
    """Liest die Datei frisch (ein anderer Rechner kann sie gerade geändert haben), wendet die Änderung an und
    schreibt sie. Ist sie gerade nicht lesbar, wird nichts geschrieben – sonst gingen Regeln verloren.
    Ist sie kaputt, wird sie als _odin-regeln.defekt-….json aufgehoben und vom zuletzt gelesenen Stand aus weitergemacht."""
    pfad = _pfad(wurzel)
    daten = {}
    if os.path.exists(pfad):
        try:
            daten = _lies(pfad)
        except ValueError:
            daten = copy.deepcopy(_GELESEN.get(pfad, (None, {}))[1])
            os.replace(pfad, os.path.join(wurzel, f"_odin-regeln.defekt-{dt.datetime.now():%Y%m%d-%H%M%S}.json"))
        except OSError as e:
            raise PermissionError(f"Die Regeln sind gerade gesperrt (z. B. von OneDrive) – bitte gleich noch einmal "
                                  f"versuchen. ({e})") from e
    daten["format"] = 1
    for k in ("stumm", "syscara", "nur_ab"):
        daten.setdefault(k, [])
    aenderung(daten)
    tmp = f"{pfad}.{os.getpid()}.{secrets.token_hex(4)}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(daten, f, ensure_ascii=False, indent=1)
    os.replace(tmp, pfad)
    _GELESEN.pop(pfad, None)


def stempel(regeln: list, hersteller: str = None) -> str:
    """Kurzer Fingerabdruck der Regeln (eines Herstellers) – ändert er sich, werden gespeicherte Vergleiche
    neu bewertet. Pro Hersteller, damit eine Hersteller2-Regel nicht alle Hersteller1-Akten neu schreibt."""
    regeln = [r for r in regeln if hersteller is None or r["hersteller"] == hersteller]
    if not regeln:
        return ""
    teile = sorted(f"{r['hersteller']}|{r['schluessel']}|{r['art']}" for r in regeln)
    return hashlib.sha1("\n".join(teile).encode()).hexdigest()[:12]


def ist_stumm(regeln: list, hersteller: str, bereich: str, art: str) -> bool:
    k = schluessel(bereich)
    return any(r["hersteller"] == hersteller and r["schluessel"] == k and r["art"] == art for r in regeln)


def schalte_stumm(wurzel: str, hersteller: str, bereich: str, art: str, titel: str = "", beispiel: str = "") -> list:
    def dazu(daten):
        if not ist_stumm(daten["stumm"], hersteller, bereich, art):
            daten["stumm"].append({"id": uuid.uuid4().hex[:10], "hersteller": hersteller, "schluessel": schluessel(bereich),
                                   "art": art, "titel": titel, "beispiel": beispiel, **_wer()})
    _aendere(wurzel, dazu)
    return lade(wurzel)


def entferne(wurzel: str, regel_id: str = "", hersteller: str = "", bereich: str = "", art: str = "") -> list:
    """Entfernt eine Regel über ihre ID oder über Hersteller + Bereich + Art."""
    k = schluessel(bereich) if bereich else ""

    def weg(daten):
        daten["stumm"] = [r for r in daten["stumm"] if not (
            r["id"] == regel_id or (k and r["hersteller"] == hersteller and r["schluessel"] == k and r["art"] == art))]
    _aendere(wurzel, weg)
    return lade(wurzel)


# ---------------- Gelernte Zuordnungen für den Syscara-Abgleich ----------------

def lade_syscara(wurzel: str) -> list:
    return _alles(wurzel).get("syscara", [])


def lade_nur_ab(wurzel: str) -> list:
    return _alles(wurzel).get("nur_ab", [])


def syscara_stempel(wurzel: str, hersteller: str) -> str:
    """Fingerabdruck der Zuordnungen eines Herstellers – ändert er sich, wird der Abgleich neu bewertet."""
    teile = sorted(f"s|{z['syscara']}|{','.join(z.get('artikel', []))}|{','.join(z.get('titel_schluessel', []))}"
                   for z in lade_syscara(wurzel) if z["hersteller"] == hersteller)
    teile += sorted(f"a|{z['artikel']}" for z in lade_nur_ab(wurzel) if z["hersteller"] == hersteller)
    return hashlib.sha1("\n".join(teile).encode()).hexdigest()[:12] if teile else ""


def _wer() -> dict:
    try:
        von = getpass.getuser()
    except Exception:
        von = ""
    return {"von": von, "am": dt.datetime.now().isoformat(timespec="seconds")}


def _gleiche_positionen(z: dict, artikel: list, titel: list) -> bool:
    eigene = sorted(z.get("artikel", []))
    return eigene == sorted(artikel) and (bool(eigene) or sorted(z.get("titel_schluessel", [])) == sorted(titel))


def ordne_syscara_zu(wurzel: str, hersteller: str, name: str, schluessel: str, positionen: list) -> list:
    """Syscara-Ausstattung 'name' entspricht diesen AB-Positionen [{artikel, text, schluessel}] – leer: steht nie
    in der AB. Wiedererkannt werden die Positionen über die Artikelnummer oder über die Bezeichnung (schluessel);
    alle müssen in der AB stehen. Gibt es für den Namen schon eine Zuordnung zu anderen Positionen, kommt diese als
    Alternative dazu (z. B. anderer Artikel bei einem anderen Fahrzeug) – beide gelten, entfernt wird jede einzeln.
    „teile“ hält die Positionen paarweise; „artikel“ und „titel_schluessel“ bleiben für ältere ODIN-Versionen."""
    artikel = [p["artikel"] for p in positionen if p.get("artikel")]
    titel = [p["schluessel"] for p in positionen if p.get("schluessel")]

    def dazu(daten):
        daten["syscara"] = [z for z in daten["syscara"] if not (
            z["hersteller"] == hersteller and z["syscara"] == schluessel and _gleiche_positionen(z, artikel, titel))]
        daten["syscara"].append({"id": uuid.uuid4().hex[:10], "hersteller": hersteller, "syscara": schluessel, "name": name,
                                 "artikel": artikel, "titel": " + ".join(p["text"] for p in positionen),
                                 "titel_schluessel": titel,
                                 "teile": [{"artikel": p.get("artikel", ""), "schluessel": p.get("schluessel", ""),
                                            "text": p.get("text", "")} for p in positionen],
                                 **_wer()})
    _aendere(wurzel, dazu)
    return lade_syscara(wurzel)


def ignoriere_nur_ab(wurzel: str, hersteller: str, artikel: str, titel: str = "") -> list:
    """Dieser AB-Artikel steht beim Hersteller nie in Syscara."""
    def dazu(daten):
        daten["nur_ab"] = [z for z in daten["nur_ab"] if not (z["hersteller"] == hersteller and z["artikel"] == artikel)]
        daten["nur_ab"].append({"id": uuid.uuid4().hex[:10], "hersteller": hersteller, "artikel": artikel, "titel": titel,
                                **_wer()})
    _aendere(wurzel, dazu)
    return lade_nur_ab(wurzel)


def entferne_zuordnung(wurzel: str, regel_id: str):
    """regel_id: eine ID oder mehrere mit Komma (alle Alternativen eines Namens, z. B. „Lösen“ bei „fehlt“)."""
    ids = set(regel_id.split(","))

    def weg(daten):
        daten["syscara"] = [z for z in daten["syscara"] if z["id"] not in ids]
        daten["nur_ab"] = [z for z in daten["nur_ab"] if z["id"] not in ids]
    _aendere(wurzel, weg)
