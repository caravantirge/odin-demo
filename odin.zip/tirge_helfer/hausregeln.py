"""
Verbindliche Hausregeln – mitgeliefert, versioniert, für alle im Team gleich.

Hausregeln sind keine Tipps: Sie hat die Geschäftsführung festgelegt und sie gelten vor jedem Coaching-Rat aus
„Beirat & Coaching“. Wer Inhalte im Beirat, in den Tagesfragen oder im Wissen schreibt, muss zu ihnen passen
(tests/test_hausregeln.py prüft das per Stichwort).

Je Regel:
- id               feste Kennung (BEREICH-NNN), wird in Antworten und Verweisen genannt – nie umnummerieren
- titel            kurz, wie man im Laden darüber spricht
- bereich          Geltungsbereich (wer/was)
- regel            die Regel selbst – verbindlich
- ausnahme         was ausdrücklich erlaubt ist (oder „keine“)
- kunde            Kundenformulierungen zum Kopieren (freundlich, ohne zusätzliche Bedingungen zu erfinden)
- stand            Datum der Festlegung (JJJJ-MM-TT)
- verantwortlich   wer die Regel ändern darf
- stichworte       Wörter, an denen der Fragen-Assistent die Regel erkennt (vereinfacht: ä → ae usw.).
                   Steht ein Wort in „schwach“, zählt es nur zusammen mit einem Wort aus „zusammen_mit“.
- abgrenzung       optional: wofür die Regel ausdrücklich NICHT gilt – dann sagt der Assistent das, statt die Regel
                   auszudehnen (es wird keine Regel erfunden)

Eine neue Regel: Eintrag in REGELN ergänzen, VERSION erhöhen, Fragen in FRAGEN ergänzen. Nichts davon liegt im
gemeinsamen Ordner – mit der neuen Fassung gilt die Regel sofort für alle.
"""

import re

VERSION = 1
WO = "Team & Projekte → Wissen & Einarbeitung → Hausregeln"
ZIEL = "#/wissen/hausregeln"
ID_MUSTER = re.compile(r"[A-Z]{3,12}-\d{3}")

REGELN = [
    {
        "id": "VERKAUF-001",
        "titel": "Probefahrt bei Neufahrzeugen",
        "bereich": "Verkauf · Neufahrzeuge",
        "regel": "Bei Neufahrzeugen bietet der Verkäufer keine Probefahrt aktiv an. Stattdessen bieten wir eine "
                 "ausführliche Besichtigung und ein Beratungsgespräch am Fahrzeug an.",
        "ausnahme": "Keine. Fragt der Kunde selbst nach einer Probefahrt, erklärst du ihm die Regel sachlich und "
                    "freundlich – das ist ausdrücklich erwünscht – und bietest Besichtigung und Gespräch an.",
        "kunde": [
            "Bei unseren Neufahrzeugen bieten wir keine Probefahrten an. Was ich Ihnen gern anbiete: Wir gehen das "
            "Fahrzeug in Ruhe gemeinsam durch – Sitzprobe, Bett, Küche, Bedienung und alles, was Ihnen beim Reisen "
            "wichtig ist.",
            "Das verstehe ich gut. Bei Neufahrzeugen machen wir grundsätzlich keine Probefahrten. Erzählen Sie mir "
            "gern, was Sie beim Fahren genau wissen möchten – vieles kann ich Ihnen direkt am Fahrzeug zeigen und "
            "erklären.",
        ],
        "stand": "2026-11-25",
        "verantwortlich": "Geschäftsführung",
        "stichworte": ["probefahrt", "probefahrten", "probefahren", "probe fahren", "testfahrt", "test fahren",
                       "proberunde", "runde drehen", "fahren lassen"],
        "schwach": [],
        "zusammen_mit": [],
        "abgrenzung": {
            "stichworte": ["gebraucht", "gebrauchtfahrzeug", "gebrauchtwagen", "gebrauchten", "mietfahrzeug",
                           "miete", "vermietung"],
            "nur_ohne": ["neu", "neufahrzeug", "neuwagen", "neues", "neuen", "neue"],
            "text": "Die Hausregel VERKAUF-001 gilt für Neufahrzeuge. Für Gebraucht- oder Mietfahrzeuge steht in "
                    "den Hausregeln nichts – im Zweifel bei der Geschäftsführung nachfragen.",
        },
    },
    {
        "id": "VERKAUF-002",
        "titel": "Keine Reservierungen",
        "bereich": "Verkauf · alle Fahrzeuge",
        "regel": "Reservierungen sind nicht vorgesehen – auch nicht kurz, „übers Wochenende“ oder „bis Freitag“.",
        "ausnahme": "Ein Kunde ruft unmittelbar vor seiner Anfahrt an: Dann halten wir das Fahrzeug nur für die "
                    "konkret bestätigte Fahrtzeit zurück. Daraus entsteht kein genereller Anspruch und keine "
                    "längere Reservierung.",
        "kunde": [
            "Reservierungen sind bei uns leider nicht vorgesehen – auch nicht übers Wochenende. Wenn noch Fragen "
            "offen sind, klären wir sie gern jetzt gleich gemeinsam.",
            "Sie machen sich jetzt direkt auf den Weg? Wann sind Sie ungefähr bei uns? Für diese Fahrt halte ich "
            "Ihnen das Fahrzeug bis dahin zurück.",
        ],
        "stand": "2026-11-25",
        "verantwortlich": "Geschäftsführung",
        "stichworte": ["reservieren", "reserviere", "reservierung", "reservierungen", "reserviert", "reservier",
                       "zuruecklegen", "zurueckgelegt", "zurueckstellen", "zurueckgestellt"],
        "schwach": ["festhalten", "freihalten", "frei halten", "zurueckhalten", "blocken", "blockieren", "vormerken"],
        "zusammen_mit": ["fahrzeug", "wohnmobil", "wohnwagen", "caravan", "kastenwagen", "neuwagen", "wagen",
                         "wochenende", "freitag", "samstag", "montag", "anfahrt"],
        "abgrenzung": None,
    },
]

# Tagesfragen zu den Hausregeln: (Kennung, Frage, Antworten – die richtige vorn –, Erklärung, Regel)
FRAGEN = [
    ("probe1", "Ein Kunde interessiert sich für ein neues Wohnmobil. Bietest du ihm von dir aus eine Probefahrt an?",
     ["Nein – ich biete eine ausführliche Besichtigung und ein Gespräch am Fahrzeug an",
      "Ja, immer – das überzeugt am meisten", "Nur, wenn er unsicher wirkt", "Ja, aber nur am Wochenende"],
     "Hausregel VERKAUF-001: Bei Neufahrzeugen bietet der Verkäufer keine Probefahrt aktiv an. Stattdessen "
     "Besichtigung und Beratungsgespräch am Fahrzeug.", "VERKAUF-001"),
    ("probe2", "Der Kunde fragt selbst: „Kann ich mit dem neuen Fahrzeug eine Probefahrt machen?“ Was tust du?",
     ["Die Hausregel freundlich und sachlich erklären und Besichtigung und Gespräch anbieten",
      "Die Frage überhören und weiter erklären", "Doch kurz eine Runde fahren, damit er zufrieden ist",
      "Sagen, das gehe nicht, und das Gespräch beenden"],
     "Die Regel verbietet keine Erklärung – im Gegenteil: sachlich sagen, wie wir es halten, und Besichtigung und "
     "Gespräch anbieten (Hausregel VERKAUF-001).", "VERKAUF-001"),
    ("reserv1", "Eine Kundin möchte ein Fahrzeug „übers Wochenende reservieren“. Was gilt?",
     ["Reservierungen sind nicht vorgesehen – auch nicht übers Wochenende", "Bis Montag ist das in Ordnung",
      "Mit einer kleinen Anzahlung geht es", "Wenn der Verkäufer zustimmt, geht es"],
     "Hausregel VERKAUF-002: Reservierungen sind nicht vorgesehen – auch nicht kurz oder übers Wochenende.",
     "VERKAUF-002"),
    ("reserv2", "Ein Kunde ruft an: „Ich fahre jetzt los und bin in einer Stunde bei Ihnen.“ Was ist möglich?",
     ["Das Fahrzeug für die konkret bestätigte Fahrtzeit zurückhalten", "Das Fahrzeug bis Ende der Woche reservieren",
      "Gar nichts – auch nicht für die Anfahrt", "Das Fahrzeug fest zusagen, egal wann er kommt"],
     "Der einzige Sonderfall der Hausregel VERKAUF-002: Anruf unmittelbar vor der Anfahrt – dann nur für die "
     "bestätigte Fahrtzeit.", "VERKAUF-002"),
    ("reserv3", "Für einen Kunden hast du ein Fahrzeug während seiner Anfahrt zurückgehalten. Entsteht daraus eine "
                "längere Reservierung?",
     ["Nein – es gilt nur für die bestätigte Fahrtzeit, ein Anspruch entsteht nicht", "Ja, für drei Tage",
      "Ja, bis er sich entschieden hat", "Nur, wenn er unterwegs aufgehalten wird"],
     "Hausregel VERKAUF-002: Der Sonderfall gilt nur für die konkret bestätigte Fahrtzeit – kein genereller "
     "Anspruch.", "VERKAUF-002"),
    ("wo", "Wo findest du die verbindlichen Hausregeln in ODIN?",
     ["Wissen & Einarbeitung → Hausregeln", "Unter Datenquellen", "Im Beirat unter „Gedanke des Tages“",
      "Nur im Kopf der Geschäftsführung"],
     "Alle Hausregeln mit Stand, Verantwortlichem und Kundenformulierungen stehen unter Wissen & Einarbeitung → "
     "Hausregeln. Der Fragen-Assistent kennt sie auch.", "VERKAUF-001"),
]


# ---------------------------------------------------------------- Zugriff

def _einfach(text) -> str:
    t = str(text or "").lower()
    for alt, neu in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(alt, neu)
    return " " + " ".join(re.split(r"[^0-9a-z]+", t)).strip() + " "


def alle() -> list:
    """Alle Regeln für die Oberfläche (Kopien, ohne Erkennungswörter)."""
    return [{k: (list(r[k]) if isinstance(r[k], list) else r[k])
             for k in ("id", "titel", "bereich", "regel", "ausnahme", "kunde", "stand", "verantwortlich")}
            | {"stichworte": [w for w in r["stichworte"] if " " not in w][:6]} for r in REGELN]


def regel(rid):
    return next((r for r in REGELN if r["id"] == rid), None)


def kurz(rid) -> dict:
    """{"id", "titel", "regel"} für Verweise (z. B. im Beirat) – leer, wenn es die Regel nicht gibt."""
    r = regel(rid)
    return {"id": r["id"], "titel": r["titel"], "regel": r["regel"]} if r else {}


def _hat(text: str, woerter) -> bool:
    """Wort oder Wortanfang (vereinfacht) kommt im Text vor."""
    return any(f" {w}" in text for w in woerter)


def erkennen(frage) -> list:
    """Regeln, um die es in der Frage geht (in der Reihenfolge von REGELN)."""
    t = _einfach(frage)
    treffer = []
    for r in REGELN:
        if _hat(t, r["stichworte"]) or (_hat(t, r["schwach"]) and _hat(t, r["zusammen_mit"])):
            treffer.append(r)
    return treffer


def antwort_text(r: dict) -> str:
    stand = ".".join(reversed(r["stand"].split("-")))
    return (f"Hausregel {r['id']} – {r['titel']} (verbindlich, Stand {stand}, {r['verantwortlich']}): {r['regel']}\n"
            f"Ausnahme: {r['ausnahme']}\n"
            f"So kannst du es dem Kunden sagen: „{r['kunde'][0]}“\n"
            f"Alle Hausregeln: {WO}.")


def assistent_antwort(frage):
    """Antwort im Format des Assistenten ({"text", "daten", "werkzeug": "hausregel", "modus", "ziel", "kundentext"})
    oder None. Hausregeln gehen jedem Coaching-Rat vor."""
    treffer = erkennen(frage)
    if not treffer:
        return None
    t = _einfach(frage)
    teile, kunde = [], []
    for r in treffer:
        a = r.get("abgrenzung")
        if a and _hat(t, a["stichworte"]) and not _hat(t, a.get("nur_ohne", [])):
            teile.append(a["text"])
            continue
        teile.append(antwort_text(r))
        kunde.append(r["kunde"][0])
    return {"text": "\n\n".join(teile), "daten": None, "werkzeug": "hausregel", "modus": "regel", "ziel": ZIEL,
            "kundentext": "\n\n".join(kunde) or None,
            "kundentext_hinweis": "Formulierung aus den Hausregeln – gern in eigenen Worten" if kunde else None}


def pruefen() -> list:
    """Probleme in den Regeln und Fragen – leer, wenn alles stimmt (Tests und Selbsttest)."""
    p = []
    ids = [r["id"] for r in REGELN]
    if len(set(ids)) != len(ids):
        p.append("Hausregeln: doppelte Kennung")
    for r in REGELN:
        if not ID_MUSTER.fullmatch(r["id"]):
            p.append(f"{r['id']}: Kennung nicht im Muster BEREICH-NNN")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", r["stand"]):
            p.append(f"{r['id']}: Stand ist kein Datum")
        for feld in ("titel", "bereich", "regel", "ausnahme", "verantwortlich"):
            if not r.get(feld):
                p.append(f"{r['id']}: {feld} fehlt")
        if not r["kunde"] or not r["stichworte"]:
            p.append(f"{r['id']}: Kundenformulierung oder Stichworte fehlen")
        if r["schwach"] and not r["zusammen_mit"]:
            p.append(f"{r['id']}: schwache Stichworte ohne „zusammen_mit“")
    for fid, frage, antworten, erklaerung, rid in FRAGEN:
        if rid not in ids:
            p.append(f"Frage {fid}: unbekannte Regel {rid}")
        if len(antworten) != 4 or len(set(antworten)) != 4 or any(len(x) > 160 for x in antworten):
            p.append(f"Frage {fid}: nicht vier verschiedene, kurze Antworten")
        if len(frage) > 300 or not 20 <= len(erklaerung) <= 600:
            p.append(f"Frage {fid}: Text zu lang oder Erklärung zu kurz")
    if len({f[0] for f in FRAGEN}) != len(FRAGEN):
        p.append("Hausregel-Fragen: doppelte Kennung")
    return p
