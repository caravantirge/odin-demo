"""AB-Vergleich als PDF, AB-Übersicht als Excel und Mailbericht als HTML."""

import datetime as dt
import html

from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.styles import Alignment, Font, PatternFill
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .ab_vergleich import WICHTIG, wortdiff, zusammenfassung

ROT = colors.HexColor("#D0141C")
TINTE = colors.HexColor("#231F20")
GRAU = colors.HexColor("#575354")
LINIE = colors.HexColor("#E2E1E1")
FLAECHE = colors.HexColor("#F4F3F3")


def _esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _fassung(ab) -> str:
    stand = ab.kopf.get("Ausfertigung") or ab.kopf.get("Änderungsstand") or ""
    return f" ({_esc(stand)})" if stand else ""


def schreibe_vergleich_pdf(pfad, fz, alt, neu, aenderungen):
    text = ParagraphStyle("t", fontName="Helvetica", fontSize=9, leading=12, textColor=TINTE, alignment=TA_LEFT)
    klein = ParagraphStyle("k", parent=text, fontSize=8, leading=10, textColor=GRAU)
    titel = ParagraphStyle("h", parent=text, fontName="Helvetica-Bold", fontSize=18, leading=22)
    zwischen = ParagraphStyle("z", parent=text, fontName="Helvetica-Bold", fontSize=11, leading=14,
                              spaceBefore=10, spaceAfter=4)

    def zelle(s, stil=text):
        return Paragraph(_esc(s) or "–", stil)

    def markiert(woerter, farbe):
        if not woerter:
            return Paragraph("–", text)
        return Paragraph(" ".join(f'<font color="{farbe}"><b>{_esc(w)}</b></font>' if g else _esc(w)
                                  for w, g in woerter), text)

    inhalt = [
        Paragraph(f"AB-Vergleich {_esc(fz.interne_id or fz.auftragsnummer)}", titel),
        Paragraph(f"{_esc(fz.hersteller)} · Auftragsnummer {_esc(fz.auftragsnummer or '–')} · "
                  f"Interne ID {_esc(fz.interne_id or '–')}", klein),
        Spacer(1, 4 * mm),
        Paragraph(f"<b>Neu:</b> {_esc(neu.belegart)} vom {_esc(neu.datum)}{_fassung(neu)}"
                  f" &nbsp;&nbsp;geprüft gegen&nbsp;&nbsp; <b>Vorher:</b> {_esc(alt.belegart)} vom {_esc(alt.datum)}"
                  f"{_fassung(alt)}", text),
        Paragraph(f"<b>Ergebnis: {_esc(zusammenfassung(aenderungen))}</b>", text),
    ]

    for stufe, ueberschrift in ((WICHTIG, "Wichtige Änderungen"), ("info", "Zur Info")):
        zeilen = [a for a in aenderungen if a.stufe == stufe]
        if not zeilen:
            continue
        inhalt.append(Paragraph(ueberschrift, zwischen))
        daten = [[zelle("Bereich", klein), zelle("Änderung", klein), zelle("Vorher", klein), zelle("Neu", klein)]]
        for a in zeilen:
            links, rechts = wortdiff(a.alt, a.neu)
            art = f"{a.art} (stumm geschaltet)" if getattr(a, "stumm", False) else a.art
            daten.append([zelle(a.bereich), zelle(art), markiert(links, "#575354"), markiert(rechts, "#D0141C")])
        # splitInRow: sehr lange Zellen (z. B. Paketinhalt mit 40 Teilen) dürfen über die Seite umbrechen
        t = Table(daten, colWidths=[38 * mm, 32 * mm, 50 * mm, 50 * mm], repeatRows=1, splitInRow=1)
        stil = [
            ("LINEBELOW", (0, 0), (-1, -1), 0.5, LINIE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (-1, 0), FLAECHE),
            ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
        if stufe == WICHTIG:
            stil.append(("LINEBEFORE", (0, 1), (0, -1), 2, ROT))
        t.setStyle(TableStyle(stil))
        inhalt.append(t)

    if not aenderungen:
        inhalt.append(Spacer(1, 6 * mm))
        inhalt.append(Paragraph("Die neue Fassung stimmt mit der vorherigen überein.", text))

    inhalt += [Spacer(1, 8 * mm),
               Paragraph(f"Erstellt am {dt.datetime.now():%d.%m.%Y %H:%M} von ODIN. "
                         "Gewichte und Rechtstexte werden nicht verglichen.", klein)]
    SimpleDocTemplate(pfad, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                      topMargin=16 * mm, bottomMargin=16 * mm,
                      title=f"AB-Vergleich {fz.interne_id or fz.auftragsnummer}").build(inhalt)


STATUS_TEXT = {"offen": "Offen", "klaerung": "In Klärung", "erledigt": "Erledigt"}
ERGEBNIS_TEXT = {"erste": "Erste AB – mit Syscara abgleichen", "keine": "Keine Änderung", "info": "Nur Info",
                 "wichtig": "Wichtige Änderungen", "syscara": "Passt zu Syscara"}
ART_TEXT = {"manuell": "", "automatisch": "automatisch", "eingelesen": "aus „AB erledigt“"}
UEBERSICHT_SPALTEN = [("Status", 12), ("Interne ID", 13), ("Auftragsnr.", 14), ("Hersteller", 11), ("Jahr", 7),
                      ("Neueste AB", 12), ("Geprüfter Stand", 15), ("Neue ABs", 10), ("Ergebnis", 22), ("Wichtig", 8),
                      ("Änderungen", 70), ("Syscara", 50), ("Liefertermin", 14), ("Notiz", 40), ("Bearbeitet von", 16),
                      ("Bearbeitet am", 14)]


def ergebnis_text(z) -> str:
    """„Erste AB – mit Syscara abgleichen“ nur, solange das Fahrzeug offen ist."""
    if z.get("status") == "erledigt" and z.get("ergebnis") == "erste":
        return "Erste AB"
    return ERGEBNIS_TEXT.get(z.get("ergebnis"), "")


def sauber(wert):
    """Steuerzeichen (z. B. aus einer aus Word kopierten Notiz) kann Excel nicht speichern."""
    return ILLEGAL_CHARACTERS_RE.sub("", wert) if isinstance(wert, str) else wert


def als_text(zelle):
    """Texte wie „=> Rückfrage …“ sind keine Excel-Formel."""
    if zelle.data_type == "f":
        zelle.data_type = "s"


def syscara_text(z) -> str:
    """'passt' / 'Fehlt in AB: … · Unsicher: …' / '' (kein Syscara-Stand)"""
    sy = z.get("syscara")
    if not sy:
        return ""
    return "passt" if sy.get("ok") else " · ".join(sy.get("kurz", []))


def _deutsch(iso: str) -> str:
    try:
        return dt.date.fromisoformat(iso[:10]).strftime("%d.%m.%Y")
    except (ValueError, TypeError):
        return iso or ""


def exportiere_uebersicht(pfad, zeilen):
    """Arbeitsliste als Excel-Tabelle, ein Fahrzeug pro Zeile (Reiter 'Auftragsbestätigungen' → Excel)."""
    wb = Workbook()
    ws = wb.active
    ws.title = "AB-Übersicht"
    for i, (titel, breite) in enumerate(UEBERSICHT_SPALTEN, start=1):
        c = ws.cell(row=1, column=i, value=titel)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="231F20")
        ws.column_dimensions[c.column_letter].width = breite
    ws.freeze_panes = "A2"
    for z in zeilen:
        fz = z["fahrzeug"]
        von = z.get("von") or ART_TEXT.get(z.get("art"), "")
        ws.append([sauber(w) for w in (
            STATUS_TEXT.get(z.get("status"), z.get("status")), fz["interne_id"], fz["auftragsnummer"],
            fz["hersteller"], fz["jahr"], _deutsch(z["datum"]),
            _deutsch(z.get("gegen_datum", "")) if z.get("gegen_art") != "erste" else "",
            z.get("neue_abs", 0), ergebnis_text(z), z.get("wichtig", 0),
            " · ".join(z.get("kurz") or z.get("stichworte", [])), syscara_text(z), z.get("liefertermin", ""),
            z.get("notiz", ""), von, _deutsch(z.get("am", "")))])
        for c in ws[ws.max_row]:
            als_text(c)
            c.alignment = Alignment(vertical="top", wrap_text=c.column in (11, 12, 14))
        if z.get("status") == "offen":
            ws.cell(row=ws.max_row, column=1).font = Font(bold=True, color="D0141C")
    ws.auto_filter.ref = f"A1:P{ws.max_row}"
    wb.save(pfad)


def schreibe_mailbericht(pfad, ergebnisse, staende):
    """HTML-Zusammenfassung einer Prüfung, pro Fahrzeug. Power Automate verschickt sie als Mail.

    ergebnisse: was mit jeder AB aus dem Eingang passiert ist; staende: (Zeile, Gesamtänderungen) je Fahrzeug."""
    e = html.escape
    zu_pruefen = [(z, a) for z, a in staende if z["status"] != "erledigt"]
    ruhig = [z for z, _ in staende if z["status"] == "erledigt"]
    doppelt = [x for x in ergebnisse if x.status == "Doppelt"]
    fehler = [x for x in ergebnisse if x.status == "Nicht erkannt"]
    abgebrochen = [x for x in ergebnisse if x.status == "Fehler"]
    eingeordnet = sum(x.status == "Eingeordnet" for x in ergebnisse)

    def kennung(fz):
        if fz["interne_id"] and fz["auftragsnummer"]:
            return f'{e(fz["interne_id"])} ({e(fz["auftragsnummer"])})'
        return e(fz["interne_id"] or fz["auftragsnummer"] or fz["name"])

    td = 'style="padding:6px 10px;border-bottom:1px solid #E2E1E1;vertical-align:top"'
    td_grau = 'style="padding:6px 10px;border-bottom:1px solid #E2E1E1;vertical-align:top;color:#575354"'
    th = 'style="padding:6px 10px;text-align:left;background:#F4F3F3;font-weight:600;font-size:12px;color:#575354"'
    teile = [
        '<div style="font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#231F20;max-width:860px">',
        '<div style="height:6px;width:64px;background:#ED1C24;margin-bottom:14px"></div>',
        f'<h2 style="margin:0 0 4px;font-size:22px">AB-Prüfung vom {dt.datetime.now():%d.%m.%Y, %H:%M} Uhr</h2>',
        f'<p style="margin:0 0 18px;color:#575354">{eingeordnet} neue AB(s) für {len(staende)} Fahrzeug(e): '
        f'<b style="color:#D0141C">{len(zu_pruefen)} Fahrzeug(e) zu prüfen</b>, {len(ruhig)} ohne Handlungsbedarf'
        f'{f", {len(doppelt)} doppelt" if doppelt else ""}{f", {len(fehler)} nicht erkannt" if fehler else ""}.</p>',
    ]
    if zu_pruefen:
        teile.append('<h3 style="font-size:16px;margin:18px 0 6px">Bitte prüfen</h3>')
        for z, aenderungen in zu_pruefen:
            fz = z["fahrzeug"]
            mehr = f' ({z["neue_abs"]} neue ABs)' if z.get("neue_abs", 0) > 1 else ""
            klaerung = ' · <b>in Klärung</b>' if z["status"] == "klaerung" else ""
            sy = z.get("syscara")
            abgleichen = "Abgleich mit Syscara unten" if sy else "<b>mit Syscara abgleichen</b>"
            if z.get("gegen_art") == "erste":
                vergleich = (f'neueste AB vom {e(_deutsch(z["datum"]))}{mehr} – {abgleichen}; '
                             f'Änderungen seit der ersten AB vom {e(_deutsch(z["gegen_datum"]))}')
            elif z["gegen"]:
                vergleich = (f'neueste AB vom {e(_deutsch(z["datum"]))}{mehr} gegen geprüften Stand vom '
                             f'{e(_deutsch(z["gegen_datum"]))}')
            else:
                vergleich = f'AB vom {e(_deutsch(z["datum"]))} – erste AB, {abgleichen}'
            teile.append(f'<p style="margin:14px 0 4px"><b>{kennung(fz)}</b> · {e(fz["hersteller"])} · {vergleich}{klaerung}</p>')
            if z.get("hinweis"):
                teile.append(f'<p style="margin:0 0 4px;color:#B25E00">{e(z["hinweis"])}</p>')
            if sy and sy.get("ok"):
                teile.append('<p style="margin:0 0 4px;color:#575354">Syscara: alles passt zur Bestellung.</p>')
            elif sy:
                teile.append('<p style="margin:0 0 2px"><b>Syscara:</b></p><ul style="margin:0 0 6px;padding-left:18px">'
                             + "".join(f"<li>{e(k)}</li>" for k in sy.get("kurz", [])) + "</ul>")
            wichtig = [a for a in aenderungen if a.stufe == WICHTIG]
            if wichtig:
                teile.append(f'<table style="border-collapse:collapse;width:100%;font-size:13px"><tr><th {th}>Bereich</th>'
                             f'<th {th}>Änderung</th><th {th}>Vorher</th><th {th}>Neu</th></tr>')
                for a in wichtig:
                    titel = f'<br><span style="color:#575354">{e(a.titel)}</span>' if a.titel and a.titel not in (a.alt, a.neu) else ""
                    teile.append(f'<tr><td {td}>{e(a.bereich)}{titel}</td><td {td}>{e(a.art)}</td>'
                                 f'<td {td_grau}>{e(a.alt) or "–"}</td>'
                                 f'<td {td}><b style="color:#D0141C">{e(a.neu) or "–"}</b></td></tr>')
                teile.append('</table>')
    if ruhig:
        teile.append('<h3 style="font-size:16px;margin:22px 0 6px">Ohne Handlungsbedarf</h3><ul style="margin:0;padding-left:18px">')
        for z in ruhig:
            grund = ("passt zur Bestellung in Syscara" if z.get("gegen_syscara") and not z.get("gegen") else
                     "keine wichtige Änderung seit dem geprüften Stand" if z.get("art") == "automatisch" else "bereits erledigt")
            teile.append(f'<li>{kennung(z["fahrzeug"])} · {e(z["fahrzeug"]["hersteller"])} · '
                         f'AB vom {e(_deutsch(z["datum"]))} – {grund}</li>')
        teile.append('</ul>')
    if doppelt or fehler or abgebrochen:
        teile.append('<h3 style="font-size:16px;margin:22px 0 6px">Sonstiges</h3><ul style="margin:0;padding-left:18px">')
        for x in doppelt:
            fz = x.fahrzeug
            teile.append(f'<li>{e(fz.interne_id or fz.auftragsnummer) if fz else e(x.datei)}: {e(x.meldung)}</li>')
        for x in fehler:
            teile.append(f'<li>{e(x.datei)}: nicht erkannt – {e(x.meldung)} (liegt in „AB-Eingang/Nicht erkannt“)</li>')
        for x in abgebrochen:
            ort = ("liegt noch im AB-Eingang, wird beim nächsten Prüfen erneut versucht"
                   if getattr(x, "noch_im_eingang", True) else "liegt schon im Fahrzeugordner")
            teile.append(f'<li>{e(x.datei)}: <b>Fehler beim Verarbeiten</b> – {e(x.meldung)} ({ort})</li>')
        teile.append('</ul>')
    teile.append('<p style="color:#575354;font-size:12px;margin-top:24px">ODIN · Details und Status im Reiter '
                 '„Auftragsbestätigungen“.</p></div>')
    with open(pfad, "w", encoding="utf-8") as f:
        f.write("<!doctype html><html><head><meta charset=\"utf-8\"></head><body>" + "".join(teile) + "</body></html>")
