"""
Rechtsfälle: je Fall eine Akte, in der alles an einem Ort liegt – Mailverlauf, Dateien, Fotos, Verträge, Protokolle,
Rechnungen, Fristen, Chronologie, Belege – dazu „Was jetzt zu tun ist“, Entwürfe für Formulierungen und ein Dossier, mit
dem der Fall in Claude (Skill muster-recht-einstieg) weiterbearbeitet werden kann. ODIN selbst rechnet und schreibt nur
nach festen Regeln; die Fachinhalte stehen in rechtsfaelle_inhalte.py.

Ablage: je Fall ein Ordner <Basis>/Rechtsfaelle/<Aktenzeichen>/ mit akte.json und dem Unterordner Dokumente/.
Basis ist ohne Einstellung der Ordner „Fahrzeuge“ unter _ODIN (wie Projekte und Besprechungen); mit der Einstellung
„rechtsfaelle_ordner“ ein eigener, zugriffsbeschränkter Ordner. Rechtsfälle enthalten personenbezogene Daten – sie
gehören nicht in eine Wissensdatenbank, auf die alle Agents zugreifen.

Eine Akte sehen nur Beteiligte: wer sie angelegt hat und die eingetragenen Bearbeiter. Wie bei den Projekten regelt
das bis zu einer Rechteverwaltung nur die Oberfläche – wer den Ordner öffnen kann, kann die Dateien lesen. Deshalb der
eigene Ordner, den nur Berechtigte sehen.

Vor jeder Änderung wird akte.json frisch gelesen und über eine Zwischendatei geschrieben; Dateien werden erst kopiert
und dann eingetragen. Gelöschte Dokumente und Akten wandern in einen Ordner „_entfernt“ bzw. „_Papierkorb“ – endgültig
löscht nur ein Mensch von Hand.
"""

import base64
import calendar
import datetime as dt
import hashlib
import io
import json
import os
import re
import secrets
import shutil

from . import rechtsfaelle_inhalte as W
from .mails import MAIL_ENDUNGEN, lies_mail_inhalt
from .projekte import ProjektFehler

ROLLEN = {"wir_fordern": "Wir fordern", "gegen_uns": "Gegen uns"}
GEGENSEITE_ARTEN = {"": "nicht eingeordnet", "verbraucher": "Verbraucher", "unternehmer": "Unternehmer"}
PHASEN = dict(W.PHASEN)
FRIST_ARTEN = {"notfrist": "Notfrist", "gesetzlich": "Gesetzliche Frist", "gegenseite": "Von der Gegenseite gesetzt",
               "wiedervorlage": "Eigene Wiedervorlage"}
VORFRIST = {"notfrist": 7, "gesetzlich": 7, "gegenseite": 3, "wiedervorlage": 0}     # Tage vorher erinnern
EREIGNIS_ARTEN = {"mail_ein": "Mail eingegangen", "mail_aus": "Mail gesendet", "brief_ein": "Brief eingegangen",
                  "brief_aus": "Brief gesendet", "telefonat": "Telefonat", "termin": "Termin", "zahlung": "Zahlung",
                  "notiz": "Notiz"}
DOKUMENT_ARTEN = {"vertrag": "Vertrag", "rechnung": "Rechnung", "foto": "Foto", "protokoll": "Protokoll", "mail": "Mail",
                  "gutachten": "Gutachten", "schriftsatz": "Schriftsatz", "sonstiges": "Sonstiges"}
BEWEISLAST = {"wir": "Wir", "gegenseite": "Gegenseite", "unklar": "Unklar – prüfen"}
BEHAUPTET = {"wir": "Wir", "gegenseite": "Gegenseite"}
BELEG_STATUS = {"offen": "noch offen", "streitig": "streitig", "unstreitig": "unstreitig"}

BILD_ENDUNGEN = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif"}
VORSCHAU_ENDUNGEN = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff"}
# Was „öffnen“ zusätzlich zu den sonstigen ODIN-Dateien an das Betriebssystem geben darf (keine Programme, keine
# Dateien mit Makros)
OEFFNEN_ZUSATZ = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif", ".docx", ".odt",
                  ".rtf", ".ods", ".pptx", ".mp4", ".mov", ".m4a", ".mp3", ".wav", ".md"}

AZ_MUSTER = re.compile(r"RF-(\d{4})-(\d{3,5})")
ID_MUSTER = re.compile(r"[0-9a-f]{6,32}")
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
ZEIT = re.compile(r"\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?")
UNERLAUBT = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
UNSICHTBAR = re.compile(r"[\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]")   # Steuer-/Richtungszeichen
HOCHZIFFERN = str.maketrans("¹²³", "123")
AUSFUEHRBAR = {".exe", ".scr", ".com", ".bat", ".cmd", ".pif", ".msi", ".msp", ".hta", ".js", ".jse", ".vbs", ".vbe",
               ".wsf", ".wsh", ".ps1", ".psm1", ".lnk", ".url", ".reg", ".jar", ".cpl", ".dll", ".scf", ".inf", ".ini",
               ".chm", ".iso", ".img", ".vhd", ".appx", ".msix", ".docm", ".xlsm", ".pptm", ".dotm", ".xlam", ".svg",
               ".html", ".htm", ".mht", ".mhtml", ".xht", ".xhtml", ".application", ".gadget", ".library-ms",
               ".settingcontent-ms", ".search-ms", ".website", ".py", ".pyw", ".sh", ".command", ".app"}
RESERVIERT = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
AKTE = "akte.json"
DOKUMENTE = "Dokumente"
ENTFERNT = "_entfernt"
PAPIERKORB = "_Papierkorb"
DATEI_MAX = 300 * 1024 * 1024
EREIGNIS_TEXT_MAX = 20000
GRENZEN = {"fristen": 200, "ereignisse": 1000, "dokumente": 2000, "belege": 300}
BALD_TAGE = 7


class RechtsfallFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- kleine Helfer

def _neue_id(laenge: int = 10) -> str:
    return secrets.token_hex(laenge // 2)


def _text(wert, laenge: int) -> str:
    return " ".join(str(wert or "").split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    return str(wert or "").replace("\r\n", "\n").strip()[:laenge]


def _gueltig(text) -> bool:
    if not isinstance(text, str) or not ISO_DATUM.fullmatch(text[:10]):
        return False
    try:
        dt.date.fromisoformat(text[:10])
    except ValueError:
        return False
    return True


def _datum(wert, pflicht: bool = False, was: str = "ein Datum"):
    if wert in (None, ""):
        if pflicht:
            raise RechtsfallFehler(f"Bitte {was} wählen.")
        return None
    text = str(wert).strip()[:10]
    if not ISO_DATUM.fullmatch(text):
        raise RechtsfallFehler(f"Bitte {was} wählen.")
    if not _gueltig(text):
        raise RechtsfallFehler("Dieses Datum gibt es nicht.")
    return text


def _zeitpunkt(wert, pflicht: bool = True) -> str:
    """„2026-11-20“ oder „2026-11-20T09:30“ (Uhrzeit optional)."""
    text = str(wert or "").strip()[:16].replace(" ", "T")
    if not text:
        if pflicht:
            raise RechtsfallFehler("Bitte ein Datum wählen.")
        return ""
    if not ZEIT.fullmatch(text) or not _gueltig(text):
        raise RechtsfallFehler("Bitte ein gültiges Datum (und gegebenenfalls eine Uhrzeit) angeben.")
    if len(text) == 16:
        stunde, minute = int(text[11:13]), int(text[14:16])
        if stunde > 23 or minute > 59:
            raise RechtsfallFehler("Diese Uhrzeit gibt es nicht.")
    return text


def _deutsch(iso) -> str:
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if _gueltig(iso) else ""


def _betrag(wert):
    """„12.500,00“, „12500“, 12500.5 → 12500.5; leer → None."""
    if wert in (None, ""):
        return None
    if isinstance(wert, bool):
        raise RechtsfallFehler("Bitte einen Betrag in Euro angeben.")
    if isinstance(wert, (int, float)):
        zahl = float(wert)
    else:
        text = str(wert).replace("€", "").replace("EUR", "").replace(" ", "").strip()
        if "," in text:
            text = text.replace(".", "").replace(",", ".")
        elif text.count(".") > 1 or re.fullmatch(r"\d{1,3}\.\d{3}", text):
            text = text.replace(".", "")
        try:
            zahl = float(text)
        except ValueError:
            raise RechtsfallFehler("Bitte einen Betrag in Euro angeben, z. B. 12.500,00.") from None
    if not 0 <= zahl < 1e10:
        raise RechtsfallFehler("Der Betrag ist nicht plausibel.")
    return round(zahl, 2)


def euro(wert) -> str:
    if wert is None:
        return ""
    ganz, rest = f"{wert:,.2f}".split(".")
    return f"{ganz.replace(',', '.')},{rest} EUR"


def _ganze_zahl(wert, von: int, bis: int, standard: int) -> int:
    if wert in (None, ""):
        return standard
    try:
        zahl = int(wert)
    except (TypeError, ValueError):
        raise RechtsfallFehler("Bitte eine ganze Zahl angeben.") from None
    if not von <= zahl <= bis:
        raise RechtsfallFehler(f"Bitte eine Zahl zwischen {von} und {bis}.")
    return zahl


def _ja(wert) -> bool:
    if isinstance(wert, str):
        return wert.strip().lower() in ("true", "1", "ja", "erledigt")
    return bool(wert)


def _eintrag(liste: list, eid: str, meldung: str) -> dict:
    x = next((e for e in liste if e.get("id") == eid), None)
    if not x:
        raise RechtsfallFehler(meldung)
    return x


def plus(datum: dt.date, anzahl: int, einheit: str) -> dt.date:
    """Datum + n Tage/Wochen/Monate/Jahre. Monate und Jahre: gleicher Tag, sonst Monatsletzter (wie § 188 Abs. 3 BGB)."""
    if einheit == "tage":
        return datum + dt.timedelta(days=anzahl)
    if einheit == "wochen":
        return datum + dt.timedelta(weeks=anzahl)
    monate = anzahl * (12 if einheit == "jahre" else 1)
    if einheit not in ("monate", "jahre"):
        raise RechtsfallFehler("Unbekannte Einheit – Tage, Wochen, Monate oder Jahre.")
    index = datum.month - 1 + monate
    jahr, monat = datum.year + index // 12, index % 12 + 1
    return dt.date(jahr, monat, min(datum.day, calendar.monthrange(jahr, monat)[1]))


def _lies(pfad: str):
    from .speicher import lies_json
    try:
        return lies_json(pfad)
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as e:
        raise RechtsfallFehler(f"„{os.path.basename(os.path.dirname(pfad))}“ ist gerade nicht lesbar ({e}). "
                               "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise RechtsfallFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner erreichbar?") from None


def sicherer_dateiname(name: str) -> str:
    """Dateiname aus Mail oder Dialog: ohne Pfad und ohne Zeichen, die Windows nicht erlaubt."""
    name = UNSICHTBAR.sub("", os.path.basename(str(name or "").replace("\\", "/")))
    name = UNERLAUBT.sub("_", name).strip(" .")
    stamm, endung = os.path.splitext(name)
    if stamm.split(".")[0].strip().upper().translate(HOCHZIFFERN) in RESERVIERT:     # auch „con.tar.gz“, „COM¹“
        stamm = "_" + stamm
    stamm = stamm[:140].strip(" .") or "Datei"
    while len(stamm.encode("utf-8")) > 180:              # Dateisysteme zählen Bytes, nicht Zeichen
        stamm = stamm[:-1]
    endung = endung[:12]
    if endung.lower() in AUSFUEHRBAR:                    # nie etwas ablegen, das ein Doppelklick startet
        endung += ".blockiert"
    return stamm + endung


def _datei_anlegen(ordner: str, name: str):
    """Neue Datei unter freiem Namen anlegen (nie überschreiben) – gibt (Name, offene Datei) zurück."""
    os.makedirs(ordner, exist_ok=True)
    stamm, endung = os.path.splitext(sicherer_dateiname(name))
    for i in range(1, 1000):
        kandidat = f"{stamm}{endung}" if i == 1 else f"{stamm} ({i}){endung}"
        try:
            return kandidat, open(os.path.join(ordner, kandidat), "xb")
        except FileExistsError:
            continue
    raise RechtsfallFehler(f"Für „{name}“ ist kein freier Dateiname zu finden.")


def _sha256_datei(pfad: str) -> str:
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _art_raten(name: str) -> str:
    n = name.lower()
    endung = os.path.splitext(n)[1]
    if endung in MAIL_ENDUNGEN:
        return "mail"
    if endung in BILD_ENDUNGEN:
        return "foto"
    for wort, art in (("rechnung", "rechnung"), ("invoice", "rechnung"), ("gutschrift", "rechnung"),
                      ("vertrag", "vertrag"), ("auftrag", "vertrag"), ("bestellung", "vertrag"),
                      ("protokoll", "protokoll"), ("gutachten", "gutachten"), ("klage", "schriftsatz"),
                      ("schriftsatz", "schriftsatz"), ("mahnbescheid", "schriftsatz"), ("abmahnung", "schriftsatz")):
        if wort in n:
            return art
    return "sonstiges"


def _groesse_text(byte: int) -> str:
    if byte < 1024:
        return f"{byte} B"
    if byte < 1024 * 1024:
        return f"{byte / 1024:.0f} KB"
    return f"{byte / 1024 / 1024:.1f} MB".replace(".", ",")


def _eigene_adresse(absender: str) -> bool:
    """Mail von uns? (Adresse mit „muster“ in der Domain)"""
    return bool(re.search(r"@[^\s>]*muster", absender or "", re.IGNORECASE))


def _md(text) -> str:
    """Text für eine Markdown-Tabellenzelle."""
    return " ".join(str(text or "").split()).replace("|", "\\|") or "–"


# ---------------------------------------------------------------- Grundform einer Akte

def _normal(a, az: str):
    if not isinstance(a, dict) or not ID_MUSTER.fullmatch(str(a.get("id") or "")):
        return None
    a["aktenzeichen"] = az
    if a.get("falltyp") not in W.FALLTYPEN:
        a["falltyp"] = "sonstiges"
    if a.get("rolle") not in ROLLEN:
        a["rolle"] = "gegen_uns"
    if a.get("phase") not in PHASEN:
        a["phase"] = "eingang"
    for k in ("fristen", "ereignisse", "dokumente", "belege", "bearbeiter", "phasen_verlauf"):
        if not isinstance(a.get(k), list):
            a[k] = []
    for k in ("fristen", "ereignisse", "dokumente", "belege"):
        a[k] = [x for x in a[k] if isinstance(x, dict) and x.get("id")]
    a["bearbeiter"] = [b for b in a["bearbeiter"] if isinstance(b, str)]
    for k, felder in (("fristen", ("titel", "datum")), ("ereignisse", ("titel", "datum")),
                      ("belege", ("behauptung",)), ("dokumente", ("name",))):
        for x in a[k]:                                  # Pflichttexte: fehlen sie (von Hand bearbeitet), dann leer
            for feld in felder:
                if not isinstance(x.get(feld), str):
                    x[feld] = ""
    for k in ("gegenseite", "bezug", "checkliste"):
        if not isinstance(a.get(k), dict):
            a[k] = {}
    if a["gegenseite"].get("art") not in GEGENSEITE_ARTEN:
        a["gegenseite"]["art"] = ""
    a["titel"] = str(a.get("titel") or "Rechtsfall")
    for k in ("notizen", "sachverhalt", "ziel", "offene_fragen", "anwalt_extern", "erstellt_am"):
        a[k] = str(a.get(k) or "")
    if not isinstance(a.get("streitwert"), (int, float)) or isinstance(a.get("streitwert"), bool):
        a["streitwert"] = None
    if not _gueltig(a.get("aufbewahren_bis")):
        a["aufbewahren_bis"] = None
    return a


# ---------------------------------------------------------------- Rechtsfälle

class Rechtsfaelle:
    """Rechtsfälle. Personen und „ich“ kommen aus `projekte`; `ordner()` liefert den eingestellten eigenen Ordner
    (leer = Standard im Ordner „Fahrzeuge“); `jetzt` (für Tests) liefert die Uhrzeit."""

    def __init__(self, projekte, ordner=None, jetzt=None):
        self._projekte = projekte
        self._ordner = ordner or (lambda: "")
        self._jetzt = jetzt or dt.datetime.now
        self._vorschauen = {}

    # ---------------- Orte und Zeit ----------------
    def _basis(self):
        """(Ordner, {eigener, lokal}) – ein eingestellter, aber nicht erreichbarer Ordner ist ein Fehler: dann nie still
        in den gemeinsamen Ordner ausweichen."""
        eigen = str(self._ordner() or "").strip()
        if eigen:
            if not os.path.isdir(eigen):
                raise RechtsfallFehler(f"Der eingestellte Ordner für Rechtsfälle ist nicht erreichbar ({eigen}). Ist das "
                                       "Laufwerk verbunden? Unter „Ablageort“ lässt er sich ändern.")
            return eigen, {"eigener": True, "lokal": False}
        basis, lokal = self._projekte._basis()
        return basis, {"eigener": False, "lokal": lokal}

    def _wurzel(self) -> str:
        return os.path.join(self._basis()[0], "Rechtsfaelle")

    def _fallordner(self, az: str) -> str:
        if not AZ_MUSTER.fullmatch(str(az or "")):
            raise RechtsfallFehler("Unbekanntes Aktenzeichen.")
        return os.path.join(self._wurzel(), az)

    def _heute(self) -> dt.date:
        return self._jetzt().date()

    def _zeit(self) -> str:
        return self._jetzt().isoformat(timespec="seconds")

    def ablage(self) -> dict:
        try:
            basis, art = self._basis()
        except RechtsfallFehler as e:
            return {"ordner": str(self._ordner() or ""), "eigener": True, "lokal": False, "fehler": str(e)}
        return {"ordner": os.path.join(basis, "Rechtsfaelle"), **art, "fehler": ""}

    @staticmethod
    def ablage_pruefen(ordner: str):
        """Taugt der Ordner als eigener Ablageort? Muss existieren und beschreibbar sein."""
        if not ordner or not os.path.isdir(ordner):
            raise RechtsfallFehler("Diesen Ordner gibt es nicht.")
        probe = os.path.join(ordner, f".odin-probe-{secrets.token_hex(3)}")
        try:
            with open(probe, "w", encoding="utf-8") as f:
                f.write("ok")
            os.remove(probe)
        except OSError as e:
            raise RechtsfallFehler(f"In diesen Ordner kann ODIN nicht schreiben ({e}).") from None

    # ---------------- Personen und Rechte ----------------
    @staticmethod
    def _p(funktion, *argumente):
        try:
            return funktion(*argumente)
        except ProjektFehler as e:
            raise RechtsfallFehler(str(e)) from None

    def _personen(self) -> dict:
        return {p["id"]: p for p in self._p(self._projekte.personen)}

    def _ich(self) -> str:
        return self._p(self._projekte.ich)

    def _ich_pflicht(self) -> str:
        ich = self._ich()
        if not ich:
            raise RechtsfallFehler("Bitte zuerst auswählen, wer du bist.")
        return ich

    @staticmethod
    def _darf_sehen(a: dict, ich: str) -> bool:
        return bool(ich) and (ich == a.get("erstellt_von") or ich in (a.get("bearbeiter") or []))

    # ---------------- Lesen ----------------
    def _alle(self) -> list:
        """Alle lesbaren Akten. Eine kaputte oder gerade gesperrte Datei hält die Übersicht nicht auf."""
        wurzel = self._wurzel()
        try:
            namen = sorted(n for n in os.listdir(wurzel) if AZ_MUSTER.fullmatch(n))
        except OSError:
            return []
        akten = []
        for az in namen:
            try:
                a = _normal(_lies(os.path.join(wurzel, az, AKTE)), az)
            except RechtsfallFehler:
                continue
            if a:
                akten.append(a)
        return akten

    def _lesen(self, az: str, ich: str) -> dict:
        a = _normal(_lies(os.path.join(self._fallordner(az), AKTE)), az)
        if not a:
            raise RechtsfallFehler("Diese Akte gibt es nicht (mehr) – vielleicht auf einem anderen Rechner gelöscht.")
        if not self._darf_sehen(a, ich):
            raise RechtsfallFehler("Diese Akte sehen nur Beteiligte: wer sie angelegt hat und die eingetragenen Bearbeiter.")
        return a

    def _aendere(self, az: str, aenderung) -> dict:
        """Frisch lesen, ändern, speichern – Änderungen anderer Rechner an anderen Stellen bleiben erhalten."""
        ich = self._ich_pflicht()
        a = self._lesen(az, ich)
        aenderung(a, ich)
        a["geaendert_am"] = self._zeit()
        _schreibe(os.path.join(self._fallordner(az), AKTE), a)
        return self._ansicht(a, ich)

    # ---------------- Fristen und Schritte berechnen ----------------
    def _frist_stand(self, f: dict) -> dict:
        heute = self._heute()
        tage = (dt.date.fromisoformat(f["datum"]) - heute).days if _gueltig(f.get("datum")) else None
        vorfrist = f.get("vorfrist_tage") if isinstance(f.get("vorfrist_tage"), int) else VORFRIST.get(f.get("art"), 0)
        if f.get("erledigt"):
            zustand = "erledigt"
        elif tage is None:
            zustand = "offen"
        elif tage < 0:
            zustand = "ueberfaellig"
        elif tage == 0:
            zustand = "heute"
        elif tage <= max(vorfrist, 0):
            zustand = "vorfrist"
        elif tage <= BALD_TAGE:
            zustand = "bald"
        else:
            zustand = "offen"
        vorfrist_ab = (dt.date.fromisoformat(f["datum"]) - dt.timedelta(days=vorfrist)).isoformat() \
            if tage is not None and vorfrist else None
        return {**f, "art_name": FRIST_ARTEN.get(f.get("art"), "Frist"), "tage": tage, "zustand": zustand,
                "vorfrist_tage": vorfrist, "vorfrist_ab": vorfrist_ab,
                "bald": not f.get("erledigt") and tage is not None and tage <= BALD_TAGE,
                "pruefen": bool(f.get("berechnung")) and not f.get("geprueft")}

    def _fristen(self, a: dict) -> list:
        return sorted((self._frist_stand(f) for f in a["fristen"]),
                      key=lambda f: (bool(f.get("erledigt")), f.get("datum") or "9999"))

    # Schritte, die sich an den Angaben der Akte ablesen lassen – sie gelten ohne Abhaken als erledigt
    AUTOMATISCH = {
        "r-uebergabe": lambda a: _gueltig((a["bezug"] or {}).get("uebergabe")),
        "e-gegenseite": lambda a: bool(a["gegenseite"].get("art")),
        "p-belege": lambda a: bool(a["belege"]),
        "v-ziel": lambda a: bool(a["ziel"].strip()),
        "g-anwalt": lambda a: bool(a["anwalt_extern"].strip()),
        "z-aufbewahrung": lambda a: bool(a["aufbewahren_bis"]),
    }

    def _schritte(self, a: dict) -> list:
        erledigt = a["checkliste"]
        liste = []
        for s in W.schritte(a["falltyp"], a["rolle"]):
            automatisch = bool(self.AUTOMATISCH.get(s["id"], lambda a: False)(a))
            liste.append({**s, "phase_name": PHASEN[s["phase"]], "automatisch": automatisch,
                          "erledigt": automatisch or bool((erledigt.get(s["id"]) or {}).get("erledigt")),
                          "erledigt_von": (erledigt.get(s["id"]) or {}).get("von")})
        return liste

    @staticmethod
    def _naechster_schritt(a: dict, schritte: list):
        reihenfolge = [p for p, _ in W.PHASEN]
        ab = reihenfolge.index(a["phase"])
        for phase in reihenfolge[ab:]:
            offen = [s for s in schritte if s["phase"] == phase and not s["erledigt"]]
            if offen:
                return {**offen[0], "offen_in_phase": len(offen), "andere_phase": phase != a["phase"]}
        return None

    def _belege(self, a: dict) -> list:
        namen = {d["id"]: d.get("name") or d.get("datei") for d in a["dokumente"]}
        liste = []
        for b in a["belege"]:
            belege = [d for d in b.get("belege") or [] if d in namen]
            luecke = (b.get("status") != "unstreitig" and b.get("beweislast") in ("wir", "unklar")
                      and not belege and not str(b.get("weitere") or "").strip())
            liste.append({**b, "belege": belege, "beleg_namen": [namen[d] for d in belege], "luecke": luecke,
                          "beweislast_name": BEWEISLAST.get(b.get("beweislast"), "–"),
                          "von_name": BEHAUPTET.get(b.get("von"), "–"),
                          "status_name": BELEG_STATUS.get(b.get("status"), "noch offen")})
        return liste

    def _erster_kontakt(self, a: dict):
        """Datum des frühesten Ereignisses (ungefähr: Eingang der Reklamation) – sonst Anlage der Akte."""
        daten = sorted(e["datum"][:10] for e in a["ereignisse"] if _gueltig(e.get("datum")))
        return daten[0] if daten else (a["erstellt_am"][:10] if _gueltig(a["erstellt_am"]) else self._heute().isoformat())

    def _hinweise(self, a: dict, fristen: list, belege: list) -> list:
        """Regelbasierte Hinweise aus den Daten der Akte – jeweils mit Quelle."""
        h = []
        offen = [f for f in fristen if not f.get("erledigt")]
        for f in offen:
            if f["zustand"] == "ueberfaellig":
                h.append({"ton": "krit", "text": f"Frist überfällig seit {_deutsch(f['datum'])}: {f['titel']}.",
                          "quelle": "workflow-fristen-ruecktritt-kuendigung"})
            elif f["bald"]:
                wann = "heute" if f["tage"] == 0 else "morgen" if f["tage"] == 1 else f"in {f['tage']} Tagen"
                h.append({"ton": "krit" if f.get("art") == "notfrist" else "warn",
                          "text": f"Frist {wann} ({_deutsch(f['datum'])}): {f['titel']}.",
                          "quelle": "workflow-fristen-ruecktritt-kuendigung"})
            if f["pruefen"]:
                h.append({"ton": "warn", "text": f"Berechnete Frist noch nicht geprüft: {f['titel']} ({f['berechnung']}).",
                          "quelle": "workflow-fristen-ruecktritt-kuendigung"})
        if not offen and a["phase"] != "erledigt":
            h.append({"ton": "info", "text": "Keine offene Frist eingetragen – mindestens eine Wiedervorlage setzen.",
                      "quelle": "schadenfall-aufnehmen"})
        g = a["gegenseite"]
        if a["rolle"] == "gegen_uns" and str(g.get("anwalt") or "").strip() and not a["anwalt_extern"].strip():
            h.append({"ton": "warn", "text": "Die Gegenseite hat einen Anwalt: Frist herausstellen und vor der Antwort "
                                             "einen eigenen Anwalt einbinden.", "quelle": "muster-recht-einstieg"})
        if a["phase"] == "gerichtlich" and not a["anwalt_extern"].strip():
            h.append({"ton": "warn", "text": "Gerichtliches Verfahren ohne eingetragenen Anwalt.",
                      "quelle": "muster-recht-einstieg"})
        luecken = sum(1 for b in belege if b["luecke"])
        if luecken:
            h.append({"ton": "warn", "text": f"{luecken} Behauptung{'en' if luecken != 1 else ''}, die wir beweisen "
                                             f"müssen, {'haben' if luecken != 1 else 'hat'} noch keinen Beleg.",
                      "quelle": "workflow-beweislast-und-belegmatrix"})
        if not g.get("art") and a["falltyp"] in ("reklamation", "werkstatt", "forderung", "lieferant", "finanzierung"):
            h.append({"ton": "info", "text": "Gegenseite noch nicht eingeordnet: Verbraucher oder Unternehmer? Davon "
                                             "hängen Beweislast, Zinsen und Fristen ab.", "quelle": "muster-recht-einstieg"})
        uebergabe = (a["bezug"] or {}).get("uebergabe")
        if a["falltyp"] == "reklamation" and _gueltig(uebergabe):
            u = dt.date.fromisoformat(uebergabe)
            kontakt = dt.date.fromisoformat(self._erster_kontakt(a))
            if g.get("art") == "verbraucher":
                if kontakt < plus(u, 1, "jahre"):
                    h.append({"ton": "info", "text": f"Gemeldet am {_deutsch(kontakt.isoformat())}, weniger als ein Jahr "
                              "nach Übergabe: Beim Verbrauchsgüterkauf wird vermutet, dass der Mangel schon bei Übergabe "
                              "da war (§ 477 BGB). Maßgeblich ist, wann er sich gezeigt hat – bitte prüfen.",
                              "quelle": "kaufrecht-sachmangel-paragraph-434"})
                else:
                    h.append({"ton": "info", "text": "Mehr als ein Jahr nach Übergabe gemeldet: keine Vermutung nach "
                              "§ 477 BGB – der Kunde muss den Mangel bei Übergabe beweisen. Bitte prüfen, wann er sich "
                              "zuerst gezeigt hat.", "quelle": "kaufrecht-sachmangel-paragraph-434"})
            elif g.get("art") == "unternehmer":
                h.append({"ton": "info", "text": "Käufer ist Unternehmer: keine Beweislastumkehr nach § 477 BGB; beim "
                          "beiderseitigen Handelskauf gilt die Rügeobliegenheit (§ 377 HGB).",
                          "quelle": "kaufrecht-sachmangel-paragraph-434"})
            if plus(u, 2, "jahre") <= self._heute() + dt.timedelta(days=60):
                h.append({"ton": "warn", "text": "Zwei Jahre seit Übergabe sind (fast) erreicht: Verjährung prüfen "
                          "(§ 438 BGB, bei Gebrauchten gegebenenfalls kürzer).", "quelle": "kaufrecht-sachmangel-paragraph-434"})
        if a["phase"] == "erledigt" and not a["aufbewahren_bis"]:
            h.append({"ton": "info", "text": "„Aufbewahrung bis“ eintragen – danach die Akte löschen.",
                      "quelle": "datenschutz-auskunftsersuchen-art-15-praxis"})
        if a["aufbewahren_bis"] and a["aufbewahren_bis"] < self._heute().isoformat():
            h.append({"ton": "warn", "text": "Aufbewahrungsfrist abgelaufen – Akte prüfen und löschen.",
                      "quelle": "datenschutz-auskunftsersuchen-art-15-praxis"})
        return h

    def _entwuerfe_liste(self, a: dict) -> list:
        return [{"id": e["id"], "titel": e["titel"], "quelle": e["quelle"]} for e in W.ENTWUERFE
                if (e["falltypen"] is None or a["falltyp"] in e["falltypen"]) and (e["rolle"] in (None, a["rolle"]))]

    # ---------------- Ansichten ----------------
    def _zusammenfassung(self, a: dict) -> dict:
        offen = [f for f in self._fristen(a) if not f.get("erledigt")]
        erledigt = a["phase"] == "erledigt"
        return {"aktenzeichen": a["aktenzeichen"], "id": a["id"], "titel": a["titel"], "falltyp": a["falltyp"],
                "falltyp_name": W.FALLTYPEN[a["falltyp"]]["kurz"], "rolle": a["rolle"], "rolle_name": ROLLEN[a["rolle"]],
                "gegenseite": a["gegenseite"].get("name", ""), "phase": a["phase"], "phase_name": PHASEN[a["phase"]],
                "streitwert": a["streitwert"], "erledigt": erledigt, "bearbeiter": a["bearbeiter"],
                "erstellt_von": a.get("erstellt_von"), "geaendert_am": a.get("geaendert_am") or a["erstellt_am"],
                "fahrzeug": (a["bezug"] or {}).get("fahrzeug", ""), "kunde": (a["bezug"] or {}).get("kunde", ""),
                "naechste_frist": offen[0] if offen else None,
                "fristen_bald": 0 if erledigt else sum(1 for f in offen if f["bald"]),
                "dokumente": len(a["dokumente"]), "ereignisse": len(a["ereignisse"])}

    def _ansicht(self, a: dict, ich: str) -> dict:
        fristen = self._fristen(a)
        schritte = self._schritte(a)
        belege = self._belege(a)
        dokumente = []
        for d in sorted(a["dokumente"], key=lambda d: (d.get("datum") or "", d.get("hinzugefuegt_am") or "")):
            endung = os.path.splitext(d.get("datei") or "")[1].lower()
            dokumente.append({**d, "art_name": DOKUMENT_ARTEN.get(d.get("art"), "Sonstiges"), "endung": endung,
                              "bild": endung in VORSCHAU_ENDUNGEN, "groesse_text": _groesse_text(d.get("groesse") or 0)})
        ereignisse = [{**e, "art_name": EREIGNIS_ARTEN.get(e.get("art"), "Notiz")}
                      for e in sorted(a["ereignisse"], key=lambda e: (e.get("datum") or "", e.get("am") or ""))]
        typ = W.FALLTYPEN[a["falltyp"]]
        return {**a, "fristen": fristen, "dokumente": dokumente, "ereignisse": ereignisse, "belege": belege,
                "falltyp_name": typ["name"], "rolle_name": ROLLEN[a["rolle"]], "phase_name": PHASEN[a["phase"]],
                "schritte": schritte, "naechster_schritt": self._naechster_schritt(a, schritte),
                "hinweise": self._hinweise(a, fristen, belege), "entwuerfe": self._entwuerfe_liste(a),
                "rechenhilfen": W.rechenhilfen(a["falltyp"], a["rolle"]),
                "skills": typ["skills"], "skills_allgemein": W.SKILLS_ALLGEMEIN, "hinweis_recht": W.HINWEIS_RECHT,
                "darf_loeschen": ich == a.get("erstellt_von"),
                "zahlen": {"fristen_offen": sum(1 for f in fristen if not f.get("erledigt")),
                           "fristen_bald": sum(1 for f in fristen if f["bald"]), "dokumente": len(dokumente),
                           "ereignisse": len(ereignisse), "belege": len(belege),
                           "luecken": sum(1 for b in belege if b["luecke"]),
                           "schritte_offen": sum(1 for s in schritte if s["phase"] == a["phase"] and not s["erledigt"])}}

    def start(self) -> dict:
        ich = self._ich()
        ablage = self.ablage()
        faelle = []
        if ich and not ablage["fehler"]:
            faelle = self.liste()
        return {"ich": ich, "personen": list(self._personen().values()), "faelle": faelle,
                "falltypen": [{"id": k, **v} for k, v in W.FALLTYPEN.items()],
                "rollen": [{"id": k, "name": v} for k, v in ROLLEN.items()],
                "phasen": [{"id": k, "name": v} for k, v in W.PHASEN],
                "frist_arten": [{"id": k, "name": v, "vorfrist": VORFRIST[k]} for k, v in FRIST_ARTEN.items()],
                "ereignis_arten": [{"id": k, "name": v} for k, v in EREIGNIS_ARTEN.items()],
                "dokument_arten": [{"id": k, "name": v} for k, v in DOKUMENT_ARTEN.items()],
                "beweislast": [{"id": k, "name": v} for k, v in BEWEISLAST.items()],
                "beleg_status": [{"id": k, "name": v} for k, v in BELEG_STATUS.items()],
                "gegenseite_arten": [{"id": k, "name": v} for k, v in GEGENSEITE_ARTEN.items()],
                "heute": self._heute().isoformat(), "ablage": ablage, "hinweis_recht": W.HINWEIS_RECHT}

    def liste(self) -> list:
        """Sichtbare Fälle (ohne Inhalt): offene vor erledigten, darin die nächste Frist zuerst."""
        ich = self._ich()
        liste = [self._zusammenfassung(a) for a in self._alle() if self._darf_sehen(a, ich)]
        liste.sort(key=lambda z: (z["erledigt"], (z["naechste_frist"] or {}).get("datum") or "9999",
                                  z["aktenzeichen"]))
        return liste

    def akte(self, az: str) -> dict:
        ich = self._ich_pflicht()
        return self._ansicht(self._lesen(az, ich), ich)

    # ---------------- Anlegen, ändern, löschen ----------------
    def _neues_aktenzeichen(self, wurzel: str) -> str:
        """RF-<Jahr>-<laufende Nummer>; auch Nummern im Papierkorb bleiben vergeben. Den Ordner legt mkdir an – zwei
        gleichzeitige Anlagen auf diesem Rechner bekommen so nie dieselbe Nummer."""
        jahr = self._jetzt().year
        hoechste = 0
        for ort in (wurzel, os.path.join(wurzel, PAPIERKORB)):
            try:
                namen = os.listdir(ort)
            except OSError:
                continue
            for n in namen:
                m = re.match(r"RF-(\d{4})-(\d{3,5})", n)
                if m and int(m.group(1)) == jahr:
                    hoechste = max(hoechste, int(m.group(2)))
        os.makedirs(wurzel, exist_ok=True)
        for nummer in range(hoechste + 1, hoechste + 100):
            az = f"RF-{jahr}-{nummer:03d}"
            try:
                os.mkdir(os.path.join(wurzel, az))
            except FileExistsError:
                continue
            return az
        raise RechtsfallFehler("Kein freies Aktenzeichen gefunden.")

    def _felder_setzen(self, a: dict, f: dict, personen: dict):
        """Gemeinsame Prüfung für Anlegen und Ändern."""
        if "titel" in f:
            titel = _text(f["titel"], 140)
            if not titel:
                raise RechtsfallFehler("Bitte den Fall kurz benennen.")
            a["titel"] = titel
        if "falltyp" in f:
            if f["falltyp"] not in W.FALLTYPEN:
                raise RechtsfallFehler("Unbekannter Falltyp.")
            a["falltyp"] = f["falltyp"]
        if "rolle" in f:
            if f["rolle"] not in ROLLEN:
                raise RechtsfallFehler("Unsere Rolle: „Wir fordern“ oder „Gegen uns“.")
            a["rolle"] = f["rolle"]
        if "gegenseite" in f:
            g = dict(a.get("gegenseite") or {})
            neu = f["gegenseite"] or {}
            for k, laenge in (("name", 140), ("anwalt", 200), ("kontakt", 300)):
                if k in neu:
                    g[k] = _text(neu[k], laenge)
            if "art" in neu:
                if neu["art"] not in GEGENSEITE_ARTEN:
                    raise RechtsfallFehler("Gegenseite: Verbraucher, Unternehmer oder offen.")
                g["art"] = neu["art"]
            a["gegenseite"] = g
        if "bezug" in f:
            b = dict(a.get("bezug") or {})
            neu = f["bezug"] or {}
            for k, laenge in (("fahrzeug", 60), ("kunde", 140)):
                if k in neu:
                    b[k] = _text(neu[k], laenge)
            if "uebergabe" in neu:
                b["uebergabe"] = _datum(neu["uebergabe"])
            a["bezug"] = b
        if "streitwert" in f:
            a["streitwert"] = _betrag(f["streitwert"])
        if "bearbeiter" in f:
            a["bearbeiter"] = [i for i in dict.fromkeys(f["bearbeiter"] or []) if i in personen]
        if "anwalt_extern" in f:
            a["anwalt_extern"] = _text(f["anwalt_extern"], 200)
        for k, laenge in (("notizen", 20000), ("sachverhalt", 20000), ("ziel", 4000), ("offene_fragen", 8000)):
            if k in f:
                a[k] = _langtext(f[k], laenge)
        if "aufbewahren_bis" in f:
            a["aufbewahren_bis"] = _datum(f["aufbewahren_bis"])

    def anlegen(self, eingabe: dict) -> dict:
        """Neue Akte mit Aktenzeichen RF-<Jahr>-<Nr>. Wer anlegt, ist ohne Angabe auch Bearbeiter."""
        ich = self._ich_pflicht()
        e = dict(eingabe or {})
        e.setdefault("titel", "")
        personen = self._personen()
        jetzt = self._zeit()
        a = {"version": 1, "id": _neue_id(12), "titel": "", "falltyp": "sonstiges", "rolle": "gegen_uns",
             "gegenseite": {"name": "", "anwalt": "", "kontakt": "", "art": ""},
             "bezug": {"fahrzeug": "", "kunde": "", "uebergabe": None}, "streitwert": None, "phase": "eingang",
             "phasen_verlauf": [{"phase": "eingang", "am": jetzt, "von": ich}], "bearbeiter": [ich],
             "anwalt_extern": "", "notizen": "", "sachverhalt": "", "ziel": "", "offene_fragen": "",
             "aufbewahren_bis": None, "fristen": [], "ereignisse": [], "dokumente": [], "belege": [], "checkliste": {},
             "erstellt_von": ich, "erstellt_am": jetzt, "geaendert_am": jetzt}
        if not e.get("bearbeiter"):
            e.pop("bearbeiter", None)
        self._felder_setzen(a, e, personen)
        if ich not in a["bearbeiter"]:
            a["bearbeiter"].insert(0, ich)
        wurzel = self._wurzel()
        az = self._neues_aktenzeichen(wurzel)
        a["aktenzeichen"] = az
        os.makedirs(os.path.join(wurzel, az, DOKUMENTE), exist_ok=True)
        _schreibe(os.path.join(wurzel, az, AKTE), a)
        return self._ansicht(_normal(a, az), ich)

    def aendern(self, az: str, felder: dict) -> dict:
        """Titel, Falltyp, Rolle, Gegenseite {name, anwalt, kontakt, art}, Bezug {fahrzeug, kunde, uebergabe},
        Streitwert, Bearbeiter, externer Anwalt, Notizen, Sachverhalt, Ziel, offene Fragen, Aufbewahrung bis, Phase."""
        f = dict(felder or {})
        personen = self._personen()

        def aendern(a, ich):
            self._felder_setzen(a, f, personen)
            if "bearbeiter" in f and ich != a.get("erstellt_von") and ich not in a["bearbeiter"]:
                raise RechtsfallFehler("Selbst austragen geht nicht – danach könntest du die Akte nicht mehr sehen. Das "
                                       "kann nur, wer die Akte angelegt hat.")
            if "phase" in f:
                self._phase(a, f["phase"], ich)
        return self._aendere(az, aendern)

    def _phase(self, a: dict, phase: str, ich: str):
        if phase not in PHASEN:
            raise RechtsfallFehler("Unbekannte Phase.")
        if phase != a["phase"]:
            a["phase"] = phase
            a["phasen_verlauf"] = (a["phasen_verlauf"] + [{"phase": phase, "am": self._zeit(), "von": ich}])[-100:]

    def phase_setzen(self, az: str, phase: str) -> dict:
        return self._aendere(az, lambda a, ich: self._phase(a, phase, ich))

    def loeschen(self, az: str) -> dict:
        """Nur wer die Akte angelegt hat. Der Ordner wandert in „_Papierkorb“ – endgültig löscht ein Mensch."""
        ich = self._ich_pflicht()
        a = self._lesen(az, ich)
        if a.get("erstellt_von") != ich:
            raise RechtsfallFehler("Löschen darf nur, wer die Akte angelegt hat.")
        korb = os.path.join(self._wurzel(), PAPIERKORB)
        ziel = os.path.join(korb, f"{az} gelöscht {self._jetzt():%Y-%m-%d %H%M%S}")
        try:
            os.makedirs(korb, exist_ok=True)
            shutil.move(self._fallordner(az), ziel)
        except OSError as e:
            raise RechtsfallFehler(f"Löschen hat nicht geklappt ({e}). Ist eine Datei der Akte gerade geöffnet?") from None
        return {"ok": True, "papierkorb": ziel}

    # ---------------- Fristen ----------------
    def _frist_felder(self, x: dict, e: dict, neu: bool):
        if neu or "titel" in e:
            titel = _text(e.get("titel"), 200)
            if not titel:
                raise RechtsfallFehler("Bitte die Frist benennen, z. B. „Antwort an Anwalt Meyer“.")
            x["titel"] = titel
        if neu or "art" in e:
            art = e.get("art") or "wiedervorlage"
            if art not in FRIST_ARTEN:
                raise RechtsfallFehler("Unbekannte Art der Frist.")
            x["art"] = art
        if neu or "datum" in e:
            x["datum"] = _datum(e.get("datum"), pflicht=True, was="das Datum der Frist")
        if neu or "vorfrist_tage" in e:
            x["vorfrist_tage"] = _ganze_zahl(e.get("vorfrist_tage"), 0, 90, VORFRIST[x["art"]])
        if "notiz" in e:
            x["notiz"] = _langtext(e["notiz"], 2000)
        if "berechnung" in e:
            x["berechnung"] = _text(e["berechnung"], 300)
            x["geprueft"] = False
        if "geprueft" in e:
            x["geprueft"] = _ja(e["geprueft"])

    def frist_anlegen(self, az: str, eingabe: dict) -> dict:
        e = dict(eingabe or {})
        x = {"id": _neue_id(), "erledigt": False, "notiz": "", "berechnung": "", "geprueft": False}
        self._frist_felder(x, e, neu=True)

        def dazu(a, ich):
            if len(a["fristen"]) >= GRENZEN["fristen"]:
                raise RechtsfallFehler("Zu viele Fristen in dieser Akte.")
            a["fristen"].append({**x, "von": ich, "am": self._zeit()})
        return self._aendere(az, dazu)

    def frist_aendern(self, az: str, frist_id: str, felder: dict) -> dict:
        f = dict(felder or {})

        def aendern(a, ich):
            x = _eintrag(a["fristen"], frist_id, "Diese Frist gibt es nicht mehr.")
            self._frist_felder(x, f, neu=False)
            if "erledigt" in f:
                x["erledigt"] = _ja(f["erledigt"])
                x["erledigt_am"], x["erledigt_von"] = (self._zeit(), ich) if x["erledigt"] else (None, None)
        return self._aendere(az, aendern)

    def frist_loeschen(self, az: str, frist_id: str) -> dict:
        def weg(a, ich):
            _eintrag(a["fristen"], frist_id, "Diese Frist gibt es nicht mehr.")
            a["fristen"] = [x for x in a["fristen"] if x["id"] != frist_id]
        return self._aendere(az, weg)

    @staticmethod
    def frist_rechnen(von, anzahl, einheit: str) -> dict:
        """Rechenhilfe: Ausgangsdatum + n Tage/Wochen/Monate/Jahre – ausdrücklich zum Prüfen, nie „sicher“."""
        start = _datum(von, pflicht=True, was="das Ausgangsdatum")
        n = _ganze_zahl(anzahl, 1, 3650, 0)
        if einheit not in W.EINHEITEN:
            raise RechtsfallFehler("Einheit: Tage, Wochen, Monate oder Jahre.")
        ende = plus(dt.date.fromisoformat(start), n, einheit)
        wort = W.EINHEITEN[einheit][0 if n == 1 else 1]
        tag = ("Samstag", "Sonntag")[ende.weekday() - 5] if ende.weekday() >= 5 else ""
        return {"datum": ende.isoformat(), "text": f"{_deutsch(start)} + {n} {wort} = {_deutsch(ende.isoformat())}",
                "wochenende": tag, "hinweis": W.RECHEN_HINWEIS}

    # ---------------- Chronologie ----------------
    def _ereignis_felder(self, x: dict, e: dict, neu: bool, a: dict):
        if neu or "datum" in e:
            x["datum"] = _zeitpunkt(e.get("datum"))
        if neu or "art" in e:
            art = e.get("art") or "notiz"
            if art not in EREIGNIS_ARTEN:
                raise RechtsfallFehler("Unbekannte Art des Eintrags.")
            x["art"] = art
        if neu or "titel" in e:
            titel = _text(e.get("titel"), 200)
            if not titel:
                raise RechtsfallFehler("Bitte kurz sagen, was passiert ist.")
            x["titel"] = titel
        if "text" in e:
            x["text"] = _langtext(e["text"], EREIGNIS_TEXT_MAX)
        if "dokumente" in e:
            vorhanden = {d["id"] for d in a["dokumente"]}
            x["dokumente"] = [d for d in dict.fromkeys(e["dokumente"] or []) if d in vorhanden]

    def ereignis_anlegen(self, az: str, eingabe: dict) -> dict:
        e = dict(eingabe or {})

        def dazu(a, ich):
            if len(a["ereignisse"]) >= GRENZEN["ereignisse"]:
                raise RechtsfallFehler("Zu viele Einträge in der Chronologie.")
            x = {"id": _neue_id(), "text": "", "dokumente": []}
            self._ereignis_felder(x, e, True, a)
            a["ereignisse"].append({**x, "von": ich, "am": self._zeit()})
        return self._aendere(az, dazu)

    def ereignis_aendern(self, az: str, ereignis_id: str, felder: dict) -> dict:
        def aendern(a, ich):
            x = _eintrag(a["ereignisse"], ereignis_id, "Diesen Eintrag gibt es nicht mehr.")
            self._ereignis_felder(x, dict(felder or {}), False, a)
        return self._aendere(az, aendern)

    def ereignis_loeschen(self, az: str, ereignis_id: str) -> dict:
        """Nur der Eintrag – verknüpfte Dokumente bleiben in der Akte."""
        def weg(a, ich):
            _eintrag(a["ereignisse"], ereignis_id, "Diesen Eintrag gibt es nicht mehr.")
            a["ereignisse"] = [x for x in a["ereignisse"] if x["id"] != ereignis_id]
            for d in a["dokumente"]:
                if d.get("ereignis_id") == ereignis_id:
                    d["ereignis_id"] = None
        return self._aendere(az, weg)

    # ---------------- Dokumente ----------------
    def dokumente_importieren(self, az: str, pfade: list, vorgaben: dict = None) -> dict:
        """
        Dateien in den Fallordner kopieren (nie verschieben) und eintragen: SHA-256, Größe, Art (aus dem Namen
        geraten), Datum. Gespeicherte Mails (.msg/.eml) werden gelesen: Betreff, Absender, Datum und Text ergeben einen
        Eintrag in der Chronologie, jeder Anhang wird ein eigenes Dokument. Was es schon gibt (gleicher SHA-256), kommt
        nicht doppelt. 'pfade' stammen nur aus dem Dateidialog (app.py), nie aus der Oberfläche.
        """
        ich = self._ich_pflicht()
        self._lesen(az, ich)                                  # sichtbar? sonst gar nicht erst kopieren
        v = dict(vorgaben or {})
        if v.get("art") and v["art"] not in DOKUMENT_ARTEN:
            raise RechtsfallFehler("Unbekannte Art des Dokuments.")
        vorgabe_datum = _datum(v.get("datum"))
        ablage = os.path.join(self._fallordner(az), DOKUMENTE)
        aktuell = _normal(_lies(os.path.join(self._fallordner(az), AKTE)), az) or {"dokumente": [], "ereignisse": []}
        bekannt = {d.get("sha256"): d["id"] for d in aktuell["dokumente"] if d.get("sha256")}
        # Dieselbe Mail zweimal gespeichert ergibt oft andere Bytes – dann zählen Absender, Betreff und Zeitpunkt
        mails_bekannt = {(e.get("mail_von"), e.get("titel"), str(e.get("datum"))[:16])
                         for e in aktuell["ereignisse"] if e.get("quelle") == "mail"}
        neue_dok, neue_ereignisse = [], []
        bericht = {"dateien": 0, "mails": 0, "anhaenge": 0, "doppelt": [], "fehler": [], "kleinbilder": 0}
        jetzt = self._zeit()

        def eintrag(datei, name, sha, groesse, art, datum, **mehr):
            d = {"id": _neue_id(), "datei": datei, "name": name, "art": art, "datum": datum,
                 "beschreibung": _text(v.get("beschreibung"), 500), "sha256": sha, "groesse": groesse,
                 "hinzugefuegt_am": jetzt, "von": ich, **mehr}
            neue_dok.append(d)
            bekannt[sha] = d["id"]
            return d

        def bytes_ablegen(name, daten, **mehr):
            sha = hashlib.sha256(daten).hexdigest()
            if sha in bekannt:
                bericht["doppelt"].append(name)
                return bekannt[sha]
            try:
                datei, f = _datei_anlegen(ablage, name)
                with f:
                    f.write(daten)
            except OSError as e:                         # ein Anhang mit unmöglichem Namen stoppt nicht die Mail
                bericht["fehler"].append(f"Anhang „{sicherer_dateiname(name)[:60]}“ ließ sich nicht ablegen "
                                         f"({e.strerror or e}).")
                return None
            bericht["anhaenge"] += 1
            return eintrag(datei, sicherer_dateiname(name), sha, len(daten), _art_raten(name), **mehr)["id"]

        for pfad in pfade or []:
            name = os.path.basename(str(pfad))
            try:
                groesse = os.path.getsize(pfad)
                if groesse > DATEI_MAX:
                    bericht["fehler"].append(f"{name}: größer als {DATEI_MAX // 1024 // 1024} MB – bitte von Hand in "
                                             "den Ordner legen.")
                    continue
                sha = _sha256_datei(pfad)
            except OSError as e:
                bericht["fehler"].append(f"{name}: nicht lesbar ({e.strerror or e}).")
                continue
            if sha in bekannt:
                bericht["doppelt"].append(name)
                continue
            m = lies_mail_inhalt(pfad) if os.path.splitext(name)[1].lower() in MAIL_ENDUNGEN else None
            if m and not m.fehler and _gueltig(m.datum):
                schluessel = (m.absender, _text(m.betreff, 200) or "(ohne Betreff)", m.datum[:16])
                if schluessel in mails_bekannt:
                    bericht["doppelt"].append(name)
                    continue
                mails_bekannt.add(schluessel)
            datei, f = _datei_anlegen(ablage, name)
            try:
                with f, open(pfad, "rb") as quelle:
                    shutil.copyfileobj(quelle, f, 1024 * 1024)
            except OSError as e:
                try:
                    os.remove(os.path.join(ablage, datei))     # keine halbe Kopie liegen lassen
                except OSError:
                    pass
                bericht["fehler"].append(f"{name}: Kopieren hat nicht geklappt ({e.strerror or e}).")
                continue
            bericht["dateien"] += 1
            if m is None:
                eintrag(datei, sicherer_dateiname(name), sha, groesse, v.get("art") or _art_raten(name), vorgabe_datum)
                continue
            if m.fehler:
                eintrag(datei, sicherer_dateiname(name), sha, groesse, "mail", None, hinweis=m.fehler)
                bericht["fehler"].append(f"{name}: {m.fehler} – als Datei abgelegt, ohne Eintrag in der Chronologie.")
                continue
            bericht["mails"] += 1
            bericht["kleinbilder"] += m.kleinbilder
            tag = m.datum[:10] if _gueltig(m.datum) else None
            dok = eintrag(datei, sicherer_dateiname(name), sha, groesse, "mail", tag,
                          mail={"betreff": m.betreff, "von": m.absender, "an": m.an, "datum": m.datum})
            anhaenge = [x for x in (bytes_ablegen(n, daten, datum=tag, aus_mail=dok["id"]) for n, daten in m.anhaenge)
                        if x]
            text = m.text if len(m.text) <= EREIGNIS_TEXT_MAX else \
                m.text[:EREIGNIS_TEXT_MAX] + "\n\n[gekürzt – die vollständige Mail liegt unter „Dokumente“]"
            ereignis = {"id": _neue_id(), "datum": m.datum[:16] if _gueltig(m.datum) else self._heute().isoformat(),
                        "art": "mail_aus" if _eigene_adresse(m.absender) else "mail_ein",
                        "titel": _text(m.betreff, 200) or "(ohne Betreff)", "text": text,
                        "mail_von": m.absender, "mail_an": m.an, "dokumente": [dok["id"]] + list(dict.fromkeys(anhaenge)),
                        "quelle": "mail", "von": ich, "am": jetzt}
            dok["ereignis_id"] = ereignis["id"]
            neue_ereignisse.append(ereignis)

        def dazu(a, ich):
            if len(a["dokumente"]) + len(neue_dok) > GRENZEN["dokumente"]:
                raise RechtsfallFehler("Zu viele Dokumente in dieser Akte.")
            a["dokumente"].extend(neue_dok)
            a["ereignisse"].extend(neue_ereignisse)
        ansicht = self._aendere(az, dazu) if neue_dok or neue_ereignisse else self.akte(az)
        bericht["neu"] = len(neue_dok)
        bericht["ereignisse"] = len(neue_ereignisse)
        return {"akte": ansicht, "bericht": bericht}

    def _dokument(self, az: str, dokument_id: str):
        ich = self._ich_pflicht()
        a = self._lesen(az, ich)
        return a, _eintrag(a["dokumente"], dokument_id, "Dieses Dokument gibt es nicht mehr in der Akte.")

    def dokument_pfad(self, az: str, dokument_id: str) -> str:
        """Pfad einer Datei der Akte – nur für app.py (öffnen); der Name kommt aus der Akte, nie aus der Oberfläche."""
        _, d = self._dokument(az, dokument_id)
        name = os.path.basename(str(d.get("datei") or ""))
        pfad = os.path.join(self._fallordner(az), DOKUMENTE, name)
        if not name or not os.path.isfile(pfad):
            raise RechtsfallFehler("Die Datei liegt nicht mehr im Ordner der Akte – vielleicht noch nicht synchronisiert.")
        return pfad

    def fallordner_pfad(self, az: str) -> str:
        ich = self._ich_pflicht()
        self._lesen(az, ich)
        return self._fallordner(az)

    def dokument_aendern(self, az: str, dokument_id: str, felder: dict) -> dict:
        """Art, Datum, Beschreibung."""
        f = dict(felder or {})

        def aendern(a, ich):
            d = _eintrag(a["dokumente"], dokument_id, "Dieses Dokument gibt es nicht mehr in der Akte.")
            if "art" in f:
                if f["art"] not in DOKUMENT_ARTEN:
                    raise RechtsfallFehler("Unbekannte Art des Dokuments.")
                d["art"] = f["art"]
            if "datum" in f:
                d["datum"] = _datum(f["datum"])
            if "beschreibung" in f:
                d["beschreibung"] = _text(f["beschreibung"], 500)
        return self._aendere(az, aendern)

    def dokument_entfernen(self, az: str, dokument_id: str) -> dict:
        """Aus der Akte nehmen; die Datei wandert in den Unterordner „_entfernt“ (nicht gelöscht)."""
        a, d = self._dokument(az, dokument_id)
        quelle = os.path.join(self._fallordner(az), DOKUMENTE, os.path.basename(str(d.get("datei") or "")))
        if os.path.isfile(quelle):
            ziel_ordner = os.path.join(self._fallordner(az), ENTFERNT)
            name, f = _datei_anlegen(ziel_ordner, os.path.basename(quelle))
            f.close()
            try:
                os.replace(quelle, os.path.join(ziel_ordner, name))
            except OSError as e:
                os.remove(os.path.join(ziel_ordner, name))
                raise RechtsfallFehler(f"Entfernen hat nicht geklappt ({e}). Ist die Datei gerade geöffnet?") from None

        def weg(a, ich):
            a["dokumente"] = [x for x in a["dokumente"] if x["id"] != dokument_id]
            for e in a["ereignisse"]:
                e["dokumente"] = [x for x in e.get("dokumente") or [] if x != dokument_id]
            for b in a["belege"]:
                b["belege"] = [x for x in b.get("belege") or [] if x != dokument_id]
        return self._aendere(az, weg)

    def vorschau(self, az: str, dokument_id: str):
        """Kleines Vorschaubild eines Fotos als data:-Adresse (oder None)."""
        _, d = self._dokument(az, dokument_id)
        if os.path.splitext(str(d.get("datei") or ""))[1].lower() not in VORSCHAU_ENDUNGEN:
            return None
        schluessel = d.get("sha256") or dokument_id
        if schluessel in self._vorschauen:
            return self._vorschauen[schluessel]
        pfad = self.dokument_pfad(az, dokument_id)
        try:
            from PIL import Image, ImageOps
            from .sicher import MAX_BILD_PIXEL
            Image.MAX_IMAGE_PIXELS = MAX_BILD_PIXEL
            with Image.open(pfad) as bild:
                if bild.width * bild.height > MAX_BILD_PIXEL:   # winzige Datei, riesiges Bild: nicht entpacken
                    raise ValueError("Bild zu groß")
                bild = ImageOps.exif_transpose(bild)
                bild.thumbnail((480, 480))
                puffer = io.BytesIO()
                bild.convert("RGB").save(puffer, "JPEG", quality=80)
            adresse = "data:image/jpeg;base64," + base64.b64encode(puffer.getvalue()).decode()
        except Exception:                                  # Pillow fehlt oder Bild nicht lesbar: keine Vorschau
            adresse = None
        if len(self._vorschauen) > 300:
            self._vorschauen.clear()
        self._vorschauen[schluessel] = adresse
        return adresse

    # ---------------- Belegmatrix ----------------
    def _beleg_felder(self, x: dict, e: dict, neu: bool, a: dict):
        if neu or "behauptung" in e:
            text = _langtext(e.get("behauptung"), 1000)
            if not text:
                raise RechtsfallFehler("Bitte die Behauptung oder Tatsache eingeben.")
            x["behauptung"] = text
        if neu or "von" in e:
            von = e.get("von") or "wir"
            if von not in BEHAUPTET:
                raise RechtsfallFehler("Wer behauptet es: wir oder die Gegenseite?")
            x["von"] = von
        if neu or "beweislast" in e:
            last = e.get("beweislast") or x.get("von") or "unklar"   # Grundregel: wer behauptet, beweist
            if last not in BEWEISLAST:
                raise RechtsfallFehler("Beweislast: wir, Gegenseite oder unklar.")
            x["beweislast"] = last
        if neu or "status" in e:
            status = e.get("status") or "offen"
            if status not in BELEG_STATUS:
                raise RechtsfallFehler("Status: offen, streitig oder unstreitig.")
            x["status"] = status
        if "belege" in e:
            vorhanden = {d["id"] for d in a["dokumente"]}
            x["belege"] = [d for d in dict.fromkeys(e["belege"] or []) if d in vorhanden]
        for k in ("weitere", "beschaffen"):
            if k in e:
                x[k] = _langtext(e[k], 1000)

    def beleg_anlegen(self, az: str, eingabe: dict) -> dict:
        """Zeile der Belegmatrix: Behauptung, wer behauptet, wer beweisen muss, Status, Belege (Dokumente), weitere
        Beweismittel (Zeugen …) und wie eine Lücke zu schließen ist."""
        e = dict(eingabe or {})

        def dazu(a, ich):
            if len(a["belege"]) >= GRENZEN["belege"]:
                raise RechtsfallFehler("Zu viele Zeilen in der Belegmatrix.")
            x = {"id": _neue_id(), "belege": [], "weitere": "", "beschaffen": ""}
            self._beleg_felder(x, e, True, a)
            a["belege"].append({**x, "von_person": ich, "am": self._zeit()})
        return self._aendere(az, dazu)

    def beleg_aendern(self, az: str, beleg_id: str, felder: dict) -> dict:
        def aendern(a, ich):
            x = _eintrag(a["belege"], beleg_id, "Diese Zeile gibt es nicht mehr.")
            self._beleg_felder(x, dict(felder or {}), False, a)
        return self._aendere(az, aendern)

    def beleg_loeschen(self, az: str, beleg_id: str) -> dict:
        def weg(a, ich):
            _eintrag(a["belege"], beleg_id, "Diese Zeile gibt es nicht mehr.")
            a["belege"] = [x for x in a["belege"] if x["id"] != beleg_id]
        return self._aendere(az, weg)

    # ---------------- Checkliste ----------------
    def schritt_abhaken(self, az: str, schritt_id: str, erledigt=True) -> dict:
        def setzen(a, ich):
            if not any(s["id"] == schritt_id for s in W.schritte(a["falltyp"], a["rolle"])):
                raise RechtsfallFehler("Diesen Schritt gibt es für diesen Fall nicht.")
            if _ja(erledigt):
                a["checkliste"][schritt_id] = {"erledigt": True, "am": self._zeit(), "von": ich}
            else:
                a["checkliste"].pop(schritt_id, None)
        return self._aendere(az, setzen)

    # ---------------- Entwürfe ----------------
    def _platzhalter(self, a: dict, entwurf: dict) -> dict:
        """Werte für die Platzhalter; was die Akte nicht hergibt, bleibt leer (wird zu [eckiger Klammer])."""
        g, b = a["gegenseite"], a["bezug"] or {}
        heute = self._heute()
        name = g.get("name", "")
        ich = self._ich()
        absender = self._personen().get(ich, {}).get("name", "") if ich else ""
        unternehmer = g.get("art") == "unternehmer"
        eingang = sorted((e for e in a["ereignisse"] if e.get("art") in ("mail_ein", "brief_ein") and _gueltig(e.get("datum"))),
                         key=lambda e: e["datum"])
        offen = [f for f in self._fristen(a) if not f.get("erledigt")]
        gesetzt = [f for f in offen if f.get("art") == "gegenseite"]
        frist_tage = entwurf.get("frist_tage")
        vorschlag = (dt.date.fromisoformat(gesetzt[0]["datum"]) + dt.timedelta(days=14)).isoformat() if gesetzt else ""
        dokumente = [f"- {d.get('name')} ({DOKUMENT_ARTEN.get(d.get('art'), 'Dokument')}"
                     + (f", {_deutsch(d['datum'])}" if _gueltig(d.get("datum")) else "") + ")"
                     for d in a["dokumente"][:15]]
        return {
            "anrede": "Sehr geehrte Damen und Herren," if unternehmer or not name else f"Guten Tag {name},",
            "anrede_schriftlich": "Sehr geehrte Damen und Herren,",
            "anrede_anwalt": f"Guten Tag {a['anwalt_extern']}," if a["anwalt_extern"] else "Sehr geehrte Damen und Herren,",
            "gegenseite": name, "kunde": b.get("kunde") or name,
            "gegenseite_voll": ", ".join(x for x in (name, f"vertreten durch {g['anwalt']}" if g.get("anwalt") else "",
                                                     GEGENSEITE_ARTEN.get(g.get("art", ""), "") if g.get("art") else "") if x),
            "fahrzeug": b.get("fahrzeug", ""), "aktenzeichen": a["aktenzeichen"], "titel": a["titel"],
            "uebergabe": _deutsch(b.get("uebergabe") or ""), "betrag": euro(a["streitwert"]),
            "hoehe": f"bisher beziffert {euro(a['streitwert'])}" if a["streitwert"] is not None else "noch nicht bekannt",
            "frist": _deutsch((heute + dt.timedelta(days=frist_tage)).isoformat()) if frist_tage else "",
            "frist_vorschlag": _deutsch(vorschlag),
            "datum_schreiben": _deutsch(eingang[-1]["datum"][:10]) if eingang else "",
            "zinssatz": "5" if g.get("art") == "verbraucher" else "",
            "kontakt_service": "service@beispiel.example",
            "absender": absender, "rolle": ROLLEN[a["rolle"]],
            "sachverhalt": " ".join(a["sachverhalt"].split())[:600],
            "dokumentliste": "\n".join(dokumente),
            "fristenliste": "\n".join(f"- {_deutsch(f['datum'])}: {f['titel']} ({f['art_name']})" for f in offen),
        }

    FEHLT = {"anrede": "Anrede", "gegenseite": "Name der Gegenseite", "kunde": "Name des Kunden", "fahrzeug": "Fahrzeug",
             "uebergabe": "Datum der Übergabe", "betrag": "Betrag", "frist": "Frist", "frist_vorschlag": "neues Fristdatum",
             "datum_schreiben": "Datum des Schreibens", "zinssatz": "5 oder 9, bitte prüfen", "absender": "Ihr Name",
             "sachverhalt": "kurze Schilderung", "dokumentliste": "Unterlagen", "fristenliste": "keine offenen Fristen",
             "gegenseite_voll": "Gegenseite"}

    def entwurf(self, az: str, entwurf_id: str) -> dict:
        """Textbaustein mit Werten aus der Akte. Fehlendes bleibt als [Platzhalter] sichtbar und wird aufgezählt."""
        ich = self._ich_pflicht()
        a = self._lesen(az, ich)
        e = next((x for x in W.ENTWUERFE if x["id"] == entwurf_id), None)
        if not e:
            raise RechtsfallFehler("Diesen Entwurf gibt es nicht.")
        werte = self._platzhalter(a, e)
        fehlend = []

        def ersetze(text: str) -> str:
            def wert(m):
                k = m.group(1)
                if werte.get(k):
                    return werte[k]
                fehlend.append(self.FEHLT.get(k, k))
                return f"[{self.FEHLT.get(k, k)}]"
            return re.sub(r"\{([a-z_]+)\}", wert, text)
        betreff, text = ersetze(e["betreff"]), ersetze(e["text"])
        offen = sorted(set(fehlend) | set(re.findall(r"\[([^\]\n]{2,80})\]", betreff + "\n" + text)))
        return {"id": e["id"], "titel": e["titel"], "betreff": betreff, "text": text, "quelle": e["quelle"],
                "hinweis": e["hinweis"], "offen": offen, "markierung": "Entwurf – prüfen", "hinweis_recht": W.HINWEIS_RECHT}

    # ---------------- Dossier ----------------
    @staticmethod
    def _kuerzer(a: dict):
        """Namen, Mailadressen, Telefonnummern und IBAN im Dossier ersetzen – reduziert, nicht anonym."""
        g, b = a["gegenseite"], a["bezug"] or {}
        paare = []
        fuellwort = {"und", "herr", "frau", "familie", "firma", "gmbh", "mbh", "kg", "ohg", "gbr", "ug", "ag", "dr.",
                     "prof.", "rechtsanwalt", "rechtsanwältin", "rechtsanwälte", "kanzlei", "von", "van", "der", "die",
                     "das", "co.", "co", "partner", "caravan", "wohnmobil", "auto", "autohaus"}
        for wert, ersatz in ((g.get("name"), "[Gegenseite]"), (b.get("kunde"), "[Kunde]"),
                             (g.get("anwalt"), "[Anwalt der Gegenseite]"), (g.get("kontakt"), "[Kontakt]"),
                             (a.get("anwalt_extern"), "[Unser Anwalt]")):
            wert = str(wert or "").strip()
            if len(wert) >= 3:
                paare.append((wert, ersatz))
                for teil in re.split(r"[\s,;/&()]+", wert):          # jeder Namensteil: Vorname, Nachname, „Mustermann, Max“
                    teil = teil.strip(".-")
                    if len(teil) >= 3 and teil.casefold() not in fuellwort and not teil.isdigit():
                        paare.append((teil, ersatz))
        erste = {}
        for wert, ersatz in paare:                       # derselbe Name in zwei Feldern: das erste Feld gilt
            erste.setdefault(wert.casefold(), (wert, ersatz))
        paare = sorted(erste.values(), key=lambda p: -len(p[0]))

        def kuerzen(text: str) -> str:
            text = str(text or "")[:200_000]                   # die Muster unten nie auf beliebig langen Text
            text = re.sub(r"[\w.+-]{1,64}@[\w-]{1,63}(?:\.[\w-]{1,63}){1,6}", "[E-Mail]", text)     # erst Adressen, dann Namen
            text = re.sub(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,4})?\b", "[IBAN]", text)
            text = re.sub(r"\b(?=[A-HJ-NPR-Z0-9]*\d)(?=[A-HJ-NPR-Z0-9]*[A-HJ-NPR-Z])[A-HJ-NPR-Z0-9]{17}\b", "[FIN]", text)
            text = re.sub(r"(?<!\w)(?:\+|00)[1-9][\d /()\-]{6,}\d", "[Telefon]", text)
            text = re.sub(r"(?<![\w.])0[1-9][\d /()\-]{5,}\d", "[Telefon]", text)
            text = re.sub(r"\b[A-ZÄÖÜ]{1,3}[- ][A-Z]{1,2}[- ]?\d{1,4}[EH]?\b", "[Kennzeichen]", text)
            for wert, ersatz in paare:
                text = re.sub(r"(?<!\w)" + re.escape(wert) + r"(?!\w)", ersatz, text, flags=re.IGNORECASE)
            return text
        return kuerzen

    def dossier(self, az: str, optionen: dict = None) -> dict:
        """Strukturierte Zusammenfassung als Markdown – zum Kopieren in Claude (Skill muster-recht-einstieg) oder für den
        Anwalt. 'optionen': kuerzen (Namen und Kontaktdaten ersetzen, Standard ja), mailtexte (Standard ja)."""
        ich = self._ich_pflicht()
        a = self._ansicht(self._lesen(az, ich), ich)
        o = dict(optionen or {})
        kuerzen = _ja(o.get("kuerzen", True))
        mit_mails = _ja(o.get("mailtexte", True))
        k = self._kuerzer(a) if kuerzen else (lambda t: str(t or ""))
        g, b = a["gegenseite"], a["bezug"] or {}
        typ = W.FALLTYPEN[a["falltyp"]]
        namen = {p["id"]: p["name"] for p in self._personen().values()}
        dok_namen = {d["id"]: d.get("name") or d.get("datei") for d in a["dokumente"]}
        z = []
        z.append(f"# Rechtsfall {a['aktenzeichen']}: {k(a['titel'])}")
        z.append("")
        z.append(f"Stand {_deutsch(self._heute().isoformat())}. Vertraulich – enthält Angaben zu Personen"
                 + (" (Namen und Kontaktdaten ersetzt, nicht vollständig anonym)." if kuerzen else "."))
        z += ["", "## Auftrag", "",
              "Bitte diesen Fall mit dem Skill muster-recht-einstieg bearbeiten: einordnen, Risiko als Ampel, Fristen mit "
              "Datum prüfen, nächsten Schritt empfehlen und – wenn eine Antwort nach außen geht – einen Antwortentwurf im "
              "Firmenton von Caravan Muster liefern. Aussagen markieren, die live zu prüfen sind, und sagen, ob ein Anwalt "
              "hinzugezogen werden sollte.", "",
              f"Passende Fachskills laut ODIN: {', '.join(typ['skills'])}. Ergänzend: {', '.join(W.SKILLS_ALLGEMEIN)}."]
        eckdaten = [("Falltyp", typ["name"]), ("Unsere Rolle", ROLLEN[a["rolle"]]), ("Phase", PHASEN[a["phase"]]),
                    ("Gegenseite", k(g.get("name")) or "–"),
                    ("Gegenseite ist", GEGENSEITE_ARTEN.get(g.get("art", ""), "") if g.get("art") else "nicht eingeordnet"),
                    ("Anwalt der Gegenseite", k(g.get("anwalt")) or "–"), ("Fahrzeug (intern)", k(b.get("fahrzeug")) or "–"),
                    ("Kunde", k(b.get("kunde")) or "–"), ("Übergabe / Abnahme", _deutsch(b.get("uebergabe") or "") or "–"),
                    ("Streitwert", euro(a["streitwert"]) or "–"), ("Unser Anwalt", k(a["anwalt_extern"]) or "–")]
        z += ["", "## Eckdaten", ""] + [f"- {t}: {w}" for t, w in eckdaten]
        z += ["", "## Ziel", "", k(a["ziel"]) or "(noch nicht festgelegt)"]
        z += ["", "## Sachverhalt", "", k(a["sachverhalt"]) or "(noch nicht beschrieben – siehe Chronologie)"]
        z += ["", "## Chronologie", ""]
        if a["ereignisse"]:
            z += ["| Datum | Art | Was | Belege |", "|---|---|---|---|"]
            for e in a["ereignisse"]:
                datum = _deutsch(e["datum"]) + (f" {e['datum'][11:16]}" if len(e.get("datum") or "") >= 16 else "")
                z.append(f"| {datum} | {e['art_name']} | {_md(k(e['titel']))} | "
                         f"{_md(', '.join(k(dok_namen[d]) for d in e.get('dokumente') or [] if d in dok_namen))} |")
            texte = [e for e in a["ereignisse"] if mit_mails and str(e.get("text") or "").strip()]
            if texte:
                z += ["", "### Inhalte der Einträge", ""]
                for e in texte:
                    text = str(e["text"]).strip()
                    if len(text) > 3000:
                        text = text[:3000] + " […]"
                    z += [f"#### {_deutsch(e['datum'])} · {e['art_name']} · {k(e['titel'])}", ""]
                    if e.get("mail_von"):
                        z.append(f"Von: {k(e['mail_von'])}")
                    z += ["", "> " + k(text).replace("\n", "\n> "), ""]
        else:
            z.append("(noch keine Einträge)")
        z += ["", "## Fristen", ""]
        if a["fristen"]:
            z += ["| Frist | Datum | Art | Stand | Hinweis |", "|---|---|---|---|---|"]
            for f in a["fristen"]:
                stand = "erledigt" if f.get("erledigt") else {"ueberfaellig": "überfällig", "heute": "heute"}.get(
                    f["zustand"], f"in {f['tage']} Tagen" if f["tage"] is not None else "offen")
                hinweis = (f"berechnet: {f['berechnung']}" + ("" if f.get("geprueft") else " – ungeprüft")) \
                    if f.get("berechnung") else ""
                z.append(f"| {_md(k(f['titel']))} | {_deutsch(f['datum'])} | {f['art_name']} | {stand} | {_md(hinweis)} |")
            z.append("")
            z.append("Fristen bitte gegen Gesetz und Unterlagen prüfen – ODIN rechnet nicht verbindlich.")
        else:
            z.append("(keine Fristen eingetragen)")
        z += ["", "## Behauptungen und Belege", ""]
        if a["belege"]:
            z += ["| Behauptung | Wer behauptet | Beweislast | Status | Belege | Lücke |", "|---|---|---|---|---|---|"]
            for x in a["belege"]:
                belege = ", ".join(x["beleg_namen"] + ([k(x["weitere"])] if x.get("weitere") else []))
                luecke = "ja" + (f" – {k(x['beschaffen'])}" if x.get("beschaffen") else "") if x["luecke"] else ""
                z.append(f"| {_md(k(x['behauptung']))} | {x['von_name']} | {x['beweislast_name']} | {x['status_name']} | "
                         f"{_md(belege)} | {_md(luecke)} |")
        else:
            z.append("(noch keine Belegmatrix)")
        z += ["", "## Dokumente in der Akte", ""]
        if a["dokumente"]:
            for d in a["dokumente"]:
                teile = [d["art_name"]] + ([_deutsch(d["datum"])] if _gueltig(d.get("datum")) else []) \
                    + ([k(d["beschreibung"])] if d.get("beschreibung") else [])
                z.append(f"- {k(d.get('name'))} ({', '.join(teile)}), SHA-256 {str(d.get('sha256') or '')[:16]}…")
        else:
            z.append("(keine Dokumente)")
        z += ["", "## Offene Fragen", "", k(a["offene_fragen"]) or "(keine notiert)"]
        erledigt = [s for s in a["schritte"] if s["erledigt"]]
        if erledigt:
            z += ["", "## Schon erledigt", ""] + [f"- {s['text']}" for s in erledigt]
        if a["notizen"].strip():
            z += ["", "## Notizen", "", k(a["notizen"])]
        z += ["", "---", f"Bearbeiter: {', '.join(namen.get(i, '?') for i in a['bearbeiter'])}. Erstellt mit ODIN. "
                         f"{W.HINWEIS_RECHT}"]
        text = "\n".join(z).strip() + "\n"
        return {"text": text, "dateiname": f"Dossier {a['aktenzeichen']} {self._heute().isoformat()}.md",
                "gekuerzt": kuerzen}

    def dossier_speichern(self, az: str, optionen: dict = None) -> dict:
        """Dossier als Markdown-Datei in den Ordner der Akte legen (nicht unter „Dokumente“)."""
        d = self.dossier(az, optionen)
        name, f = _datei_anlegen(self._fallordner(az), d["dateiname"])
        with f:
            f.write(d["text"].encode("utf-8"))
        return {"datei": name, "ordner": self._fallordner(az)}

    # ---------------- Zähler und Heute & Woche ----------------
    def _offene_fristen(self):
        ich = self._ich()
        if not ich:
            return []
        try:
            akten = self._alle()
        except RechtsfallFehler:
            return []
        for a in akten:
            if not self._darf_sehen(a, ich) or a["phase"] == "erledigt":
                continue
            for f in a["fristen"]:
                if not f.get("erledigt") and _gueltig(f.get("datum")):
                    yield a, self._frist_stand(f)

    def zaehler(self) -> dict:
        """Für die Seitenleiste: offene Fristen in den nächsten 7 Tagen oder überfällig."""
        bald = ueber = 0
        for _, f in self._offene_fristen():
            if f["bald"]:
                bald += 1
                ueber += f["tage"] < 0
        return {"bald": bald, "ueberfaellig": ueber}

    def agenda(self) -> list:
        """Fristen (und Vorfristen) für „Heute & Woche“: nur Fälle, an denen ich beteiligt bin."""
        punkte = []
        for a, f in self._offene_fristen():
            basis = {"aktenzeichen": a["aktenzeichen"], "fall": a["titel"], "art": f.get("art"),
                     "art_name": f["art_name"], "frist_id": f["id"], "frist_datum": f["datum"]}
            punkte.append({**basis, "datum": f["datum"], "titel": f["titel"], "vorfrist": False,
                           "ueberfaellig": f["tage"] < 0, "pruefen": f["pruefen"]})
            if f["vorfrist_ab"] and f["vorfrist_ab"] != f["datum"] and f["vorfrist_ab"] >= self._heute().isoformat():
                punkte.append({**basis, "datum": f["vorfrist_ab"], "titel": f["titel"], "vorfrist": True,
                               "ueberfaellig": False, "pruefen": f["pruefen"]})
        return sorted(punkte, key=lambda p: (p["datum"], p["aktenzeichen"]))
