"""
Die Tür zwischen Oberfläche und Programm.

pywebview löst Aufrufe aus der Oberfläche per getattr-Kette auf ("a.b.c") und prüft beim Aufruf keine Unterstriche.
Bekäme das Fenster das Api-Objekt selbst, wären darüber auch private Methoden und alle Unterobjekte (Fenster,
Cockpit, Projekte …) erreichbar – an jeder Allowlist vorbei. Deshalb zwei Riegel:

1. `oberflaeche(api)` baut eine Fassade, die nur die öffentlichen Methoden der Api-Klasse kennt. Sie hält keinen
   Verweis auf die Api als Attribut; es gibt nichts, wohin eine Kette weiterlaufen könnte.
2. `riegel_setzen(namen)` umhüllt pywebviews `js_bridge_call`: Durch kommt nur ein Name aus der festen Menge –
   ohne Punkt, ohne Unterstrich am Anfang. Alles andere wird verworfen und protokolliert.
"""

import inspect
import json

# Namen, die pywebview selbst über die Brücke schickt (Fenster verschieben, Ereignisse, Rückgaben, Zustand)
INTERN = frozenset({"pywebviewMoveWindow", "pywebviewEventHandler", "pywebviewAsyncCallback", "pywebviewStateUpdate",
                    "pywebviewStateDelete"})


def oeffentliche_namen(api) -> list:
    """Öffentliche Methoden der Api-Klasse – keine Attribute, keine Unterobjekte, nichts mit Unterstrich."""
    klasse = type(api)
    return sorted(n for n in dir(klasse) if not n.startswith("_")
                  and isinstance(inspect.getattr_static(klasse, n), (type(oeffentliche_namen), staticmethod)))


def _tuer(methode):
    def aufruf(_selbst, *argumente):
        ergebnis = methode(*argumente)
        try:
            # NaN/Infinity (z. B. aus einer von Hand veränderten Datei) kann die Oberfläche nicht lesen – der Aufruf
            # bliebe dort für immer hängen. Dann lieber ein klarer Fehler.
            json.dumps(ergebnis, allow_nan=False)
        except ValueError:
            raise ValueError("Die Antwort enthält ungültige Zahlen – vermutlich ist eine gemeinsame Datei beschädigt.") from None
        except TypeError:
            pass                                        # nicht serialisierbar: meldet pywebview selbst
        return ergebnis
    return aufruf


def oberflaeche(api):
    """Objekt für `js_api`: nur die erlaubten Methoden, sonst nichts."""
    methoden = {name: _tuer(getattr(api, name)) for name in oeffentliche_namen(api)}
    methoden["__slots__"] = ()
    methoden["__doc__"] = "Was die Oberfläche aufrufen darf."
    return type("Oberflaeche", (), methoden)()


def erlaubt(name, namen) -> bool:
    return isinstance(name, str) and (name in INTERN or (name in namen and "." not in name and not name.startswith("_")))


# Die Adresse der eigenen Oberfläche – gesetzt, sobald sie das erste Mal geladen ist (fenster_sichern)
_EIGENE = {"adresse": None}


def _ohne_anhang(url) -> str:
    """Adresse ohne #… und ?… – nur daran wird erkannt, ob noch die eigene Oberfläche im Fenster ist."""
    return str(url or "").split("#", 1)[0].split("?", 1)[0].rstrip("/").lower()


def _kann_eigene_sein(url) -> bool:
    """Die Oberfläche liegt immer als index.html auf diesem Rechner (pywebviews eigener Server oder Datei)."""
    u = _ohne_anhang(url)
    return u.endswith("/index.html") and u.startswith(("http://127.0.0.1:", "http://localhost:", "file:///"))


def eigene_seite(url, window=None) -> bool:
    start = _EIGENE["adresse"]
    if start is None:                                   # noch nichts gemerkt: die Adresse, die ODIN selbst lädt
        soll = _ohne_anhang(getattr(window, "real_url", None)) if window is not None else ""
        return url is None or _kann_eigene_sein(url) or (bool(soll) and _ohne_anhang(url) == soll)
    return _ohne_anhang(url) == start


def _aktuelle_adresse(window):
    """Was gerade im Fenster geladen ist – direkt gelesen (kein Umweg über die Seite selbst)."""
    try:
        return window.gui.get_current_url(window.uid)
    except Exception:                                   # noqa: BLE001 – Plattform ohne diese Auskunft
        return None


def fenster_sichern(window, protokoll=None):
    """Das Fenster zeigt nur die eigene Oberfläche. Gelingt es jemandem, HTML einzuschleusen, das woandershin
    weiterleitet (dagegen hilft keine Inhaltsregel), dann wird (1) der Wechsel abgebrochen, (2) eine doch geladene
    fremde Seite sofort wieder ersetzt und (3) jeder Aufruf von einer fremden Seite verworfen (riegel_setzen)."""
    melde = protokoll or (lambda text: None)

    def geladen(*_):
        url = _aktuelle_adresse(window)
        if _EIGENE["adresse"] is None:
            if url and eigene_seite(url, window):
                _EIGENE["adresse"] = _ohne_anhang(url)
                if not _wechsel_abbrechen(window, melde):
                    melde("Fenster: Seitenwechsel lassen sich auf diesem System nicht vorab abbrechen "
                          "(fremde Seiten werden nachträglich ersetzt)")
            elif url:
                melde(f"Fenster: unerwartete Startadresse ({str(url)[:120]!r})")
            return
        if url and not eigene_seite(url):
            melde(f"Fenster: fremde Seite geladen ({str(url)[:120]!r}) – zurück zur Oberfläche")
            try:
                window.load_url(_EIGENE["adresse"])
            except Exception:                           # noqa: BLE001
                pass

    window.events.loaded += geladen
    return geladen


def _wechsel_abbrechen(window, melde):
    """Windows (WebView2): Navigation zu einer fremden Adresse gar nicht erst beginnen lassen."""
    try:
        from webview.platforms.winforms import BrowserView
        ansicht = BrowserView.instances.get(window.uid)
        steuerung = getattr(getattr(ansicht, "browser", None), "webview", None)
        if steuerung is None or not hasattr(steuerung, "NavigationStarting"):
            return False

        def beginnt(sender, args):
            try:
                ziel = str(args.Uri)
                if not eigene_seite(ziel):
                    args.Cancel = True
                    melde(f"Fenster: Wechsel zu fremder Adresse abgebrochen ({ziel[:120]!r})")
            except Exception:                           # noqa: BLE001
                pass

        steuerung.NavigationStarting += beginnt
        return True
    except Exception:                                   # noqa: BLE001 – nicht Windows oder anderer Aufbau
        return False


def riegel_setzen(namen, protokoll=None) -> bool:
    """pywebviews Brücke umhüllen. Vor `webview.start()` aufrufen – die Plattform-Module holen sich die Funktion
    erst beim Start. True, wenn der Riegel sitzt."""
    import webview.util as wu
    namen = frozenset(namen)
    original = getattr(wu.js_bridge_call, "_odin_original", wu.js_bridge_call)

    def js_bridge_call(window, func_name, param, value_id):
        if not eigene_seite(_aktuelle_adresse(window), window):
            if protokoll:
                protokoll("Brücke: Aufruf von einer fremden Seite verworfen")
            return None
        if not erlaubt(func_name, namen):
            if protokoll:
                protokoll(f"Brücke: Aufruf verworfen ({str(func_name)[:80]!r})")
            return None
        return original(window, func_name, param, value_id)

    js_bridge_call._odin_original = original
    wu.js_bridge_call = js_bridge_call
    return wu.js_bridge_call is js_bridge_call
