"""
Fahrzeugordner im synchronisierten SharePoint-Ordner "Fahrzeuge" und der AB-Prüfprozess.

Aufbau:
    Fahrzeuge/
      AB-Eingang/                     neue ABs (legt Power Automate ab)
        Nicht erkannt/                Dateien, die keine lesbare AB sind
      _Mailberichte/                  HTML-Zusammenfassung jeder Prüfung (für den Mail-Flow)
      2027/Hersteller1/DRM00285_1448596/
        2026-05-06_AB.pdf
        2026-06-01_AB.pdf
        AB-Vergleich_2026-06-01_gegen_2026-05-06.pdf
        _akte.json                    Prüfstatus aller ABs dieses Fahrzeugs (nicht von Hand ändern)

Ordnername = Interne ID + "_" + Auftragsnummer des Herstellers. Fehlt eine davon, steht nur die
bekannte da; sobald die zweite auftaucht, wird der Ordner umbenannt.

Prüfregeln (Fahrzeugakte):
- Alle ABs eines Fahrzeugs bilden eine Kette, sortiert nach Datum der Fassung, dann nach
  Ausfertigung/Änderungsstand, dann nach Eingang. Jede AB wird gegen ihre Vorgängerin in dieser
  Kette geprüft – egal, in welcher Reihenfolge die ABs eingehen. Kommt eine ältere AB nachträglich
  an, wird die Kette neu berechnet und die betroffenen Einzelvergleiche (Verlauf) neu verglichen; der
  Status des Fahrzeugs richtet sich weiter nach der neuesten AB.
- Status: "offen" (wichtige Änderungen, muss jemand ansehen), "klaerung" (in Klärung, z. B. Rückfrage
  beim Hersteller), "erledigt". Eine neue Fassung ohne wichtige Änderung gegenüber dem geprüften Stand
  wird automatisch erledigt; die erste AB nur, wenn sie zur Bestellung in Syscara passt.
"""

import base64
import copy
import datetime as dt
import errno
import filecmp
import functools
import getpass
import hashlib
import json
import os
import re
import shutil
import tempfile
import threading
from dataclasses import dataclass, field, replace

from .ab_lesen import AB, ab_nummern, extrahiere_interne_id, ist_interne_id, kommission, lies_ab, lies_ab_kopf
from . import regeln as regelwerk
from . import syscara as sc
from .ab_vergleich import INFO, WICHTIG, kurztext, vergleiche
from .mails import MAIL_ENDUNGEN, ist_mail, lies_mail

HERSTELLER = ["Hersteller1", "Hersteller2", "Hersteller3"]
ORDNERNAME = {"Hersteller3": "Hersteller3"}          # Umlaute vermeiden, SharePoint-sicher
EINGANG = "AB-Eingang"
NICHT_ERKANNT = "Nicht erkannt"
MAILBERICHTE = "_Mailberichte"
AKTE = "_akte.json"
AB_DATEI = re.compile(r"^(\d{4}-\d{2}-\d{2})_AB(?:_(\d+))?\.pdf$", re.I)
ALTER_BERICHT = re.compile(r"^\d{4}-\d{2}-\d{2}_AB-Vergleich(?:_\d+)?\.pdf$", re.I)
UNERLAUBT = re.compile(r'[<>:"/\\|?*#%]')

OFFEN, KLAERUNG, ERLEDIGT = "offen", "klaerung", "erledigt"
ERSTE, KEINE, NUR_INFO, MIT_WICHTIG = "erste", "keine", "info", "wichtig"
UNLESBAR = "unlesbar"                 # eine der beiden PDFs war gerade nicht lesbar – wird beim nächsten Laden wiederholt
PASST_ZU_SYSCARA = "syscara"         # erste AB, automatisch geprüft gegen die Bestellung in Syscara
MANUELL, AUTOMATISCH, EINGELESEN = "manuell", "automatisch", "eingelesen"     # wie eine AB geprüft wurde
VERGLEICH_STAND = 6          # erhöhen, wenn sich gespeicherte Vergleiche ändern (dann einmal neu berechnet)


def jetzt() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


_GELESEN = {}


def lies(pfad: str) -> AB:
    """lies_ab mit Zwischenspeicher: beim Einlesen vieler ABs wird jede PDF nur einmal ausgewertet."""
    try:
        st = os.stat(pfad)
    except OSError:
        return lies_ab(pfad)
    schluessel = (os.path.abspath(pfad), st.st_size, st.st_mtime_ns)
    if schluessel not in _GELESEN:
        ab = lies_ab(pfad)
        if ab.fehler:              # z. B. gerade von OneDrive gesperrt: nicht merken, beim nächsten Mal neu versuchen
            return ab
        if len(_GELESEN) > 300:
            _GELESEN.pop(next(iter(_GELESEN)))
        _GELESEN[schluessel] = ab
    return _GELESEN[schluessel]


def bewege(quelle: str, ziel: str):
    """Verschiebt eine Datei, ohne dass eine Kopie zurückbleibt: im selben Laufwerk durch Umbenennen – ist die
    Datei gerade gesperrt (OneDrive, Virenscanner), schlägt das fehl und sie bleibt, wo sie war. Nur über
    Laufwerksgrenzen (z. B. aus dem Temp-Ordner) wird kopiert; klappt das Löschen der Quelle nicht, wird die
    Kopie wieder entfernt."""
    try:
        os.rename(quelle, ziel)
    except OSError as fehler:
        if fehler.errno != errno.EXDEV:
            raise
        shutil.copy2(quelle, ziel)
        try:
            os.remove(quelle)
        except OSError:
            os.remove(ziel)
            raise


def pruefsumme(pfad: str) -> str:
    try:
        with open(pfad, "rb") as f:
            return hashlib.sha1(f.read()).hexdigest()[:16]
    except OSError:
        return ""


def merke(pfad: str, ab: AB):
    try:
        st = os.stat(pfad)
    except OSError:
        return
    _GELESEN[(os.path.abspath(pfad), st.st_size, st.st_mtime_ns)] = ab


def liegt_in(pfad: str, ordner: str) -> bool:
    try:
        p, o = os.path.normcase(os.path.abspath(pfad)), os.path.normcase(os.path.abspath(ordner))
        return os.path.commonpath([p, o]) == o
    except ValueError:          # verschiedene Laufwerke
        return False


def finde_einlesbare(ordner: str) -> list:
    """Alle PDFs und gespeicherten Mails in einem Ordner (mit Unterordnern)."""
    dateien = []
    for wurzel, unterordner, namen in os.walk(ordner):
        unterordner[:] = sorted(u for u in unterordner if not u.startswith("."))
        for n in sorted(namen):
            if n.lower().endswith((".pdf",) + MAIL_ENDUNGEN) and not n.startswith((".", "~$")):
                dateien.append(os.path.join(wurzel, n))
    return dateien


def benutzer() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return ""


@dataclass
class Fahrzeug:
    pfad: str
    jahr: str
    hersteller: str
    interne_id: str = ""
    auftragsnummer: str = ""

    @property
    def name(self) -> str:
        return os.path.basename(self.pfad)

    @property
    def nummern(self) -> set:
        """Nummern zum Wiederfinden. Freitext wie „Kunde“ zählt nicht – sonst landeten verschiedene
        Fahrzeuge im selben Ordner."""
        return {n.upper() for n in (self.interne_id if ist_interne_id(self.interne_id) else "", self.auftragsnummer) if n}

    def ab_dateien(self) -> list:
        try:
            return sorted(n for n in os.listdir(self.pfad) if AB_DATEI.match(n))
        except FileNotFoundError:
            return []

    def als_dict(self) -> dict:
        return {"pfad": self.pfad, "name": self.name, "jahr": self.jahr, "hersteller": self.hersteller,
                "interne_id": self.interne_id, "auftragsnummer": self.auftragsnummer}


@dataclass
class EingangsErgebnis:
    datei: str                        # Dateiname im Eingang
    status: str                       # "Eingeordnet", "Doppelt", "Nicht erkannt", "Fehler" (bleibt im Eingang)
    fahrzeug: Fahrzeug = None
    ab: AB = None
    neue_datei: str = ""              # Name im Fahrzeugordner
    pruefung: dict = None             # Einzelvergleich dieser AB mit ihrer Vorgängerin
    stand: dict = None                # Stand des Fahrzeugs danach (Zeile der Arbeitsliste)
    neu_geprueft: list = field(default_factory=list)   # weitere ABs, die dadurch neu verglichen wurden
    ordner_neu: bool = False
    meldung: str = ""
    noch_im_eingang: bool = True      # bei "Fehler": liegt die PDF noch im Eingang (sonst schon im Fahrzeugordner)


def ordnername(interne_id: str, auftragsnummer: str) -> str:
    teile = [UNERLAUBT.sub("-", t.strip()) for t in (interne_id, auftragsnummer) if t and t.strip()]
    return "_".join(teile)


def ist_auftragsnummer(teil: str) -> bool:
    return bool(re.fullmatch(r"\d+", teil) or re.match(r"POVAB\d", teil, re.I))


def eingegebene_auftragsnummer(text: str) -> str:
    """Von Hand eingegebene Auftrags-/Bestellnummer: Leerzeichen raus, dann nur Ziffern (mind. 4) oder POVAB-Nr. –
    sonst würde der Ordnername später als Interne ID gelesen."""
    nr = re.sub(r"\s+", "", text or "")
    if nr and not (re.fullmatch(r"\d{4,}", nr) or re.fullmatch(r"POVAB\d+", nr, re.I)):
        raise ValueError(f"„{text.strip()}“ ist keine Auftragsnummer – bitte nur die Ziffern eingeben, z. B. 1431110.")
    return nr.upper() if nr.upper().startswith("POVAB") else nr


def zerlege_ordnername(name: str):
    teile = [t for t in name.split("_") if t]
    if len(teile) >= 2:
        return teile[0], teile[1]
    if teile and ist_auftragsnummer(teile[0]):
        return "", teile[0]
    return (teile[0] if teile else ""), ""


def kennung(ab_datei: str) -> str:
    """'2026-06-01_AB_2.pdf' -> '2026-06-01_2'"""
    m = AB_DATEI.match(ab_datei)
    return m.group(1) + (f"_{m.group(2)}" if m.group(2) else "") if m else ab_datei


def nummern_von(fz: dict) -> set:
    return {n.upper() for n in (fz.get("interne_id"), fz.get("auftragsnummer")) if n}


def berichtsname(neu: str, alt: str) -> str:
    return f"AB-Vergleich_{kennung(neu)}_gegen_{kennung(alt)}.pdf"


def wichtige_liste(aenderungen) -> list:
    """Die wichtigen Änderungen in kurzer Form – gespeichert, damit Regeln ohne erneutes Einlesen wirken."""
    return [{"bereich": a.bereich, "art": a.art, "titel": a.titel, "kurz": kurztext(a)}
            for a in aenderungen if a.stufe == WICHTIG]


def wende_regeln_an(eintrag: dict, regeln: list, hersteller: str):
    """Setzt wichtig/info/kurz/stichworte eines gespeicherten Vergleichs nach den aktuellen Regeln."""
    liste = eintrag.get("liste", [])
    wirksam = [x for x in liste if not regelwerk.ist_stumm(regeln, hersteller, x["bereich"], x["art"])]
    eintrag["wichtig"] = len(wirksam)
    eintrag["stumm"] = len(liste) - len(wirksam)
    eintrag["kurz"] = [x["kurz"] for x in wirksam]
    worte = []
    for x in wirksam:
        wort = x["bereich"].split(" · ")[0]
        if wort not in worte:
            worte.append(wort)
    eintrag["stichworte"] = worte
    eintrag["regeln"] = regelwerk.stempel(regeln, hersteller)


def regeln_anwenden(aenderungen: list, regeln: list, hersteller: str) -> list:
    """Für die Anzeige: stumm geschaltete wichtige Änderungen werden zu Info (mit Kennzeichen)."""
    for a in aenderungen:
        if a.stufe == WICHTIG and regelwerk.ist_stumm(regeln, hersteller, a.bereich, a.art):
            a.stufe, a.stumm = INFO, True
    aenderungen.sort(key=lambda x: x.stufe != WICHTIG)
    return aenderungen



# ---------------- Fahrzeugakte ----------------

SPERRE = threading.RLock()     # ein Vorgang nach dem anderen (Liste, Eingang, Einlesen laufen in eigenen Threads)


def gesperrt(methode):
    @functools.wraps(methode)
    def mit_sperre(*args, **kwargs):
        with SPERRE:
            return methode(*args, **kwargs)
    return mit_sperre


class AkteGesperrt(Exception):
    """_akte.json ist gerade nicht lesbar (z. B. von OneDrive gesperrt) – dann wird nichts überschrieben."""


def _pruefe_form(daten):
    """Grobe Formprüfung einer geladenen Akte – sonst gilt sie als beschädigt."""
    if not isinstance(daten, dict):
        raise ValueError("keine Akte")
    for teil in ("abs", "pruefungen", "stand"):
        if teil in daten and not isinstance(daten[teil], dict):
            raise ValueError(f"{teil} beschädigt")
    for eintrag in list(daten.get("abs", {}).values()) + list(daten.get("pruefungen", {}).values()):
        if not isinstance(eintrag, dict):
            raise ValueError("Eintrag beschädigt")
    for eintrag in daten.get("abs", {}).values():
        if eintrag.get("geprueft") is not None and not isinstance(eintrag.get("geprueft"), dict):
            raise ValueError("Haken beschädigt")
    _richte_form(daten)


def _richte_form(daten):
    """Die Akte liegt im gemeinsamen Ordner. Jeder Wert, der später angezeigt oder als Dateiname benutzt wird, bekommt
    hier die erwartete Art. Ein einzelner falscher Wert wird berichtigt oder entfernt – Haken, Notizen und der
    Klärungsstand bleiben erhalten (die ganze Akte zu verwerfen, wäre für jeden mit Schreibzugriff ein Hebel)."""
    def ganz(eintrag, feld):
        wert = eintrag.get(feld)
        if wert is None or (isinstance(wert, int) and not isinstance(wert, bool)):
            return
        try:
            zahl = float(wert)
            eintrag[feld] = int(zahl) if zahl == int(zahl) and abs(zahl) < 10 ** 9 else 0
        except (TypeError, ValueError, OverflowError):
            eintrag[feld] = 0

    def text(eintrag, feld):
        if eintrag.get(feld) is not None and not isinstance(eintrag[feld], str):
            eintrag[feld] = ""

    abs_ = daten.get("abs", {})
    for name in list(abs_):
        if not isinstance(name, str) or name != os.path.basename(name.replace("\\", "/")) or name in ("", ".", ".."):
            del abs_[name]                               # nie ein Pfad: sonst läse ODIN außerhalb des Ordners
            continue
        eintrag = abs_[name]
        ganz(eintrag, "fassung")
        for feld in ("datum", "belegart", "andere_nummer", "eingang"):
            text(eintrag, feld)
        g = eintrag.get("geprueft")
        if isinstance(g, dict):
            ganz(g, "wichtig")
            ganz(g, "info")
            text(g, "gegen")
            if g.get("gegen") and g["gegen"] != os.path.basename(g["gegen"].replace("\\", "/")):
                g["gegen"] = ""
    stand = daten.get("stand", {})
    sy = stand.get("syscara")
    if sy is not None:
        e = sy.get("ergebnis") if isinstance(sy, dict) else None
        ok = (isinstance(sy, dict) and isinstance(e, dict) and isinstance(sy.get("auszug"), dict)
              and isinstance(sy["auszug"].get("positionen", []), list)
              and all(isinstance(sy.get(f, ""), str) for f in ("ab", "stand", "export_datei"))
              and all(isinstance(e.get(f, 0), int) and not isinstance(e.get(f, 0), bool)
                      for f in ("passt", "unsicher", "fehlt", "nur_ab", "abweichung", "ausstattung"))
              and isinstance(e.get("ok"), bool) and isinstance(e.get("kurz"), list)
              and all(isinstance(x, str) for x in e["kurz"]) and isinstance(e.get("zeilen"), list))
        if not ok:
            del stand["syscara"]                         # der Abgleich wird beim nächsten Export neu gerechnet


def _verbinde(basis, unsere, fremde, tiefe=0):
    """Drei-Wege-Abgleich, wenn ein anderer Rechner die Akte inzwischen gespeichert hat: unsere Änderungen
    (gegenüber dem geladenen Stand) kommen auf den fremden Stand, alles andere bleibt wie drüben.
    Abgeglichen wird bis auf die Ebene einzelner Felder einer AB bzw. des Standes."""
    if tiefe >= 3 or not all(isinstance(x, dict) for x in (basis, unsere, fremde)):
        return unsere if unsere != basis else fremde
    ergebnis = dict(fremde)
    for k in set(basis) | set(unsere):
        if k not in unsere:                                    # bei uns entfernt
            if k in basis and fremde.get(k) == basis.get(k):
                ergebnis.pop(k, None)
            continue
        if k in basis and unsere[k] == basis[k]:
            continue                                           # bei uns unverändert: der fremde Stand gilt
        if k in basis and k in fremde:
            ergebnis[k] = _verbinde(basis[k], unsere[k], fremde[k], tiefe + 1)
        else:
            ergebnis[k] = unsere[k]
    return ergebnis


class Akte:
    """Prüfstand eines Fahrzeugs, gespeichert als _akte.json im Fahrzeugordner.

    abs         je AB: Datum, Fassung, Belegart, Eingang, Liefertermin – und „geprueft“, wenn diese AB als
                geprüfter Stand abgehakt wurde (von wem, wann, gegen welche AB, welche Bereiche sich geändert hatten).
    pruefungen  jede AB gegen ihre direkte Vorgängerin – für den Verlauf („was kam mit welcher AB“).
    stand       die Arbeit am Fahrzeug: Vergleich der neuesten AB gegen die zuletzt geprüfte, Klärung, Notiz –
                und der Abgleich der neuesten AB mit der in Syscara bestellten Ausstattung („syscara“).
    """

    def __init__(self, fz: Fahrzeug):
        self.fz = fz
        self.pfad = os.path.join(fz.pfad, AKTE)
        self.daten = {"format": 2, "abs": {}, "pruefungen": {}, "stand": {}}
        self.migriert = False
        self._stempel = None                       # Änderungszeit der Datei beim Laden
        geladen = self._lies_datei()
        if geladen is not None:
            self.daten.update(geladen)
            for teil in ("abs", "pruefungen", "stand"):
                if self.daten.get(teil) is None:
                    self.daten[teil] = {}
            if geladen.get("format", 1) < 2:
                self._migriere()
        self._geladen = copy.deepcopy(self.daten)

    def _lies_datei(self):
        """Gelesene Akte, None wenn es keine gibt. Gesperrt: AkteGesperrt (nichts darf überschrieben werden).
        Beschädigt: wird als _akte.defekt-….json aufgehoben und aus den PDFs neu aufgebaut."""
        try:
            self._stempel = os.stat(self.pfad).st_mtime_ns
            with open(self.pfad, encoding="utf-8") as f:
                roh = f.read()
        except FileNotFoundError:
            self._stempel = None
            return None
        except OSError as e:
            raise AkteGesperrt(f"{self.fz.name}: Fahrzeugakte gerade nicht lesbar ({e}) – bitte gleich noch einmal "
                               "versuchen.") from e
        try:
            geladen = json.loads(roh)
            _pruefe_form(geladen)
            return geladen
        except ValueError:
            try:
                os.replace(self.pfad, os.path.join(self.fz.pfad, f"_akte.defekt-{dt.datetime.now():%Y%m%d-%H%M%S}.json"))
            except OSError:
                pass
            self._stempel = None
            return None

    @property
    def abs(self) -> dict:
        return self.daten["abs"]

    @property
    def pruefungen(self) -> dict:
        return self.daten["pruefungen"]

    @property
    def stand(self) -> dict:
        return self.daten["stand"]

    def _datei(self, name: str) -> str:
        return os.path.join(self.fz.pfad, name)

    @property
    def regeln(self) -> list:
        return regelwerk.lade(regelwerk.wurzel_von(self.fz.pfad))

    def speichern(self):
        """Speichert die Akte. Hat inzwischen jemand anderes gespeichert (zweiter Rechner), werden unsere
        Änderungen auf dessen Stand übertragen statt ihn zu überschreiben."""
        try:
            jetzt_stempel = os.stat(self.pfad).st_mtime_ns
        except FileNotFoundError:
            jetzt_stempel = None
        if jetzt_stempel != self._stempel and jetzt_stempel is not None:
            fremd = self._lies_datei()
            if fremd is not None and fremd.get("format", 1) >= 2:
                self.daten = _verbinde(self._geladen, self.daten, fremd)
        tmp = f"{self.pfad}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.pfad)
        try:
            self._stempel = os.stat(self.pfad).st_mtime_ns
        except OSError:
            self._stempel = None
        self._geladen = copy.deepcopy(self.daten)

    def kette(self) -> list:
        """AB-Dateien in Prüfreihenfolge: Datum, Fassung, Eingang."""
        return sorted(self.abs, key=lambda d: (self.abs[d].get("datum", ""), self.abs[d].get("fassung", 0),
                                               self.abs[d].get("eingang", ""), d))

    def geprueft_bis(self) -> str:
        """Die neueste AB, die als geprüft abgehakt ist ("" = noch keine)."""
        return next((d for d in reversed(self.kette()) if self.abs[d].get("geprueft")), "")

    def neue_abs(self) -> list:
        """ABs, die nach der zuletzt geprüften eingegangen sind (nach Datum)."""
        kette, basis = self.kette(), self.geprueft_bis()
        return kette[kette.index(basis) + 1:] if basis else kette

    def registriere(self, datei: str, ab: AB, quelle: str = "", eingang: str = "", einlesung: str = ""):
        eintrag = {"datum": ab.iso_datum or datei[:10], "fassung": ab.fassung, "belegart": ab.belegart,
                   "eingang": eingang or jetzt(), "quelle": quelle, "liefertermin": ab.kopf.get("Liefertermin", ""),
                   "kommission": kommission(ab), "pruefsumme": pruefsumme(self._datei(datei))}
        if einlesung:
            eintrag["einlesung"] = einlesung      # nachträglich eingelesen (Kennung des Laufs)
        if ab.fehler:
            eintrag["unvollstaendig"] = True      # gerade nicht lesbar: Datum, Fassung usw. später nachholen
        elif self.fz.auftragsnummer and ab.auftragsnummer and self.fz.auftragsnummer.upper() not in ab_nummern(ab):
            # gleiche Interne ID, aber andere Auftragsnummer: Tippfehler oder neue Bestellung – nie automatisch erledigen
            eintrag["andere_nummer"] = ab.auftragsnummer
        self.abs[datei] = eintrag

    def _lies_nach(self):
        """ABs, die beim Einordnen nicht lesbar waren (z. B. noch nicht von OneDrive geladen): sobald es geht,
        Datum, Fassung, Liefertermin usw. nachtragen – sonst stünden sie falsch in der Reihenfolge."""
        for datei, alt in list(self.abs.items()):
            if alt.get("unvollstaendig"):
                ab = lies(self._datei(datei))
                if ab.fehler:
                    continue
                self.registriere(datei, ab, alt.get("quelle", ""), alt.get("eingang", ""), alt.get("einlesung", ""))
                if alt.get("geprueft"):
                    self.abs[datei]["geprueft"] = alt["geprueft"]

    def braucht_aktualisierung(self) -> bool:
        """Ordner geändert, ein Eintrag noch unvollständig oder ein Einzelvergleich war nicht lesbar."""
        return (self.migriert or set(self.abs) != set(self.fz.ab_dateien())
                or any(e.get("unvollstaendig") for e in self.abs.values())
                or any(p.get("ergebnis") == UNLESBAR for p in self.pruefungen.values()))

    def markiere_eingelesen(self, datei: str):
        """Laut Outlook-Ordner „AB erledigt“ schon bearbeitet. Ist es die neueste AB, endet auch eine Klärung."""
        self.markiere_geprueft(datei, EINGELESEN)
        if datei == self.kette()[-1]:
            self.stand.update(status="", offen_gelassen="", klaerung_bei="")

    def markiere_geprueft(self, datei: str, art: str, **vergleich):
        self.abs[datei]["geprueft"] = {"art": art, "von": "" if art == AUTOMATISCH else benutzer(),
                                       "am": jetzt(), **vergleich}

    def aktualisiere(self, bericht_schreiben=None) -> list:
        """Gleicht die Akte mit den PDFs im Ordner ab, berechnet geänderte Einzelvergleiche neu und bewertet
        den Stand des Fahrzeugs. Gibt die ABs zurück, deren Einzelvergleich neu berechnet wurde."""
        vorhanden = set(self.fz.ab_dateien())
        weg = self.stand.setdefault("verschwunden", {})
        for datei in list(self.abs):
            if datei not in vorhanden:       # gelöscht – oder gerade nicht da (anderer PC synchronisiert noch)
                weg[datei] = {**self.abs.pop(datei), "seit": jetzt()}
                self.pruefungen.pop(datei, None)
        for datei in sorted(vorhanden - set(self.abs)):      # PDF ohne Eintrag (z. B. von Hand abgelegt)
            summe = pruefsumme(self._datei(datei))
            frueher = weg.pop(datei, None)
            if frueher and summe and frueher.get("pruefsumme") == summe:   # wieder da: Eintrag samt Haken zurück
                frueher.pop("seit", None)
                self.abs[datei] = frueher
                continue
            ab = lies(self._datei(datei))
            self.registriere(datei, ab, quelle="im Ordner vorgefunden")
            self.abs[datei]["eingang"] = dt.datetime.fromtimestamp(
                os.path.getmtime(self._datei(datei))).isoformat(timespec="seconds")
        for datei, e in self.abs.items():                    # Einträge aus älteren Versionen
            if not e.get("pruefsumme"):
                e["pruefsumme"] = pruefsumme(self._datei(datei))
        grenze = (dt.datetime.now() - dt.timedelta(days=30)).isoformat(timespec="seconds")
        for datei in [d for d, e in weg.items() if e.get("seit", "") < grenze]:
            del weg[datei]                                   # nach 30 Tagen endgültig weg
        if not weg:
            self.stand.pop("verschwunden", None)
        self._lies_nach()

        neu_berechnet = []
        kette = self.kette()
        for i, datei in enumerate(kette):
            gegen = kette[i - 1] if i else ""
            alt_pruefung = self.pruefungen.get(datei)
            if alt_pruefung and alt_pruefung.get("gegen") == gegen and alt_pruefung.get("ergebnis") != UNLESBAR:
                continue
            self.pruefungen[datei] = self._pruefe(datei, gegen, alt_pruefung, bericht_schreiben)
            neu_berechnet.append(datei)
        self._bewerte()
        self._entferne_alte_berichte()
        self.speichern()
        return neu_berechnet

    def _pruefe(self, datei: str, gegen: str, alt_pruefung, bericht_schreiben) -> dict:
        """Einzelvergleich einer AB mit ihrer direkten Vorgängerin (für den Verlauf)."""
        p = {"gegen": gegen, "wichtig": 0, "info": 0, "stichworte": [], "kurz": [], "bericht": "", "am": jetzt(),
             "v": VERGLEICH_STAND}
        if alt_pruefung and alt_pruefung.get("bericht"):
            try:
                os.remove(self._datei(alt_pruefung["bericht"]))
            except OSError:
                pass
        if not gegen:
            p["ergebnis"] = ERSTE
            return p
        alt, neu = lies(self._datei(gegen)), lies(self._datei(datei))
        if alt.fehler or neu.fehler:              # nicht als „alles neu“ werten – beim nächsten Laden wiederholen
            p.update(ergebnis=UNLESBAR, fehler=alt.fehler or neu.fehler)
            return p
        aenderungen = vergleiche(alt, neu)
        p["liste"] = wichtige_liste(aenderungen)
        p["info"] = sum(a.stufe == INFO for a in aenderungen)
        wende_regeln_an(p, self.regeln, self.fz.hersteller)
        p["ergebnis"] = MIT_WICHTIG if p["wichtig"] else NUR_INFO if aenderungen else KEINE
        if bericht_schreiben and aenderungen:
            try:                                  # ein fehlgeschlagenes PDF darf die Prüfung nicht abbrechen
                bericht_schreiben(self._datei(berichtsname(datei, gegen)), self.fz, alt, neu,
                                  regeln_anwenden(list(aenderungen), self.regeln, self.fz.hersteller))
                p["bericht"] = berichtsname(datei, gegen)
            except Exception:
                p["bericht"] = ""
        return p

    def _bewerte(self) -> bool:
        """Gesamtvergleich: neueste AB gegen die zuletzt geprüfte. Ohne wichtige Änderung wird die neueste
        automatisch zum geprüften Stand – das Fahrzeug taucht dann gar nicht erst in „Offen“ auf.
        Ist noch keine AB geprüft, wird zur Übersicht gegen die erste AB verglichen (Status bleibt offen:
        mit Syscara abgleichen). Gibt zurück, ob sich etwas geändert hat."""
        kette, st = self.kette(), self.stand
        if not kette:
            geaendert = bool(st.get("vergleich"))
            st["vergleich"] = {}
            return geaendert
        neueste = kette[-1]
        geaendert = False
        regeln = self.regeln
        g = self.abs[neueste].get("geprueft") or {}
        if g.get("art") == AUTOMATISCH and g.get("liste") and g.get("regeln") != regelwerk.stempel(regeln, self.fz.hersteller):
            # nur erledigt, weil Änderungen stumm geschaltet waren – zählen sie nach geänderten Regeln wieder: offen
            neu_bewertet = {"liste": g["liste"]}
            wende_regeln_an(neu_bewertet, regeln, self.fz.hersteller)
            if neu_bewertet["wichtig"]:
                self.abs[neueste].pop("geprueft")
            else:
                g["regeln"] = neu_bewertet["regeln"]
            geaendert = True
        basis = self.geprueft_bis()
        gegen = basis or (kette[0] if len(kette) > 1 else "")
        v = st.get("vergleich") or {}
        # Stand einer NEUEREN ODIN-Version (anderer PC schon aktualisiert) nicht mit alter Logik überschreiben
        if (v.get("neu") != neueste or v.get("gegen") != gegen or v.get("v", 0) < VERGLEICH_STAND
                or v.get("unlesbar")):
            v = {"neu": neueste, "gegen": gegen, "geprueft": bool(basis), "liste": [], "info": 0, "v": VERGLEICH_STAND}
            if gegen and gegen != neueste:
                alt_ab, neu_ab = lies(self._datei(gegen)), lies(self._datei(neueste))
                if alt_ab.fehler or neu_ab.fehler:
                    v["unlesbar"] = alt_ab.fehler or neu_ab.fehler   # nichts folgern, beim nächsten Laden wiederholen
                else:
                    aenderungen = vergleiche(alt_ab, neu_ab)
                    v.update(liste=wichtige_liste(aenderungen), info=sum(a.stufe == INFO for a in aenderungen))
            wende_regeln_an(v, regeln, self.fz.hersteller)
            st["vergleich"] = v
            geaendert = True
        elif v.get("regeln") != regelwerk.stempel(regeln, self.fz.hersteller):   # Regeln geändert: nur neu bewerten
            wende_regeln_an(v, regeln, self.fz.hersteller)
            geaendert = True
        v["geprueft"] = bool(basis)
        geaendert |= self._syscara_abgleich(neueste)
        sy = (st.get("syscara") or {}).get("ergebnis")
        frei = (st.get("status") != KLAERUNG and st.get("offen_gelassen") != neueste and not v.get("unlesbar")
                and not self.abs[neueste].get("andere_nummer"))
        if basis and basis != neueste and not v["wichtig"] and frei and not (sy and (sy["fehlt"] or sy["abweichung"])):
            stumm = {"liste": v["liste"], "regeln": v["regeln"]} if v.get("stumm") else {}   # für „Regel entfernt“
            self.markiere_geprueft(neueste, AUTOMATISCH, gegen=basis, wichtig=0, info=v["info"], stichworte=[], kurz=[],
                                   syscara=bool(sy and sy["ok"]), **stumm)
            geaendert = True
        elif not basis and sy and sy["ok"] and frei and not v["wichtig"]:
            # noch keine AB geprüft: passt alles zur Bestellung in Syscara (und gibt es mehrere ABs, hat sich
            # seit der ersten nichts Wichtiges wie Preise oder Zahlungsbedingungen geändert)
            self.markiere_geprueft(neueste, AUTOMATISCH, gegen="", wichtig=0, info=0, stichworte=[], kurz=[], syscara=True)
            geaendert = True
        return geaendert

    def _syscara_abgleich(self, neueste: str) -> bool:
        """Neueste AB gegen den Syscara-Stand des Fahrzeugs. Neu gerechnet wird nur, wenn sich die AB, der
        Syscara-Stand oder die gelernten Zuordnungen geändert haben. Gibt zurück, ob sich etwas geändert hat."""
        st, wurzel = self.stand, regelwerk.wurzel_von(self.fz.pfad)
        try:
            eintrag = sc.finde(sc.lade(wurzel), self.fz.interne_id, self.fz.nummern)
        except sc.NichtLesbar:
            return False                     # Syscara-Daten gerade nicht lesbar: alten Abgleich behalten, AB trotzdem prüfen
        alt = st.get("syscara")
        if not eintrag:
            return st.pop("syscara", None) is not None
        kennung = {"ab": neueste, "export": sc.stempel(eintrag), "v": sc.ABGLEICH_STAND,
                   "regeln": regelwerk.syscara_stempel(wurzel, self.fz.hersteller)}
        if alt and alt.get("v", 0) > sc.ABGLEICH_STAND and alt.get("ab") == neueste:
            return False                     # von einer neueren ODIN-Version berechnet: so lassen
        if alt and all(alt.get(k) == w for k, w in kennung.items()):
            neu_stand = {"stand": eintrag.get("stand", ""), "export_datei": eintrag.get("export", "")}
            if all(alt.get(k) == w for k, w in neu_stand.items()):
                return False
            alt.update(neu_stand)            # gleicher Inhalt, neuerer Export: nur Datum und Dateiname nachziehen
            return True
        if alt and alt.get("ab") == neueste and alt.get("v") == sc.ABGLEICH_STAND and alt.get("auszug"):
            auszug = alt["auszug"]                                  # nur Zuordnungen/Export geändert: nicht neu lesen
        else:
            ab = lies(self._datei(neueste))
            if ab.fehler:                                           # gerade nicht lesbar: nichts speichern, später neu
                return st.pop("syscara", None) is not None
            auszug = sc.ab_auszug(ab)
        ergebnis = sc.gleiche_ab(
            eintrag, auszug,
            [z for z in regelwerk.lade_syscara(wurzel) if z["hersteller"] == self.fz.hersteller],
            [z for z in regelwerk.lade_nur_ab(wurzel) if z["hersteller"] == self.fz.hersteller])
        st["syscara"] = {**kennung, "stand": eintrag.get("stand", ""), "export_datei": eintrag.get("export", ""),
                         "auszug": auszug, "ergebnis": ergebnis}
        return True

    def syscara_kurz(self) -> dict:
        """Zusammenfassung des Syscara-Abgleichs für die Liste (None: kein Syscara-Stand)."""
        sy = self.stand.get("syscara")
        if not sy:
            return None
        e = sy["ergebnis"]
        return {**{k: e[k] for k in ("passt", "unsicher", "fehlt", "nur_ab", "abweichung", "ausstattung", "ok", "kurz")},
                "stand": sy.get("stand", ""), "ab": sy.get("ab", "")}

    def _entferne_alte_berichte(self):
        """Berichte der ersten Programmversion und Berichte, deren ABs es nicht mehr gibt."""
        gueltig = {kennung(d) for d in self.abs}
        for name in os.listdir(self.fz.pfad):
            m = re.fullmatch(r"AB-Vergleich_(.+)_gegen_(.+)\.pdf", name)
            verwaist = bool(m) and not (m.group(1) in gueltig and m.group(2) in gueltig)
            if ALTER_BERICHT.match(name) or verwaist:
                try:
                    os.remove(self._datei(name))
                except OSError:
                    pass

    def status(self) -> str:
        kette = self.kette()
        if not kette or self.abs[kette[-1]].get("geprueft"):
            return ERLEDIGT
        return KLAERUNG if self.stand.get("status") == KLAERUNG else OFFEN

    def zeile(self) -> dict:
        """Ein Eintrag für die Arbeitsliste: das Fahrzeug mit seiner neuesten AB."""
        kette, st = self.kette(), self.stand
        neueste = kette[-1]
        info = self.abs[neueste]
        status = self.status()
        if status == ERLEDIGT:
            g = info["geprueft"]
            neue, von, am, art = [], g.get("von", ""), g.get("am", ""), g.get("art", "")
        else:
            g = st.get("vergleich") or {}
            neue, art = self.neue_abs(), ""
            von, am = (st.get("von", ""), st.get("am", "")) if status == KLAERUNG else ("", "")
        gegen, wichtig, nur_info = g.get("gegen", ""), g.get("wichtig", 0), g.get("info", 0)
        if gegen not in self.abs:                        # die verglichene AB wurde inzwischen von Hand gelöscht
            gegen = ""
        ohne_pruefung = status != ERLEDIGT and not g.get("geprueft")       # noch keine AB abgehakt
        ergebnis = (UNLESBAR if status != ERLEDIGT and g.get("unlesbar") else ERSTE if ohne_pruefung
                    else MIT_WICHTIG if wichtig else NUR_INFO if nur_info or g.get("stumm") else KEINE if gegen
                    else PASST_ZU_SYSCARA if g.get("syscara") else ERSTE)
        hinweis = ""
        if status != ERLEDIGT and info.get("andere_nummer"):
            hinweis = (f"Diese AB hat die Auftragsnummer {info['andere_nummer']}, das Fahrzeug {self.fz.auftragsnummer} – "
                       "Tippfehler beim Hersteller oder eine neue Bestellung? Bitte prüfen (wird nicht automatisch erledigt).")
        elif status != ERLEDIGT and g.get("unlesbar"):
            hinweis = (f"Eine AB ist gerade nicht lesbar ({g['unlesbar']}) – z. B. noch nicht von OneDrive geladen. "
                       "Der Vergleich wird beim nächsten Laden wiederholt.")
        elif status == KLAERUNG and st.get("klaerung_bei") in self.abs and st.get("klaerung_bei") != neueste:
            hinweis = "Seit der Klärung ist eine neue AB eingegangen."
        elif ohne_pruefung and st.get("syscara"):
            hinweis = ("" if len(kette) == 1 else          # bei der ersten AB spricht der Abgleich mit Syscara für sich
                       "Noch keine AB als geprüft abgehakt – hier unten der Abgleich der neuesten AB mit Syscara, danach "
                       "die Änderungen seit der ersten AB. Schon eine AB geprüft? Unten bei „Alle ABs“ abhaken.")
        elif ohne_pruefung:
            hinweis = ("Erste AB – mit Syscara abgleichen (oder den Syscara-Export einlesen, dann macht ODIN das)."
                       if len(kette) == 1 else
                       "Noch keine AB als geprüft abgehakt – die neueste mit Syscara abgleichen. Darunter siehst du, "
                       "was sich seit der ersten AB geändert hat. Schon eine AB geprüft? Unten bei „Alle ABs“ abhaken.")
        eingang = max((self.abs[d].get("eingang", "") for d in (neue or [neueste])), default="")
        gegen_info = self.abs.get(gegen, {})
        # Vergleichsbasis: eine abgehakte AB oder nur die erste (bei „erledigt“ zählt, ob sie selbst abgehakt ist)
        basis_geprueft = bool(gegen_info.get("geprueft")) if status == ERLEDIGT else not ohne_pruefung
        return {"fahrzeug": self.fz.als_dict(), "status": status, "ergebnis": ergebnis,
                "datei": neueste, "datum": info.get("datum", ""), "fassung": info.get("fassung", 0),
                "belegart": info.get("belegart", ""), "liefertermin": info.get("liefertermin", ""),
                "gegen": gegen, "gegen_datum": gegen_info.get("datum", ""), "gegen_fassung": gegen_info.get("fassung", 0),
                "neue_abs": len(neue), "anzahl_abs": len(kette), "wichtig": wichtig, "info": nur_info,
                "stichworte": g.get("stichworte", []), "kurz": g.get("kurz", []),
                "gegen_art": ("geprueft" if basis_geprueft else "erste") if gegen else "",
                "notiz": st.get("notiz", ""), "von": von, "am": am,
                "art": art, "automatisch": art == AUTOMATISCH, "hinweis": hinweis, "eingang": eingang,
                "syscara": self.syscara_kurz(), "gegen_syscara": bool(status == ERLEDIGT and g.get("syscara")),
                "kommission": next((self.abs[d].get("kommission") for d in reversed(kette) if self.abs[d].get("kommission")), "")}

    def setze_status(self, status: str = None, notiz: str = None, datei: str = None) -> dict:
        """Erledigt: die neueste AB wird zum geprüften Stand. Klärung: bleibt offen, mit Notiz.
        Wieder öffnen: der geprüfte Stand fällt auf die AB davor zurück."""
        kette = self.kette()
        if not kette:
            raise ValueError("In diesem Fahrzeugordner liegt keine AB.")
        neueste, st = kette[-1], self.stand
        if datei and datei != neueste:
            raise ValueError("Inzwischen ist eine neuere AB eingegangen – bitte die Ansicht neu laden.")
        self._bewerte()
        if status and status != self.status():
            if status == ERLEDIGT:
                v = st.get("vergleich") or {}
                self.markiere_geprueft(neueste, MANUELL, gegen=v.get("gegen", ""), wichtig=v.get("wichtig", 0),
                                       info=v.get("info", 0), stichworte=v.get("stichworte", []), kurz=v.get("kurz", []))
                st.update(status="", offen_gelassen="", klaerung_bei="")
            else:
                self.abs[neueste].pop("geprueft", None)     # war erledigt: zurück auf den Stand davor
                st.update(status=KLAERUNG if status == KLAERUNG else "", klaerung_bei=neueste,
                          offen_gelassen=neueste, von=benutzer(), am=jetzt())
        if notiz is not None:
            st["notiz"] = notiz
        self._bewerte()
        self.speichern()
        return self.zeile()

    def hake_ab(self, datei: str, geprueft: bool) -> dict:
        """Eine einzelne AB als geprüft abhaken (oder den Haken entfernen). Danach wird die neueste AB
        automatisch gegen die neueste abgehakte verglichen."""
        if datei not in self.abs:
            raise FileNotFoundError(f"{datei} gibt es in diesem Fahrzeugordner nicht (mehr).")
        neueste, st = self.kette()[-1], self.stand
        if geprueft and not self.abs[datei].get("geprueft"):
            v = (st.get("vergleich") or {}) if datei == neueste else {}
            self.markiere_geprueft(datei, MANUELL, **({k: v.get(k) for k in ("gegen", "wichtig", "info", "stichworte", "kurz")
                                                      if k in v} if v.get("neu") == datei else {}))
            if datei == neueste:
                st.update(status="", offen_gelassen="", klaerung_bei="")
        elif not geprueft and self.abs[datei].pop("geprueft", None) and datei == neueste:
            st["offen_gelassen"] = neueste                                  # nicht gleich wieder automatisch
        self._bewerte()
        self.speichern()
        return self.zeile()

    def _migriere(self):
        """Format 1 (Status je AB) -> Format 2 (Status je Fahrzeug): von Hand erledigte ABs gelten als geprüft."""
        notizen = []
        for d in sorted(self.pruefungen, key=lambda d: self.abs.get(d, {}).get("datum", "")):
            p = self.pruefungen[d]
            if d in self.abs and p.get("status") == ERLEDIGT and not p.get("automatisch"):
                self.abs[d]["geprueft"] = {"art": MANUELL, "von": p.get("von", ""), "am": p.get("am", ""),
                                           "gegen": p.get("gegen", ""), "wichtig": p.get("wichtig", 0),
                                           "info": p.get("info", 0), "stichworte": p.get("stichworte", [])}
            elif p.get("status") == KLAERUNG:
                self.stand.update(status=KLAERUNG, klaerung_bei=d, von=p.get("von", ""), am=p.get("am", ""))
            if p.get("notiz"):
                notizen.append(p["notiz"])
            for k in ("status", "von", "notiz", "automatisch", "hinweis"):
                p.pop(k, None)
        if notizen:
            self.stand["notiz"] = " · ".join(dict.fromkeys(notizen))
        self.daten.pop("aktuell", None)
        self.daten["format"] = 2
        self.migriert = True


# ---------------- Ablage ----------------

class Fahrzeugablage:
    def __init__(self, wurzel: str):
        self.wurzel = wurzel

    # ---------------- Pfade ----------------
    @property
    def eingang(self):
        return os.path.join(self.wurzel, EINGANG)

    @property
    def mailberichte(self):
        return os.path.join(self.wurzel, MAILBERICHTE)

    def pruefe_wurzel(self):
        if not self.wurzel or not os.path.isdir(self.wurzel):
            raise FileNotFoundError(f"Ordner 'Fahrzeuge' nicht gefunden: {self.wurzel or '(nicht gewählt)'}")
        os.makedirs(self.eingang, exist_ok=True)
        os.makedirs(self.mailberichte, exist_ok=True)     # gleich da, damit Power Automate ihn findet

    # ---------------- Fahrzeuge ----------------
    def alle_fahrzeuge(self) -> list:
        fahrzeuge = []
        if not os.path.isdir(self.wurzel):
            return fahrzeuge
        for jahr in sorted(os.listdir(self.wurzel)):
            jahr_pfad = os.path.join(self.wurzel, jahr)
            if not (re.fullmatch(r"\d{4}", jahr) and os.path.isdir(jahr_pfad)):
                continue
            for h_ordner in sorted(os.listdir(jahr_pfad)):
                h_pfad = os.path.join(jahr_pfad, h_ordner)
                if not os.path.isdir(h_pfad):
                    continue
                hersteller = next((h for h in HERSTELLER if ORDNERNAME.get(h, h) == h_ordner), h_ordner)
                for f in sorted(os.listdir(h_pfad)):
                    f_pfad = os.path.join(h_pfad, f)
                    if os.path.isdir(f_pfad):
                        iid, nr = zerlege_ordnername(f)
                        fahrzeuge.append(Fahrzeug(f_pfad, jahr, hersteller, iid, nr))
        return fahrzeuge

    def finde(self, *nummern) -> Fahrzeug:
        """Der Ordner, der die meisten der Nummern trägt (z. B. lieber „DRM00999_1234560“ als „DRM00999“)."""
        treffer = self.alle_treffer(*nummern)
        return treffer[0] if treffer else None

    def alle_treffer(self, *nummern) -> list:
        gesucht = {n.strip().upper() for n in nummern if n and n.strip()}
        if not gesucht:
            return []
        treffer = [f for f in self.alle_fahrzeuge() if f.nummern & gesucht]
        # die Auftragsnummer des Herstellers zählt mehr als die Interne ID (die tippt der Händler, da passieren Tippfehler)
        return sorted(treffer, key=lambda f: (-(bool(f.auftragsnummer) and f.auftragsnummer.upper() in gesucht),
                                              -len(f.nummern & gesucht), -len(f.nummern)))

    def fahrzeug_zu_pfad(self, pfad: str) -> Fahrzeug:
        pfad = os.path.normpath(pfad)
        return next((f for f in self.alle_fahrzeuge() if os.path.normpath(f.pfad) == pfad), None)

    @gesperrt
    def lege_an(self, hersteller: str, jahr: str, interne_id: str = "", auftragsnummer: str = "", weitere=()):
        """Legt den Fahrzeugordner an. Gibt (Fahrzeug, neu_angelegt) zurück.

        'weitere' sind zusätzliche Nummern (z. B. Hersteller3 POVAB-Nr.), unter denen ein vorhandener
        Ordner gefunden werden soll."""
        roh = (interne_id or "").strip()
        interne_id = extrahiere_interne_id(roh) or (roh if ist_interne_id(roh) else "")
        if roh and not interne_id:
            raise ValueError(f"„{roh}“ ist keine Interne ID. Bitte im Format wie DRM00285 eingeben oder leer lassen.")
        auftragsnummer = (auftragsnummer or "").strip()
        if not (interne_id or auftragsnummer):
            raise ValueError("Mindestens eine Nummer angeben (Interne ID oder Auftragsnummer).")
        if not re.fullmatch(r"\d{4}", str(jahr)):
            raise ValueError("Jahr bitte vierstellig angeben, z. B. 2026.")
        treffer = self.alle_treffer(interne_id, auftragsnummer, *weitere)
        if treffer:
            vorhanden = treffer[0]
            for anderer in treffer[1:]:          # dasselbe Fahrzeug in zwei Ordnern (z. B. erst nur ID, dann nur Nr.)
                if anderer.hersteller == vorhanden.hersteller and not (
                        anderer.auftragsnummer and vorhanden.auftragsnummer
                        and anderer.auftragsnummer != vorhanden.auftragsnummer):
                    self._fuehre_zusammen(anderer, vorhanden)
                    vorhanden = Fahrzeug(vorhanden.pfad, vorhanden.jahr, vorhanden.hersteller,
                                         vorhanden.interne_id or anderer.interne_id,
                                         vorhanden.auftragsnummer or anderer.auftragsnummer)
            return self.ergaenze_nummern(vorhanden, interne_id, auftragsnummer), False
        pfad = os.path.join(self.wurzel, str(jahr), ORDNERNAME.get(hersteller, hersteller),
                            ordnername(interne_id, auftragsnummer))
        os.makedirs(pfad)
        return Fahrzeug(pfad, str(jahr), hersteller, interne_id, auftragsnummer), True

    def ergaenze_nummern(self, fz: Fahrzeug, interne_id: str = "", auftragsnummer: str = "") -> Fahrzeug:
        """Benennt den Ordner um, wenn eine bisher fehlende Nummer bekannt wird."""
        neue_id = fz.interne_id or (interne_id or "").strip()
        neue_nr = fz.auftragsnummer or (auftragsnummer or "").strip()
        neuer_name = ordnername(neue_id, neue_nr)
        if neuer_name == fz.name:
            return fz
        ziel = os.path.join(os.path.dirname(fz.pfad), neuer_name)
        if os.path.exists(ziel):                   # gibt es schon: zusammenführen statt zwei Ordner zu behalten
            return self._benenne_um(fz, neue_id, neue_nr)
        os.rename(fz.pfad, ziel)
        return Fahrzeug(ziel, fz.jahr, fz.hersteller, neue_id, neue_nr)

    def _verschiebe_ab(self, von: Fahrzeug, datei: str, nach: Fahrzeug) -> str:
        """Verschiebt eine AB samt Akte-Eintrag (z. B. „geprüft“) in einen anderen Fahrzeugordner."""
        alt, neu = Akte(von), Akte(nach)
        quelle, ziel = os.path.join(von.pfad, datei), os.path.join(nach.pfad, datei)
        if os.path.exists(ziel) and filecmp.cmp(quelle, ziel, shallow=False):
            os.remove(quelle)                                          # dieselbe Datei gibt es dort schon
        else:
            if os.path.exists(ziel):
                ziel = self._freier_name(nach.pfad, os.path.splitext(datei)[0], ".pdf")
            shutil.move(quelle, ziel)
        name = os.path.basename(ziel)
        eintrag = alt.abs.pop(datei, None)
        alt.pruefungen.pop(datei, None)
        if eintrag:
            vorhanden = neu.abs.setdefault(name, eintrag)
            if eintrag.get("geprueft") and not vorhanden.get("geprueft"):
                vorhanden["geprueft"] = eintrag["geprueft"]
        alt.speichern()
        neu.speichern()
        return name

    def _benenne_um(self, fz: Fahrzeug, interne_id: str, auftragsnummer: str) -> Fahrzeug:
        """Benennt einen Ordner um; gibt es den Zielordner schon, wird zusammengeführt."""
        ziel = Fahrzeug(os.path.join(os.path.dirname(fz.pfad), ordnername(interne_id, auftragsnummer)),
                        fz.jahr, fz.hersteller, interne_id, auftragsnummer)
        if not os.path.exists(ziel.pfad):
            os.rename(fz.pfad, ziel.pfad)
            Akte(ziel).aktualisiere()
        else:
            self._fuehre_zusammen(fz, ziel)
        return ziel

    def _fuehre_zusammen(self, von: Fahrzeug, nach: Fahrzeug):
        """Legt zwei Ordner desselben Fahrzeugs zusammen. Nichts geht verloren: ABs samt Haken wandern mit,
        andere Dateien und Unterordner (Bestellung, Fotos) bekommen bei gleichem Namen einen freien Namen,
        Klärung und Notiz werden übernommen. Der alte Ordner wird nur entfernt, wenn er danach leer ist."""
        alt_stand = dict(Akte(von).stand)
        for datei in von.ab_dateien():
            self._verschiebe_ab(von, datei, nach)
        for name in os.listdir(von.pfad):
            quelle = os.path.join(von.pfad, name)
            if name == AKTE or name.startswith("AB-Vergleich_") or name.endswith(".tmp"):
                continue                                               # wird neu erzeugt
            ziel = os.path.join(nach.pfad, name)
            if os.path.exists(ziel):
                if os.path.isfile(quelle) and os.path.isfile(ziel) and filecmp.cmp(quelle, ziel, shallow=False):
                    os.remove(quelle)
                    continue
                basis, endung = os.path.splitext(name) if os.path.isfile(quelle) else (name, "")
                ziel = self._freier_name(nach.pfad, basis, endung)
            shutil.move(quelle, ziel)
        akte = Akte(nach)
        st = akte.stand
        if alt_stand.get("notiz") and alt_stand["notiz"] not in (st.get("notiz") or ""):
            st["notiz"] = " · ".join(x for x in (st.get("notiz"), alt_stand["notiz"]) if x)
        if alt_stand.get("status") == KLAERUNG and st.get("status") != KLAERUNG:
            st.update({k: alt_stand.get(k, "") for k in ("status", "klaerung_bei", "offen_gelassen", "von", "am")})
        akte.aktualisiere()
        for name in (AKTE,) + tuple(n for n in os.listdir(von.pfad) if n.startswith("AB-Vergleich_") or n.endswith(".tmp")):
            try:
                os.remove(os.path.join(von.pfad, name))
            except OSError:
                pass
        try:
            os.rmdir(von.pfad)                                         # nur wenn wirklich leer
        except OSError:
            pass

    @gesperrt
    def bereinige_ordnernamen(self) -> list:
        """Repariert Ordner, deren Interne ID keine ist:
        - 'VFW-b1-DRM00285_1448596' wird zu 'DRM00285_1448596',
        - 'Kunde_1234567' (Freitext aus dem Bestelltext) wird zu '1234567'. ABs anderer Fahrzeuge, die nur
          wegen desselben Freitexts dort gelandet sind, kommen in ihre eigenen Ordner.
        Gibt es den richtigen Ordner schon, wird zusammengeführt. Der Prüfstand wandert mit."""
        meldungen = []
        for fz in self.alle_fahrzeuge():
            if not fz.interne_id or ist_interne_id(fz.interne_id):
                continue
            sauber = extrahiere_interne_id(fz.interne_id)
            if not sauber:
                for datei in fz.ab_dateien():
                    ab = lies(os.path.join(fz.pfad, datei))
                    if ab.auftragsnummer and ab.auftragsnummer != fz.auftragsnummer:
                        jahr = ab.modelljahr or (ab.iso_datum[:4] if ab.iso_datum else fz.jahr)
                        nach, _ = self.lege_an(fz.hersteller, jahr, ab.interne_id, ab.auftragsnummer, ab.weitere_nummern)
                        self._verschiebe_ab(fz, datei, nach)
                        Akte(nach).aktualisiere()
                        meldungen.append(f"{fz.name}/{datei} → {nach.name}")
            if not (sauber or fz.auftragsnummer):
                continue
            neu = self._benenne_um(fz, sauber, fz.auftragsnummer)
            meldungen.append(f"{fz.name} → {neu.name}")
        return meldungen

    @staticmethod
    def schreibe_neu(ordner, basis, endung, daten: bytes) -> str:
        """Legt eine Datei mit freiem Namen an – auch wenn gleichzeitig eine gleichnamige kommt
        (exklusiv anlegen statt erst prüfen und dann schreiben). Gibt den Pfad zurück."""
        n = 1
        while True:
            ziel = os.path.join(ordner, basis + endung if n == 1 else f"{basis}_{n}{endung}")
            try:
                with open(ziel, "xb") as f:
                    f.write(daten)
                return ziel
            except FileExistsError:
                n += 1

    @staticmethod
    def _freier_name(ordner, basis, endung):
        ziel = os.path.join(ordner, basis + endung)
        n = 2
        while os.path.exists(ziel):
            ziel = os.path.join(ordner, f"{basis}_{n}{endung}")
            n += 1
        return ziel

    # ---------------- Übersicht und Status ----------------
    @gesperrt
    def akte(self, fz: Fahrzeug) -> Akte:
        """Akte eines Fahrzeugs, abgeglichen mit den PDFs im Ordner."""
        akte = Akte(fz)
        if akte.braucht_aktualisierung():
            akte.aktualisiere()           # Ordner aus älterer Version, von Hand geändert oder etwas nachzuholen
        elif akte._bewerte():             # z. B. Vergleich aus älterer Programmversion
            akte.speichern()
        return akte

    def _fahrzeug(self, fahrzeug_pfad: str) -> Fahrzeug:
        fz = self.fahrzeug_zu_pfad(fahrzeug_pfad)
        if not fz:
            raise FileNotFoundError("Fahrzeugordner nicht gefunden – wurde er umbenannt? Bitte neu laden.")
        return fz

    @gesperrt
    def uebersicht(self) -> list:
        """Arbeitsliste: ein Eintrag pro Fahrzeug mit AB. Ein Fahrzeug, dessen Akte gerade gesperrt oder kaputt
        ist, fehlt nur dieses eine Mal – die anderen werden trotzdem angezeigt."""
        zeilen = []
        self.uebersprungen = []
        for fz in self.alle_fahrzeuge():
            try:
                akte = self.akte(fz)
                if akte.abs:
                    zeilen.append(akte.zeile())
            except AkteGesperrt as fehler:
                self.uebersprungen.append(str(fehler))
            except Exception as fehler:
                self.uebersprungen.append(f"{fz.name}: {fehler}")
        return zeilen

    @gesperrt
    def syscara_uebersicht(self) -> dict:
        """Reiter „Ausstattungsvergleich“: jedes Fahrzeug aus den Syscara-Daten mit dem Ergebnis des Abgleichs
        gegen seine neueste AB, dazu die Fahrzeuge mit AB, die in Syscara fehlen.
        Gruppe: passt, unsicher, abweichung (fehlt / nur in AB / Nummer / AB nicht lesbar), ohne_ab, nicht_in_syscara."""
        daten = sc.lade(self.wurzel)
        schluessel_von = {id(e): k for k, e in daten.items()}
        gefunden, nicht_in_syscara = {}, []
        self.uebersprungen = []
        nicht_lesbar = set()
        for fz in self.alle_fahrzeuge():
            eintrag = sc.finde(daten, fz.interne_id, fz.nummern)
            try:
                akte = self.akte(fz)
                z = akte.zeile() if akte.abs else None
            except Exception as fehler:      # z. B. gerade von OneDrive gesperrt: beim nächsten Laden wieder da
                self.uebersprungen.append(str(fehler) if isinstance(fehler, AkteGesperrt) else f"{fz.name}: {fehler}")
                if eintrag:
                    nicht_lesbar.add(schluessel_von[id(eintrag)])
                continue
            if not eintrag:
                if z:
                    nicht_in_syscara.append({"schluessel": fz.pfad, "gruppe": "nicht_in_syscara", "fahrzeug": fz.als_dict(),
                                             "zeile": z, "syscara": None, "ausstattung": []})
                continue
            key = schluessel_von[id(eintrag)]
            if key not in gefunden or (z and not gefunden[key][1]):          # doppelter Ordner: der mit AB zählt
                gefunden[key] = (fz, z)

        def gruppe(key, z):
            if key in nicht_lesbar and not z:
                return "abweichung"          # Akte gerade nicht lesbar – nicht als „ohne AB“ verstecken
            if not z:
                return "ohne_ab"
            sy = z.get("syscara")
            if not sy or sy.get("fehlt") or sy.get("nur_ab") or sy.get("abweichung"):
                return "abweichung"
            return "unsicher" if sy.get("unsicher") else "passt"

        fahrzeuge = []
        for key, e in daten.items():
            fz, z = gefunden.get(key, (None, None))
            fahrzeuge.append({
                "schluessel": key, "gruppe": gruppe(key, z), "fahrzeug": fz.als_dict() if fz else None, "zeile": z,
                "nicht_lesbar": key in nicht_lesbar and not z,
                "syscara": {k: e.get(k, "") for k in ("interne_id", "hersteller", "baureihe", "modell", "fin",
                                                      "seriennummer", "bestellnummer", "stand", "export")},
                "ausstattung": e.get("ausstattung") or []})
        exporte = sorted(((e.get("stand", ""), e.get("export", "")) for e in daten.values()), reverse=True)
        return {"fahrzeuge": fahrzeuge + nicht_in_syscara,
                "export": {"stand": exporte[0][0], "datei": exporte[0][1]} if exporte else None}

    @gesperrt
    def fahrzeug_zusammenfassung(self) -> list:
        ergebnis = []
        for fz in self.alle_fahrzeuge():
            try:
                akte = self.akte(fz)
                z = akte.zeile() if akte.abs else {}
            except Exception:
                continue
            ergebnis.append({**fz.als_dict(), "anzahl_abs": len(akte.abs), "status": z.get("status", ""),
                             "neue_abs": z.get("neue_abs", 0), "gegen_art": z.get("gegen_art", ""), "letzte_ab": z.get("datum", ""),
                             "liefertermin": z.get("liefertermin", "")})
        return ergebnis

    @gesperrt
    def setze_status(self, fahrzeug_pfad: str, status: str = None, notiz=None, datei: str = None) -> dict:
        if status not in (None, OFFEN, KLAERUNG, ERLEDIGT):
            raise ValueError(f"Unbekannter Status: {status}")
        return self.akte(self._fahrzeug(fahrzeug_pfad)).setze_status(status, notiz, datei)

    def regeln(self) -> list:
        return regelwerk.lade(self.wurzel)

    @gesperrt
    def schalte_stumm(self, fahrzeug_pfad: str, bereich: str, art: str, titel: str = "", beispiel: str = "") -> list:
        """Diese Art Änderung zählt bei diesem Hersteller künftig nicht mehr als wichtig."""
        fz = self._fahrzeug(fahrzeug_pfad)
        return regelwerk.schalte_stumm(self.wurzel, fz.hersteller, bereich, art, titel, beispiel)

    @gesperrt
    def schalte_laut(self, regel_id: str = "", fahrzeug_pfad: str = "", bereich: str = "", art: str = "") -> list:
        hersteller = self._fahrzeug(fahrzeug_pfad).hersteller if fahrzeug_pfad else ""
        return regelwerk.entferne(self.wurzel, regel_id, hersteller, bereich, art)

    @gesperrt
    def hake_ab(self, fahrzeug_pfad: str, datei: str, geprueft: bool) -> dict:
        return self.akte(self._fahrzeug(fahrzeug_pfad)).hake_ab(datei, bool(geprueft))

    @gesperrt
    def details(self, fahrzeug_pfad: str, datei: str = None, gegen: str = None) -> dict:
        """Ohne datei/gegen: die neueste AB gegen die zuletzt geprüfte (bzw. bei erledigten Fahrzeugen der
        Vergleich, der abgehakt wurde). Mit datei und/oder gegen: freier Vergleich, ohne Status zu ändern;
        fehlt gegen, wird die direkte Vorgängerin von datei genommen."""
        fz = self._fahrzeug(fahrzeug_pfad)
        akte = self.akte(fz)
        kette = akte.kette()
        if not kette:
            raise FileNotFoundError("In diesem Fahrzeugordner liegt keine AB.")
        z = akte.zeile()
        # Nur ABs aus diesem Fahrzeugordner – nie ein freier Pfad aus der Oberfläche
        if (datei and datei not in kette) or (gegen and gegen not in kette):
            raise ValueError("Diese AB gehört nicht zu diesem Fahrzeug.")
        frei = bool(datei) or gegen is not None
        neu = datei or z["datei"]
        if not frei:
            gegen = z["gegen"]
        elif gegen is None:
            i = kette.index(neu)
            gegen = kette[i - 1] if i else ""
        if gegen and gegen not in kette:              # geprüfte AB wurde inzwischen von Hand gelöscht
            gegen = ""
        regeln = akte.regeln
        neu_ab = lies(os.path.join(fz.pfad, neu))
        alt_ab = lies(os.path.join(fz.pfad, gegen)) if gegen else None
        unlesbar = [x.fehler for x in (neu_ab, alt_ab) if x is not None and x.fehler]
        aenderungen = vergleiche(alt_ab, neu_ab) if gegen and not unlesbar else []
        regeln_anwenden(aenderungen, regeln, fz.hersteller)
        neue = set(akte.neue_abs()) if z["status"] != ERLEDIGT else set()
        verlauf, nachgerechnet = [], False
        for i, d in enumerate(kette):
            p = akte.pruefungen.get(d, {})
            if i and p and p.get("v") != VERGLEICH_STAND:                    # Einzelvergleich aus älterer Version
                a_vor, a_d = lies(os.path.join(fz.pfad, kette[i - 1])), lies(os.path.join(fz.pfad, d))
                if not (a_vor.fehler or a_d.fehler):
                    einzel = vergleiche(a_vor, a_d)
                    p.update(liste=wichtige_liste(einzel), info=sum(a.stufe == INFO for a in einzel), v=VERGLEICH_STAND)
                    p["regeln"] = None
            if i and p and p.get("regeln") != regelwerk.stempel(regeln, fz.hersteller) and p.get("ergebnis") != UNLESBAR:
                wende_regeln_an(p, regeln, fz.hersteller)
                p["ergebnis"] = MIT_WICHTIG if p["wichtig"] else NUR_INFO if (p.get("info") or p.get("stumm")) else KEINE
                nachgerechnet = True
            verlauf.append({"datei": d, **akte.abs[d], "vorgaenger": kette[i - 1] if i else "", "neu": d in neue,
                            "einzel": {k: p.get(k) for k in ("ergebnis", "wichtig", "info", "stichworte", "kurz", "bericht")}})
        if nachgerechnet:
            akte.speichern()
        return {"fahrzeug": fz.als_dict(), "zeile": z, "datei": neu, "gegen": gegen, "frei": frei,
                "aenderungen": aenderungen, "unlesbar": unlesbar[0] if unlesbar else "",
                "hinweise": [f"{h.artikel}: {h.text}" for h in neu_ab.hinweise],
                "kopf": neu_ab.kopf, "verlauf": verlauf, "syscara": self._syscara_details(akte)}

    @staticmethod
    def _syscara_details(akte) -> dict:
        sy = akte.stand.get("syscara")
        if not sy:
            return None
        return {"ab": sy["ab"], "stand": sy.get("stand", ""), "export_datei": sy.get("export_datei", ""),
                **sy["ergebnis"],
                "positionen": [{"pos": p["pos"], "artikel": p["artikel"], "text": p["text"], "preis": sc._preis(p)}
                               for p in sy["auszug"]["positionen"]]}

    @gesperrt
    def bericht(self, fahrzeug_pfad: str, datei: str, gegen: str, bericht_schreiben) -> str:
        """Vergleich zweier ABs als PDF im Fahrzeugordner (wird bei Bedarf erzeugt)."""
        fz = self._fahrzeug(fahrzeug_pfad)
        kette = self.akte(fz).kette()
        if datei not in kette or gegen not in kette:
            raise ValueError("Diese AB gehört nicht zu diesem Fahrzeug.")
        pfad = os.path.join(fz.pfad, berichtsname(datei, gegen))
        alt, neu = lies(os.path.join(fz.pfad, gegen)), lies(os.path.join(fz.pfad, datei))
        if alt.fehler or neu.fehler:          # sonst stünde im PDF „alles neu“
            raise ValueError(f"Der Vergleich geht gerade nicht – eine AB ist nicht lesbar ({alt.fehler or neu.fehler}).")
        # immer neu schreiben: Stummschalt-Regeln können sich seit dem letzten Mal geändert haben
        bericht_schreiben(pfad, fz, alt, neu, regeln_anwenden(vergleiche(alt, neu), Akte(fz).regeln, fz.hersteller))
        return pfad

    @gesperrt
    def staende(self, nummern_listen) -> list:
        """Aktueller Stand (Zeile + Gesamtänderungen) der Fahrzeuge, zu denen eine der Nummernmengen passt."""
        ergebnis = []
        for fz in self.alle_fahrzeuge():
            if not any(n & fz.nummern for n in nummern_listen):
                continue
            try:
                akte = self.akte(fz)
            except Exception:
                continue
            if not akte.abs:
                continue
            z = akte.zeile()
            aenderungen = []
            if z["gegen"] and z["status"] != ERLEDIGT and z["gegen"] in akte.abs:
                alt, neu = lies(os.path.join(fz.pfad, z["gegen"])), lies(os.path.join(fz.pfad, z["datei"]))
                if not (alt.fehler or neu.fehler):
                    aenderungen = regeln_anwenden(vergleiche(alt, neu), akte.regeln, fz.hersteller)
            ergebnis.append((z, aenderungen))
        return ergebnis

    # ---------------- Syscara ----------------
    @gesperrt
    def syscara_einlesen(self, quelle, datei: str = "", fortschritt=None) -> dict:
        """Liest einen Syscara-Export ein und gleicht danach alle betroffenen Fahrzeuge ab.
        quelle: Pfad oder Bytes. Passt bei einer noch nicht geprüften AB alles, ist sie danach automatisch erledigt."""
        self.pruefe_wurzel()
        export = sc.lies_export(quelle, datei)
        if export.fehler:
            raise ValueError(f"{export.datei}: {export.fehler}")
        aenderung = sc.speichere_export(self.wurzel, export, benutzer())
        melde = fortschritt or (lambda *a: None)
        erg = {"datei": export.datei, "stand": export.stand, "fahrzeuge": len(export.fahrzeuge),
               "neu": len(aenderung["neu"]), "aktualisiert": len(aenderung["aktualisiert"]),
               "aelter": len(aenderung["aelter"]), "mit_ab": 0, "ohne_ab": [], "passt": 0, "abweichung": 0,
               "automatisch": 0, "offen": 0, "nicht_lesbar": []}
        daten = sc.lade(self.wurzel)
        alle = self.alle_fahrzeuge()
        for i, sfz in enumerate(export.fahrzeuge):
            melde("abgleichen", i, len(export.fahrzeuge), sfz.interne_id or sfz.bestellnummer)
            eintrag = daten.get(sfz.schluessel)
            if not eintrag:
                continue
            fz = next((f for f in alle if sc.finde({sfz.schluessel: eintrag}, f.interne_id, f.nummern)), None)
            try:
                akte = Akte(fz) if fz else None
                if not (akte and akte.abs):
                    erg["ohne_ab"].append(sfz.interne_id or sfz.bestellnummer)
                    continue
                vorher = akte.status()
                akte = self.akte(fz)
                z = akte.zeile()
            except Exception as fehler:      # z. B. Akte gerade von OneDrive gesperrt: die anderen trotzdem abgleichen
                erg["nicht_lesbar"].append(f"{sfz.interne_id or sfz.bestellnummer}: {fehler}")
                continue
            erg["mit_ab"] += 1
            sy = z.get("syscara") or {}
            erg["passt" if sy.get("ok") else "abweichung"] += 1
            if vorher != ERLEDIGT and z["status"] == ERLEDIGT:
                erg["automatisch"] += 1
            elif z["status"] != ERLEDIGT:
                erg["offen"] += 1
        return erg

    @gesperrt
    def syscara_zuordnen(self, fahrzeug_pfad: str, name: str, positionen) -> dict:
        """Lernt: Syscara-Ausstattung 'name' = diese AB-Positionen (Pos.-Nummern der neuesten AB).
        Leere Liste: steht nie in der AB (z. B. Verkaufsaktion). Gilt für alle Fahrzeuge des Herstellers."""
        fz = self._fahrzeug(fahrzeug_pfad)
        akte = self.akte(fz)
        sy = akte.stand.get("syscara")
        if not sy:
            raise ValueError("Für dieses Fahrzeug gibt es keinen Syscara-Stand.")
        alle = {p["pos"]: p for p in sy["auszug"]["positionen"]}
        gewaehlt = [alle[str(nr)] for nr in positionen or [] if str(nr) in alle]
        if positionen and len(gewaehlt) != len(positionen):
            raise ValueError("Die AB hat sich inzwischen geändert – bitte die Ansicht neu laden und noch einmal zuordnen.")
        zeile = next((z for z in sy["ergebnis"]["zeilen"] if z.get("syscara") == name and z.get("schluessel")), None)
        regelwerk.ordne_syscara_zu(self.wurzel, fz.hersteller, name, zeile["schluessel"] if zeile else sc.schluessel(name),
                                   [{"artikel": p["artikel"], "text": p["text"], "schluessel": sc.schluessel(p["text"])}
                                    for p in gewaehlt])
        return self.akte(fz).zeile()

    @gesperrt
    def syscara_nur_ab(self, fahrzeug_pfad: str, pos: str) -> dict:
        """Lernt: diese AB-Position steht beim Hersteller nie in Syscara."""
        fz = self._fahrzeug(fahrzeug_pfad)
        akte = self.akte(fz)
        sy = akte.stand.get("syscara") or {}
        p = next((p for p in (sy.get("auszug") or {}).get("positionen", []) if p["pos"] == str(pos)), None)
        if not p:
            raise ValueError(f"Position {pos} gibt es in der neuesten AB nicht.")
        regelwerk.ignoriere_nur_ab(self.wurzel, fz.hersteller, p["artikel"], p["text"])
        return self.akte(fz).zeile()

    def zuordnungen(self) -> dict:
        return {"syscara": regelwerk.lade_syscara(self.wurzel), "nur_ab": regelwerk.lade_nur_ab(self.wurzel)}

    @gesperrt
    def zuordnung_entfernen(self, regel_id: str) -> dict:
        regelwerk.entferne_zuordnung(self.wurzel, regel_id)
        return self.zuordnungen()

    # ---------------- AB-Eingang ----------------
    def neue_abs(self) -> list:
        if not os.path.isdir(self.eingang):
            return []
        dateien = [os.path.join(self.eingang, n) for n in os.listdir(self.eingang) if n.lower().endswith(".pdf")]
        return sorted(dateien, key=os.path.getmtime)

    def verarbeite_eingang(self, bericht_schreiben=None, mailbericht_schreiben=None) -> list:
        self.pruefe_wurzel()
        try:
            self.bereinige_ordnernamen()
        except Exception:
            pass                              # z. B. ein gesperrter Ordner – wird beim nächsten Mal wiederholt
        ergebnisse = []
        for pfad in self.neue_abs():
            try:
                ergebnisse.append(self.verarbeite_ab(pfad, bericht_schreiben))
            except FileNotFoundError:
                continue      # gleichzeitig von einem anderen Rechner verarbeitet
            except Exception as fehler:          # eine kaputte AB darf die anderen nicht aufhalten
                noch_da = os.path.exists(pfad)
                ergebnisse.append(EingangsErgebnis(
                    os.path.basename(pfad), "Fehler", noch_im_eingang=noch_da,
                    meldung=f"{type(fehler).__name__}: {fehler}" if noch_da else
                    f"Schon im Fahrzeugordner abgelegt, aber nicht fertig geprüft ({type(fehler).__name__}: {fehler}) – "
                    "wird beim nächsten Laden der Liste nachgeholt."))
        staende = self.staende([e.fahrzeug.nummern for e in ergebnisse if e.fahrzeug])
        for e in ergebnisse:                      # Endstand des Fahrzeugs nach allen ABs dieses Laufs
            if e.fahrzeug:
                e.stand = next((z for z, _ in staende if nummern_von(z["fahrzeug"]) & e.fahrzeug.nummern), e.stand)
        if mailbericht_schreiben and ergebnisse:
            os.makedirs(self.mailberichte, exist_ok=True)
            ziel = self._freier_name(self.mailberichte, f"AB-Pruefung_{dt.datetime.now():%Y-%m-%d_%H-%M-%S}", ".html")
            mailbericht_schreiben(ziel, ergebnisse, staende)
        return ergebnisse

    @staticmethod
    def repariere_base64(pfad: str) -> bool:
        """Macht aus einem von Power Automate als Text gespeicherten Anhang wieder eine echte PDF.

        Vorkommende Formen: reiner Base64-Text ("JVBERi0…"), mit Anführungszeichen, mit
        unsichtbarem BOM am Anfang oder als JSON {"$content-type": …, "$content": "JVBERi0…"}.
        """
        with open(pfad, "rb") as f:
            roh = f.read()
        if roh.startswith(b"%PDF"):
            return False
        text = roh.lstrip(b"\xef\xbb\xbf").strip()
        if text.startswith(b"{"):
            try:
                text = json.loads(text.decode("utf-8")).get("$content", "").encode()
            except (ValueError, AttributeError, UnicodeDecodeError):
                return False
        text = text.strip(b'"\' \r\n\t')
        if not text.startswith(b"JVBER"):          # Base64 von "%PDF"
            return False
        try:
            daten = base64.b64decode(b"".join(text.split()), validate=False)
        except ValueError:
            return False
        if not daten.startswith(b"%PDF"):
            return False
        with open(pfad, "wb") as f:
            f.write(daten)
        return True

    @gesperrt
    def verarbeite_ab(self, pfad: str, bericht_schreiben=None, ab: AB = None, eingang: str = "",
                      quelle: str = "", einlesung: str = "", geprueft: bool = False) -> EingangsErgebnis:
        """Ordnet eine AB-PDF ihrem Fahrzeug zu und prüft sie. Die PDF wird dabei verschoben.

        Beim nachträglichen Einlesen ist 'ab' schon gelesen und 'eingang' die Zeit der Mail;
        geprueft=True: die AB wurde schon von Hand bearbeitet (Vergleichsbasis aus „AB erledigt“)."""
        name = quelle or os.path.basename(pfad)
        if ab is None:
            self.repariere_base64(pfad)
            ab = lies_ab(pfad)
        if ab.fehler:
            ziel_ordner = os.path.join(self.eingang, NICHT_ERKANNT)
            os.makedirs(ziel_ordner, exist_ok=True)
            basis, endung = os.path.splitext(name)
            bewege(pfad, self._freier_name(ziel_ordner, basis, endung))
            return EingangsErgebnis(name, "Nicht erkannt", ab=ab, meldung=ab.fehler)

        jahr = ab.modelljahr or (ab.iso_datum[:4] if ab.iso_datum else str(dt.date.today().year))
        fz, neu = self.lege_an(ab.hersteller, jahr, ab.interne_id, ab.auftragsnummer, ab.weitere_nummern)
        akte = Akte(fz)

        datum = ab.iso_datum or dt.date.today().isoformat()
        for v in fz.ab_dateien():
            v_pfad = os.path.join(fz.pfad, v)
            gleiche_datei = filecmp.cmp(pfad, v_pfad, shallow=False)
            vorhandene = lies(v_pfad)
            gleiche_fassung = (akte.abs.get(v, {}).get("datum", v[:10]) == datum
                               and akte.abs.get(v, {}).get("fassung", ab.fassung) == ab.fassung
                               and not vorhandene.fehler and not vergleiche(vorhandene, ab))
            if gleiche_datei or gleiche_fassung:
                os.remove(pfad)
                if geprueft:                      # schon vorhanden, aber laut „AB erledigt“ bearbeitet
                    akte.aktualisiere()
                    if not akte.abs[v].get("geprueft"):
                        akte.markiere_eingelesen(v)
                        akte.aktualisiere()
                return EingangsErgebnis(name, "Doppelt", fz, ab, neue_datei=v, stand=akte.zeile() if akte.abs else None,
                                        meldung=f"Gleiche Fassung wie {v} – aus dem Eingang entfernt.")

        ziel = self._freier_name(fz.pfad, f"{datum}_AB", ".pdf")
        bewege(pfad, ziel)
        neue_datei = os.path.basename(ziel)
        merke(ziel, replace(ab, datei=neue_datei))     # nicht noch einmal auslesen
        akte.registriere(neue_datei, ab, quelle=name, eingang=eingang, einlesung=einlesung)
        if geprueft:
            akte.markiere_eingelesen(neue_datei)
        neu_berechnet = akte.aktualisiere(bericht_schreiben)
        return EingangsErgebnis(name, "Eingeordnet", fz, ab, neue_datei=neue_datei,
                                pruefung=akte.pruefungen.get(neue_datei, {}), stand=akte.zeile(),
                                neu_geprueft=[d for d in neu_berechnet if d != neue_datei], ordner_neu=neu)

    # ---------------- Nachträglich einlesen ----------------
    def importiere(self, ordner: str = "", basis_ordner: str = "", bericht_schreiben=None,
                   fortschritt=None, abbrechen=None) -> dict:
        """Liest ABs aus Ordnern mit gespeicherten Mails (.msg/.eml) und/oder PDFs ein.

        ordner:       noch nicht bearbeitete ABs (z. B. aus dem Posteingang). Sie werden normal geprüft: pro
                      Fahrzeug die neueste gegen die zuletzt geprüfte AB.
        basis_ordner: schon bearbeitete ABs (z. B. Outlook-Ordner „AB erledigt“), nur als Vergleichsbasis.
                      Genommen werden nur ABs von Fahrzeugen aus 'ordner' oder aus der Ablage – alte
                      Fahrzeuge werden ignoriert. Sie gelten als geprüfter Stand.
        Die Dateien in den Ordnern bleiben unverändert. ABs werden nach Datum sortiert eingeordnet,
        doppelte erkannt (auch dieselbe AB in mehreren Mails), andere Anhänge übersprungen."""
        self.pruefe_wurzel()
        quellen = [(o, basis) for o, basis in ((ordner, False), (basis_ordner, True)) if o]   # Posteingang zuerst
        if not quellen:
            raise ValueError("Bitte einen Ordner wählen.")
        for o, _ in quellen:
            if liegt_in(o, self.wurzel) or liegt_in(self.wurzel, o):
                raise ValueError("Bitte einen Ordner außerhalb von „Fahrzeuge“ wählen, z. B. auf dem Schreibtisch.")
        self.bereinige_ordnernamen()
        melde = fortschritt or (lambda *a: None)
        stopp = abbrechen or (lambda: False)
        kennung = dt.datetime.now().strftime("%Y%m%d%H%M%S")
        beruehrt = []                                     # Nummern der Fahrzeuge, die ABs bekommen haben
        erg = {"dateien": 0, "gelesen": 0, "mails": 0, "anhaenge": 0, "eingeordnet": 0, "basis": 0, "basis_ignoriert": 0, "doppelt": 0,
               "fahrzeuge": 0, "fahrzeuge_neu": 0, "automatisch": 0, "offen": 0, "ohne_vorgaenger": 0,
               "uebersprungen": [], "fehler": [], "abgebrochen": False}
        dateien = [(d, o, basis) for o, basis in quellen for d in finde_einlesbare(o)]
        erg["dateien"] = len(dateien)
        gesehen, keine_ab, kandidaten = {}, set(), []     # gesehen: Prüfsumme -> Index in kandidaten
        relevant = set()                                  # Nummern der Fahrzeuge, für die eine Basis-AB nützt
        for fz in self.alle_fahrzeuge():
            relevant |= fz.nummern

        with tempfile.TemporaryDirectory() as tmp:
            # 1. Mails und PDFs lesen
            for i, (pfad, o, basis) in enumerate(dateien):
                if stopp():
                    erg["abgebrochen"] = True
                    break
                name = os.path.relpath(pfad, o)
                melde("lesen", i, len(dateien), name)
                erg["gelesen"] = i + 1
                if ist_mail(pfad):
                    erg["mails"] += 1
                    mail = lies_mail(pfad)
                    if mail.fehler:
                        erg["fehler"].append({"datei": name, "grund": mail.fehler})
                        continue
                    if not mail.pdfs and not basis:
                        erg["uebersprungen"].append({"datei": name, "grund": "Keine PDF im Anhang"})
                    pdfs, eingang = mail.pdfs, mail.datum
                else:
                    try:
                        with open(pfad, "rb") as f:
                            pdfs = [(os.path.basename(pfad), f.read())]
                        eingang = dt.datetime.fromtimestamp(os.path.getmtime(pfad)).isoformat(timespec="seconds")
                    except OSError as fehler:             # z. B. gesperrt oder nur online in OneDrive
                        erg["fehler"].append({"datei": name, "grund": f"nicht lesbar: {fehler}"})
                        continue
                for anhang, daten in pdfs:
                    erg["anhaenge"] += 1
                    pruefsumme = hashlib.sha1(daten).hexdigest()
                    if pruefsumme in gesehen:
                        k = kandidaten[gesehen[pruefsumme]]
                        if basis and not k[4]:                 # liegt auch in „AB erledigt“: schon bearbeitet
                            kandidaten[gesehen[pruefsumme]] = k[:4] + (True,)
                        erg["doppelt"] += 1
                        continue
                    if pruefsumme in keine_ab:
                        continue
                    tmp_pfad = os.path.join(tmp, pruefsumme + ".pdf")
                    with open(tmp_pfad, "wb") as f:
                        f.write(daten)
                    if basis:                                  # erst schnell prüfen, ob das Fahrzeug gebraucht wird
                        kopf = lies_ab_kopf(tmp_pfad, datei=anhang)
                        if kopf.fehler or not (ab_nummern(kopf) & relevant):
                            erg["basis_ignoriert"] += 0 if kopf.fehler else 1
                            keine_ab.add(pruefsumme)
                            os.remove(tmp_pfad)
                            continue
                    ab = lies_ab(tmp_pfad, datei=anhang)
                    if ab.fehler:
                        keine_ab.add(pruefsumme)
                        if not basis:
                            erg["uebersprungen"].append({"datei": name if anhang == os.path.basename(name)
                                                         else f"{name} → {anhang}", "grund": ab.fehler})
                        os.remove(tmp_pfad)
                        continue
                    if not basis:
                        relevant |= ab_nummern(ab)
                    gesehen[pruefsumme] = len(kandidaten)
                    kandidaten.append((ab, tmp_pfad, eingang, anhang, basis))

            # 2. Nach Datum sortiert einordnen – so wächst jede Kette von alt nach neu. Bei gleicher Fassung
            #    zuerst die schon bearbeitete; die zweite Kopie wird dann als doppelt erkannt.
            kandidaten.sort(key=lambda k: (k[0].iso_datum or "9999", k[0].fassung, not k[4], k[2]))
            for i, (ab, tmp_pfad, eingang, anhang, basis) in enumerate(kandidaten):
                if stopp():
                    erg["abgebrochen"] = True
                    break
                melde("einordnen", i, len(kandidaten), ab.interne_id or ab.auftragsnummer or anhang)
                try:
                    e = self.verarbeite_ab(tmp_pfad, bericht_schreiben, ab=ab, eingang=eingang, quelle=anhang,
                                           einlesung=kennung, geprueft=basis)
                except Exception as fehler:
                    erg["fehler"].append({"datei": anhang, "grund": f"{type(fehler).__name__}: {fehler}"})
                    continue
                if e.fahrzeug and e.status != "Doppelt":
                    beruehrt.append(e.fahrzeug.nummern)
                if e.status == "Doppelt":
                    erg["doppelt"] += 1
                else:
                    erg["basis" if basis else "eingeordnet"] += 1
                    erg["fahrzeuge_neu"] += int(e.ordner_neu)

        # 3. Abschluss: Stand der beteiligten Fahrzeuge zählen
        melde("abschluss", 0, 0, "")
        for z, _ in self.staende(beruehrt):
            erg["fahrzeuge"] += 1
            if z["status"] == OFFEN:
                erg["offen"] += 1
                erg["ohne_vorgaenger"] += int(z["ergebnis"] == ERSTE)
            elif z["status"] == ERLEDIGT and z["art"] == AUTOMATISCH:
                erg["automatisch"] += 1
        return erg
