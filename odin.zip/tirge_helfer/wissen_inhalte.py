"""
Startinhalte für „Wissen & Einarbeitung“ – werden einmal angelegt, wenn der Speicher noch leer ist.

Alles hier ist ein ENTWURF: allgemeines Branchenwissen als Gerüst, damit niemand vor einem leeren Blatt sitzt. Es
steht in der Oberfläche als „Entwurf – noch nicht geprüft“, bis jemand aus dem Betrieb es durchgesehen hat. Bewusst
keine erfundenen Klickwege für CaraCamp und keine Namen. Was zu ODIN, zu den Auftragsbestätigungen und zum
Syscara-Export steht, stammt aus der README dieses Programms; die Anleitungen zum HG-Portal stammen aus den
Schulungen der HG Academy (wissen_hg.py).

Lieferungen: Was mit einer späteren Fassung dazukommt, trägt „lieferung“ (> 1). Ein schon vorhandener Speicher bekommt
es einmal nachgeliefert (stand.json merkt sich die Lieferung); gelöscht bleibt gelöscht.

Schritte: (Text, „woran erkenne ich, dass es stimmt“, Notiz ist Pflicht)
"""

from . import wissen_hg as hg

LIEFERUNG = 4                     # 1: erste Startinhalte, 2: Anleitungen aus der HG Academy,
                                  # 3: Verweise auf „Beirat & Coaching“ in den Einarbeitungsplänen Verkauf,
                                  # 4: Hausregel VERKAUF-001 – „Probefahrt“ → „Besichtigung“ im Plan Verkauf (Azubi)

FEHLT = "Hier fehlt noch euer Wissen – am besten 10 Minuten diktieren."
ERGAENZEN = "Entwurf: bitte so ergänzen, wie es bei euch wirklich läuft."

ABLAEUFE = [
    {
        "titel": "Neufahrzeug: von der Anlieferung bis in die Reihe (Check-in)",
        "zweck": "Jedes Neufahrzeug kommt auf demselben Weg in den Bestand: Transportschäden sind gesichert, das "
                 "Fahrzeug entspricht der Bestellung, es ist in Syscara und in der Bestandsliste eingetragen und steht "
                 "verkaufsbereit in der Reihe – egal, wer an dem Tag da ist.",
        "bereich": "Verkauf", "rolle": "Disposition",
        "schritte": [
            ("Anlieferung annehmen: Fahrzeug gemeinsam mit dem Fahrer rundum ansehen, bevor er weiterfährt",
             "Front, beide Seiten, Heck, Dach (soweit einsehbar), Scheiben, Felgen und Unterkante sind bei gutem Licht "
             "angesehen – auch wenn der Fahrer es eilig hat.", False),
            ("Schäden und Fehlendes auf dem Frachtbrief vermerken, vom Fahrer gegenzeichnen lassen und fotografieren",
             "Der Vermerk steht auf beiden Ausfertigungen, die Fotos liegen im Fahrzeugordner. Ohne Vermerk bei der "
             "Übernahme wird eine spätere Reklamation beim Spediteur schwierig. In die Notiz: Schaden ja/nein und was.",
             True),
            ("Fahrgestellnummer am Fahrzeug mit dem Frachtbrief und der Auftragsbestätigung vergleichen",
             "Alle 17 Stellen stimmen überein.", False),
            ("Papiere, Schlüssel und loses Zubehör auf Vollständigkeit prüfen",
             "Was laut Lieferschein dabei sein soll, ist da: Schlüssel (Anzahl notieren), Bordmappe mit Anleitungen, "
             "Serviceunterlagen, Bescheinigungen, loses Zubehör. Fahrzeugpapiere kommen je nach Hersteller und "
             "Finanzierung getrennt – hier eintragen, wie es bei euch läuft.", True),
            ("Fahrzeug gegen die Auftragsbestätigung abgleichen: Modell, Grundriss, Farben, Motor, Pakete, Sonderausstattung",
             "Jede Position der neuesten Auftragsbestätigung ist am Fahrzeug gefunden oder als Abweichung notiert. "
             "Die neueste Fassung steht in ODIN unter „Auftragsbestätigungen“.", True),
            ("Anlieferungsdurchsicht in der Werkstatt nach Vorgabe des Herstellers",
             "Aufbau (Wasser, Gas, Strom, Heizung, Kühlschrank, Fenster, Türen, Klappen) und Basisfahrzeug "
             "(Flüssigkeiten, Reifendruck, Warnleuchten) sind geprüft, das Protokoll liegt im Fahrzeugordner.", False),
            ("Mängel aus der Durchsicht festhalten und dem Hersteller melden – vor der Aufbereitung",
             "Jeder Mangel hat ein Foto und ist gemeldet; wer nachhakt, steht fest.", False),
            ("Check-in in Syscara: Fahrzeug als eingetroffen führen, Nummern und Standort nachtragen",
             "Fahrgestellnummer, Seriennummer, Eingangsdatum und Standort stehen in Syscara. " + ERGAENZEN, False),
            ("Bestandsliste nachtragen: Eingang, Standort, Status",
             "Die Zeile des Fahrzeugs zeigt den Eingang; ODIN liest die Liste beim nächsten Laden. " + ERGAENZEN, False),
            ("Eingang an die Buchhaltung melden (Rechnung, Einkaufsfinanzierung)",
             "Die Rechnung ist dem Fahrzeug zugeordnet; bei finanzierten Fahrzeugen ist der Beginn der Zinsfreiheit bekannt.",
             False),
            ("Garantieanmeldung beim Hersteller – soweit er sie schon beim Eingang verlangt",
             "Der Zeitpunkt ist je Hersteller verschieden (Eingang oder Übergabe an den Kunden). " + ERGAENZEN, False),
            ("Aufbereitung: Transportschutz entfernen, außen waschen, innen reinigen",
             "Keine Folien, Aufkleber und Transportsicherungen mehr; das Fahrzeug ist vorzeigbar.", False),
            ("Fotos für das Inserat machen und ablegen",
             "Außen, innen und Details nach eurer Bildliste; die Bilder liegen dort, wo alle sie finden.", False),
            ("Fließtext und Preisschild erstellen",
             "In ODIN unter „Preisschilder & Texte“. Preis und Ausstattung stimmen mit Syscara überein.", False),
            ("Preisschild ins Fahrzeug, Stellplatz in der Reihe, Schlüssel an ihren Platz – Standort nachtragen",
             "Das Fahrzeug steht dort, wo Syscara und Bestandsliste es führen.", False),
            ("Verkauf informieren: Fahrzeug ist verkaufsbereit (bei Kundenfahrzeug: Kunde und Übergabetermin)",
             "Der zuständige Verkäufer weiß Bescheid.", False),
        ],
    },
    {
        "titel": "Fahrzeug in Syscara anlegen",
        "zweck": "Jedes bestellte Fahrzeug steht einmal und vollständig in Syscara, damit Auftragsbestätigung, "
                 "Ausstattung und Preisschild dazu passen.",
        "bereich": "Verkauf", "rolle": "Disposition",
        "schritte": [
            ("Unterlagen bereitlegen: Bestellung oder Vormerkung des Herstellers", "", False),
            ("Hersteller, Baureihe und Modell wählen", ERGAENZEN, False),
            ("Interne ID nach eurem Schema vergeben",
             "Die Interne ID ist eindeutig. ODIN ordnet Auftragsbestätigungen und den Syscara-Export über sie zu – eine "
             "falsche ID zeigt sich im Ausstattungsvergleich unter „Nicht in Syscara“.", False),
            ("Bestellnummer eintragen; Seriennummer und Fahrgestellnummer nachtragen, sobald sie bekannt sind",
             "Die Nummern stimmen mit der Auftragsbestätigung überein.", False),
            ("Bestellte Ausstattung vollständig erfassen", "Jede bestellte Option ist angehakt.", False),
            ("Preise und Termine eintragen", ERGAENZEN, False),
            ("Gegenprobe: Fahrzeuge aus Syscara exportieren und in ODIN unter „Ausstattungsvergleich“ einlesen",
             "Das Fahrzeug steht dort unter „Passt“ – oder die Abweichungen sind geklärt.", False),
        ],
    },
    {
        "titel": "Auftragsbestätigung lesen und prüfen",
        "zweck": "Keine Änderung des Herstellers an Ausstattung, Preis oder Termin geht unbemerkt durch.",
        "bereich": "Verkauf", "rolle": "Disposition",
        "schritte": [
            ("In ODIN „Auftragsbestätigungen“ öffnen und „Eingang prüfen“ klicken",
             "Neue Auftragsbestätigungen sind ihrem Fahrzeug zugeordnet; die Liste zeigt einen Eintrag je Fahrzeug.", False),
            ("Erste Auftragsbestätigung eines Fahrzeugs: mit Syscara abgleichen (Reiter „Ausstattungsvergleich“)",
             "Modell, jede Ausstattung sowie Serien-, Bestell- und Fahrgestellnummer passen – dann erledigt ODIN die "
             "erste Auftragsbestätigung von selbst.", False),
            ("Wichtige Änderungen ansehen: Ausstattung, Bezeichnungen, Preise, Summe, Zahlungs- und Lieferbedingung, "
             "geänderter Liefertermin",
             "Jede wichtige Änderung ist verstanden: gewollt, oder beim Hersteller reklamiert.", True),
            ("Bei Unklarheit auf „In Klärung“ setzen und notieren, wer nachfragt", "", False),
            ("Kunden informieren, wenn sich Termin, Preis oder Ausstattung für ihn ändert", ERGAENZEN, False),
            ("Auf „Erledigt“ setzen – die neueste Auftragsbestätigung ist dann der geprüfte Stand", "", False),
        ],
    },
    {
        "titel": "Garantiefall abwickeln",
        "zweck": "Der Kunde bekommt eine verlässliche Auskunft, der Hersteller einen vollständigen Antrag, und die "
                 "Erstattung kommt an.",
        "bereich": "Garantie", "rolle": "Garantiesachbearbeitung",
        "schritte": [
            ("Meldung aufnehmen: Kunde, Fahrzeug, Fahrgestellnummer, Kauf- und Übergabedatum, Beschreibung, Fotos",
             "Ein Dritter versteht den Mangel allein aus der Aufnahme.", True),
            ("Einordnen: Herstellergarantie, Gewährleistung, Kulanz oder kein Anspruch",
             "Bei Streit oder Fristen den Fall unter „Rechtsfälle“ anlegen.", False),
            ("Antrag beim Hersteller stellen und die Freigabe abwarten, bevor repariert wird", ERGAENZEN, False),
            ("Teile bestellen und Werkstatttermin mit dem Kunden abstimmen", "", False),
            ("Reparatur durchführen und dokumentieren (Arbeitszeit, Teile, Fotos vorher/nachher)", "", False),
            ("Altteile aufbewahren, bis der Hersteller entschieden hat", ERGAENZEN, False),
            ("Mit dem Hersteller abrechnen und den Eingang der Gutschrift kontrollieren",
             "Die Gutschrift ist da und passt zum Antrag.", False),
            ("Kunden informieren und den Fall schließen", "", False),
        ],
    },
    {
        "titel": "Teile bestellen",
        "zweck": "Das richtige Teil kommt rechtzeitig, und jeder sieht, wofür es bestellt wurde.",
        "bereich": "Teile & Zubehör", "rolle": "Teile & Zubehör",
        "schritte": [
            ("Bedarf klären: Fahrzeug, Fahrgestellnummer, Teilenummer oder genaue Beschreibung, Auftrag oder Kunde", "", False),
            ("Lagerbestand prüfen", "", False),
            ("Lieferanten, Preis und Lieferzeit klären", ERGAENZEN, False),
            ("Bestellen und den zugesagten Liefertermin notieren", "Die Bestellung ist dem Auftrag oder Kunden zugeordnet.", False),
            ("Werkstatt oder Kunden über den Termin informieren", "", False),
            ("Wareneingang prüfen: richtiges Teil, Menge, unbeschädigt",
             "Lieferschein und Teil stimmen überein; Transportschäden sind sofort gemeldet.", False),
            ("Teil dem Auftrag zuordnen und bereitlegen, Rechnung prüfen", "", False),
        ],
    },
    {
        "titel": "Fahrzeugübergabe an den Kunden",
        "zweck": "Der Kunde fährt mit einem fertigen Fahrzeug, vollständigen Papieren und einer guten Einweisung vom Hof.",
        "bereich": "Verkauf", "rolle": "Verkauf",
        "schritte": [
            ("Vor dem Termin: Zahlung, Zulassung und Papiere prüfen",
             "In ODIN unter „Auslieferungen“ steht die Ampel der Übergabe: Teile, Papiere, Zahlung, TÜV, Einbauten.", False),
            ("Bestelltes Zubehör ist montiert, Übergabedurchsicht der Werkstatt ist erledigt", "", False),
            ("Fahrzeug innen und außen übergabefertig reinigen, Gas und Wasser nach Absprache", ERGAENZEN, False),
            ("Einweisung: Gas, Wasser, Strom, Heizung, Kühlschrank, Toilette, Markise, Basisfahrzeug",
             "Der Kunde hat die wichtigsten Handgriffe selbst gemacht.", False),
            ("Papiere, Schlüssel und Bordmappe übergeben", "Anzahl der Schlüssel steht im Protokoll.", False),
            ("Übergabeprotokoll gemeinsam durchgehen und unterschreiben lassen",
             "Offene Punkte stehen mit Termin im Protokoll.", True),
            ("Garantie beim Hersteller auf den Kunden anmelden", ERGAENZEN, False),
            ("Status in Syscara und in der Bestandsliste auf ausgeliefert setzen", "", False),
            ("Nach etwa zwei Wochen nachfragen, ob alles funktioniert", "", False),
        ],
    },
]

_GERUEST = ("## Wofür nutzen wir es\n\n" + FEHLT + "\n\n"
            "## Anmelden\n\nWo der Zugang zu finden ist und wer ihn vergibt – aber keine Passwörter hier hinein.\n\n"
            "## Die häufigsten Aufgaben\n\n1. " + FEHLT + "\n\n"
            "## Stolperfallen\n\n- " + FEHLT)

ANLEITUNGEN = [
    {"titel": "CaraCamp: Grundlagen", "system": "CaraCamp", "kategorie": "Grundlagen", "text": _GERUEST},
    {"titel": "Syscara: Grundlagen", "system": "Syscara", "kategorie": "Grundlagen", "text": _GERUEST},
    {
        "titel": "Syscara: Fahrzeuge exportieren für den Ausstattungsvergleich", "system": "Syscara",
        "kategorie": "Auftragsbestätigungen",
        "text": "ODIN vergleicht die in Syscara bestellte Ausstattung mit der neuesten Auftragsbestätigung.\n\n"
                "## So geht es\n\n"
                "1. In Syscara die Fahrzeuge exportieren (Excel oder CSV) – am besten den ganzen Bestand auf einmal.\n"
                "2. In ODIN den Bereich **Ausstattungsvergleich** öffnen.\n"
                "3. **Syscara-Export einlesen** klicken oder die Datei ins Fenster ziehen.\n"
                "4. Die Liste von oben nach unten durchgehen: Abweichung, Unsicher, Passt, Ohne AB.\n\n"
                "## Was die Ergebnisse bedeuten\n\n"
                "- **Fehlt in AB:** in Syscara bestellt, steht aber nicht in der Auftragsbestätigung.\n"
                "- **Nur in AB:** Position mit Preis, die nicht in Syscara steht.\n"
                "- **Unsicher:** ähnlicher Name – einmal mit „Passt“ bestätigen oder zuordnen, ODIN merkt es sich für "
                "den Hersteller.\n"
                "- **Nicht in Syscara:** Fahrzeug mit Auftragsbestätigung, das im Export fehlt – oft eine falsche "
                "Interne ID in Syscara.\n\n"
                "## Stolperfallen\n\n"
                "- Syscara kürzt lange Ausstattungsnamen im Export (bisher nach etwa 50 Zeichen). ODIN kommt damit "
                "meist zurecht; steht dort „Name in Syscara gekürzt – mehrdeutig“, bitte selbst in der "
                "Auftragsbestätigung nachsehen.\n"
                "- Wo genau der Export in Syscara zu finden ist: " + FEHLT,
    },
    {
        "titel": "Bestandsliste: Aufbau und Pflege", "system": "Bestandsliste", "kategorie": "Grundlagen",
        "text": "ODIN liest die Bestandsliste unter **Datenquellen** ein (Tabellen-Symbol unten links) und sagt dort, "
                "was es verstanden hat. Eingetragen wird weiter in Excel.\n\n"
                "## Wer trägt was ein\n\n" + FEHLT + "\n\n"
                "## Farben und Spalten\n\n" + FEHLT + "\n\n"
                "## Stolperfallen\n\n- " + FEHLT,
    },
    {
        "titel": "ODIN: Auftragsbestätigungen prüfen", "system": "ODIN", "kategorie": "Auftragsbestätigungen",
        "text": "Die Liste hat einen Eintrag je Fahrzeug. Geprüft wird die neueste Auftragsbestätigung gegen die, die "
                "zuletzt als geprüft abgehakt wurde – alle Änderungen seitdem auf einen Blick.\n\n"
                "## Wichtig, Info, nicht verglichen\n\n"
                "- **Wichtig:** Ausstattung, Bezeichnungen, Preise, Summe, Zahlungs- und Lieferbedingung, ein "
                "geänderter Liefertermin.\n"
                "- **Info:** erstmals genannte Werte (Preise, Termin, Fahrgestellnummer), Serien- und Aufbaunummer, "
                "Belegart, Fassung, Bestelltext.\n"
                "- **Nicht verglichen:** Gewichte, Rechtstexte, Bemerkungszeilen ohne Positionsnummer.\n\n"
                "## Status\n\n"
                "- **Erledigt (Taste E):** die neueste Auftragsbestätigung wird der geprüfte Stand.\n"
                "- **In Klärung (Taste K):** bleibt mit Notiz stehen, auch wenn neue Auftragsbestätigungen kommen.\n"
                "- **Wieder öffnen (Taste O):** zurück auf den Stand davor.\n\n"
                "## Stummschalten\n\n"
                "Ist eine Art Änderung bei einem Hersteller immer egal: in der Tabelle auf das Glocken-Symbol klicken. "
                "Sie zählt dann bei allen Fahrzeugen dieses Herstellers nicht mehr als wichtig.",
    },
    {"titel": "Werkstatt: Anlieferungsdurchsicht", "system": "Werkstatt", "kategorie": "Neufahrzeuge",
     "text": "## Was wird geprüft\n\n" + FEHLT + "\n\n## Wo liegt das Protokoll des Herstellers\n\n" + FEHLT +
             "\n\n## Was tun bei einem Mangel\n\n1. Foto machen.\n2. " + FEHLT},
    {
        "titel": "So schreibst du eine gute Anleitung", "system": "Allgemein", "kategorie": "Grundlagen",
        "text": "Eine Anleitung ist gut, wenn jemand Neues die Aufgabe damit **ohne Rückfrage** schafft.\n\n"
                "## So gehst du vor\n\n"
                "1. Eine Aufgabe je Anleitung – lieber fünf kurze als eine lange.\n"
                "2. Die Aufgabe einmal selbst machen und dabei laut mitsprechen oder diktieren.\n"
                "3. Jeden Schritt so nennen, wie er auf dem Bildschirm heißt.\n"
                "4. Am Ende von jemandem ausprobieren lassen, der es noch nie gemacht hat – erst dann auf „geprüft“ setzen.\n\n"
                "## Schreibweise\n\n"
                "- Eine Zeile, die mit „- “ beginnt, wird ein Aufzählungspunkt.\n"
                "- Eine Zeile, die mit „1. “ beginnt, wird ein nummerierter Schritt.\n"
                "- Zwei Sternchen davor und dahinter machen ein Wort **fett**.\n"
                "- Eine Zeile, die mit „## “ beginnt, wird eine Überschrift.\n\n"
                "## Was nicht hineingehört\n\n"
                "- Keine Passwörter und Zugangsdaten – nur, wo sie zu finden sind und wer sie vergibt.\n"
                "- Keine Kundendaten.",
    },
    *({**a, "lieferung": 2} for a in hg.ANLEITUNGEN),
]

# Einarbeitung je Rolle: (Phase, Text, Verweis) – Verweis ist ("anleitung"|"ablauf", Titel aus den Listen oben),
# ("beirat", Kennung eines Moduls aus beirat_inhalte.py) oder None.
# „lieferung_schritte“: Lieferung, mit der die Schritte zuletzt ergänzt oder geändert wurden. Ein mitgelieferter Plan,
# den noch niemand bearbeitet hat, bekommt die neuen Schritte nachgeliefert (hinten angehängt) und geänderte Texte
# und Verweise übernommen; bearbeitete Pläne bleiben, wie sie sind.
_ANKOMMEN = [
    ("tag1", "Begrüßung, Rundgang über das Gelände und Vorstellung im Team", None),
    ("tag1", "Arbeitsplatz, Schlüssel, Arbeitskleidung und Zugänge sind eingerichtet", None),
    ("tag1", "Arbeitszeiten, Pausen, Urlaub und Krankmeldung besprochen", None),
    ("tag1", "Sicherheitsunterweisung: Gelände, Rangieren, Gas, Brandschutz, Erste Hilfe", None),
    ("tag1", "ODIN gezeigt: „Heute & Woche“, „Meine Aufgaben“, „Wissen & Einarbeitung“", None),
]


def _plan(rolle: str, *schritte, lieferung_schritte: int = 1) -> dict:
    return {"rolle": rolle, "schritte": [*_ANKOMMEN, *schritte], "lieferung_schritte": lieferung_schritte}


_CHECKIN = ("ablauf", ABLAEUFE[0]["titel"])
_UEBERGABE = ("ablauf", "Fahrzeugübergabe an den Kunden")
_AB = ("ablauf", "Auftragsbestätigung lesen und prüfen")

PLAENE = [
    _plan("Verkauf",
          ("woche", "Marken, Baureihen und Grundrisse im Bestand kennenlernen", None),
          ("woche", "Syscara: Fahrzeug suchen, Ausstattung und Preis lesen", ("anleitung", "Syscara: Grundlagen")),
          ("woche", "Bei zwei Verkaufsgesprächen und einer Übergabe zuhören", None),
          ("monat", "Angebot und Kaufvertrag erstellen – erst mit Pate, dann allein", None),
          ("monat", "Fahrzeug in Syscara anlegen", ("ablauf", "Fahrzeug in Syscara anlegen")),
          ("monat", "Auftragsbestätigungen lesen und prüfen", _AB),
          ("monat", "Finanzierung, Inzahlungnahme und Zubehör im Gespräch anbieten", None),
          ("tage90", "Fahrzeugübergabe an den Kunden selbst durchführen", _UEBERGABE),
          ("tage90", "Eigene Kunden von der Anfrage bis zur Übergabe betreuen", None),
          # Lieferung 3: Beirat & Coaching
          ("woche", "Beirat & Coaching: Bedarfsanalyse durcharbeiten – erst fragen, dann zeigen",
           ("beirat", "bedarfsanalyse")),
          ("monat", "Beirat & Coaching: Preisgespräch und Einwände – Formulierungen mit dem Paten üben",
           ("beirat", "preisgespraech")),
          ("monat", "Beirat & Coaching: Abschluss und Nachfassen mit System", ("beirat", "abschluss")),
          ("tage90", "Beirat & Coaching: Verhandeln mit taktischer Empathie", ("beirat", "verhandeln")),
          lieferung_schritte=3),
    _plan("Verkauf (Azubi)",
          ("woche", "Ausbildungsplan, Berichtsheft und Berufsschultage besprochen", None),
          ("woche", "Marken, Baureihen und Grundrisse im Bestand kennenlernen", None),
          ("woche", "Telefon und Empfang: Anliegen aufnehmen und richtig weitergeben", None),
          ("monat", "Syscara: Fahrzeug suchen, Ausstattung und Preis lesen", ("anleitung", "Syscara: Grundlagen")),
          ("monat", "Beim Check-in eines Neufahrzeugs mitgehen", _CHECKIN),
          ("monat", "Preisschild und Fließtext in ODIN erstellen", None),
          ("tage90", "Bei einer Fahrzeugübergabe mitgehen und Teile der Einweisung übernehmen", _UEBERGABE),
          ("tage90", "Erste Verkaufsgespräche im Beisein des Paten führen", None),
          # Lieferung 3: Beirat & Coaching
          ("woche", "Beirat & Coaching: Bedarfsanalyse durcharbeiten – erst fragen, dann zeigen",
           ("beirat", "bedarfsanalyse")),
          ("monat", "Beirat & Coaching: Kopf frei – alles erfassen, nächster Schritt", ("beirat", "kopffrei")),
          ("tage90", "Beirat & Coaching: Besichtigung und Vorführung am Fahrzeug vorbereiten",
           ("beirat", "besichtigung")),
          lieferung_schritte=4),
    _plan("Werkstatt",
          ("woche", "Werkstattordnung, Werkzeug, Hebebühnen und Gasprüfplatz gezeigt", None),
          ("woche", "Auftragsannahme: vom Auftrag über die Zeiterfassung bis zur Rechnung", None),
          ("woche", "Anlieferungsdurchsicht mitmachen", ("anleitung", "Werkstatt: Anlieferungsdurchsicht")),
          ("monat", "Anlieferungsdurchsicht selbst durchführen", ("anleitung", "Werkstatt: Anlieferungsdurchsicht")),
          ("monat", "Übergabedurchsicht und Zubehörmontage nach Herstellervorgabe", None),
          ("monat", "Garantiearbeiten richtig dokumentieren (Fotos, Zeiten, Altteile)", ("ablauf", "Garantiefall abwickeln")),
          ("tage90", "Dichtigkeits- und Gasprüfung – soweit die nötige Befähigung vorliegt", None)),
    _plan("Teile & Zubehör",
          ("woche", "Lager, Lagerorte und Shop gezeigt", None),
          ("woche", "Teile suchen: Kataloge der Hersteller, Teilenummern, Fahrgestellnummer", ("anleitung", hg.ERSATZTEILE)),
          ("monat", "Teile bestellen und Wareneingang prüfen", ("ablauf", "Teile bestellen")),
          ("monat", "Preise und Montagezeiten in ODIN unter „Teile & Montage“ nachschlagen", None),
          ("monat", "Zubehör beraten und verkaufen, Kasse", None),
          ("tage90", "Reklamationen und Rücksendungen an Lieferanten", None)),
    _plan("Garantie",
          ("woche", "Unterschied Herstellergarantie, Gewährleistung und Kulanz", None),
          ("woche", "Garantieportale der Hersteller gezeigt", ("anleitung", hg.EINSTEIGER)),
          ("monat", "Garantiefall von der Meldung bis zur Gutschrift mit Pate abwickeln", ("ablauf", "Garantiefall abwickeln")),
          ("monat", "Fristen und Fotos: was der Hersteller für einen Antrag verlangt", None),
          ("tage90", "Garantiefälle allein abwickeln und offene Gutschriften nachhalten", ("ablauf", "Garantiefall abwickeln"))),
    _plan("Büro",
          ("woche", "Telefon, Post und Mail-Postfächer: wer bekommt was", None),
          ("woche", "Ablage: Fahrzeugordner, Kundenakten, SharePoint", None),
          ("monat", "Auftragsbestätigungen in ODIN prüfen", ("anleitung", "ODIN: Auftragsbestätigungen prüfen")),
          ("monat", "Bestandsliste pflegen", ("anleitung", "Bestandsliste: Aufbau und Pflege")),
          ("monat", "Zulassungen und Fahrzeugpapiere", None),
          ("tage90", "Rechnungen, Zahlungseingänge und Mahnungen", None)),
]

# Feste Gespräche: (Tage nach dem Start, Phase, Titel, Leitfragen)
GESPRAECHE = [
    (30, "monat", "Gespräch nach 30 Tagen", [
        "Wie bist du angekommen – was lief gut, was hat gefehlt?",
        "Was kannst du schon allein, wobei brauchst du noch jemanden?",
        "Welche Anleitung oder welcher Ablauf hat dir gefehlt oder war unklar?",
        "Was nehmen wir uns bis zum nächsten Gespräch vor?",
    ]),
    (90, "tage90", "Gespräch nach 90 Tagen", [
        "Passt die Aufgabe zu dir – und du zu uns?",
        "Welche Aufgaben übernimmst du jetzt eigenverantwortlich?",
        "Wo willst du dich weiterentwickeln, welche Schulung hilft dabei?",
        "Was sollten wir an der Einarbeitung für die nächsten Neuen ändern?",
    ]),
]
