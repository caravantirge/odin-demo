from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.formatting.rule import Rule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.styles.differential import DifferentialStyle

from .einstellungen import EINSTELLUNGEN

SPALTEN = [
    ("Interne ID", 14), ("Hersteller", 12), ("Modell", 30), ("Fließtext", 100), ("mobile.de", 50),
    ("Status", 9), ("Hinweise", 40), ("Datei", 30),
]


def exportiere(ergebnisse, pfad: str):
    """Schreibt die Ergebnisse als Tabelle. Begriffe aus 'rot_markieren' färben die Zelle rot."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Fließtexte"
    for i, (titel, breite) in enumerate(SPALTEN, start=1):
        c = ws.cell(row=1, column=i, value=titel)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3A5F")
        ws.column_dimensions[c.column_letter].width = breite
    ws.freeze_panes = "A2"

    for e in ergebnisse:
        hinweise = list(e.hinweise) + ([e.fehler] if e.fehler else [])
        werte = [e.interne_id, e.hersteller, e.modell, e.fliesstext, e.werbetext, e.status,
                 " | ".join(hinweise), e.datei]
        # Steuerzeichen aus der PDF (z. B. \x02) kann Excel nicht speichern
        ws.append([ILLEGAL_CHARACTERS_RE.sub("", w) if isinstance(w, str) else w for w in werte])
        for c in ws[ws.max_row]:
            if c.data_type == "f":            # Text, der mit „=“ beginnt, ist keine Formel
                c.data_type = "s"
            c.alignment = Alignment(wrap_text=True, vertical="top")

    if ws.max_row > 1:
        rot = DifferentialStyle(font=Font(color="FF0000"))
        for begriff in EINSTELLUNGEN["rot_markieren"]:
            regel = Rule(type="containsText", operator="containsText", text=begriff, dxf=rot)
            regel.formula = [f'NOT(ISERROR(SEARCH("{begriff.replace(chr(34), chr(34) * 2)}",D2)))']   # " verdoppeln
            ws.conditional_formatting.add(f"D2:D{ws.max_row}", regel)
    wb.save(pfad)
