"""Programmversion – der Build trägt hier die Build-Nummer ein."""
VERSION = "dev"
