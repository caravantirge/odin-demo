"""
PIN je Person – damit sich niemand bequem als jemand anderes ausgibt.

Ablage im gemeinsamen ODIN-Ordner (gilt so auf allen Rechnern und im Browser): _ODIN/Zugang/<person-id>.json mit
Version, Verfahren, Salz, Hash, gesetzt_am, gesetzt_von und einem kurzen Verlauf (gesetzt, geändert, zurückgesetzt).
Die PIN selbst steht nirgends: gespeichert ist nur ein gesalzener, absichtlich langsamer Hash (scrypt; ohne scrypt
PBKDF2-HMAC-SHA256 mit 600 000 Runden), verglichen wird zeitkonstant (hmac.compare_digest).

Grenzen – ehrlich: Wer im SharePoint-Ordner schreiben darf, kann eine Datei austauschen oder löschen; wer sie lesen
darf, kann eine kurze PIN mit genug Rechenzeit erraten. Die PIN verhindert das bequeme „Ich bin jetzt jemand anders“
im Alltag – echte Sicherheit bringt erst die Microsoft-Anmeldung.

Fehlversuche: je Person und Gerät (Rechner bzw. Browser-Gerät) nach 5 falschen PINs eine Sperre von 5, dann 15, dann
60 Minuten. Der Zähler liegt im Arbeitsspeicher und zusätzlich in einer Datei im Einstellungsordner dieses Rechners –
ein Neustart von ODIN hebt die Sperre nicht auf.
"""

import base64
import datetime as dt
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import threading
import time

from .projekte import ProjektFehler

PIN_MIN, PIN_MAX = 4, 8
VERSUCHE = 5                                   # falsche PINs je Runde
SPERREN = (5 * 60, 15 * 60, 60 * 60)           # Sekunden: erste, zweite, ab der dritten Runde
VERLAUF_MAX = 50
SCRYPT = {"n": 2 ** 14, "r": 8, "p": 1}        # ≈ 16 MB, einige zehn Millisekunden je Versuch
PBKDF2_RUNDEN = 600_000
ID = re.compile(r"[A-Za-z0-9_-]{1,40}")
# Naheliegende PINs: gleiche Ziffern (0000 …), auf- und absteigende Folgen (1234, 9876 …) kommen per Regel dazu
GESPERRT = {"1212", "1122", "1313", "2580", "0852", "1004", "2000", "2001", "2020", "6969", "4321", "1010", "0101",
            "123123", "121212", "112233", "147258", "159753", "696969", "102030", "1357", "2468", "13579", "24680"}


class PinFehler(ProjektFehler):
    """Meldung für Menschen (geht wie ProjektFehler an die Oberfläche)."""


def _jetzt_iso(uhr=time.time) -> str:
    return dt.datetime.fromtimestamp(uhr()).isoformat(timespec="seconds")


def pin_pruefen_form(pin) -> str:
    """Neue PIN prüfen: 4 bis 8 Ziffern, nichts Naheliegendes. Gibt die PIN zurück oder wirft PinFehler."""
    pin = str(pin if pin is not None else "")
    if not re.fullmatch(r"[0-9]+", pin):
        raise PinFehler("Die PIN besteht nur aus Ziffern.")
    if not PIN_MIN <= len(pin) <= PIN_MAX:
        raise PinFehler(f"Bitte {PIN_MIN} bis {PIN_MAX} Ziffern.")
    if trivial(pin):
        raise PinFehler("Diese PIN ist zu leicht zu erraten – bitte eine andere wählen.")
    return pin


def trivial(pin: str) -> bool:
    """0000, 1111 …, 1234, 3456, 9876, 0123 … und eine kurze Sperrliste."""
    if len(set(pin)) == 1 or pin in GESPERRT:
        return True
    schritte = {(int(b) - int(a)) % 10 for a, b in zip(pin, pin[1:])}
    return schritte in ({1}, {9})


# ---------------- Hash ----------------

def _b64(daten: bytes) -> str:
    return base64.b64encode(daten).decode("ascii")


def hash_bilden(pin: str, salz: bytes = None, verfahren: str = None) -> dict:
    """{"verfahren", "salz", "hash", …} – nie die PIN selbst."""
    salz = salz or secrets.token_bytes(16)
    verfahren = verfahren or ("scrypt" if hasattr(hashlib, "scrypt") else "pbkdf2-sha256")
    if verfahren == "scrypt":
        wert = hashlib.scrypt(pin.encode("utf-8"), salt=salz, dklen=32, maxmem=64 * 1024 * 1024, **SCRYPT)
        return {"verfahren": "scrypt", **SCRYPT, "salz": _b64(salz), "hash": _b64(wert)}
    wert = hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salz, PBKDF2_RUNDEN, dklen=32)
    return {"verfahren": "pbkdf2-sha256", "runden": PBKDF2_RUNDEN, "salz": _b64(salz), "hash": _b64(wert)}


def hash_vergleichen(pin: str, eintrag: dict) -> bool:
    """Zeitkonstanter Vergleich mit dem gespeicherten Hash. Unbekanntes Verfahren oder kaputte Werte: False."""
    try:
        salz = base64.b64decode(eintrag["salz"], validate=True)
        soll = base64.b64decode(eintrag["hash"], validate=True)
        if eintrag.get("verfahren") == "scrypt":
            n, r, p = int(eintrag.get("n", 0)), int(eintrag.get("r", 0)), int(eintrag.get("p", 0))
            if not (2 ** 10 <= n <= 2 ** 17 and n & (n - 1) == 0 and 1 <= r <= 16 and 1 <= p <= 4):
                return False                                   # unsinnige Werte aus einer veränderten Datei
            ist = hashlib.scrypt(str(pin).encode("utf-8"), salt=salz, n=n, r=r, p=p, dklen=len(soll),
                                 maxmem=128 * 1024 * 1024)
        elif eintrag.get("verfahren") == "pbkdf2-sha256":
            runden = int(eintrag.get("runden", 0))
            if not 100_000 <= runden <= 5_000_000:
                return False
            ist = hashlib.pbkdf2_hmac("sha256", str(pin).encode("utf-8"), salz, runden, dklen=len(soll))
        else:
            return False
    except (KeyError, TypeError, ValueError, MemoryError):
        return False
    return len(soll) >= 16 and hmac.compare_digest(ist, soll)


# ---------------- Ablage im gemeinsamen Ordner ----------------

class PinSpeicher:
    """_ODIN/Zugang/<person-id>.json. 'ordner()' liefert den Ordner „Zugang“."""

    def __init__(self, ordner, uhr=time.time):
        self._ordner = ordner
        self._uhr = uhr

    def _pfad(self, person_id: str) -> str:
        if not ID.fullmatch(str(person_id or "")):
            raise PinFehler("Diese Person gibt es nicht.")
        return os.path.join(self._ordner(), f"{person_id}.json")

    def eintrag(self, person_id: str) -> dict:
        """Inhalt der Datei (leer, wenn es keine gibt). Nicht lesbar → PinFehler: lieber keine Anmeldung als eine
        ohne Prüfung."""
        from .speicher import lies_json
        try:
            daten = lies_json(self._pfad(person_id))
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as e:
            raise PinFehler("Die Anmeldedaten sind gerade nicht lesbar – synchronisiert OneDrive noch? "
                            f"Bitte gleich noch einmal ({e}).") from None
        return daten if isinstance(daten, dict) else {}

    @staticmethod
    def hat_pin(eintrag: dict) -> bool:
        return bool(eintrag.get("hash") and eintrag.get("salz"))

    @staticmethod
    def stand(eintrag: dict) -> str:
        """Kennung des aktuellen Stands – ändert sich mit jeder neuen PIN und jeder Zurücksetzung (für gemerkte
        Anmeldungen: nach einer Zurücksetzung gilt keine alte Anmeldung mehr)."""
        if eintrag.get("salz"):
            return "pin:" + str(eintrag["salz"])
        z = eintrag.get("zurueckgesetzt") or {}
        return "zurueck:" + str(z.get("am", "")) if z else ""

    def _schreibe(self, person_id: str, daten: dict):
        pfad = self._pfad(person_id)
        os.makedirs(os.path.dirname(pfad), exist_ok=True)
        tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(daten, f, ensure_ascii=False, indent=1)
            os.replace(tmp, pfad)
        except OSError as e:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise PinFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None

    def _verlauf(self, alt: dict, art: str, von: str, am: str) -> list:
        verlauf = [v for v in alt.get("verlauf") or [] if isinstance(v, dict)]
        verlauf.append({"art": art, "am": am, "von": von})
        return verlauf[-VERLAUF_MAX:]

    def setzen(self, person_id: str, pin: str, von: str, wie: str = "") -> dict:
        alt = self.eintrag(person_id)
        am = _jetzt_iso(self._uhr)
        daten = {"version": 1, "person": person_id, **hash_bilden(pin), "gesetzt_am": am, "gesetzt_von": von,
                 "wie": wie, "verlauf": self._verlauf(alt, "geändert" if self.hat_pin(alt) else "gesetzt", von, am)}
        if alt.get("zurueckgesetzt"):
            daten["zuletzt_zurueckgesetzt"] = alt["zurueckgesetzt"]
        self._schreibe(person_id, daten)
        return daten

    def zuruecksetzen(self, person_id: str, von: str, von_name: str) -> dict:
        alt = self.eintrag(person_id)
        am = _jetzt_iso(self._uhr)
        daten = {"version": 1, "person": person_id, "zurueckgesetzt": {"am": am, "von": von, "von_name": von_name},
                 "verlauf": self._verlauf(alt, "zurückgesetzt", von, am)}
        self._schreibe(person_id, daten)
        return daten

    def pruefen(self, person_id: str, pin: str) -> bool:
        eintrag = self.eintrag(person_id)
        return self.hat_pin(eintrag) and hash_vergleichen(str(pin or ""), eintrag)


# ---------------- Fehlversuche ----------------

class Fehlversuche:
    """Zähler je Schlüssel („<person>|<gerät>“) im Arbeitsspeicher und in 'datei' (Einstellungsordner dieses
    Rechners). 'uhr' liefert Sekunden seit 1970 (für Tests austauschbar)."""

    def __init__(self, datei: str, uhr=time.time):
        self._datei = datei
        self._uhr = uhr
        self._riegel = threading.Lock()
        self._werte = None

    def _laden(self) -> dict:
        if self._werte is None:
            try:
                with open(self._datei, encoding="utf-8") as f:
                    roh = json.load(f)
            except (OSError, ValueError):
                roh = {}
            self._werte = {}
            for k, v in (roh.items() if isinstance(roh, dict) else []):
                if isinstance(k, str) and isinstance(v, dict):
                    try:
                        self._werte[k[:120]] = {"anzahl": int(v.get("anzahl", 0)), "runden": int(v.get("runden", 0)),
                                                "bis": float(v.get("bis", 0))}
                    except (TypeError, ValueError):
                        continue
        return self._werte

    def _sichern(self):
        werte = self._werte or {}
        if len(werte) > 1000:                                  # nie unbegrenzt wachsen: alte, erledigte zuerst weg
            for k in sorted(werte, key=lambda k: werte[k]["bis"])[:len(werte) - 1000]:
                del werte[k]
        try:
            os.makedirs(os.path.dirname(self._datei) or ".", exist_ok=True)
            tmp = self._datei + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(werte, f)
            os.replace(tmp, self._datei)
        except OSError:
            pass                                               # dann eben nur im Arbeitsspeicher

    def warten(self, schluessel: str) -> int:
        """Sekunden, die noch gesperrt ist (0 = darf)."""
        with self._riegel:
            e = self._laden().get(schluessel)
            rest = (e["bis"] - self._uhr()) if e else 0
            return math.ceil(rest) if rest > 0 else 0

    def rest(self, schluessel: str) -> int:
        """Wie viele Versuche bis zur nächsten Sperre."""
        with self._riegel:
            e = self._laden().get(schluessel) or {"anzahl": 0}
            return max(0, VERSUCHE - e["anzahl"])

    def fehler(self, schluessel: str) -> dict:
        """Einen Fehlversuch zählen. {"rest": Versuche bis zur Sperre, "warten": Sekunden Sperre (0 = keine)}."""
        with self._riegel:
            werte = self._laden()
            e = werte.setdefault(schluessel, {"anzahl": 0, "runden": 0, "bis": 0.0})
            e["anzahl"] += 1
            warten = 0
            if e["anzahl"] >= VERSUCHE:
                warten = SPERREN[min(e["runden"], len(SPERREN) - 1)]
                e.update(anzahl=0, runden=e["runden"] + 1, bis=self._uhr() + warten)
            self._sichern()
            return {"rest": VERSUCHE - e["anzahl"] if not warten else 0, "warten": warten}

    def erfolg(self, schluessel: str):
        with self._riegel:
            if self._laden().pop(schluessel, None) is not None:
                self._sichern()

    def vergessen(self, praefix: str):
        """Alle Zähler einer Person (nach einer Zurücksetzung durch einen Verwalter)."""
        with self._riegel:
            werte = self._laden()
            weg = [k for k in werte if k.startswith(praefix)]
            for k in weg:
                del werte[k]
            if weg:
                self._sichern()
