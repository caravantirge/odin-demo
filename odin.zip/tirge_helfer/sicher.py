"""
Schutz vor präparierten Dateien: Eine wenige KB große Excel-Mappe oder PDF kann sich beim Lesen auf Gigabytes
aufblähen und den Rechner lahmlegen. Vor dem eigentlichen Lesen wird deshalb geprüft, wie groß die Datei entpackt
wäre, und Blätter werden nie über eine feste Zeilen- und Spaltenzahl hinaus gelesen.
"""

import io
import os
import re
import zipfile
import zlib

MAX_XLSX_ENTPACKT = 150 * 1024 * 1024       # alle Teile der Mappe zusammen (eine volle Bestandsliste hat wenige MB)
MAX_XLSX_TEILE = 3000
MAX_ZEILEN = 20000
MAX_SPALTEN = 300
MAX_PDF = 40 * 1024 * 1024                  # Dateigröße
MAX_PDF_ENTPACKT = 250 * 1024 * 1024        # alle gepackten Abschnitte zusammen
MAX_PDF_SEITEN = 300
MAX_BILD_PIXEL = 60_000_000

_STROM = re.compile(rb"stream\r?\n")
_SEITE = re.compile(rb"/Type\s*/Page(?![a-zA-Z])")


class DateiZuGross(ValueError):
    """Die Datei wäre beim Lesen zu groß – sie wird nicht geöffnet."""


def _bytes(quelle, grenze: int):
    """(daten oder None, groesse) – Pfad, Bytes oder Datei-Objekt; liest höchstens grenze+1 Bytes."""
    if isinstance(quelle, (bytes, bytearray)):
        return bytes(quelle), len(quelle)
    if isinstance(quelle, (str, os.PathLike)):
        groesse = os.path.getsize(quelle)
        if groesse > grenze:
            return None, groesse
        with open(quelle, "rb") as f:
            return f.read(), groesse
    stelle = quelle.tell()
    daten = quelle.read(grenze + 1)
    quelle.seek(stelle)
    return daten, len(daten)


def pruefe_xlsx(quelle):
    """Wie groß wäre die Mappe entpackt? Zu groß → DateiZuGross. Keine Zip-Datei → nichts tun (meldet der Leser)."""
    try:
        if isinstance(quelle, (bytes, bytearray)):
            quelle = io.BytesIO(quelle)
        stelle = quelle.tell() if hasattr(quelle, "tell") else None
        try:
            with zipfile.ZipFile(quelle) as z:
                teile = z.infolist()
                if len(teile) > MAX_XLSX_TEILE or sum(t.file_size for t in teile) > MAX_XLSX_ENTPACKT:
                    raise DateiZuGross("Die Excel-Datei ist ungewöhnlich groß und wird nicht gelesen.")
        finally:
            if stelle is not None:
                quelle.seek(stelle)
    except (zipfile.BadZipFile, OSError):
        return


def blatt_zeilen(ws, max_zeilen: int = MAX_ZEILEN, max_spalten: int = MAX_SPALTEN) -> list:
    """Zeilen eines Blatts als Listen – nie mehr als max_zeilen × max_spalten, egal was die Datei behauptet.
    Leere Zeilen am Ende fallen weg."""
    if hasattr(ws, "reset_dimensions"):
        ws.reset_dimensions()                  # die gespeicherten Abmessungen können gelogen sein
    zeilen, letzte = [], 0
    for nr, zeile in enumerate(ws.iter_rows(max_row=max_zeilen, max_col=max_spalten, values_only=True), start=1):
        zeile = list(zeile)
        while zeile and zeile[-1] is None:
            zeile.pop()
        zeilen.append(zeile)
        if zeile:
            letzte = nr
        elif nr - letzte > 2000:               # nur noch Leere: nichts mehr zu holen
            break
    return zeilen[:letzte]


_HEX_NAME = re.compile(rb"#([0-9A-Fa-f]{2})")
_FILTER = re.compile(rb"/(FlateDecode|Fl|ASCIIHexDecode|AHx|ASCII85Decode|A85|RunLengthDecode|RL|LZWDecode|LZW)(?![A-Za-z0-9])")
_ANZAHL = re.compile(rb"/Count\s+(\d{1,12})")
_BLAEHT = "Die PDF bläht sich beim Lesen stark auf und wird nicht gelesen."
MAX_ZWISCHEN = 48 * 1024 * 1024             # so viel darf eine Zwischenstufe (z. B. Hex vor Flate) höchstens werden


def _klarname(daten: bytes) -> bytes:
    """PDF-Namen dürfen Zeichen als #xx schreiben (/P#61ge = /Page) – für die Suche zurückübersetzen."""
    return _HEX_NAME.sub(lambda m: bytes([int(m.group(1), 16)]), daten) if b"#" in daten else daten


def _flate_groesse(stueck: bytes, grenze: int, behalten: bool):
    """(entpackte Größe, Inhalt oder None). Zählt häppchenweise; bei mehr als grenze → DateiZuGross."""
    entpacker, summe, teile = zlib.decompressobj(), 0, []
    while stueck:
        aus = entpacker.decompress(stueck, 1 << 20)
        summe += len(aus)
        if summe > grenze:
            raise DateiZuGross(_BLAEHT)
        if behalten:
            teile.append(aus)
        stueck = entpacker.unconsumed_tail
        if not aus and not stueck:
            break
    return summe, (b"".join(teile) if behalten else None)


def pruefe_pdf(quelle):
    """PDF vor dem Lesen: Dateigröße, Seitenzahl und wie groß die gepackten Abschnitte entpackt wären – auch bei
    mehrfach oder ungewöhnlich gepackten Abschnitten (Hex, ASCII85, Lauflängen, LZW, Flate hintereinander)."""
    import base64
    daten, groesse = _bytes(quelle, MAX_PDF)
    if daten is None or groesse > MAX_PDF:
        raise DateiZuGross("Die PDF ist größer als 40 MB und wird nicht gelesen.")
    klar = _klarname(daten)
    if len(_SEITE.findall(klar)) > MAX_PDF_SEITEN or any(int(n) > MAX_PDF_SEITEN for n in _ANZAHL.findall(klar)):
        raise DateiZuGross("Die PDF hat ungewöhnlich viele Seiten und wird nicht gelesen.")
    summe = 0
    for treffer in _STROM.finditer(daten):
        anfang = treffer.end()
        ende = daten.find(b"endstream", anfang)
        stueck = daten[anfang:ende if ende >= 0 else len(daten)]
        kopf = daten[max(0, treffer.start() - 800):treffer.start()]
        kopf = _klarname(kopf[kopf.rfind(b"<<"):] if b"<<" in kopf else kopf)
        namen = [f.decode() for f in _FILTER.findall(kopf)]
        if not namen and stueck[:1] == b"\x78":
            namen = ["FlateDecode"]                                         # ohne Angabe, sieht aber gepackt aus
        try:
            for nr, name in enumerate(namen[:6]):
                letzte = nr == len(namen[:6]) - 1
                rest = MAX_PDF_ENTPACKT - summe
                if name in ("FlateDecode", "Fl"):
                    n, stueck = _flate_groesse(stueck, rest if letzte else min(rest, MAX_ZWISCHEN), not letzte)
                    if letzte:
                        summe += n
                elif name in ("ASCIIHexDecode", "AHx"):
                    stueck = bytes.fromhex(re.sub(rb"[^0-9A-Fa-f]", b"", stueck.split(b">", 1)[0][:2 * MAX_ZWISCHEN]).decode()[: 2 * MAX_ZWISCHEN // 2 * 2])
                    if letzte:
                        summe += len(stueck)
                elif name in ("ASCII85Decode", "A85"):
                    roh = stueck.strip()
                    roh = roh[:-2] if roh.endswith(b"~>") else roh
                    stueck = base64.a85decode(roh[:MAX_ZWISCHEN], adobe=False, ignorechars=b" \t\n\r\x0c\x00")
                    if letzte:
                        summe += len(stueck)
                elif name in ("RunLengthDecode", "RL"):                     # höchstens 64-fach je Byte
                    if len(stueck) * 64 > rest:
                        raise DateiZuGross(_BLAEHT)
                    summe += len(stueck) * 64
                    break
                else:                                                       # LZW: kann sich über 1000-fach aufblähen
                    if len(stueck) * 1400 > rest:
                        raise DateiZuGross(_BLAEHT)
                    summe += len(stueck) * 1400
                    break
                if stueck is None:
                    stueck = b""
                if len(stueck) > MAX_ZWISCHEN:
                    raise DateiZuGross(_BLAEHT)
            else:
                if not namen:
                    summe += len(stueck)
        except DateiZuGross:
            raise
        except (zlib.error, ValueError):
            summe += len(stueck) if isinstance(stueck, (bytes, bytearray)) else 0   # kaputt gepackt: meldet der Leser
        if summe > MAX_PDF_ENTPACKT:
            raise DateiZuGross(_BLAEHT)
    pruefe_pdf_struktur(daten)


# ---------------------------------------------------------------- Prüfung mit dem Leser selbst
MAX_PDF_OBJEKTE = 200_000
MAX_SCHICHTEN = 12
PRUEF_SEKUNDEN = 12
LESE_SEKUNDEN = 25                          # so lange darf das eigentliche Lesen einer PDF dauern (Frist je Datei)


def _strom_groesse(strom, rest: int) -> int:
    """Entpackte Größe eines Abschnitts – mit den Filtern, die der Leser selbst dafür ermittelt (auch wenn sie in
    einem eigenen Objekt stehen), Schicht für Schicht und nie über 'rest' hinaus."""
    import base64
    stueck = strom.rawdata or b""
    try:
        filter_ = strom.get_filters()
    except Exception:                                   # noqa: BLE001 – kaputte Angabe: meldet der Leser
        return len(stueck)
    if len(filter_) > MAX_SCHICHTEN:
        raise DateiZuGross(_BLAEHT)
    for nr, (f, _parameter) in enumerate(filter_):
        name = str(getattr(f, "name", f))
        letzte = nr == len(filter_) - 1
        try:
            if name in ("FlateDecode", "Fl"):
                n, stueck = _flate_groesse(stueck, rest if letzte else min(rest, MAX_ZWISCHEN), not letzte)
                if letzte:
                    return n
            elif name in ("ASCIIHexDecode", "AHx"):
                stueck = bytes.fromhex(re.sub(rb"[^0-9A-Fa-f]", b"", stueck.split(b">", 1)[0]).decode()[: len(stueck) // 2 * 2])
            elif name in ("ASCII85Decode", "A85"):
                roh = stueck.strip()
                stueck = base64.a85decode(roh[:-2] if roh.endswith(b"~>") else roh, adobe=False,
                                          ignorechars=b" \t\n\r\x0c\x00")
            elif name in ("RunLengthDecode", "RL"):
                if len(stueck) * 64 > rest:
                    raise DateiZuGross(_BLAEHT)
                return len(stueck) * 64
            elif name in ("LZWDecode", "LZW"):
                if len(stueck) * 1400 > rest:
                    raise DateiZuGross(_BLAEHT)
                return len(stueck) * 1400
            else:                                       # Bildformate u. Ä.: werden nicht zu Text entpackt
                return len(stueck)
        except DateiZuGross:
            raise
        except (zlib.error, ValueError):
            return len(stueck or b"")
        if stueck is None or len(stueck) > min(rest, MAX_ZWISCHEN):
            raise DateiZuGross(_BLAEHT)
    return len(stueck or b"")


def pruefe_pdf_struktur(quelle):
    """Zweite Prüfung, mit dem Aufbau, wie ihn der Leser (pdfminer) sieht: jeder Abschnitt mit seinen wirklichen
    Filtern und seiner wirklichen Länge, Seiten wirklich gezählt, und was alle Seiten zusammen an Inhalt hätten."""
    import time
    from pdfminer.pdfdocument import PDFDocument
    from pdfminer.pdfpage import PDFPage
    from pdfminer.pdfparser import PDFParser
    from pdfminer.pdftypes import PDFStream, resolve1
    daten, _ = _bytes(quelle, MAX_PDF)
    if daten is None:
        raise DateiZuGross("Die PDF ist größer als 40 MB und wird nicht gelesen.")
    frist = time.monotonic() + PRUEF_SEKUNDEN

    def zeit():
        if time.monotonic() > frist:
            raise DateiZuGross("Die PDF ist ungewöhnlich aufwendig aufgebaut und wird nicht gelesen.")
    try:
        dok = PDFDocument(PDFParser(io.BytesIO(daten)))
    except DateiZuGross:
        raise
    except Exception:                                   # noqa: BLE001 – keine lesbare PDF: das meldet der Leser
        return
    groessen, summe, anzahl = {}, 0, 0

    def strom(objekt):
        nonlocal summe
        if not isinstance(objekt, PDFStream):
            return 0
        nr = getattr(objekt, "objid", None)
        if nr in groessen:
            return groessen[nr]
        n = _strom_groesse(objekt, MAX_PDF_ENTPACKT - summe)
        summe += n
        if summe > MAX_PDF_ENTPACKT:
            raise DateiZuGross(_BLAEHT)
        if nr is not None:
            groessen[nr] = n
        return n
    try:
        for xref in dok.xrefs:
            for nr in list(xref.get_objids()):
                anzahl += 1
                if anzahl > MAX_PDF_OBJEKTE:
                    raise DateiZuGross("Die PDF ist ungewöhnlich aufwendig aufgebaut und wird nicht gelesen.")
                if anzahl % 500 == 0:
                    zeit()
                try:
                    behaelter = xref.get_pos(nr)[0]
                    if behaelter is not None:           # Objekt steckt in einem gepackten Sammelabschnitt: den zuerst
                        strom(dok.getobj(behaelter))
                    strom(dok.getobj(nr))
                except DateiZuGross:
                    raise
                except Exception:                       # noqa: BLE001 – einzelnes kaputtes Objekt
                    continue
        seiten, inhalt = 0, 0
        for seite in PDFPage.create_pages(dok):
            seiten += 1
            if seiten > MAX_PDF_SEITEN:
                raise DateiZuGross("Die PDF hat ungewöhnlich viele Seiten und wird nicht gelesen.")
            for c in (seite.contents or []):
                try:
                    inhalt += strom(resolve1(c)) if not isinstance(resolve1(c), PDFStream) else groessen.get(
                        getattr(resolve1(c), "objid", None), strom(resolve1(c)))
                except DateiZuGross:
                    raise
                except Exception:                       # noqa: BLE001
                    continue
            if inhalt > MAX_PDF_ENTPACKT:               # derselbe große Inhalt auf vielen Seiten
                raise DateiZuGross("Die PDF ist ungewöhnlich aufwendig aufgebaut und wird nicht gelesen.")
            zeit()
    except DateiZuGross:
        raise
    except RecursionError:
        raise DateiZuGross("Die PDF ist ungewöhnlich aufwendig aufgebaut und wird nicht gelesen.") from None
    except Exception:                                   # noqa: BLE001 – Rest meldet der Leser
        return


def seitentexte(pdf, je_seite=None) -> list:
    """Text aller Seiten einer mit pdfplumber geöffneten PDF – mit Frist: dauert es zu lange, wird abgebrochen."""
    import time
    frist = time.monotonic() + LESE_SEKUNDEN
    texte = []
    for nr, seite in enumerate(pdf.pages):
        if nr >= MAX_PDF_SEITEN or time.monotonic() > frist:
            raise DateiZuGross("Die PDF ist ungewöhnlich aufwendig aufgebaut und wird nicht gelesen.")
        texte.append((je_seite(seite) if je_seite else seite.extract_text()) or "")
    return texte
