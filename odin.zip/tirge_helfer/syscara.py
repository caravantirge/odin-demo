"""
Syscara-Export (Excel oder CSV) -> bestellte Ausstattung je Fahrzeug, und deren Abgleich mit der AB.

Aufbau des Exports („Fahrzeuge exportieren“): Kopfzeile mit #, Hersteller, Baureihe, Modell, Interne ID,
Fahrgestellnummer, Seriennummer, Bestellnummer, danach eine Spalte je Ausstattung. Hat ein Fahrzeug die
Ausstattung, steht ihr Name in der Zelle. Syscara kürzt die Namen auf 50 Zeichen. Andere Spalten
(z. B. Kunde, Preis) werden ignoriert: Ausstattung ist nur eine Spalte, deren Zellen ihren eigenen Namen tragen.

Die Daten aller Exporte liegen zusammengeführt in Fahrzeuge/_odin-syscara.json (je Fahrzeug der neueste Stand).

Abgleich mit der neuesten AB eines Fahrzeugs:
1. Modell (Baureihe + Modell) sucht seine Position, z. B. „Adventure Vento 540“ ↔ „CV540 Adventure – MJ 2027“.
2. Jede Ausstattung sucht ihre Position: zuerst gelernte Zuordnungen („Expedition Grau“ = Hersteller2 25048),
   dann gleicher Name, dann alle Wörter des Syscara-Namens in der AB-Bezeichnung (Farben Deutsch/Englisch,
   „3,5t“ = „3.500 kg“, „4,0“ = „4“, kleine Schreibfehler egal, bei auf 50 Zeichen gekürzten Namen darf das
   letzte Wort abgeschnitten sein). Zahlen – auch die in Klammern und die Modellnummer – müssen in der AB
   stehen. Ähnliche, aber nicht sichere Treffer sind „unsicher“.
3. Positionen, die nur in der AB stehen: Gebühren (Zulassung, Versicherung …) und Positionen ohne Preis
   (0,00; leer nur in einer AB mit Preisen, die keine Vormerkung ist) sind Info, alles andere muss jemand ansehen.
4. Nummern: Seriennummer, Fahrgestellnummer und Bestellnummer müssen übereinstimmen, wenn beide sie nennen.
Passt alles, ist die AB gegen Syscara geprüft.
"""

import csv
import datetime as dt
import difflib
import hashlib
import io
import json
import os
import secrets
import re
import unicodedata
from dataclasses import asdict, dataclass, field

from .ab_lesen import AB, Position

DATEI = "_odin-syscara.json"
ABGLEICH_STAND = 2          # erhöhen, wenn sich die Zuordnungslogik ändert (gespeicherte Abgleiche werden neu berechnet)
GEKUERZT = 49               # Syscara kürzt Namen auf 50 Zeichen (doppelte Leerzeichen werden beim Lesen zu einem)
MEHRDEUTIG = "Name in Syscara gekürzt – mehrdeutig"
KODIERUNG_UNBEKANNT = "Die CSV-Datei hat eine unbekannte Zeichenkodierung – bitte als Excel (.xlsx) exportieren."

PASST, UNSICHER, FEHLT, IGNORIERT = "passt", "unsicher", "fehlt", "ignoriert"
NUR_AB, GEBUEHR, OHNE_PREIS, ABWEICHUNG = "nur_ab", "gebuehr", "ohne_preis", "abweichung"

KOPF = {
    "#": "", "nr": "", "nr.": "",
    "hersteller": "hersteller", "marke": "hersteller",
    "baureihe": "baureihe", "modell": "modell",
    "interne id": "interne_id", "interne-id": "interne_id",
    "fahrgestellnummer": "fin", "fin": "fin", "fahrgestell-nr.": "fin", "fahrgestell": "fin",
    "seriennummer": "seriennummer", "serien-nr.": "seriennummer",
    "bestellnummer": "bestellnummer", "auftragsnummer": "bestellnummer",
}
JA = {"x", "ja", "1", "true", "wahr", "✓", "✔"}

# nur am Wortanfang: „COC-Papiere“, „Vorfracht“ ja – „Cockpit“ nein
NEBENKOSTEN = re.compile(r"\b(?:coc\b|tüv\b|zulassung|tageszulassung|versicherung|überführung|ueberfuehrung|"
                         r"(?:vor)?fracht|bereitstellung|händlerbeteiligung|haendlerbeteiligung|zusatzbetankung|"
                         r"neufahrzeug-deckung|family-service|aktionsprämie|aktionspraemie)")

SYNONYME = {"grey": "grau", "gray": "grau", "white": "weiss", "black": "schwarz", "silver": "silber",
            "blue": "blau", "red": "rot", "green": "gruen", "brown": "braun", "watt": "w", "liter": "l", "ltr": "l"}
FUELLWOERTER = {"und", "mit", "inkl", "incl", "fur", "im", "in", "der", "die", "das", "des", "dem", "den", "von", "zu",
                "zum", "zur", "auf", "am", "an", "als", "bei", "sowie", "ein", "eine", "the", "and", "for", "with"}
ALLGEMEIN = {"paket", "ausstattung", "vorbereitung", "system", "set", "anlage", "sitzplatz", "fenster", "elektrische",
             "elektrisch", "automatisch", "automatische", "zusatzlich", "zusatzliche", "zusatzlicher"}
# Wörter, die die Bedeutung ändern: „Solaranlage“ ist nicht „Kabelvorbereitung für Solaranlage“,
# „Rückfahrkamera“ nicht „zweite Rückfahrkamera“. Steht so ein Wort nur in der AB, ist der Treffer unsicher.
EINSCHRAENKUNG_TEIL = ("vorbereitung", "vorber", "entfall", "zweit")
EINSCHRAENKUNG_WORT = {"ohne", "kein", "keine", "nicht", "statt", "anstatt", "anstelle", "vorb"}


class NichtLesbar(Exception):
    """_odin-syscara.json ist da, aber nicht lesbar – und es gibt keinen zuletzt gelesenen Stand."""

    def __init__(self, beschaedigt: bool = False):
        super().__init__(
            "Die Datei „_odin-syscara.json“ im Ordner „Fahrzeuge“ ist beschädigt – bitte den Syscara-Export neu "
            "einlesen." if beschaedigt else
            "Die Syscara-Daten sind gerade nicht lesbar (z. B. von OneDrive gesperrt) – gleich noch einmal versuchen.")


class _Unlesbar(ValueError):
    """Datei ist da, aber nicht zu entziffern – die Meldung geht so an den Benutzer."""


# ---------------- Export lesen ----------------

@dataclass
class SyscaraFahrzeug:
    interne_id: str = ""
    hersteller: str = ""
    baureihe: str = ""
    modell: str = ""
    fin: str = ""
    seriennummer: str = ""
    bestellnummer: str = ""
    ausstattung: list = field(default_factory=list)
    mehrdeutig: list = field(default_factory=list)     # Namen, die im Export mehrfach als Spalte stehen

    @property
    def schluessel(self) -> str:
        return (self.interne_id or ("#" + self.bestellnummer)).upper()


@dataclass
class Export:
    datei: str
    stand: str = ""                 # Zeitpunkt des Exports (ISO)
    fahrzeuge: list = field(default_factory=list)
    fehler: str = ""
    stand_geschaetzt: bool = False  # kein Zeitstempel im Export: Dateidatum bzw. jetzt


def _text(wert) -> str:
    if wert is None:
        return ""
    if isinstance(wert, bool):
        return "x" if wert else ""
    if isinstance(wert, float) and wert.is_integer():
        return str(int(wert))
    if isinstance(wert, (dt.datetime, dt.date)):
        return wert.isoformat()
    return " ".join(str(wert).split())


def kurzname(name: str) -> str:
    """'Lounge Paket  (Klimaanlage Fahrerhaus Automatik, I' -> 'Lounge Paket'"""
    name = " ".join((name or "").split())
    kern = name.split(" (")[0].strip()
    return kern or name


def _zeilen_xlsx(quelle) -> list:
    from openpyxl import load_workbook
    from .sicher import blatt_zeilen, pruefe_xlsx
    pruefe_xlsx(quelle)
    wb = load_workbook(quelle, read_only=True, data_only=True)
    try:
        for ws in wb.worksheets[:30]:
            zeilen = blatt_zeilen(ws)
            if _finde_kopf_in(zeilen):                  # auch Kopf in Zeile 1 (Index 0)
                return zeilen
        return blatt_zeilen(wb.worksheets[0]) if wb.worksheets else []
    finally:
        wb.close()


def _dekodiere(daten: bytes) -> str:
    """UTF-8 (mit/ohne BOM), UTF-16, sonst Windows (cp1252) oder alter Mac (mac_roman) – was mehr Umlaute ergibt."""
    if daten[:2] in (b"\xff\xfe", b"\xfe\xff"):
        versuch = "utf-16"
    elif daten[:400].count(b"\x00") > 40:                # UTF-16 ohne BOM
        versuch = "utf-16-le" if daten[1:2] == b"\x00" else "utf-16-be"
    else:
        versuch = "utf-8-sig"
    try:
        text = daten.decode(versuch)
    except UnicodeDecodeError:
        texte = [daten.decode("cp1252", errors="replace"), daten.decode("mac_roman")]
        text = max(texte, key=lambda t: sum(t.count(c) for c in "äöüÄÖÜß") - t.count("\ufffd"))
    if "\x00" in text or sum(not c.isprintable() and c not in "\r\n\t" for c in text[:5000]) > 5:
        raise _Unlesbar(KODIERUNG_UNBEKANNT)
    return text


def _zeilen_csv(daten: bytes) -> list:
    text = _dekodiere(daten)
    probe = text[:5000]
    try:
        dialekt = csv.Sniffer().sniff(probe, delimiters=";,\t")
    except csv.Error:
        class dialekt(csv.excel):
            delimiter = ";" if probe.count(";") >= probe.count(",") else ","
    return [z for z in csv.reader(io.StringIO(text), dialekt)]


def _finde_kopf_in(zeilen) -> list:
    return [i for i, z in enumerate(zeilen[:20]) if any(_text(c).casefold() in ("interne id", "interne-id") for c in z)]


def _stand_aus(zeilen_davor, datei: str) -> str:
    """Zeitstempel des Exports aus den Zeilen über dem Kopf oder dem Dateinamen, '' wenn keiner da ist."""
    for z in zeilen_davor:
        for c in z:
            if isinstance(c, dt.datetime):
                return c.isoformat(timespec="seconds")
            m = re.search(r"(\d{1,2})\.(\d{1,2})\.(\d{4})(?:,?\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?", _text(c))
            if m:
                t, mo, j, h, mi, s = (int(x or 0) for x in m.groups())
                try:
                    return dt.datetime(j, mo, t, h, mi, s).isoformat(timespec="seconds")
                except ValueError:
                    continue
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})-(\d{2})-(\d{2})-(\d{2})", datei)
    if m:
        try:
            return dt.datetime(*map(int, m.groups())).isoformat(timespec="seconds")
        except ValueError:
            pass
    return ""


def _ohne_doppelte(namen: list) -> list:
    """Gleicher Name zweimal: einmal – außer bei gekürzten Namen (zwei verschiedene Optionen)."""
    return [n for k, n in enumerate(namen) if ist_gekuerzt(n) or n not in namen[:k]]


def werte_zeilen_aus(zeilen: list, datei: str = "", mtime: float = None) -> Export:
    """Kern ohne Dateizugriff: Tabelle (Liste von Zeilen) -> Export."""
    erg = Export(datei=datei)
    kopf_idx = _finde_kopf_in(zeilen)
    if not kopf_idx:
        erg.fehler = "Keine Spalte „Interne ID“ gefunden – ist das ein Syscara-Fahrzeugexport?"
        return erg
    k = kopf_idx[0]
    erg.stand = _stand_aus(zeilen[:k], datei)
    if not erg.stand:           # kein Zeitstempel: gilt als neuester Export (gerade ausgewählt), Stand = Dateidatum
        erg.stand_geschaetzt = True
        erg.stand = (dt.datetime.fromtimestamp(mtime) if mtime else dt.datetime.now()).isoformat(timespec="seconds")
    kopf = [_text(c) for c in zeilen[k]]
    daten = [z for z in zeilen[k + 1:] if any(_text(c) for c in z)]
    felder, ausstattung = {}, []
    for i, name in enumerate(kopf):
        if not name:
            continue
        schl = name.casefold()
        if schl in KOPF:
            if KOPF[schl]:
                felder.setdefault(KOPF[schl], i)
            continue
        werte = [_text(z[i]) for z in daten if i < len(z) and _text(z[i])]
        # Ausstattung: die Zellen tragen den Namen der Spalte (oder x/ja). Sonst ist es ein Datenfeld (Kunde, Preis …)
        if werte and sum(w == name or w.casefold() in JA or name.startswith(w) for w in werte) >= 0.8 * len(werte):
            ausstattung.append(i)
    if any(k.casefold().replace("ß", "ss") in ("fliesstext", "fließtext") for k in kopf):
        erg.fehler = "Das ist die Fließtext-Liste aus ODIN, kein Syscara-Export."
        return erg
    if not ausstattung:
        erg.fehler = "Keine Ausstattungsspalten gefunden – ist das ein Syscara-Fahrzeugexport mit Ausstattung?"
        return erg
    namen = [kopf[i] for i in ausstattung]
    # zwei Optionen mit denselben ersten 50 Zeichen: mehrdeutig, beide behalten. Ein kurzer Name zweimal (z. B. mit
    # Leerzeichen am Ende) ist dieselbe Ausstattung.
    doppelt = {n for n in namen if namen.count(n) > 1 and ist_gekuerzt(n)}
    for z in daten:
        def feld(n):
            i = felder.get(n)
            return _text(z[i]) if i is not None and i < len(z) else ""
        fz = SyscaraFahrzeug(interne_id=feld("interne_id").upper(), hersteller=feld("hersteller"),
                             baureihe=feld("baureihe"), modell=feld("modell"), fin=feld("fin").upper(),
                             seriennummer=feld("seriennummer"), bestellnummer=feld("bestellnummer"))
        if not (fz.interne_id or fz.bestellnummer):
            continue
        fz.ausstattung = _ohne_doppelte([kopf[i] for i in ausstattung if i < len(z) and _text(z[i])])
        fz.mehrdeutig = sorted(doppelt & set(fz.ausstattung))
        erg.fahrzeuge.append(fz)
    if not erg.fahrzeuge:
        erg.fehler = "Im Export steht kein Fahrzeug mit Interner ID."
    return erg


def lies_export(quelle, datei: str = "") -> Export:
    """quelle: Pfad oder Bytes (z. B. aus Drag & Drop)."""
    datei = datei or os.path.basename(str(quelle))
    mtime = None
    try:
        if isinstance(quelle, (bytes, bytearray)):
            daten = bytes(quelle)
        else:
            mtime = os.path.getmtime(quelle)
            with open(quelle, "rb") as f:
                daten = f.read()
        if daten[:2] == b"PK":                               # xlsx ist ein ZIP
            zeilen = _zeilen_xlsx(io.BytesIO(daten))
        else:
            zeilen = _zeilen_csv(daten)
    except _Unlesbar as e:
        return Export(datei=datei, fehler=str(e))
    except Exception as e:
        return Export(datei=datei, fehler=f"Datei nicht lesbar: {e}")
    return werte_zeilen_aus(zeilen, datei, mtime)


# ---------------- Ablage im Ordner „Fahrzeuge“ ----------------

_GELESEN = {}


def _pfad(wurzel: str) -> str:
    return os.path.join(wurzel, DATEI)


def _lies(pfad: str) -> dict:
    with open(pfad, encoding="utf-8") as f:
        daten = json.load(f)
    fahrzeuge = daten.get("fahrzeuge") if isinstance(daten, dict) else None
    if not isinstance(fahrzeuge, dict) or not all(isinstance(e, dict) for e in fahrzeuge.values()):
        raise ValueError("Syscara-Datei beschädigt")
    return fahrzeuge


def lade(wurzel: str) -> dict:
    """Schlüssel (Interne ID) -> gespeicherter Stand des Fahrzeugs aus dem neuesten Export; {} wenn es noch keine
    Syscara-Daten gibt. Ist die Datei gerade gesperrt oder kaputt, gilt der zuletzt gelesene Stand (ein Fehlversuch
    wird nicht gemerkt) – gibt es keinen: NichtLesbar (sonst verlöre jedes Fahrzeug seinen Abgleich)."""
    pfad = _pfad(wurzel)
    zuletzt = _GELESEN.get(pfad)
    try:
        stempel = os.stat(pfad).st_mtime_ns
        if zuletzt and zuletzt[0] == stempel:
            return zuletzt[1]
        fahrzeuge = _lies(pfad)
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as e:
        if zuletzt:
            return zuletzt[1]
        raise NichtLesbar(beschaedigt=isinstance(e, ValueError)) from e
    _GELESEN[pfad] = (stempel, fahrzeuge)
    return fahrzeuge


def speichere_export(wurzel: str, export: Export, von: str = "") -> dict:
    """Führt den Export in die Ablage ein. Pro Fahrzeug gewinnt der neuere Export.
    Gibt {'neu': [...], 'aktualisiert': [...], 'aelter': [...], 'gleich': [...]} (Schlüssel) zurück."""
    pfad = _pfad(wurzel)
    alle = {}
    if os.path.exists(pfad):                         # frisch lesen – nie von einem Fehlversuch aus überschreiben
        try:
            alle = _lies(pfad)
        except ValueError:
            alle = dict(_GELESEN.get(pfad, (None, {}))[1])
            os.replace(pfad, os.path.join(wurzel, f"_odin-syscara.defekt-{dt.datetime.now():%Y%m%d-%H%M%S}.json"))
        except OSError as e:
            raise PermissionError(f"Die Syscara-Daten sind gerade gesperrt (z. B. von OneDrive) – bitte gleich noch "
                                  f"einmal versuchen. ({e})") from e
    erg = {"neu": [], "aktualisiert": [], "aelter": [], "gleich": []}
    jetzt = dt.datetime.now().isoformat(timespec="seconds")
    meta = ("export", "stand", "stand_geschaetzt", "eingelesen", "von")
    for fz in export.fahrzeuge:
        alt = alle.get(fz.schluessel)
        eintrag = {**asdict(fz), "export": export.datei, "stand": export.stand, "eingelesen": jetzt, "von": von}
        if not eintrag["mehrdeutig"]:
            del eintrag["mehrdeutig"]
        if export.stand_geschaetzt:
            eintrag["stand_geschaetzt"] = True
        # älter nur, wenn beide Exporte einen Zeitstempel haben – ohne gilt der gerade gewählte als neuester
        sicher = not (export.stand_geschaetzt or (alt or {}).get("stand_geschaetzt"))
        if alt and sicher and alt.get("stand", "") > export.stand:
            erg["aelter"].append(fz.schluessel)
            continue
        inhalt = {k: v for k, v in eintrag.items() if k not in meta}
        if alt and {k: v for k, v in alt.items() if k not in meta} == inhalt:
            erg["gleich"].append(fz.schluessel)
            if alt.get("stand", "") <= export.stand:      # nur Datum und Datei nachziehen
                alt.update(export=export.datei, stand=export.stand)
                if export.stand_geschaetzt:
                    alt["stand_geschaetzt"] = True
                else:
                    alt.pop("stand_geschaetzt", None)
            continue
        erg["aktualisiert" if alt else "neu"].append(fz.schluessel)
        alle[fz.schluessel] = eintrag
    tmp = f"{pfad}.{os.getpid()}.{secrets.token_hex(4)}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"format": 1, "fahrzeuge": alle}, f, ensure_ascii=False, indent=1)
    os.replace(tmp, pfad)
    _GELESEN.pop(pfad, None)
    return erg


def finde(daten: dict, interne_id: str = "", nummern=()) -> dict:
    """Syscara-Stand zu einem Fahrzeug: über die Interne ID, sonst über Bestell- oder Seriennummer."""
    if interne_id and interne_id.upper() in daten:
        return daten[interne_id.upper()]
    gesucht = {_ziffern_oder_text(n) for n in nummern if n}
    if not gesucht:
        return None
    return next((e for e in daten.values()
                 if {_ziffern_oder_text(e.get("bestellnummer")), _ziffern_oder_text(e.get("seriennummer"))} & gesucht
                 - {""}), None)


def stempel(eintrag: dict) -> str:
    if not eintrag:
        return ""
    werte = {k: eintrag.get(k) for k in ("interne_id", "baureihe", "modell", "fin", "seriennummer", "bestellnummer",
                                         "ausstattung")}
    if eintrag.get("mehrdeutig"):
        werte["mehrdeutig"] = eintrag["mehrdeutig"]
    roh = json.dumps(werte, sort_keys=True)
    return hashlib.sha1(roh.encode()).hexdigest()[:12]


# ---------------- Wörter vergleichen ----------------

def _ziffern_oder_text(wert) -> str:
    t = re.sub(r"[\s.\-/]", "", str(wert or "")).upper()
    return t.lstrip("0") if t.isdigit() else t


def _ohne_akzente(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    return "".join(c for c in s if not unicodedata.combining(c)).casefold()


def woerter(text: str) -> list:
    """'Citroën Jumper 3.500 kg' -> ['citroen', 'jumper', '3500', 'kg']; 'Expedition Grey' -> [..., 'grau'];
    'Markise 4,0 m' -> ['markise', '4']"""
    s = _ohne_akzente(text)
    s = re.sub(r"(\d+)[.,](\d+)\s*t\b", lambda m: f" {round(float(m.group(1) + '.' + m.group(2)) * 1000)} kg ", s)
    s = re.sub(r"(?<=\d)\.(?=\d{3}\b)", "", s)                  # 3.500 -> 3500
    s = re.sub(r"(?<=\d)\.(?=\d)", ",", s)                       # 2.2 -> 2,2
    ergebnis = []
    for w in re.findall(r"[a-z]+|\d+(?:,\d+)?", s):
        if "," in w:                                             # 4,0 = 4,00 = 4; 4,50 = 4,5
            ganz, bruch = w.split(",")
            w = ganz + ("," + bruch.rstrip("0") if bruch.rstrip("0") else "")
        w = SYNONYME.get(w, w)
        if w in FUELLWOERTER or (len(w) == 1 and not w.isdigit()):
            continue
        ergebnis.append(w)
    return ergebnis


def ist_gekuerzt(name: str) -> bool:
    """Auf 50 Zeichen gekürzter Syscara-Name – sein letztes Wort kann abgeschnitten sein („… Umsc“)."""
    return len(" ".join((name or "").split())) >= GEKUERZT


def _gleich(a: str, b: str) -> bool:
    if a == b:
        return True
    if a[0].isdigit() or b[0].isdigit() or len(a) < 4 or len(b) < 4:     # Zahlen nur exakt
        return False
    kurz, lang = sorted((a, b), key=len)
    # Grundwort am Ende: markise ↔ cassettenmarkise – aber nicht markise ↔ markisenleuchte
    if len(kurz) >= 5 and kurz not in ALLGEMEIN and lang.endswith(kurz):
        return True
    return difflib.SequenceMatcher(None, a, b).ratio() >= 0.86   # anhangerkupplung ↔ anhangekupplung


def _gewicht(w: str) -> float:
    return 0.35 if w in ALLGEMEIN else 1.0


def _schraenkt_ein(a: list, s: list) -> bool:
    """Steht in der AB ein bedeutungsänderndes Wort, das im Syscara-Namen fehlt?"""
    for x in a:
        if x in EINSCHRAENKUNG_WORT and x not in s:
            return True
        if any(t in x and not any(t in w for w in s) for t in EINSCHRAENKUNG_TEIL):
            return True
    return False


def bewerte(syscara: str, ab_text: str, beschreibung: str = "", gekuerzt: bool = None) -> tuple:
    """(Klasse, Punkte) für ein Paar Syscara-Name ↔ AB-Bezeichnung. Klasse: 'gleich', 'woerter' oder ''.
    gekuerzt (sonst aus der Länge von Name + Beschreibung): das letzte Wort darf ein Wortanfang sein."""
    s, a = woerter(syscara), woerter(ab_text)
    if not s or not a:
        return "", 0.0
    if gekuerzt is None:
        gekuerzt = ist_gekuerzt(syscara + beschreibung)
    anfang = len(s) - 1 if gekuerzt and not woerter(beschreibung) else -1    # Index des abgeschnittenen Worts

    def passt(i, w, x):
        return _gleich(w, x) or (i == anfang and x.startswith(w))

    if s == a or (anfang >= 0 and len(a) >= len(s) and s[:-1] == a[:len(s) - 1] and a[len(s) - 1].startswith(s[-1])
                  and not _schraenkt_ein(a, s)):
        return "gleich", 1.0
    treffer_s = [w for i, w in enumerate(s) if any(passt(i, w, x) for x in a)]
    treffer_a = [x for x in a if any(passt(i, w, x) for i, w in enumerate(s))]
    abdeckung_s = sum(map(_gewicht, treffer_s)) / sum(map(_gewicht, s))
    abdeckung_a = len(treffer_a) / len(a)
    punkte = 0.65 * abdeckung_s + 0.35 * abdeckung_a
    if beschreibung:                                             # Text in Klammern (gekürzt) als kleiner Bonus
        b = [w for w in woerter(beschreibung) if w not in s]
        if b:
            punkte += 0.1 * sum(any(_gleich(w, x) for x in a) for w in b) / len(b)
    if (len(treffer_s) == len(s) and (len(s) >= 2 or len(s[0]) >= 6) and any(_gewicht(w) == 1 for w in s)
            and not _schraenkt_ein(a, s)):
        return "woerter", max(punkte, 0.9)                     # alle Wörter des Syscara-Namens stehen in der AB
    return "", round(punkte, 3)


def zahlen_fehlen(name: str, ab_texte) -> list:
    """Zahlen des ganzen Syscara-Namens (auch in Klammern), die in keinem der AB-Texte stehen:
    'Dieseltank (90 l)' ↔ 'Dieseltank 120 l' -> ['90']. Bei gekürzten Namen darf die letzte Zahl abgeschnitten sein."""
    w = woerter(name)
    ab = {x for t in ab_texte for x in woerter(t) if x[0].isdigit()}
    letzte = len(w) - 1 if ist_gekuerzt(name) else -1
    return [x for i, x in enumerate(w)
            if x[0].isdigit() and x not in ab and not (i == letzte and any(y.startswith(x) for y in ab))]


def schluessel(name: str) -> str:
    """Schlüssel eines Syscara-Namens für gelernte Zuordnungen."""
    return " ".join(_ohne_akzente(name).split())


def ist_nebenkosten(text: str) -> bool:
    return bool(NEBENKOSTEN.search((text or "").lower()))


def _preis(p) -> str:
    """Preis einer Position (Einzelpreis, sonst Gesamtpreis), '' wenn ohne Preis."""
    for wert in (p.get("einzelpreis"), p.get("gesamtpreis")):
        if wert and re.sub(r"[^\d]", "", wert).strip("0"):
            return wert
    return ""


def _null(p) -> bool:
    """Ausdrücklich 0,00 (nicht leer)."""
    return not _preis(p) and any(re.search(r"\d", w or "") for w in (p.get("einzelpreis"), p.get("gesamtpreis")))


def position_dict(p: Position) -> dict:
    return {"pos": p.pos, "artikel": p.artikel, "text": " ".join((p.text or "").split()),
            "einzelpreis": p.einzelpreis, "gesamtpreis": p.gesamtpreis, "inhalt": list(p.inhalt or [])}


def ab_auszug(ab: AB) -> dict:
    """Was der Abgleich von einer AB braucht – wird gespeichert, damit Zuordnungen ohne erneutes Lesen wirken."""
    kopf = ab.kopf or {}
    return {"positionen": [position_dict(p) for p in ab.positionen],
            "interne_id": ab.interne_id, "auftragsnummer": ab.auftragsnummer,
            "weitere_nummern": list(ab.weitere_nummern or []), "belegart": ab.belegart or "",
            "seriennummer": kopf.get("Seriennummer") or kopf.get("Serien-Nr.") or "",
            "fin": kopf.get("Fahrgestell-Nr.") or kopf.get("FIN") or ""}


# ---------------- Abgleich ----------------

def _pos_kurz(p: dict) -> dict:
    return {"pos": p["pos"], "artikel": p["artikel"], "text": p["text"], "preis": _preis(p)}


def _ab_texte(p: dict) -> list:
    return [p["text"], *p.get("inhalt", [])]


def _teile(z: dict) -> list:
    """Die Positionen einer gelernten Zuordnung, je {artikel, schluessel, text}. Ältere Regeln haben nur die Listen
    „artikel“ und „titel_schluessel“ – gleich lang: paarweise, sonst je Titel eine Position (Artikel beliebig aus der Liste)."""
    if z.get("teile"):
        return z["teile"]
    artikel, titel = z.get("artikel", []), z.get("titel_schluessel", [])
    if len(artikel) == len(titel):
        return [{"artikel": a, "schluessel": t} for a, t in zip(artikel, titel)]
    if not titel:
        return [{"artikel": a} for a in artikel]
    return [{"schluessel": t, "artikel_aus": artikel} for t in titel]


def _teil_findet(t: dict, p: dict) -> bool:
    return bool((t.get("artikel") and p["artikel"] == t["artikel"]) or p["artikel"] in t.get("artikel_aus", ())
                or (t.get("schluessel") and schluessel(p["text"]) == t["schluessel"]))


def _teil_name(t: dict) -> str:
    return t.get("text") or t.get("schluessel") or t.get("artikel") or ""


def gleiche_ab(eintrag: dict, auszug: dict, zuordnungen: list = (), ignoriert_ab: list = ()) -> dict:
    """Vergleicht den Syscara-Stand eines Fahrzeugs mit einer AB (als ab_auszug).

    zuordnungen:  gelernte Zuordnungen des Herstellers [{syscara (Schlüssel), teile/artikel/titel_schluessel, id}],
                  mehrere je Name sind Alternativen; ohne Positionen = steht nie in der AB (z. B. Verkaufsaktion).
    ignoriert_ab: Artikel des Herstellers, die nie in Syscara stehen (z. B. Händlerbeteiligung)."""
    positionen = auszug.get("positionen", [])
    frei = list(range(len(positionen)))
    zeilen = []
    gelernt = {}
    for z in zuordnungen:
        gelernt.setdefault(z["syscara"], []).append(z)

    def belege(treffer):
        for j in treffer:
            if j in frei:
                frei.remove(j)

    def nach_regel(regeln: list) -> dict:
        """Ergebnis der gelernten Zuordnungen eines Namens (Alternativen); belegt die gefundenen Positionen.
        Alle Positionen einer Zuordnung müssen da sein. None: keine davon steht in dieser AB."""
        teilweise = None
        for z in regeln:
            teile = _teile(z)
            if not teile:
                continue
            gefunden, fehlen = [], []
            for t in teile:                                  # jede Position zählt nur einmal, freie zuerst
                j = next((j for j in frei + list(range(len(positionen)))
                          if j not in gefunden and _teil_findet(t, positionen[j])), None)
                if j is None:
                    fehlen.append(t)
                else:
                    gefunden.append(j)
            if gefunden and not fehlen:
                belege(gefunden)
                return {"status": PASST, "wie": "gelernt", "ab": [_pos_kurz(positionen[j]) for j in gefunden],
                        "regel": z.get("id", "")}
            if gefunden and (not teilweise or len(gefunden) > len(teilweise[1])):
                teilweise = (z, gefunden, fehlen)
        if teilweise:                                        # Paket nur zum Teil in der AB
            z, gefunden, fehlen = teilweise
            belege(gefunden)
            return {"status": FEHLT, "wie": "gelernt", "ab": [_pos_kurz(positionen[j]) for j in gefunden],
                    "regel": z.get("id", ""), "erwartet": ", ".join(map(_teil_name, fehlen))}
        nie = next((z for z in regeln if not _teile(z)), None)
        if nie:
            return {"status": IGNORIERT, "wie": "gelernt", "ab": [], "regel": nie.get("id", "")}
        return None

    def regel_fehlt(regeln: list) -> dict:
        return {"status": FEHLT, "wie": "gelernt", "ab": [], "regel": ",".join(z.get("id", "") for z in regeln),
                "erwartet": " oder ".join(z.get("titel") or ", ".join(map(_teil_name, _teile(z))) for z in regeln)}

    # 1. Modell: Wörter, und jede Zahl der Modellbezeichnung muss in der Position stehen („T 7055“ ≠ „T7052“)
    modell = " ".join(x for x in (eintrag.get("baureihe", ""), eintrag.get("modell", "")) if x).strip()
    modell_schluessel = "modell: " + schluessel(modell)
    regel = nach_regel(gelernt[modell_schluessel]) if modell and modell_schluessel in gelernt else None
    if regel:
        zeilen.append({"art": "modell", "syscara": modell, "schluessel": modell_schluessel, **regel})
    elif modell:
        s = woerter(modell)
        zahlen = [w for w in s if w[0].isdigit()]
        bester, bestes, fehlen = None, (0.0, False), zahlen
        for j, p in enumerate(positionen):
            a = woerter(p["text"])
            if not s or not a:
                continue
            ohne = [w for w in zahlen if w not in a]
            wert = (round(sum(any(_gleich(w, x) for x in a) for w in s) / len(s), 6), not ohne)
            if bester is None or wert > bestes:              # bei gleich vielen Wörtern: die mit der Modellnummer
                bester, bestes, fehlen = j, wert, ohne
        punkte = bestes[0]
        gefunden = bester is not None and punkte >= 0.3
        if gefunden and punkte >= 0.6:
            frei.remove(bester)
        zeile = {"art": "modell", "syscara": modell, "schluessel": modell_schluessel, "wie": "woerter",
                 "status": PASST if punkte >= 0.6 and not fehlen else UNSICHER if gefunden else FEHLT,
                 "ab": [_pos_kurz(positionen[bester])] if gefunden else []}
        if gefunden and fehlen:
            zeile["hinweis"] = f"Modellnummer {' '.join(fehlen)} steht nicht in der AB-Position"
        if zeile["status"] == FEHLT and modell_schluessel in gelernt:
            zeile.update(regel_fehlt(gelernt[modell_schluessel]))
        zeilen.append(zeile)

    # 2. Ausstattung: gelernte Zuordnungen zuerst; finden sie nichts, wird automatisch gesucht
    ausstattung = _ohne_doppelte(list(eintrag.get("ausstattung", [])))
    mehrdeutig = set(eintrag.get("mehrdeutig") or ()) | {n for n in ausstattung if ausstattung.count(n) > 1}
    offen, ergebnis = [], {}
    for i, name in enumerate(ausstattung):
        regel = nach_regel(gelernt[schluessel(name)]) if schluessel(name) in gelernt else None
        if regel:
            ergebnis[i] = regel
        else:
            offen.append(i)

    # 3. automatisch: beste Paare zuerst, jede Position nur einmal; Zahlen (auch in Klammern) müssen in der AB stehen.
    #    Hat eine gelernte Zuordnung nichts gefunden, zählen nur Treffer mit allen Wörtern – sonst bleibt es bei „fehlt“
    #    mit dem, was erwartet wurde (ein „unsicher“ hielte eine spätere AB nicht offen)
    paare = []
    for i in offen:
        name = ausstattung[i]
        kern = kurzname(name)
        for j in frei:
            klasse, punkte = bewerte(kern, positionen[j]["text"], name[len(kern):])
            if klasse or (punkte >= 0.45 and schluessel(name) not in gelernt):
                fehlen = zahlen_fehlen(name, _ab_texte(positionen[j])) if klasse else []
                sicher = bool(klasse) and not fehlen
                paare.append((sicher and klasse == "gleich", sicher, bool(klasse), punkte, -j, i, j, klasse, fehlen))
    paare.sort(reverse=True)
    for *_, i, j, klasse, fehlen in paare:
        if i in ergebnis or j not in frei:
            continue
        frei.remove(j)
        ergebnis[i] = {"status": PASST if klasse and not fehlen else UNSICHER, "wie": klasse or "aehnlich",
                       "ab": [_pos_kurz(positionen[j])]}
        if fehlen:
            ergebnis[i]["hinweis"] = f"Zahl {', '.join(fehlen)} steht so nicht in der AB"
    # 4. im Paketinhalt einer Position („bestehend aus …“)
    for i in offen:
        if i in ergebnis:
            continue
        name = ausstattung[i]
        kern = kurzname(name)
        for p in positionen:
            for zeile in p.get("inhalt", []):
                if not bewerte(kern, zeile, name[len(kern):])[0]:
                    continue
                fehlen = zahlen_fehlen(name, [zeile, p["text"]])
                if not fehlen:
                    ergebnis[i] = {"status": PASST, "wie": "inhalt", "ab": [_pos_kurz(p)]}
                    break
                ergebnis.setdefault(i, {"status": UNSICHER, "wie": "inhalt", "ab": [_pos_kurz(p)],
                                        "hinweis": f"Zahl {', '.join(fehlen)} steht so nicht in der AB"})
            if ergebnis.get(i, {}).get("status") == PASST:
                break
    # 5. Übrig gebliebene mit gemeinsamem Stichwort als Vorschlag („Wohnwelt Jupiter“ ↔ „Wohnwelt Yoko“), nicht bei
    #    gelernter Zuordnung (wie 3.)
    rest = []
    for i in offen:
        if i in ergebnis or schluessel(ausstattung[i]) in gelernt:
            continue
        s = [w for w in woerter(kurzname(ausstattung[i])) if _gewicht(w) == 1 and not w[0].isdigit()]
        for j in frei:
            a = woerter(positionen[j]["text"])
            if any(_gleich(w, x) for w in s for x in a):
                rest.append((bewerte(kurzname(ausstattung[i]), positionen[j]["text"])[1], -j, i, j))
    for _, _, i, j in sorted(rest, reverse=True):
        if i in ergebnis or j not in frei:
            continue
        frei.remove(j)
        ergebnis[i] = {"status": UNSICHER, "wie": "stichwort", "ab": [_pos_kurz(positionen[j])]}
    for i in offen:
        if i not in ergebnis:
            regeln = gelernt.get(schluessel(ausstattung[i]))
            ergebnis[i] = (regel_fehlt(regeln) if regeln
                           else {"status": IGNORIERT, "wie": "gebuehr", "ab": []} if ist_nebenkosten(ausstattung[i])
                           else {"status": FEHLT, "wie": "", "ab": []})
    for i, name in enumerate(ausstattung):
        e = ergebnis[i]
        if name in mehrdeutig:          # zwei Optionen mit denselben ersten 50 Zeichen: nie sicher
            e = {**e, "status": UNSICHER if e["status"] in (PASST, IGNORIERT) else e["status"], "hinweis": MEHRDEUTIG,
                 "mehrdeutig": True}
        zeilen.append({"art": "ausstattung", "syscara": name, "kurz": kurzname(name), "schluessel": schluessel(name), **e})

    # 6. Positionen, die nur in der AB stehen. Ohne Preis (Info) ist 0,00 – ein leerer Preis nur in einer AB mit
    #    Preisen, die keine Vormerkung ist (dort fehlen Preise oft nur noch, z. B. bei Paketen)
    leer_ist_info = any(_preis(p) for p in positionen) and "vormerkung" not in auszug.get("belegart", "").casefold()
    ignoriert = {x["artikel"]: x.get("id", "") for x in ignoriert_ab}
    for j in frei:
        p = positionen[j]
        if p["artikel"] in ignoriert:
            status, regel = IGNORIERT, ignoriert[p["artikel"]]
        else:
            status, regel = (GEBUEHR if ist_nebenkosten(p["text"]) else NUR_AB if _preis(p)
                             else OHNE_PREIS if _null(p) or leer_ist_info else NUR_AB), ""
        zeilen.append({"art": "nur_ab", "status": status, "ab": [_pos_kurz(p)], "regel": regel})

    # 7. Nummern
    for feld, titel, ab_werte in (
            ("seriennummer", "Seriennummer", [auszug.get("seriennummer")]),
            ("fin", "Fahrgestellnummer", [auszug.get("fin")]),
            ("bestellnummer", "Bestellnummer", [auszug.get("auftragsnummer"), *auszug.get("weitere_nummern", [])])):
        soll = eintrag.get(feld, "")
        ist = [w for w in ab_werte if w]
        if not soll or not ist:
            continue
        gleich = _ziffern_oder_text(soll) in {_ziffern_oder_text(w) for w in ist}
        zeilen.append({"art": "nummer", "feld": titel, "status": PASST if gleich else ABWEICHUNG,
                       "syscara": soll, "ab_wert": ist[0]})
    return zusammenfassen(zeilen)


def zusammenfassen(zeilen: list) -> dict:
    zaehle = lambda *st: sum(z["status"] in st for z in zeilen if z["art"] in ("modell", "ausstattung"))
    fehlt, unsicher = zaehle(FEHLT), zaehle(UNSICHER)
    nur_ab = sum(z["art"] == "nur_ab" and z["status"] == NUR_AB for z in zeilen)
    abweichung = sum(z["art"] == "nummer" and z["status"] == ABWEICHUNG for z in zeilen)
    kurz = []
    for z in zeilen:
        if z["art"] == "nummer" and z["status"] == ABWEICHUNG:
            kurz.append(f"{z['feld']}: Syscara {z['syscara']} ≠ AB {z['ab_wert']}")
        elif z["art"] in ("modell", "ausstattung") and z["status"] == FEHLT:
            kurz.append(f"Fehlt in AB: {z['syscara'] or z.get('kurz')}"
                        + (f" (nicht gefunden: {z['erwartet']})" if z["ab"] and z.get("erwartet") else ""))
        elif z["art"] in ("modell", "ausstattung") and z["status"] == UNSICHER:
            kurz.append(f"Unsicher: {z['syscara'] or z.get('kurz')}" + (f" ↔ {z['ab'][0]['text']}" if z["ab"] else "")
                        + (f" ({z['hinweis']})" if z.get("hinweis") else ""))
        elif z["art"] == "nur_ab" and z["status"] == NUR_AB:
            p = z["ab"][0]
            kurz.append(f"Nur in AB: {p['text']}" + (f" ({p['preis']} €)" if p["preis"] else ""))
    return {"zeilen": zeilen, "passt": zaehle(PASST), "unsicher": unsicher, "fehlt": fehlt, "nur_ab": nur_ab,
            "abweichung": abweichung, "ausstattung": sum(z["art"] == "ausstattung" for z in zeilen),
            "ok": not (fehlt or unsicher or nur_ab or abweichung), "kurz": kurz}
