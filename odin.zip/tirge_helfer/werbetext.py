"""
mobile.de-Werbetext aus dem Preisschild: die wertvollsten Ausstattungen als Händler-Kürzel.

Bei mobile.de haben Baureihe/Modell und Werbetext zusammen 48 Zeichen, die Marke zählt nicht mit
(„Adventure Vento 540 Autom./SAT/Solar/AHK“).
So wird der Text gebaut:
1. Merkmale erkennen – in den Sonderausstattungen (mit Preis), im Inhalt von Paketen, in der Kurzliste auf
   Seite 1 („TV Sat-Antenne Navigation …“) und in den technischen Daten (Getriebe).
2. Bewerten – nach dem Preis der Position (stehen mehrere Merkmale in einer Position, z. B. „Radio mit
   Rückfahrkamera und Navi“, teilen sie sich den Preis). In Paketen zählt der Paketpreis geteilt durch alle
   Bestandteile, mindestens aber der Richtwert des Merkmals. Ohne Preis (Serie, Kurzliste) gilt der Richtwert.
3. Packen – ICONIC Edition immer zuerst, ACC direkt danach (wenn es passt), dann die wertvollsten, getrennt
   mit „/“, bis die Zeichen voll sind. Ist am Ende noch Platz, werden Kürzel ausgeschrieben („Autom.“ → „Automatik“).
Bewusst nicht als Merkmal: Vorbereitungen („Kabelvorbereitung für Solaranlage“ ist keine Solaranlage).
"""

import re

GRENZE = 48            # mobile.de: Modell + Werbetext
TRENNER = "/"

# id, Muster, Ausschluss, Kürzel, ausgeschrieben, Richtwert (€, wenn kein Preis dabeisteht) – Groß-/Kleinschreibung egal
KATALOG = [
    ("allrad", r"\b4x4\b|allrad|4motion", "", "4x4", "Allrad", 5000),
    ("automatik", r"automatikgetriebe|wandler-automatik|\bAT8\b|\bDSG\b|automatik-getriebe", "", "Autom.", "Automatik", 3500),
    ("aufstelldach", r"aufstelldach|schlafdach", "", "Aufstelldach", "Aufstelldach", 3000),
    ("sat", r"\bsat\b|sat-anlage|satanlage|sat-antenne|\bsat\d|teleco|oyster|kathrein", "", "SAT", "SAT", 2500),
    ("tv", r"\btv\b|flachbildschirm|fernseh", "", "TV", "TV", 900),
    ("dachklima", r"dachklima|dach-klima|klimaanlage (im|für den) aufbau|aufbauklima", "", "Dachklima", "Dachklima", 2000),
    # normale Klimaanlage hat jeder – nur die Klimaautomatik (Fahrerhaus) ist ein Verkaufsargument
    ("klimaautomatik", r"klima-?automatik|automatische klimaanlage|klimaanlage[^,;|]*automati|klimaanlage automatisch",
     "dachklima|dach-klima|aufbau", "Klimaautom.", "Klimaautomatik", 800),
    ("dieselheizung", r"dieselheizung|standheizung diesel|diesel-?standheizung|combi \d? ?d\b|combi d\b", "", "Dieselhzg.", "Dieselheizung", 1800),
    ("standheizung", r"standheizung", "", "Standhzg.", "Standheizung", 1200),
    ("hubbett", r"hubbett", "", "Hubbett", "Hubbett", 1400),
    ("lithium", r"lithium|lifepo|li-batt|li-ion", "", "Lithium", "Lithium", 1500),
    ("solar", r"solar", "", "Solar", "Solar", 900),
    ("wechselrichter", r"wechselrichter|inverter", "", "Inverter", "Wechselrichter", 900),
    ("ahk", r"anhänge(r)?kupplung|\bahk\b", "", "AHK", "AHK", 1200),
    ("markise", r"markise", "", "Markise", "Markise", 1000),
    ("acc", r"\bacc\b|adaptive[mnrs]?\s+(tempomat|geschwindigkeitsregel|cruise)|tempomat,? adaptiv|abstandsregel|"
            r"abstands-?tempomat|distronic|autonomous driving", "", "ACC", "ACC", 2500),
    ("navi", r"navi|navigationssystem|naviceiver", "", "Navi", "Navi", 900),
    ("rfk", r"rückfahrkamera", "zweite", "RFK", "RFK", 600),
    ("led", r"led-scheinwerfer|led scheinwerfer|voll-led", "", "LED", "LED-Scheinw.", 900),
    ("combi6e", r"combi 6 e\b|combi 6e\b", "", "Combi 6E", "Combi 6E", 700),
    ("winterpaket", r"winterpaket|winter-paket", "", "Winterpaket", "Winterpaket", 500),
    ("fahrrad", r"fahrradhalter|fahrradträger|radträger", "", "Radträger", "Fahrradträger", 700),
    ("alu", r"alufelgen|alu-felgen|leichtmetall|borbet", "", "Alu", "Alufelgen", 600),
    ("pdc", r"parksensor|einparkhilfe|parkpilot|\bpdc\b", "", "PDC", "Parksensoren", 500),
    ("isofix", r"isofix", "", "Isofix", "Isofix", 300),
    ("iconic", r"\biconic\b", "", "ICONIC Edition", "ICONIC Edition", 0),
]
# Gilt für jeden Eintrag: eine Vorbereitung ist keine Ausstattung („Kabelvorbereitung für Solaranlage“)
VORBEREITUNG = r"vorbereit|vorrüst|vorgerüst|vorverkabel|vorb\."
SCHLUESSEL = {k[0]: k for k in KATALOG}
# So wichtig für Käufer, dass sie mindestens mit ihrem Richtwert zählen, auch wenn sie billig im Paket stecken
MINDESTENS_RICHTWERT = {"acc"}
# Immer vorne, egal was sie kosten: die Edition zieht Aufmerksamkeit, ACC ist Käufern sehr wichtig
VORNE = ["iconic", "acc"]
# Ist das eine da, ist das andere überflüssig (Klimaautomatik im Fahrerhaus und Dachklima sind zwei Geräte)
UEBERFLUESSIG = {"standheizung": "dieselheizung"}


def _treffer(text: str) -> list:
    t = text or ""
    if re.search(VORBEREITUNG, t, re.I):
        return []
    return [id_ for id_, muster, ausschluss, *_ in KATALOG
            if re.search(muster, t, re.I) and not (ausschluss and re.search(ausschluss, t, re.I))]


def _bestandteile(inhalt: list) -> list:
    """Paketinhalt in einzelne Bestandteile: 'Markise, Solar, Raintec' / 'A | B'. Klammern bleiben zusammen."""
    text, teile, tiefe, aktuell = " ".join(inhalt), [], 0, ""
    for c in text:
        tiefe += (c == "(") - (c == ")")
        if c in ",|;" and tiefe <= 0:
            teile.append(aktuell)
            aktuell = ""
        else:
            aktuell += c
    teile.append(aktuell)
    return [" ".join(t.split()) for t in teile if t.strip()]


def _preis(kopf: str) -> int:
    from .fliesstext import PREIS_RE
    m = PREIS_RE.search(kopf or "")
    return int(re.sub(r"[^\d]", "", m.group(1).split(",")[0])) if m else 0


def optionen(seiten: list, td: dict = None) -> list:
    """Erkannte Merkmale, ICONIC und ACC vorne, sonst wertvollste zuerst: [{id, kurz, lang, wert, quelle}]."""
    from .fliesstext import schneide_sonderausstattung, zerlege_positionen
    try:
        positionen = zerlege_positionen(schneide_sonderausstattung(seiten))
    except ValueError:
        positionen = []
    return optionen_aus_positionen(positionen, seiten[0] if seiten else "", td)


def optionen_aus_positionen(positionen: list, seite1: str = "", td: dict = None) -> list:
    """Wie optionen(), aber aus fertigen Positionen [{kopf: „Name 1.234,00 €“, inhalt: [...]}] –
    z. B. aus der Syscara-Schnittstelle statt aus dem Preisschild. seite1: Kurzliste, falls vorhanden."""
    from .fliesstext import ist_gebuehr
    td = td or {}
    beste = {}

    def merke(id_, wert, quelle, echt):
        """echt: ein Preis vom Preisschild – gilt vor jedem Richtwert."""
        if id_ in MINDESTENS_RICHTWERT:
            wert = max(wert, SCHLUESSEL[id_][5])
        alt = beste.get(id_)
        if alt and (alt["echt"], alt["wert"]) >= (echt, wert):
            return
        _, _, _, kurz, lang, _ = SCHLUESSEL[id_]
        beste[id_] = {"id": id_, "kurz": kurz, "lang": lang, "wert": wert, "quelle": quelle, "echt": echt}

    for p in positionen:
        kopf = p["kopf"]
        if kopf in ("", "-") or ist_gebuehr(kopf):
            continue
        preis = _preis(kopf)
        im_kopf = _treffer(kopf)
        name = " ".join(kopf.split())
        for id_ in im_kopf:                                   # z. B. „8-Gang Automatikgetriebe 3.799 €“
            if preis:
                merke(id_, preis // len(im_kopf), name, True)
            else:
                merke(id_, SCHLUESSEL[id_][5], name, False)
        teile = _bestandteile(p["inhalt"])
        for teil in teile:                                    # Paketinhalt: jeder Bestandteil für sich
            for id_ in _treffer(teil):
                if id_ in im_kopf:
                    continue
                richtwert = SCHLUESSEL[id_][5]
                if preis and len(teile) == 1 and not im_kopf:   # z. B. Fahrgestell 3.399 € | „Automatikgetriebe“
                    merke(id_, preis, name, True)
                else:
                    merke(id_, max(preis // len(teile) if preis else 0, richtwert), f"in {name}", False)
        ps = re.search(r"(\d{3})\s*PS", kopf)
        if ps and int(ps.group(1)) >= 150 and preis:          # stärkerer Motor als die üblichen 120–140 PS
            beste["ps"] = {"id": "ps", "kurz": f"{ps.group(1)} PS", "lang": f"{ps.group(1)} PS", "wert": preis,
                           "quelle": name, "echt": True}
    # Kurzliste auf Seite 1 (Symbole): Serienausstattung zählt mit ihrem Richtwert
    for zeile in seite1.split("\n"):
        if re.search(r"Rückfahrkamera|Tempomat|Klimaanlage|Markise|Navigation|Zentralver", zeile):   # Kurzliste
            for id_ in _treffer(zeile.replace("Sat-Antenne", "SAT")):
                merke(id_, SCHLUESSEL[id_][5], "Kurzliste Seite 1", False)
    if "automatik" in (td.get("getriebe") or "").lower():
        merke("automatik", SCHLUESSEL["automatik"][5], "Technische Daten", False)
    for id_, besser in UEBERFLUESSIG.items():
        if besser in beste:
            beste.pop(id_, None)
    if "sat" in beste and "tv" in beste:                      # „SAT+TV“ als ein Merkmal
        sat, tv = beste.pop("sat"), beste.pop("tv")
        beste["sat"] = {"id": "sat", "kurz": "SAT+TV", "lang": "SAT+TV", "wert": sat["wert"] + tv["wert"],
                        "quelle": f"{sat['quelle']} · {tv['quelle']}", "echt": sat["echt"] or tv["echt"]}
    reihenfolge = [k[0] for k in KATALOG]

    def rang(o):
        return (VORNE.index(o["id"]) if o["id"] in VORNE else len(VORNE), -o["wert"],
                reihenfolge.index(o["id"]) if o["id"] in reihenfolge else 99)
    return sorted(beste.values(), key=rang)


def modell_kurz(modell: str) -> str:
    """Vorschlag für Baureihe und Modell: genau so, wie es auf dem Preisschild steht (bei mobile.de steht
    derselbe Text, er zählt mit zu den 48 Zeichen – die Marke nicht), z. B. 'Monte Shine 640 R Citroen'."""
    return " ".join((modell or "").split())


def baue(optionen_liste: list, modell: str = "", gewaehlt=None, grenze: int = GRENZE) -> dict:
    """Packt die Merkmale in die freien Zeichen. gewaehlt: feste Auswahl (ids) – sonst automatisch die
    wertvollsten, die passen. Gibt {text, werbetext, gewaehlt, laenge, frei, zu_lang} zurück."""
    modell = " ".join((modell or "").split())
    platz = grenze - (len(modell) + 1 if modell else 0)
    if gewaehlt is None:
        auswahl, laenge = [], 0
        for o in optionen_liste:
            dazu = len(o["kurz"]) + (len(TRENNER) if auswahl else 0)
            if laenge + dazu <= platz:
                auswahl.append(o)
                laenge += dazu
    else:
        auswahl = [o for o in optionen_liste if o["id"] in set(gewaehlt)]
    formen = {o["id"]: o["kurz"] for o in auswahl}
    for o in auswahl:                                        # Platz übrig: ausschreiben
        rest = platz - len(TRENNER.join(formen[x["id"]] for x in auswahl))
        if o["lang"] != o["kurz"] and len(o["lang"]) - len(o["kurz"]) <= rest:
            formen[o["id"]] = o["lang"]
    werbetext = TRENNER.join(formen[o["id"]] for o in auswahl)
    text = f"{modell} {werbetext}".strip()
    return {"text": text, "werbetext": werbetext, "gewaehlt": [o["id"] for o in auswahl], "laenge": len(text),
            "frei": grenze - len(text), "zu_lang": len(text) > grenze}
