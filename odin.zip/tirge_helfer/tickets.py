"""
Tickets: Probleme, Ideen und Fragen zu ODIN melden – und eine Brücke zu Claude.

Jede Person in ODIN kann ein Ticket anlegen (Art, Titel, Beschreibung, nachstellen, erwartet, Seite, Dringlichkeit,
auf Wunsch ein Bildschirmfoto). ODIN hängt den technischen Kontext an: Version, Plattform, Seite und – nur am Rechner –
die letzten Fehler aus dem eigenen Protokoll, vorher bereinigt (Benutzernamen in Pfaden, E-Mail-Adressen, Passwörter,
Schlüssel und Token fliegen raus). Vor dem Absenden sucht ODIN passende Hinweise: in einer kleinen, mitgelieferten
Liste typischer Probleme und in den Anleitungen aus „Wissen“.

Wer sieht was: Melder sehen ihre eigenen Tickets mit allen Antworten. Verwalter – wie bei den Tagesfragen die
Urlaubs-Genehmiger – sehen alle, setzen den Status und kopieren den Auftragstext für Claude. Im Browser (Handy,
Tablet) weiß ODIN nicht sicher, wer am Gerät sitzt: dort nur eigene Tickets und Anlegen, Verwalten nur am Rechner.

Brücke zu Claude: Die Tickets liegen im Ordner „Fahrzeuge“ unter _ODIN/Tickets/ (per OneDrive/SharePoint
synchronisiert) – je Ticket eine Datei <id>.json, das Bild als <id>.bild.jpg. Claude liest sie über den
SharePoint-Zugang und legt eine Antwort als <id>.antwort.json daneben (Format im README, Abschnitt „Tickets“, und in
LIESMICH-Claude.md im Ordner). ODIN zeigt sie als „Hinweis von Claude“; der Status folgt der Antwort („Hinweis
gegeben“ oder „erledigt“), bis jemand ihn danach von Hand ändert. Der Status wird dafür nicht in die Ticketdatei
geschrieben, sondern beim Lesen aus Verlauf und Antworten bestimmt – Lesen schreibt nie.

Alles aus dem gemeinsamen Ordner gilt als nicht vertrauenswürdig: Größe begrenzt, nur bekannte Felder, Texte gekürzt,
Links nur http(s), kein HTML (die Oberfläche maskiert jeden Text). IDs bestehen nur aus a–f und 0–9; aus der
Oberfläche kommt nie ein Pfad. Geschrieben wird über eine Zwischendatei, vor jeder Änderung wird frisch gelesen.
"""

import base64
import datetime as dt
import io
import os
import platform
import re
import secrets
import sys

from .projekte import ProjektFehler
from .speicher import ist_id, lies_json
from .urlaub_antraege import UrlaubFehler

ARTEN = {"fehler": "Fehler", "idee": "Idee", "frage": "Frage", "daten": "Daten falsch"}
STATUS = {"neu": "Neu", "pruefung": "In Prüfung", "hinweis": "Hinweis gegeben", "arbeit": "In Arbeit",
          "erledigt": "Erledigt", "abgelehnt": "Abgelehnt"}
OFFEN = ("neu", "pruefung", "hinweis", "arbeit")
DRINGLICHKEIT = {"niedrig": "Niedrig", "normal": "Normal", "hoch": "Hoch", "dringend": "Dringend"}
ANTWORT_STATUS = ("hinweis", "arbeit", "erledigt", "abgelehnt")      # was eine Antwortdatei setzen darf
MELDER_STATUS = ("erledigt", "neu")                                   # „Problem ist weg“ / „wieder öffnen“

ID_MUSTER = re.compile(r"[0-9a-f]{10}")
TICKET_DATEI = re.compile(r"([0-9a-f]{10})\.json")
ISO_ZEIT = re.compile(r"\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2})?)?")
VERSION_MUSTER = re.compile(r"[0-9A-Za-z][0-9A-Za-z.+_-]{0,39}")
LINK_MUSTER = re.compile(r"https?://[^\s<>\"'`\\]{3,480}")
STEUERZEICHEN = re.compile(r"[\x00-\x08\x0b-\x1f\x7f​-‏‪-‮⁦-⁩]")

MAX_TICKETS = 2000                       # so viele Dateien liest die Übersicht höchstens
MAX_TICKET_DATEI = 512 * 1024
MAX_ANTWORT_DATEI = 256 * 1024
MAX_ANTWORTEN = 20
MAX_VERLAUF = 300
MAX_BILD = 6 * 1024 * 1024               # angenommenes Bild (Bytes, vor dem Verkleinern)
MAX_BILD_DATEI = 3 * 1024 * 1024         # gespeichertes Bild, das wir wieder anzeigen
BILD_KANTE = 1920
PROTOKOLL_EINTRAEGE = 3
PROTOKOLL_TAGE = 3
PROTOKOLL_ZEILEN = 25
PROTOKOLL_LESEN = 96 * 1024
LAENGEN = {"titel": 120, "beschreibung": 4000, "schritte": 2000, "erwartet": 1000, "kommentar": 2000}


class TicketFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- Seiten → Dateien (für den Auftragstext)
# Welche Dateien hinter einer Seite stecken – damit Claude weiß, wo es anfangen soll. Pfade ab dem Repository.
_UI = "tirge-helfer/ui/"
_PY = "tirge-helfer/tirge_helfer/"
_CP = _PY + "cockpit/"
_COCKPIT = [_UI + "cockpit.js", _UI + "cockpit.css", _CP + "export.py"]
SEITEN = {
    "uebersicht": ("Übersicht", _COCKPIT + [_CP + "auswertungen.py"]),
    "heute": ("Heute & Woche", _COCKPIT + [_CP + "auswertungen.py"]),
    "assistent": ("Fragen (Assistent)", [_UI + "cockpit.js", _UI + "aktionen.js", _CP + "assistent.py",
                                         "tirge-helfer/tirge_helfer/aktionen/dienst.py"]),
    "aenderungen": ("Änderungen (In ODIN arbeiten)", [_UI + "aktionen.js", _UI + "aktionen.css",
                                                     "tirge-helfer/tirge_helfer/aktionen/dienst.py",
                                                     "tirge-helfer/tirge_helfer/aktionen/protokoll.py"]),
    "scorecard": ("Scorecard", _COCKPIT + [_CP + "fuehrung.py"]),
    "fristen": ("Fristen", _COCKPIT + [_CP + "fuehrung.py"]),
    "cashback": ("Cashback & Gutschriften", _COCKPIT + [_CP + "cashback.py"]),
    "todos": ("To-dos", _COCKPIT + [_CP + "todos.py"]),
    "bestand": ("Bestand", _COCKPIT + [_CP + "importer.py", _CP + "auswertungen.py"]),
    "fahrzeug": ("Fahrzeug (Bestand)", _COCKPIT + [_CP + "importer.py", _CP + "auswertungen.py"]),
    "auslieferungen": ("Auslieferungen", _COCKPIT + [_CP + "importer.py", _CP + "auswertungen.py"]),
    "finanzierung": ("Finanzierung", _COCKPIT + [_CP + "importer.py", _CP + "auswertungen.py"]),
    "zinsuhr": ("Zinsuhr & Langsteher", _COCKPIT + [_CP + "auswertungen.py"]),
    "vororder": ("Linien & Bestellungen", _COCKPIT + [_CP + "vororder.py"]),
    "liquiditaet": ("Liquidität", _COCKPIT + [_CP + "auswertungen.py", _CP + "importer.py"]),
    "provisionen": ("Provisionen", _COCKPIT + [_CP + "auswertungen.py"]),
    "teile": ("Teile & Montage", _COCKPIT + [_CP + "auswertungen.py", _CP + "fahrzeugtypen.py"]),
    "excel": ("Datenquellen", _COCKPIT + [_CP + "daten.py", _CP + "importer.py", _CP + "struktur.py"]),
    "konto": ("Konto & Anmeldung", [_UI + "cockpit.js", _PY + "konto.py", _PY + "microsoft.py"]),
    "web": ("Handy & Tablet (Browser)", [_UI + "cockpit.js", _PY + "web.py"]),
    "abs": ("Auftragsbestätigungen", [_UI + "abs.js", _PY + "fahrzeugablage.py", _PY + "ab_lesen.py",
                                      _PY + "ab_vergleich.py"]),
    "ausstattung": ("Ausstattungsvergleich", [_UI + "ausstattung.js", _PY + "syscara.py", _PY + "regeln.py"]),
    "preisschilder": ("Preisschilder & Texte", [_UI + "app.js", _PY + "fliesstext.py", _PY + "syscara_api.py",
                                                _PY + "werbetext.py"]),
    "fahrzeuge": ("Fahrzeugordner", [_UI + "abs.js", _PY + "fahrzeugablage.py"]),
    "projekte": ("Alle Projekte", [_UI + "projekte.js", _PY + "projekte.py"]),
    "projekt": ("Projekt", [_UI + "projekte.js", _PY + "projekte.py"]),
    "aufgaben": ("Meine Aufgaben", [_UI + "projekte.js", _PY + "projekte.py"]),
    "urlaub": ("Urlaub", [_UI + "urlaub.js", _PY + "urlaub_antraege.py"]),
    "tagesfragen": ("Tagesfragen", [_UI + "tagesfragen.js", _PY + "tagesfragen.py"]),
    "besprechungen": ("Besprechungen", [_UI + "besprechungen.js", _PY + "besprechungen.py"]),
    "besprechung": ("Besprechung", [_UI + "besprechungen.js", _PY + "besprechungen.py"]),
    "beschluesse": ("Beschluss-Log", [_UI + "besprechungen.js", _PY + "besprechungen.py"]),
    "ziele": ("Quartalsziele", [_UI + "besprechungen.js", _PY + "besprechungen.py", _PY + "projekte.py"]),
    "rechtsfaelle": ("Rechtsfälle", [_UI + "rechtsfaelle.js", _PY + "rechtsfaelle.py"]),
    "rechtsfall": ("Rechtsfall", [_UI + "rechtsfaelle.js", _PY + "rechtsfaelle.py"]),
    "wissen": ("Wissen & Einarbeitung", [_UI + "wissen.js", _PY + "wissen.py"]),
    "beirat": ("Beirat & Coaching", [_UI + "beirat.js", _PY + "beirat.py", _PY + "beirat_inhalte.py"]),
    "messe": ("Messe-Personal", [_UI + "messe.js", _PY + "messe.py"]),
    "tickets": ("Tickets", [_UI + "tickets.js", _PY + "tickets.py"]),
}
IMMER = ["tirge-helfer/app.py"]          # verbindet Oberfläche und Logik – fast immer beteiligt


# ---------------------------------------------------------------- Bekannte Probleme (mitgeliefert)
# Stichwörter umlautfrei und klein; ein Stichwort passt, wenn ein Wort der Meldung damit beginnt. `seiten`: auf diesen
# Seiten zählt der Hinweis etwas mehr. Nur Dinge, die in ODIN so sind.
BEKANNTE_PROBLEME = [
    {"id": "excel", "titel": "Eine Excel-Liste wird nicht gelesen",
     "stichworte": ["excel", "liste", "gelesen", "einlesen", "eingelesen", "bestandsliste", "finanzaufstellung",
                    "teileliste", "auslieferungsliste", "spalte", "zeilen", "xlsx", "mappe", "erkannt"],
     "seiten": ["excel", "bestand", "auslieferungen", "finanzierung", "teile", "liquiditaet", "provisionen"],
     "text": "Unten links „Datenquellen“ öffnen: Ist bei der Liste eine Datei gewählt – am besten direkt im "
             "OneDrive-Ordner? Steht dort ein Hinweis (fehlende Spalte, Blatt nicht gefunden)? Danach „Jetzt neu "
             "einlesen“. Ist die Datei gerade in Excel geöffnet oder synchronisiert OneDrive noch, kurz warten. Wird "
             "die Liste weiter nicht erkannt: „Aufbau prüfen“ speichert einen Bericht ohne Werte – den ans Ticket "
             "hängen statt der Datei.",
     "link": "#/excel", "link_text": "Datenquellen öffnen"},
    {"id": "beispieldaten", "titel": "Das Cockpit zeigt erfundene Beispieldaten",
     "stichworte": ["beispiel", "beispieldaten", "erfunden", "demo", "falsche", "fremde", "testdaten"],
     "seiten": ["uebersicht", "bestand", "excel"],
     "text": "Solange keine Liste eingerichtet ist, rechnet ODIN mit Beispieldaten. Unter „Datenquellen“ je Liste "
             "einmal „Datei wählen …“ – ODIN liest sie sofort probeweise und sagt, wie viele Zeilen es erkannt hat.",
     "link": "#/excel", "link_text": "Datenquellen öffnen"},
    {"id": "aktuell", "titel": "Eine Änderung in der Liste erscheint nicht",
     "stichworte": ["veraltet", "alt", "aktuell", "aktualisiert", "geaendert", "erscheint", "fehlt", "neu",
                    "stand", "nachgetragen"],
     "seiten": ["uebersicht", "bestand", "auslieferungen", "heute", "excel"],
     "text": "ODIN liest die Excel-Listen beim Öffnen und wenn man ins Fenster zurückkehrt. Ist die Änderung auf "
             "einem anderen Rechner gemacht, muss OneDrive sie erst herunterladen (Wolken-Symbol unten rechts). "
             "Danach „Datenquellen → Jetzt neu einlesen“. Die Liste bleibt die Quelle: ODIN ändert sie nie.",
     "link": "#/excel", "link_text": "Datenquellen öffnen"},
    {"id": "zahlen", "titel": "Eine Zahl oder ein Preis stimmt nicht",
     "stichworte": ["falsch", "stimmt", "preis", "betrag", "summe", "zahl", "datum", "rechnet", "abweichung"],
     "seiten": ["teile", "bestand", "finanzierung", "liquiditaet", "provisionen", "auslieferungen"],
     "text": "Fast alle Zahlen kommen aus den Excel-Listen. Erst in der Liste nachsehen, ob der Wert dort stimmt – "
             "dann ist es ein Lesefehler von ODIN (bitte Fahrzeug, Zeile oder Teilenummer ins Ticket schreiben). "
             "Steht es in der Liste schon falsch, dort korrigieren und neu einlesen.",
     "link": "#/excel", "link_text": "Datenquellen öffnen"},
    {"id": "onedrive", "titel": "Der Ordner „Fahrzeuge“ ist nicht gewählt",
     "stichworte": ["onedrive", "sharepoint", "ordner", "fahrzeuge", "synchron", "gemeinsam", "andere", "sehen",
                    "kollegen", "verbinden", "projekte"],
     "seiten": ["abs", "fahrzeuge", "projekte", "tickets"],
     "text": "Projekte, Urlaub, Tagesfragen, Wissen und Tickets liegen im SharePoint-Ordner „Fahrzeuge“, den "
             "OneDrive auf jeden Rechner synchronisiert. Ist er auf diesem Rechner nicht gewählt, speichert ODIN "
             "nur hier – die anderen sehen dann nichts. Unter „Auftragsbestätigungen“ den Ordner „Fahrzeuge“ wählen "
             "(der OneDrive-Ordner, nicht eine Kopie).",
     "link": "#/abs", "link_text": "Ordner wählen"},
    {"id": "syscara", "titel": "Die Syscara-Anmeldung schlägt fehl",
     "stichworte": ["syscara", "anmeldung", "anmelden", "zugang", "login", "benutzer", "schnittstelle", "401",
                    "kennwort"],
     "seiten": ["preisschilder", "ausstattung", "bestand"],
     "text": "Unter „Preisschilder & Texte“ → „Aus Syscara holen“ → „Zugang ändern“ Benutzername und Passwort neu "
             "eingeben und „Prüfen und speichern“. Den Zugang vergibt Syscara; wurde das Passwort dort geändert, "
             "gilt das alte in ODIN nicht mehr. Der Zugang liegt nur auf diesem Rechner – jeder Rechner braucht ihn "
             "einmal. Passwörter nie ins Ticket schreiben.",
     "link": "#/preisschilder", "link_text": "Preisschilder & Texte"},
    {"id": "microsoft", "titel": "Die Microsoft-Anmeldung klappt nicht",
     "stichworte": ["microsoft", "konto", "anmelden", "anmeldung", "mail", "erinnerung", "devicelogin", "office",
                    "outlook", "abmelden"],
     "seiten": ["konto"],
     "text": "Datenquellen → „Konto & Anmeldung“. Geht kein Browserfenster auf, „Mit Code anmelden“ wählen und den "
             "Code auf microsoft.com/devicelogin eingeben. Fehlt die Einrichtung (Anwendungs- und Verzeichnis-ID), "
             "trägt der Administrator sie einmal ein. Im Browser auf Handy und Tablet gibt es keine Anmeldung.",
     "link": "#/konto", "link_text": "Konto & Anmeldung"},
    {"id": "person", "titel": "ODIN hält mich für jemand anderen",
     "stichworte": ["person", "name", "wer", "ich", "jemand", "anderen", "falscher", "falsche", "kollege"],
     "seiten": ["projekte", "aufgaben", "urlaub", "tagesfragen", "tickets"],
     "text": "Wer an diesem Rechner arbeitet, merkt sich ODIN einmal je Rechner (im Browser je Gerät). Mit "
             "Microsoft angemeldet erkennt ODIN die Person an der E-Mail-Adresse. Sonst unter „Alle Projekte“ die "
             "richtige Person wählen.",
     "link": "#/projekte", "link_text": "Alle Projekte"},
    {"id": "browser", "titel": "Handy oder Tablet verbindet sich nicht",
     "stichworte": ["handy", "tablet", "iphone", "ipad", "browser", "nummer", "qr", "firewall", "wlan", "netz"],
     "seiten": ["web"],
     "text": "Auf dem Rechner, auf dem ODIN läuft: Handy-Symbol unten in der Seitenleiste → „Jetzt freigeben“. Das "
             "Gerät muss im selben Netz sein. Beim ersten Mal fragt Windows nach der Firewall – „Zugriff zulassen“ "
             "für private Netzwerke. Schließt man ODIN, endet die Freigabe.",
     "link": "#/web", "link_text": "Handy & Tablet"},
    {"id": "gesperrt", "titel": "Eine Seite fehlt im Browser",
     "stichworte": ["fehlt", "browser", "rechtsfaelle", "wissen", "gesperrt", "sehe", "nicht", "handy"],
     "seiten": ["web"],
     "text": "Im Browser sind Rechtsfälle, Wissen, Dateien wählen oder öffnen, Excel-Listen einrichten, Zugangsdaten "
             "und die Microsoft-Anmeldung bewusst gesperrt – das geht nur am Rechner.",
     "link": "", "link_text": ""},
    {"id": "wartet", "titel": "ODIN wartet auf eine Datei im gemeinsamen Ordner",
     "stichworte": ["wartet", "haengt", "langsam", "laedt", "speichern", "gespeichert", "klappt", "datei",
                    "beschaedigt"],
     "seiten": [],
     "text": "Meist synchronisiert OneDrive gerade oder eine Datei ist kurz gesperrt. Ein paar Sekunden warten und "
             "noch einmal versuchen. Kommt die Meldung immer wieder, ist eine gemeinsame Datei vielleicht beschädigt – "
             "das Ticket bekommt die letzten Fehler aus dem Protokoll automatisch mit.",
     "link": "", "link_text": ""},
    {"id": "ab", "titel": "Eine Auftragsbestätigung wird nicht erkannt",
     "stichworte": ["ab", "auftragsbestaetigung", "pdf", "erkannt", "eingang", "zugeordnet", "hersteller1",
                    "hersteller2", "hersteller3"],
     "seiten": ["abs", "fahrzeuge"],
     "text": "Nicht erkannte ABs landen in „AB-Eingang/Nicht erkannt“. Unter „Auftragsbestätigungen“ lässt sich die "
             "Auftragsnummer von Hand eintragen. Bitte Hersteller und Dateiname ins Ticket schreiben – die PDF "
             "selbst nicht anhängen.",
     "link": "#/abs", "link_text": "Auftragsbestätigungen"},
]

_FUELLWOERTER = {"und", "oder", "der", "die", "das", "den", "dem", "des", "ein", "eine", "einen", "einer", "ist",
                 "sind", "wird", "werden", "bei", "mit", "von", "vom", "zum", "zur", "auf", "aus", "fuer", "ich",
                 "wir", "es", "nicht", "kein", "keine", "mal", "noch", "schon", "wenn", "dann", "wie", "was", "wo",
                 "da", "im", "in", "an", "am", "so", "auch", "nur", "man", "mir", "mich", "geht", "gibt", "hat",
                 "habe", "bitte", "immer", "seit", "beim"}


# ---------------------------------------------------------------- kleine Helfer

def _neue_id(laenge: int = 10) -> str:
    return secrets.token_hex(laenge // 2)


def _sauber(wert) -> str:
    return STEUERZEICHEN.sub("", str(wert if isinstance(wert, str) else ""))


def _text(wert, laenge: int) -> str:
    return " ".join(_sauber(wert).split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    zeilen = [z.rstrip() for z in _sauber(wert).replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(zeilen)).strip()[:laenge]


def _wahl(wert, erlaubt, standard):
    return wert if isinstance(wert, str) and wert in erlaubt else standard


def _woerter(text) -> list:
    t = _sauber(text).casefold()
    for alt, neu in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(alt, neu)
    return [w for w in re.split(r"[^0-9a-z]+", t) if w]


def _zeit_gelesen(wert) -> str:
    return wert[:19] if isinstance(wert, str) and ISO_ZEIT.fullmatch(wert[:19].strip()) else ""


def route_gelesen(wert) -> str:
    """Nur eine ODIN-Seite in fester Form; frei getippte Teile (z. B. ein Suchtext im Hash) fallen weg."""
    wert = _text(wert, 240)
    if not wert.startswith("#/"):
        return ""
    teile = []
    for i, teil in enumerate(wert[2:].split("/")[:4]):
        if not re.fullmatch(r"[a-z0-9_-]{1,40}" if i == 0 else r"[A-Za-z0-9_-]{1,40}", teil):
            break
        teile.append(teil)
    return "#/" + "/".join(teile) if teile else ""


def seite_zu_route(route: str) -> tuple:
    """(Name der Seite, [Dateien]) zu einer Route wie „#/teile“ – unbekannte Seiten ohne Dateien."""
    name = (route or "")[2:].split("/")[0]
    titel, dateien = SEITEN.get(name, ("", []))
    return titel, list(dateien)


# Bereinigen, bevor etwas den Rechner verlässt (Auftragstext für Claude) oder im gemeinsamen Ordner landet
# (Protokollzeilen): Benutzernamen in Pfaden, E-Mail-Adressen, Passwörter, Schlüssel und Token.
_BEREINIGEN = [
    (re.compile(r"(?i)([A-Z]:(?:\\\\|\\|/)(?:Users|Benutzer|Documents and Settings|Dokumente und Einstellungen)"
                r"(?:\\\\|\\|/))[^\\/\s\"'<>|:]+"), r"\1…"),
    (re.compile(r"(?i)(/(?:home|Users)/)[^/\s\"'<>]+"), r"\1…"),
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+"), "[E-Mail]"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+"), "Bearer [entfernt]"),
    (re.compile(r"eyJ[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]*"), "[Token entfernt]"),
    (re.compile(r"(?i)\b(passw(?:or)?[dt]|kennwort|pwd|passwd|pin|token|access_token|refresh_token|id_token|"
                r"secret|client_secret|api[_-]?key|apikey|authorization|cookie|sitzung|session|zugangscode|"
                r"geheimzahl)(\"?'?\s*(?:[:=]|lautet)\s*\"?'?)([^\s\"',;}&]+)"), r"\1\2[entfernt]"),
    (re.compile(r"(?i)([?&](?:code|token|key|sig|signature|state|access_token|password)=)[^&\s\"']+"),
     r"\1[entfernt]"),
    (re.compile(r"\b(?=[A-Za-z0-9+_-]*\d)(?=[A-Za-z0-9+_-]*[A-Za-z])[A-Za-z0-9+_-]{40,}={0,2}"), "[entfernt]"),
]


def bereinigen(text) -> str:
    text = _sauber(text)
    for muster, ersatz in _BEREINIGEN:
        text = muster.sub(ersatz, text)
    return text


_ZUGANGSDATEN = re.compile(r"\b(passwort|paßwort|kennwort|password|passwd|pwd|pin|zugangscode|geheimzahl)\b"
                           r"\s*(?:[:=]|lautet)\s*(\S+)", re.IGNORECASE)
_ZUGANG_HARMLOS = {"siehe", "steht", "stehen", "liegt", "im", "in", "beim", "bei", "über", "ueber", "frag", "fragen",
                   "wie", "nicht", "nie", "kein", "keine", "falsch", "abgelaufen", "geändert", "geaendert", "–", "-",
                   "→", "vergessen", "gesperrt", "neu", "alt"}


def _keine_zugangsdaten(*texte):
    for text in texte:
        for m in _ZUGANGSDATEN.finditer(text or ""):
            if m.group(2).strip(".,;:!?()„“\"'").lower() not in _ZUGANG_HARMLOS:
                raise TicketFehler(f"Das sieht nach Zugangsdaten aus („{m.group(1)}: …“). Bitte keine Passwörter "
                                   "ins Ticket schreiben – es reicht „Syscara-Anmeldung schlägt fehl“.")


def _lies(pfad: str, grenze: int):
    try:
        if os.path.getsize(pfad) > grenze:
            return None
        return lies_json(pfad)
    except FileNotFoundError:
        return None
    except (OSError, ValueError):
        return None


def _schreibe(pfad: str, daten):
    import json
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise TicketFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


# ---------------------------------------------------------------- Dateien in fester Form

def _eintrag_form(e):
    if not isinstance(e, dict) or e.get("art") not in ("kommentar", "status"):
        return None
    aus = {"id": e["id"] if isinstance(e.get("id"), str) and re.fullmatch(r"[0-9a-f]{6,16}", e["id"]) else "",
           "art": e["art"], "von": e["von"] if ist_id(e.get("von")) else "",
           "am": _zeit_gelesen(e.get("am")), "text": _langtext(e.get("text"), LAENGEN["kommentar"])}
    if e["art"] == "status":
        if e.get("status") not in STATUS:
            return None
        aus["status"] = e["status"]
    return aus if aus["am"] else None


def ticket_form(d):
    """Eine Ticketdatei in fester Form – oder None, wenn sie kein Ticket (mehr) ist."""
    if not isinstance(d, dict) or not isinstance(d.get("id"), str) or not ID_MUSTER.fullmatch(d["id"]):
        return None
    k = d.get("kontext") if isinstance(d.get("kontext"), dict) else {}
    protokoll = k.get("protokoll") if isinstance(k.get("protokoll"), list) else []
    verlauf = [e for e in (_eintrag_form(x) for x in (d.get("verlauf") if isinstance(d.get("verlauf"), list) else [])
                           [:MAX_VERLAUF]) if e]
    t = {
        "version": 1, "id": d["id"],
        "art": _wahl(d.get("art"), ARTEN, "fehler"),
        "titel": _text(d.get("titel"), LAENGEN["titel"]) or "Ohne Titel",
        "beschreibung": _langtext(d.get("beschreibung"), LAENGEN["beschreibung"]),
        "schritte": _langtext(d.get("schritte"), LAENGEN["schritte"]),
        "erwartet": _langtext(d.get("erwartet"), LAENGEN["erwartet"]),
        "route": route_gelesen(d.get("route")),
        "dringlichkeit": _wahl(d.get("dringlichkeit"), DRINGLICHKEIT, "normal"),
        "von": d["von"] if ist_id(d.get("von")) else "",
        "am": _zeit_gelesen(d.get("am")),
        "bild": bool(d.get("bild") is True),
        "kontext": {
            "version": _text(k.get("version"), 40), "plattform": _text(k.get("plattform"), 160),
            "browser": bool(k.get("browser") is True), "bildschirm": _text(k.get("bildschirm"), 20),
            "protokoll": [_langtext(z, 4000) for z in protokoll[:PROTOKOLL_EINTRAEGE] if isinstance(z, str)],
        },
        "verlauf": verlauf,
    }
    return t if t["am"] else None


def _link_form(x):
    url, titel = (x.get("url"), x.get("titel")) if isinstance(x, dict) else (x, "")
    url = _text(url, 490)
    if not LINK_MUSTER.fullmatch(url):
        return None
    return {"url": url, "titel": _text(titel, 120) or url}


def antworten_form(d, mtime: str = "") -> list:
    """Antwortdatei von Claude in fester Form: eine Antwort ({"text": …}) oder {"antworten": [...]}. Unbekannte
    Felder fallen weg, Texte werden gekürzt, Links nur http(s). Ohne Zeitpunkt gilt der Zeitpunkt der Datei."""
    if not isinstance(d, dict):
        return []
    roh = d.get("antworten") if isinstance(d.get("antworten"), list) else [d]
    aus = []
    for a in roh[:MAX_ANTWORTEN]:
        if not isinstance(a, dict):
            continue
        text = _langtext(a.get("text"), 8000)
        if not text:
            continue
        behoben = _text(a.get("behoben_in"), 40)
        links = [l for l in (_link_form(x) for x in (a.get("links") if isinstance(a.get("links"), list) else [])[:5])
                 if l]
        aus.append({"text": text, "am": _zeit_gelesen(a.get("am")) or mtime,
                    "status": _wahl(a.get("status"), ANTWORT_STATUS, "hinweis"),
                    "behoben_in": behoben if VERSION_MUSTER.fullmatch(behoben) else "", "links": links})
    aus.sort(key=lambda a: a["am"])
    return aus


def status_bestimmen(t: dict, antworten: list) -> tuple:
    """(Status, wann, wodurch) – der jüngste Statuswechsel aus Verlauf oder Antwort gilt; ohne beides „neu“."""
    ereignisse = [(e["am"], 0, e["status"], "verlauf") for e in t["verlauf"] if e["art"] == "status"]
    ereignisse += [(a["am"], 1, a["status"], "claude") for a in antworten if a["am"]]
    if not ereignisse:
        return "neu", t["am"], ""
    am, _, status, quelle = max(ereignisse)
    return status, am, quelle


# ---------------------------------------------------------------- Protokoll

def protokoll_auszug(pfad: str, jetzt: dt.datetime) -> list:
    """Die letzten Fehler aus fehler.log (höchstens 3 aus den letzten 3 Tagen, je die letzten 25 Zeilen) – bereinigt."""
    if not pfad:
        return []
    try:
        with open(pfad, "rb") as f:
            f.seek(0, os.SEEK_END)
            groesse = f.tell()
            f.seek(max(0, groesse - PROTOKOLL_LESEN))
            roh = f.read().decode("utf-8", "replace")
    except OSError:
        return []
    eintraege = []
    for teil in re.split(r"(?m)^(?=--- )", roh):
        kopf = re.match(r"--- (\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2})", teil)
        if not kopf:
            continue
        try:
            wann = dt.datetime(int(kopf[3]), int(kopf[2]), int(kopf[1]), int(kopf[4]), int(kopf[5]))
        except ValueError:
            continue
        if jetzt - wann > dt.timedelta(days=PROTOKOLL_TAGE):
            continue
        zeilen = teil.rstrip().split("\n")
        if len(zeilen) > PROTOKOLL_ZEILEN + 1:
            zeilen = zeilen[:1] + ["…"] + zeilen[-PROTOKOLL_ZEILEN:]
        eintraege.append(bereinigen("\n".join(z[:400] for z in zeilen))[:4000])
    return eintraege[-PROTOKOLL_EINTRAEGE:]


# ---------------------------------------------------------------- Bildschirmfoto

def bild_pruefen(data_url) -> bytes:
    """Ein Bild aus der Oberfläche (data:-Adresse, PNG oder JPEG) prüfen und als JPEG neu schreiben – ohne
    Metadaten, höchstens 1920 Pixel lang. Ohne Pillow gibt es keine Bilder."""
    if not isinstance(data_url, str):
        raise TicketFehler("Das Bildschirmfoto ließ sich nicht lesen.")
    m = re.fullmatch(r"data:image/(png|jpeg);base64,([A-Za-z0-9+/=\s]+)", data_url[:MAX_BILD * 2])
    if not m:
        raise TicketFehler("Als Bildschirmfoto gehen nur PNG- oder JPEG-Bilder.")
    try:
        roh = base64.b64decode("".join(m.group(2).split()), validate=True)
    except ValueError:
        raise TicketFehler("Das Bildschirmfoto ließ sich nicht lesen.") from None
    if len(roh) > MAX_BILD:
        raise TicketFehler("Das Bildschirmfoto ist zu groß (höchstens 6 MB).")
    if not (roh.startswith(b"\x89PNG\r\n\x1a\n") or roh.startswith(b"\xff\xd8\xff")):
        raise TicketFehler("Als Bildschirmfoto gehen nur PNG- oder JPEG-Bilder.")
    try:
        from PIL import Image
        from .sicher import MAX_BILD_PIXEL
    except ImportError:
        raise TicketFehler("Bildschirmfotos gehen auf diesem Rechner nicht – bitte ohne Bild senden.") from None
    Image.MAX_IMAGE_PIXELS = MAX_BILD_PIXEL
    try:
        with Image.open(io.BytesIO(roh)) as bild:
            if bild.format not in ("PNG", "JPEG") or bild.width * bild.height > MAX_BILD_PIXEL:
                raise ValueError("Format oder Größe")
            bild.thumbnail((BILD_KANTE, BILD_KANTE))
            puffer = io.BytesIO()
            bild.convert("RGB").save(puffer, "JPEG", quality=82, optimize=True)
    except TicketFehler:
        raise
    except Exception:                                                    # noqa: BLE001 – jedes kaputte Bild
        raise TicketFehler("Das Bildschirmfoto ließ sich nicht lesen.") from None
    return puffer.getvalue()


# ---------------------------------------------------------------- Die Tickets

class Tickets:
    """
    `projekte` liefert Personen, „ich“ und den gemeinsamen Ordner, `urlaub_fabrik()` das Urlaub-Objekt (Genehmiger =
    Verwalter), `wissen_fabrik()` (optional) das Wissen für die Hinweise, `protokoll_pfad()` den Pfad von fehler.log,
    `im_browser()` sagt, ob der Aufruf aus dem Browser kommt, `version` die ODIN-Version.
    """

    def __init__(self, projekte, urlaub_fabrik, wissen_fabrik=None, protokoll_pfad=None, im_browser=None,
                 version="dev", jetzt=None):
        self._projekte = projekte
        self._urlaub_fabrik = urlaub_fabrik
        self._wissen_fabrik = wissen_fabrik
        self._protokoll_pfad = protokoll_pfad or (lambda: "")
        self._im_browser = im_browser or (lambda: False)
        self._version = version
        self._jetzt = jetzt or dt.datetime.now

    # ---------------- Orte ----------------
    def _ordner(self) -> str:
        return os.path.join(self._projekte._basis()[0], "Tickets")

    def _pfad(self, tid, endung: str = ".json") -> str:
        if not isinstance(tid, str) or not ID_MUSTER.fullmatch(tid):
            raise TicketFehler("Unbekanntes Ticket.")
        return os.path.join(self._ordner(), tid + endung)

    def _zeit(self) -> str:
        return self._jetzt().isoformat(timespec="seconds")

    # ---------------- Personen und Rechte ----------------
    def _lauf(self, ich_pflicht: bool = True) -> dict:
        try:
            personen = {p["id"]: p for p in self._projekte.personen()}
            ich = self._projekte.ich()
        except ProjektFehler as e:
            raise TicketFehler(str(e)) from None
        ich = ich if ich in personen else ""
        if ich_pflicht and not ich:
            raise TicketFehler("Bitte zuerst auswählen, wer du bist.")
        browser = bool(self._im_browser())
        genehmiger = []
        try:
            genehmiger = [g for g in self._urlaub_fabrik().regeln().get("genehmiger") or [] if g in personen]
        except (UrlaubFehler, ProjektFehler):
            pass
        return {"personen": personen, "ich": ich, "browser": browser, "verwalter_fehlt": not genehmiger,
                "verwalter": bool(ich) and ich in genehmiger and not browser}

    def _name(self, lauf: dict, pid: str) -> str:
        if pid == "claude":
            return "Claude"
        return (lauf["personen"].get(pid) or {}).get("name") or "(unbekannt)"

    # ---------------- Lesen ----------------
    def _lesen(self, tid: str):
        return ticket_form(_lies(self._pfad(tid), MAX_TICKET_DATEI))

    def _antworten(self, tid: str) -> list:
        pfad = self._pfad(tid, ".antwort.json")
        try:
            mtime = dt.datetime.fromtimestamp(os.path.getmtime(pfad)).isoformat(timespec="seconds")
        except OSError:
            return []
        return antworten_form(_lies(pfad, MAX_ANTWORT_DATEI), mtime)

    def _alle(self) -> list:
        try:
            namen = sorted(n for n in os.listdir(self._ordner()) if TICKET_DATEI.fullmatch(n))[:MAX_TICKETS]
        except OSError:
            return []
        tickets = []
        for n in namen:
            t = ticket_form(_lies(os.path.join(self._ordner(), n), MAX_TICKET_DATEI))
            if t and n == f"{t['id']}.json":
                tickets.append(t)
        return tickets

    def _sichtbar(self, lauf: dict, t: dict) -> bool:
        return lauf["verwalter"] or (bool(lauf["ich"]) and t["von"] == lauf["ich"])

    def _holen(self, lauf: dict, tid) -> dict:
        t = self._lesen(tid)
        if not t or not self._sichtbar(lauf, t):
            raise TicketFehler("Dieses Ticket gibt es nicht (mehr) – oder es gehört jemand anderem.")
        return t

    def _kurz(self, lauf: dict, t: dict) -> dict:
        antworten = self._antworten(t["id"])
        status, seit, quelle = status_bestimmen(t, antworten)
        kommentare = [e for e in t["verlauf"] if e["art"] == "kommentar"]
        letzte = max([t["am"]] + [e["am"] for e in t["verlauf"]] + [a["am"] for a in antworten])
        return {"id": t["id"], "nummer": t["id"][:6].upper(), "art": t["art"], "titel": t["titel"],
                "route": t["route"], "seite": seite_zu_route(t["route"])[0], "dringlichkeit": t["dringlichkeit"],
                "status": status, "status_seit": seit, "status_quelle": quelle, "von": t["von"],
                "von_name": self._name(lauf, t["von"]), "am": t["am"], "zuletzt": letzte,
                "antworten": len(antworten), "kommentare": len(kommentare), "bild": t["bild"],
                "eigen": t["von"] == lauf["ich"]}

    def _ansicht(self, lauf: dict, t: dict) -> dict:
        antworten = self._antworten(t["id"])
        kurz = self._kurz(lauf, t)
        verlauf = [{**e, "von_name": self._name(lauf, e["von"]), "status_text": STATUS.get(e.get("status"), "")}
                   for e in t["verlauf"]]
        eigen = t["von"] == lauf["ich"]
        return {**kurz, "beschreibung": t["beschreibung"], "schritte": t["schritte"], "erwartet": t["erwartet"],
                "kontext": t["kontext"] if lauf["verwalter"] or eigen else {}, "verlauf": verlauf,
                "claude": antworten, "bild_daten": self._bild(t) if t["bild"] else "",
                "darf": {"kommentieren": True, "status": lauf["verwalter"], "claude": lauf["verwalter"],
                         "melder_status": eigen and not lauf["verwalter"]}}

    def _bild(self, t: dict) -> str:
        pfad = self._pfad(t["id"], ".bild.jpg")
        try:
            if os.path.getsize(pfad) > MAX_BILD_DATEI:
                return ""
            with open(pfad, "rb") as f:
                roh = f.read(MAX_BILD_DATEI + 1)
        except OSError:
            return ""
        if not roh.startswith(b"\xff\xd8\xff") or len(roh) > MAX_BILD_DATEI:
            return ""
        return "data:image/jpeg;base64," + base64.b64encode(roh).decode()

    # ---------------- Für alle ----------------
    def start(self) -> dict:
        lauf = self._lauf(ich_pflicht=False)
        basis, nur_hier = self._projekte._basis()
        allgemein = {"personen": list(lauf["personen"].values()), "arten": ARTEN, "status": STATUS,
                     "dringlichkeiten": DRINGLICHKEIT, "im_browser": lauf["browser"], "nur_hier": nur_hier,
                     "version": self._version}
        if not lauf["ich"]:
            return {**allgemein, "ich": "", "ist_verwalter": False, "tickets": []}
        return {**allgemein, "ich": lauf["ich"], "ist_verwalter": lauf["verwalter"],
                "verwalter_fehlt": lauf["verwalter_fehlt"], "tickets": self._liste(lauf)}

    def _liste(self, lauf: dict) -> list:
        liste = [self._kurz(lauf, t) for t in self._alle() if self._sichtbar(lauf, t)]
        liste.sort(key=lambda t: t["zuletzt"], reverse=True)
        return liste

    def liste(self) -> list:
        return self._liste(self._lauf())

    def ticket(self, tid) -> dict:
        lauf = self._lauf()
        return self._ansicht(lauf, self._holen(lauf, tid))

    def zaehler(self) -> dict:
        """Für Seitenleiste und Heute & Woche: Verwalter – neue und offene Tickets; alle – eigene mit Hinweis."""
        lauf = self._lauf(ich_pflicht=False)
        if not lauf["ich"]:
            return {"neu": 0, "offen": 0, "hinweis": 0, "verwalter": False}
        neu = offen = hinweis = 0
        for t in self._alle():
            if not self._sichtbar(lauf, t):
                continue
            status = status_bestimmen(t, self._antworten(t["id"]))[0]
            neu += status == "neu"
            offen += status in OFFEN
            hinweis += status == "hinweis" and t["von"] == lauf["ich"]
        return {"neu": neu, "offen": offen, "hinweis": hinweis, "verwalter": lauf["verwalter"]}

    def hinweise(self, text="", route="") -> list:
        """Bekannte Lösungen zu einer Meldung: mitgelieferte typische Probleme und Anleitungen aus „Wissen“."""
        lauf = self._lauf(ich_pflicht=False)
        woerter = [w for w in _woerter(_text(text, 600)) if len(w) >= 2 and w not in _FUELLWOERTER][:40]
        seite = route_gelesen(route)[2:].split("/")[0]
        if not woerter:
            return []
        treffer = []
        for p in BEKANNTE_PROBLEME:
            passend = {s for s in p["stichworte"] if any(w.startswith(s) or (len(w) >= 5 and s.startswith(w))
                                                         for w in woerter)}
            punkte = len(passend) + (1 if passend and seite in p["seiten"] else 0)
            if punkte >= 2:
                treffer.append((punkte, {"quelle": "odin", "id": p["id"], "titel": p["titel"], "text": p["text"],
                                         "link": p["link"], "link_text": p["link_text"]}))
        treffer.sort(key=lambda x: -x[0])
        ergebnis = [t[1] for t in treffer[:3]]
        if self._wissen_fabrik and not lauf["browser"]:            # Wissen gibt es im Browser nicht
            ergebnis += self._wissen_hinweise([w for w in woerter if len(w) >= 4])
        return ergebnis

    def _wissen_hinweise(self, woerter: list) -> list:
        if not woerter:
            return []
        try:
            anleitungen = self._wissen_fabrik()._alle("anleitung")
        except Exception:                                           # noqa: BLE001 – Hinweise sind Zugabe
            return []
        treffer = []
        for a in anleitungen:
            titel = set(_woerter(a.get("titel", "")))
            rest = set(_woerter(f"{a.get('kategorie', '')} {a.get('system', '')} {a.get('text', '')}"))
            passt = lambda w, t: t.startswith(w) or (len(w) >= 5 and w in t)    # „liste“ passt auch zu „teileliste“
            im_titel = sum(1 for w in set(woerter) if any(passt(w, t) for t in titel))
            im_text = sum(1 for w in set(woerter) if any(passt(w, t) for t in rest))
            punkte = 2 * im_titel + im_text
            if punkte >= 3 and (im_titel or im_text >= 3):
                flach = " ".join(re.sub(r"[#*]", "", a.get("text", "")).split())
                treffer.append((punkte, {"quelle": "wissen", "id": a["id"], "titel": a["titel"],
                                         "text": flach[:220] + (" …" if len(flach) > 220 else ""),
                                         "link": f"#/wissen/anleitung/{a['id']}", "link_text": "Anleitung öffnen"}))
        treffer.sort(key=lambda x: -x[0])
        return [t[1] for t in treffer[:3]]

    def anlegen(self, eingabe, kontext=None) -> dict:
        """Jeder: ein Ticket anlegen. `kontext` aus der Oberfläche: route, plattform (nur im Browser), bildschirm."""
        lauf = self._lauf()
        e = eingabe if isinstance(eingabe, dict) else {}
        k = kontext if isinstance(kontext, dict) else {}
        titel = _text(e.get("titel"), LAENGEN["titel"])
        if len(titel) < 3:
            raise TicketFehler("Bitte einen kurzen Titel eingeben (mindestens 3 Zeichen).")
        felder = {f: _langtext(e.get(f), LAENGEN[f]) for f in ("beschreibung", "schritte", "erwartet")}
        _keine_zugangsdaten(titel, *felder.values())
        if e.get("art") not in ARTEN:
            raise TicketFehler("Bitte die Art wählen: Fehler, Idee, Frage oder Daten falsch.")
        bild = bild_pruefen(e["bild"]) if e.get("bild") else b""
        if lauf["browser"]:
            plattform = "Browser: " + (_text(k.get("plattform"), 120) or "unbekannt")
            protokoll = []                                            # das Protokoll gehört dem Rechner, nicht dem Gerät
        else:
            plattform = f"{sys.platform} · {platform.system()} {platform.release()}".strip()
            protokoll = protokoll_auszug(self._protokoll_pfad(), self._jetzt())
        t = {"version": 1, "id": _neue_id(), "art": e["art"], "titel": titel, **felder,
             "route": route_gelesen(e.get("route") or k.get("route")),
             "dringlichkeit": _wahl(e.get("dringlichkeit"), DRINGLICHKEIT, "normal"),
             "von": lauf["ich"], "am": self._zeit(), "bild": bool(bild),
             "kontext": {"version": self._version, "plattform": bereinigen(plattform)[:160],
                         "browser": lauf["browser"], "bildschirm": _text(k.get("bildschirm"), 20),
                         "protokoll": protokoll},
             "verlauf": []}
        if bild:
            pfad = self._pfad(t["id"], ".bild.jpg")
            os.makedirs(os.path.dirname(pfad), exist_ok=True)
            try:
                with open(pfad, "wb") as f:
                    f.write(bild)
            except OSError as fehler:
                raise TicketFehler(f"Das Bild ließ sich nicht speichern ({fehler}).") from None
        _schreibe(self._pfad(t["id"]), t)
        self._liesmich()
        return self._ansicht(lauf, ticket_form(t))

    def kommentieren(self, tid, text) -> dict:
        """Melder (eigenes Ticket) und Verwalter: einen Kommentar anhängen."""
        lauf = self._lauf()
        text = _langtext(text, LAENGEN["kommentar"])
        if not text:
            raise TicketFehler("Bitte etwas schreiben.")
        _keine_zugangsdaten(text)
        return self._aendern(lauf, tid, {"art": "kommentar", "text": text})

    def status_setzen(self, tid, status, kommentar="") -> dict:
        """Verwalter: jeden Status; Melder am eigenen Ticket: „erledigt“ (Problem ist weg) oder „neu“ (wieder offen)."""
        lauf = self._lauf()
        if status not in STATUS:
            raise TicketFehler("Unbekannter Status.")
        t = self._holen(lauf, tid)
        if not lauf["verwalter"] and not (t["von"] == lauf["ich"] and status in MELDER_STATUS):
            raise TicketFehler("Den Status setzen die Verwalter (die Urlaubs-Genehmiger) – am Rechner.")
        kommentar = _langtext(kommentar, LAENGEN["kommentar"])
        _keine_zugangsdaten(kommentar)
        return self._aendern(lauf, tid, {"art": "status", "status": status, "text": kommentar})

    def _aendern(self, lauf: dict, tid, eintrag: dict) -> dict:
        t = self._holen(lauf, tid)                                     # frisch gelesen, dann gleich geschrieben
        if len(t["verlauf"]) >= MAX_VERLAUF:
            raise TicketFehler("Dieses Ticket hat schon sehr viele Einträge – bitte ein neues anlegen.")
        t["verlauf"].append({"id": _neue_id(8), "von": lauf["ich"], "am": self._zeit(), **eintrag})
        _schreibe(self._pfad(t["id"]), t)
        return self._ansicht(lauf, t)

    # ---------------- Für Claude ----------------
    def fuer_claude(self, tid) -> str:
        """Verwalter: fertiger, bereinigter Auftragstext für Claude (Markdown) – ohne Namen, Adressen und Geheimnisse."""
        lauf = self._lauf()
        if not lauf["verwalter"]:
            raise TicketFehler("Den Auftragstext für Claude holen die Verwalter – am Rechner.")
        t = self._holen(lauf, tid)
        antworten = self._antworten(t["id"])
        status = status_bestimmen(t, antworten)[0]
        seite, dateien = seite_zu_route(t["route"])
        rolle = lambda pid: "Melder" if pid == t["von"] else "Verwalter"
        datum = lambda iso: f"{iso[8:10]}.{iso[5:7]}.{iso[:4]} {iso[11:16]}".strip()
        z = [f"# ODIN-Ticket {t['id'][:6].upper()}: {t['titel']}", "",
             "Bitte prüfe dieses Ticket aus ODIN (Caravan Muster, App im Repository-Ordner `tirge-helfer/`). Gib einen "
             "Hinweis, wie es sich beheben lässt – oder behebe es direkt, mit Test, und nenne die Version.", "",
             "## Ticket",
             f"- Kennung: `{t['id']}`",
             f"- Art: {ARTEN[t['art']]}",
             f"- Dringlichkeit: {DRINGLICHKEIT[t['dringlichkeit']]}",
             f"- Status: {STATUS[status]}",
             f"- Gemeldet: {datum(t['am'])}",
             f"- Betroffene Seite: {t['route'] or 'nicht angegeben'}" + (f" ({seite})" if seite else ""), "",
             "## Beschreibung", t["beschreibung"] or "(keine)", ""]
        if t["schritte"]:
            z += ["## So lässt es sich nachstellen", t["schritte"], ""]
        z += ["## Erwartetes Verhalten", t["erwartet"] or "(nicht angegeben)", ""]
        verlauf = [e for e in t["verlauf"] if e["text"] or e["art"] == "status"]
        if verlauf or antworten:
            z.append("## Verlauf")
            for e in verlauf:
                was = f"Status → {STATUS[e['status']]}" if e["art"] == "status" else "Kommentar"
                z.append(f"- {datum(e['am'])} · {rolle(e['von'])} · {was}" + (f": {e['text']}" if e["text"] else ""))
            for a in antworten:
                z.append(f"- {datum(a['am'])} · bisheriger Hinweis von Claude: {a['text'][:600]}")
            z.append("")
        k = t["kontext"]
        z += ["## Technischer Kontext",
              f"- ODIN-Version: {k['version'] or 'unbekannt'}",
              f"- Plattform: {k['plattform'] or 'unbekannt'}" + (f" · Bildschirm {k['bildschirm']}" if k["bildschirm"] else ""),
              f"- Gemeldet {'im Browser (Handy/Tablet)' if k['browser'] else 'am Rechner'}"]
        if t["bild"]:
            z.append(f"- Bildschirmfoto: `_ODIN/Tickets/{t['id']}.bild.jpg` im Ordner „Fahrzeuge“")
        if k["protokoll"]:
            z += ["- Letzte Fehler aus dem ODIN-Protokoll (bereinigt):", "", "```"]
            for eintrag in k["protokoll"]:
                z += [eintrag.replace("```", "'''"), ""]
            z += ["```"]
        z.append("")
        z += ["## Vermutlich betroffene Dateien"]
        z += [f"- `{d}`" for d in dateien + IMMER] if dateien else ["- (Seite unbekannt – bitte über die Beschreibung "
                                                                    "suchen; `tirge-helfer/app.py` verbindet "
                                                                    "Oberfläche und Logik)"]
        z += ["", "## Antwort zurück an ODIN",
              f"Lege die Antwort als JSON in den Ticketordner (`_ODIN/Tickets/{t['id']}.antwort.json` im Ordner "
              "„Fahrzeuge“), Format siehe README, Abschnitt „Tickets“ (und `LIESMICH-Claude.md` im Ordner):",
              "```json",
              '{"version": 1, "antworten": [{"am": "JJJJ-MM-TTThh:mm:ss", "status": "hinweis", '
              '"text": "Was zu tun ist …", "behoben_in": "", "links": []}]}',
              "```",
              "`status`: „hinweis“ (Hinweis gegeben), „arbeit“, „erledigt“ (mit `behoben_in`) oder „abgelehnt“. "
              "Nur Text, kein HTML; Links nur https://. Weitere Antworten hinten an die Liste anhängen."]
        return bereinigen("\n".join(z))

    def _liesmich(self):
        """Beim ersten Ticket eine kurze Anleitung für Claude in den Ordner legen (nie überschreiben)."""
        pfad = os.path.join(self._ordner(), "LIESMICH-Claude.md")
        if os.path.exists(pfad):
            return
        try:
            with open(pfad, "x", encoding="utf-8") as f:
                f.write(LIESMICH)
        except OSError:
            pass


LIESMICH = """# ODIN-Tickets – für Claude

In diesem Ordner legt ODIN die Tickets aus dem Team ab: je Ticket `<id>.json` (id = 10 Zeichen 0–9/a–f),
ein Bildschirmfoto als `<id>.bild.jpg`. Die Ticketdateien schreibt nur ODIN – bitte nicht ändern.

Antwort von Claude: `<id>.antwort.json` daneben legen (UTF-8, höchstens 256 KB):

```json
{"version": 1, "ticket": "<id>", "antworten": [
  {"am": "2026-11-25T14:30:00", "status": "hinweis", "text": "Was zu tun ist …",
   "behoben_in": "", "links": [{"url": "https://…", "titel": "…"}]}
]}
```

- `status`: hinweis | arbeit | erledigt | abgelehnt (Standard: hinweis). ODIN übernimmt ihn als Ticketstatus,
  bis danach jemand den Status von Hand ändert.
- `text`: reiner Text (höchstens 8000 Zeichen), kein HTML, keine Geheimnisse, keine Namen.
- `behoben_in`: ODIN-Version mit der Korrektur (nur bei „erledigt“).
- `links`: höchstens 5, nur https:// bzw. http://.
- Weitere Antworten hinten an die Liste anhängen, frühere stehen lassen.

Mehr im README des Repositorys, Abschnitt „Tickets“.
"""
