"""
Syscara-Schnittstelle (SYSCARA API v1.9, https://api.syscara.com): Fahrzeuge mit vollständiger Ausstattung.

Im Gegensatz zum Excel-Export sind die Ausstattungsnamen hier ungekürzt und haben ihren Preis. Daraus baut
ODIN Fließtext und mobile.de-Werbetext – nach denselben Regeln wie beim Preisschild:
- vorne die Basiszeile (Basisfahrzeug mit PS/kW, zul. Gesamtgewicht, Getriebe),
- Pakete nur mit ihrem Namen (der Inhalt in Klammern fällt weg; außer den Paketen aus „pakete_mit_inhalt“),
- Gebühren und Motor-/Fahrgestellzeilen (stehen schon in der Basiszeile) fallen weg,
- lange Positionen ohne Preis (Serien- oder Aktionstexte) fallen weg, kurze (Farbe, Wohnwelt) bleiben.
Der Zugang (Benutzername/Passwort) kommt von Syscara; ODIN fragt nur lesend ab.
"""

import base64
import json
import re
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request

from .fliesstext import (Ergebnis, baue_basiszeile, entferne_fahrgestell_dubletten, ist_gebuehr,
                         ist_inhalt_paket)

BASIS = "https://api.syscara.com"
ZEITLIMIT = 60


class SyscaraFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------- Abfragen ----------------

def _ssl_kontext():
    kontext = ssl.create_default_context()        # Windows: Zertifikate des Systems
    if sys.platform == "darwin" or getattr(sys, "frozen", False):
        try:                                      # Mac/fertiges Programm: ohne certifi kennt Python keine Zertifikate
            import certifi
            kontext.load_verify_locations(certifi.where())
        except (ImportError, OSError):
            pass
    return kontext


MAX_ANTWORT = 80 * 1024 * 1024


class _KeineWeiterleitung(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None                                     # die 3xx-Antwort kommt als HTTPError beim Aufrufer an


def hole(pfad: str, parameter: dict, benutzer: str, passwort: str, basis: str = None):
    """GET auf die Schnittstelle, Antwort als JSON. Fehler kommen als SyscaraFehler mit verständlichem Text."""
    abfrage = urllib.parse.urlencode({k: v for k, v in (parameter or {}).items() if v not in (None, "")})
    url = f"{(basis or BASIS).rstrip('/')}{pfad}" + (f"?{abfrage}" if abfrage else "")
    schluessel = base64.b64encode(f"{benutzer}:{passwort}".encode("utf-8")).decode()
    anfrage = urllib.request.Request(url, headers={"Authorization": f"Basic {schluessel}",
                                                   "Accept": "application/json", "User-Agent": "ODIN"})
    try:
        kontext = _ssl_kontext() if url.startswith("https:") else None
        # Keine Weiterleitungen: die Zugangsdaten gehen nur an die eingestellte Adresse, nie an eine andere
        oeffner = urllib.request.build_opener(_KeineWeiterleitung(),
                                              *([urllib.request.HTTPSHandler(context=kontext)] if kontext else []))
        with oeffner.open(anfrage, timeout=ZEITLIMIT) as antwort:
            roh = antwort.read(MAX_ANTWORT + 1)
        if len(roh) > MAX_ANTWORT:
            raise SyscaraFehler("Syscara hat ungewöhnlich viele Daten geschickt – die Abfrage wurde abgebrochen.")
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise SyscaraFehler("Syscara lehnt den Zugang ab – Benutzername oder Passwort stimmt nicht "
                                "(oder der Zugang darf diese Daten nicht lesen).") from e
        if 300 <= e.code < 400:
            raise SyscaraFehler("Syscara leitet auf eine andere Adresse um – die Zugangsdaten wurden nicht "
                                "weitergegeben. Bitte bei Syscara nachfragen.") from e
        if e.code == 429:
            raise SyscaraFehler("Zu viele Abfragen bei Syscara – bitte in ein paar Minuten noch einmal.") from e
        raise SyscaraFehler(f"Syscara antwortet mit Fehler {e.code} – bitte später noch einmal versuchen.") from e
    except ssl.SSLError as e:
        raise SyscaraFehler(f"Keine sichere Verbindung zu Syscara möglich ({e.reason or e}).") from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        grund = getattr(e, "reason", e)
        if isinstance(grund, ssl.SSLError):
            raise SyscaraFehler(f"Keine sichere Verbindung zu Syscara möglich ({grund.reason or grund}).") from e
        raise SyscaraFehler(f"Keine Verbindung zu Syscara – Internet prüfen ({grund}).") from e
    try:
        return json.loads(roh.decode("utf-8-sig") or "null")
    except (UnicodeDecodeError, ValueError) as e:
        raise SyscaraFehler("Syscara hat keine lesbaren Daten geschickt.") from e


def _liste(antwort) -> list:
    """Die Schnittstelle antwortet mit {"id": {...}, …}; zur Sicherheit auch eine Liste annehmen."""
    if isinstance(antwort, dict):
        werte = list(antwort.values())
        if werte and all(isinstance(w, dict) for w in werte):
            return werte
        return [antwort] if "identifier" in antwort else []
    if isinstance(antwort, list):
        return [w for w in antwort if isinstance(w, dict)]
    return []


def teste_zugang(benutzer: str, passwort: str, basis: str = None):
    """Kleinste mögliche Abfrage – wirft SyscaraFehler, wenn der Zugang nicht geht."""
    hole("/sale/vehicles/", {"internal_id": "ODIN-ZUGANGSTEST"}, benutzer, passwort, basis)


def ids_aus_text(text: str) -> list:
    """Interne IDs aus beliebigem Text (Komma, Zeilen, aus Excel kopiert): 'DRM00297, slkw00299' -> [...]"""
    gesehen, ids = set(), []
    for teil in re.split(r"[\s,;]+", (text or "").upper()):
        teil = teil.strip()
        if teil and teil not in gesehen:
            gesehen.add(teil)
            ids.append(teil)
    return ids


def hole_fahrzeuge(benutzer: str, passwort: str, interne_ids=(), seit: str = "", basis: str = None,
                   fortschritt=None) -> dict:
    """Fahrzeuge aus /sale/vehicles/: entweder die genannten Internen IDs (je eine Abfrage) oder alle, die seit
    'seit' (JJJJ-MM-TT) geändert wurden. Gibt {"fahrzeuge": [...], "nicht_gefunden": [...], "roh": {...}} zurück."""
    fahrzeuge, nicht_gefunden, roh = {}, [], {}
    ids = [x.strip().upper() for x in interne_ids if x.strip()]
    if ids:
        for i, iid in enumerate(ids):
            if fortschritt:
                fortschritt(i, len(ids), iid)
            antwort = hole("/sale/vehicles/", {"internal_id": iid}, benutzer, passwort, basis)
            roh[iid] = antwort
            # nur genau diese ID – ignoriert die Schnittstelle den Filter, kommt sonst der ganze Bestand
            treffer = [f for f in _liste(antwort) if _norm_id(_kennung(f)) == _norm_id(iid)]
            if not treffer:
                nicht_gefunden.append(iid)
            for f in treffer:
                fahrzeuge[str(f.get("id", _kennung(f)))] = f
    else:
        antwort = hole("/sale/vehicles/", {"update": seit}, benutzer, passwort, basis)
        roh["seit " + (seit or "immer")] = antwort
        for f in _liste(antwort):
            fahrzeuge[str(f.get("id", _kennung(f)))] = f
    return {"fahrzeuge": list(fahrzeuge.values()), "nicht_gefunden": nicht_gefunden, "roh": roh}


# ---------------- Fließtext aus den Daten ----------------

def _text(wert) -> str:
    return " ".join(str(wert or "").split())


def _norm_id(text: str) -> str:
    """'slkw00272 AF' -> 'SLKW00272' (wie in der Bestandsliste: angehängtes AF zählt nicht)."""
    return re.sub(r"(?<=\d)AF$", "", re.sub(r"\s+", "", (text or "").upper()))


def _kennung(fz: dict) -> str:
    return _text((fz.get("identifier") or {}).get("internal"))


def _zahl(wert) -> float:
    try:
        return float(str(wert).replace(",", ".")) if wert not in (None, "") else 0.0
    except ValueError:
        return 0.0


def _tausender(zahl: float) -> str:
    return f"{int(round(zahl)):,}".replace(",", ".")


def _euro(zahl: float) -> str:
    return f"{zahl:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") + " €"


def teile_name(name: str):
    """'All-In-Paket (ESP, ASR, Kraftstofftank 120 l)' -> ('All-In-Paket', ['ESP', 'ASR', 'Kraftstofftank 120 l']).
    Paketinhalt ist nur eine Klammer am Ende, die nach Aufzählung aussieht (lang, mehrere Teile oder ein Paket) –
    kurze Angaben wie 'Markise (4,5 m, manuell)' oder 'MultiJet 130 (2,3 l/130 PS)' bleiben am Namen."""
    name = _text(name)
    if not name.endswith(")"):
        return name, []
    tiefe = 0
    for i in range(len(name) - 1, -1, -1):
        tiefe += (name[i] == ")") - (name[i] == "(")
        if tiefe == 0:
            kern, inhalt = name[:i].rstrip(" ,;-"), name[i + 1:-1].strip()
            teile = len(re.findall(r",\s|;|\|", inhalt)) + 1          # „2,3 l“ ist keine Aufzählung
            if kern and (len(inhalt) > 30 or teile >= 3 or (teile >= 2 and "paket" in kern.lower())):
                from .werbetext import _bestandteile
                return kern, _bestandteile([inhalt])
            return name, []
    return name, []


def technische_daten(fz: dict) -> dict:
    """Für die Basiszeile wie beim Preisschild: basisfahrzeug, ps, kw, gesamtmasse, getriebe."""
    motor, gewicht = fz.get("engine") or {}, fz.get("weights") or {}
    marke = _text(motor.get("chassis"))
    basis = marke
    for e in fz.get("equipment") or []:             # „Fiat Ducato MultiJet 140 …“ nennt auch das Modell
        n = _text(e.get("name"))
        if marke and n.lower().startswith(marke.lower() + " ") and len(n.split()) >= 2:
            zweites = n.split()[1]
            if zweites[:1].isalpha() and zweites.lower() not in ("multijet", "ecoblue", "tdci", "light"):
                basis = f"{marke} {zweites}"
            break
    gang = _text(motor.get("gear")).lower()
    getriebe = ("Automatik" if "auto" in gang or gang in ("at", "dsg") else
                "Schaltgetriebe" if any(w in gang for w in ("manu", "schalt")) else _text(motor.get("gear")))
    gesamt = _zahl(gewicht.get("total"))
    ps, kw = _zahl(motor.get("ps")), _zahl(motor.get("kw"))
    return {"basisfahrzeug": basis, "ps": _tausender(ps) if ps else "", "kw": _tausender(kw) if kw else "",
            "gesamtmasse": _tausender(gesamt) if gesamt else "", "getriebe": getriebe}


def ergebnis_aus(fz: dict) -> Ergebnis:
    """Ein Fahrzeug aus der Schnittstelle -> Ergebnis wie aus einem Preisschild (für dieselbe Oberfläche)."""
    modell = fz.get("model") or {}
    erg = Ergebnis(datei=f"Syscara · {_kennung(fz) or fz.get('id', '')}", quelle="Syscara")
    erg.interne_id = _kennung(fz)
    erg.hersteller = _text(modell.get("producer"))
    erg.modell = _text(" ".join(_text(modell.get(k)) for k in ("series", "model", "model_add")))
    td = technische_daten(fz)

    namen, weggelassen, positionen, mit_preis = [], [], [], 0
    for e in fz.get("equipment") or []:
        voll = _text(e.get("name"))
        if not voll or ist_gebuehr(voll):
            continue
        preis = _zahl(e.get("price"))
        mit_preis += preis > 0
        kern, inhalt = teile_name(voll)
        if ist_inhalt_paket(kern) and inhalt:
            text = f"{kern}, {', '.join(inhalt)}"
        elif preis <= 0 and len(kern) > 70:
            weggelassen.append(voll)                 # lange Position ohne Preis: Serien- oder Aktionstext
            continue
        else:
            text = kern
        namen.append(text)
        positionen.append({"kopf": f"{kern} {_euro(preis)}" if preis > 0 else kern, "inhalt": inhalt})
    namen = entferne_fahrgestell_dubletten(list(dict.fromkeys(namen)), td)

    basis = baue_basiszeile(td)
    erg.fliesstext = ", ".join(t for t in [basis] + namen if t)
    erg.weggelassen = weggelassen
    if not erg.interne_id:
        erg.hinweise.append("Keine Interne ID in Syscara")
    motor_ps = {int(x) for e in fz.get("equipment") or [] for x in re.findall(r"(\d{2,3})\s*PS\b", _text(e.get("name")))}
    if td["ps"] and motor_ps and int(td["ps"].replace(".", "")) not in motor_ps:
        erg.hinweise.append(f"Motor in Syscara uneinheitlich: technische Daten {td['ps']} PS, Ausstattung "
                            f"{'/'.join(map(str, sorted(motor_ps)))} PS – bitte prüfen")
    if not basis:
        erg.hinweise.append("Basisfahrzeug/Motor in Syscara nicht gepflegt – bitte den Anfang des Textes prüfen")
    if not namen:
        erg.hinweise.append("Keine Ausstattung in Syscara")
    elif not mit_preis:
        erg.hinweise.append("Keine Preise an der Ausstattung in Syscara – bitte prüfen, ob Serienausstattung "
                            "mit drinsteht")

    from .werbetext import baue, modell_kurz, optionen_aus_positionen
    erg.werbe_optionen = optionen_aus_positionen(positionen, "", td)
    erg.modell_kurz = modell_kurz(erg.modell)
    erg.werbetext = baue(erg.werbe_optionen, erg.modell_kurz)["text"] if erg.modell_kurz else ""
    return erg
