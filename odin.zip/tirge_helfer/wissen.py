"""
Wissen & Einarbeitung: damit die Qualität nicht davon abhängt, wer gerade da ist.

Drei Teile:
- Abläufe (Standards): wiederkehrende Abläufe als Checklisten-Vorlage (Titel, Zweck, Bereich, verantwortliche Rolle,
  Schritte mit „woran erkenne ich, dass es stimmt“ und optionaler Pflicht-Notiz). Aus einer Vorlage startet man einen
  Durchlauf – die Schritte werden beim Start KOPIERT, spätere Änderungen an der Vorlage lassen laufende Durchläufe in
  Ruhe. Je Schritt wird gespeichert, wer ihn wann abgehakt hat.
- Anleitungen (Wissen): kurze Artikel je System mit einfacher Formatierung (Absätze, „- “, „1. “, **fett**, „## “,
  Bilder nur aus ui/wissen-bilder/ über einen festen Namen).
  Der Text wird hier in Bausteine zerlegt; die Oberfläche setzt daraus die Anzeige zusammen und maskiert jeden Text –
  HTML aus einem Artikel kommt nie als HTML an.
- Einarbeitung: Pläne je Rolle mit den Phasen Tag 1 / Erste Woche / Erster Monat / Nach 90 Tagen. Beim Start für eine
  Person werden die Termine aus dem Startdatum berechnet (0, 7, 30, 90 Tage; am Wochenende der Montag danach), die
  Gespräche nach 30 und 90 Tagen kommen als feste Schritte mit Leitfragen dazu. Je Schritt „gezeigt von“ und
  „kann es selbst“ getrennt.

Dazu „Hausregeln“ (verbindlich, mitgeliefert aus hausregeln.py – nur lesen) und „Offene Fragen“: was der
Fragen-Assistent nicht verstanden hat, bereinigt um mögliche Kundendaten (offene_fragen.py) – mit „erledigt“ und
„Anleitung anlegen“.

Dazu „Wer weiß was“: je System und Ablauf die Kenner – Themen mit nur einem Kenner oder ohne geprüften Inhalt sind
ein Risiko („hängt an einer Person“).

Gespeichert wird wie bei den Projekten im Ordner „Fahrzeuge“ unter _ODIN/Wissen/<Art>/<id>.json – je Eintrag eine
Datei, vor jeder Änderung frisch gelesen, geschrieben über eine Zwischendatei. Personen und „ich“ kommen aus den
Projekten. Alles Gelesene wird in eine Grundform gebracht: eine kaputte oder von Hand veränderte Datei kann die
Übersicht nicht aufhalten und keine fremden Felder einschleusen. IDs bestehen nur aus a–z und 0–9; aus der
Oberfläche kommt nie ein Pfad.

Keine Zugangsdaten im Wissen: Eingaben, die wie ein Passwortfeld aussehen („Passwort: …“), werden abgelehnt.
Sichtbar ist das Wissen für alle; bei einer Einarbeitung sehen die Notizen der Gespräche nur der Neue, der Pate und
wer sie angelegt hat. Wie bei den Projekten regelt das nur die Oberfläche: wer die Dateien öffnen kann, kann sie lesen.
"""

import datetime as dt
import hashlib
import json
import os
import re
import secrets

from . import beirat, hausregeln, offene_fragen
from . import wissen_inhalte as inhalte
from .projekte import ProjektFehler
from .wissen_hg import BILDER

BEREICHE = ["Verkauf", "Werkstatt", "Teile & Zubehör", "Garantie", "Büro", "Allgemein"]
SYSTEME_START = ["CaraCamp", "Syscara", "HG-Portal", "Bestandsliste", "ODIN", "Werkstatt", "Allgemein"]
# Phasen der Einarbeitung: (Schlüssel, Titel, fällig so viele Tage nach dem Start)
PHASEN = [("tag1", "Tag 1", 0), ("woche", "Erste Woche", 7), ("monat", "Erster Monat", 30), ("tage90", "Nach 90 Tagen", 90)]
PHASEN_TAGE = {k: tage for k, _, tage in PHASEN}
PHASEN_TITEL = {k: titel for k, titel, _ in PHASEN}
ORDNER = {"ablauf": "Ablaeufe", "durchlauf": "Durchlaeufe", "anleitung": "Anleitungen", "plan": "Plaene",
          "einarbeitung": "Einarbeitungen"}
ID_MUSTER = re.compile(r"[a-z0-9]{6,32}")
PERSON_MUSTER = re.compile(r"[a-z0-9]{4,40}")
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
# Als Link nur eine Webadresse oder eine Seite in ODIN – kein frei wählbares Schema (javascript:, file:, data: …)
LINK_MUSTER = re.compile(r"https?://[^\s<>\"'`\\]{3,480}|#/[A-Za-z0-9/_\-]{1,200}")
ZUGANGSDATEN = re.compile(r"\b(passwort|paßwort|kennwort|password|passwd|pwd|pw|pin|zugangscode|geheimzahl)\b"
                          r"\s*(?:[:=]|lautet)\s*(\S+)", re.IGNORECASE)
ZUGANG_HARMLOS = {"siehe", "steht", "stehen", "liegt", "im", "in", "beim", "bei", "über", "ueber", "frag", "fragen",
                  "wie", "nicht", "nie", "kein", "keine", "vergibt", "bekommst", "gibt", "–", "-", "→"}
MAX_SCHRITTE = 80
MAX_DATEIEN = 2000                # je Art – mehr liest die Übersicht nicht
MAX_BYTES = 2 * 1024 * 1024       # eine Datei, die größer ist, stammt nicht von ODIN
MAX_SYSTEME = 40
TEXT_MAX = 20000
SCHRITT_MAX = 300
NOTIZ_MAX = 2000
FETT = re.compile(r"\*\*(.+?)\*\*")
# Bild aus dem Programm: „![Beschreibung](wissen-bild:Datei.png)“ auf einer eigenen Zeile – nur Namen aus BILDER
BILD = re.compile(r"!\[([^\]\n]{0,300})\]\(wissen-bild:([A-Za-z0-9_-]{1,80}\.png)\)")
STEUERZEICHEN = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


class WissenFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- kleine Helfer

def _neue_id(laenge: int = 12) -> str:
    return secrets.token_hex(laenge // 2)


def start_id(art: str, titel: str) -> str:
    """Feste ID eines Startinhalts: zwei Rechner, die gleichzeitig zum ersten Mal starten, schreiben dieselben Dateien."""
    return hashlib.sha1(f"{art}:{titel}".encode("utf-8")).hexdigest()[:12]


def _roh(wert) -> str:
    """Nur Text und Zahlen werden Text – Listen, Objekte und Wahrheitswerte aus einer veränderten Datei nicht."""
    if isinstance(wert, bool) or not isinstance(wert, (str, int, float)):
        return ""
    return STEUERZEICHEN.sub("", str(wert))


def _text(wert, laenge: int) -> str:
    return " ".join(_roh(wert).split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    """Mehrzeilig erlaubt, nur Leerraum am Rand weg."""
    return _roh(wert).replace("\r\n", "\n").replace("\r", "\n").strip()[:laenge]


def _ja(wert) -> bool:
    if isinstance(wert, str):
        return wert.strip().lower() in ("true", "1", "ja", "on")
    return wert is True or (isinstance(wert, (int, float)) and not isinstance(wert, bool) and wert == 1)


def _gueltiges_datum(text) -> bool:
    if not isinstance(text, str) or not ISO_DATUM.fullmatch(text):
        return False
    try:
        dt.date.fromisoformat(text)
    except ValueError:
        return False
    return True


def _datum(wert, pflicht: bool = False):
    if wert in (None, ""):
        if pflicht:
            raise WissenFehler("Bitte ein Datum wählen.")
        return ""
    text = _roh(wert).strip()[:10]
    if not ISO_DATUM.fullmatch(text):
        raise WissenFehler("Bitte ein Datum wählen.")
    if not _gueltiges_datum(text):
        raise WissenFehler("Dieses Datum gibt es nicht.")
    return text


def _datum_gelesen(wert) -> str:
    text = _roh(wert)[:10]
    return text if _gueltiges_datum(text) else ""


def _zeit_gelesen(wert) -> str:
    text = _roh(wert)[:19]
    return text if _gueltiges_datum(text[:10]) else ""


def _deutsch(iso: str) -> str:
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if _gueltiges_datum(iso[:10]) else ""


def _id_gelesen(wert) -> str:
    return wert if isinstance(wert, str) and ID_MUSTER.fullmatch(wert) else ""


def _person_gelesen(wert) -> str:
    return wert if isinstance(wert, str) and PERSON_MUSTER.fullmatch(wert) else ""


def _liste(wert) -> list:
    return wert if isinstance(wert, list) else []


def _eingabe(wert) -> dict:
    return wert if isinstance(wert, dict) else {}


def link_pruefen(wert) -> str:
    """Link zu einer Aufzeichnung: nur http(s):// oder eine Seite in ODIN (#/…). Leer bleibt leer."""
    text = _roh(wert).strip()
    if not text:
        return ""
    if not LINK_MUSTER.fullmatch(text) or re.search(r"[\x00-\x20\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]", text):
        raise WissenFehler("Als Link geht nur eine Adresse, die mit https:// oder http:// beginnt (ohne Leerzeichen).")
    return text


def _link_gelesen(wert) -> str:
    text = _roh(wert).strip()
    ok = LINK_MUSTER.fullmatch(text) and not re.search(r"[\x00-\x20\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]", text)
    return text if ok else ""


def zugangsdaten_pruefen(*texte):
    """Lehnt Eingaben ab, die wie ein Passwortfeld aussehen („Passwort: abc123“) – Zugangsdaten gehören nicht ins Wissen."""
    for text in texte:
        for m in ZUGANGSDATEN.finditer(_roh(text)):
            if m.group(2).strip(".,;:!?()„“\"'").lower() not in ZUGANG_HARMLOS:
                raise WissenFehler(f"Das sieht nach Zugangsdaten aus („{m.group(1)}: …“). Passwörter gehören nicht ins "
                                   "Wissen – schreib nur, wo sie zu finden sind und wer sie vergibt.")


def _teile(zeile: str) -> list:
    """Eine Zeile in Stücke: [{"t": Text, "f": fett?}] – der Text bleibt, wie er ist (auch „<script>“)."""
    teile, pos = [], 0
    for m in FETT.finditer(zeile):
        if m.start() > pos:
            teile.append({"t": zeile[pos:m.start()], "f": False})
        teile.append({"t": m.group(1), "f": True})
        pos = m.end()
    if pos < len(zeile):
        teile.append({"t": zeile[pos:], "f": False})
    return teile


def bloecke(text) -> list:
    """Einfache Formatierung → Bausteine für die Anzeige. Kein HTML: die Oberfläche maskiert jedes Stück Text.
    „## Titel“ → titel, „- Punkt“ → liste, „1. Schritt“ → schritte, alles andere → absatz (Zeilen bleiben Zeilen).
    Beginnen Schritte nicht bei 1 (nach einer eingeschobenen Liste), steht die erste Nummer in „start“.
    „![Beschreibung](wissen-bild:Datei.png)“ → bild – aber nur, wenn die Datei in BILDER steht; sonst bleibt es Text."""
    ergebnis, aktuell = [], None
    for zeile in _langtext(text, TEXT_MAX).split("\n"):
        z = zeile.strip()
        if not z:
            aktuell = None
            continue
        m = re.fullmatch(r"#{1,3}\s+(.+)", z)
        if m:
            ergebnis.append({"art": "titel", "teile": _teile(m.group(1))})
            aktuell = None
            continue
        m = BILD.fullmatch(z)
        if m and m.group(2) in BILDER:
            ergebnis.append({"art": "bild", "datei": m.group(2), "text": m.group(1).strip()})
            aktuell = None
            continue
        art, inhalt, nummer = "absatz", z, 1
        m = re.fullmatch(r"[-*•]\s+(.+)", z)
        if m:
            art, inhalt = "liste", m.group(1)
        else:
            m = re.fullmatch(r"(\d{1,3})[.)]\s+(.+)", z)
            if m:
                art, inhalt, nummer = "schritte", m.group(2), int(m.group(1))
        if not aktuell or aktuell["art"] != art:
            aktuell = {"art": art, "zeilen" if art == "absatz" else "punkte": []}
            if art == "schritte" and nummer > 1:
                aktuell["start"] = nummer
            ergebnis.append(aktuell)
        aktuell["zeilen" if art == "absatz" else "punkte"].append(_teile(inhalt))
    return ergebnis


def _woerter(text) -> list:
    t = _roh(text).casefold()
    for alt, neu in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(alt, neu)
    return [w for w in re.split(r"[^0-9a-z]+", t) if w]


def _suchtext(text) -> str:
    return " ".join(_woerter(text))


def _faellig(start: dt.date, tage: int) -> str:
    """Start + Tage; fällt der Tag aufs Wochenende, gilt der Montag danach."""
    tag = start + dt.timedelta(days=tage)
    if tag.weekday() >= 5:
        tag += dt.timedelta(days=7 - tag.weekday())
    return tag.isoformat()


def _lies(pfad: str):
    """Gelesene Datei oder None (fehlt). Kaputt, gesperrt oder viel zu groß → WissenFehler."""
    try:
        if os.path.getsize(pfad) > MAX_BYTES:
            raise WissenFehler(f"„{os.path.basename(pfad)}“ ist zu groß – das ist keine Datei von ODIN.")
        with open(pfad, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except (OSError, ValueError, RecursionError) as e:
        raise WissenFehler(f"„{os.path.basename(pfad)}“ ist gerade nicht lesbar ({type(e).__name__}). "
                           "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise WissenFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


# ---------------------------------------------------------------- Grundformen (alles Gelesene geht hier durch)

def _pruefung(d: dict) -> dict:
    """„geprüft von … am …“ – nur vollständig gültig, sonst Entwurf."""
    von, am = _person_gelesen(d.get("geprueft_von")), _datum_gelesen(d.get("geprueft_am"))
    return {"geprueft_von": von if von and am else "", "geprueft_am": am if von and am else ""}


def _kopf(d: dict) -> dict:
    """Felder, die jede Art hat."""
    return {"id": d["id"], "startinhalt": d.get("startinhalt") is True,
            "erstellt_von": _person_gelesen(d.get("erstellt_von")), "erstellt_am": _zeit_gelesen(d.get("erstellt_am")),
            "geaendert_von": _person_gelesen(d.get("geaendert_von")), "geaendert_am": _zeit_gelesen(d.get("geaendert_am"))}


def _schritt_vorlage(s) -> dict:
    return {"id": s["id"], "text": _text(s.get("text"), SCHRITT_MAX), "hinweis": _text(s.get("hinweis"), 600),
            "notiz_pflicht": s.get("notiz_pflicht") is True}


def _mit_id(liste) -> list:
    """Nur Einträge mit gültiger, noch nicht vergebener ID."""
    gesehen, ergebnis = set(), []
    for x in _liste(liste)[:MAX_SCHRITTE]:
        if isinstance(x, dict) and _id_gelesen(x.get("id")) and x["id"] not in gesehen:
            gesehen.add(x["id"])
            ergebnis.append(x)
    return ergebnis


def _normal_ablauf(d: dict) -> dict:
    return {**_kopf(d), "titel": _text(d.get("titel"), 120) or "Ohne Titel", "zweck": _langtext(d.get("zweck"), 600),
            "bereich": _text(d.get("bereich"), 40), "rolle": _text(d.get("rolle"), 60),
            "kenner": _person_gelesen(d.get("kenner")), "kenner2": _person_gelesen(d.get("kenner2")),
            "schritte": [s for s in (_schritt_vorlage(x) for x in _mit_id(d.get("schritte"))) if s["text"]], **_pruefung(d)}


def _normal_durchlauf(d: dict) -> dict:
    schritte = []
    for x in _mit_id(d.get("schritte")):
        s = _schritt_vorlage(x)
        if not s["text"]:
            continue
        erledigt = x.get("erledigt") is True
        schritte.append({**s, "erledigt": erledigt, "notiz": _langtext(x.get("notiz"), NOTIZ_MAX),
                         "erledigt_von": _person_gelesen(x.get("erledigt_von")) if erledigt else "",
                         "erledigt_am": _zeit_gelesen(x.get("erledigt_am")) if erledigt else ""})
    return {**_kopf(d), "ablauf_id": _id_gelesen(d.get("ablauf_id")), "titel": _text(d.get("titel"), 120) or "Ohne Titel",
            "bereich": _text(d.get("bereich"), 40), "fahrzeug": _text(d.get("fahrzeug"), 40),
            "kunde": _text(d.get("kunde"), 80), "ziel": _datum_gelesen(d.get("ziel")),
            "zustaendig": _person_gelesen(d.get("zustaendig")), "schritte": schritte,
            "abgeschlossen_am": _zeit_gelesen(d.get("abgeschlossen_am")),
            "abgeschlossen_von": _person_gelesen(d.get("abgeschlossen_von"))}


def _normal_anleitung(d: dict) -> dict:
    return {**_kopf(d), "titel": _text(d.get("titel"), 120) or "Ohne Titel", "system": _text(d.get("system"), 40),
            "kategorie": _text(d.get("kategorie"), 60), "text": _langtext(d.get("text"), TEXT_MAX),
            "kenner": _person_gelesen(d.get("kenner")), "kenner2": _person_gelesen(d.get("kenner2")),
            "link": _link_gelesen(d.get("link")), **_pruefung(d)}


def _verweis_gelesen(v):
    """Verweis eines Planschritts: Ablauf, Anleitung oder ein Modul aus „Beirat & Coaching“ (nur bekannte Module)."""
    if isinstance(v, dict) and v.get("art") in ("anleitung", "ablauf") and _id_gelesen(v.get("id")):
        return {"art": v["art"], "id": v["id"]}
    if isinstance(v, dict) and v.get("art") == "beirat" and beirat.ist_modul(v.get("id")):
        return {"art": "beirat", "id": beirat.modul_id(v["id"])}             # umbenannte Module: neue Kennung
    return None


def _schritt_plan(x: dict) -> dict:
    return {"id": x["id"], "phase": x.get("phase") if x.get("phase") in PHASEN_TAGE else "tag1",
            "text": _text(x.get("text"), SCHRITT_MAX), "verweis": _verweis_gelesen(x.get("verweis"))}


def _normal_plan(d: dict) -> dict:
    return {**_kopf(d), "rolle": _text(d.get("rolle"), 60) or "Ohne Rolle",
            "schritte": [s for s in (_schritt_plan(x) for x in _mit_id(d.get("schritte"))) if s["text"]]}


def _normal_einarbeitung(d: dict) -> dict:
    schritte = []
    for x in _mit_id(d.get("schritte")):
        s = _schritt_plan(x)
        if not s["text"]:
            continue
        gezeigt = _person_gelesen(x.get("gezeigt_von"))
        schritte.append({**s, "faellig": _datum_gelesen(x.get("faellig")), "gespraech": x.get("gespraech") is True,
                         "leitfragen": [t for t in (_text(f, 300) for f in _liste(x.get("leitfragen"))[:12]) if t],
                         "gezeigt_von": gezeigt, "gezeigt_am": _zeit_gelesen(x.get("gezeigt_am")) if gezeigt else "",
                         "kann": x.get("kann") is True, "kann_am": _zeit_gelesen(x.get("kann_am")),
                         "gefuehrt": x.get("gefuehrt") is True, "gefuehrt_am": _zeit_gelesen(x.get("gefuehrt_am")),
                         "notiz": _langtext(x.get("notiz"), NOTIZ_MAX)})
    return {**_kopf(d), "person": _person_gelesen(d.get("person")), "pate": _person_gelesen(d.get("pate")),
            "rolle": _text(d.get("rolle"), 60) or "Ohne Rolle", "plan_id": _id_gelesen(d.get("plan_id")),
            "start": _datum_gelesen(d.get("start")), "schritte": schritte,
            "abgeschlossen_am": _zeit_gelesen(d.get("abgeschlossen_am"))}


NORMAL = {"ablauf": _normal_ablauf, "durchlauf": _normal_durchlauf, "anleitung": _normal_anleitung,
          "plan": _normal_plan, "einarbeitung": _normal_einarbeitung}
FEHLT = {"ablauf": "Diesen Ablauf gibt es nicht mehr.", "durchlauf": "Diesen Durchlauf gibt es nicht mehr.",
         "anleitung": "Diese Anleitung gibt es nicht mehr.", "plan": "Diesen Einarbeitungsplan gibt es nicht mehr.",
         "einarbeitung": "Diese Einarbeitung gibt es nicht mehr."}


def _normal(art: str, d):
    """Grundform eines gelesenen Eintrags; Unbrauchbares (halb synchronisiert, von Hand verändert) → None."""
    if not isinstance(d, dict) or not _id_gelesen(d.get("id")):
        return None
    try:
        return NORMAL[art](d)
    except (TypeError, ValueError, AttributeError, KeyError):
        return None


def _schritt_fertig(s: dict) -> bool:
    return s["gefuehrt"] if s["gespraech"] else s["kann"]


# ---------------------------------------------------------------- Wissen

class Wissen:
    """Abläufe, Anleitungen und Einarbeitung. Personen und „ich“ kommen aus `projekte`; `jetzt` (für Tests) liefert
    die Uhrzeit."""

    def __init__(self, projekte, jetzt=None):
        self._projekte = projekte
        self._jetzt = jetzt or dt.datetime.now

    # ---------------- Orte und Zeit ----------------
    def _wurzel(self) -> str:
        return os.path.join(self._projekte._basis()[0], "Wissen")

    def _pfad(self, art: str, eid) -> str:
        """Pfad eines Eintrags – Art aus der festen Liste, ID nur a–z und 0–9: nichts davon kann einen Ordner verlassen."""
        if not isinstance(art, str) or art not in ORDNER or not isinstance(eid, str) or not ID_MUSTER.fullmatch(eid):
            raise WissenFehler(FEHLT.get(art, "Unbekannter Eintrag.") if isinstance(art, str) else "Unbekannter Eintrag.")
        return os.path.join(self._wurzel(), ORDNER[art], f"{eid}.json")

    def _zeit(self) -> str:
        return self._jetzt().isoformat(timespec="seconds")

    def _heute(self) -> str:
        return self._jetzt().date().isoformat()

    # ---------------- Personen ----------------
    def _personen(self) -> dict:
        try:
            return {p["id"]: p for p in self._projekte.personen() if isinstance(p.get("id"), str)}
        except ProjektFehler as e:
            raise WissenFehler(str(e)) from None

    def _ich(self) -> str:
        try:
            return self._projekte.ich()
        except ProjektFehler as e:
            raise WissenFehler(str(e)) from None

    def _ich_pflicht(self) -> str:
        ich = self._ich()
        if not ich:
            raise WissenFehler("Bitte zuerst auswählen, wer du bist.")
        return ich

    def _person(self, wert, was: str, pflicht: bool = False) -> str:
        if wert in (None, ""):
            if pflicht:
                raise WissenFehler(f"Bitte wählen: {was}.")
            return ""
        if not isinstance(wert, str) or wert not in self._personen():
            raise WissenFehler(f"{was}: diese Person gibt es nicht.")
        return wert

    def _name(self, pid: str, personen: dict = None) -> str:
        p = (personen if personen is not None else self._personen()).get(pid)
        return _text(p.get("name"), 60) if p else ""

    # ---------------- Lesen und Schreiben ----------------
    def _alle(self, art: str) -> list:
        """Alle lesbaren Einträge einer Art. Eine kaputte, fremde oder gerade gesperrte Datei hält nichts auf."""
        ordner = os.path.join(self._wurzel(), ORDNER[art])
        try:
            namen = sorted(n for n in os.listdir(ordner) if n.endswith(".json"))[:MAX_DATEIEN]
        except OSError:
            return []
        gefunden = {}
        for n in namen:
            try:
                d = _normal(art, _lies(os.path.join(ordner, n)))
            except WissenFehler:
                continue
            if not d or not n.startswith(d["id"]):                # Dateiname und ID gehören zusammen
                continue
            # OneDrive-Konfliktkopie („<id>-PC.json“): dieselbe ID zweimal – die Datei mit dem richtigen Namen gilt
            if d["id"] in gefunden and n != f"{d['id']}.json":
                continue
            gefunden[d["id"]] = d
        return list(gefunden.values())

    def _lesen(self, art: str, eid) -> dict:
        d = _normal(art, _lies(self._pfad(art, eid)))
        if not d or d["id"] != eid:
            raise WissenFehler(FEHLT[art])
        return d

    def _speichern(self, art: str, d: dict, ich: str = "", neu: bool = False) -> dict:
        if neu:
            d["erstellt_von"], d["erstellt_am"] = ich, self._zeit()
        d["geaendert_von"], d["geaendert_am"] = ich, self._zeit()
        _schreibe(self._pfad(art, d["id"]), d)
        return d

    def _loeschen(self, art: str, eid) -> bool:
        pfad = self._pfad(art, eid)
        try:
            os.remove(pfad)
        except FileNotFoundError:
            pass
        except OSError as e:
            raise WissenFehler(f"Löschen hat nicht geklappt ({e}).") from None
        return True

    def _platz(self, art: str, was: str):
        if len(self._alle(art)) >= MAX_DATEIEN:
            raise WissenFehler(f"Höchstens {MAX_DATEIEN} {was}.")

    # ---------------- Systeme und Startinhalte ----------------
    def _stand_pfad(self) -> str:
        return os.path.join(self._wurzel(), "stand.json")

    def _stand(self):
        """{"systeme": [...], "lieferung": n} oder None, wenn es den Speicher noch nicht gibt."""
        try:
            roh = _lies(self._stand_pfad())
        except WissenFehler:                          # gerade nicht lesbar: nichts neu anlegen, nichts nachliefern,
            return {"version": 1, "systeme": list(SYSTEME_START), "lieferung": inhalte.LIEFERUNG}   # Standardliste
        if roh is None:
            return None
        systeme = []
        for s in _liste(roh.get("systeme") if isinstance(roh, dict) else None)[:MAX_SYSTEME]:
            name = _text(s, 40)
            if name and name.casefold() not in {x.casefold() for x in systeme}:
                systeme.append(name)
        lieferung = roh.get("lieferung") if isinstance(roh, dict) else None
        if not isinstance(lieferung, int) or isinstance(lieferung, bool) or not 1 <= lieferung <= 1000:
            lieferung = 1                             # ältere stand.json: hatte nur die ersten Startinhalte
        return {"version": 1, "systeme": systeme or list(SYSTEME_START), "lieferung": lieferung}

    def _startinhalte(self) -> dict:
        """Beim allerersten Mal die Startinhalte anlegen – nur wenn der Speicher noch leer ist. Danach nie wieder:
        was jemand löscht, bleibt gelöscht. Kommt mit einer neuen Fassung etwas dazu (inhalte.LIEFERUNG), wird nur
        das Neue einmal nachgeliefert – und nur, was es noch nicht gibt."""
        stand = self._stand()
        if stand is not None:
            if stand["lieferung"] < inhalte.LIEFERUNG:
                for eintrag in startinhalte():
                    art = eintrag.pop("_art")
                    neu_schritte = eintrag.pop("_lieferung_schritte", 1)
                    if eintrag.pop("_lieferung") > stand["lieferung"] and not os.path.exists(self._pfad(art, eintrag["id"])):
                        self._speichern(art, eintrag, neu=True)
                    elif art == "plan" and neu_schritte > stand["lieferung"]:
                        self._plan_nachliefern(eintrag)
                stand["lieferung"] = inhalte.LIEFERUNG
                _schreibe(self._stand_pfad(), stand)
            return stand
        stand = {"version": 1, "systeme": list(SYSTEME_START), "lieferung": inhalte.LIEFERUNG}
        if not any(self._alle(art) for art in ORDNER):
            for eintrag in startinhalte():
                eintrag.pop("_lieferung")
                eintrag.pop("_lieferung_schritte", None)
                self._speichern(eintrag.pop("_art"), eintrag, neu=True)
        _schreibe(self._stand_pfad(), stand)
        return stand

    def _plan_nachliefern(self, neu: dict):
        """Neue Schritte eines mitgelieferten Plans – nur, wenn der Plan noch genau so ist, wie er mitkam (niemand hat
        ihn bearbeitet). Die bisherigen Schritte bleiben mit ihren Kennungen (geänderte Texte und Verweise der
        mitgelieferten Fassung werden übernommen), die neuen kommen hinten dazu. Laufende Einarbeitungen ändern sich
        nicht (sie haben ihre Schritte beim Start kopiert)."""
        try:
            alt = self._lesen("plan", neu["id"])
        except WissenFehler:                          # gelöscht oder nicht lesbar: nichts anlegen, nichts anfassen
            return
        if not alt["startinhalt"] or alt["geaendert_von"]:
            return
        neu_je_id = {s["id"]: s for s in neu["schritte"]}
        geaendert = False
        for s in alt["schritte"]:
            n = neu_je_id.get(s["id"])
            if n and (s["text"], s["verweis"]) != (n["text"], n["verweis"]):
                s["text"], s["verweis"] = n["text"], n["verweis"]
                geaendert = True
        vorhanden = {s["id"] for s in alt["schritte"]}
        dazu = [s for s in neu["schritte"] if s["id"] not in vorhanden]
        if dazu or geaendert:
            alt["schritte"] = alt["schritte"] + dazu
            self._speichern("plan", alt)

    def _systeme(self) -> list:
        """Gepflegte Liste plus alles, was in Anleitungen schon benutzt wird."""
        systeme = list(self._startinhalte()["systeme"])
        for a in self._alle("anleitung"):
            if a["system"] and a["system"].casefold() not in {s.casefold() for s in systeme}:
                systeme.append(a["system"])
        return systeme

    def system_anlegen(self, name) -> list:
        self._ich_pflicht()
        name = _text(name, 40)
        if len(name) < 2:
            raise WissenFehler("Bitte einen Namen für das System eingeben.")
        stand = self._startinhalte()
        if name.casefold() in {s.casefold() for s in self._systeme()}:
            raise WissenFehler(f"„{name}“ gibt es schon.")
        if len(stand["systeme"]) >= MAX_SYSTEME:
            raise WissenFehler(f"Höchstens {MAX_SYSTEME} Systeme.")
        stand["systeme"].append(name)
        _schreibe(self._stand_pfad(), stand)
        return self._systeme()

    def system_loeschen(self, name) -> list:
        self._ich_pflicht()
        name = _text(name, 40)
        if any(a["system"].casefold() == name.casefold() for a in self._alle("anleitung")):
            raise WissenFehler(f"Zu „{name}“ gibt es noch Anleitungen – erst diese löschen oder umhängen.")
        stand = self._startinhalte()
        stand["systeme"] = [s for s in stand["systeme"] if s.casefold() != name.casefold()]
        _schreibe(self._stand_pfad(), stand)
        return self._systeme()

    # ---------------- Kurzformen für Listen ----------------
    @staticmethod
    def _ablauf_kurz(a: dict, offen: int = 0) -> dict:
        return {"id": a["id"], "titel": a["titel"], "zweck": a["zweck"], "bereich": a["bereich"], "rolle": a["rolle"],
                "schritte": len(a["schritte"]), "kenner": a["kenner"], "kenner2": a["kenner2"],
                "geprueft_von": a["geprueft_von"], "geprueft_am": a["geprueft_am"], "entwurf": not a["geprueft_von"],
                "startinhalt": a["startinhalt"], "geaendert_am": a["geaendert_am"], "offen": offen}

    def _durchlauf_kurz(self, d: dict) -> dict:
        fertig = sum(1 for s in d["schritte"] if s["erledigt"])
        zu = bool(d["abgeschlossen_am"])
        return {"id": d["id"], "ablauf_id": d["ablauf_id"], "titel": d["titel"], "bereich": d["bereich"],
                "fahrzeug": d["fahrzeug"], "kunde": d["kunde"], "ziel": d["ziel"], "zustaendig": d["zustaendig"],
                "gestartet_von": d["erstellt_von"], "gestartet_am": d["erstellt_am"], "fertig": fertig,
                "gesamt": len(d["schritte"]), "abgeschlossen": zu, "abgeschlossen_am": d["abgeschlossen_am"],
                "ueberfaellig": bool(d["ziel"]) and not zu and d["ziel"] < self._heute()}

    @staticmethod
    def _anleitung_kurz(a: dict) -> dict:
        return {"id": a["id"], "titel": a["titel"], "system": a["system"], "kategorie": a["kategorie"],
                "kenner": a["kenner"], "kenner2": a["kenner2"], "geprueft_von": a["geprueft_von"],
                "geprueft_am": a["geprueft_am"], "entwurf": not a["geprueft_von"], "startinhalt": a["startinhalt"],
                "stand": a["geaendert_am"][:10], "link": bool(a["link"])}

    def _fortschritt(self, e: dict) -> dict:
        heute = self._heute()
        offen = [s for s in e["schritte"] if not _schritt_fertig(s)]
        fertig = len(e["schritte"]) - len(offen)
        return {"gesamt": len(e["schritte"]), "fertig": fertig,
                "gezeigt": sum(1 for s in e["schritte"] if s["gezeigt_von"] and not s["gespraech"]),
                "prozent": round(100 * fertig / len(e["schritte"])) if e["schritte"] else 0,
                "ueberfaellig": 0 if e["abgeschlossen_am"] else sum(1 for s in offen if s["faellig"] and s["faellig"] < heute),
                "naechster": min((s["faellig"] for s in offen if s["faellig"]), default="")}

    def _einarbeitung_kurz(self, e: dict) -> dict:
        return {"id": e["id"], "person": e["person"], "pate": e["pate"], "rolle": e["rolle"], "start": e["start"],
                "abgeschlossen": bool(e["abgeschlossen_am"]), **self._fortschritt(e)}

    # ---------------- Einstieg ----------------
    def start(self) -> dict:
        """Alles für den Einstieg: wer ich bin, Personen, Systeme und die Listen (ohne die langen Texte)."""
        basis, lokal = self._projekte._basis()
        ich = self._ich()
        personen = [{"id": p["id"], "name": _text(p.get("name"), 60), "kuerzel": _text(p.get("kuerzel"), 3),
                     "farbe": _text(p.get("farbe"), 9)} for p in self._personen().values()]
        d = {"ich": ich, "personen": personen, "heute": self._heute(), "bereiche": BEREICHE,
             "beirat": beirat.module_kurz(), "hausregeln": hausregeln.alle(),
             "phasen": [{"id": k, "titel": t, "tage": tage} for k, t, tage in PHASEN],
             "speicher": {"lokal": lokal, "ordner": os.path.join(basis, "Wissen")},
             "systeme": [], "ablaeufe": [], "durchlaeufe": [], "anleitungen": [], "plaene": [], "einarbeitungen": []}
        if not ich:
            return d
        d["systeme"] = self._systeme()
        durchlaeufe = [self._durchlauf_kurz(x) for x in self._alle("durchlauf")]
        offen = {}
        for x in durchlaeufe:
            if not x["abgeschlossen"]:
                offen[x["ablauf_id"]] = offen.get(x["ablauf_id"], 0) + 1
        d["ablaeufe"] = sorted((self._ablauf_kurz(a, offen.get(a["id"], 0)) for a in self._alle("ablauf")),
                               key=lambda a: (a["bereich"].casefold(), a["titel"].casefold()))
        laufend = sorted((x for x in durchlaeufe if not x["abgeschlossen"]),
                         key=lambda x: (x["ziel"] or "9999", x["gestartet_am"]))
        fertig = sorted((x for x in durchlaeufe if x["abgeschlossen"]), key=lambda x: x["abgeschlossen_am"], reverse=True)
        d["durchlaeufe"] = laufend + fertig[:30]
        d["anleitungen"] = sorted((self._anleitung_kurz(a) for a in self._alle("anleitung")),
                                  key=lambda a: (a["system"].casefold(), a["titel"].casefold()))
        d["plaene"] = sorted(({"id": p["id"], "rolle": p["rolle"], "schritte": len(p["schritte"]),
                               "startinhalt": p["startinhalt"]} for p in self._alle("plan")),
                             key=lambda p: p["rolle"].casefold())
        d["einarbeitungen"] = sorted((self._einarbeitung_kurz(e) for e in self._alle("einarbeitung")),
                                     key=lambda e: (e["abgeschlossen"], e["start"]))
        return d

    # ---------------- Abläufe (Vorlagen) ----------------
    def ablauf(self, aid) -> dict:
        self._ich_pflicht()
        a = self._lesen("ablauf", aid)
        laeufe = [self._durchlauf_kurz(d) for d in self._alle("durchlauf") if d["ablauf_id"] == a["id"]]
        laeufe.sort(key=lambda x: (x["abgeschlossen"], x["gestartet_am"]))
        return {**a, "entwurf": not a["geprueft_von"], "durchlaeufe": laeufe}

    def ablauf_speichern(self, eingabe) -> dict:
        """Vorlage anlegen (ohne ID) oder ändern. Die Schritte kommen als ganze Liste in der gewünschten Reihenfolge:
        damit sind Hinzufügen, Umsortieren und Löschen ein Vorgang. Laufende Durchläufe bleiben, wie sie sind."""
        ich = self._ich_pflicht()
        e = _eingabe(eingabe)
        titel = _text(e.get("titel"), 120)
        if len(titel) < 3:
            raise WissenFehler("Bitte einen Titel für den Ablauf eingeben.")
        neu = not e.get("id")
        if neu:
            self._platz("ablauf", "Abläufe")
            a = {"id": _neue_id(), "startinhalt": False, "geprueft_von": "", "geprueft_am": ""}
        else:
            a = self._lesen("ablauf", e.get("id"))
        alt = {s["id"] for s in a.get("schritte", [])}
        schritte = []
        for x in _liste(e.get("schritte"))[:MAX_SCHRITTE]:
            x = _eingabe(x)
            text = _text(x.get("text"), SCHRITT_MAX)
            if not text:
                continue
            sid = x.get("id") if x.get("id") in alt and x.get("id") not in {s["id"] for s in schritte} else _neue_id(8)
            schritte.append({"id": sid, "text": text, "hinweis": _text(x.get("hinweis"), 600),
                             "notiz_pflicht": _ja(x.get("notiz_pflicht"))})
        if not schritte:
            raise WissenFehler("Ein Ablauf braucht mindestens einen Schritt.")
        a.update({"titel": titel, "zweck": _langtext(e.get("zweck"), 600), "bereich": _text(e.get("bereich"), 40),
                  "rolle": _text(e.get("rolle"), 60), "kenner": self._person(e.get("kenner"), "Kenner"),
                  "kenner2": self._person(e.get("kenner2"), "Zweiter Kenner"), "schritte": schritte})
        if a["kenner2"] and a["kenner2"] == a["kenner"]:
            a["kenner2"] = ""
        zugangsdaten_pruefen(a["titel"], a["zweck"], a["rolle"], *(s["text"] for s in schritte),
                             *(s["hinweis"] for s in schritte))
        self._speichern("ablauf", a, ich, neu)
        return self.ablauf(a["id"])

    def ablauf_loeschen(self, aid) -> bool:
        """Vorlage löschen – gestartete Durchläufe bleiben (sie haben ihre eigene Kopie der Schritte)."""
        self._ich_pflicht()
        return self._loeschen("ablauf", aid)

    def pruefen(self, art, eid, geprueft=True) -> dict:
        """„geprüft von mir, heute“ setzen oder zurück auf Entwurf – für Abläufe und Anleitungen."""
        ich = self._ich_pflicht()
        if art not in ("ablauf", "anleitung"):
            raise WissenFehler("Geprüft werden Abläufe und Anleitungen.")
        d = self._lesen(art, eid)
        d["geprueft_von"], d["geprueft_am"] = (ich, self._heute()) if _ja(geprueft) else ("", "")
        self._speichern(art, d, ich)
        return self.ablauf(eid) if art == "ablauf" else self.anleitung(eid)

    # ---------------- Durchläufe ----------------
    def _durchlauf_ansicht(self, d: dict) -> dict:
        return {**d, **self._durchlauf_kurz(d)}

    def durchlauf_starten(self, aid, eingabe=None) -> dict:
        """Durchlauf aus einer Vorlage: die Schritte werden kopiert – die Vorlage darf sich danach ändern."""
        ich = self._ich_pflicht()
        a = self._lesen("ablauf", aid)
        e = _eingabe(eingabe)
        self._platz("durchlauf", "Durchläufe")
        d = {"id": _neue_id(), "ablauf_id": a["id"], "titel": a["titel"], "bereich": a["bereich"],
             "fahrzeug": _text(e.get("fahrzeug"), 40), "kunde": _text(e.get("kunde"), 80), "ziel": _datum(e.get("ziel")),
             "zustaendig": self._person(e.get("zustaendig"), "Zuständig") or ich,
             "schritte": [{**s, "erledigt": False, "erledigt_von": "", "erledigt_am": "", "notiz": ""} for s in a["schritte"]],
             "abgeschlossen_am": "", "abgeschlossen_von": ""}
        zugangsdaten_pruefen(d["fahrzeug"], d["kunde"])
        self._speichern("durchlauf", d, ich, neu=True)
        return self.durchlauf(d["id"])

    def durchlauf(self, did) -> dict:
        self._ich_pflicht()
        return self._durchlauf_ansicht(self._lesen("durchlauf", did))

    def durchlauf_schritt(self, did, sid, eingabe) -> dict:
        """Schritt abhaken (wer und wann wird gespeichert), Haken zurücknehmen oder die Notiz ändern."""
        ich = self._ich_pflicht()
        d = self._lesen("durchlauf", did)
        if d["abgeschlossen_am"]:
            raise WissenFehler("Dieser Durchlauf ist abgeschlossen – zum Ändern erst wieder öffnen.")
        s = next((x for x in d["schritte"] if x["id"] == sid), None)
        if not s:
            raise WissenFehler("Diesen Schritt gibt es in dem Durchlauf nicht.")
        e = _eingabe(eingabe)
        if "notiz" in e:
            s["notiz"] = _langtext(e.get("notiz"), NOTIZ_MAX)
            zugangsdaten_pruefen(s["notiz"])
        if "erledigt" in e:
            if _ja(e.get("erledigt")):
                if s["notiz_pflicht"] and not s["notiz"]:
                    raise WissenFehler("Bei diesem Schritt ist eine Notiz Pflicht – bitte erst kurz festhalten, was war.")
                if not s["erledigt"]:
                    s["erledigt"], s["erledigt_von"], s["erledigt_am"] = True, ich, self._zeit()
            else:
                s["erledigt"], s["erledigt_von"], s["erledigt_am"] = False, "", ""
        self._speichern("durchlauf", d, ich)
        return self._durchlauf_ansicht(d)

    def durchlauf_abschliessen(self, did, abschliessen=True) -> dict:
        ich = self._ich_pflicht()
        d = self._lesen("durchlauf", did)
        if _ja(abschliessen):
            offen = sum(1 for s in d["schritte"] if not s["erledigt"])
            if offen:
                raise WissenFehler(f"Noch {offen} {'Schritt' if offen == 1 else 'Schritte'} offen – erst abhaken, "
                                   "dann abschließen.")
            d["abgeschlossen_am"], d["abgeschlossen_von"] = self._zeit(), ich
        else:
            d["abgeschlossen_am"], d["abgeschlossen_von"] = "", ""
        self._speichern("durchlauf", d, ich)
        return self._durchlauf_ansicht(d)

    def durchlauf_loeschen(self, did) -> bool:
        self._ich_pflicht()
        return self._loeschen("durchlauf", did)

    # ---------------- Anleitungen ----------------
    def anleitung(self, aid) -> dict:
        self._ich_pflicht()
        a = self._lesen("anleitung", aid)
        return {**a, "entwurf": not a["geprueft_von"], "bloecke": bloecke(a["text"]), "stand": a["geaendert_am"][:10],
                "geruest": inhalte.FEHLT in a["text"]}           # mitgeliefertes Gerüst, in das der Betrieb noch schreibt

    def anleitung_speichern(self, eingabe) -> dict:
        ich = self._ich_pflicht()
        e = _eingabe(eingabe)
        titel = _text(e.get("titel"), 120)
        if len(titel) < 3:
            raise WissenFehler("Bitte einen Titel für die Anleitung eingeben.")
        system = _text(e.get("system"), 40)
        bekannt = {s.casefold(): s for s in self._systeme()}
        if system.casefold() not in bekannt:
            raise WissenFehler("Bitte ein System aus der Liste wählen (oder zuerst ein neues anlegen).")
        neu = not e.get("id")
        if neu:
            self._platz("anleitung", "Anleitungen")
            a = {"id": _neue_id(), "startinhalt": False, "geprueft_von": "", "geprueft_am": ""}
        else:
            a = self._lesen("anleitung", e.get("id"))
        a.update({"titel": titel, "system": bekannt[system.casefold()], "kategorie": _text(e.get("kategorie"), 60),
                  "text": _langtext(e.get("text"), TEXT_MAX), "kenner": self._person(e.get("kenner"), "Kenner"),
                  "kenner2": self._person(e.get("kenner2"), "Zweiter Kenner"), "link": link_pruefen(e.get("link"))})
        if a["kenner2"] and a["kenner2"] == a["kenner"]:
            a["kenner2"] = ""
        zugangsdaten_pruefen(a["titel"], a["kategorie"], a["text"])
        self._speichern("anleitung", a, ich, neu)
        return self.anleitung(a["id"])

    def anleitung_loeschen(self, aid) -> bool:
        self._ich_pflicht()
        return self._loeschen("anleitung", aid)

    def suche(self, text="", system="") -> list:
        """Volltextsuche über Titel, Kategorie und Text der Anleitungen (alle Wörter müssen vorkommen, Umlaute egal);
        auf Wunsch nur ein System. Treffer im Titel zuerst, mit einem Ausschnitt aus dem Text."""
        self._ich_pflicht()
        woerter = _woerter(_text(text, 200))[:12]
        system = _text(system, 40).casefold()
        treffer = []
        for a in self._alle("anleitung"):
            if system and a["system"].casefold() != system:
                continue
            titel = _suchtext(a["titel"])
            alles = f"{titel} {_suchtext(a['kategorie'])} {_suchtext(a['system'])} {_suchtext(a['text'])}"
            if not all(w in alles for w in woerter):
                continue
            ausschnitt = ""
            flach = " ".join(re.sub(r"[#*]", "", a["text"]).split())
            if woerter:
                stelle = min((p for p in (_stelle(flach, w) for w in woerter) if p >= 0), default=-1)
                if stelle >= 0:
                    von = max(0, stelle - 50)
                    ausschnitt = ("… " if von else "") + flach[von:stelle + 110] + (" …" if stelle + 110 < len(flach) else "")
            treffer.append((0 if woerter and all(w in titel for w in woerter) else 1, a["titel"].casefold(),
                            {**self._anleitung_kurz(a), "ausschnitt": ausschnitt or flach[:140]}))
        return [t[2] for t in sorted(treffer, key=lambda t: t[:2])]

    # ---------------- Einarbeitung: Pläne ----------------
    def plan(self, pid) -> dict:
        self._ich_pflicht()
        return self._lesen("plan", pid)

    def plan_speichern(self, eingabe) -> dict:
        ich = self._ich_pflicht()
        e = _eingabe(eingabe)
        rolle = _text(e.get("rolle"), 60)
        if len(rolle) < 2:
            raise WissenFehler("Bitte die Rolle nennen, für die der Plan gilt (z. B. „Verkauf“).")
        neu = not e.get("id")
        if neu:
            self._platz("plan", "Einarbeitungspläne")
            p = {"id": _neue_id(), "startinhalt": False}
        else:
            p = self._lesen("plan", e.get("id"))
        if any(x["rolle"].casefold() == rolle.casefold() and x["id"] != p["id"] for x in self._alle("plan")):
            raise WissenFehler(f"Für „{rolle}“ gibt es schon einen Plan.")
        alt = {s["id"] for s in p.get("schritte", [])}
        schritte = []
        for x in _liste(e.get("schritte"))[:MAX_SCHRITTE]:
            x = _eingabe(x)
            text = _text(x.get("text"), SCHRITT_MAX)
            if not text:
                continue
            if x.get("phase") not in PHASEN_TAGE:
                raise WissenFehler("Unbekannte Phase – möglich sind Tag 1, Erste Woche, Erster Monat und Nach 90 Tagen.")
            sid = x.get("id") if x.get("id") in alt and x.get("id") not in {s["id"] for s in schritte} else _neue_id(8)
            schritte.append({"id": sid, "phase": x["phase"], "text": text, "verweis": _verweis_gelesen(x.get("verweis"))})
        if not schritte:
            raise WissenFehler("Ein Plan braucht mindestens einen Schritt.")
        reihenfolge = list(PHASEN_TAGE)
        schritte.sort(key=lambda s: reihenfolge.index(s["phase"]))            # stabil: Reihenfolge je Phase bleibt
        zugangsdaten_pruefen(rolle, *(s["text"] for s in schritte))
        p.update({"rolle": rolle, "schritte": schritte})
        return self._speichern("plan", p, ich, neu)

    def plan_loeschen(self, pid) -> bool:
        """Plan löschen – laufende Einarbeitungen bleiben (sie haben ihre eigene Kopie der Schritte)."""
        self._ich_pflicht()
        return self._loeschen("plan", pid)

    # ---------------- Einarbeitung: für eine Person ----------------
    @staticmethod
    def _beteiligt(e: dict, ich: str) -> bool:
        return bool(ich) and ich in (e["person"], e["pate"], e["erstellt_von"])

    def _einarbeitung_ansicht(self, e: dict, ich: str) -> dict:
        beteiligt = self._beteiligt(e, ich)
        schritte = []
        for s in e["schritte"]:
            s = {**s, "fertig": _schritt_fertig(s), "phase_titel": PHASEN_TITEL[s["phase"]]}
            if s["gespraech"] and not beteiligt:                  # Gesprächsnotizen nur für die Beteiligten
                s["notiz"], s["notiz_verborgen"] = "", True
            schritte.append(s)
        return {**e, "schritte": schritte, "beteiligt": beteiligt, "abgeschlossen": bool(e["abgeschlossen_am"]),
                **self._fortschritt(e)}

    def einarbeitung_starten(self, eingabe) -> dict:
        """Einarbeitung für eine Person: Schritte des Plans kopieren, Termine aus dem Startdatum berechnen, die
        Gespräche nach 30 und 90 Tagen als feste Schritte dazu."""
        ich = self._ich_pflicht()
        e = _eingabe(eingabe)
        person = self._person(e.get("person"), "Wer wird eingearbeitet", pflicht=True)
        pate = self._person(e.get("pate"), "Pate", pflicht=True)
        if pate == person:
            raise WissenFehler("Der Pate muss jemand anderes sein als die Person, die eingearbeitet wird.")
        start = dt.date.fromisoformat(_datum(e.get("start"), pflicht=True))
        plan = self._lesen("plan", e.get("plan_id"))
        if any(x["person"] == person and not x["abgeschlossen_am"] for x in self._alle("einarbeitung")):
            raise WissenFehler("Für diese Person läuft schon eine Einarbeitung.")
        self._platz("einarbeitung", "Einarbeitungen")
        leer = {"gezeigt_von": "", "gezeigt_am": "", "kann": False, "kann_am": "", "gefuehrt": False, "gefuehrt_am": "",
                "notiz": ""}
        schritte = [{"id": _neue_id(8), "phase": s["phase"], "text": s["text"], "verweis": s["verweis"],
                     "faellig": _faellig(start, PHASEN_TAGE[s["phase"]]), "gespraech": False, "leitfragen": [], **leer}
                    for s in plan["schritte"]]
        for tage, phase, titel, fragen in inhalte.GESPRAECHE:
            schritte.append({"id": _neue_id(8), "phase": phase, "text": titel, "verweis": None,
                             "faellig": _faellig(start, tage), "gespraech": True, "leitfragen": list(fragen), **leer})
        reihenfolge = list(PHASEN_TAGE)
        schritte.sort(key=lambda s: reihenfolge.index(s["phase"]))
        d = {"id": _neue_id(), "startinhalt": False, "person": person, "pate": pate, "rolle": plan["rolle"],
             "plan_id": plan["id"], "start": start.isoformat(), "schritte": schritte, "abgeschlossen_am": ""}
        self._speichern("einarbeitung", d, ich, neu=True)
        return self._einarbeitung_ansicht(d, ich)

    def einarbeitung(self, eid) -> dict:
        ich = self._ich_pflicht()
        return self._einarbeitung_ansicht(self._lesen("einarbeitung", eid), ich)

    def _einarbeitung_aendern(self, eid):
        ich = self._ich_pflicht()
        e = self._lesen("einarbeitung", eid)
        if not self._beteiligt(e, ich):
            raise WissenFehler("Ändern können das nur der Neue, der Pate und wer die Einarbeitung angelegt hat.")
        return ich, e

    def einarbeitung_schritt(self, eid, sid, eingabe) -> dict:
        """„gezeigt“ (von wem: wer den Haken setzt – setzt ihn der Neue selbst, zählt der Pate), „kann es selbst“,
        bei Gesprächen „geführt“ und die Notiz."""
        ich, e = self._einarbeitung_aendern(eid)
        if e["abgeschlossen_am"]:
            raise WissenFehler("Diese Einarbeitung ist abgeschlossen – zum Ändern erst wieder öffnen.")
        s = next((x for x in e["schritte"] if x["id"] == sid), None)
        if not s:
            raise WissenFehler("Diesen Schritt gibt es in der Einarbeitung nicht.")
        ein = _eingabe(eingabe)
        if "notiz" in ein:
            s["notiz"] = _langtext(ein.get("notiz"), NOTIZ_MAX)
            zugangsdaten_pruefen(s["notiz"])
        if s["gespraech"]:
            if "gefuehrt" in ein:
                s["gefuehrt"] = _ja(ein.get("gefuehrt"))
                s["gefuehrt_am"] = self._zeit() if s["gefuehrt"] else ""
        else:
            if "gezeigt" in ein:
                if _ja(ein.get("gezeigt")):
                    if not s["gezeigt_von"]:
                        s["gezeigt_von"], s["gezeigt_am"] = (ich if ich != e["person"] else e["pate"]) or ich, self._zeit()
                else:
                    s["gezeigt_von"], s["gezeigt_am"] = "", ""
            if "kann" in ein:
                s["kann"] = _ja(ein.get("kann"))
                s["kann_am"] = self._zeit() if s["kann"] else ""
        self._speichern("einarbeitung", e, ich)
        return self._einarbeitung_ansicht(e, ich)

    def einarbeitung_abschliessen(self, eid, abschliessen=True) -> dict:
        ich, e = self._einarbeitung_aendern(eid)
        e["abgeschlossen_am"] = self._zeit() if _ja(abschliessen) else ""
        self._speichern("einarbeitung", e, ich)
        return self._einarbeitung_ansicht(e, ich)

    def einarbeitung_loeschen(self, eid) -> bool:
        self._einarbeitung_aendern(eid)
        return self._loeschen("einarbeitung", eid)

    # ---------------- Heute & Woche ----------------
    def agenda(self) -> list:
        """Was für mich mit Datum ansteht: offene Schritte meiner Einarbeitung (als Neuer oder als Pate) – je Phase
        ein Punkt –, die Gespräche nach 30 und 90 Tagen und meine offenen Durchläufe mit Zieltermin."""
        ich = self._ich()
        if not ich:
            return []
        heute, personen, punkte = self._heute(), self._personen(), []
        for e in self._alle("einarbeitung"):
            if e["abgeschlossen_am"] or ich not in (e["person"], e["pate"]):
                continue
            neu = ich == e["person"]
            wer = "Deine Einarbeitung" if neu else f"Einarbeitung {self._name(e['person'], personen) or 'unbekannt'}"
            rolle = "" if neu else "du bist Pate"
            link = f"#/wissen/einarbeitung/{e['id']}"
            je_phase = {}
            for s in e["schritte"]:
                if _schritt_fertig(s) or not s["faellig"]:
                    continue
                if s["gespraech"]:
                    mit = self._name(e["pate"] if neu else e["person"], personen)
                    punkte.append({"datum": s["faellig"], "art": "einarbeitung", "link": link,
                                   "titel": s["text"] + (f" mit {mit}" if mit else ""),
                                   "text": " · ".join(t for t in (e["rolle"], rolle) if t),
                                   "ueberfaellig": s["faellig"] < heute})
                else:
                    je_phase.setdefault((s["faellig"], s["phase"]), []).append(s)
            for (faellig, phase), offen in je_phase.items():
                zeigen = sum(1 for s in offen if not s["gezeigt_von"])
                text = [f"{len(offen)} {'Schritt' if len(offen) == 1 else 'Schritte'} offen"]
                if zeigen:
                    text.append(f"{zeigen} noch nicht gezeigt")
                punkte.append({"datum": faellig, "art": "einarbeitung", "link": link,
                               "titel": f"{wer}: {PHASEN_TITEL[phase]}",
                               "text": " · ".join(t for t in (*text, e["rolle"], rolle) if t),
                               "ueberfaellig": faellig < heute})
        for d in self._alle("durchlauf"):
            if d["abgeschlossen_am"] or not d["ziel"] or ich not in (d["zustaendig"], d["erstellt_von"]):
                continue
            fertig = sum(1 for s in d["schritte"] if s["erledigt"])
            punkte.append({"datum": d["ziel"], "art": "ablauf", "link": f"#/wissen/durchlauf/{d['id']}",
                           "titel": d["titel"],
                           "text": " · ".join(t for t in (d["fahrzeug"], d["kunde"], f"{fertig} von {len(d['schritte'])} erledigt") if t),
                           "ueberfaellig": d["ziel"] < heute})
        return sorted(punkte, key=lambda p: p["datum"])

    # ---------------- Wer weiß was ----------------
    # ---------------- Offene Fragen aus dem Assistenten ----------------
    def _fragen_ordner(self) -> list:
        """Wo der Assistent nicht verstandene Fragen notiert: _ODIN im Ordner „Fahrzeuge“; ohne verbundenen Ordner
        der Einstellungsordner (dort schreibt cockpit/daten.py ohne _ODIN)."""
        basis, lokal = self._projekte._basis()
        return [basis, os.path.dirname(basis)] if lokal else [basis]

    def offene_fragen(self) -> dict:
        self._ich_pflicht()
        return offene_fragen.liste(self._fragen_ordner())

    def offene_frage_erledigt(self, schluessel, erledigt=True) -> dict:
        ich = self._ich_pflicht()
        try:
            offene_fragen.erledigen(self._fragen_ordner()[0], schluessel, ich, self._jetzt(), rueckgaengig=not erledigt)
        except ValueError as e:
            raise WissenFehler(str(e)) from None
        except OSError as e:
            raise WissenFehler(f"Speichern hat nicht geklappt ({e}).") from None
        return offene_fragen.liste(self._fragen_ordner())

    def wer_weiss_was(self) -> dict:
        """Je System und je Ablauf: wer kennt sich aus, gibt es einen Zweiten, ist etwas geprüft? Ein Thema mit nur
        einem Kenner oder ohne geprüften Inhalt ist ein Risiko – es hängt an einer Person."""
        self._ich_pflicht()
        personen = self._personen()
        themen = []

        def thema(art, name, kenner, geprueft, inhalt, eid=""):
            kenner = [k for k in dict.fromkeys(kenner) if k in personen]
            gruende = []
            if not kenner:
                gruende.append("kein Kenner eingetragen")
            elif len(kenner) == 1:
                gruende.append("nur ein Kenner – kein Zweiter")
            if not inhalt:
                gruende.append("noch keine Anleitung")
            elif not geprueft:
                gruende.append("nichts geprüft" if art == "system" else "noch nicht geprüft")
            themen.append({"art": art, "name": name, "id": eid, "kenner": kenner, "geprueft": geprueft,
                           "inhalt": inhalt, "risiko": bool(gruende), "gruende": gruende})

        anleitungen = self._alle("anleitung")
        for system in self._systeme():
            eigene = [a for a in anleitungen if a["system"].casefold() == system.casefold()]
            thema("system", system, [k for a in eigene for k in (a["kenner"], a["kenner2"]) if k],
                  sum(1 for a in eigene if a["geprueft_von"]), len(eigene))
        for a in sorted(self._alle("ablauf"), key=lambda a: a["titel"].casefold()):
            thema("ablauf", a["titel"], [k for k in (a["kenner"], a["kenner2"]) if k], 1 if a["geprueft_von"] else 0, 1,
                  a["id"])
        allein = {}
        for t in themen:
            if len(t["kenner"]) == 1:
                allein[t["kenner"][0]] = allein.get(t["kenner"][0], 0) + 1
        return {"themen": themen, "risiken": sum(1 for t in themen if t["risiko"]), "gesamt": len(themen),
                "allein": sorted(({"person": p, "themen": n} for p, n in allein.items()),
                                 key=lambda x: -x["themen"])}

    # ---------------- Für den Fragen-Assistenten ----------------
    def stichworte(self) -> list:
        """Abläufe und Anleitungen für die Stichwortsuche des Assistenten: Art, ID, Titel, Text, Entwurf?"""
        if not self._ich():
            return []
        liste = [{"art": "ablauf", "id": a["id"], "titel": a["titel"], "entwurf": not a["geprueft_von"],
                  "text": " ".join([a["zweck"], *(s["text"] for s in a["schritte"])])[:4000]}
                 for a in self._alle("ablauf")]
        liste += [{"art": "anleitung", "id": a["id"], "titel": a["titel"], "entwurf": not a["geprueft_von"],
                   "text": f"{a['system']} {a['kategorie']} {a['text']}"[:4000]} for a in self._alle("anleitung")]
        return liste

    # ---------------- Export ----------------
    def markdown(self, art, eid) -> dict:
        """Ablauf oder Anleitung als Markdown-Text – zum Ablegen in SharePoint (musterOS). {"dateiname", "text"}"""
        self._ich_pflicht()
        if art not in ("ablauf", "anleitung"):
            raise WissenFehler("Als Markdown gibt es Abläufe und Anleitungen.")
        d = self._lesen(art, eid)
        personen = self._personen()
        status = (f"Geprüft von {self._name(d['geprueft_von'], personen) or 'unbekannt'} am {_deutsch(d['geprueft_am'])}"
                  if d["geprueft_von"] else "Entwurf – noch nicht geprüft")
        kenner = ", ".join(n for n in (self._name(d["kenner"], personen), self._name(d["kenner2"], personen)) if n)
        zeilen = [f"# {d['titel']}", "", f"*{status}*", ""]
        if art == "ablauf":
            if d["zweck"]:
                zeilen += [f"**Zweck:** {d['zweck']}", ""]
            kopf = [f"**Bereich:** {d['bereich']}" if d["bereich"] else "",
                    f"**Verantwortliche Rolle:** {d['rolle']}" if d["rolle"] else "",
                    f"**Kenner:** {kenner}" if kenner else ""]
            zeilen += [" · ".join(k for k in kopf if k), "", "## Schritte", ""]
            for i, s in enumerate(d["schritte"], 1):
                zeilen.append(f"{i}. [ ] {s['text']}" + (" *(Notiz ist Pflicht)*" if s["notiz_pflicht"] else ""))
                if s["hinweis"]:
                    zeilen.append(f"   - Woran erkenne ich, dass es stimmt: {s['hinweis']}")
        else:
            kopf = [f"**System:** {d['system']}" if d["system"] else "",
                    f"**Kategorie:** {d['kategorie']}" if d["kategorie"] else "",
                    f"**Kenner:** {kenner}" if kenner else ""]
            zeilen += [" · ".join(k for k in kopf if k), "", d["text"]]
            if d["link"]:
                zeilen += ["", f"Aufzeichnung: {d['link']}"]
        zeilen += ["", f"Stand: {_deutsch(d['geaendert_am'][:10]) or _deutsch(self._heute())} · aus ODIN, Wissen & Einarbeitung", ""]
        name = re.sub(r"[^0-9A-Za-zÄÖÜäöüß \-]+", " ", d["titel"])
        name = "_".join(name.split())[:60] or "Wissen"
        return {"dateiname": f"{'Ablauf' if art == 'ablauf' else 'Anleitung'}_{name}.md", "text": "\n".join(zeilen)}


def _stelle(text: str, wort: str) -> int:
    """Wo steht das Suchwort (umlautfrei) im Text? Näherung über die Wörter des Originals."""
    for m in re.finditer(r"\S+", text):
        if wort in _suchtext(m.group(0)):
            return m.start()
    return -1


def _start_verweis(v):
    """Verweis eines mitgelieferten Planschritts: Ablauf/Anleitung über den Titel, Beirat-Modul über seine Kennung."""
    if not v:
        return None
    if v[0] == "beirat":
        return {"art": "beirat", "id": v[1]}
    return {"art": v[0], "id": start_id(v[0], v[1])}


def startinhalte() -> list:
    """Die mitgelieferten Entwürfe als fertige Einträge (mit „_art“ und „_lieferung“) – feste IDs, damit Verweise passen."""
    eintraege = []
    for a in inhalte.ABLAEUFE:
        eintraege.append({"_art": "ablauf", "_lieferung": a.get("lieferung", 1), "id": start_id("ablauf", a["titel"]), "startinhalt": True,
                          "titel": a["titel"], "zweck": a["zweck"], "bereich": a["bereich"], "rolle": a["rolle"],
                          "kenner": "", "kenner2": "", "geprueft_von": "", "geprueft_am": "",
                          "schritte": [{"id": start_id("schritt", f"{a['titel']}:{i}")[:8], "text": text,
                                        "hinweis": hinweis, "notiz_pflicht": pflicht}
                                       for i, (text, hinweis, pflicht) in enumerate(a["schritte"])]})
    for a in inhalte.ANLEITUNGEN:
        eintraege.append({"_art": "anleitung", "_lieferung": a.get("lieferung", 1), "id": start_id("anleitung", a["titel"]), "startinhalt": True,
                          "titel": a["titel"], "system": a["system"], "kategorie": a["kategorie"], "text": a["text"],
                          "kenner": "", "kenner2": "", "link": "", "geprueft_von": "", "geprueft_am": ""})
    for p in inhalte.PLAENE:
        eintraege.append({"_art": "plan", "_lieferung": p.get("lieferung", 1),
                          "_lieferung_schritte": p.get("lieferung_schritte", 1),
                          "id": start_id("plan", p["rolle"]), "startinhalt": True, "rolle": p["rolle"],
                          "schritte": [{"id": start_id("planschritt", f"{p['rolle']}:{i}")[:8], "phase": phase, "text": text,
                                        "verweis": _start_verweis(v)}
                                       for i, (phase, text, v) in enumerate(p["schritte"])]})
    return eintraege
