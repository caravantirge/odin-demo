"""
Besprechungen & Protokolle: Wochenrunde, Mitarbeitergespräche, Termine mit Kunden, Lieferanten oder der Bank – mit
Notizen je Abschnitt, Themenliste, Beschlüssen, Aufgaben und einer Bewertung 1–10 je Teilnehmer.

Die Wochenrunde folgt dem „Level 10“-Meeting aus EOS: 90 Minuten in fester Reihenfolge – Gute Nachrichten,
Scorecard, Quartalsziele, Kunden & Mitarbeiter, Aufgaben der Vorwoche (je 5 Minuten), Themen lösen nach
Erkennen – Besprechen – Lösen (60 Minuten), Abschluss & Bewertung (5 Minuten). Eine neue Wochenrunde übernimmt die
offenen Themen und die nicht erledigten Aufgaben der letzten Wochenrunde. Bis zu drei offene Themen lassen sich als
„Top 3“ markieren – sie stehen vorn. Zum Abschluss: „Was sagen wir unseren Leuten (in 24 Stunden)?“ und die Bewertung
1–10 je Teilnehmer (Ziel: mindestens 8; darunter die Frage „Was würde es zur 10 machen?“).

Beschlüsse haben immer einen Grund (warum so entschieden), auf Wunsch eine Wiedervorlage und einen Status („gilt“,
„beendet“, „geändert“). Jede Aufgabe hat genau einen Verantwortlichen und ist ohne Angabe in sieben Tagen fällig.

Protokolle aus der Protokoll-App (iPad/iPhone, JSON wie „aktuell.json“ in OneDrive unter Apps/Besprechungsprotokoll)
lassen sich übernehmen: je Punkt ein Thema, je Beschluss ein Beschluss, je Beschluss mit Verantwortlichem eine Aufgabe.
Die Protokoll-App selbst bleibt unberührt – ODIN liest die Datei nur.

Aufgaben aus einer Besprechung sind echte Aufgaben in einem Projekt – im gewählten oder im Sammelprojekt
„Aus Besprechungen“ (wird bei Bedarf angelegt, Mitglieder sind die Teilnehmer). Vertrauliche Besprechungen ohne
gewähltes Projekt bekommen ein eigenes Projekt nur für Teilnehmer und Ersteller – sonst stünde z. B. eine Aufgabe aus
einem Mitarbeitergespräch für alle sichtbar im gemeinsamen Sammelprojekt. So stehen die Aufgaben unter
„Meine Aufgaben“ und in „Heute & Woche“. Die Besprechung merkt sich nur, welche Aufgabe es ist; ob sie erledigt ist,
steht im Projekt.

Gespeichert wird wie bei den Projekten im Ordner „Fahrzeuge“ unter _ODIN/Besprechungen/<id>.json – je Besprechung eine
Datei, vor jeder Änderung frisch gelesen, geschrieben über eine Zwischendatei. Personen und „ich“ kommen aus den
Projekten. Eine Besprechung sehen alle – ist sie vertraulich, nur ihre Teilnehmer und wer sie angelegt hat. Wie bei
den Projekten regelt das nur die Oberfläche: wer die Dateien öffnen kann, kann sie lesen.
"""

import datetime as dt
import json
import os
import re
import secrets

from .projekte import ProjektFehler, quartal_von

ARTEN = {"wochenrunde": "Wochenrunde", "gespraech": "Mitarbeitergespräch", "kunde": "Kunde",
         "lieferant": "Lieferant", "bank": "Bank", "sonstiges": "Sonstiges"}
# Wochenrunde nach EOS „Level 10“: (Schlüssel, Titel, Minuten, kurze Anleitung)
WOCHENRUNDE = [
    ("gute_nachrichten", "Gute Nachrichten", 5, "Jeder eine gute Nachricht – privat und geschäftlich."),
    ("scorecard", "Scorecard", 5, "Die Wochenzahlen: auf Kurs oder nicht? Was nicht passt, wird ein Thema."),
    ("quartalsziele", "Quartalsziele", 5, "Jedes Ziel kurz: auf Kurs oder nicht auf Kurs? Was nicht auf Kurs ist, wird ein Thema."),
    ("kunden_mitarbeiter", "Kunden & Mitarbeiter", 5, "Kurze Meldungen zu Kunden und Mitarbeitern – Probleme werden ein Thema."),
    ("aufgaben", "Aufgaben der Vorwoche", 5, "Erledigt oder nicht? Ziel: 90 % erledigt. Was hängt, wird ein Thema."),
    ("themen", "Themen lösen", 60, "Erkennen – Besprechen – Lösen: die Top 3 zuerst; eine Lösung wird eine Aufgabe."),
    ("abschluss", "Abschluss & Bewertung", 5, "Neue Aufgaben wiederholen, festlegen, was wir unseren Leuten sagen, Bewertung 1–10."),
]
HILFE = {s: h for s, _, _, h in WOCHENRUNDE}
STANDARD_ABSCHNITTE = [("notizen", "Notizen", None)]           # alle anderen Arten
THEMA_STATUS = ("offen", "geloest")
TOP_MAX = 3                                                    # „Top 3“ unter den offenen Themen
BESCHLUSS_STATUS = ("gilt", "beendet", "geändert")
BEWERTUNG_ZIEL = 8
AUFGABE_TAGE = 7                                               # Fälligkeit ohne Angabe: heute + 7 Tage
SAMMELPROJEKT = "Aus Besprechungen"
MAX_EINTRAEGE = 300                                            # je Liste (Themen, Beschlüsse, Aufgaben)
NOTIZ_MAX = 20000
ID_MUSTER = re.compile(r"[0-9a-f]{6,32}")
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")


class BesprechungFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- kleine Helfer

def _neue_id(laenge: int = 12) -> str:
    """Zufällige ID: zwei Rechner, die gleichzeitig etwas anlegen, vergeben nie dieselbe."""
    return secrets.token_hex(laenge // 2)


def _text(wert, laenge: int) -> str:
    return " ".join(str(wert or "").split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    """Mehrzeilig erlaubt (Notizen), nur Leerraum am Rand weg."""
    return str(wert or "").replace("\r\n", "\n").strip()[:laenge]


def _gueltiges_datum(text) -> bool:
    if not isinstance(text, str) or not ISO_DATUM.fullmatch(text):
        return False
    try:
        dt.date.fromisoformat(text)
    except ValueError:
        return False
    return True


def _datum(wert, pflicht: bool = False):
    if wert in (None, ""):
        if pflicht:
            raise BesprechungFehler("Bitte ein Datum wählen.")
        return None
    text = str(wert).strip()[:10]
    if not ISO_DATUM.fullmatch(text):
        raise BesprechungFehler("Bitte ein Datum wählen.")
    if not _gueltiges_datum(text):
        raise BesprechungFehler("Dieses Datum gibt es nicht.")
    return text


def _deutsch(iso: str) -> str:
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if _gueltiges_datum(iso) else ""


def _minuten(wert):
    if wert in (None, ""):
        return None
    try:
        zahl = int(wert)
    except (TypeError, ValueError):
        raise BesprechungFehler("Minuten bitte als ganze Zahl angeben.") from None
    if not 0 <= zahl <= 600:
        raise BesprechungFehler("Minuten bitte zwischen 0 und 600.")
    return zahl


def _note(wert):
    """Bewertung 1–10 (auch „8“ aus der Oberfläche); leer → None (Bewertung entfernen)."""
    if wert in (None, ""):
        return None
    try:
        zahl = float(str(wert).replace(",", ".")) if not isinstance(wert, bool) else None
    except ValueError:
        zahl = None
    if zahl is None or not zahl.is_integer() or not 1 <= zahl <= 10:
        raise BesprechungFehler("Bitte eine Bewertung von 1 bis 10.")
    return int(zahl)


def _schnitt(bewertungen: dict):
    noten = [n for n in (bewertungen or {}).values() if isinstance(n, int) and 1 <= n <= 10]
    return round(sum(noten) / len(noten), 1) if noten else None


def _ja(wert) -> bool:
    if isinstance(wert, str):
        return wert.strip().lower() in ("true", "1", "ja", "erledigt")
    return bool(wert)


def _eintrag(liste: list, eid: str, meldung: str) -> dict:
    x = next((e for e in liste if e.get("id") == eid), None)
    if not x:
        raise BesprechungFehler(meldung)
    return x


def _platz(liste: list, was: str):
    if len(liste) >= MAX_EINTRAEGE:
        raise BesprechungFehler(f"Höchstens {MAX_EINTRAEGE} {was} je Besprechung.")


def _top_setzen(b: dict, t: dict):
    """Thema als „Top 3“ markieren – höchstens drei offene gleichzeitig."""
    if t.get("status") == "geloest":
        raise BesprechungFehler("Ein gelöstes Thema braucht keinen Platz unter den Top 3.")
    andere = [x for x in b["themen"] if x is not t and x.get("top") and x.get("status") != "geloest"]
    if len(andere) >= TOP_MAX:
        raise BesprechungFehler("Schon drei Themen sind Top 3 – erst eines lösen oder abwählen.")
    t["top"] = True


def _lies(pfad: str):
    from .speicher import lies_json
    try:
        return lies_json(pfad)
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as e:
        raise BesprechungFehler(f"„{os.path.basename(pfad)}“ ist gerade nicht lesbar ({e}). "
                                "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise BesprechungFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


PROTOKOLL_MAX_BYTES = 20 * 1024 * 1024
DEUTSCHES_DATUM = re.compile(r"(\d{1,2})\.(\d{1,2})\.(\d{2}|\d{4})")


def _protokoll_lesen(quelle) -> dict:
    """Protokoll der Protokoll-App (iPad/iPhone): Pfad zur JSON-Datei (z. B. aktuell.json) oder schon gelesene Daten."""
    if isinstance(quelle, dict):
        roh = quelle
    else:
        pfad = str(quelle or "")
        if not pfad.lower().endswith(".json"):
            raise BesprechungFehler("Bitte eine JSON-Datei aus der Protokoll-App wählen (z. B. „aktuell.json“).")
        try:
            if os.path.getsize(pfad) > PROTOKOLL_MAX_BYTES:
                raise BesprechungFehler("Die Datei ist für ein Protokoll zu groß.")
            with open(pfad, encoding="utf-8-sig") as f:
                roh = json.load(f)
        except FileNotFoundError:
            raise BesprechungFehler("Die Datei gibt es nicht (mehr).") from None
        except (OSError, ValueError) as e:
            raise BesprechungFehler(f"Die Datei ist nicht lesbar ({e}).") from None
    if not isinstance(roh, dict) or not isinstance(roh.get("punkte"), list):
        raise BesprechungFehler("Das ist kein Protokoll der Protokoll-App – die Liste der Punkte fehlt.")
    return roh


def _feld(d: dict, schluessel: str) -> str:
    """Textfeld aus der Protokoll-App – fehlt es oder ist es kein Text, dann leer."""
    wert = d.get(schluessel)
    if isinstance(wert, bool) or not isinstance(wert, (str, int, float)):
        return ""
    return str(wert).replace("\r\n", "\n").strip()


def _protokoll_datum(wert):
    """„2027-01-12“ oder „12.01.2027“ / „12.1.27“ → ISO; sonst None."""
    text = str(wert or "").strip() if isinstance(wert, str) else ""
    if _gueltiges_datum(text[:10]):
        return text[:10]
    m = DEUTSCHES_DATUM.fullmatch(text)
    if m:
        jahr = int(m.group(3))
        try:
            return dt.date(jahr + 2000 if jahr < 100 else jahr, int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            return None
    return None


def _woerter(text) -> list:
    t = str(text or "").casefold()
    for alt, neu in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(alt, neu)
    return [w for w in re.split(r"[^0-9a-z]+", t) if w]


def _person_zu_name(name: str, personen: list):
    """„Carla Probe“, „C. Probe“, „Probe“ oder „Carla“ → Personen-ID, wenn genau eine Person passt."""
    teile = _woerter(name)
    if not teile:
        return None
    voll = [p["id"] for p in personen if _woerter(p.get("name")) == teile]
    if len(voll) == 1:
        return voll[0]
    treffer = []
    for p in personen:
        woerter = _woerter(p.get("name"))
        if all((t in woerter) if len(t) > 1 else any(w.startswith(t) for w in woerter) for t in teile):
            treffer.append(p["id"])
    return treffer[0] if len(treffer) == 1 else None


def _mehrere(text: str) -> bool:
    """„Anna und Ben“, „Team Werkstatt“, „alle“: keine einzelne verantwortliche Person."""
    return bool(re.search(r"[,;/+&]|\bund\b|\bteam\b|\balle\b", text or "", re.IGNORECASE))


def _normal(b):
    """Grundform einer gelesenen Besprechung: fehlende Listen ergänzt. Unbrauchbares (halb synchronisiert) → None."""
    if not isinstance(b, dict) or not ID_MUSTER.fullmatch(str(b.get("id") or "")):
        return None
    if b.get("art") not in ARTEN:
        b["art"] = "sonstiges"
    for k in ("teilnehmer", "abschnitte", "themen", "beschluesse", "aufgaben"):
        if not isinstance(b.get(k), list):
            b[k] = []
    b["teilnehmer"] = [t for t in b["teilnehmer"] if isinstance(t, str)]
    for k in ("abschnitte", "themen", "beschluesse", "aufgaben"):
        b[k] = [x for x in b[k] if isinstance(x, dict) and x.get("id")]
    if not isinstance(b.get("bewertungen"), dict):
        b["bewertungen"] = {}
    b["vertraulich"] = bool(b.get("vertraulich"))
    b["titel"] = str(b.get("titel") or "Besprechung")
    b["erstellt_am"] = str(b.get("erstellt_am") or "")
    if not _gueltiges_datum(b.get("datum")):
        b["datum"] = b["erstellt_am"][:10] if _gueltiges_datum(b["erstellt_am"][:10]) else ""
    return b


# ---------------------------------------------------------------- Besprechungen

class Besprechungen:
    """Besprechungen und Protokolle. Personen, „ich“ und Aufgaben kommen aus `projekte`; `jetzt` (für Tests) liefert
    die Uhrzeit."""

    def __init__(self, projekte, jetzt=None):
        self._projekte = projekte
        self._jetzt = jetzt or dt.datetime.now

    # ---------------- Orte und Zeit ----------------
    def _ordner(self) -> str:
        return os.path.join(self._projekte._basis()[0], "Besprechungen")

    def _pfad(self, bid: str) -> str:
        if not ID_MUSTER.fullmatch(str(bid or "")):
            raise BesprechungFehler("Unbekannte Besprechung.")
        return os.path.join(self._ordner(), f"{bid}.json")

    def _zeit(self) -> str:
        return self._jetzt().isoformat(timespec="seconds")

    def _heute(self) -> str:
        return self._jetzt().date().isoformat()

    # ---------------- Personen und Rechte ----------------
    @staticmethod
    def _p(funktion, *argumente):
        """Aufruf in die Projekte – deren Meldungen kommen als BesprechungFehler an."""
        try:
            return funktion(*argumente)
        except ProjektFehler as e:
            raise BesprechungFehler(str(e)) from None

    def _personen(self) -> dict:
        return {p["id"]: p for p in self._p(self._projekte.personen)}

    def _ich(self) -> str:
        return self._p(self._projekte.ich)

    def _ich_pflicht(self) -> str:
        ich = self._ich()
        if not ich:
            raise BesprechungFehler("Bitte zuerst auswählen, wer du bist.")
        return ich

    @staticmethod
    def _darf_sehen(b: dict, ich: str) -> bool:
        if not ich:
            return False
        if not b.get("vertraulich"):
            return True
        return ich == b.get("erstellt_von") or ich in (b.get("teilnehmer") or [])

    # ---------------- Lesen ----------------
    def _alle(self) -> list:
        """Alle lesbaren Besprechungen. Eine kaputte oder gerade gesperrte Datei hält die Übersicht nicht auf."""
        ordner = self._ordner()
        try:
            namen = sorted(n for n in os.listdir(ordner) if n.endswith(".json"))
        except OSError:
            return []
        gefunden = {}
        for n in namen:
            try:
                b = _normal(_lies(os.path.join(ordner, n)))
            except BesprechungFehler:
                continue
            if not b:
                continue
            # OneDrive-Konfliktkopie („<id>-PC.json“): dieselbe ID zweimal – die Datei mit dem richtigen Namen gilt
            if b["id"] in gefunden and n != f"{b['id']}.json":
                continue
            gefunden[b["id"]] = b
        return list(gefunden.values())

    def _lesen(self, bid: str, ich: str) -> dict:
        b = _normal(_lies(self._pfad(bid)))
        if not b:
            raise BesprechungFehler("Diese Besprechung gibt es nicht mehr – vielleicht auf einem anderen Rechner gelöscht.")
        if not self._darf_sehen(b, ich):
            raise BesprechungFehler("Diese Besprechung ist vertraulich – sie sehen nur Teilnehmer und wer sie angelegt hat.")
        return b

    @staticmethod
    def _zusammenfassung(b: dict) -> dict:
        return {"id": b["id"], "art": b["art"], "art_name": ARTEN[b["art"]], "titel": b["titel"], "datum": b["datum"],
                "teilnehmer": b["teilnehmer"], "vertraulich": b["vertraulich"], "erstellt_von": b.get("erstellt_von"),
                "erstellt_am": b["erstellt_am"], "geaendert_am": b.get("geaendert_am") or b["erstellt_am"],
                "themen": len(b["themen"]), "themen_offen": sum(1 for t in b["themen"] if t.get("status") != "geloest"),
                "beschluesse": len(b["beschluesse"]), "aufgaben": len(b["aufgaben"]), "bewertung": _schnitt(b["bewertungen"])}

    def start(self) -> dict:
        """Alles für den Einstieg: wer ich bin, Personen, Arten, Vorlage, meine Projekte, sichtbare Besprechungen."""
        basis, lokal = self._projekte._basis()
        ich = self._ich()
        projekte = []
        if ich:
            projekte = [{"id": p["id"], "name": p["name"], "farbe": p["farbe"], "mitglieder": p["mitglieder"]}
                        for p in self._p(self._projekte.start)["projekte"] if not p["archiviert"]]
        return {"ich": ich, "personen": list(self._personen().values()),
                "arten": [{"id": k, "name": v} for k, v in ARTEN.items()],
                "vorlage": [{"schluessel": s, "titel": t, "minuten": m, "hilfe": h} for s, t, m, h in WOCHENRUNDE],
                "besprechungen": self.liste() if ich else [], "projekte": projekte, "sammelprojekt": SAMMELPROJEKT,
                "heute": self._heute(), "quartal": quartal_von(self._jetzt().date()),
                "speicher": {"lokal": lokal, "ordner": os.path.join(basis, "Besprechungen")}}

    def liste(self, art: str = None) -> list:
        """Sichtbare Besprechungen (ohne Inhalt), neueste zuerst; auf Wunsch nur eine Art."""
        if art and art not in ARTEN:
            raise BesprechungFehler("Unbekannte Art der Besprechung.")
        ich = self._ich()
        liste = [self._zusammenfassung(b) for b in self._alle()
                 if self._darf_sehen(b, ich) and (not art or b["art"] == art)]
        liste.sort(key=lambda b: (b["datum"], b["erstellt_am"]), reverse=True)
        return liste

    def besprechung(self, bid: str) -> dict:
        ich = self._ich_pflicht()
        return self._ansicht(self._lesen(bid, ich), ich)

    def _vorwoche(self, b: dict, ich: str):
        if b["art"] != "wochenrunde" or not b.get("vorherige"):
            return None
        try:
            return self._lesen(b["vorherige"], ich)
        except BesprechungFehler:                     # gelöscht oder vertraulich: dann eben ohne Vorwoche
            return None

    def _ansicht(self, b: dict, ich: str) -> dict:
        """Die Besprechung für die Oberfläche: Aufgaben mit ihrem Stand im Projekt, Durchschnitt, Rechte –
        bei der Wochenrunde dazu die Quartalsziele und die Aufgaben der Vorwoche."""
        vorwoche = self._vorwoche(b, ich)
        alle = b["aufgaben"] + (vorwoche["aufgaben"] if vorwoche else [])
        stand = self._p(self._projekte.aufgaben_stand, [(a.get("projekt_id"), a.get("aufgabe_id")) for a in alle])

        def mit_stand(a):
            s = stand.get(a.get("aufgabe_id"))
            return {**a, "stand": s, "erledigt": bool(s and s["erledigt"]), "geloescht": s is None}

        ansicht = {**b, "art_name": ARTEN[b["art"]],
                   "abschnitte": [{**x, "hilfe": HILFE.get(x.get("schluessel"), "")} for x in b["abschnitte"]],
                   "themen": sorted(b["themen"], key=lambda t: (t.get("status") == "geloest", not t.get("top"))),
                   "aufgaben": [mit_stand(a) for a in b["aufgaben"]], "bewertung": _schnitt(b["bewertungen"]),
                   "bewertung_ziel": BEWERTUNG_ZIEL, "mitteilung": b.get("mitteilung", ""), "zur_zehn": b.get("zur_zehn", ""),
                   "minuten": sum(x.get("minuten") or 0 for x in b["abschnitte"]),
                   "darf_loeschen": ich == b.get("erstellt_von"), "darf_vertraulich": ich == b.get("erstellt_von"),
                   "quartal": quartal_von(b["datum"]) if b["datum"] else None, "ziele": None, "vorwoche": None}
        if b["art"] == "wochenrunde":
            try:
                ansicht["ziele"] = self._projekte.ziele(ansicht["quartal"])["ziele"]
            except ProjektFehler:
                ansicht["ziele"] = []
            if vorwoche:
                liste = [a for a in map(mit_stand, vorwoche["aufgaben"]) if not a["geloescht"]]
                ansicht["vorwoche"] = {"id": vorwoche["id"], "titel": vorwoche["titel"], "datum": vorwoche["datum"],
                                       "aufgaben": liste, "anzahl": len(liste),
                                       "erledigt": sum(1 for a in liste if a["erledigt"])}
        return ansicht

    # ---------------- Anlegen, ändern, löschen ----------------
    def _letzte_wochenrunde(self, ich: str, datum: str, von=None):
        """Die Wochenrunde, aus der übernommen wird: die letzte sichtbare bis zum Datum (oder die angegebene)."""
        if von is False:
            return None
        if von:
            b = self._lesen(von, ich)
            if b["art"] != "wochenrunde":
                raise BesprechungFehler("Übernehmen geht nur aus einer Wochenrunde.")
            return b
        kandidaten = [b for b in self._alle()
                      if b["art"] == "wochenrunde" and self._darf_sehen(b, ich) and b["datum"] and b["datum"] <= datum]
        return max(kandidaten, key=lambda b: (b["datum"], b["erstellt_am"]), default=None)

    @staticmethod
    def _standard_titel(art: str, datum: str) -> str:
        if art == "wochenrunde":
            jahr, kw, _ = dt.date.fromisoformat(datum).isocalendar()
            return f"Wochenrunde KW {kw}/{jahr}"
        return f"{ARTEN[art]} am {_deutsch(datum)}"

    def _neu(self, ich: str, art: str, titel: str, datum: str, teilnehmer: list, vertraulich: bool) -> dict:
        """Gerüst einer neuen Besprechung mit den Abschnitten ihrer Art (noch nicht gespeichert)."""
        vorlage = [(s, t, m) for s, t, m, _ in WOCHENRUNDE] if art == "wochenrunde" else STANDARD_ABSCHNITTE
        jetzt = self._zeit()
        return {"version": 1, "id": _neue_id(12), "art": art, "titel": titel or self._standard_titel(art, datum),
                "datum": datum, "teilnehmer": teilnehmer, "vertraulich": vertraulich,
                "abschnitte": [{"id": _neue_id(8), "schluessel": s, "titel": t, "minuten": m, "notiz": ""} for s, t, m in vorlage],
                "themen": [], "beschluesse": [], "aufgaben": [], "bewertungen": {},
                "erstellt_von": ich, "erstellt_am": jetzt, "geaendert_am": jetzt}

    def anlegen(self, eingabe: dict) -> dict:
        """
        Neue Besprechung. Eine Wochenrunde bekommt die Abschnitte nach „Level 10“ und übernimmt aus der letzten
        Wochenrunde die offenen Themen und die Aufgaben, die im Projekt noch nicht erledigt sind (dieselben Aufgaben,
        keine Kopien) – ohne Angabe auch deren Teilnehmer. „uebernehmen_von“: andere Wochenrunde oder False.
        """
        ich = self._ich_pflicht()
        e = eingabe or {}
        art = e.get("art") or "sonstiges"
        if art not in ARTEN:
            raise BesprechungFehler("Unbekannte Art der Besprechung.")
        datum = _datum(e.get("datum")) or self._heute()
        personen = self._personen()
        vorige = self._letzte_wochenrunde(ich, datum, e.get("uebernehmen_von")) if art == "wochenrunde" else None
        if e.get("teilnehmer") is not None:
            teilnehmer = [i for i in dict.fromkeys(e["teilnehmer"] or []) if i in personen]
        elif vorige:
            teilnehmer = [i for i in vorige["teilnehmer"] if i in personen]
        else:
            teilnehmer = [ich]
        b = self._neu(ich, art, _text(e.get("titel"), 120), datum, teilnehmer,
                      bool(e["vertraulich"]) if "vertraulich" in e else art == "gespraech")
        if vorige:
            b["vorherige"] = vorige["id"]
            b["themen"] = [{**t, "id": _neue_id(10), "uebernommen_aus": vorige["id"]}
                           for t in vorige["themen"] if t.get("status") != "geloest"]
            stand = self._p(self._projekte.aufgaben_stand,
                            [(a.get("projekt_id"), a.get("aufgabe_id")) for a in vorige["aufgaben"]])
            b["aufgaben"] = [{**a, "id": _neue_id(10), "uebernommen_aus": vorige["id"]} for a in vorige["aufgaben"]
                             if a.get("aufgabe_id") in stand and not stand[a["aufgabe_id"]]["erledigt"]]
        _schreibe(self._pfad(b["id"]), b)
        return self._ansicht(b, ich)

    def _aendere(self, bid: str, aenderung) -> dict:
        """Frisch lesen, ändern, speichern – Änderungen anderer Rechner an anderen Stellen bleiben erhalten."""
        ich = self._ich_pflicht()
        pfad = self._pfad(bid)
        b = self._lesen(bid, ich)
        aenderung(b, ich)
        b["geaendert_am"] = self._zeit()
        _schreibe(pfad, b)
        return self._ansicht(b, ich)

    def aendern(self, bid: str, felder: dict) -> dict:
        """
        Titel, Datum, Art, Teilnehmer, vertraulich (nur wer angelegt hat), Abschnitte [{id, notiz, titel, minuten}],
        „mitteilung“ (Was sagen wir unseren Leuten?) und „zur_zehn“ (Was würde es zur 10 machen?).
        """
        f = felder or {}
        personen = self._personen()

        def aendern(b, ich):
            if "titel" in f:
                titel = _text(f["titel"], 120)
                if not titel:
                    raise BesprechungFehler("Der Titel darf nicht leer sein.")
                b["titel"] = titel
            if "datum" in f:
                b["datum"] = _datum(f["datum"], pflicht=True)
            if "art" in f and f["art"] != b["art"]:
                if f["art"] not in ARTEN:
                    raise BesprechungFehler("Unbekannte Art der Besprechung.")
                if "wochenrunde" in (f["art"], b["art"]):
                    raise BesprechungFehler("Eine Wochenrunde bleibt eine Wochenrunde – bitte neu anlegen.")
                b["art"] = f["art"]
            if "teilnehmer" in f:
                b["teilnehmer"] = [i for i in dict.fromkeys(f["teilnehmer"] or []) if i in personen]
            if "vertraulich" in f and bool(f["vertraulich"]) != b["vertraulich"]:
                if ich != b.get("erstellt_von"):
                    raise BesprechungFehler("Vertraulich machen oder freigeben darf nur, wer die Besprechung angelegt hat.")
                b["vertraulich"] = bool(f["vertraulich"])
            for feld in ("mitteilung", "zur_zehn"):
                if feld in f:
                    b[feld] = _langtext(f[feld], 4000)
            for teil in f.get("abschnitte") or []:
                x = _eintrag(b["abschnitte"], (teil or {}).get("id"),
                             "Diesen Abschnitt gibt es nicht mehr – vielleicht auf einem anderen Rechner gelöscht.")
                if "notiz" in teil:
                    x["notiz"] = _langtext(teil["notiz"], NOTIZ_MAX)
                if "titel" in teil and _text(teil["titel"], 80):
                    x["titel"] = _text(teil["titel"], 80)
                if "minuten" in teil:
                    x["minuten"] = _minuten(teil["minuten"])
        return self._aendere(bid, aendern)

    def loeschen(self, bid: str) -> dict:
        """Nur wer die Besprechung angelegt hat. Aufgaben in den Projekten bleiben."""
        ich = self._ich_pflicht()
        b = self._lesen(bid, ich)
        if b.get("erstellt_von") != ich:
            raise BesprechungFehler("Löschen darf nur, wer die Besprechung angelegt hat.")
        try:
            os.remove(self._pfad(bid))
        except FileNotFoundError:
            pass
        except OSError as e:
            raise BesprechungFehler(f"Löschen hat nicht geklappt ({e}).") from None
        return {"ok": True}

    # ---------------- Abschnitte ----------------
    def abschnitt_anlegen(self, bid: str, titel: str, minuten=None) -> dict:
        titel = _text(titel, 80)
        if not titel:
            raise BesprechungFehler("Bitte den Abschnitt benennen.")
        minuten = _minuten(minuten)

        def neu(b, ich):
            if len(b["abschnitte"]) >= 30:
                raise BesprechungFehler("Höchstens 30 Abschnitte je Besprechung.")
            b["abschnitte"].append({"id": _neue_id(8), "schluessel": "eigener", "titel": titel, "minuten": minuten, "notiz": ""})
        return self._aendere(bid, neu)

    def abschnitt_loeschen(self, bid: str, abschnitt_id: str) -> dict:
        def weg(b, ich):
            x = _eintrag(b["abschnitte"], abschnitt_id, "Diesen Abschnitt gibt es nicht mehr.")
            if b["art"] == "wochenrunde" and x.get("schluessel") in HILFE:
                raise BesprechungFehler("Die Abschnitte der Wochenrunde bleiben – eigene lassen sich löschen.")
            if len(b["abschnitte"]) <= 1:
                raise BesprechungFehler("Ein Abschnitt muss bleiben.")
            b["abschnitte"] = [a for a in b["abschnitte"] if a["id"] != abschnitt_id]
        return self._aendere(bid, weg)

    # ---------------- Themen ----------------
    def thema_anlegen(self, bid: str, eingabe) -> dict:
        e = {"titel": eingabe} if isinstance(eingabe, str) else (eingabe or {})
        titel = _text(e.get("titel"), 200)
        if not titel:
            raise BesprechungFehler("Bitte das Thema kurz benennen.")

        def neu(b, ich):
            _platz(b["themen"], "Themen")
            t = {"id": _neue_id(10), "titel": titel, "status": "offen", "notiz": _langtext(e.get("notiz"), 5000),
                 "top": False, "von": ich, "am": self._zeit(), "geloest_am": None}
            b["themen"].append(t)
            if e.get("top"):
                _top_setzen(b, t)
        return self._aendere(bid, neu)

    def thema_aendern(self, bid: str, thema_id: str, felder: dict) -> dict:
        f = felder or {}

        def aendern(b, ich):
            t = _eintrag(b["themen"], thema_id, "Dieses Thema gibt es nicht mehr.")
            if "titel" in f:
                titel = _text(f["titel"], 200)
                if not titel:
                    raise BesprechungFehler("Das Thema braucht einen Namen.")
                t["titel"] = titel
            if "status" in f:
                if f["status"] not in THEMA_STATUS:
                    raise BesprechungFehler("Ein Thema ist offen oder gelöst.")
                if f["status"] != t.get("status"):
                    t["status"] = f["status"]
                    t["geloest_am"] = self._zeit() if f["status"] == "geloest" else None
                    if f["status"] == "geloest":
                        t["top"] = False
            if "notiz" in f:
                t["notiz"] = _langtext(f["notiz"], 5000)
            if "top" in f:
                if f["top"]:
                    _top_setzen(b, t)
                else:
                    t["top"] = False
        return self._aendere(bid, aendern)

    def thema_loeschen(self, bid: str, thema_id: str) -> dict:
        def weg(b, ich):
            _eintrag(b["themen"], thema_id, "Dieses Thema gibt es nicht mehr.")
            b["themen"] = [t for t in b["themen"] if t["id"] != thema_id]
        return self._aendere(bid, weg)

    # ---------------- Beschlüsse ----------------
    def beschluss_anlegen(self, bid: str, eingabe: dict) -> dict:
        """
        Text und Grund (Pflicht: warum so entschieden), auf Wunsch Wiedervorlage, Datum (sonst das der Besprechung)
        und das Thema, das damit gelöst ist. Ein neuer Beschluss „gilt“.
        """
        e = eingabe or {}
        text = _langtext(e.get("text"), 2000)
        if not text:
            raise BesprechungFehler("Bitte den Beschluss eingeben.")
        grund = _langtext(e.get("grund"), 2000)
        if not grund:
            raise BesprechungFehler("Bitte den Grund angeben – warum wurde so entschieden?")
        datum = _datum(e.get("datum"))
        wiedervorlage = _datum(e.get("wiedervorlage"))

        def neu(b, ich):
            _platz(b["beschluesse"], "Beschlüsse")
            eintrag = {"id": _neue_id(10), "text": text, "grund": grund, "status": "gilt", "wiedervorlage": wiedervorlage,
                       "datum": datum or b["datum"] or self._heute(), "von": ich, "am": self._zeit()}
            if e.get("thema_id"):
                t = _eintrag(b["themen"], e["thema_id"], "Dieses Thema gibt es nicht mehr.")
                if t.get("status") != "geloest":
                    t["status"], t["geloest_am"], t["top"] = "geloest", self._zeit(), False
                eintrag["thema_id"] = t["id"]
            b["beschluesse"].append(eintrag)
        return self._aendere(bid, neu)

    def beschluss_aendern(self, bid: str, beschluss_id: str, felder: dict) -> dict:
        """Text, Grund, Wiedervorlage (leer = keine) und Status („gilt“, „beendet“, „geändert“)."""
        f = felder or {}

        def aendern(b, ich):
            x = _eintrag(b["beschluesse"], beschluss_id, "Diesen Beschluss gibt es nicht mehr.")
            for feld, meldung in (("text", "Der Beschluss darf nicht leer sein."), ("grund", "Der Grund darf nicht leer sein.")):
                if feld in f:
                    wert = _langtext(f[feld], 2000)
                    if not wert:
                        raise BesprechungFehler(meldung)
                    x[feld] = wert
            if "wiedervorlage" in f:
                x["wiedervorlage"] = _datum(f["wiedervorlage"])
            if "status" in f:
                if f["status"] not in BESCHLUSS_STATUS:
                    raise BesprechungFehler("Ein Beschluss „gilt“, ist „beendet“ oder wurde „geändert“.")
                x["status"] = f["status"]
            x["geaendert_am"], x["geaendert_von"] = self._zeit(), ich
        return self._aendere(bid, aendern)

    def beschluss_loeschen(self, bid: str, beschluss_id: str) -> dict:
        def weg(b, ich):
            _eintrag(b["beschluesse"], beschluss_id, "Diesen Beschluss gibt es nicht mehr.")
            b["beschluesse"] = [x for x in b["beschluesse"] if x["id"] != beschluss_id]
        return self._aendere(bid, weg)

    def beschluesse(self, suche: str = None) -> list:
        """
        Beschluss-Log: alle Beschlüsse aller Besprechungen, die ich sehen darf. Fällige Wiedervorlagen (geltende
        Beschlüsse, deren Wiedervorlage heute oder früher ist) stehen oben, danach die neuesten zuerst. 'suche' findet
        Wörter in Beschluss, Grund, Besprechung, Art und Name (alle Wörter müssen vorkommen).
        """
        ich = self._ich()
        if not ich:
            return []
        namen = {p["id"]: p["name"] for p in self._personen().values()}
        heute = self._heute()
        woerter = str(suche or "").casefold().split()
        liste = []
        for b in self._alle():
            if not self._darf_sehen(b, ich):
                continue
            for x in b["beschluesse"]:
                status = x.get("status") if x.get("status") in BESCHLUSS_STATUS else "gilt"
                wv = x.get("wiedervorlage") if _gueltiges_datum(x.get("wiedervorlage")) else None
                e = {**x, "status": status, "grund": x.get("grund") or "", "wiedervorlage": wv,
                     "wiedervorlage_faellig": bool(wv) and status == "gilt" and wv <= heute,
                     "besprechung_id": b["id"], "besprechung": b["titel"], "besprechung_datum": b["datum"],
                     "art": b["art"], "art_name": ARTEN[b["art"]], "vertraulich": b["vertraulich"]}
                text = " ".join((str(x.get("text") or ""), e["grund"], b["titel"], ARTEN[b["art"]],
                                 namen.get(x.get("von"), ""), status)).casefold()
                if all(w in text for w in woerter):
                    liste.append(e)
        liste.sort(key=lambda e: (str(e.get("datum") or ""), str(e.get("am") or "")), reverse=True)
        faellig = sorted((e for e in liste if e["wiedervorlage_faellig"]), key=lambda e: e["wiedervorlage"])
        return faellig + [e for e in liste if not e["wiedervorlage_faellig"]]

    # ---------------- Aufgaben (echte Aufgaben in Projekten) ----------------
    def _standardprojekt(self, b: dict, zustaendig: list) -> dict:
        """Ohne gewähltes Projekt: „Aus Besprechungen“ – bei vertraulichen Besprechungen ein eigenes Projekt."""
        mitglieder = list(dict.fromkeys(b["teilnehmer"] + zustaendig))
        if b["vertraulich"]:
            mitglieder = list(dict.fromkeys([b.get("erstellt_von")] + mitglieder))
            return self._p(self._projekte.sammelprojekt, f"besprechung-{b['id']}", f"Vertraulich: {b['titel']}"[:80],
                           mitglieder, f"Aufgaben aus der vertraulichen Besprechung „{b['titel']}“ – nur für ihre Teilnehmer.")
        return self._p(self._projekte.sammelprojekt, "besprechungen", SAMMELPROJEKT, mitglieder,
                       "Aufgaben aus Besprechungen, für die kein eigenes Projekt gewählt wurde.")

    def _projekt_fuer(self, b: dict, projekt_id: str, zustaendig: list) -> dict:
        """Gewähltes Projekt (Zuständige werden dort Mitglied) oder das Standardprojekt der Besprechung."""
        if not projekt_id:
            return self._standardprojekt(b, zustaendig)
        p = self._p(self._projekte.projekt, projekt_id)
        if p.get("archiviert"):
            raise BesprechungFehler("Dieses Projekt ist archiviert – bitte ein anderes wählen.")
        for z in zustaendig:
            if z not in p.get("mitglieder", []):
                p = self._p(self._projekte.mitglied_hinzufuegen, p["id"], z)
        return p

    def _projektaufgabe(self, b: dict, ich: str, p: dict, titel: str, zustaendig: list, faellig, zusatz: str = "") -> dict:
        """Aufgabe im Projekt anlegen; zurück kommt der Eintrag für die Besprechung."""
        herkunft = f"Aus der Besprechung „{b['titel']}“" + (f" vom {_deutsch(b['datum'])}" if b["datum"] else "") + "."
        p = self._p(self._projekte.aufgabe_anlegen, p["id"], {"titel": titel, "zustaendig": zustaendig, "faellig": faellig,
                                                             "beschreibung": herkunft + ("\n\n" + zusatz if zusatz else "")})
        neu = p["aufgaben"][-1]
        return {"id": _neue_id(10), "titel": titel, "zustaendig": neu.get("zustaendig") or [], "faellig": faellig,
                "projekt_id": p["id"], "aufgabe_id": neu["id"], "von": ich, "am": self._zeit()}

    def aufgabe_anlegen(self, bid: str, eingabe: dict) -> dict:
        """
        Legt die Aufgabe im Projekt an ('projekt_id', sonst „Aus Besprechungen“) und hält sie in der Besprechung fest.
        Genau ein Verantwortlicher ('zustaendig'); ohne Fälligkeit heute + 7 Tage. Ist er im gewählten Projekt noch
        nicht Mitglied, wird er dazugeholt – sonst sähe er die Aufgabe nicht unter „Meine Aufgaben“. Mit 'thema_id'
        ist die Aufgabe die Lösung dieses Themas: das Thema gilt dann als gelöst.
        """
        ich = self._ich_pflicht()
        e = eingabe or {}
        b = self._lesen(bid, ich)
        _platz(b["aufgaben"], "Aufgaben")
        titel = _text(e.get("titel"), 200)
        if not titel:
            raise BesprechungFehler("Bitte die Aufgabe kurz beschreiben.")
        faellig = _datum(e.get("faellig")) or (self._jetzt().date() + dt.timedelta(days=AUFGABE_TAGE)).isoformat()
        personen = self._personen()
        zustaendig = e.get("zustaendig") or []
        zustaendig = [i for i in dict.fromkeys([zustaendig] if isinstance(zustaendig, str) else zustaendig) if i in personen]
        if len(zustaendig) != 1:
            raise BesprechungFehler("Bitte genau eine Person als verantwortlich wählen.")
        if e.get("thema_id"):
            _eintrag(b["themen"], e["thema_id"], "Dieses Thema gibt es nicht mehr.")
        p = self._projekt_fuer(b, e.get("projekt_id"), zustaendig)
        eintrag = self._projektaufgabe(b, ich, p, titel, zustaendig, faellig, _langtext(e.get("beschreibung"), 4000))

        def dazu(b, ich):
            if e.get("thema_id"):
                t = next((x for x in b["themen"] if x["id"] == e["thema_id"]), None)
                if t:                                         # inzwischen gelöscht: Aufgabe bleibt trotzdem
                    eintrag["thema_id"] = t["id"]
                    if t.get("status") != "geloest":
                        t["status"], t["geloest_am"], t["top"] = "geloest", self._zeit(), False
            b["aufgaben"].append(eintrag)
        return self._aendere(bid, dazu)

    def _aufgabe_finden(self, b: dict, ich: str, eintrag_id: str) -> dict:
        """Aufgabe dieser Besprechung – oder der Vorwoche (die Wochenrunde zeigt beide)."""
        a = next((x for x in b["aufgaben"] if x["id"] == eintrag_id), None)
        vorwoche = None if a else self._vorwoche(b, ich)
        a = a or next((x for x in (vorwoche or {}).get("aufgaben", []) if x["id"] == eintrag_id), None)
        if not a or not a.get("aufgabe_id"):
            raise BesprechungFehler("Diese Aufgabe steht nicht mehr in der Besprechung.")
        return a

    def aufgabe_erledigen(self, bid: str, eintrag_id: str, erledigt=True) -> dict:
        """Abhaken (oder wieder öffnen) – im Projekt, denn dort steht die Aufgabe."""
        ich = self._ich_pflicht()
        b = self._lesen(bid, ich)
        a = self._aufgabe_finden(b, ich, eintrag_id)
        self._p(self._projekte.aufgabe_erledigen, a["projekt_id"], a["aufgabe_id"], _ja(erledigt))
        return self._ansicht(b, ich)

    def aufgabe_loeschen(self, bid: str, eintrag_id: str) -> dict:
        """Aus der Besprechung und aus dem Projekt löschen (ist sie dort schon weg, nur aus der Besprechung)."""
        ich = self._ich_pflicht()
        b = self._lesen(bid, ich)
        a = _eintrag(b["aufgaben"], eintrag_id, "Diese Aufgabe steht nicht mehr in der Besprechung.")
        if a.get("aufgabe_id") and a["aufgabe_id"] in self._p(self._projekte.aufgaben_stand, [(a.get("projekt_id"), a["aufgabe_id"])]):
            self._p(self._projekte.aufgabe_loeschen, a["projekt_id"], a["aufgabe_id"])

        def weg(b, ich):
            b["aufgaben"] = [x for x in b["aufgaben"] if x["id"] != eintrag_id]
        return self._aendere(bid, weg)

    # ---------------- Bewertung ----------------
    def bewerten(self, bid: str, note, person_id: str = None) -> dict:
        """Note 1–10 je Teilnehmer (ohne 'person_id' die eigene); leer entfernt sie wieder."""
        n = _note(note)

        def setzen(b, ich):
            wer = person_id or ich
            if wer not in b["teilnehmer"]:
                raise BesprechungFehler("Bewerten können nur Teilnehmer der Besprechung.")
            if n is None:
                b["bewertungen"].pop(wer, None)
            else:
                b["bewertungen"][wer] = n
        return self._aendere(bid, setzen)

    # ---------------- Übernahme aus der Protokoll-App ----------------
    def _protokoll_plan(self, quelle) -> dict:
        """Was aus einem Protokoll der Protokoll-App würde – für Vorschau und Übernahme dieselbe Rechnung."""
        roh = _protokoll_lesen(quelle)
        m = roh["meeting"] if isinstance(roh.get("meeting"), dict) else {}
        personen = list(self._personen().values())
        hinweise = []
        datum = _protokoll_datum(m.get("datum"))
        if not datum:
            datum = self._heute()
            hinweise.append("Im Protokoll steht kein Datum – eingesetzt ist heute.")
        namen = [n for n in (x.strip() for x in re.split(r"[,;\n]+", _feld(m, "teilnehmer"))) if n]
        teilnehmer, unbekannt = [], []
        for n in namen:
            pid = _person_zu_name(n, personen)
            if pid:
                teilnehmer.append(pid)
            else:
                unbekannt.append(n)
        if unbekannt:
            hinweise.append("Ohne Person in ODIN (nur in den Notizen): " + ", ".join(unbekannt) + ".")
        zeit = "–".join(x for x in (_feld(m, "beginn"), _feld(m, "ende")) if x)
        kopf = [("Ort", _feld(m, "ort")), ("Zeit", zeit + " Uhr" if zeit else ""), ("Teilnehmer laut Protokoll", ", ".join(namen)),
                ("Protokoll", _feld(m, "protokoll")), ("Nächster Termin", _deutsch(_protokoll_datum(m.get("naechsterTermin")) or ""))]
        notiz = "\n".join(["Übernommen aus der Protokoll-App."] + [f"{k}: {v}" for k, v in kopf if v] +
                          ([""] + [_feld(m, "notizen")] if _feld(m, "notizen") else []))
        punkte, leer = [], 0
        for p in roh["punkte"]:
            if not isinstance(p, dict):
                leer += 1
                continue
            kritik, beschluss, verantwortlich = _feld(p, "kritik"), _feld(p, "beschluss"), _feld(p, "verantwortlich")
            titel = _text(kritik or beschluss or _feld(p, "loesung") or _feld(p, "notizen"), 200)
            if not titel:
                leer += 1
                continue
            status = str(p.get("status") or "offen")
            teile = [("Lösung", _feld(p, "loesung")), ("Offen", _feld(p, "offen")), ("Notizen", _feld(p, "notizen")),
                     ("Kategorie", " · ".join(x for x in (_feld(p, "kategorie"), _feld(p, "herkunft")) if x)),
                     ("Priorität", "hoch" if p.get("prioritaet") == "hoch" else "")]
            thema = {"titel": titel, "status": "geloest" if status in ("besprochen", "erledigt") else "offen",
                     "notiz": _langtext("\n".join(f"{k}: {v}" for k, v in teile if v) + ("\nVertagt." if status == "vertagt" else ""), 5000),
                     "nr": p.get("urspNr") if isinstance(p.get("urspNr"), int) else None, "beschluss": None, "aufgabe": None}
            if beschluss:
                thema["beschluss"] = {"text": _langtext(beschluss, 2000),
                                      "grund": _langtext(_feld(p, "kriterium") or kritik or "Aus dem Protokoll übernommen.", 2000)}
            if beschluss and verantwortlich:
                pid = None if _mehrere(verantwortlich) else _person_zu_name(verantwortlich, personen)
                frist = _protokoll_datum(p.get("frist"))
                thema["aufgabe"] = {"titel": _text(beschluss, 200), "faellig": frist, "verantwortlich": verantwortlich,
                                    "zustaendig": pid, "erledigt": status == "erledigt", "kriterium": _feld(p, "kriterium")}
                if not pid:
                    hinweise.append(f"„{_text(beschluss, 60)}“: „{verantwortlich}“ ist keiner Person zugeordnet – "
                                    "die Aufgabe kommt ohne Verantwortlichen.")
                if _feld(p, "frist") and not frist:
                    hinweise.append(f"„{_text(beschluss, 60)}“: Frist „{_feld(p, 'frist')}“ ist kein Datum – ohne Fälligkeit übernommen.")
            punkte.append(thema)
        if leer:
            hinweise.append(f"{leer} leere Punkte übersprungen.")
        quelle_id, ich = str(roh.get("id") or "")[:80], self._ich()
        frueher = [b for b in self._alle() if quelle_id and (b.get("quelle") or {}).get("id") == quelle_id
                   and self._darf_sehen(b, ich)]
        if frueher:
            hinweise.insert(0, f"Dieses Protokoll wurde schon übernommen: „{frueher[0]['titel']}“ – es entsteht eine zweite Besprechung.")
        return {"titel": _text(_feld(m, "titel"), 120) or f"Protokoll vom {_deutsch(datum)}", "datum": datum,
                "teilnehmer": list(dict.fromkeys(teilnehmer)), "teilnehmer_unbekannt": unbekannt, "notiz": notiz,
                "punkte": punkte, "hinweise": hinweise, "quelle": {"app": str(roh.get("app") or "Protokoll-App")[:60],
                                                                  "id": quelle_id}}

    def protokoll_vorschau(self, quelle) -> dict:
        """Vorschau vor dem Übernehmen: Titel, Datum, Teilnehmer und wie viele Themen, Beschlüsse und Aufgaben entstehen."""
        self._ich_pflicht()
        plan = self._protokoll_plan(quelle)
        aufgaben = [t["aufgabe"] for t in plan["punkte"] if t["aufgabe"]]
        return {"titel": plan["titel"], "datum": plan["datum"], "teilnehmer": plan["teilnehmer"],
                "teilnehmer_unbekannt": plan["teilnehmer_unbekannt"], "themen": len(plan["punkte"]),
                "themen_offen": sum(1 for t in plan["punkte"] if t["status"] == "offen"),
                "beschluesse": sum(1 for t in plan["punkte"] if t["beschluss"]), "aufgaben": len(aufgaben),
                "aufgaben_ohne_person": sum(1 for a in aufgaben if not a["zustaendig"]), "hinweise": plan["hinweise"],
                "punkte": [{"titel": t["titel"], "status": t["status"], "beschluss": bool(t["beschluss"]),
                            "verantwortlich": (t["aufgabe"] or {}).get("verantwortlich", "")} for t in plan["punkte"][:50]]}

    def protokoll_uebernehmen(self, quelle, optionen: dict = None) -> dict:
        """
        Protokoll der Protokoll-App als neue Besprechung (Art „Mitarbeitergespräch“, vertraulich): je Punkt ein Thema
        (gelöst, wenn besprochen oder erledigt), je Beschluss ein Beschluss (Grund = Kriterium, sonst die Kritik), je
        Beschluss mit Verantwortlichem eine Aufgabe im Projekt (erledigt, wenn der Punkt erledigt ist). Verantwortliche
        ohne passende Person bleiben unzugeordnet, mit Hinweis. 'optionen': titel, art, vertraulich, projekt_id.
        """
        ich = self._ich_pflicht()
        o = optionen or {}
        plan = self._protokoll_plan(quelle)
        art = o.get("art") or "gespraech"
        if art not in ARTEN or art == "wochenrunde":
            raise BesprechungFehler("Übernehmen geht als Gespräch, Kunden-, Lieferanten-, Bank- oder sonstige Besprechung.")
        b = self._neu(ich, art, _text(o.get("titel"), 120) or plan["titel"], plan["datum"], plan["teilnehmer"] or [ich],
                      bool(o["vertraulich"]) if "vertraulich" in o else art == "gespraech")
        b["abschnitte"][0]["notiz"] = plan["notiz"]
        b["quelle"] = {**plan["quelle"], "uebernommen_am": self._zeit()}
        jetzt = self._zeit()
        for t in plan["punkte"][:MAX_EINTRAEGE]:
            thema = {"id": _neue_id(10), "titel": t["titel"], "status": t["status"], "notiz": t["notiz"], "top": False,
                     "von": ich, "am": jetzt, "geloest_am": jetzt if t["status"] == "geloest" else None}
            b["themen"].append(thema)
            t["thema_id"] = thema["id"]
            if t["beschluss"]:
                b["beschluesse"].append({"id": _neue_id(10), **t["beschluss"], "status": "gilt", "wiedervorlage": None,
                                         "datum": b["datum"], "von": ich, "am": jetzt, "thema_id": thema["id"]})
        _schreibe(self._pfad(b["id"]), b)              # erst die Besprechung, dann die Aufgaben in den Projekten
        aufgaben = [t for t in plan["punkte"][:MAX_EINTRAEGE] if t["aufgabe"]]
        if aufgaben:
            zustaendige = [t["aufgabe"]["zustaendig"] for t in aufgaben if t["aufgabe"]["zustaendig"]]
            p = self._projekt_fuer(b, o.get("projekt_id"), list(dict.fromkeys(zustaendige)))
            eintraege = []
            for t in aufgaben:
                a = t["aufgabe"]
                zusatz = "\n".join(x for x in (f"Erledigt, wenn: {a['kriterium']}" if a["kriterium"] else "",
                                               "" if a["zustaendig"] else f"Verantwortlich laut Protokoll: {a['verantwortlich']} "
                                               "(in ODIN keiner Person zugeordnet).") if x)
                e = self._projektaufgabe(b, ich, p, a["titel"], [a["zustaendig"]] if a["zustaendig"] else [], a["faellig"], zusatz)
                e["thema_id"] = t["thema_id"]
                if not a["zustaendig"]:
                    e["hinweis"] = f"Verantwortlich laut Protokoll: {a['verantwortlich']} – keiner Person zugeordnet."
                if a["erledigt"]:
                    self._p(self._projekte.aufgabe_erledigen, e["projekt_id"], e["aufgabe_id"], True)
                eintraege.append(e)

            def dazu(b, ich):
                b["aufgaben"].extend(eintraege)
            ansicht = self._aendere(b["id"], dazu)
        else:
            ansicht = self._ansicht(b, ich)
        ansicht["uebernahme"] = {"themen": len(b["themen"]), "beschluesse": len(b["beschluesse"]),
                                 "aufgaben": len(aufgaben), "hinweise": plan["hinweise"]}
        return ansicht
