"""
ODIN im Browser – für Handy und Tablet im selben Netz, ohne eigenen Server.

Der Rechner, auf dem ODIN läuft, liefert die Oberfläche (Ordner ui/) aus und beantwortet die Aufrufe, die im
Programm über pywebview laufen, per HTTP (POST /api/<name>). Im Browser ersetzt eine kleine Brücke
(web-bruecke.js) `window.pywebview.api`, die Oberfläche bleibt dieselbe.

Sicherheit für den Betrieb im Firmennetz:
- Zugang nur mit der sechsstelligen Nummer, die ODIN beim Freigeben anzeigt (danach Sitzungs-Cookie).
- Nur freigegebene Aufrufe: keine Datei-Dialoge, kein Öffnen oder Lesen beliebiger Dateien, keine Zugangsdaten.
- Wer man ist (Projekte, Urlaub, Tagesfragen …), gilt je Gerät (Sitzung) – und erst nach Personenwahl mit PIN
  (tresor.py). Falsche PINs zählen je Gerät; „Abmelden“ beendet die Sitzung, danach wieder Nummer und PIN.
Das ist eine Vorstufe der Web-App, keine Internet-Freigabe: nicht am Router nach außen öffnen.
"""

import http.cookies
import json
import mimetypes
import os
import secrets
import socket
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .cockpit.export import ohne_einkauf

# Aufrufe, die im Browser erlaubt sind. Alles, was Fenster-Dialoge braucht, Dateien des Rechners öffnet/liest
# oder Zugangsdaten berührt, fehlt bewusst.
ERLAUBT = {
    "design", "stil", "oberflaeche",
    "cockpit_daten", "cockpit_frage", "cockpit_todo_anlegen", "cockpit_todo_umschalten", "cockpit_todo_loeschen",
    "cockpit_vororder_anlegen", "cockpit_vororder_loeschen", "cockpit_abloesung_planen", "cockpit_abloesung_loeschen",
    "cockpit_aufruf", "projekte_aufruf", "urlaub_aufruf", "tagesfragen_aufruf", "besprechungen_aufruf",
    "beirat_aufruf", "messe_aufruf", "tickets_aufruf", "aktionen_aufruf", "tresor_aufruf",
    "ablage_status", "ab_uebersicht", "syscara_uebersicht", "ab_details", "ab_uebersprungen", "fahrzeuge",
}
# Rechtsfälle bewusst nicht: Akten lesen darf nur, wer den Ordner selbst öffnen kann – übers Handy würde
# man mit den Rechten des Rechners lesen, auf dem ODIN läuft. Erst mit echter Anmeldung freigeben.
# Microsoft-Anmeldung und Erinnerungsmail (konto_aufruf) ebenso nicht: übers Handy würde man im Namen dessen
# anmelden oder Mails senden, der am Rechner angemeldet ist.
# Einzelne Aktionen innerhalb erlaubter Aufrufe, die ein Fenster brauchen
GESPERRTE_AKTIONEN = {"protokoll_waehlen", "protokoll_uebernehmen", "dokumente_waehlen", "dokument_oeffnen",
                      "ordner_waehlen", "ordner_oeffnen"}
MAX_ANFRAGE = 2 * 1024 * 1024
# Im Browser weiß ODIN nicht sicher, wer am Gerät sitzt (es gibt dort keine persönliche Anmeldung). Alles, was Rechte
# braucht oder sich schwer zurückholen lässt, geht deshalb nur am Rechner.
NUR_AM_RECHNER = {
    "urlaub_aufruf": {"entscheiden", "regeln_speichern", "antrag_zurueckziehen", "antraege", "konten"},
    "projekte_aufruf": {"projekt_loeschen", "projekt_aendern", "mitglied_entfernen", "mitglied_hinzufuegen",
                        "spalte_loeschen", "spalte_umbenennen", "aufgabe_loeschen", "kommentar_loeschen",
                        "punkt_loeschen", "person_anlegen"},
    # Anmeldung: Person + PIN ja; PINs anderer zurücksetzen nur Verwalter am Rechner
    "tresor_aufruf": {"pin_zuruecksetzen", "pin_uebersicht", "einstellungen_speichern"},
    "tagesfragen_aufruf": {"vorschlag_entscheiden", "einstellungen_speichern", "verlosen", "frage_speichern",
                           "frage_aktiv"},
    "besprechungen_aufruf": {"loeschen", "aendern", "abschnitt_loeschen", "thema_loeschen", "beschluss_loeschen",
                             "beschluss_aendern", "aufgabe_loeschen"},
    # Messe-Personal: lesen und CSV im Browser ja, ändern nur Verwalter – und die erkennt ODIN nur am Rechner
    "messe_aufruf": {"anlegen", "aendern", "entfernen", "csv_speichern", "bearbeiter_setzen"},
    "cockpit_aufruf": {"fuehrung_einstellungen", "scorecard_speichern", "scorecard_wert", "bonus_speichern",
                       "bonus_loeschen", "frist_loeschen", "frist_speichern", "frist_erledigt",
                       "cashback_verantwortlich", "fahrzeugtyp_zuordnen", "assistent_finanzen"},
    # Tickets: im Browser nur melden und eigene sehen (Verwalter gelten dort nicht, siehe tickets.py)
    "tickets_aufruf": {"fuer_claude"},
    # In ODIN arbeiten: verstehen und Vorschau ja; ausführen prüft der Aktionsdienst je Aktion (nur, was im Browser
    # heute schon schreiben darf: To-dos, eigener Urlaubsantrag, Ticket) – Excel-Listen ändern nur am Rechner
    "aktionen_aufruf": {"rueckgaengig", "einstellungen_speichern"},
}
# Schutz vor Durchprobieren der Nummer
FEHLVERSUCHE_JE_GERAET = 5          # danach Pause für dieses Gerät …
SPERRE_SEKUNDEN = 60                # … die sich mit jeder weiteren Runde verdoppelt (höchstens eine Stunde)
FEHLVERSUCHE_GESAMT = 40            # danach nimmt der Server eine Weile gar keine Nummer mehr an (alle Geräte)
PAUSE_GESAMT = 120                  # Sekunden; wer schon angemeldet ist, arbeitet weiter
MAX_LEBENSZEIT = 45                 # Sekunden, die eine einzelne Verbindung insgesamt offen bleiben darf
MAX_VERBINDUNGEN = 48               # gleichzeitig offene Verbindungen insgesamt
MAX_VERBINDUNGEN_JE_GERAET = 12
MAX_SITZUNGEN = 40
ZEITLIMIT = 20                      # Sekunden, die eine Verbindung für Kopf und Inhalt Zeit hat

# Wer gerade fragt – je Anfrage (Thread) gesetzt; Projekte liest daraus „ich“, solange eine Web-Anfrage läuft.
ANFRAGE = threading.local()
SITZUNG_SEKUNDEN = 12 * 3600
# Nur eigene Dateien, keine fremden Skripte, keine Einbettung in fremde Seiten. Stile stehen in der Oberfläche auch
# direkt an Elementen, deshalb 'unsafe-inline' nur für Stile.
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
       "font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; "
       "frame-ancestors 'none'")


UNVERAENDERT = object()


def ich_im_web():
    """(aktiv, person_id) der laufenden Web-Anfrage; außerhalb einer Web-Anfrage (False, None)."""
    return getattr(ANFRAGE, "aktiv", False), getattr(ANFRAGE, "ich", None)


def ich_im_web_setzen(person_id: str):
    """Nur aus tresor.py nach geprüfter PIN (oder "" beim Abmelden/Sperren) – gilt für die Sitzung des Geräts."""
    ANFRAGE.ich = person_id or None
    ANFRAGE.neues_ich = person_id or ""


def geraet_im_web() -> str:
    """Wofür Fehlversuche bei der PIN zählen: „web:<ip>“ im Browser, sonst „rechner“."""
    if getattr(ANFRAGE, "aktiv", False):
        return "web:" + str(getattr(ANFRAGE, "ip", "") or "?")
    return "rechner"


def lokale_adressen() -> list:
    """IPv4-Adressen dieses Rechners im lokalen Netz (ohne 127.x)."""
    adressen = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))           # sendet nichts, wählt nur die Schnittstelle
        adressen.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in adressen:
                adressen.append(ip)
    except OSError:
        pass
    return adressen


BRUECKE = r"""/* ODIN im Browser: ersetzt window.pywebview.api durch Aufrufe an den Rechner, auf dem ODIN läuft. */
(function () {
  const ruf = (name, args) => fetch("/api/" + encodeURIComponent(name), {
    method: "POST", headers: { "Content-Type": "application/json" }, credentials: "same-origin",
    body: JSON.stringify(args),
  }).then(async (r) => {
    if (r.status === 401) { location.href = "/"; throw new Error("Bitte neu anmelden."); }
    const x = await r.json();
    if (x && x.__fehler) throw new Error(x.__fehler);
    return x ? x.ergebnis : null;
  });
  const api = new Proxy({}, { get: (_, name) => (...args) => ruf(String(name), args) });
  window.pywebview = { api, web: true };
  document.documentElement.dataset.web = "1";
  const bereit = () => window.dispatchEvent(new Event("pywebviewready"));
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bereit); else bereit();
})();
"""

ANMELDUNG = """<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>ODIN</title>
<style>
@font-face { font-family: Inter; font-weight: 400; src: url(/fonts/inter-latin-400-normal.woff2) format("woff2"); }
@font-face { font-family: Inter; font-weight: 600; src: url(/fonts/inter-latin-600-normal.woff2) format("woff2"); }
@font-face { font-family: Archivo; font-weight: 800; src: url(/fonts/archivo-latin-800-normal.woff2) format("woff2"); }
:root { color-scheme: light dark; --w1: #F5F2EE; --w2: #E9E4DE; --w3: #D8D1C9; --ink: #231F20; --leise: #6E6767;
  --feld: rgba(255,255,255,.7); --linie: rgba(60,40,30,.16); --rot: #D0141C; --fehler: #9E1A13;
  --s1: #ECEBE9; --s2: #B8B6B3; --s3: #7F7D7A; --s4: #4E4C4A; }
@media (prefers-color-scheme: dark) { :root { --w1: #251D19; --w2: #15110F; --w3: #0A0807; --ink: #F4EFEC; --leise: #A69C97;
  --feld: rgba(255,255,255,.06); --linie: rgba(255,255,255,.13); --rot: #FF4A50; --fehler: #FF8F85;
  --s1: #D9D8D6; --s2: #9E9C99; --s3: #6A6865; --s4: #3C3A38; } }
* { box-sizing: border-box; }
body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 32px 16px; color: var(--ink);
  font: 15px/1.5 Inter, system-ui, -apple-system, "Segoe UI", sans-serif;
  background: radial-gradient(130% 95% at 24% 12%, var(--w1) 0%, var(--w2) 50%, var(--w3) 100%) fixed; }
form { width: min(340px, 100%); text-align: center; }
.tuer { width: 128px; height: 128px; margin: 10px auto 30px; border-radius: 50%; position: relative;
  background: repeating-radial-gradient(circle, rgba(255,255,255,.07) 0 .6px, rgba(0,0,0,.045) .6px 1.4px, transparent 1.4px 2.4px),
    conic-gradient(from 18deg, var(--s2), var(--s1) 38deg, var(--s3) 100deg, var(--s2) 150deg, var(--s1) 218deg, var(--s3) 284deg, var(--s2));
  box-shadow: 0 0 0 9px var(--s3), 0 0 0 10px rgba(0,0,0,.22), 0 30px 50px -24px rgba(0,0,0,.6), inset 0 2px 2px rgba(255,255,255,.4); }
.tuer::before { content: ""; position: absolute; inset: 26%; border-radius: 50%;
  background: repeating-conic-gradient(var(--s4) 0 2.5deg, var(--s1) 2.5deg 5deg); box-shadow: 0 4px 8px rgba(0,0,0,.4); }
.tuer img { position: absolute; inset: 36%; width: 28%; height: 28%; border-radius: 22%; box-shadow: 0 1px 2px rgba(0,0,0,.45); }
h1 { font: 800 30px/1.1 Archivo, Inter, sans-serif; letter-spacing: -.01em; margin: 0 0 6px; }
p { margin: 0 0 20px; color: var(--leise); font-size: 14px; }
input { width: 100%; font: 600 28px/1 ui-monospace, Consolas, monospace; letter-spacing: .3em; text-indent: .3em; text-align: center;
  padding: 12px; border: 1px solid var(--linie); border-radius: 12px; background: var(--feld); color: var(--ink); }
input:focus { outline: 2px solid var(--ink); outline-offset: 1px; }
button { margin-top: 12px; width: 100%; min-height: 46px; font: 600 15px Inter, system-ui, sans-serif; border: 0; border-radius: 12px;
  background: var(--rot); color: #fff; cursor: pointer; transition: transform 160ms cubic-bezier(.23,1,.32,1); }
button:active { transform: scale(.97); }
button:focus-visible { outline: 2px solid var(--ink); outline-offset: 2px; }
.fehler { color: var(--fehler); font-size: 13.5px; margin-top: 12px; }
</style></head><body><form method="get" action="/">
<div class="tuer" aria-hidden="true"><img src="/img/odin-signet.svg" alt=""></div>
<h1>ODIN</h1><p>Bitte die sechsstellige Nummer eingeben, die ODIN auf dem Rechner anzeigt.</p>
<input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" autofocus aria-label="Nummer">
<button type="submit">Weiter</button>FEHLER</form></body></html>"""


class WebServer:
    def __init__(self, api, ui_ordner: str, port: int = 8765, protokoll=print):
        self.api = api
        self.ui = os.path.abspath(ui_ordner)
        self.port = int(port)
        self.protokoll = protokoll
        self.code = self._neue_nummer()
        self._sitzungen = {}                 # token -> {"ich": person_id oder None, "ip": …, "seit": …}
        self._fehler = {}                    # ip -> {"anzahl": n, "runden": n, "gesperrt_bis": zeit}
        self._fehler_gesamt = 0
        self._pause_bis = 0.0
        self._riegel = threading.Lock()
        self._offen = {}                     # ip -> gleichzeitig offene Verbindungen
        self._server = None
        self._thread = None

    @staticmethod
    def _neue_nummer() -> str:
        return f"{secrets.randbelow(10 ** 6):06d}"

    # ---------------- Schutz vor Durchprobieren ----------------
    def gesperrt(self, ip: str) -> int:
        """Sekunden, die dieses Gerät noch warten muss (0 = darf)."""
        with self._riegel:
            jetzt = time.monotonic()
            e = self._fehler.get(ip)
            bis = max(e["gesperrt_bis"] if e else 0.0, self._pause_bis)
            return int(bis - jetzt) + 1 if bis > jetzt else 0

    def fehlversuch(self, ip: str):
        with self._riegel:
            e = self._fehler.setdefault(ip, {"anzahl": 0, "runden": 0, "gesperrt_bis": 0.0})
            e["anzahl"] += 1
            self._fehler_gesamt += 1
            if e["anzahl"] >= FEHLVERSUCHE_JE_GERAET:
                e["anzahl"] = 0
                e["gesperrt_bis"] = time.monotonic() + min(3600, SPERRE_SEKUNDEN * 2 ** e["runden"])
                e["runden"] += 1
                self.protokoll(f"ODIN im Browser: Gerät {ip} nach falschen Nummern gesperrt")
            if self._fehler_gesamt >= FEHLVERSUCHE_GESAMT:
                # Die Nummer bleibt (sonst könnte jemand die verteilte Nummer beliebig oft entwerten) –
                # stattdessen eine Pause für neue Anmeldungen.
                self._fehler_gesamt = 0
                self._pause_bis = time.monotonic() + PAUSE_GESAMT
                self.protokoll("ODIN im Browser: sehr viele falsche Nummern – kurze Pause für neue Anmeldungen")
            if len(self._fehler) > 2000:                     # nie unbegrenzt wachsen
                self._fehler.clear()

    def anmeldung_gelungen(self, ip: str):
        with self._riegel:
            self._fehler.pop(ip, None)

    # ---------------- Verbindungen begrenzen ----------------
    def verbindung_auf(self, ip: str) -> bool:
        with self._riegel:
            if sum(self._offen.values()) >= MAX_VERBINDUNGEN or self._offen.get(ip, 0) >= MAX_VERBINDUNGEN_JE_GERAET:
                return False
            self._offen[ip] = self._offen.get(ip, 0) + 1
            return True

    def verbindung_zu(self, ip: str):
        with self._riegel:
            n = self._offen.get(ip, 0) - 1
            if n > 0:
                self._offen[ip] = n
            else:
                self._offen.pop(ip, None)

    def erlaubter_host(self, host: str) -> bool:
        """Nur die eigenen Adressen – eine fremde Webseite kann den Server so nicht unter ihrem Namen ansprechen."""
        name = (host or "").strip().lower()
        if name.startswith("["):
            return False
        name, _, port = name.partition(":")
        if port and port != str(self.port):
            return False
        return name in {"localhost", "127.0.0.1", socket.gethostname().lower(), *lokale_adressen()}

    # ---------------- Start / Stopp ----------------
    @property
    def laeuft(self) -> bool:
        return self._server is not None

    def start(self) -> dict:
        if self._server is None:
            server = self

            class Bearbeiter(_Bearbeiter):
                web = server

            class Server(ThreadingHTTPServer):
                def handle_error(self, request, client_address):     # abgebrochene Verbindungen: kein Lärm
                    pass

            self._server = Server(("0.0.0.0", self.port), Bearbeiter)
            self._server.daemon_threads = True
            self._thread = threading.Thread(target=self._server.serve_forever, name="odin-web", daemon=True)
            self._thread.start()
            self.protokoll(f"ODIN im Browser freigegeben auf Port {self.port}")
        return self.status()

    def stopp(self) -> dict:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
            self._sitzungen.clear()
            self.code = self._neue_nummer()               # jede Freigabe hat ihre eigene Nummer
            self._fehler.clear()
            self.protokoll("ODIN im Browser beendet")
        return self.status()

    def status(self) -> dict:
        adressen = [f"http://{ip}:{self.port}" for ip in lokale_adressen()] if self.laeuft else []
        return {"laeuft": self.laeuft, "port": self.port, "code": self.code if self.laeuft else "",
                "adressen": adressen, "lokal": f"http://localhost:{self.port}/?code={self.code}" if self.laeuft else "",
                "geraete": len(self._sitzungen)}

    # ---------------- Sitzungen ----------------
    def neue_sitzung(self, ip: str = "") -> str:
        token = secrets.token_urlsafe(24)
        with self._riegel:
            jetzt = time.time()
            for alt in [t for t, e in self._sitzungen.items() if jetzt - e["seit"] > SITZUNG_SEKUNDEN]:
                del self._sitzungen[alt]
            while len(self._sitzungen) >= MAX_SITZUNGEN:      # älteste Anmeldung weicht
                del self._sitzungen[min(self._sitzungen, key=lambda t: self._sitzungen[t]["seit"])]
            # Neue Sitzung: noch niemand angemeldet – Person und PIN wählt man im Tresor (tresor.py)
            self._sitzungen[token] = {"ich": None, "ip": ip, "seit": jetzt}
        return token

    def sitzung(self, token):
        """Die Sitzung zu diesem Token oder None (abgelaufen, unbekannt)."""
        if not token or not isinstance(token, str):
            return None
        with self._riegel:
            e = self._sitzungen.get(token)
            if e and time.time() - e["seit"] > SITZUNG_SEKUNDEN:
                del self._sitzungen[token]
                return None
            return e

    def sitzung_beenden(self, token):
        with self._riegel:
            self._sitzungen.pop(token, None)

    def gueltig(self, token) -> bool:
        return self.sitzung(token) is not None

    # ---------------- Aufrufe ----------------
    def aufrufen(self, name: str, argumente: list, sitzung: dict):
        """Ein Aufruf aus dem Browser. Wer fragt, steht in der Sitzung auf dem Rechner – nicht in dem, was das Gerät
        mitschickt. Gesetzt wird die Person nur über die Anmeldung mit PIN (tresor_aufruf → tresor.py)."""
        if not isinstance(name, str) or name not in ERLAUBT or not hasattr(self.api, name):
            raise PermissionError("Diese Funktion gibt es im Browser nicht – bitte am Rechner in ODIN.")
        aktion = argumente[0] if argumente else None
        if name.endswith("_aufruf"):
            if not isinstance(aktion, str):
                raise PermissionError("Ungültige Anfrage.")
            if aktion in GESPERRTE_AKTIONEN:
                raise PermissionError("Dateien auswählen und öffnen geht nur am Rechner in ODIN.")
            if aktion in NUR_AM_RECHNER.get(name, ()):
                raise PermissionError("Das geht nur am Rechner in ODIN – im Browser ist nicht sicher, wer am Gerät sitzt.")
            if name == "urlaub_aufruf" and aktion == "antrag_stellen":
                # Im Browser nur für sich selbst und nur mit heutigem Datum – nie im Namen anderer oder rückdatiert
                angaben = argumente[1][0] if len(argumente) > 1 and isinstance(argumente[1], list) and argumente[1] else None
                if isinstance(angaben, dict):
                    angaben.pop("person", None)
                    angaben.pop("eingereicht_am", None)
        ich = sitzung.get("ich")
        # Hell/Dunkel, Gestaltung und Ansicht gelten im Browser nur für das Gerät – der Rechner bleibt, wie er ist
        if name in ("design", "stil") and argumente:
            return argumente[0]
        if name == "oberflaeche" and len(argumente) > 1:
            return argumente[1]
        ANFRAGE.aktiv, ANFRAGE.ich, ANFRAGE.neues_ich, ANFRAGE.ip = True, ich, UNVERAENDERT, sitzung.get("ip") or ""
        try:
            ergebnis = getattr(self.api, name)(*argumente)
            if name == "cockpit_daten":
                # Einkaufspreise und Margen der Teile bleiben am Rechner – im Browser weiß ODIN nicht, wer zusieht
                ergebnis = ohne_einkauf(ergebnis)
            neu = getattr(ANFRAGE, "neues_ich", UNVERAENDERT)
            if neu is not UNVERAENDERT:                     # nur aus tresor.py: nach geprüfter PIN oder beim Abmelden
                with self._riegel:
                    sitzung["ich"] = neu or None
            return ergebnis
        finally:
            ANFRAGE.aktiv, ANFRAGE.ich, ANFRAGE.neues_ich, ANFRAGE.ip = False, None, UNVERAENDERT, ""


class _Bearbeiter(BaseHTTPRequestHandler):
    web: WebServer = None
    server_version = "ODIN"
    sys_version = ""
    timeout = ZEITLIMIT                                   # langsame Verbindungen halten keinen Platz besetzt

    def setup(self):
        self._ip = self.client_address[0]
        self._gezaehlt = self.web.verbindung_auf(self._ip)
        super().setup()
        # Tröpfelnde Verbindungen: nach MAX_LEBENSZEIT ist Schluss, egal wie langsam jemand sendet
        self._frist = threading.Timer(MAX_LEBENSZEIT, self._abbrechen)
        self._frist.daemon = True
        self._frist.start()

    def _abbrechen(self):
        try:
            self.connection.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass

    def finish(self):
        try:
            self._frist.cancel()
            super().finish()
        except OSError:
            pass
        finally:
            if self._gezaehlt:
                self.web.verbindung_zu(self._ip)

    def handle_one_request(self):
        if not self._gezaehlt:                            # zu viele Verbindungen: sofort schließen
            self.close_connection = True
            return
        super().handle_one_request()

    def _host_ok(self) -> bool:
        if self.web.erlaubter_host(self.headers.get("Host")):
            return True
        self._senden(421, b"Unbekannte Adresse", "text/plain; charset=utf-8")
        return False

    def log_message(self, *_):                            # kein Rauschen im Protokoll
        pass

    # ---------------- Hilfen ----------------
    def _cookies(self) -> dict:
        roh = http.cookies.SimpleCookie(self.headers.get("Cookie") or "")
        return {k: v.value for k, v in roh.items()}

    def _senden(self, status: int, inhalt: bytes, typ: str, kopf: dict = None):
        self.send_response(status)
        self.send_header("Content-Type", typ)
        self.send_header("Content-Length", str(len(inhalt)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        for k, v in (kopf or {}).items():
            if isinstance(v, list):
                for einzel in v:
                    self.send_header(k, einzel)
            else:
                self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(inhalt)

    def _json(self, status: int, daten, kopf: dict = None):
        self._senden(status, json.dumps(daten, ensure_ascii=False, default=str).encode("utf-8"),
                     "application/json; charset=utf-8", kopf)

    def _sitzung(self):
        s = self.web.sitzung(self._cookies().get("odin_sitzung"))
        # Die Anmeldung gilt nur für das Gerät, das sich angemeldet hat – ein mitgelesenes Cookie hilft woanders nicht
        return s if s is not None and (not s.get("ip") or s["ip"] == self._ip) else None

    def _angemeldet(self) -> bool:
        return self._sitzung() is not None

    def _abmelden(self):
        """Abmelden im Browser: die Sitzung dieses Geräts endet, danach fragt ODIN wieder nach der Nummer – und dann
        nach Person und PIN."""
        token = self._cookies().get("odin_sitzung")
        if self._sitzung() is None:
            self._json(401, {"__fehler": "Bitte neu anmelden."})
            return
        self.web.sitzung_beenden(token)
        self._json(200, {"ergebnis": True}, {"Set-Cookie": "odin_sitzung=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})

    # ---------------- GET ----------------
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        if not self._host_ok():
            return
        teile = urllib.parse.urlsplit(self.path)
        pfad = urllib.parse.unquote(teile.path)
        frage = urllib.parse.parse_qs(teile.query)
        if pfad in ("/", "/index.html"):
            code = (frage.get("code") or [""])[0].strip()
            if code:
                warten = self.web.gesperrt(self._ip)
                if warten:
                    self._senden(429, ANMELDUNG.replace("FEHLER", '<div class="fehler">Zu viele falsche Versuche. '
                                 f'Bitte in {warten} Sekunden noch einmal.</div>').encode("utf-8"),
                                 "text/html; charset=utf-8", {"Retry-After": str(warten)})
                    return
                if secrets.compare_digest(code.encode("utf-8"), self.web.code.encode("utf-8")):
                    self.web.anmeldung_gelungen(self._ip)
                    token = self.web.neue_sitzung(self._ip)
                    self._senden(303, b"", "text/plain", {"Location": "/", "Set-Cookie":
                                 f"odin_sitzung={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200"})
                    return
                self.web.fehlversuch(self._ip)
                self._senden(401, ANMELDUNG.replace("FEHLER", '<div class="fehler">Die Nummer stimmt nicht.</div>')
                             .encode("utf-8"), "text/html; charset=utf-8")
                return
            if not self._angemeldet():
                self._senden(401, ANMELDUNG.replace("FEHLER", "").encode("utf-8"), "text/html; charset=utf-8")
                return
            with open(os.path.join(self.web.ui, "index.html"), encoding="utf-8") as f:
                html = f.read()
            html = html.replace("<head>", '<head>\n  <script src="web-bruecke.js"></script>', 1)
            self._senden(200, html.encode("utf-8"), "text/html; charset=utf-8")
            return
        if pfad == "/web-bruecke.js":
            self._senden(200, BRUECKE.encode("utf-8"), "text/javascript; charset=utf-8")
            return
        # Dateien der Oberfläche: nur innerhalb von ui/, nur mit Anmeldung (Schriften und Logo auch für die Anmeldung)
        ziel = os.path.abspath(os.path.join(self.web.ui, pfad.lstrip("/")))
        if not ziel.startswith(self.web.ui + os.sep) or not os.path.isfile(ziel):
            self._senden(404, b"Nicht gefunden", "text/plain; charset=utf-8")
            return
        if not self._angemeldet() and not pfad.startswith(("/fonts/", "/img/")):
            self._senden(401, b"Bitte anmelden", "text/plain; charset=utf-8")
            return
        typ = mimetypes.guess_type(ziel)[0] or "application/octet-stream"
        if typ.startswith("text/") or typ in ("application/javascript", "image/svg+xml"):
            typ += "; charset=utf-8"
        with open(ziel, "rb") as f:
            self._senden(200, f.read(), typ)

    # ---------------- POST /api/<name> ----------------
    def do_POST(self):
        if not self._host_ok():
            return
        herkunft = self.headers.get("Origin")
        if herkunft and urllib.parse.urlsplit(herkunft).netloc.lower() != (self.headers.get("Host") or "").lower():
            self._json(403, {"__fehler": "Fremde Herkunft."})
            return
        pfad = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if pfad == "/abmelden":
            self._abmelden()
            return
        if not pfad.startswith("/api/"):
            self._senden(404, b"Nicht gefunden", "text/plain; charset=utf-8")
            return
        sitzung = self._sitzung()
        if sitzung is None:
            self._json(401, {"__fehler": "Bitte neu anmelden."})
            return
        try:
            laenge = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            laenge = -1
        if laenge < 0:
            self._json(400, {"__fehler": "Ungültige Anfrage."})
            return
        if laenge > MAX_ANFRAGE:
            self._json(413, {"__fehler": "Anfrage zu groß."})
            return
        try:
            argumente = json.loads(self.rfile.read(laenge) or b"[]")
            if not isinstance(argumente, list):
                raise ValueError
        except (ValueError, RecursionError, OSError):
            self._json(400, {"__fehler": "Ungültige Anfrage."})
            return
        try:
            ergebnis = self.web.aufrufen(pfad[5:], argumente, sitzung)
        except PermissionError as e:
            self._json(200, {"__fehler": str(e)})
            return
        except Exception as e:                            # noqa: BLE001 – Fehler gehen ins Protokoll, nicht ans Gerät
            self.web.protokoll(f"Web {pfad}: {traceback.format_exc()}")
            self._json(200, {"__fehler": f"Interner Fehler ({type(e).__name__})."})
            return
        self._json(200, {"ergebnis": ergebnis})
