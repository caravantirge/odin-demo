"""
Urlaubsanträge: Mitarbeiter beantragen Urlaub in ODIN, die Genehmiger entscheiden.

ODIN zeigt, was gegen einen Antrag spricht – Gruppen, aus denen nur einer gleichzeitig fehlen darf, Sperrzeiten wie
die Hausmesse, Höchstzahl Abwesender je Bereich, Resturlaub, Überschneidung mit eigenen Anträgen. Entscheiden tun
Menschen, nicht das Programm: Konflikte sperren nichts.

Reihenfolge: Bis zum Stichtag eines Urlaubsjahres (z. B. 31.01.2027 für 2027) eingereichte Anträge sind
„fristgerecht“ und untereinander gleichrangig; spätere sind „nachrangig“ und kommen nach Eingang dran. Was schon
genehmigt ist, hat Vorrang vor allem Offenen. Ohne Stichtag gilt jeder Antrag als fristgerecht.

Gespeichert wird wie bei den Projekten im Ordner „Fahrzeuge“ unter _ODIN/Urlaub/ (per OneDrive auf allen Rechnern):
- regeln.json            Genehmiger, Stichtage, Gruppen, Sperrzeiten, Betriebsurlaub, Bereiche, Anspruch
- antraege/<id>.json     je Antrag eine Datei – zwei Rechner überschreiben sich nie gegenseitig
Vor jeder Änderung wird frisch gelesen, geschrieben wird über eine Zwischendatei. Ohne Ordner „Fahrzeuge“ landet
alles im Ersatzordner der Projekte (nur auf diesem Rechner).

Personen und „ich“ kommen aus den Projekten (personen.json) – es gibt keine zweite Personenliste.
Genehmiger sind Personen-IDs in regeln.json. Solange es keinen gibt, wird Genehmiger, wer die Regeln als Erster
speichert – so lässt sich das ohne Verwalter einrichten. Danach ändern nur Genehmiger die Regeln. Wie bei den
Projekten regelt das nur die Oberfläche: wer die Dateien öffnen kann, kann sie lesen.

Arbeitstage: Montag bis Freitag ohne gesetzliche Feiertage (Niedersachsen) und ohne Betriebsurlaub – der geht jedem
automatisch vom Anspruch ab und zählt im Antrag nicht noch einmal. 24.12. und 31.12. zählen als halbe Tage
(Regel „halbe_tage“; deshalb steht im Jahresplaner „24.12. bis 31.12.27 (5 Tage)“ für sechs Werktage).

Konflikte, Rang und Arbeitstage werden beim Lesen berechnet und nie gespeichert: ändern sich Regeln oder andere
Anträge, stimmen sie sofort.
"""

import datetime as dt
import json
import os
import re
import secrets

from .cockpit.demo import _ostersonntag, feiertage
from .projekte import ProjektFehler

ARTEN = ("Urlaub", "Sonderurlaub", "Überstundenausgleich")
STATUS = ("beantragt", "genehmigt", "abgelehnt", "zurückgezogen")
AKTIV = ("beantragt", "genehmigt")             # zählen für Überschneidungen, Kalender und Konto
VOM_ANSPRUCH = "Urlaub"                         # nur Erholungsurlaub geht vom Jahresanspruch ab
FRISTGERECHT, NACHRANGIG = "fristgerecht", "nachrangig"
STANDARD_HALBE_TAGE = ["12-24", "12-31"]        # Heiligabend und Silvester: halber Arbeitstag
LAENGSTER_ANTRAG = 92                           # Kalendertage am Stück – fängt Tippfehler wie 2072 statt 2027 ab
VERLAUF_MAX = 100
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
DEUTSCHES_DATUM = re.compile(r"(\d{1,2})\.(\d{1,2})\.(\d{2}|\d{4})")
ID_MUSTER = re.compile(r"[0-9a-f]{6,32}")
JAHR_MUSTER = re.compile(r"20\d\d")


class UrlaubFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- kleine Helfer

def _neue_id(laenge: int = 12) -> str:
    """Zufällige ID: zwei Rechner, die gleichzeitig etwas anlegen, vergeben nie dieselbe."""
    return secrets.token_hex(laenge // 2)


def _text(wert, laenge: int) -> str:
    return " ".join(str(wert or "").split())[:laenge]


def _langtext(wert, laenge: int) -> str:
    return str(wert or "").replace("\r\n", "\n").strip()[:laenge]


def _datum(wert, was: str = "Datum") -> dt.date:
    """ISO-Datum (aus der Oberfläche) oder TT.MM.JJJJ (von Hand in einer Datei) → date."""
    if isinstance(wert, dt.datetime):
        return wert.date()
    if isinstance(wert, dt.date):
        return wert
    text = str(wert or "").strip()
    if not text:
        raise UrlaubFehler(f"{was}: bitte ein Datum wählen.")
    try:
        if ISO_DATUM.fullmatch(text[:10]):
            return dt.date.fromisoformat(text[:10])
        m = DEUTSCHES_DATUM.fullmatch(text)
        if m:
            jahr = int(m.group(3))
            return dt.date(jahr + 2000 if jahr < 100 else jahr, int(m.group(2)), int(m.group(1)))
    except ValueError:
        raise UrlaubFehler(f"{was}: dieses Datum gibt es nicht.") from None
    raise UrlaubFehler(f"{was}: bitte ein Datum wählen.")


def _tage_zwischen(von, bis):
    d = dt.date.fromisoformat(von) if isinstance(von, str) else von
    ende = dt.date.fromisoformat(bis) if isinstance(bis, str) else bis
    while d <= ende:
        yield d
        d += dt.timedelta(days=1)


def _zahl(wert) -> str:
    """4.5 → „4,5“, 5.0 → „5“ – für Texte an Menschen."""
    return f"{wert:g}".replace(".", ",")


def _tage_text(n) -> str:
    return f"{_zahl(n)} Tag" if n == 1 else f"{_zahl(n)} Tage"


def _kurz(iso: str) -> str:
    return f"{iso[8:10]}.{iso[5:7]}."


def _spanne(von: str, bis: str) -> str:
    if von == bis:
        return f"{_kurz(von)}{von[:4]}"
    if von[:4] == bis[:4]:
        return f"{_kurz(von)}–{_kurz(bis)}{bis[:4]}"
    return f"{_kurz(von)}{von[:4]}–{_kurz(bis)}{bis[:4]}"


def _tageszahl(wert):
    """Urlaubstage als Zahl (auch „27,5“), auf halbe Tage gerundet; None, wenn keine Zahl."""
    if isinstance(wert, bool):
        return None
    try:
        zahl = float(str(wert).replace(",", ".")) if isinstance(wert, str) else float(wert)
    except (TypeError, ValueError, OverflowError):
        return None
    if zahl != zahl or abs(zahl) > 1000:                 # NaN oder unsinnig groß (z. B. 1e308 von Hand eingetragen)
        return None
    zahl = round(zahl * 2) / 2
    return int(zahl) if zahl.is_integer() else zahl


def _ganzzahl(wert):
    zahl = _tageszahl(wert)
    return zahl if isinstance(zahl, int) else None


def _monat_tag(wert):
    """'12-24', '24.12.' oder '24.12' → '12-24'; None, wenn es den Tag nicht gibt."""
    text = str(wert or "").strip()
    m = re.fullmatch(r"(\d{1,2})-(\d{1,2})", text)
    monat, tag = (int(m.group(1)), int(m.group(2))) if m else (None, None)
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.?", text)
    if m:
        tag, monat = int(m.group(1)), int(m.group(2))
    try:
        dt.date(2000, monat, tag)                  # 2000 war ein Schaltjahr: 29.02. bleibt erlaubt
    except (TypeError, ValueError):
        return None
    return f"{monat:02d}-{tag:02d}"


_FEIERTAGE = {}


def feiertag_namen(jahr: int) -> dict:
    """ISO-Datum → Name der gesetzlichen Feiertage. Welche Tage es sind, bestimmt cockpit.demo.feiertage()."""
    if jahr not in _FEIERTAGE:
        o = _ostersonntag(jahr)
        tag = dt.timedelta(days=1)
        namen = {dt.date(jahr, 1, 1): "Neujahr", o - 2 * tag: "Karfreitag", o + tag: "Ostermontag",
                 dt.date(jahr, 5, 1): "Tag der Arbeit", o + 39 * tag: "Christi Himmelfahrt",
                 o + 50 * tag: "Pfingstmontag", dt.date(jahr, 10, 3): "Tag der Deutschen Einheit",
                 dt.date(jahr, 10, 31): "Reformationstag", dt.date(jahr, 12, 25): "1. Weihnachtstag",
                 dt.date(jahr, 12, 26): "2. Weihnachtstag"}
        _FEIERTAGE[jahr] = {d.isoformat(): namen.get(d, "Feiertag") for d in feiertage(jahr)}
    return _FEIERTAGE[jahr]


def _lies(pfad: str):
    from .speicher import lies_json
    try:
        return lies_json(pfad)
    except FileNotFoundError:
        return None
    except (OSError, ValueError) as e:
        raise UrlaubFehler(f"„{os.path.basename(pfad)}“ ist gerade nicht lesbar ({e}). "
                           "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=1)
        os.replace(tmp, pfad)
    except OSError as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise UrlaubFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


def _antrag_lesbar(a) -> bool:
    """Grundform eines gelesenen Antrags – alles andere (halb synchronisiert, von Hand verdorben) bleibt draußen."""
    if not isinstance(a, dict) or not ID_MUSTER.fullmatch(str(a.get("id") or "")):
        return False
    if a.get("status") not in STATUS or not isinstance(a.get("person"), str) or not a["person"]:
        return False
    if not isinstance(a.get("eingereicht_am"), str) or a.get("art") not in ARTEN:
        return False
    try:
        von, bis = dt.date.fromisoformat(a["von"]), dt.date.fromisoformat(a["bis"])
    except (KeyError, TypeError, ValueError):
        return False
    return von <= bis and (bis - von).days < 400


# ---------------------------------------------------------------- Regeln

def leere_regeln() -> dict:
    return {"version": 1, "genehmiger": [], "stichtage": {}, "gruppen": [], "sperrzeiten": [], "betriebsurlaub": [],
            "bereiche": {"personen": {}, "max_abwesend": {}}, "anspruch": {}, "anspruch_standard": None,
            "halbe_tage": list(STANDARD_HALBE_TAGE),
            # Ohne eigenen Stichtag gilt der 31.10. des Vorjahres (Urlaub 2028: Anträge bis 31.10.2027)
            "stichtag_standard": "10-31",
            # Nicht genommene Tage wandern ins nächste Jahr
            "resttage_uebertragen": True}


def _regeln_normalisieren(roh, streng: bool = False, bekannte=None) -> dict:
    """
    Regeln in feste Form bringen. Beim Lesen (streng=False) fällt Unlesbares still weg, damit eine halb
    synchronisierte oder von Hand bearbeitete Datei ODIN nicht anhält; beim Speichern gibt es eine Meldung.
    `bekannte`: Personen-IDs, die es gibt – andere fallen beim Speichern weg.
    """
    roh = roh if isinstance(roh, dict) else {}

    def pruefe(bedingung, text) -> bool:
        if not bedingung and streng:
            raise UrlaubFehler(text)
        return bool(bedingung)

    def person_ok(pid) -> bool:
        return isinstance(pid, str) and bool(pid) and (bekannte is None or pid in bekannte)

    def datum(wert, was):
        try:
            return _datum(wert, was).isoformat()
        except UrlaubFehler:
            if streng:
                raise
            return None

    def liste(wert):
        return wert if isinstance(wert, list) else []

    def woerterbuch(wert):
        return wert if isinstance(wert, dict) else {}

    r = leere_regeln()
    r["genehmiger"] = [p for p in dict.fromkeys(liste(roh.get("genehmiger"))) if person_ok(p)]

    for jahr, tag in woerterbuch(roh.get("stichtage")).items():
        jahr = str(jahr).strip()
        if not pruefe(JAHR_MUSTER.fullmatch(jahr), f"Stichtag: „{jahr}“ ist kein Jahr."):
            continue
        if tag in (None, ""):
            continue                               # leer heißt: für dieses Jahr kein Stichtag
        d = datum(tag, f"Stichtag {jahr}")
        if d:
            r["stichtage"][jahr] = d

    for n, g in enumerate(liste(roh.get("gruppen")), start=1):
        if not pruefe(isinstance(g, dict), "Gruppe: ungültiger Eintrag."):
            continue
        name = _text(g.get("name"), 60) or f"Gruppe {n}"
        mitglieder = [p for p in dict.fromkeys(liste(g.get("personen"))) if person_ok(p)]
        if not pruefe(len(mitglieder) >= 2, f"Gruppe „{name}“: bitte mindestens zwei Personen auswählen."):
            continue
        hoechstens = _ganzzahl(g.get("max_gleichzeitig", 1))
        if not pruefe(hoechstens is not None and hoechstens >= 1,
                      f"Gruppe „{name}“: „höchstens gleichzeitig“ muss eine ganze Zahl ab 1 sein."):
            continue
        gid = g.get("id") if ID_MUSTER.fullmatch(str(g.get("id") or "")) else _neue_id(8)
        r["gruppen"].append({"id": gid, "name": name, "personen": mitglieder, "max_gleichzeitig": hoechstens})

    for schluessel, standardgrund in (("sperrzeiten", "Sperrzeit"), ("betriebsurlaub", "Betriebsurlaub")):
        was = "Sperrzeit" if schluessel == "sperrzeiten" else "Betriebsurlaub"
        for s in liste(roh.get(schluessel)):
            if not pruefe(isinstance(s, dict), f"{was}: ungültiger Eintrag."):
                continue
            von = datum(s.get("von"), f"{was}: erster Tag")
            bis = datum(s.get("bis") or s.get("von"), f"{was}: letzter Tag")
            if not von or not bis or not pruefe(von <= bis, f"{was}: der letzte Tag liegt vor dem ersten."):
                continue
            eintrag = {"von": von, "bis": bis, "grund": _text(s.get("grund"), 80) or standardgrund}
            if schluessel == "sperrzeiten":
                eintrag["bereiche"] = list(dict.fromkeys(b for b in (_text(x, 40) for x in liste(s.get("bereiche")))
                                                         if b))
            r[schluessel].append(eintrag)

    bereiche = woerterbuch(roh.get("bereiche"))
    # auch flach als {Person: Bereich} – Personen-IDs sind hex, ein Verwechseln mit den beiden Schlüsseln geht nicht
    flach = {k: v for k, v in bereiche.items() if k not in ("personen", "max_abwesend") and isinstance(v, str)}
    for pid, name in {**flach, **woerterbuch(bereiche.get("personen"))}.items():
        name = _text(name, 40)
        if person_ok(pid) and name:
            r["bereiche"]["personen"][pid] = name
    for name, wert in woerterbuch(bereiche.get("max_abwesend")).items():
        name = _text(name, 40)
        if not name or wert in (None, ""):
            continue
        zahl = _ganzzahl(wert)
        if pruefe(zahl is not None and zahl >= 1, f"Bereich {name}: „höchstens abwesend“ muss eine ganze Zahl ab 1 "
                                                  "sein (für „niemand“ eine Sperrzeit anlegen)."):
            r["bereiche"]["max_abwesend"][name] = zahl

    for pid, jahre in woerterbuch(roh.get("anspruch")).items():
        if not person_ok(pid):
            continue
        for jahr, tage in woerterbuch(jahre).items():
            jahr = str(jahr).strip()
            if not pruefe(JAHR_MUSTER.fullmatch(jahr), f"Urlaubsanspruch: „{jahr}“ ist kein Jahr."):
                continue
            if tage in (None, ""):
                continue
            zahl = _tageszahl(tage)
            if pruefe(zahl is not None and 0 <= zahl <= 366, f"Urlaubsanspruch {jahr}: bitte eine Zahl von 0 bis 366."):
                r["anspruch"].setdefault(pid, {})[jahr] = zahl
    if roh.get("anspruch_standard") not in (None, ""):
        zahl = _tageszahl(roh["anspruch_standard"])
        if pruefe(zahl is not None and 0 <= zahl <= 366, "Standard-Urlaubsanspruch: bitte eine Zahl von 0 bis 366."):
            r["anspruch_standard"] = zahl

    if isinstance(roh.get("halbe_tage"), list):
        halbe = []
        for t in roh["halbe_tage"]:
            md = _monat_tag(t)
            if pruefe(md, f"Halber Tag: „{t}“ ist kein Tag (Form 24.12.)."):
                halbe.append(md)
        r["halbe_tage"] = list(dict.fromkeys(halbe))

    if "stichtag_standard" in roh:
        if roh["stichtag_standard"] in (None, ""):
            r["stichtag_standard"] = None
        else:
            md = _monat_tag(roh["stichtag_standard"])
            if pruefe(md, f"Standard-Stichtag: „{roh['stichtag_standard']}“ ist kein Tag (Form 31.10.)."):
                r["stichtag_standard"] = md
    if isinstance(roh.get("resttage_uebertragen"), bool):
        r["resttage_uebertragen"] = roh["resttage_uebertragen"]

    for k in ("geaendert_am", "geaendert_von"):
        if isinstance(roh.get(k), str):
            r[k] = roh[k]
    return r


def stichtag_fuer(regeln: dict, jahr) -> str:
    """Stichtag eines Urlaubsjahres: eigener Eintrag, sonst der Standard-Tag (z. B. 31.10.) im Vorjahr."""
    eigener = (regeln.get("stichtage") or {}).get(str(jahr))
    if eigener:
        return eigener
    md = regeln.get("stichtag_standard")
    return f"{int(jahr) - 1}-{md}" if md else None


class _Kalender:
    """Arbeitstage nach den Regeln: ohne Wochenende, gesetzliche Feiertage und Betriebsurlaub; halbe Tage zählen 0,5."""

    def __init__(self, regeln: dict):
        self.halbe = set(regeln.get("halbe_tage") or [])
        self.betriebsurlaub = {}                   # ISO → Grund
        for b in regeln.get("betriebsurlaub") or []:
            for d in _tage_zwischen(b["von"], b["bis"]):
                self.betriebsurlaub.setdefault(d.isoformat(), b.get("grund") or "Betriebsurlaub")

    @staticmethod
    def feiertag(d: dt.date):
        return feiertag_namen(d.year).get(d.isoformat())

    def gewicht(self, d: dt.date) -> float:
        """Wert eines Tages, Betriebsurlaub nicht berücksichtigt: 0 am Wochenende und Feiertag, sonst 1 oder 0,5."""
        if d.weekday() >= 5 or self.feiertag(d):
            return 0
        return 0.5 if d.strftime("%m-%d") in self.halbe else 1

    def arbeitstage(self, von, bis, halber_tag: bool = False) -> dict:
        """ISO → Wert der Tage, die ein Antrag vom Anspruch braucht."""
        tage = {}
        for d in _tage_zwischen(von, bis):
            wert = self.gewicht(d)
            if wert and d.isoformat() not in self.betriebsurlaub:
                tage[d.isoformat()] = min(wert, 0.5) if halber_tag else wert
        return tage

    def betriebsurlaub_tage(self, jahr) -> float:
        """Arbeitstage im Betriebsurlaub eines Jahres – die gehen jedem vom Anspruch ab."""
        return sum(self.gewicht(dt.date.fromisoformat(t)) for t in self.betriebsurlaub if t.startswith(f"{jahr}-"))


def _vergleiche(a: dict, ia: dict, o: dict, io: dict) -> tuple:
    """Wer zuerst dran ist: (-1 = a, 1 = o, 0 = gleichrangig) und der Grund dafür."""
    ga, go = a["status"] == "genehmigt", o["status"] == "genehmigt"
    if ga != go:
        return (-1 if ga else 1), "bereits genehmigt"
    if ga:
        return 0, "beide genehmigt"
    fa, fo = ia["rang"] == FRISTGERECHT, io["rang"] == FRISTGERECHT
    if fa != fo:
        return (-1 if fa else 1), "fristgerecht eingereicht"
    if fa:
        return 0, "beide fristgerecht"
    if a["eingereicht_am"] != o["eingereicht_am"]:
        return (-1 if a["eingereicht_am"] < o["eingereicht_am"] else 1), "früher eingereicht"
    return 0, "gleichzeitig eingereicht"


class Urlaub:
    """Urlaubsanträge und -regeln. Personen und „ich“ kommen aus `projekte`; `jetzt` (für Tests) liefert die Uhrzeit."""

    def __init__(self, projekte, jetzt=None):
        self._projekte = projekte
        self._jetzt = jetzt or dt.datetime.now

    # ---------------- Orte ----------------
    def _ordner(self) -> str:
        return os.path.join(self._projekte._basis()[0], "Urlaub")

    def _regeln_pfad(self) -> str:
        return os.path.join(self._ordner(), "regeln.json")

    def _antrag_ordner(self) -> str:
        return os.path.join(self._ordner(), "antraege")

    def _antrag_pfad(self, aid: str) -> str:
        if not ID_MUSTER.fullmatch(str(aid or "")):
            raise UrlaubFehler("Unbekannter Antrag.")
        return os.path.join(self._antrag_ordner(), f"{aid}.json")

    def _zeit(self) -> str:
        return self._jetzt().isoformat(timespec="seconds")

    def _heute(self) -> str:
        return self._jetzt().date().isoformat()

    # ---------------- Personen und Rechte ----------------
    def _personen(self) -> dict:
        try:
            return {p["id"]: p for p in self._projekte.personen()}
        except ProjektFehler as e:
            raise UrlaubFehler(str(e)) from None

    def _ich(self, personen: dict) -> str:
        try:
            ich = self._projekte.ich()
        except ProjektFehler as e:
            raise UrlaubFehler(str(e)) from None
        return ich if ich in personen else ""

    def _ich_pflicht(self, personen: dict) -> str:
        ich = self._ich(personen)
        if not ich:
            raise UrlaubFehler("Bitte zuerst auswählen, wer du bist.")
        return ich

    @staticmethod
    def _genehmiger(regeln: dict, personen: dict) -> list:
        """Genehmiger, die es als Person noch gibt."""
        return [g for g in regeln["genehmiger"] if g in personen]

    def ist_genehmiger(self) -> bool:
        personen = self._personen()
        ich = self._ich(personen)
        return bool(ich) and ich in self._genehmiger(self._regeln(), personen)

    # ---------------- Regeln ----------------
    def _regeln(self) -> dict:
        return _regeln_normalisieren(_lies(self._regeln_pfad()))

    def regeln(self) -> dict:
        """Die Regeln; wer kein Genehmiger ist, sieht vom Anspruch nur den eigenen."""
        regeln = self._regeln()
        personen = self._personen()
        ich = self._ich(personen)
        if ich not in self._genehmiger(regeln, personen):
            regeln["anspruch"] = {k: v for k, v in regeln["anspruch"].items() if k == ich}
        return regeln

    def regeln_speichern(self, regeln: dict) -> dict:
        """
        Ersetzt die übergebenen Abschnitte (fehlende bleiben, wie sie sind). Nur Genehmiger – solange es keinen gibt,
        wird Genehmiger, wer zuerst speichert.
        """
        personen = self._personen()
        ich = self._ich_pflicht(personen)
        neu = self._regeln()                        # frisch gelesen: Änderungen anderer Rechner bleiben
        genehmiger = self._genehmiger(neu, personen)
        if genehmiger and ich not in genehmiger:
            raise UrlaubFehler("Die Urlaubsregeln dürfen nur Genehmiger ändern.")
        # Streng geprüft wird nur, was gerade gespeichert wird – eine alte Gruppe mit einer inzwischen gelöschten
        # Person soll das Ändern eines Stichtags nicht blockieren.
        eingabe = {k: v for k, v in (regeln if isinstance(regeln, dict) else {}).items()
                   if k in leere_regeln() and k != "version"}
        geprueft = _regeln_normalisieren(eingabe, streng=True, bekannte=set(personen))
        neu.update({k: geprueft[k] for k in eingabe})
        if not genehmiger:
            neu["genehmiger"] = [ich] + [g for g in neu["genehmiger"] if g != ich and g in personen]
        if not self._genehmiger(neu, personen):
            raise UrlaubFehler("Mindestens ein Genehmiger muss bleiben.")
        neu["geaendert_am"], neu["geaendert_von"] = self._zeit(), ich
        _schreibe(self._regeln_pfad(), neu)
        return self.regeln()

    # ---------------- Anträge lesen ----------------
    def _alle(self) -> tuple:
        """(Anträge, Zahl unlesbarer Dateien). Eine kaputte oder gesperrte Datei hält die Übersicht nicht auf."""
        ordner = self._antrag_ordner()
        try:
            namen = sorted(n for n in os.listdir(ordner) if n.endswith(".json"))
        except OSError:
            return [], 0
        antraege, kaputt = {}, 0
        for n in namen:
            try:
                a = _lies(os.path.join(ordner, n))
            except UrlaubFehler:
                kaputt += 1
                continue
            if not _antrag_lesbar(a):
                kaputt += 1
                continue
            # OneDrive-Konfliktkopie („<id>-PC.json“): dieselbe ID zweimal – die Datei mit dem richtigen Namen gilt
            if a["id"] in antraege and n != f"{a['id']}.json":
                continue
            antraege[a["id"]] = a
        return list(antraege.values()), kaputt

    def _info(self, a: dict, regeln: dict, kal: _Kalender) -> dict:
        """Arbeitstage und Rang eines Antrags – immer frisch aus den aktuellen Regeln."""
        stichtag = stichtag_fuer(regeln, a["von"][:4])
        rang = FRISTGERECHT if not stichtag or a["eingereicht_am"][:10] <= stichtag else NACHRANGIG
        return {"tage": kal.arbeitstage(a["von"], a["bis"], bool(a.get("halber_tag"))), "rang": rang,
                "rang_schluessel": f"{0 if rang == FRISTGERECHT else 1}|{a['eingereicht_am']}", "stichtag": stichtag}

    def _stand(self) -> dict:
        """Alles, was eine Auswertung braucht, einmal gelesen."""
        personen = self._personen()
        regeln = self._regeln()
        ich = self._ich(personen)
        antraege, kaputt = self._alle()
        kal = _Kalender(regeln)
        info = {a["id"]: self._info(a, regeln, kal) for a in antraege}
        je_tag = {}
        for a in antraege:
            if a["status"] in AKTIV:
                for t in info[a["id"]]["tage"]:
                    je_tag.setdefault(t, []).append(a)
        return {"personen": personen, "regeln": regeln, "ich": ich, "antraege": antraege, "kaputt": kaputt,
                "kal": kal, "info": info, "je_tag": je_tag,
                "genehmiger": ich in self._genehmiger(regeln, personen)}

    @staticmethod
    def _bereich(regeln: dict, pid: str):
        return regeln["bereiche"]["personen"].get(pid)

    @staticmethod
    def _anspruch(regeln: dict, pid: str, jahr):
        return regeln["anspruch"].get(pid, {}).get(str(jahr), regeln["anspruch_standard"])

    def _konflikte(self, a: dict, s: dict) -> list:
        """Was gegen einen (offenen oder genehmigten) Antrag spricht. Jeder Konflikt: art, text, tage, mit, vorrang."""
        if a["status"] not in AKTIV:
            return []
        info, regeln, personen = s["info"], s["regeln"], s["personen"]
        ia = info[a["id"]]
        tage = sorted(ia["tage"])
        if not tage:
            return [{"art": "keine_arbeitstage", "text": "Im Zeitraum liegt kein Arbeitstag (Wochenende, Feiertage, "
                                                        "Betriebsurlaub).", "tage": [], "mit": [], "vorrang": None}]

        def name(pid):
            return personen.get(pid, {}).get("name") or "(unbekannt)"

        def andere(t):
            return [o for o in s["je_tag"].get(t, []) if o["id"] != a["id"]]

        def beteiligte(treffer: dict) -> tuple:
            """Details je anderem Antrag samt Vorrang, dazu Gesamtvorrang und Satz dazu."""
            details, vor, gleich = [], [], 0
            for oid, (o, ts) in treffer.items():
                wert, grund = _vergleiche(a, ia, o, info[oid])
                details.append({"antrag": oid, "person": o["person"], "name": name(o["person"]), "status": o["status"],
                                "rang": info[oid]["rang"], "tage": ts, "grund": grund,
                                "vorrang": "dieser" if wert < 0 else "anderer" if wert > 0 else "gleich"})
                if wert > 0:
                    vor.append(f"{name(o['person'])} ({grund})")
                gleich += wert == 0
            if vor:
                return details, "anderer", "Vorrang hat " + ", ".join(vor) + "."
            if gleich:
                return details, "gleich", "Gleichrangig – bitte entscheiden."
            return details, "dieser", "Vorrang hat dieser Antrag."

        konflikte = []
        # Überschneidung mit eigenen Anträgen (z. B. doppelt eingereicht)
        eigene = {}
        for t in tage:
            for o in andere(t):
                if o["person"] == a["person"]:
                    eigene.setdefault(o["id"], (o, []))[1].append(t)
        for oid, (o, ts) in eigene.items():
            konflikte.append({"art": "eigener_antrag", "tage": ts, "mit": [oid], "vorrang": None,
                              "text": f"Überschneidet sich mit einem anderen Antrag derselben Person "
                                      f"({_spanne(o['von'], o['bis'])}, {o['status']})."})

        # Gruppen: aus ihnen dürfen nur so viele gleichzeitig fehlen
        for g in regeln["gruppen"]:
            if a["person"] not in g["personen"]:
                continue
            zuviel, treffer = [], {}
            for t in tage:
                abwesend = {}
                for o in andere(t):
                    if o["person"] != a["person"] and o["person"] in g["personen"]:
                        abwesend.setdefault(o["person"], []).append(o)
                if 1 + len(abwesend) > g["max_gleichzeitig"]:
                    zuviel.append(t)
                    for liste in abwesend.values():
                        for o in liste:
                            treffer.setdefault(o["id"], (o, []))[1].append(t)
            if zuviel:
                details, vorrang, satz = beteiligte(treffer)
                wer = ", ".join(dict.fromkeys(f"{d['name']} ({d['status']})" for d in details))
                konflikte.append({"art": "gruppe", "gruppe": g["name"], "tage": zuviel, "mit": list(treffer),
                                  "vorrang": vorrang, "details": details,
                                  "text": f"Gruppe „{g['name']}“ (höchstens {g['max_gleichzeitig']} gleichzeitig): "
                                          f"auch {wer} – {_tage_text(len(zuviel))}. {satz}"})

        # Sperrzeiten (für alle oder nur bestimmte Bereiche)
        bereich = self._bereich(regeln, a["person"])
        for sp in regeln["sperrzeiten"]:
            if sp["bereiche"] and (bereich or "").casefold() not in {b.casefold() for b in sp["bereiche"]}:
                continue
            ts = [t for t in tage if sp["von"] <= t <= sp["bis"]]
            if ts:
                konflikte.append({"art": "sperrzeit", "tage": ts, "mit": [], "vorrang": None,
                                  "text": f"Sperrzeit „{sp['grund']}“ ({_spanne(sp['von'], sp['bis'])}): "
                                          f"{_tage_text(len(ts))} betroffen."})

        # Höchstzahl Abwesender im Bereich
        hoechstens = next((n for b, n in regeln["bereiche"]["max_abwesend"].items()
                           if bereich and b.casefold() == bereich.casefold()), None)
        if hoechstens:
            zuviel, treffer = [], {}
            for t in tage:
                abwesend = {}
                for o in andere(t):
                    ob = self._bereich(regeln, o["person"])
                    if o["person"] != a["person"] and ob and ob.casefold() == bereich.casefold():
                        abwesend.setdefault(o["person"], []).append(o)
                if 1 + len(abwesend) > hoechstens:
                    zuviel.append(t)
                    for liste in abwesend.values():
                        for o in liste:
                            treffer.setdefault(o["id"], (o, []))[1].append(t)
            if zuviel:
                details, vorrang, satz = beteiligte(treffer)
                konflikte.append({"art": "bereich", "bereich": bereich, "tage": zuviel, "mit": list(treffer),
                                  "vorrang": vorrang, "details": details,
                                  "text": f"{bereich}: mehr als {hoechstens} gleichzeitig abwesend – "
                                          f"{_tage_text(len(zuviel))}. {satz}"})

        # Resturlaub (nur Erholungsurlaub; Betriebsurlaub ist schon abgezogen)
        if a["art"] == VOM_ANSPRUCH:
            for jahr in sorted({t[:4] for t in tage}):
                anspruch = self._anspruch(regeln, a["person"], jahr)
                if anspruch is None:
                    continue
                dieser = sum(w for t, w in ia["tage"].items() if t[:4] == jahr)
                genehmigt, offen = 0, {}
                for o in s["antraege"]:
                    if o["id"] == a["id"] or o["person"] != a["person"] or o["art"] != VOM_ANSPRUCH:
                        continue
                    wert = sum(w for t, w in info[o["id"]]["tage"].items() if t[:4] == jahr)
                    if wert and o["status"] == "genehmigt":
                        genehmigt += wert
                    elif wert and o["status"] == "beantragt":
                        offen[o["id"]] = wert
                rest = anspruch - s["kal"].betriebsurlaub_tage(jahr) - genehmigt
                tage_jahr = [t for t in tage if t[:4] == jahr]
                if a["status"] == "genehmigt" and dieser > rest:
                    konflikte.append({"art": "anspruch", "tage": tage_jahr, "mit": [], "vorrang": None,
                                      "text": f"Urlaubsanspruch {jahr} überschritten: {_tage_text(anspruch)} "
                                              f"Anspruch, genehmigt sind {_zahl(anspruch - rest + dieser)} "
                                              "(mit Betriebsurlaub)."})
                elif a["status"] == "beantragt" and dieser > rest:
                    konflikte.append({"art": "anspruch", "tage": tage_jahr, "mit": [], "vorrang": None,
                                      "text": f"Resturlaub {jahr} reicht nicht: braucht {_tage_text(dieser)}, "
                                              f"übrig {_tage_text(rest)}."})
                elif a["status"] == "beantragt" and dieser + sum(offen.values()) > rest:
                    konflikte.append({"art": "anspruch", "tage": tage_jahr, "mit": list(offen), "vorrang": None,
                                      "text": f"Zusammen mit den anderen offenen Anträgen reicht der Resturlaub {jahr} "
                                              f"nicht: beantragt {_tage_text(dieser + sum(offen.values()))}, übrig "
                                              f"{_tage_text(rest)}."})
        return konflikte

    def _darf_zurueckziehen(self, a: dict, s: dict) -> bool:
        if a["person"] != s["ich"] and not s["genehmiger"]:
            return False
        return a["status"] == "beantragt" or (a["status"] == "genehmigt" and a["von"] > self._heute())

    def _ansicht(self, a: dict, s: dict) -> dict:
        """Antrag für die Oberfläche: gespeicherte Felder plus Name, Arbeitstage, Rang und Konflikte."""
        p = s["personen"].get(a["person"], {})
        info = s["info"][a["id"]]
        aus = {k: a.get(k) for k in ("id", "person", "von", "bis", "art", "halber_tag", "bemerkung", "eingereicht_am",
                                     "eingereicht_von", "status", "entscheidung", "verlauf", "geaendert_am")}
        aus.update(name=p.get("name") or "(unbekannt)", kuerzel=p.get("kuerzel") or "", farbe=p.get("farbe"),
                   bereich=self._bereich(s["regeln"], a["person"]), tage=sorted(info["tage"]),
                   arbeitstage=sum(info["tage"].values()), rang=info["rang"], rang_schluessel=info["rang_schluessel"],
                   stichtag=info["stichtag"], konflikte=self._konflikte(a, s),
                   darf_zurueckziehen=self._darf_zurueckziehen(a, s),
                   darf_entscheiden=s["genehmiger"] and a["status"] != "zurückgezogen")
        return aus

    @staticmethod
    def _sortierung(a: dict) -> tuple:
        """Offene zuerst (fristgerecht vor nachrangig, dann nach Eingang), danach Entschiedene nach Datum."""
        stufe = STATUS.index(a["status"])
        return (stufe, a["rang_schluessel"] if a["status"] == "beantragt" else a["von"], a["id"])

    def antraege(self, jahr=None, nur_offen: bool = False, person: str = None) -> list:
        """
        Anträge, die ins Jahr fallen (None = alle), mit Konflikten, Rang und Arbeitstagen. Genehmiger sehen alle
        (oder die von `person`), alle anderen nur die eigenen.
        """
        s = self._stand()
        ich = self._ich_pflicht(s["personen"])
        if not s["genehmiger"]:
            if person not in (None, "", ich):
                raise UrlaubFehler("Anträge anderer sehen nur Genehmiger.")
            person = ich
        liste = []
        for a in s["antraege"]:
            if jahr not in (None, "") and not (a["von"][:4] <= str(jahr) <= a["bis"][:4]):
                continue
            if nur_offen and a["status"] != "beantragt":
                continue
            if person and a["person"] != person:
                continue
            liste.append(self._ansicht(a, s))
        liste.sort(key=self._sortierung)
        return liste

    def antrag(self, aid: str) -> dict:
        s = self._stand()
        ich = self._ich_pflicht(s["personen"])
        a = next((x for x in s["antraege"] if x["id"] == aid), None)
        if not a:
            raise UrlaubFehler("Diesen Antrag gibt es nicht mehr.")
        if a["person"] != ich and not s["genehmiger"]:
            raise UrlaubFehler("Anträge anderer sehen nur Genehmiger.")
        return self._ansicht(a, s)

    # ---------------- Anträge stellen und ändern ----------------
    def _neuer_antrag(self, eingabe: dict, s: dict) -> dict:
        """Eingabe prüfen und einen (noch nicht gespeicherten) Antrag bauen."""
        e = eingabe if isinstance(eingabe, dict) else {}
        ich = self._ich_pflicht(s["personen"])
        person = e.get("person") or ich
        if not isinstance(person, str):
            raise UrlaubFehler("Diese Person gibt es nicht.")
        if person != ich:
            if not s["genehmiger"]:
                raise UrlaubFehler("Anträge für andere stellen nur Genehmiger.")
            if person not in s["personen"]:
                raise UrlaubFehler("Diese Person gibt es nicht.")
        von = _datum(e.get("von"), "Erster Urlaubstag")
        bis = _datum(e.get("bis") or e.get("von"), "Letzter Urlaubstag")
        if bis < von:
            raise UrlaubFehler("Der letzte Urlaubstag liegt vor dem ersten.")
        if (bis - von).days >= LAENGSTER_ANTRAG:
            raise UrlaubFehler(f"Höchstens {LAENGSTER_ANTRAG} Tage am Stück – bitte die Daten prüfen.")
        art = e.get("art") or "Urlaub"
        if art not in ARTEN:
            raise UrlaubFehler(f"Unbekannte Art „{art}“ (möglich: {', '.join(ARTEN)}).")
        halber = bool(e.get("halber_tag"))
        if halber and von != bis:
            raise UrlaubFehler("Einen halben Tag gibt es nur, wenn erster und letzter Tag gleich sind.")
        tage = s["kal"].arbeitstage(von, bis, halber)
        if not tage:
            ganz_betriebsurlaub = any(d.isoformat() in s["kal"].betriebsurlaub for d in _tage_zwischen(von, bis)
                                      if s["kal"].gewicht(d))
            if ganz_betriebsurlaub:
                raise UrlaubFehler("Der Zeitraum liegt im Betriebsurlaub – dafür ist kein Antrag nötig.")
            raise UrlaubFehler("Im gewählten Zeitraum liegt kein Arbeitstag (nur Wochenende oder Feiertage).")
        eingereicht = self._zeit()
        if e.get("eingereicht_am") not in (None, ""):
            # nur Genehmiger: ein Antrag auf Papier zählt mit dem Tag, an dem er kam
            if not s["genehmiger"]:
                raise UrlaubFehler("Das Eingangsdatum setzen nur Genehmiger.")
            text = str(e["eingereicht_am"]).strip()
            try:
                eingereicht = dt.datetime.fromisoformat(text).isoformat(timespec="seconds")
            except ValueError:
                eingereicht = f"{_datum(text, 'Eingegangen am').isoformat()}T00:00:00"
            if eingereicht[:10] > self._heute():
                raise UrlaubFehler("Das Eingangsdatum liegt in der Zukunft.")
        jetzt = self._zeit()
        wer = "hat den Antrag gestellt" if person == ich else \
            f"hat den Antrag für {s['personen'][person].get('name', 'jemanden')} gestellt"
        return {"version": 1, "id": _neue_id(12), "person": person, "von": von.isoformat(), "bis": bis.isoformat(),
                "art": art, "halber_tag": halber, "bemerkung": _langtext(e.get("bemerkung"), 1000),
                "eingereicht_am": eingereicht, "eingereicht_von": ich, "status": "beantragt", "entscheidung": None,
                "geaendert_am": jetzt, "verlauf": [{"am": jetzt, "von": ich, "text": wer}]}

    def _mit_kandidat(self, s: dict, a: dict) -> dict:
        """Stand, als wäre der Antrag schon gespeichert – für Prüfung und Rückgabe."""
        s = dict(s)
        s["antraege"] = [x for x in s["antraege"] if x["id"] != a["id"]] + [a]
        s["info"] = {**s["info"], a["id"]: self._info(a, s["regeln"], s["kal"])}
        je_tag = {t: [x for x in liste if x["id"] != a["id"]] for t, liste in s["je_tag"].items()}
        if a["status"] in AKTIV:
            for t in s["info"][a["id"]]["tage"]:
                je_tag.setdefault(t, []).append(a)
        s["je_tag"] = je_tag
        return s

    def antrag_pruefen(self, eingabe: dict) -> dict:
        """Wie antrag_stellen, speichert aber nichts: zeigt Arbeitstage und Konflikte vor dem Absenden."""
        s = self._stand()
        a = self._neuer_antrag(eingabe, s)
        return self._ansicht(a, self._mit_kandidat(s, a))

    def antrag_stellen(self, eingabe: dict) -> dict:
        """Neuer Antrag für mich – Genehmiger auch für andere (`person`) und mit Eingangsdatum (`eingereicht_am`)."""
        s = self._stand()
        a = self._neuer_antrag(eingabe, s)
        doppelt = next((o for o in s["antraege"] if o["status"] in AKTIV and o["person"] == a["person"]
                        and (o["von"], o["bis"], o["art"], bool(o.get("halber_tag"))) ==
                        (a["von"], a["bis"], a["art"], a["halber_tag"])), None)
        if doppelt:
            raise UrlaubFehler(f"Diesen Antrag gibt es schon ({_spanne(a['von'], a['bis'])}, {doppelt['status']}).")
        _schreibe(self._antrag_pfad(a["id"]), a)
        return self._ansicht(a, self._mit_kandidat(s, a))

    def _aendere(self, aid: str, aenderung) -> dict:
        """Antrag frisch lesen, ändern, Verlauf ergänzen, speichern – und mit Konflikten zurückgeben."""
        pfad = self._antrag_pfad(aid)
        s = self._stand()
        self._ich_pflicht(s["personen"])
        a = _lies(pfad)
        if not _antrag_lesbar(a):
            raise UrlaubFehler("Diesen Antrag gibt es nicht mehr.")
        text = aenderung(a, s)
        if text:
            a["geaendert_am"] = self._zeit()
            a["verlauf"] = ((a.get("verlauf") or []) + [{"am": a["geaendert_am"], "von": s["ich"], "text": text}])[
                -VERLAUF_MAX:]
            _schreibe(pfad, a)
        return self._ansicht(a, self._mit_kandidat(s, a))

    def antrag_zurueckziehen(self, aid: str) -> dict:
        """Eigene Anträge (Genehmiger: alle). Genehmigte nur, solange der Urlaub noch nicht begonnen hat."""
        def zurueck(a, s):
            if a["person"] != s["ich"] and not s["genehmiger"]:
                raise UrlaubFehler("Nur eigene Anträge lassen sich zurückziehen.")
            if a["status"] == "zurückgezogen":
                raise UrlaubFehler("Dieser Antrag ist schon zurückgezogen.")
            if a["status"] == "abgelehnt":
                raise UrlaubFehler("Dieser Antrag ist abgelehnt – zurückziehen ist nicht nötig.")
            if a["status"] == "genehmigt" and a["von"] <= self._heute():
                raise UrlaubFehler("Der Urlaub hat schon begonnen – zurückziehen geht nur vorher. "
                                   "Bitte mit einem Genehmiger sprechen.")
            war = a["status"]
            a["status"] = "zurückgezogen"
            return "hat den genehmigten Antrag zurückgezogen" if war == "genehmigt" else "hat den Antrag zurückgezogen"
        return self._aendere(aid, zurueck)

    def entscheiden(self, aid: str, genehmigt, kommentar: str = "") -> dict:
        """Genehmigen oder ablehnen (nur Genehmiger). Eine Entscheidung lässt sich ändern, außer nach Zurückziehen."""
        if isinstance(genehmigt, str):
            genehmigt = genehmigt.strip().lower() in ("true", "ja", "1", "genehmigt", "genehmigen")
        neu = "genehmigt" if genehmigt else "abgelehnt"
        kommentar = _langtext(kommentar, 1000)

        def entscheide(a, s):
            if not s["genehmiger"]:
                raise UrlaubFehler("Entscheiden dürfen nur Genehmiger.")
            if a["status"] == "zurückgezogen":
                raise UrlaubFehler("Dieser Antrag wurde zurückgezogen.")
            if a["status"] == neu and (a.get("entscheidung") or {}).get("kommentar", "") == kommentar:
                return ""
            a["status"] = neu
            a["entscheidung"] = {"von": s["ich"], "am": self._zeit(), "kommentar": kommentar}
            return ("hat genehmigt" if genehmigt else "hat abgelehnt") + (f": {kommentar}" if kommentar else "")
        return self._aendere(aid, entscheide)

    # ---------------- Übersichten ----------------
    def _konto(self, s: dict, pid: str, jahr, _tiefe: int = 0) -> dict:
        jahr = str(jahr)
        summen = {"genehmigt": 0, "beantragt": 0}
        andere = {"Sonderurlaub": 0, "Überstundenausgleich": 0}
        for a in s["antraege"]:
            if a["person"] != pid or a["status"] not in AKTIV:
                continue
            wert = sum(w for t, w in s["info"][a["id"]]["tage"].items() if t[:4] == jahr)
            if a["art"] == VOM_ANSPRUCH:
                summen[a["status"]] += wert
            elif a["status"] == "genehmigt":
                andere[a["art"]] += wert
        anspruch = self._anspruch(s["regeln"], pid, jahr)
        # Resttage aus dem Vorjahr – nur wenn dort für die Person ein Anspruch eingetragen ist (sonst würden aus dem
        # Standard-Anspruch Jahre vor ODIN „unverbrauchte“ Tage erfinden); höchstens drei Jahre zurück
        uebertrag = 0
        if s["regeln"].get("resttage_uebertragen", True) and _tiefe < 3 and anspruch is not None \
                and str(int(jahr) - 1) in s["regeln"]["anspruch"].get(pid, {}):
            vorjahr = self._konto(s, pid, int(jahr) - 1, _tiefe + 1)
            uebertrag = max(0, vorjahr["rest"] or 0)
        betriebsurlaub = s["kal"].betriebsurlaub_tage(jahr)
        rest = None if anspruch is None else anspruch + uebertrag - betriebsurlaub - summen["genehmigt"]
        p = s["personen"].get(pid, {})
        return {"person": pid, "name": p.get("name") or "(unbekannt)", "jahr": int(jahr),
                "bereich": self._bereich(s["regeln"], pid), "anspruch": anspruch, "uebertrag": uebertrag,
                "betriebsurlaub": betriebsurlaub,
                "genommen": summen["genehmigt"], "beantragt": summen["beantragt"], "rest": rest,
                "rest_nach_antraegen": None if rest is None else rest - summen["beantragt"],
                "sonderurlaub": andere["Sonderurlaub"], "ueberstundenausgleich": andere["Überstundenausgleich"]}

    def konto(self, jahr, person: str = None) -> dict:
        """Urlaubskonto: Anspruch, Betriebsurlaub, genommen (genehmigt), beantragt (offen), Rest."""
        s = self._stand()
        ich = self._ich_pflicht(s["personen"])
        person = person or ich
        if person != ich and not s["genehmiger"]:
            raise UrlaubFehler("Das Urlaubskonto anderer sehen nur Genehmiger.")
        if person not in s["personen"]:
            raise UrlaubFehler("Diese Person gibt es nicht.")
        return self._konto(s, person, jahr)

    def konten(self, jahr) -> list:
        """Alle Urlaubskonten eines Jahres (nur Genehmiger)."""
        s = self._stand()
        self._ich_pflicht(s["personen"])
        if not s["genehmiger"]:
            raise UrlaubFehler("Die Urlaubskonten aller sehen nur Genehmiger.")
        aktive = [p for p in s["personen"].values() if p.get("aktiv", True)]
        return sorted((self._konto(s, p["id"], jahr) for p in aktive),
                      key=lambda k: ((k["bereich"] or "~").casefold(), k["name"].casefold()))

    def kalender(self, jahr) -> dict:
        """
        Jahresraster: je Tag Wochenende, Feiertag, Betriebsurlaub, Sperrzeiten; je Person die Tage mit offenen oder
        genehmigten Anträgen ({status, antrag_id, halber_tag}, Art nur bei eigenen oder für Genehmiger).
        """
        s = self._stand()
        ich = self._ich_pflicht(s["personen"])
        jahr = int(jahr)
        regeln, kal = s["regeln"], s["kal"]
        tage = []
        for d in _tage_zwischen(dt.date(jahr, 1, 1), dt.date(jahr, 12, 31)):
            iso = d.isoformat()
            tage.append({"datum": iso, "wochentag": d.weekday(), "kw": d.isocalendar()[1],
                         "wochenende": d.weekday() >= 5, "feiertag": kal.feiertag(d),
                         "halber_tag": d.strftime("%m-%d") in kal.halbe,
                         "betriebsurlaub": kal.betriebsurlaub.get(iso),
                         "sperrzeiten": [{"grund": sp["grund"], "bereiche": sp["bereiche"]}
                                         for sp in regeln["sperrzeiten"] if sp["von"] <= iso <= sp["bis"]]})
            tage[-1]["sperrzeit"] = ", ".join(sp["grund"] for sp in tage[-1]["sperrzeiten"]) or None
        personen = []
        for p in s["personen"].values():
            if not p.get("aktiv", True):
                continue
            eintraege = {}
            for a in s["antraege"]:
                if a["person"] != p["id"] or a["status"] not in AKTIV:
                    continue
                sichtbar = s["genehmiger"] or a["person"] == ich
                for t in s["info"][a["id"]]["tage"]:
                    if not t.startswith(f"{jahr}-"):
                        continue
                    if t in eintraege and eintraege[t]["status"] == "genehmigt":
                        continue                    # genehmigt schlägt offen, wenn sich zwei Anträge überschneiden
                    eintraege[t] = {"status": a["status"], "antrag_id": a["id"],
                                    "halber_tag": bool(a.get("halber_tag"))}
                    if sichtbar:
                        eintraege[t]["art"] = a["art"]
            personen.append({"id": p["id"], "name": p.get("name", ""), "kuerzel": p.get("kuerzel", ""),
                             "farbe": p.get("farbe"), "bereich": self._bereich(regeln, p["id"]), "tage": eintraege})
        personen.sort(key=lambda x: ((x["bereich"] or "~").casefold(), x["name"].casefold()))
        return {"jahr": jahr, "ich": ich, "ist_genehmiger": s["genehmiger"], "tage": tage, "personen": personen,
                "stichtag": stichtag_fuer(regeln, jahr), "sperrzeiten": regeln["sperrzeiten"],
                "betriebsurlaub": regeln["betriebsurlaub"]}

    def abwesenheiten(self, jahr, mit_feiertagen: bool = True) -> list:
        """
        Für „wer fehlt“ in „Heute & Woche“ im Cockpit: genehmigte Tage als Zeilen {mitarbeiter, person, datum, art, bereich,
        halber_tag}, dazu Betriebsurlaub (und Feiertage) für jede aktive Person. Braucht kein „ich“.
        """
        s = self._stand()
        jahr = str(jahr)
        regeln, kal = s["regeln"], s["kal"]
        aktive = [p for p in s["personen"].values() if p.get("aktiv", True)]
        zeilen = {}
        for a in s["antraege"]:
            p = s["personen"].get(a["person"])
            if a["status"] != "genehmigt" or not p:
                continue
            for t in sorted(s["info"][a["id"]]["tage"]):
                if t.startswith(f"{jahr}-"):
                    zeilen.setdefault((p["name"], t), {
                        "mitarbeiter": p["name"], "person": p["id"], "datum": t, "art": a["art"],
                        "bereich": self._bereich(regeln, p["id"]), "halber_tag": bool(a.get("halber_tag"))})
        sonder = {t: "Betriebsurlaub" for t in kal.betriebsurlaub if t.startswith(f"{jahr}-")
                  and kal.gewicht(dt.date.fromisoformat(t))}
        if mit_feiertagen:
            sonder.update({t: "Feiertag" for t, n in feiertag_namen(int(jahr)).items()
                           if dt.date.fromisoformat(t).weekday() < 5})
        for t, art in sonder.items():
            for p in aktive:
                zeilen.setdefault((p["name"], t), {"mitarbeiter": p["name"], "person": p["id"], "datum": t, "art": art,
                                                   "bereich": self._bereich(regeln, p["id"]), "halber_tag": False})
        return sorted(zeilen.values(), key=lambda z: (z["datum"], z["mitarbeiter"]))

    def start(self, jahr=None) -> dict:
        """Alles für den Einstieg der Oberfläche: wer ich bin, Rechte, Personen, Regeln, offene Anträge."""
        basis, lokal = self._projekte._basis()
        s = self._stand()
        ich = s["ich"]
        offen = [a for a in s["antraege"] if a["status"] == "beantragt" and (s["genehmiger"] or a["person"] == ich)]
        regeln = s["regeln"]
        if not s["genehmiger"]:
            regeln = {**regeln, "anspruch": {k: v for k, v in regeln["anspruch"].items() if k == ich}}
        return {"ich": ich, "ist_genehmiger": s["genehmiger"],
                "genehmiger_fehlt": not self._genehmiger(s["regeln"], s["personen"]),
                "personen": list(s["personen"].values()), "regeln": regeln, "arten": list(ARTEN),
                "jahr": int(jahr) if jahr else self._jetzt().year, "offen": len(offen),
                "unlesbare_dateien": s["kaputt"], "speicher": {"lokal": lokal, "ordner": os.path.join(basis, "Urlaub")}}

    # ---------------- Vorschlag aus dem Excel-Urlaubsplaner ----------------
    def planer_vorschlag(self, pfad: str) -> dict:
        """
        Regelvorschlag aus dem Jahresplaner (Gruppen, Hausmesse, Betriebsurlaub). Namen aus dem Plan werden Personen
        zugeordnet, wo das eindeutig geht. Nur ein Vorschlag – gespeichert wird erst mit regeln_speichern().
        """
        from .cockpit.urlaub import regel_vorschlag_aus_planer
        vorschlag = regel_vorschlag_aus_planer(pfad)
        personen = list(self._personen().values())
        for g in vorschlag.get("gruppen", []):
            g["personen"], g["unklar"] = [], []
            for n in g.get("namen", []):
                treffer = _person_zu_name(n, personen)
                if treffer:
                    g["personen"].append(treffer)
                else:
                    g["unklar"].append(n)
        return vorschlag


def _person_zu_name(name: str, personen: list):
    """„M. Albers“, „Albers“ oder „Lars“ → Personen-ID, wenn genau eine Person passt."""
    teile = [t.casefold() for t in re.split(r"[\s.]+", name or "") if t]
    if not teile:
        return None
    nachname, initialen = teile[-1], [t[0] for t in teile[:-1]]
    treffer = []
    for p in personen:
        woerter = [w.casefold() for w in re.split(r"[\s\-]+", p.get("name") or "") if w]
        if nachname not in woerter:
            continue
        andere = [w for w in woerter if w != nachname]
        if all(any(w.startswith(i) for w in andere) for i in initialen):
            treffer.append(p["id"])
    return treffer[0] if len(treffer) == 1 else None
