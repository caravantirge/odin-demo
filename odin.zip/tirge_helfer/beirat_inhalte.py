"""
Inhalte für „Beirat & Coaching“ – mitgeliefert, versioniert, für alle im Team lesbar.

Der Beirat ist ein gedachter Kreis von Vollprofis: Was würden sie an unserer Stelle tun? Alles hier sind sinngemäße
Zusammenfassungen öffentlich bekannter Ideen dieser Personen (aus Büchern, Vorträgen, Aktionärsbriefen), in eigenen
Worten und übertragen auf den Caravan- und Wohnmobilhandel bei Muster. Keine Aussagen der Personen selbst, keine
Zusammenarbeit, keine Bilder. Wo ein kurzer, allgemein bekannter Leitsatz steht, ist er als solcher gekennzeichnet
und sinngemäß übersetzt.

Aufbau:
- THEMEN       Gruppen der Module (Verkaufstraining, Verhandeln, Entscheiden, Struktur, Service, Führung)
- MITGLIEDER   Steckbrief, Kernideen, Übertragung auf Muster
- MODULE       Coaching-Karten: Kernidee, Schritte, Praxisbeispiel, typische Fehler, Formulierungen
- SITUATIONEN  „Frag den Beirat“: typische Lagen mit 2–3 Perspektiven, nächsten Schritten und Formulierungen
- GEDANKEN     Impuls des Tages (rotiert nach Datum)
- FRAGEN       Tagesfragen zu den Modulen (die richtige Antwort steht vorn)

Kennungen nur a–z und 0–9 (Module 6–32 Zeichen), damit sie in Adressen und Verweisen sicher sind. Wer Inhalte
ändert, erhöht VERSION. Wird ein Modul umbenannt, kommt die alte Kennung in MODUL_ALIAS – gespeicherte Verweise
(Einarbeitungspläne, Tagesfragen von früher, Lesezeichen) führen dann weiter zum richtigen Modul.

Verbindliche Hausregeln (hausregeln.py) gehen jedem Coaching-Rat vor: Nichts hier darf ihnen widersprechen
(tests/test_hausregeln.py prüft das). Ein Modul kann mit „hausregeln“ auf die Regeln verweisen, die es berührt.
"""

VERSION = 2
STAND = "2026-11"

# Alte Modul-Kennung → neue (Version 2: „Probefahrt und Vorführung“ wurde wegen Hausregel VERKAUF-001 zu
# „Besichtigung und Vorführung am Fahrzeug“)
MODUL_ALIAS = {"probefahrt": "besichtigung"}

HINWEIS = ("Die Inhalte sind sinngemäße Zusammenfassungen öffentlich bekannter Ideen dieser Personen, übertragen auf "
           "Muster – keine Aussagen der Personen selbst und keine Zusammenarbeit mit ihnen.")

THEMEN = [
    {"id": "verkauf", "titel": "Verkaufstraining",
     "text": "Vom ersten Hallo über Besichtigung und Preisgespräch bis zum Abschluss und Nachfassen."},
    {"id": "verhandeln", "titel": "Verhandeln",
     "text": "Mit Kunden, Herstellern, Bank und Lieferanten – ruhig, klar und fair."},
    {"id": "entscheiden", "titel": "Entscheiden",
     "text": "Gute Entscheidungen unter Unsicherheit: Ankauf, Preis, Investition, Personal."},
    {"id": "struktur", "titel": "Struktur & Selbstorganisation",
     "text": "Woche planen, Kopf frei bekommen, saubere Übergaben im Team."},
    {"id": "service", "titel": "Kundenservice & Reklamation",
     "text": "Übergabe als Erlebnis, Reklamationen als Chance für Vertrauen."},
    {"id": "fuehrung", "titel": "Führung",
     "text": "Für Teamleiter: klare Erwartungen, Wochenrunde, Sinn und Richtung."},
]

# ---------------------------------------------------------------- Beiratsmitglieder
# leitsatz: kurzer, allgemein bekannter Leitsatz – sinngemäß übersetzt und in der Oberfläche als Zitat gekennzeichnet.

MITGLIEDER = [
    {
        "id": "buffett", "name": "Warren Buffett", "kuerzel": "WB",
        "bekannt": "Investor, führte jahrzehntelang Berkshire Hathaway",
        "fuer": "Entscheiden, Geduld, Ruf, Wert statt Preis",
        "steckbrief": "US-amerikanischer Investor, der Berkshire Hathaway über Jahrzehnte zu einer der größten "
                      "Firmengruppen der Welt gemacht hat. Bekannt für langfristiges Denken, einfache Regeln und seine "
                      "jährlichen Briefe an die Aktionäre, in denen er Fehler offen zugibt.",
        "kernideen": [
            ("Wert statt Preis", "Der Preis ist das, was jemand zahlt; der Wert ist das, was er dafür bekommt. Wer nur "
                                 "über den Preis redet, hat den Wert noch nicht gezeigt."),
            ("Kompetenzkreis", "Entscheide dort, wo du dich wirklich auskennst. Wichtig ist nicht, wie groß dein Kreis "
                               "ist, sondern dass du seine Grenze kennst."),
            ("Sicherheitsabstand", "Kauf nur mit Puffer: Wenn deine Rechnung nur aufgeht, wenn alles klappt, ist sie zu "
                                   "knapp."),
            ("Ruf ist alles", "Ein guter Ruf entsteht über Jahre und ist mit einer schlechten Entscheidung weg. Lieber "
                              "ein Geschäft verlieren als den Ruf."),
            ("Geduld", "Nicht jede Gelegenheit muss genutzt werden. Wer warten kann, bis ein Angebot wirklich passt, "
                       "macht weniger, aber bessere Geschäfte."),
        ],
        "leitsatz": "Preis ist, was du zahlst. Wert ist, was du bekommst.",
        "muster": [
            "Im Preisgespräch zuerst den Wert zeigen (Ausstattung, Übergabe, Werkstatt, Erreichbarkeit nach dem Kauf) – "
            "erst dann über Zahlen reden.",
            "Gebrauchtankauf nur mit Puffer: Ankaufspreis so, dass Aufbereitung, Standzeit und eine Überraschung in der "
            "Werkstatt noch hineinpassen.",
            "Lieber ein Fahrzeug nicht verkaufen, als dem Kunden etwas zuzusagen, das wir nicht halten können.",
            "Bei Modellen und Technik, die wir nicht kennen, ehrlich sein und nachfragen statt raten.",
        ],
    },
    {
        "id": "munger", "name": "Charlie Munger", "kuerzel": "CM",
        "bekannt": "Buffetts langjähriger Partner bei Berkshire Hathaway (1924–2023)",
        "fuer": "Umkehrdenken, Denkmodelle, Denkfehler vermeiden",
        "steckbrief": "Jahrzehntelang Buffetts Partner und Vizechef bei Berkshire Hathaway. Bekannt für trockenen "
                      "Humor, breites Wissen aus vielen Fächern und seine Liste typischer Denkfehler, mit denen sich "
                      "Menschen selbst austricksen.",
        "kernideen": [
            ("Umkehrdenken", "Frag nicht nur „Wie gelingt das?“, sondern „Wie würde es garantiert schiefgehen?“ – und "
                             "vermeide genau das."),
            ("Denkmodelle", "Schau mit mehreren Brillen auf ein Problem: Zahlen, Psychologie, Anreize, Zeit. Wer nur "
                            "einen Hammer hat, sieht überall Nägel."),
            ("Anreize", "Zeig mir den Anreiz, und ich sage dir das Verhalten. Wer sich wundert, warum etwas passiert, "
                        "sollte zuerst fragen, wofür jemand belohnt wird."),
            ("Denkfehler kennen", "Wir halten an Verlusten fest, glauben, was wir glauben wollen, und folgen der Masse. "
                                  "Wer diese Fallen kennt, tappt seltener hinein."),
        ],
        "leitsatz": "Umkehren, immer umkehren.",
        "muster": [
            "Vor einem Ankauf fragen: Was müsste passieren, damit dieses Fahrzeug ein Langsteher wird? Steht davon "
            "schon etwas fest?",
            "Bei Langstehern nicht am Einkaufspreis festhalten – entscheidend ist, was das Fahrzeug ab heute bringt "
            "und kostet.",
            "Provisions- und Bonusregeln so bauen, dass sie das gewünschte Verhalten belohnen (zufriedene Kunden, "
            "gesunder Bestand) – nicht nur Stückzahl.",
        ],
    },
    {
        "id": "hormozi", "name": "Alex Hormozi", "kuerzel": "AH",
        "bekannt": "US-Unternehmer, Autor von „$100M Offers“ und „$100M Leads“",
        "fuer": "Wert des Angebots, Value Equation, Grand Slam Offer",
        "steckbrief": "US-amerikanischer Unternehmer und Investor. Bekannt für seine Bücher und Videos darüber, wie man "
                      "Angebote so gut macht, dass der Preis in den Hintergrund tritt, und wie man verlässlich neue "
                      "Anfragen gewinnt.",
        "kernideen": [
            ("Value Equation", "Der Wert eines Angebots steigt mit dem Traumergebnis des Kunden und mit seiner "
                               "Sicherheit, dass es klappt. Er sinkt mit der Wartezeit und mit Aufwand und Mühe für den "
                               "Kunden."),
            ("Grand Slam Offer", "Statt billiger zu werden, das Angebot besser machen: Probleme des Kunden vorher "
                                 "sammeln und jedes mit einer Lösung beantworten – gebündelt zu einem Paket, das man "
                                 "schwer vergleichen kann."),
            ("Risiko abnehmen", "Je mehr Risiko du dem Kunden abnimmst (Zusagen, Garantien, klare Abläufe), desto "
                                "leichter sagt er Ja."),
            ("Menge und Wiederholung", "Mehr Kontakte, mehr Angebote, mehr Nachfassen – das meiste Geschäft "
                                       "entsteht durch Ausdauer, nicht durch den einen perfekten Satz."),
        ],
        "leitsatz": "",
        "muster": [
            "Ein Fahrzeug nicht nur als Fahrzeug verkaufen, sondern als Paket: Übergabe mit Einweisung, erster Check, "
            "passendes Zubehör montiert, Ansprechpartner für die erste Reise.",
            "Wartezeit und Mühe für den Kunden senken: Zulassung, Inzahlungnahme und Finanzierung aus einer Hand.",
            "Typische Sorgen (Gas, Strom, Rangieren, Winter) vorher kennen und im Gespräch beantworten, bevor der "
            "Kunde fragt.",
        ],
    },
    {
        "id": "kreuter", "name": "Dirk Kreuter", "kuerzel": "DK",
        "bekannt": "deutscher Verkaufstrainer, Redner und Buchautor",
        "fuer": "Verkaufen, Akquise, Einwandbehandlung, Abschluss, Nachfassen",
        "steckbrief": "Deutscher Verkaufstrainer, der seit vielen Jahren Vertriebsteams schult. Schwerpunkte: neue "
                      "Kunden aktiv gewinnen, am Telefon und im Gespräch klar führen, Einwände behandeln und "
                      "konsequent nach dem Auftrag fragen.",
        "kernideen": [
            ("Aktiv verkaufen", "Verkaufen ist ein Beruf mit Handwerk. Wer wartet, bis Kunden kommen, überlässt das "
                                "Geschäft anderen."),
            ("Wer fragt, der führt", "Gute Verkäufer reden weniger und fragen mehr. Mit Fragen findest du heraus, "
                                     "was der Kunde wirklich will – und lenkst das Gespräch."),
            ("Einwand ist kein Nein", "Ein Einwand zeigt Interesse und eine offene Frage. Erst verstehen, dann "
                                      "beantworten, dann zurück zum Abschluss."),
            ("Nach dem Auftrag fragen", "Viele Gespräche enden ohne Abschluss, weil niemand gefragt hat. Abschluss ist "
                                        "der natürliche nächste Schritt, kein Überfall."),
            ("Nachfassen", "Die meisten Abschlüsse kommen nach mehreren Kontakten. Wer nach dem ersten Angebot "
                           "aufhört, verschenkt Geschäft."),
        ],
        "leitsatz": "",
        "muster": [
            "Jede Anfrage bekommt einen nächsten Termin – nicht „melden Sie sich“, sondern ein konkretes Datum.",
            "Am Ende der Besichtigung nach der Entscheidung fragen: „Wenn wir das so machen – sollen wir den "
            "Kaufvertrag vorbereiten?“",
            "Nach jedem Angebot zwei, drei feste Nachfass-Termine in den Kalender legen.",
        ],
    },
    {
        "id": "wickman", "name": "Gino Wickman", "kuerzel": "GW",
        "bekannt": "Autor von „Traction“, Begründer des Entrepreneurial Operating System (EOS)",
        "fuer": "Struktur, Rollen, Scorecard, Wochenrunde, Quartalsziele",
        "steckbrief": "US-amerikanischer Unternehmer und Autor. Sein Betriebssystem für kleine und mittlere Firmen "
                      "(EOS) gibt einfache Werkzeuge: klares Organigramm nach Verantwortung, wenige Wochenzahlen, "
                      "Quartalsziele und eine feste Wochenrunde, in der Probleme gelöst statt nur besprochen werden.",
        "kernideen": [
            ("Verantwortung klären", "Jede Aufgabe hat genau einen Namen. Ein Organigramm nach Verantwortung statt "
                                     "nach Titeln zeigt, wer wofür geradesteht."),
            ("Richtige Person, richtiger Platz", "Passt jemand zu unseren Werten – und versteht er die Aufgabe, will "
                                                 "er sie und kann er sie? Wenn eins fehlt, hilft kein Druck."),
            ("Scorecard", "Fünf bis fünfzehn Wochenzahlen zeigen früh, ob es läuft – bevor es in der Buchhaltung "
                          "auffällt."),
            ("Quartalsziele (Rocks)", "Drei bis sieben wichtige Ziele pro Quartal, jedes mit einem Verantwortlichen. "
                                      "Lieber wenig fertig als viel angefangen."),
            ("Probleme lösen", "In der Wochenrunde: Problem benennen, kurz besprechen, lösen – mit Aufgabe und Namen. "
                               "Nicht jede Woche dieselbe Diskussion."),
        ],
        "leitsatz": "",
        "muster": [
            "Für jeden Bereich (Verkauf, Werkstatt, Teile, Büro, Garantie) einen Verantwortlichen benennen – auch bei "
            "kleinen Teams.",
            "Die Scorecard in ODIN wöchentlich pflegen: Anfragen, Beratungstermine und Besichtigungen, Abschlüsse, "
            "Übergaben, offene Reklamationen.",
            "Die Wochenrunde unter „Besprechungen“ mit fester Zeit und fester Reihenfolge abhalten.",
        ],
    },
    {
        "id": "harnish", "name": "Verne Harnish", "kuerzel": "VH",
        "bekannt": "Autor von „Scaling Up“ und „Mastering the Rockefeller Habits“",
        "fuer": "Prioritäten, Rhythmus, Wachstum mit Ordnung",
        "steckbrief": "US-amerikanischer Unternehmer, Gründer der Unternehmerorganisation EO und Autor. Bekannt für "
                      "drei einfache Hebel beim Wachsen: wenige klare Prioritäten, Zahlen, die jeder versteht, und "
                      "ein fester Takt von kurzen Besprechungen.",
        "kernideen": [
            ("Die eine Priorität", "Von allen Zielen ist eines das wichtigste. Wenn alle es kennen, entscheiden sie "
                                   "im Alltag in dieselbe Richtung."),
            ("Rhythmus", "Täglich ein kurzes Abstimmen (zehn Minuten im Stehen), wöchentlich eine Runde, monatlich "
                         "und quartalsweise ein Blick nach vorn. Takt schafft Ruhe."),
            ("Zahlen sichtbar machen", "Jeder kennt die eine oder zwei Zahlen, an denen er seinen Tag messen kann."),
            ("Engpass zuerst", "Wachstum bremst immer an einer Stelle. Finde sie und kümmere dich zuerst darum."),
        ],
        "leitsatz": "",
        "muster": [
            "In der Saison ein tägliches Kurztreffen am Morgen: Übergaben heute, Engpässe, wer braucht Hilfe?",
            "Vor der Saison den Engpass benennen (z. B. Werkstattplätze für Übergabedurchsichten) und früh planen.",
            "Pro Quartal eine Hauptpriorität für den ganzen Betrieb festlegen und sichtbar aufhängen.",
        ],
    },
    {
        "id": "voss", "name": "Chris Voss", "kuerzel": "CV",
        "bekannt": "ehemaliger FBI-Verhandlungsführer, Autor von „Never Split the Difference“",
        "fuer": "Verhandeln: taktische Empathie, kalibrierte Fragen, Labeling",
        "steckbrief": "Früher Verhandlungsführer des FBI bei Entführungen. Heute bekannt für eine Verhandlungsweise, "
                      "die auf Zuhören und Gefühlen aufbaut statt auf Druck – auf Deutsch erschienen als "
                      "„Kompromisslos verhandeln“.",
        "kernideen": [
            ("Taktische Empathie", "Zeig dem anderen, dass du seine Lage und sein Gefühl verstanden hast – auch wenn "
                                   "du anderer Meinung bist. Wer sich verstanden fühlt, wird ruhiger und offener."),
            ("Labeling", "Gefühle benennen: „Es klingt so, als hätten Sie sich das anders vorgestellt.“ Dann "
                         "schweigen und zuhören."),
            ("Spiegeln", "Die letzten zwei, drei Worte des anderen fragend wiederholen. Er erzählt dann von selbst "
                         "mehr."),
            ("Kalibrierte Fragen", "Offene Wie- und Was-Fragen („Wie soll ich das machen?“) lassen den anderen nach "
                                   "einer Lösung suchen, statt sich zu verteidigen."),
            ("Ein Nein ist ein Anfang", "Ein Nein gibt Sicherheit. Fragen, auf die man mit Nein antworten kann "
                                        "(„Ist es eine schlechte Idee, …?“), öffnen oft mehr als Drängen auf ein Ja."),
        ],
        "leitsatz": "",
        "muster": [
            "Bei einer Reklamation zuerst das Gefühl benennen, dann die Sache: „Das ist ärgerlich, gerade vor dem "
            "ersten Urlaub.“",
            "Beim Preisgespräch statt Gegenangebot fragen: „Wie kommen Sie auf diesen Betrag?“",
            "Vor einem schwierigen Gespräch die Vorwürfe vorwegnehmen, die der andere im Kopf hat.",
        ],
    },
    {
        "id": "covey", "name": "Stephen R. Covey", "kuerzel": "SC",
        "bekannt": "Autor von „Die 7 Wege zur Effektivität“ (1932–2012)",
        "fuer": "Selbstführung, Prioritäten, erst verstehen, Win-win",
        "steckbrief": "US-amerikanischer Autor und Berater. Sein Buch über sieben Gewohnheiten wirksamer Menschen "
                      "gehört zu den meistgelesenen Büchern über Selbstführung und Zusammenarbeit.",
        "kernideen": [
            ("Proaktiv sein", "Konzentriere dich auf das, was du beeinflussen kannst – nicht auf Wetter, Hersteller "
                              "oder Konjunktur."),
            ("Mit dem Ziel beginnen", "Vor jeder Aufgabe und jedem Gespräch klären: Was soll am Ende herauskommen?"),
            ("Das Wichtige zuerst", "Wichtiges, aber nicht Dringendes (Planen, Vorbereiten, Schulen, Beziehungen "
                                    "pflegen) bekommt feste Zeit – sonst frisst das Dringende alles."),
            ("Erst verstehen, dann verstanden werden", "Zuhören, um zu verstehen – nicht, um zu antworten."),
            ("Win-win", "Gute Lösungen sind für beide Seiten gut. Wer nur gewinnen will, verliert auf Dauer den "
                        "Kunden oder den Kollegen."),
        ],
        "leitsatz": "Beginne mit dem Ende im Sinn.",
        "muster": [
            "Montags zehn Minuten Wochenplanung: die drei wichtigsten Dinge der Woche zuerst in den Kalender.",
            "Vor jedem Kundengespräch einen Satz notieren: Was soll der Kunde am Ende wissen, fühlen, tun?",
            "In Reklamationen eine Lösung suchen, mit der Kunde und Betrieb leben können – nicht wer recht hat.",
        ],
    },
    {
        "id": "allen", "name": "David Allen", "kuerzel": "DA",
        "bekannt": "Autor von „Getting Things Done“ (GTD)",
        "fuer": "Selbstorganisation, Kopf frei, nächster Schritt",
        "steckbrief": "US-amerikanischer Berater und Autor. Seine Methode „Getting Things Done“ hilft, alles Offene "
                      "aus dem Kopf in ein verlässliches System zu bringen, damit man sich auf die Arbeit vor sich "
                      "konzentrieren kann.",
        "kernideen": [
            ("Alles erfassen", "Was offen ist, gehört in eine Liste, nicht in den Kopf. Der Kopf ist zum Denken da, "
                               "nicht zum Merken."),
            ("Nächster konkreter Schritt", "„Kunde Müller“ ist keine Aufgabe. „Herrn Müller wegen "
                                           "Besichtigungstermin anrufen“ ist eine."),
            ("Zwei-Minuten-Regel", "Was in zwei Minuten erledigt ist, sofort machen statt aufschreiben."),
            ("Wochenrückblick", "Einmal pro Woche alle Listen durchgehen, aufräumen und die neue Woche "
                                "vorbereiten."),
        ],
        "leitsatz": "Dein Kopf ist zum Ideenhaben da, nicht zum Festhalten.",
        "muster": [
            "Jede Kundenzusage sofort festhalten (ODIN-Aufgabe, To-do oder CaraCamp) – nie „merk ich mir“.",
            "Freitags 20 Minuten: offene Angebote, Rückrufe und Zusagen durchgehen.",
            "Bei Übergaben an Kollegen immer den nächsten Schritt mit Datum nennen.",
        ],
    },
    {
        "id": "sinek", "name": "Simon Sinek", "kuerzel": "SS",
        "bekannt": "Autor von „Start with Why“ und „Leaders Eat Last“",
        "fuer": "Sinn und Warum, Vertrauen im Team",
        "steckbrief": "Britisch-amerikanischer Autor und Redner. Bekannt für den „Golden Circle“: Menschen folgen "
                      "dem Warum – erst danach interessieren sie das Wie und das Was.",
        "kernideen": [
            ("Mit dem Warum beginnen", "Menschen kaufen nicht, was du machst, sondern warum du es machst. Erst das "
                                       "Warum, dann das Wie, dann das Was."),
            ("Sicherheit im Team", "Teams leisten am meisten, wenn sie sich sicher fühlen – wenn Fehler angesprochen "
                                   "werden dürfen und die Führung zuerst für die Leute einsteht."),
            ("Langfristig denken", "Wer nur auf den nächsten Monat schaut, verliert das Spiel, das über Jahre geht."),
        ],
        "leitsatz": "Fang mit dem Warum an.",
        "muster": [
            "Unser Warum in einem Satz kennen: Wir sorgen dafür, dass Familien sorgenfrei unterwegs sind – vor, "
            "während und nach dem Kauf.",
            "In der Übergabe nicht nur Technik erklären, sondern die erste Reise mit dem Kunden gedanklich durchgehen.",
            "Als Teamleiter in der Hochsaison sichtbar mit anpacken.",
        ],
    },
]

# ---------------------------------------------------------------- Module (Coaching-Karten)

MODULE = [
    # ---------------- Verkaufstraining
    {
        "id": "bedarfsanalyse", "thema": "verkauf", "titel": "Bedarfsanalyse: erst fragen, dann zeigen",
        "mitglieder": ["kreuter", "voss", "hormozi"],
        "kernidee": "Wer zu früh Fahrzeuge zeigt, verkauft Blech. Wer zuerst fragt, verkauft Urlaub. In den ersten "
                    "Minuten findest du heraus, wie, mit wem und wohin der Kunde reisen will – dann zeigst du zwei, "
                    "höchstens drei passende Fahrzeuge statt die ganze Reihe.",
        "schritte": [
            "Begrüßen, Namen merken, kurz erklären, wie du vorgehst: „Darf ich Ihnen erst ein paar Fragen stellen, "
            "damit ich Ihnen nicht die falschen Fahrzeuge zeige?“",
            "Offene Fragen zur Reise: Wer fährt mit (Kinder, Hund)? Wohin, wie lange, wie oft? Stellplatz oder "
            "Campingplatz? Sommer oder auch Winter?",
            "Fragen zu Rahmen und Sorgen: Führerschein (3,5 t?), Stellplatz zu Hause, Budget und Zahlweise, was hat "
            "beim letzten Fahrzeug gestört?",
            "Zusammenfassen in den Worten des Kunden: „Wenn ich Sie richtig verstehe, brauchen Sie …“ – und auf die "
            "Bestätigung warten.",
            "Erst jetzt zwei oder drei passende Fahrzeuge zeigen und jeden Vorteil an eine Aussage des Kunden "
            "knüpfen.",
        ],
        "beispiel": "Ein Paar kommt wegen eines Kastenwagens. In der Bedarfsanalyse stellt sich heraus: zwei Enkel "
                    "fahren oft mit, und die Frau möchte nicht über das Bett klettern. Statt des günstigen "
                    "Kastenwagens aus dem Inserat passt ein teilintegrierter Hersteller2 mit Hubbett und Querbett – der "
                    "Preis ist höher, aber das Paar sagt: „Endlich versteht uns mal jemand.“",
        "fehler": [
            "Direkt zum Fahrzeug laufen und alle Extras aufzählen.",
            "Geschlossene Fragen („Soll es ein Kastenwagen sein?“) – sie liefern Ja/Nein, aber keine Gründe.",
            "Das Budget nicht ansprechen und am Ende ein Fahrzeug zeigen, das nie infrage kam.",
            "Zuhören, um zu antworten – statt zuzuhören, um zu verstehen.",
        ],
        "formulierungen": [
            "„Erzählen Sie mal: Wie sieht ein perfekter Urlaub mit dem neuen Fahrzeug aus?“",
            "„Was hat Sie an Ihrem bisherigen Fahrzeug am meisten gestört?“",
            "„Wer entscheidet außer Ihnen noch mit?“",
            "„Damit ich Ihnen das Richtige zeige: Was ist für Sie die Obergrenze, mit der Sie sich wohlfühlen?“",
        ],
    },
    {
        "id": "besichtigung", "thema": "verkauf", "titel": "Besichtigung und Vorführung am Fahrzeug",
        "mitglieder": ["hormozi", "kreuter"],
        "hausregeln": ["VERKAUF-001"],
        "kernidee": "Die Besichtigung ist der Moment, in dem aus „Ganz interessant“ ein „Das ist unser Fahrzeug“ "
                    "wird. Am Fahrzeug nimmst du dem Kunden Unsicherheit (Größe, Bedienung, Platz) und machst das "
                    "Traumergebnis greifbar – gut vorbereitet, mit Ziel und mit einer Frage am Ende. Hausregel "
                    "VERKAUF-001: Bei Neufahrzeugen bieten wir keine Probefahrt aktiv an, sondern eine ausführliche "
                    "Besichtigung und ein Gespräch am Fahrzeug.",
        "schritte": [
            "Vorbereiten: Fahrzeug sauber, Stromversorgung an, Heizung im Winter vorgewärmt, Licht an, Unterlagen "
            "griffbereit.",
            "Am Fahrzeug die Sorgen des Kunden beantworten: Maße und Gewicht zeigen, Rückfahrkamera und "
            "Assistenzsysteme erklären, Fahrersitz und Spiegel einstellen lassen.",
            "Den Kunden machen lassen: Tisch aufbauen, Bett ausprobieren, Küche und Bad bedienen – der Beifahrer "
            "bekommt eine Aufgabe (z. B. die Sitzgruppe umbauen).",
            "Fragt der Kunde selbst nach einer Probefahrt mit einem Neufahrzeug: die Hausregel sachlich und "
            "freundlich erklären und anbieten, alles Weitere direkt am Fahrzeug zu zeigen.",
            "Mit einer Frage abschließen: „Wie fühlt es sich an?“ und dann: „Sollen wir das so festmachen?“",
        ],
        "beispiel": "Ein Kunde hat Angst vor 7,40 m Länge. Statt ihn zu beruhigen, setzt der Verkäufer ihn auf den "
                    "Fahrersitz, lässt ihn Sitz und Spiegel einstellen, zeigt das Bild der Rückfahrkamera und geht "
                    "mit ihm einmal ums Fahrzeug: Wo sind die Ecken, wie weit steht das Heck über? Danach sagt der "
                    "Kunde: „Ist ja übersichtlicher als gedacht.“ Der Einwand ist kleiner, bevor er im Preisgespräch "
                    "auftaucht.",
        "fehler": [
            "Nur die Ausstattungsliste vorlesen – die eigentliche Sorge bleibt.",
            "Pausenlos reden, statt den Kunden selbst ausprobieren zu lassen.",
            "Bei einem Neufahrzeug von sich aus eine Probefahrt anbieten (Hausregel VERKAUF-001).",
            "Nach der Besichtigung direkt ins Büro gehen, ohne nach dem Eindruck zu fragen.",
        ],
        "formulierungen": [
            "„Was ist Ihnen bei einem so großen Fahrzeug am wichtigsten? Genau das schauen wir uns jetzt in Ruhe "
            "an.“",
            "„Setzen Sie sich mal hinten an den Tisch – stellen Sie sich vor, es regnet draußen am Gardasee.“",
            "„Auf einer Skala von 1 bis 10: Wie nah ist das an dem, was Sie suchen? Was fehlt zur 10?“",
            "Fragt der Kunde nach einer Probefahrt (Neufahrzeug): „Bei unseren Neufahrzeugen bieten wir keine "
            "Probefahrten an. Was ich Ihnen gern anbiete: Wir gehen das Fahrzeug in Ruhe gemeinsam durch – und "
            "was Ihnen beim Fahren wichtig ist, zeige und erkläre ich Ihnen direkt am Fahrzeug.“",
        ],
    },
    {
        "id": "preisgespraech", "thema": "verkauf", "titel": "Preisgespräch und Preiseinwände",
        "mitglieder": ["buffett", "hormozi", "kreuter", "voss"],
        "kernidee": "„Zu teuer“ heißt fast nie „zu teuer“, sondern „Ich sehe den Wert noch nicht“ oder „Ich habe "
                    "Angst, einen Fehler zu machen“. Bevor du am Preis drehst, finde heraus, was hinter dem Satz "
                    "steckt – und erhöhe den Wert statt den Rabatt.",
        "schritte": [
            "Ruhig bleiben und den Einwand annehmen: „Gut, dass Sie das offen sagen.“",
            "Nachfragen, was genau gemeint ist: zu teuer im Vergleich wozu? Zu hohe Rate? Zu viel auf einmal?",
            "Den Wert noch einmal mit den Wünschen des Kunden verknüpfen: Was bekommt er bei uns, was er woanders "
            "nicht bekommt (Übergabe, Werkstatt vor Ort, Ansprechpartner, montiertes Zubehör)?",
            "Wenn nötig, das Paket verändern statt den Preis: anderes Fahrzeug, weniger Ausstattung, Finanzierung "
            "mit kleinerer Rate, Inzahlungnahme.",
            "Nach der Einigung auf den Wert erneut nach der Entscheidung fragen.",
        ],
        "beispiel": "Ein Kunde sagt beim Hersteller1-Teilintegrierten: „Im Internet steht der 3.000 € günstiger.“ Die "
                    "Verkäuferin fragt nach und erfährt: Das Inserat ist 400 km entfernt, ohne Markise und ohne "
                    "Übergabedurchsicht. Sie rechnet mit dem Kunden zusammen, was Anfahrt, Markise mit Einbau und "
                    "der Weg in die Werkstatt im Garantiefall kosten würden. Am Ende kauft er bei uns – zum vollen "
                    "Preis, mit einem Gutschein fürs erste Gas.",
        "fehler": [
            "Sofort Rabatt anbieten – das sagt dem Kunden: Der Preis war vorher nicht ehrlich.",
            "Den Wettbewerber schlechtmachen.",
            "Sich rechtfertigen und lange Erklärungen liefern, ohne vorher zu fragen.",
            "Preis und Rate verwechseln: Wer „zu teuer“ wegen der Monatsrate meint, braucht eine andere Lösung.",
        ],
        "formulierungen": [
            "„Zu teuer im Vergleich wozu?“",
            "„Mal angenommen, der Preis wäre kein Thema – wäre das dann Ihr Fahrzeug?“",
            "„Was müsste in dem Paket drin sein, damit sich der Betrag für Sie richtig anfühlt?“",
            "„Ich verstehe. Bevor wir über Zahlen reden: Was ist Ihnen beim Händler wichtig, wenn mal etwas ist?“",
        ],
    },
    {
        "id": "einwaende", "thema": "verkauf", "titel": "Einwände behandeln",
        "mitglieder": ["kreuter", "voss", "hormozi"],
        "kernidee": "Ein Einwand ist kein Nein, sondern eine offene Frage. Wer ihn ernst nimmt, versteht und dann "
                    "beantwortet, kommt dem Abschluss näher. Wer ihn überrennt, verliert das Vertrauen.",
        "schritte": [
            "Ausreden lassen und nicht unterbrechen.",
            "Den Einwand bestätigen, ohne ihm zuzustimmen: „Das verstehe ich gut.“",
            "Nachfragen, ob es der einzige Punkt ist: „Ist das der einzige Punkt, der Sie noch zögern lässt?“",
            "Den Einwand mit Fakten, Beispiel oder Lösung beantworten – kurz.",
            "Prüfen, ob er erledigt ist, und zurück zum nächsten Schritt.",
        ],
        "beispiel": "Ein Kunde sagt: „Gas im Fahrzeug ist mir nicht geheuer.“ Statt zu sagen „Das ist sicher“, fragt "
                    "der Verkäufer: „Was genau macht Ihnen Sorgen?“ – Es ist die Angst vor dem Gasflaschenwechsel. "
                    "Er zeigt den Wechsel in zwei Minuten, erwähnt die regelmäßige Gasprüfung in unserer Werkstatt "
                    "und bietet an, den ersten Wechsel bei der Übergabe gemeinsam zu machen.",
        "fehler": [
            "„Ja, aber …“ – das „aber“ wischt alles davor weg.",
            "Mit Fachbegriffen antworten.",
            "Mehrere Einwände gleichzeitig beantworten, statt sie nacheinander zu klären.",
        ],
        "formulierungen": [
            "„Gut, dass Sie das ansprechen. Was genau macht Ihnen da Sorgen?“",
            "„Angenommen, wir finden dafür eine Lösung – gibt es dann noch etwas, das Sie abhält?“",
            "„Es klingt so, als hätten Sie damit schon schlechte Erfahrungen gemacht.“",
        ],
    },
    {
        "id": "inzahlungnahme", "thema": "verkauf", "titel": "Inzahlungnahme im Gespräch",
        "mitglieder": ["voss", "munger", "buffett"],
        "kernidee": "Für den Kunden ist sein altes Fahrzeug voller Erinnerungen – für uns ist es ein Fahrzeug, das "
                    "wir wieder verkaufen müssen. Ehrlich, nachvollziehbar bewerten und die Erinnerungen respektieren, "
                    "ohne beim Wert nachzugeben.",
        "schritte": [
            "Zuerst nach der Geschichte fragen: Wie lange gefahren, wohin, was war gut?",
            "Gemeinsam ums Fahrzeug gehen und den Zustand offen ansprechen: Feuchtigkeit, Reifenalter, Gasprüfung, "
            "Service, Schäden – mit Fotos.",
            "Den Wert nachvollziehbar herleiten: Marktpreis, minus Aufbereitung, Reparaturen und Risiko. Die "
            "Rechnung zeigen, nicht nur die Zahl.",
            "Inzahlungnahme und neues Fahrzeug getrennt besprechen, dann zusammenführen: Was bleibt als Differenz?",
            "Bei großer Lücke Alternativen nennen: Privatverkauf, Kommission, späterer Übergabetermin.",
        ],
        "beispiel": "Ein Kunde erwartet 18.000 € für seinen 15 Jahre alten Wohnwagen. Bei der Feuchtigkeitsmessung "
                    "zeigt sich ein Wert über dem Grenzwert an der Frontwand. Der Verkäufer zeigt ihm das "
                    "Messgerät, die geschätzten Reparaturkosten und die Vergleichsangebote. Der Kunde ist "
                    "enttäuscht, aber er sagt: „Das ist wenigstens ehrlich.“ Man einigt sich auf einen fairen Preis.",
        "fehler": [
            "Beim neuen Fahrzeug Rabatt geben und ihn als höheren Ankaufspreis verstecken – das verzerrt beide "
            "Zahlen.",
            "Den Zustand nur grob schätzen, ohne Feuchtigkeitsmessung und Prüfung.",
            "Das alte Fahrzeug schlechtreden.",
        ],
        "formulierungen": [
            "„Erzählen Sie mal, wo Sie mit ihm überall waren.“",
            "„Ich zeige Ihnen gern, wie ich auf den Betrag komme – dann können Sie es selbst nachvollziehen.“",
            "„Es klingt so, als hätten Sie mit mehr gerechnet. Was war Ihre Vorstellung, und woher kommt sie?“",
        ],
    },
    {
        "id": "finanzierung", "thema": "verkauf", "titel": "Finanzierung anbieten",
        "mitglieder": ["hormozi", "buffett", "covey"],
        "kernidee": "Viele Kunden denken in Monatsraten, nicht im Gesamtpreis. Wer Finanzierung selbstverständlich "
                    "und ehrlich anbietet, macht den Kauf leichter – wer sie aufdrängt oder Kosten verschweigt, "
                    "verspielt Vertrauen. Ziel: die passende Zahlweise für diesen Kunden.",
        "schritte": [
            "Früh, aber offen fragen: „Wie möchten Sie bezahlen – bar, finanziert oder mit Inzahlungnahme?“",
            "Beide Wege fair vergleichen: Gesamtkosten, Rate, Laufzeit, Schlussrate, Flexibilität, Rücklagen.",
            "Rate an den Alltag knüpfen, aber ehrlich bleiben: Was kostet der Kredit insgesamt?",
            "Nur anbieten, was der Kunde sich sicher leisten kann – lieber ein kleineres Fahrzeug.",
            "Unterlagen und nächste Schritte klar nennen; Pflichtangaben und Widerrufsrecht nicht verkürzen.",
        ],
        "beispiel": "Ein junges Paar will bar zahlen, hätte danach aber keine Rücklage mehr. Die Verkäuferin "
                    "rechnet beide Wege vor: Barkauf ohne Puffer oder eine Finanzierung mit Anzahlung, bei der "
                    "6.000 € als Rücklage bleiben. Das Paar entscheidet sich bewusst für die Finanzierung – und "
                    "empfiehlt uns später weiter, weil es sich gut beraten fühlte.",
        "fehler": [
            "Nur die Monatsrate nennen und Gesamtkosten oder Schlussrate verschweigen.",
            "Finanzierung als Druckmittel für den Abschluss nutzen.",
            "Annehmen, wer bar zahlen kann, will bar zahlen.",
        ],
        "formulierungen": [
            "„Viele unserer Kunden finanzieren, um eine Rücklage für Reisen und Unvorhergesehenes zu behalten. Soll "
            "ich Ihnen beide Wege nebeneinander zeigen?“",
            "„Hier sehen Sie alles auf einen Blick: Rate, Laufzeit, Schlussrate und was Sie insgesamt zahlen.“",
        ],
    },
    {
        "id": "abschluss", "thema": "verkauf", "titel": "Abschluss: um den Auftrag bitten",
        "mitglieder": ["kreuter", "voss"],
        "kernidee": "Viele gute Gespräche enden ohne Kauf, weil niemand gefragt hat. Der Abschluss ist der "
                    "natürliche nächste Schritt nach einer guten Beratung – klar fragen, dann schweigen.",
        "schritte": [
            "Kaufsignale erkennen: Fragen nach Lieferzeit, Farben, Übergabe, Finanzierung; Kunde setzt sich wieder "
            "ins Fahrzeug.",
            "Kurz zusammenfassen, was passt.",
            "Eine klare Abschlussfrage stellen – und dann schweigen, bis der Kunde antwortet.",
            "Bei Zögern den Grund erfragen statt Druck aufzubauen.",
            "Nächsten Schritt sofort festmachen: Kaufvertrag, Anzahlung, Übergabetermin.",
        ],
        "beispiel": "Nach der Besichtigung fragt die Kundin, ob die Markise bis Ostern montiert sein kann. Das ist ein "
                    "Kaufsignal. Der Verkäufer fasst zusammen und fragt: „Sollen wir den Übergabetermin für die "
                    "Woche vor Ostern festmachen?“ – und wartet. Nach einer Pause sagt sie: „Ja, machen wir.“",
        "fehler": [
            "Weiterreden, obwohl der Kunde schon kaufbereit ist.",
            "Die Abschlussfrage stellen und die Stille sofort selbst füllen.",
            "„Melden Sie sich einfach“ als Gesprächsende.",
        ],
        "formulierungen": [
            "„Sollen wir das so festmachen?“",
            "„Welcher Übergabetermin passt Ihnen besser – vor oder nach Ostern?“",
            "„Was fehlt Ihnen noch, damit Sie heute Ja sagen können?“",
            "„Ist es eine schlechte Idee, heute schon den Kaufvertrag vorzubereiten?“",
        ],
    },
    {
        "id": "nachfassen", "thema": "verkauf", "titel": "Nachfassen mit System",
        "mitglieder": ["kreuter", "allen", "voss"],
        "kernidee": "Die meisten Kunden kaufen nicht beim ersten Kontakt. Wer freundlich und verlässlich nachfasst, "
                    "zeigt Interesse und Zuverlässigkeit – genau das, was der Kunde später von uns erwartet.",
        "schritte": [
            "Am Ende jedes Gesprächs einen nächsten Kontakt vereinbaren – mit Datum und Weg (Telefon, Mail).",
            "Den Termin sofort festhalten (Kalender, Aufgabe), nicht „merken“.",
            "Beim Nachfassen etwas Neues mitbringen: Antwort auf eine offene Frage, neues Fahrzeug, freier "
            "Übergabetermin.",
            "Offen fragen, wo der Kunde steht – und ein Nein akzeptieren.",
            "Nach dem dritten Kontakt ohne Rückmeldung eine freundliche Abschlussnachricht schicken.",
        ],
        "beispiel": "Ein Angebot über einen Hersteller3 ist seit einer Woche raus. Der Verkäufer ruft wie vereinbart an "
                    "und hat eine Neuigkeit: Ein Fahrzeug in der Wunschfarbe kommt im März. Der Kunde hatte "
                    "gezögert, weil er die Farbe nicht wollte – jetzt bestellt er verbindlich.",
        "fehler": [
            "Nachfassen ohne Grund: „Wollte nur mal hören …“",
            "Nach einem Kontakt aufgeben.",
            "Druck machen („Das Angebot gilt nur noch heute“), wenn es nicht stimmt.",
        ],
        "formulierungen": [
            "„Ich hatte versprochen, mich heute zu melden – und ich habe eine gute Nachricht.“",
            "„Haben Sie sich schon gegen uns entschieden?“ – ein Nein darauf öffnet oft das Gespräch.",
            "„Ich möchte Sie nicht nerven. Soll ich mich im Frühjahr noch einmal melden?“",
        ],
    },
    {
        "id": "zubehoer", "thema": "verkauf", "titel": "Zubehör und Mehrverkauf – ehrlich",
        "mitglieder": ["hormozi", "buffett"],
        "kernidee": "Gutes Zubehör macht die Reise des Kunden besser – dann ist es kein Mehrverkauf, sondern "
                    "Beratung. Biete an, was zum Bedarf passt, erkläre den Nutzen und montiere es vor der Übergabe. "
                    "Was nicht passt, lässt du weg.",
        "schritte": [
            "Aus der Bedarfsanalyse ableiten: Wer viel frei steht, braucht Strom (Solar, Batterie); wer Fahrräder "
            "mitnimmt, einen Träger.",
            "Nutzen in einem Satz erklären, nicht die Technik.",
            "Ein vernünftiges Paket schnüren, mit Preis inklusive Montage (Teile & Montage in ODIN).",
            "Einbau vor der Übergabe planen, damit der Kunde startklar ist.",
            "Nein akzeptieren – und den Wunsch für später notieren.",
        ],
        "beispiel": "Ein Kunde will viel in Skandinavien frei stehen. Die Verkäuferin schlägt Solaranlage und "
                    "Lithium-Batterie vor und erklärt: „Damit kommen Sie vier, fünf Tage ohne Landstrom aus.“ Die "
                    "Rückfahrkamera lehnt er ab – sie notiert es. Zwei Jahre später lässt er sie bei uns "
                    "nachrüsten.",
        "fehler": [
            "Jedem dasselbe Paket verkaufen.",
            "Zubehör anbieten, das nicht ins Gewicht passt (Zuladung!).",
            "Nach der Unterschrift noch einmal mit einer langen Liste kommen.",
        ],
        "formulierungen": [
            "„Sie hatten erzählt, dass Sie gern frei stehen. Darf ich Ihnen zeigen, was das deutlich leichter macht?“",
            "„Mit Einbau sind das … – und es ist zur Übergabe fertig montiert.“",
        ],
    },
    {
        "id": "akquise", "thema": "verkauf", "titel": "Neue Kunden gewinnen",
        "mitglieder": ["kreuter", "hormozi", "sinek"],
        "kernidee": "Wer nur auf Laufkundschaft wartet, hat in ruhigen Wochen nichts zu tun. Aktiv auf Interessenten "
                    "zugehen, bestehende Kunden pflegen und um Empfehlungen bitten füllt den Kalender – verlässlich "
                    "und Woche für Woche.",
        "schritte": [
            "Jeden Tag eine feste Zeit für Kontakte blocken (z. B. 30 Minuten am Vormittag).",
            "Alte Anfragen und Interessenten ohne Kauf durchgehen und mit einem Anlass melden (neues Modell, "
            "Hausmesse, Saisonstart).",
            "Bestandskunden zum richtigen Zeitpunkt ansprechen: Gasprüfung fällig, Fahrzeug fünf Jahre alt.",
            "Nach jeder gelungenen Übergabe um eine Empfehlung und eine Bewertung bitten.",
            "Zählen: Wie viele Kontakte, Beratungstermine und Besichtigungen pro Woche? (Scorecard)",
        ],
        "beispiel": "Im November ist es ruhig. Ein Verkäufer ruft jeden Vormittag fünf Kunden an, deren Wohnwagen "
                    "älter als acht Jahre ist, und lädt zur Hausmesse ein. Von 40 Anrufen kommen elf zur Messe, "
                    "drei kaufen bis Februar.",
        "fehler": [
            "Nur anrufen, wenn man Zeit hat – also nie.",
            "Ohne Anlass anrufen („Wollen Sie nicht ein neues Fahrzeug?“).",
            "Werbung und Kontaktwege ohne Einwilligung nutzen – Datenschutz und Wettbewerbsrecht beachten.",
        ],
        "formulierungen": [
            "„Sie hatten im Frühjahr nach einem Fahrzeug mit Einzelbetten gefragt – jetzt haben wir genau so eins "
            "hereinbekommen.“",
            "„Kennen Sie jemanden, dem wir genauso helfen können wie Ihnen?“",
        ],
    },
    # ---------------- Verhandeln
    {
        "id": "verhandeln", "thema": "verhandeln", "titel": "Verhandeln mit taktischer Empathie",
        "mitglieder": ["voss", "covey"],
        "kernidee": "Gute Verhandler drücken nicht, sie hören zu. Wenn sich dein Gegenüber verstanden fühlt, "
                    "redet es offener, und ihr findet Lösungen, an die vorher keiner gedacht hat. Ziel ist ein "
                    "Ergebnis, mit dem beide Seiten gut leben können.",
        "schritte": [
            "Vorbereiten: Was will ich erreichen, was ist meine Grenze, was könnte der andere wollen?",
            "Vorwürfe vorwegnehmen: „Sie denken jetzt vielleicht, wir wollen nur …“",
            "Gefühle benennen (Labeling) und schweigen.",
            "Mit kalibrierten Fragen arbeiten: „Wie soll ich das machen?“, „Was ist Ihnen dabei am wichtigsten?“",
            "Ergebnis festhalten: Wer macht was bis wann?",
        ],
        "beispiel": "Ein Kunde will 2.000 € Nachlass. Statt einen Gegenvorschlag zu machen, sagt der Verkäufer: "
                    "„Es klingt so, als wäre Ihnen ein faires Gefühl beim Kauf wichtig.“ Der Kunde erzählt, dass "
                    "er beim letzten Kauf übers Ohr gehauen wurde. Am Ende einigen sie sich auf den Preis, dazu "
                    "eine ausführliche Übergabe mit Probenacht auf dem Hof.",
        "fehler": [
            "Sofort ein Gegenangebot machen – oder in der Mitte treffen, ohne zu verstehen, worum es geht.",
            "Druck mit erfundenen Fristen.",
            "Ein Zugeständnis machen, ohne etwas dafür zu bekommen.",
        ],
        "formulierungen": [
            "„Wie soll ich das machen?“",
            "„Es scheint, als wäre Ihnen … besonders wichtig.“",
            "„Wäre es unvernünftig, wenn wir … ?“",
        ],
    },
    {
        "id": "partnergespraech", "thema": "verhandeln", "titel": "Gespräche mit Hersteller, Bank und Lieferanten",
        "mitglieder": ["voss", "munger", "buffett"],
        "kernidee": "Hersteller, Banken und Lieferanten sind langfristige Partner. Gute Verhandlungen mit ihnen sind "
                    "gut vorbereitet, sachlich und fair – und berücksichtigen, wofür das Gegenüber selbst belohnt "
                    "wird.",
        "schritte": [
            "Zahlen und Fakten vorher zusammentragen (Bestand, Linien, Stückzahlen, offene Gutschriften – ODIN hilft).",
            "Überlegen, was das Gegenüber braucht: Ziele, Stückzahlen, Risiko, interne Regeln.",
            "Eigene Grenze und beste Alternative festlegen, bevor das Gespräch beginnt.",
            "Mit Fragen einsteigen: „Was müsste passieren, damit …?“",
            "Ergebnis schriftlich bestätigen.",
        ],
        "beispiel": "Vor dem Gespräch mit der Bank über eine höhere Linie bereitet das Büro Standtage, "
                    "Zinsfreiheiten und die geplanten Vororder vor. Die Geschäftsführung fragt: „Was müssten Sie "
                    "sehen, um die Linie für die Saison zu erhöhen?“ – Die Bank will eine monatliche Übersicht. "
                    "Die Linie wird erhöht.",
        "fehler": [
            "Unvorbereitet ins Gespräch gehen.",
            "Nur über den eigenen Vorteil reden.",
            "Mündliche Zusagen nicht schriftlich bestätigen.",
        ],
        "formulierungen": [
            "„Was müssten Sie sehen, damit Sie das intern vertreten können?“",
            "„Ich fasse kurz zusammen, was wir vereinbart haben – und schicke es Ihnen heute noch per Mail.“",
        ],
    },
    # ---------------- Entscheiden
    {
        "id": "entscheiden", "thema": "entscheiden", "titel": "Gut entscheiden: die Checkliste",
        "mitglieder": ["munger", "buffett", "covey"],
        "kernidee": "Gute Entscheidungen sind kein Glück, sondern Handwerk. Eine kurze Checkliste schützt vor "
                    "typischen Fehlern: außerhalb des eigenen Wissens zu entscheiden, nur an den Erfolg zu denken "
                    "oder eine leicht umkehrbare Frage zu zerdenken.",
        "schritte": [
            "Kompetenzkreis: Kenne ich mich damit wirklich aus? Wenn nicht, wer im Team?",
            "Umkehrbar oder nicht? Umkehrbare Entscheidungen schnell treffen, nicht umkehrbare gründlich.",
            "Umkehrdenken: Was müsste passieren, damit das schiefgeht? Was davon kann ich verhindern?",
            "Pre-Mortem: Stell dir vor, es ist ein Jahr später und die Entscheidung war ein Fehler. Warum?",
            "10/10/10: Wie fühle ich mich in 10 Minuten, 10 Monaten und 10 Jahren mit dieser Entscheidung?",
        ],
        "beispiel": "Soll der Betrieb eine zweite Hebebühne kaufen? Umkehrbar ist das kaum. Das Team macht ein "
                    "Pre-Mortem: Ein Jahr später steht die Bühne still, weil der Monteur fehlt. Daraus folgt: erst "
                    "die Einstellung des Monteurs klären, dann die Bühne bestellen.",
        "fehler": [
            "Jede Entscheidung gleich gründlich behandeln – auch kleine, umkehrbare.",
            "Nur Gründe dafür sammeln.",
            "An früheren Ausgaben festhalten („Wir haben schon so viel investiert“).",
        ],
        "formulierungen": [
            "„Ist das umkehrbar? Dann probieren wir es vier Wochen und schauen dann.“",
            "„Stellen wir uns vor, es ist schiefgegangen. Was war der Grund?“",
        ],
    },
    {
        "id": "ankauf", "thema": "entscheiden", "titel": "Gebrauchtankauf: Ja oder Nein?",
        "mitglieder": ["buffett", "munger", "harnish"],
        "kernidee": "Beim Ankauf wird der Gewinn gemacht – oder der Langsteher. Kaufe Fahrzeuge, die du kennst, "
                    "zu einem Preis mit Sicherheitsabstand. Wenn die Rechnung nur aufgeht, wenn alles gut läuft, "
                    "lass es.",
        "schritte": [
            "Kenne ich Marke, Baureihe und typische Schwachstellen? (Kompetenzkreis)",
            "Zustand prüfen: Feuchtigkeit, Reifenalter, Gasprüfung, Basisfahrzeug, Service, Unfallschäden.",
            "Rückwärts rechnen: realistischer Verkaufspreis minus Aufbereitung, Reparatur, Standkosten und Marge "
            "= höchster Ankaufspreis.",
            "Umkehrdenken: Was würde ihn zum Langsteher machen (Grundriss, Saison, Preis, Zustand)?",
            "Entscheidung und Begründung kurz festhalten – damit wir aus den Ergebnissen lernen.",
        ],
        "beispiel": "Ein 12 Jahre alter Alkoven wird angeboten, Preis wirkt günstig. Bei der Prüfung fallen "
                    "Feuchtigkeit im Heck und alte Reifen auf. Rückwärts gerechnet bleibt bei realistischem "
                    "Verkaufspreis kein Puffer. Der Verkäufer lehnt freundlich ab und empfiehlt dem Kunden den "
                    "Privatverkauf.",
        "fehler": [
            "Aus Gefälligkeit ankaufen, damit das neue Geschäft klappt, ohne die Zahl zu prüfen.",
            "Auf den Verkaufspreis im Internet vertrauen statt auf echte Verkaufspreise.",
            "Standzeit und Zinsen vergessen (Zinsuhr in ODIN).",
        ],
        "formulierungen": [
            "„Ich zeige Ihnen, wie ich rechne – dann sehen Sie, warum ich nicht höher gehen kann.“",
            "„Für dieses Fahrzeug sind wir nicht der beste Käufer. Privat erzielen Sie wahrscheinlich mehr.“",
        ],
    },
    # ---------------- Struktur & Selbstorganisation
    {
        "id": "wochenplanung", "thema": "struktur", "titel": "Wochenplanung und Prioritäten",
        "mitglieder": ["covey", "harnish", "allen"],
        "kernidee": "Wenn du deine Woche nicht planst, planen sie andere für dich. Zehn Minuten am Anfang der Woche "
                    "reichen, um das Wichtige vor das Dringende zu stellen.",
        "schritte": [
            "Montagmorgen oder Freitagnachmittag zehn Minuten blocken.",
            "Fragen: Was sind die drei wichtigsten Ergebnisse dieser Woche? (nicht Aufgaben – Ergebnisse)",
            "Für jedes Ergebnis einen festen Zeitblock im Kalender eintragen.",
            "Termine aus „Heute & Woche“ prüfen: Übergaben, Fristen, Abwesenheiten.",
            "Puffer lassen – in der Saison kommt immer etwas dazwischen.",
        ],
        "beispiel": "Eine Verkäuferin plant montags: 1. Drei offene Angebote nachfassen, 2. Übergabe Donnerstag "
                    "vorbereiten, 3. Fotos für zwei neue Inserate. Sie blockt Dienstag 9–10 Uhr für Anrufe. Am "
                    "Freitag sind alle drei erledigt – trotz voller Ausstellung.",
        "fehler": [
            "Die To-do-Liste mit 40 Punkten als Plan verstehen.",
            "Wichtiges ohne festen Termin lassen.",
            "Den Plan nie überprüfen.",
        ],
        "formulierungen": [
            "„Woran merke ich am Freitag, dass es eine gute Woche war?“",
        ],
    },
    {
        "id": "kopffrei", "thema": "struktur", "titel": "Kopf frei: alles erfassen, nächster Schritt",
        "mitglieder": ["allen", "covey"],
        "kernidee": "Wer sich verzettelt, hat meist zu viel im Kopf und zu wenig auf Papier. Alles Offene an einem "
                    "Ort sammeln, für jedes den nächsten konkreten Schritt festlegen – dann wird es ruhig im Kopf.",
        "schritte": [
            "Alles aufschreiben, was offen ist: Rückrufe, Zusagen, Ideen, Ärger.",
            "Für jeden Punkt klären: Was ist der nächste konkrete Schritt? Wer macht ihn?",
            "Was in zwei Minuten geht, sofort erledigen.",
            "Den Rest an einen verlässlichen Ort: ODIN-Aufgaben, To-dos, Kalender.",
            "Einmal pro Woche alles durchsehen (Wochenrückblick).",
        ],
        "beispiel": "Ein Serviceberater hat am Montag 23 Zettel und Notizen. Er nimmt sich 20 Minuten, schreibt "
                    "alles in eine Liste, erledigt sieben Kleinigkeiten sofort, gibt vier an Kollegen weiter und "
                    "plant den Rest in die Woche. Nachmittags vergisst er zum ersten Mal seit Wochen keinen Rückruf.",
        "fehler": [
            "Aufgaben als Projekte formulieren („Kunde Schulz“).",
            "Mehrere Listen an mehreren Orten.",
            "Erfassen, aber nie durchsehen.",
        ],
        "formulierungen": [
            "„Was ist hier der nächste Schritt – und wer macht ihn?“",
        ],
    },
    {
        "id": "teamuebergabe", "thema": "struktur", "titel": "Saubere Übergaben im Team",
        "mitglieder": ["wickman", "allen"],
        "kernidee": "Zwischen Verkauf, Werkstatt, Teilen und Büro geht am meisten verloren. Eine gute Übergabe "
                    "beantwortet immer dieselben Fragen: Was ist der Stand, was ist zugesagt, was ist der nächste "
                    "Schritt, bis wann, wer ist verantwortlich?",
        "schritte": [
            "Schriftlich übergeben (Aufgabe in ODIN, Notiz am Auftrag) – nie nur im Vorbeigehen.",
            "Stand und Zusagen an den Kunden nennen.",
            "Den nächsten Schritt mit Datum festlegen.",
            "Einen Namen als Verantwortlichen nennen.",
            "Rückmeldung einfordern: „Passt das so für dich?“",
        ],
        "beispiel": "Der Verkäufer verkauft einen Wohnwagen mit Fahrradträger, Übergabe in drei Wochen. Er legt "
                    "sofort eine Aufgabe für Teile und Werkstatt an: Träger bestellen, montieren bis zum 12., "
                    "Kunde wünscht Montage auf der Deichsel. Die Übergabe läuft ohne Rückfragen.",
        "fehler": [
            "„Ich hab’s dem Kollegen gesagt.“",
            "Kein Datum, kein Name.",
            "Zusagen an den Kunden nicht weitergeben.",
        ],
        "formulierungen": [
            "„Stand, Zusage, nächster Schritt, bis wann, wer – passt das so?“",
        ],
    },
    # ---------------- Kundenservice & Reklamation
    {
        "id": "reklamation", "thema": "service", "titel": "Reklamation: aus Ärger Vertrauen machen",
        "mitglieder": ["voss", "covey", "buffett"],
        "kernidee": "Ein Kunde mit einer gut gelösten Reklamation ist oft treuer als einer ohne Problem. "
                    "Entscheidend ist, wie wir reagieren: erst das Gefühl, dann die Sache, dann eine klare Zusage, "
                    "die wir halten.",
        "schritte": [
            "Zuhören und ausreden lassen – nicht rechtfertigen.",
            "Das Gefühl benennen: „Das ist ärgerlich, gerade vor der ersten Reise.“",
            "Sache aufnehmen: Was genau, seit wann, Fotos, Fahrzeugnummer.",
            "Konkreten nächsten Schritt mit Termin zusagen – nur, was wir halten können.",
            "Nachfassen, wenn erledigt: „Ist alles wieder in Ordnung?“ Bei rechtlichen Fragen (Gewährleistung, "
            "Rücktritt) früh die Geschäftsführung einbinden.",
        ],
        "beispiel": "Zwei Wochen nach der Übergabe tropft das Dachfenster. Der Kunde ist wütend. Die "
                    "Serviceberaterin sagt: „Das ist ärgerlich, Sie hatten sich auf das Wochenende gefreut.“ Sie "
                    "nimmt Fotos auf, bietet am nächsten Morgen einen Termin an und einen Ersatz-Stellplatz unter "
                    "Dach. Nach der Reparatur ruft sie an. Der Kunde schreibt später eine gute Bewertung.",
        "fehler": [
            "„Das kann gar nicht sein.“",
            "Schuld beim Hersteller abladen.",
            "Mehr zusagen, als wir halten können.",
            "Rechtliche Aussagen aus dem Bauch („Da haben Sie keinen Anspruch“).",
        ],
        "formulierungen": [
            "„Das ist ärgerlich – gut, dass Sie sich gleich melden.“",
            "„Damit ich das richtig verstehe: Was genau ist passiert?“",
            "„Ich verspreche Ihnen, bis morgen 12 Uhr meldet sich jemand mit einem Termin.“",
        ],
    },
    {
        "id": "fahrzeuguebergabe", "thema": "service", "titel": "Übergabe als Erlebnis",
        "mitglieder": ["sinek", "hormozi", "covey"],
        "kernidee": "Die Übergabe ist der Moment, an den sich der Kunde jahrelang erinnert. Sie soll ihm Sicherheit "
                    "für die erste Reise geben – und das Gefühl, die richtige Wahl getroffen zu haben.",
        "schritte": [
            "Vorbereiten: Fahrzeug fertig, Zubehör montiert, Papiere vollständig, genug Zeit eingeplant.",
            "Nicht alles erklären, sondern die erste Reise durchgehen: Ankommen, Strom, Wasser, Gas, Heizung, "
            "Abfahren.",
            "Den Kunden selbst machen lassen (Gas wechseln, Stützen, Markise).",
            "Ansprechpartner und Notfallnummer nennen.",
            "Nach der ersten Reise anrufen.",
        ],
        "beispiel": "Bei einer Übergabe stellt der Verkäufer einen kleinen Korb mit Wasserschlauch-Adapter und "
                    "Ausgleichskeilen ins Fahrzeug und geht mit der Familie die erste Nacht auf dem Campingplatz "
                    "Schritt für Schritt durch. Eine Woche später ruft er an – die Familie schickt Fotos vom "
                    "Gardasee.",
        "fehler": [
            "Übergabe zwischen zwei Terminen in 20 Minuten.",
            "Technik-Vortrag statt Üben.",
            "Nach der Übergabe nie wieder melden.",
        ],
        "formulierungen": [
            "„Wir gehen jetzt gemeinsam Ihre erste Nacht auf dem Campingplatz durch.“",
            "„Wenn unterwegs etwas ist: Hier ist meine Nummer.“",
        ],
    },
    # ---------------- Führung
    {
        "id": "erwartungen", "thema": "fuehrung", "titel": "Klare Rollen und Erwartungen",
        "mitglieder": ["wickman", "covey", "sinek"],
        "kernidee": "Wenn jemand nicht liefert, liegt es selten am Willen allein. Meist ist unklar, was erwartet "
                    "wird, oder jemand sitzt auf dem falschen Platz. Erst Klarheit schaffen, dann Leistung "
                    "einfordern.",
        "schritte": [
            "Klären: Ist die Erwartung aufgeschrieben – mit Ergebnis, Termin und Maßstab?",
            "Prüfen (nach Wickman): Versteht die Person die Aufgabe? Will sie sie? Kann sie sie (Zeit, Wissen, "
            "Werkzeug)?",
            "Unter vier Augen ansprechen: Beobachtung statt Vorwurf, dann zuhören.",
            "Gemeinsam vereinbaren, was sich ändert – mit Datum für das nächste Gespräch.",
            "Nachhalten. Wenn es dauerhaft nicht passt: über Platz oder Rolle sprechen.",
        ],
        "beispiel": "Ein Monteur dokumentiert Garantiearbeiten unvollständig. Im Gespräch zeigt sich: Er weiß nicht, "
                    "welche Fotos der Hersteller verlangt. Der Teamleiter zeigt ihm die Anleitung im Wissen, sie "
                    "vereinbaren eine Checkliste. Nach vier Wochen fehlt nichts mehr.",
        "fehler": [
            "Erwartungen nur denken, nicht aussprechen.",
            "Vor dem Team kritisieren.",
            "Jahrelang nichts sagen und dann explodieren.",
        ],
        "formulierungen": [
            "„Mir ist aufgefallen, dass … Wie siehst du das?“",
            "„Was brauchst du, damit das klappt?“",
            "„Lass uns in zwei Wochen noch einmal draufschauen.“",
        ],
    },
    {
        "id": "wochenrunde", "thema": "fuehrung", "titel": "Wochenrunde und Scorecard",
        "mitglieder": ["wickman", "harnish"],
        "kernidee": "Eine gute Wochenrunde ist kurz, immer gleich aufgebaut und löst Probleme. Die Scorecard "
                    "zeigt mit wenigen Zahlen, wo es klemmt – bevor es teuer wird.",
        "schritte": [
            "Feste Zeit und feste Reihenfolge: Zahlen, Quartalsziele, Kunden- und Teamthemen, Probleme, Aufgaben.",
            "Zahlen nur kurz: im Plan oder nicht? Wenn nicht, wird es ein Problem für die Liste.",
            "Probleme der Reihe nach: benennen, kurz besprechen, lösen – mit Aufgabe, Namen und Datum.",
            "Aufgaben der letzten Woche abfragen: erledigt oder nicht.",
            "Pünktlich enden. Unter „Besprechungen“ in ODIN festhalten.",
        ],
        "beispiel": "In der Wochenrunde fällt auf: Beratungstermine sind drei Wochen in Folge unter Plan. Statt zu "
                    "diskutieren, wird das Problem benannt (zu wenig Termine am Wochenende) und gelöst: Samstags "
                    "gibt es feste Beratungstermine. Zwei Wochen später ist die Zahl im Plan.",
        "fehler": [
            "Berichte vorlesen statt Probleme lösen.",
            "Jede Woche dieselbe Diskussion ohne Entscheidung.",
            "Zu viele Zahlen, die niemand versteht.",
        ],
        "formulierungen": [
            "„Was ist das eigentliche Problem?“",
            "„Wer übernimmt das, bis wann?“",
        ],
    },
    {
        "id": "warumfuehren", "thema": "fuehrung", "titel": "Mit dem Warum führen",
        "mitglieder": ["sinek", "harnish", "covey"],
        "kernidee": "In der Hochsaison sind alle müde. Was trägt, ist nicht noch eine Regel, sondern ein Grund: "
                    "Wir sorgen dafür, dass Familien sorgenfrei unterwegs sind. Wer das Warum kennt, entscheidet "
                    "auch ohne Chef richtig.",
        "schritte": [
            "Das Warum in einem Satz formulieren und oft wiederholen.",
            "Geschichten von Kunden erzählen, denen wir geholfen haben.",
            "Erfolge sichtbar machen – auch kleine.",
            "Als Führung zuerst für das Team einstehen und mit anpacken.",
            "Fehler ansprechen dürfen, ohne Angst.",
        ],
        "beispiel": "Im Juni liest der Chef in der Morgenrunde die Mail einer Familie vor, die dank schneller Hilfe "
                    "der Werkstatt doch noch in den Urlaub fahren konnte. Danach fragt er: „Was brauchen wir, damit "
                    "uns das diese Woche noch zweimal gelingt?“",
        "fehler": [
            "Nur über Zahlen sprechen.",
            "Lob nur einmal im Jahr.",
            "Selbst nicht das tun, was man vom Team verlangt.",
        ],
        "formulierungen": [
            "„Für wen machen wir das hier eigentlich?“",
            "„Danke – das war für den Kunden der Unterschied.“",
        ],
    },
]

# ---------------------------------------------------------------- Frag den Beirat: Situationen
# perspektiven: (Mitglied, Kern, nächste Schritte, Formulierungen)

SITUATIONEN = [
    {
        "id": "zuteuer", "thema": "verkauf", "titel": "Kunde sagt: zu teuer",
        "lage": "Der Kunde mag das Fahrzeug, aber beim Preis kommt: „Das ist mir zu teuer.“",
        "stichworte": ["zu teuer", "teuer", "preis", "zu viel", "kostet zu viel", "nicht leisten", "preiseinwand",
                       "zu hoch"],
        "module": ["preisgespraech", "einwaende", "finanzierung"],
        "perspektiven": [
            ("voss", "Erst verstehen, was „zu teuer“ wirklich heißt – nicht verteidigen.",
             ["Gefühl benennen: „Es klingt so, als hätten Sie mit einem anderen Betrag gerechnet.“",
              "Schweigen und zuhören.", "Kalibriert nachfragen: „Wie kommen Sie auf den Betrag, der passen würde?“"],
             ["„Es klingt so, als wäre das mehr, als Sie eingeplant hatten.“",
              "„Was müsste passieren, damit es sich für Sie richtig anfühlt?“"]),
            ("hormozi", "Den Wert erhöhen statt den Preis senken.",
             ["Die Wünsche aus der Bedarfsanalyse noch einmal nennen.",
              "Zeigen, was im Paket steckt: Übergabe, Werkstatt vor Ort, montiertes Zubehör, Ansprechpartner.",
              "Wenn nötig das Paket verändern (Ausstattung, Zahlweise) – nicht den Preis."],
             ["„Lassen Sie uns kurz schauen, was in dem Preis alles für Sie drin ist.“"]),
            ("kreuter", "„Zu teuer“ ist ein Einwand, kein Nein – klären, ob es der einzige ist, dann zurück zum "
                        "Abschluss.",
             ["Nachfragen: „Zu teuer im Vergleich wozu?“", "Prüfen: „Ist der Preis der einzige Punkt?“",
              "Nach der Klärung erneut nach der Entscheidung fragen."],
             ["„Mal angenommen, wir bekommen das mit dem Preis gelöst – wäre das dann Ihr Fahrzeug?“"]),
        ],
    },
    {
        "id": "ueberlegen", "thema": "verkauf", "titel": "Kunde will es sich noch überlegen",
        "lage": "Gutes Gespräch, ausführliche Besichtigung – und dann: „Wir überlegen uns das noch mal.“",
        "stichworte": ["überlegen", "ueberlegen", "drüber schlafen", "noch nicht entscheiden", "melden uns",
                       "bedenkzeit", "zögert", "unentschlossen", "nochmal nachdenken"],
        "module": ["abschluss", "nachfassen", "einwaende"],
        "perspektiven": [
            ("kreuter", "Hinter „Ich überlege noch“ steckt fast immer ein unausgesprochener Grund. Freundlich "
                        "nachfragen, dann einen festen nächsten Termin vereinbaren.",
             ["Fragen: „Was genau möchten Sie noch überlegen?“", "Den Punkt klären, wenn möglich sofort.",
              "Sonst einen konkreten Rückruf-Termin festmachen – mit Datum und Uhrzeit."],
             ["„Gern. Damit ich Ihnen helfen kann: Was ist der Punkt, über den Sie noch nachdenken?“",
              "„Darf ich Sie am Donnerstag um 17 Uhr anrufen?“"]),
            ("voss", "Ein Nein gibt Sicherheit. Statt auf ein Ja zu drängen, eine Frage stellen, auf die der Kunde "
                     "Nein sagen kann.",
             ["Die Sorge benennen: „Es scheint, als wäre noch etwas offen.“",
              "Nein-Frage stellen und zuhören."],
             ["„Ist es eine schlechte Idee, die offenen Punkte jetzt gleich gemeinsam durchzugehen?“",
              "„Haben Sie das Gefühl, dass etwas Wichtiges noch nicht angesprochen wurde?“"]),
            ("hormozi", "Unsicherheit ist das größte Kaufhindernis. Risiko abnehmen, wo es ehrlich geht.",
             ["Fragen, wovor der Kunde Angst hat (Fehlkauf, Technik, Finanzierung).",
              "Sicherheit geben: klarer Ablauf, Übergabe mit Probenacht, fester Ansprechpartner. Reservieren "
              "gehört nicht dazu (Hausregel VERKAUF-002)."],
             ["„Was müsste passieren, damit Sie sich ganz sicher fühlen?“"]),
        ],
    },
    {
        "id": "rabatt", "thema": "verhandeln", "titel": "Kunde will Rabatt",
        "lage": "„Was geht noch am Preis?“ oder „Bei Barzahlung gibt’s doch sicher Nachlass.“",
        "stichworte": ["rabatt", "nachlass", "was geht noch", "skonto", "barzahlung", "prozente", "handeln",
                       "verhandeln", "runter mit dem preis"],
        "module": ["verhandeln", "preisgespraech"],
        "perspektiven": [
            ("voss", "Nicht sofort gegenbieten. Erst verstehen, was dem Kunden wichtig ist – oft ist es das Gefühl, "
                     "fair behandelt zu werden.",
             ["Nachfragen: „Was wäre für Sie ein faires Ergebnis?“",
              "Labeling: „Es klingt, als wäre Ihnen wichtig, kein schlechtes Geschäft zu machen.“",
              "Zugeständnis nur gegen Gegenleistung (z. B. schnelle Entscheidung, Anzahlung)."],
             ["„Wie soll ich das machen, ohne dass es gegenüber anderen Kunden unfair wird?“"]),
            ("buffett", "Preis ist, was du zahlst; Wert ist, was du bekommst. Wer am Preis dreht, sollte zuerst "
                        "fragen, ob der Wert stimmt.",
             ["Den Wert erklären, bevor über Nachlass geredet wird.",
              "Grenze vorher festlegen und dabei bleiben – unser Ruf hängt an ehrlichen Preisen."],
             ["„Unsere Preise sind so gemacht, dass jeder Kunde fair behandelt wird.“"]),
            ("hormozi", "Lieber etwas dazugeben, das für den Kunden viel wert ist und uns wenig kostet, als Geld "
                        "nachzulassen.",
             ["Prüfen: Was wäre ein echter Mehrwert? (Gasflasche voll, Einweisung, erster Service, Zubehör)",
              "Mehrwert anbieten statt Rabatt."],
             ["„Am Preis kann ich nichts machen – aber ich kann dafür sorgen, dass Sie direkt startklar sind.“"]),
        ],
    },
    {
        "id": "internetpreis", "thema": "verkauf", "titel": "Kunde hat ein günstigeres Angebot",
        "lage": "„Beim Händler im Nachbarort / im Internet ist er 2.000 € günstiger.“",
        "stichworte": ["günstiger", "guenstiger", "internet", "konkurrenz", "anderer händler", "wettbewerb",
                       "billiger", "vergleichsangebot", "mobile.de", "angebot vom"],
        "module": ["preisgespraech", "verhandeln"],
        "perspektiven": [
            ("hormozi", "Vergleichbar sind nur gleiche Angebote. Mach dein Angebot schwer vergleichbar – durch "
                        "echten Mehrwert.",
             ["Gemeinsam das andere Angebot ansehen: Ausstattung, Übergabe, Garantie, Entfernung.",
              "Zusammenrechnen, was beim anderen Angebot noch fehlt.",
              "Unser Paket klar zeigen."],
             ["„Darf ich mir das Angebot mal mit Ihnen anschauen? Dann vergleichen wir Äpfel mit Äpfeln.“"]),
            ("voss", "Den Druck ernst nehmen, aber nicht in die Verteidigung gehen.",
             ["Labeling: „Es klingt, als würden Sie lieber bei uns kaufen, wenn es passt.“",
              "Kalibriert fragen: „Was ist Ihnen außer dem Preis noch wichtig?“"],
             ["„Was hat Sie trotz des günstigeren Angebots wieder zu uns geführt?“"]),
            ("buffett", "Ein Geschäft, das den Ruf kostet, ist kein gutes Geschäft.",
             ["Nicht jeden Preis mitgehen.", "Freundlich bleiben – der Kunde kommt vielleicht zum Service wieder."],
             ["„Wenn es für Sie nur um den Preis geht, verstehe ich das. Unsere Tür bleibt offen.“"]),
        ],
    },
    {
        "id": "inzahlung", "thema": "verkauf", "titel": "Kunde will mehr für seinen Gebrauchten",
        "lage": "Der Kunde erwartet für sein altes Fahrzeug deutlich mehr, als wir zahlen können.",
        "stichworte": ["inzahlungnahme", "in zahlung", "altes fahrzeug", "gebrauchten", "mehr für", "ankaufspreis",
                       "eintausch", "wohnwagen abgeben"],
        "module": ["inzahlungnahme", "ankauf"],
        "perspektiven": [
            ("voss", "Die Erwartung kommt meist aus einem Gefühl oder einer Internet-Anzeige. Erst verstehen, dann "
                     "erklären.",
             ["Fragen: „Woher kommt Ihre Vorstellung?“", "Die Erinnerungen wertschätzen.",
              "Die eigene Rechnung offenlegen."],
             ["„Es klingt, als hätten Sie mit deutlich mehr gerechnet.“"]),
            ("munger", "Anreize prüfen: Ein zu hoher Ankaufspreis „rettet“ heute das Geschäft und erzeugt morgen "
                       "einen Langsteher.",
             ["Rückwärts rechnen: realistischer Verkaufspreis minus Kosten minus Marge.",
              "Nicht Rabatt beim Neuen als Ankaufspreis verstecken."],
             []),
            ("kreuter", "Neues Fahrzeug und Inzahlungnahme getrennt besprechen, dann die Differenz.",
             ["Erst Einigung aufs neue Fahrzeug, dann aufs alte.",
              "Alternativen anbieten: Privatverkauf, späterer Übergabetermin."],
             ["„Lassen Sie uns erst das neue Fahrzeug festmachen, dann schauen wir uns Ihren Wohnwagen in Ruhe an.“"]),
        ],
    },
    {
        "id": "ankaufen", "thema": "entscheiden", "titel": "Soll ich dieses Gebrauchtfahrzeug ankaufen?",
        "lage": "Ein Gebrauchtes wird angeboten. Der Preis wirkt gut – aber passt es wirklich?",
        "stichworte": ["ankaufen", "ankauf", "gebrauchtfahrzeug", "gebrauchtwagen", "einkaufen", "zukaufen",
                       "gebraucht kaufen", "fahrzeug kaufen"],
        "module": ["ankauf", "entscheiden"],
        "perspektiven": [
            ("buffett", "Nur kaufen, was du kennst, und nur mit Sicherheitsabstand.",
             ["Kompetenzkreis prüfen: Kennen wir Marke, Baureihe, Schwachstellen?",
              "Höchsten Ankaufspreis rückwärts rechnen – mit Puffer für Überraschungen.",
              "Im Zweifel: nein."],
             []),
            ("munger", "Umkehren: Was würde dieses Fahrzeug zum Langsteher machen?",
             ["Grundriss, Saison, Zustand, Preisniveau prüfen.", "Standkosten einrechnen (Zinsuhr in ODIN).",
              "Nicht aus Gefälligkeit kaufen."],
             []),
            ("harnish", "Zahlen statt Bauchgefühl: Wie haben sich ähnliche Ankäufe entwickelt?",
             ["Standtage ähnlicher Fahrzeuge im Bestand ansehen.", "Entscheidung und Begründung festhalten."],
             []),
        ],
    },
    {
        "id": "finanzierungbar", "thema": "verkauf", "titel": "Finanzierung oder Barkauf empfehlen?",
        "lage": "Der Kunde fragt, was besser ist: bar bezahlen oder finanzieren.",
        "stichworte": ["finanzierung", "finanzieren", "barkauf", "bar bezahlen", "kredit", "rate", "monatsrate",
                       "zahlweise", "leasing"],
        "module": ["finanzierung"],
        "perspektiven": [
            ("buffett", "Keine Schulden, die den Kunden nachts wach halten. Und keine Kaufentscheidung, die ihm "
                        "jede Rücklage nimmt.",
             ["Beides ehrlich nebeneinanderstellen: Gesamtkosten, Rücklage, Sicherheit.",
              "Lieber kleineres Fahrzeug als zu hohe Belastung."],
             []),
            ("hormozi", "Die Zahlweise ist Teil des Angebots: Sie entscheidet, wie leicht der Kunde Ja sagen kann.",
             ["Rate und Gesamtkosten zeigen.", "Erklären, wofür eine Rücklage gut ist."],
             ["„Soll ich Ihnen beide Wege nebeneinander zeigen?“"]),
            ("covey", "Win-win: Die Empfehlung muss zum Kunden passen, nicht zu unserem Monatsziel.",
             ["Fragen: Was ist dem Kunden wichtiger – Sicherheit, Flexibilität, keine Zinsen?",
              "Die Entscheidung beim Kunden lassen."],
             ["„Was ist Ihnen wichtiger: keine Zinsen zahlen oder eine Rücklage behalten?“"]),
        ],
    },
    {
        "id": "reklamationuebergabe", "thema": "service", "titel": "Reklamation nach der Übergabe",
        "lage": "Kurz nach der Übergabe meldet sich der Kunde verärgert: Etwas funktioniert nicht.",
        "stichworte": ["reklamation", "beschwerde", "kaputt", "funktioniert nicht", "mangel", "ärger", "aerger",
                       "verärgert", "wütend", "undicht", "nach übergabe", "nach der übergabe"],
        "module": ["reklamation", "fahrzeuguebergabe"],
        "perspektiven": [
            ("voss", "Erst das Gefühl, dann die Sache.",
             ["Ausreden lassen.", "Gefühl benennen.", "Dann Fakten aufnehmen: was, seit wann, Fotos."],
             ["„Das ist ärgerlich – gerade jetzt, wo Sie losfahren wollten.“"]),
            ("covey", "Erst verstehen, dann verstanden werden – und eine Lösung, mit der beide leben können.",
             ["Zusammenfassen, was du verstanden hast.", "Gemeinsam die Lösung suchen (Termin, Ersatz, Hilfe "
              "unterwegs)."],
             ["„Damit ich sicher bin, dass ich Sie richtig verstehe: …“"]),
            ("buffett", "Der Ruf ist wichtiger als die Kosten der einzelnen Reparatur.",
             ["Nur zusagen, was wir halten können – und es dann halten.",
              "Bei rechtlichen Fragen (Gewährleistung) früh die Geschäftsführung einbinden; Rechtsfälle in ODIN "
              "nutzen."],
             []),
        ],
    },
    {
        "id": "verzettelt", "thema": "struktur", "titel": "Ich verzettele mich",
        "lage": "Zu viel gleichzeitig: Telefon, Kunden, Zettel, Mails – und am Abend ist nichts fertig.",
        "stichworte": ["verzettel", "zu viel", "überfordert", "ueberfordert", "chaos", "stress", "keine zeit",
                       "organisieren", "durcheinander", "vergesse", "zettel", "priorität", "prioritaeten"],
        "module": ["kopffrei", "wochenplanung"],
        "perspektiven": [
            ("allen", "Alles raus aus dem Kopf und an einen Ort. Dann für jedes den nächsten Schritt.",
             ["20 Minuten: alles aufschreiben, was offen ist.", "Zwei-Minuten-Sachen sofort erledigen.",
              "Rest als Aufgaben mit nächstem Schritt in ODIN oder Kalender."],
             []),
            ("covey", "Das Wichtige zuerst – sonst frisst das Dringende alles.",
             ["Die drei wichtigsten Ergebnisse der Woche festlegen.", "Feste Zeitblöcke dafür eintragen."],
             []),
            ("harnish", "Rhythmus schafft Ruhe.",
             ["Täglich ein kurzer Blick am Morgen: Was ist heute das Wichtigste?",
              "Im Team kurz abstimmen, wer was übernimmt."],
             []),
        ],
    },
    {
        "id": "liefertnicht", "thema": "fuehrung", "titel": "Mitarbeiter liefert nicht",
        "lage": "Jemand im Team hält Termine nicht ein oder die Qualität stimmt nicht.",
        "stichworte": ["liefert nicht", "mitarbeiter", "kollege", "leistung", "unzuverlässig", "unzuverlaessig",
                       "hält sich nicht", "nicht erledigt", "kritikgespräch", "fehlt motivation"],
        "module": ["erwartungen", "wochenrunde"],
        "perspektiven": [
            ("wickman", "Prüfe: Versteht er die Aufgabe, will er sie, kann er sie? Und passt er zu unseren Werten?",
             ["Erwartung schriftlich klären (Ergebnis, Termin, Maßstab).", "Unter vier Augen ansprechen.",
              "Nachhalten – und wenn es dauerhaft nicht passt, über die Rolle reden."],
             ["„Mir ist aufgefallen, dass … Wie siehst du das?“"]),
            ("covey", "Erst verstehen: Vielleicht gibt es einen Grund, den du nicht kennst.",
             ["Zuhören, ohne zu unterbrechen.", "Gemeinsam vereinbaren, was sich ändert."],
             ["„Was brauchst du, damit das klappt?“"]),
            ("sinek", "Leute geben mehr, wenn sie sich sicher fühlen und wissen, wofür sie arbeiten.",
             ["Das Warum der Aufgabe erklären.", "Fehler ansprechen dürfen, ohne Angst."],
             []),
        ],
    },
    {
        "id": "entscheidung", "thema": "entscheiden", "titel": "Wie entscheide ich mich?",
        "lage": "Eine schwierige Entscheidung steht an – und du drehst dich im Kreis.",
        "stichworte": ["entscheiden", "entscheidung", "entscheide", "unsicher", "abwägen", "abwaegen", "soll ich",
                       "zweifel", "richtig entscheiden", "dilemma"],
        "module": ["entscheiden"],
        "perspektiven": [
            ("munger", "Umkehren: Wie würde es garantiert schiefgehen? Vermeide genau das.",
             ["Liste: Was müsste passieren, damit es schiefgeht?", "Was davon kann ich verhindern?"],
             []),
            ("buffett", "Bleib in deinem Kompetenzkreis – und hol dir Rat, wo du ihn verlässt.",
             ["Ehrlich fragen: Kenne ich mich damit aus?", "Bei großen, nicht umkehrbaren Fragen: Zeit nehmen."],
             []),
            ("covey", "Beginne mit dem Ende im Sinn.",
             ["Was soll in einem Jahr anders sein?", "10/10/10: Wie fühle ich mich in 10 Minuten, 10 Monaten, "
              "10 Jahren?"],
             []),
        ],
    },
    {
        "id": "wenigkunden", "thema": "verkauf", "titel": "Wenig Anfragen, Ausstellung leer",
        "lage": "Ruhige Wochen: kaum Anfragen, wenig Besucher.",
        "stichworte": ["wenig kunden", "keine kunden", "keine anfragen", "ruhig", "leer", "akquise",
                       "neukunden", "flaute", "nebensaison", "winter"],
        "module": ["akquise", "nachfassen"],
        "perspektiven": [
            ("kreuter", "Nicht warten, sondern anrufen.",
             ["Täglich feste Zeit für Kontakte blocken.", "Alte Anfragen und Bestandskunden mit Anlass anrufen.",
              "Kontakte zählen."],
             ["„Sie hatten im Frühjahr nach … gefragt – jetzt haben wir genau so eins da.“"]),
            ("hormozi", "Mehr Kontakte, bessere Angebote, mehr Nachfassen.",
             ["Ein Winterangebot schnüren (z. B. Zubehör-Einbau mit Rabatt auf die Montage).",
              "Bestehende Kunden um Empfehlungen bitten."],
             []),
            ("sinek", "Menschen kommen wegen des Warums.",
             ["Geschichten zufriedener Kunden erzählen (Bewertungen, Fotos – mit Einwilligung)."],
             []),
        ],
    },
    {
        "id": "nurgucken", "thema": "verkauf", "titel": "Kunde will nur mal gucken",
        "lage": "Auf die Frage, ob du helfen kannst: „Nein danke, wir gucken nur.“",
        "stichworte": ["nur gucken", "nur schauen", "nur mal gucken", "umschauen", "keine beratung",
                       "ansprechen", "begrüßung", "erster kontakt"],
        "module": ["bedarfsanalyse"],
        "perspektiven": [
            ("kreuter", "Akzeptieren, aber Tür offenhalten.",
             ["Freundlich Raum lassen.", "Nach ein paar Minuten mit einer offenen Frage wiederkommen."],
             ["„Gern! Eine Frage nur: Wohnwagen oder Reisemobil – was reizt Sie mehr?“"]),
            ("voss", "Ein Nein gibt Sicherheit. Nimm den Druck raus.",
             ["Nein-Frage stellen."],
             ["„Wäre es schlimm, wenn ich Ihnen kurz zeige, wo die Fahrzeuge mit Einzelbetten stehen?“"]),
            ("sinek", "Erzähl, warum wir machen, was wir machen – nicht was im Fahrzeug ist.",
             ["Statt Technik: Frage nach dem Urlaub, den sie sich vorstellen."],
             ["„Wohin soll die erste Reise gehen?“"]),
        ],
    },
    {
        "id": "partner", "thema": "verkauf", "titel": "Kunde muss erst mit Partner sprechen",
        "lage": "„Das muss ich erst mit meiner Frau / meinem Mann besprechen.“",
        "stichworte": ["partner", "frau", "mann", "ehefrau", "ehemann", "besprechen", "mitentscheiden",
                       "nicht allein", "familie fragen"],
        "module": ["abschluss", "bedarfsanalyse"],
        "perspektiven": [
            ("voss", "Ernst nehmen und den Partner ins Boot holen.",
             ["Nachfragen, was dem Partner wichtig ist.", "Gemeinsamen Termin anbieten."],
             ["„Was wird Ihr Partner als Erstes fragen?“"]),
            ("kreuter", "Am besten früh klären, wer entscheidet – und einen festen Termin für beide machen.",
             ["In der Bedarfsanalyse fragen: „Wer entscheidet mit?“", "Termin für eine gemeinsame Besichtigung "
              "festmachen."],
             ["„Wann passt es Ihnen beiden, sich das Fahrzeug gemeinsam in Ruhe anzusehen – Samstag Vormittag?“"]),
        ],
    },
    {
        "id": "reservieren", "thema": "verkauf", "titel": "Kunde möchte reservieren oder Probe fahren",
        "lage": "„Können Sie ihn mir bis Samstag zurücklegen?“ oder „Kann ich den neuen mal Probe fahren?“",
        "stichworte": ["reservieren", "reservierung", "zurücklegen", "zurückstellen", "festhalten", "probefahrt",
                       "testfahrt", "probe fahren", "übers wochenende"],
        "module": ["besichtigung", "abschluss", "einwaende"],
        "perspektiven": [
            ("voss", "Erst die Sorge hinter dem Wunsch verstehen – dann ehrlich sagen, wie wir es halten.",
             ["Nachfragen, was bis dahin noch geklärt werden soll.",
              "Die Hausregeln freundlich erklären: keine Reservierungen, bei Neufahrzeugen keine Probefahrt."],
             ["„Es klingt, als wäre noch eine Frage offen – welche ist es?“"]),
            ("kreuter", "Der Wunsch nach Aufschub ist ein Einwand: den offenen Punkt jetzt klären und den nächsten "
                        "Schritt festmachen.",
             ["Besichtigung und Gespräch am Fahrzeug anbieten.",
              "Ruft ein Kunde unmittelbar vor seiner Anfahrt an: das Fahrzeug nur für die bestätigte Fahrtzeit "
              "zurückhalten (Hausregel VERKAUF-002)."],
             ["„Reservierungen sind bei uns leider nicht vorgesehen – auch nicht übers Wochenende. Wenn noch Fragen "
              "offen sind, klären wir sie gern jetzt gleich gemeinsam.“"]),
        ],
    },
    {
        "id": "nichtmeldet", "thema": "verkauf", "titel": "Angebot raus, Kunde meldet sich nicht",
        "lage": "Das Angebot ist seit Tagen beim Kunden – keine Antwort.",
        "stichworte": ["meldet sich nicht", "keine antwort", "nachfassen", "nachhaken", "angebot raus",
                       "funkstille", "rückruf", "rueckruf", "ghosting"],
        "module": ["nachfassen"],
        "perspektiven": [
            ("kreuter", "Nachfassen ist Service, nicht Aufdringlichkeit – mit Anlass.",
             ["Anrufen statt mailen.", "Etwas Neues mitbringen.", "Nach drei Versuchen freundlich abschließen."],
             ["„Ich hatte versprochen, mich zu melden – und ich habe eine Neuigkeit.“"]),
            ("voss", "Eine Frage, auf die man Nein sagen kann, holt Stille zurück ins Gespräch.",
             ["Kurze Nachricht mit Nein-Frage."],
             ["„Haben Sie das Projekt Wohnmobil aufgegeben?“"]),
            ("allen", "Kein Nachfassen ohne festen Termin im Kalender.",
             ["Jedes offene Angebot bekommt einen nächsten Schritt mit Datum."],
             []),
        ],
    },
    {
        "id": "zubehoeranbieten", "thema": "verkauf", "titel": "Zubehör anbieten, ohne aufdringlich zu sein",
        "lage": "Du möchtest Zubehör anbieten, aber nicht wie ein Vertreter wirken.",
        "stichworte": ["zubehör", "zubehoer", "upselling", "mehrverkauf", "markise", "solar", "fahrradträger",
                       "zusatz", "aufdringlich", "cross selling"],
        "module": ["zubehoer"],
        "perspektiven": [
            ("hormozi", "Zubehör ist Teil eines besseren Angebots – wenn es ein echtes Problem des Kunden löst.",
             ["Aus der Bedarfsanalyse ableiten.", "Nutzen in einem Satz.", "Preis inklusive Montage nennen."],
             ["„Sie hatten erzählt, dass … – dafür gibt es eine einfache Lösung.“"]),
            ("buffett", "Langfristig zählt Vertrauen mehr als der einzelne Zusatzverkauf.",
             ["Nur anbieten, was passt.", "Nein akzeptieren und für später notieren."],
             []),
        ],
    },
    {
        "id": "lieferverzug", "thema": "service", "titel": "Fahrzeug kommt später als zugesagt",
        "lage": "Der Hersteller verschiebt die Lieferung, der Kunde hat schon den Urlaub gebucht.",
        "stichworte": ["lieferverzug", "verspätung", "verspaetung", "später", "spaeter", "liefertermin",
                       "verschoben", "kommt nicht", "lieferung"],
        "module": ["reklamation", "verhandeln"],
        "perspektiven": [
            ("voss", "Vorwürfe vorwegnehmen, bevor der Kunde sie ausspricht.",
             ["Früh anrufen, nicht warten.", "Die Enttäuschung aussprechen."],
             ["„Sie werden jetzt denken, dass wir uns nicht genug gekümmert haben – und ich verstehe das.“"]),
            ("covey", "Proaktiv: Auf das konzentrieren, was wir beeinflussen können.",
             ["Lösungen suchen: Mietfahrzeug, Vorführfahrzeug, früherer Termin für einen Teil."],
             ["„Was können wir tun, damit Ihr Urlaub trotzdem klappt?“"]),
            ("buffett", "Offen sein, auch wenn es unangenehm ist – der Ruf hängt daran.",
             ["Nichts beschönigen, nichts zusagen, was der Hersteller nicht bestätigt hat."],
             []),
        ],
    },
    {
        "id": "saisondruck", "thema": "struktur", "titel": "Saisonstart: alle wollen gleichzeitig",
        "lage": "Vor Ostern wollen alle ihre Übergabe, Gasprüfung und Reparatur – sofort.",
        "stichworte": ["saison", "saisonstart", "ostern", "werkstatt voll", "termine", "drängeln", "draengeln",
                       "engpass", "kapazität", "kapazitaet", "alle gleichzeitig"],
        "module": ["wochenplanung", "verhandeln"],
        "perspektiven": [
            ("harnish", "Den Engpass benennen und früh planen.",
             ["Vor der Saison: Wo wird es eng?", "Tägliche Kurzabstimmung im Team."],
             []),
            ("covey", "Das Wichtige zuerst: Übergaben und Sicherheit vor Wunschterminen.",
             ["Prioritäten klar machen und kommunizieren."],
             []),
            ("voss", "Mit kalibrierten Fragen statt Nein.",
             ["Gemeinsam mit dem Kunden eine Lösung suchen."],
             ["„Wie können wir das lösen, wenn die Werkstatt bis zum 20. voll ist?“"]),
        ],
    },
    {
        "id": "bankgespraech", "thema": "verhandeln", "titel": "Gespräch mit Hersteller oder Bank steht an",
        "lage": "Konditionen, Linie, Bonus oder Gutschrift – ein wichtiges Gespräch steht an.",
        "stichworte": ["bank", "hersteller", "lieferant", "linie", "konditionen", "bonus", "gutschrift",
                       "verhandlung", "jahresgespräch", "kreditlinie"],
        "module": ["partnergespraech", "verhandeln"],
        "perspektiven": [
            ("voss", "Verstehen, was das Gegenüber intern vertreten muss.",
             ["Kalibrierte Fragen vorbereiten."],
             ["„Was müssten Sie sehen, damit Sie das intern durchbekommen?“"]),
            ("munger", "Anreize verstehen: Wofür wird der Gesprächspartner belohnt?",
             ["Ziele des Gegenübers recherchieren (Stückzahlen, Risiko)."],
             []),
            ("buffett", "Langfristige Partnerschaft vor kurzfristigem Vorteil.",
             ["Fair bleiben.", "Vereinbarungen schriftlich festhalten."],
             []),
        ],
    },
    {
        "id": "neuerkollege", "thema": "fuehrung", "titel": "Neuer Kollege fängt an",
        "lage": "Jemand Neues startet im Team – wie gelingt ein guter Anfang?",
        "stichworte": ["neuer kollege", "neue kollegin", "einarbeitung", "einarbeiten", "neuer mitarbeiter",
                       "erster tag", "onboarding", "azubi"],
        "module": ["erwartungen", "teamuebergabe"],
        "perspektiven": [
            ("wickman", "Von Tag eins klar: Rolle, Verantwortung, woran Erfolg gemessen wird.",
             ["Einarbeitungsplan unter „Wissen & Einarbeitung“ starten.",
              "Nach 30 und 90 Tagen Gespräch einplanen."],
             []),
            ("sinek", "Erzähl das Warum, bevor du das Was erklärst.",
             ["Am ersten Tag: Warum gibt es uns, für wen machen wir das?"],
             []),
            ("covey", "Mit dem Ziel beginnen: Was soll der Neue nach 90 Tagen allein können?",
             ["Ziele gemeinsam festlegen."],
             []),
        ],
    },
    {
        "id": "besprechungzaeh", "thema": "fuehrung", "titel": "Besprechungen sind zäh",
        "lage": "Lange Runden, viel Gerede, wenig Ergebnis.",
        "stichworte": ["besprechung", "meeting", "wochenrunde", "zäh", "zaeh", "lang", "nichts bringt",
                       "teamrunde", "sitzung"],
        "module": ["wochenrunde"],
        "perspektiven": [
            ("wickman", "Feste Reihenfolge, feste Zeit – und Probleme lösen statt besprechen.",
             ["Ablauf: Zahlen, Ziele, Themen, Probleme, Aufgaben.", "Pro Problem: benennen, besprechen, lösen."],
             []),
            ("harnish", "Rhythmus statt Marathon: kurz, aber regelmäßig.",
             ["Täglich zehn Minuten, wöchentlich eine Stunde."],
             []),
        ],
    },
    {
        "id": "fehlerpassiert", "thema": "service", "titel": "Mir ist ein Fehler passiert",
        "lage": "Eine falsche Zusage, ein vergessener Rückruf, ein falsch bestelltes Teil.",
        "stichworte": ["fehler", "falsch", "vergessen", "versehen", "verbockt", "falsche zusage", "peinlich",
                       "entschuldigen"],
        "module": ["reklamation", "kopffrei"],
        "perspektiven": [
            ("buffett", "Fehler schnell und offen zugeben – Vertuschen kostet mehr.",
             ["Sofort sagen, was passiert ist.", "Lösung anbieten."],
             []),
            ("covey", "Verantwortung übernehmen statt erklären, wer schuld ist.",
             ["Konzentrieren auf das, was du jetzt tun kannst."],
             ["„Das war mein Fehler. Ich kümmere mich darum, dass …“"]),
            ("voss", "Den Ärger des anderen aussprechen, bevor er es tut.",
             ["Vorwürfe vorwegnehmen."],
             ["„Sie werden zu Recht verärgert sein.“"]),
        ],
    },
    {
        "id": "langsteher", "thema": "entscheiden", "titel": "Fahrzeug steht zu lange – Preis runter?",
        "lage": "Ein Fahrzeug steht seit Monaten. Preis senken, warten oder anders vermarkten?",
        "stichworte": ["langsteher", "steht lange", "standzeit", "standtage", "preis senken", "nachlass",
                       "verkauft sich nicht", "ladenhüter"],
        "module": ["entscheiden", "preisgespraech"],
        "perspektiven": [
            ("munger", "Nicht am Einkaufspreis festhalten – was zählt, ist die Zukunft.",
             ["Kosten pro Tag ansehen (Zinsuhr & Langsteher in ODIN).", "Entscheiden nach dem, was ab heute "
              "sinnvoll ist."],
             []),
            ("buffett", "Lieber einmal klar entscheiden als jede Woche ein bisschen.",
             ["Ein deutlicher Schritt statt vieler kleiner Nachlässe."],
             []),
            ("hormozi", "Vielleicht ist nicht der Preis das Problem, sondern das Angebot.",
             ["Bessere Fotos, besserer Text, Paket mit Zubehör."],
             []),
        ],
    },
    {
        "id": "teammuede", "thema": "fuehrung", "titel": "Team ist müde in der Hochsaison",
        "lage": "Viel Arbeit, wenig Pause – die Stimmung kippt.",
        "stichworte": ["müde", "muede", "motivation", "stimmung", "hochsaison", "erschöpft", "erschoepft",
                       "frust", "überlastet", "ueberlastet"],
        "module": ["warumfuehren", "wochenrunde"],
        "perspektiven": [
            ("sinek", "Erinnere an das Warum.",
             ["Kundengeschichten erzählen.", "Sichtbar mit anpacken."],
             ["„Danke – das war für die Familie der Unterschied.“"]),
            ("harnish", "Rhythmus und eine klare Priorität geben Halt.",
             ["Täglich kurz abstimmen, was heute zählt."],
             []),
            ("covey", "Die Säge schärfen: Pausen sind kein Luxus.",
             ["Pausen und freie Tage schützen."],
             []),
        ],
    },
]

# ---------------------------------------------------------------- Gedanke des Tages (rotiert nach Datum)
# (Mitglied, Gedanke in eigenen Worten, Modul)

GEDANKEN = [
    ("buffett", "Bevor du über den Preis sprichst: Hat der Kunde den Wert schon gesehen?", "preisgespraech"),
    ("munger", "Frag dich heute einmal: Wie würde es garantiert schiefgehen? Und dann vermeide genau das.",
     "entscheiden"),
    ("hormozi", "Mach dein Angebot heute ein bisschen besser statt billiger.", "zubehoer"),
    ("kreuter", "Jedes Gespräch endet mit einem nächsten Termin – heute ohne Ausnahme.", "nachfassen"),
    ("wickman", "Hat jede wichtige Aufgabe heute genau einen Namen?", "erwartungen"),
    ("harnish", "Was ist heute das eine, das wirklich zählt?", "wochenplanung"),
    ("voss", "Benenne heute bei einem schwierigen Gespräch zuerst das Gefühl – dann die Sache.", "reklamation"),
    ("covey", "Höre heute einmal zu, um zu verstehen – nicht, um zu antworten.", "bedarfsanalyse"),
    ("allen", "Was du heute zusagst, schreibst du sofort auf. Der Kopf ist kein Notizbuch.", "kopffrei"),
    ("sinek", "Erzähl einem Kunden heute, warum wir das machen – nicht nur, was im Fahrzeug ist.", "warumfuehren"),
    ("kreuter", "Ein Einwand ist kein Nein. Frag nach, was dahintersteckt.", "einwaende"),
    ("buffett", "Ein guter Ruf braucht Jahre und ist in einem Moment weg. Sag heute nur zu, was du hältst.",
     "reklamation"),
    ("munger", "Wofür wird hier eigentlich wer belohnt? Wer das versteht, versteht das Verhalten.", "entscheiden"),
    ("hormozi", "Welche Sorge des Kunden kannst du heute beantworten, bevor er sie ausspricht?", "besichtigung"),
    ("voss", "Stell heute eine Wie-Frage statt eines Gegenangebots.", "verhandeln"),
    ("covey", "Plane heute zehn Minuten für etwas Wichtiges, das nicht dringend ist.", "wochenplanung"),
    ("allen", "Was in zwei Minuten erledigt ist, erledigst du jetzt.", "kopffrei"),
    ("wickman", "Ein Problem in der Runde wird gelöst – mit Aufgabe, Namen und Datum.", "wochenrunde"),
    ("kreuter", "Frag heute bei einem Kaufsignal klar nach dem Auftrag – und dann schweig.", "abschluss"),
    ("sinek", "Sag heute einem Kollegen, was seine Arbeit für den Kunden bedeutet hat.", "warumfuehren"),
    ("harnish", "Wo ist diese Woche unser Engpass – und wer kümmert sich darum?", "wochenplanung"),
    ("buffett", "Bleib bei dem, was du wirklich kennst – und frag, wo du es nicht tust.", "ankauf"),
    ("hormozi", "Mehr Kontakte, mehr Nachfassen: Ausdauer schlägt den perfekten Satz.", "akquise"),
    ("voss", "Ein Nein ist oft der Anfang eines ehrlichen Gesprächs.", "abschluss"),
    ("covey", "Was soll am Ende dieses Gesprächs herauskommen? Beginne mit dem Ende im Sinn.", "bedarfsanalyse"),
    ("allen", "Übergib heute nichts ohne nächsten Schritt und Datum.", "teamuebergabe"),
    ("munger", "Festhalten am Einkaufspreis ist ein Denkfehler. Zählt nur, was ab heute sinnvoll ist.", "ankauf"),
    ("kreuter", "Ruf heute einen Kunden an, dem du lange nicht geschrieben hast – mit einem guten Anlass.",
     "akquise"),
    ("sinek", "Die Übergabe ist der Moment, an den sich der Kunde in zehn Jahren erinnert.", "fahrzeuguebergabe"),
    ("hormozi", "Nimm dem Kunden heute ein Risiko ab, das ihn am Kauf hindert.", "finanzierung"),
]

# ---------------------------------------------------------------- Tagesfragen zu den Modulen
# (Kennung, Frage, Antworten – die richtige vorn –, Erklärung, Modul). Kategorie „Beirat“.

FRAGEN = [
    ("zuteuer1", "Ein Kunde sagt: „Das ist mir zu teuer.“ Was ist der beste erste Schritt?",
     ["Nachfragen: „Zu teuer im Vergleich wozu?“", "Sofort 5 % Rabatt anbieten",
      "Erklären, dass die Preise vom Hersteller kommen", "Ein günstigeres Fahrzeug holen"],
     "„Zu teuer“ heißt selten wirklich zu teuer. Erst verstehen, was gemeint ist (Vergleich, Rate, Unsicherheit), "
     "dann den Wert zeigen.", "preisgespraech"),
    ("zuteuer2", "Was zeigt ein sofortiger Rabatt nach „zu teuer“ dem Kunden oft?",
     ["Dass der Preis vorher nicht ehrlich war", "Dass wir besonders kundenfreundlich sind",
      "Dass das Fahrzeug Mängel hat", "Gar nichts – Rabatt ist immer gut"],
     "Wer sofort nachlässt, signalisiert: Da war noch Luft drin. Besser den Wert zeigen oder das Paket verändern.",
     "preisgespraech"),
    ("wert", "Nach Buffett: Was ist der Unterschied zwischen Preis und Wert?",
     ["Preis ist, was du zahlst – Wert ist, was du bekommst", "Es gibt keinen Unterschied",
      "Wert ist der Listenpreis, Preis der Hauspreis", "Wert ist nur für Investoren wichtig"],
     "Ein bekannter Leitsatz Buffetts (sinngemäß). Im Verkauf heißt das: erst den Wert sichtbar machen.",
     "preisgespraech"),
    ("value", "Was erhöht nach Hormozis „Value Equation“ den Wert eines Angebots?",
     ["Ein großes Traumergebnis und hohe Sicherheit, dass es klappt", "Ein möglichst langer Liefertermin",
      "Viel Aufwand für den Kunden", "Ein höherer Listenpreis"],
     "Wert steigt mit Traumergebnis und Erfolgssicherheit und sinkt mit Wartezeit und Aufwand für den Kunden.",
     "preisgespraech"),
    ("bedarf1", "Was kommt in einem guten Verkaufsgespräch zuerst?",
     ["Fragen stellen, wie und mit wem der Kunde reisen will", "Alle Extras des Fahrzeugs erklären",
      "Den Preis nennen", "Den Kaufvertrag vorbereiten"],
     "Erst fragen, dann zeigen: So zeigst du zwei, drei passende Fahrzeuge statt die ganze Reihe.",
     "bedarfsanalyse"),
    ("bedarf2", "Welche Frage ist eine offene Frage?",
     ["„Wie sieht ein perfekter Urlaub für Sie aus?“", "„Soll es ein Kastenwagen sein?“",
      "„Haben Sie einen Hund?“", "„Fahren Sie im Winter?“"],
     "Offene Fragen (wie, was, wer, warum) liefern Gründe und Geschichten statt Ja oder Nein.", "bedarfsanalyse"),
    ("bedarf3", "Warum fragst du früh, wer außer dem Kunden noch mitentscheidet?",
     ["Damit der Partner bei Besichtigung und Entscheidung dabei sein kann", "Um später Druck machen zu können",
      "Das ist nicht wichtig", "Für die Statistik"],
     "Wer früh weiß, wer mitentscheidet, plant gemeinsame Termine und vermeidet „Das muss ich erst besprechen“.",
     "bedarfsanalyse"),
    ("besicht1", "Ein Kunde sorgt sich, ob er mit 7,40 m Länge zurechtkommt. Was machst du bei der Besichtigung?",
     ["Am Fahrzeug zeigen: Fahrersitz einstellen, Rückfahrkamera, Maße – und ihn selbst ausprobieren lassen",
      "Ihm von dir aus eine Probefahrt mit dem Neufahrzeug anbieten", "Die Sorge überspielen und zum Preis kommen",
      "Ohne nachzufragen ein kleineres Fahrzeug holen"],
     "Viele Sorgen lassen sich am Fahrzeug beantworten. Eine Probefahrt bieten wir bei Neufahrzeugen nicht aktiv an "
     "(Hausregel VERKAUF-001).", "besichtigung"),
    ("besicht2", "Was tust du direkt nach der Besichtigung?",
     ["Im Fahrzeug bleiben, den Urlaub spüren lassen und nach dem Eindruck fragen", "Sofort ins Büro gehen",
      "Das nächste Fahrzeug holen", "Den Kunden allein lassen"],
     "Tisch aufbauen, Bett ausprobieren und fragen: „Wie fühlt es sich an?“ – dann nach der Entscheidung "
     "fragen.", "besichtigung"),
    ("einwand1", "Was ist ein Einwand nach Kreuter?",
     ["Eine offene Frage – kein Nein", "Ein endgültiges Nein", "Ein Zeichen, dass der Kunde nicht kaufen will",
      "Etwas, das man ignorieren sollte"],
     "Ein Einwand zeigt Interesse und eine offene Frage. Verstehen, beantworten, zurück zum Abschluss.",
     "einwaende"),
    ("einwand2", "Welche Reaktion auf einen Einwand ist ungünstig?",
     ["„Ja, aber …“", "„Gut, dass Sie das ansprechen.“", "„Was genau macht Ihnen Sorgen?“",
      "„Ist das der einzige Punkt?“"],
     "Das „aber“ wischt alles davor weg. Besser bestätigen, nachfragen, dann antworten.", "einwaende"),
    ("abschluss1", "Du hast die Abschlussfrage gestellt. Was jetzt?",
     ["Schweigen, bis der Kunde antwortet", "Sofort weiterreden", "Einen Rabatt nachschieben",
      "Die Frage noch zweimal stellen"],
     "Nach der Abschlussfrage gehört die Stille dem Kunden. Wer sie füllt, nimmt ihm die Entscheidung ab.",
     "abschluss"),
    ("abschluss2", "Welche Frage ist ein Kaufsignal?",
     ["„Kann die Markise bis Ostern montiert sein?“", "„Wo sind die Toiletten?“", "„Haben Sie WLAN?“",
      "„Wann schließen Sie heute?“"],
     "Fragen nach Lieferzeit, Montage, Übergabe oder Finanzierung zeigen: Der Kunde sieht sich schon mit dem "
     "Fahrzeug.", "abschluss"),
    ("abschluss3", "Wie endet ein Verkaufsgespräch ohne Kauf am besten?",
     ["Mit einem festen nächsten Termin", "Mit „Melden Sie sich einfach“", "Ohne weitere Absprache",
      "Mit einer Rabattdrohung"],
     "Ein konkreter Termin (Datum, Uhrzeit, Weg) hält das Gespräch am Leben. „Melden Sie sich“ beendet es meist.",
     "abschluss"),
    ("nachfassen1", "Was bringst du beim Nachfassen am besten mit?",
     ["Einen Anlass: eine Antwort, ein neues Fahrzeug, einen freien Termin", "Nichts – nur mal hören",
      "Eine erfundene Frist", "Einen höheren Preis"],
     "Nachfassen mit Anlass ist Service. „Wollte nur mal hören“ wirkt wie Druck ohne Grund.", "nachfassen"),
    ("nachfassen2", "Wie viele Kontakte brauchen viele Abschlüsse?",
     ["Mehrere – wer nach dem ersten aufhört, verschenkt Geschäft", "Genau einen", "Keinen – Kunden melden sich "
      "selbst", "Mindestens zwanzig"],
     "Die meisten Kunden kaufen nicht beim ersten Kontakt. Zwei, drei feste Nachfass-Termine gehören dazu.",
     "nachfassen"),
    ("inzahlung1", "Wie erklärst du am besten den Ankaufspreis für das alte Fahrzeug?",
     ["Die Rechnung offenlegen: Marktpreis minus Aufbereitung, Reparatur und Risiko", "Nur die Zahl nennen",
      "Auf den Hersteller verweisen", "Den Preis beim neuen Fahrzeug erhöhen"],
     "Eine nachvollziehbare Rechnung schafft Vertrauen – auch wenn die Zahl enttäuscht.", "inzahlungnahme"),
    ("inzahlung2", "Warum ist es keine gute Idee, Rabatt aufs neue Fahrzeug als höheren Ankaufspreis zu verstecken?",
     ["Es verzerrt beide Zahlen – Ankauf und Verkauf", "Weil der Kunde dann mehr zahlt",
      "Weil das verboten ist", "Das ist sogar empfehlenswert"],
     "Ein überhöhter Ankaufspreis macht das alte Fahrzeug schnell zum Langsteher und verschleiert den echten "
     "Nachlass.", "inzahlungnahme"),
    ("finanz1", "Was gehört zu einem ehrlichen Finanzierungsangebot?",
     ["Rate, Laufzeit, Schlussrate und Gesamtkosten", "Nur die Monatsrate", "Nur der Zinssatz",
      "Nur der Barpreis"],
     "Wer nur die Rate nennt, verschweigt das Wichtigste. Beide Wege fair nebeneinander zeigen.", "finanzierung"),
    ("finanz2", "Ein Kunde könnte bar zahlen, hätte danach aber keine Rücklage. Was ist eine gute Beratung?",
     ["Beide Wege zeigen und auf die Rücklage hinweisen", "Barkauf, weil Zinsen immer schlecht sind",
      "Finanzierung, weil wir daran verdienen", "Gar nichts dazu sagen"],
     "Die Empfehlung muss zum Kunden passen. Eine Rücklage für Reisen und Unvorhergesehenes kann wertvoll sein.",
     "finanzierung"),
    ("zubehoer1", "Wann ist Zubehör anbieten gute Beratung?",
     ["Wenn es ein Problem löst, das der Kunde in der Bedarfsanalyse genannt hat", "Immer, je mehr desto besser",
      "Nur nach der Unterschrift", "Nie – das wirkt aufdringlich"],
     "Passendes Zubehör macht die Reise besser. Jedem dasselbe Paket zu verkaufen ist Mehrverkauf, keine "
     "Beratung.", "zubehoer"),
    ("zubehoer2", "Worauf musst du bei schwerem Zubehör im Reisemobil besonders achten?",
     ["Zuladung und zulässiges Gesamtgewicht", "Die Farbe", "Den Markennamen", "Gar nichts"],
     "Markise, Batterie, Fahrradträger: Zubehör geht von der Zuladung ab – bei 3,5 t wird es schnell knapp.",
     "zubehoer"),
    ("voss1", "Was ist „Labeling“ nach Chris Voss?",
     ["Das Gefühl des anderen benennen: „Es klingt so, als …“", "Preisschilder anbringen",
      "Kunden in Gruppen einteilen", "Einen Vertrag unterschreiben lassen"],
     "Wer Gefühle benennt und dann schweigt, nimmt Spannung raus und bekommt ehrliche Antworten.", "verhandeln"),
    ("voss2", "Welche Frage ist eine „kalibrierte Frage“?",
     ["„Wie soll ich das machen?“", "„Ist das Ihr letztes Wort?“", "„Wollen Sie es nun oder nicht?“",
      "„Sind Sie sicher?“"],
     "Offene Wie- und Was-Fragen lassen den anderen nach einer Lösung suchen, statt sich zu verteidigen.",
     "verhandeln"),
    ("voss3", "Was machst du, wenn du ein Zugeständnis machst?",
     ["Etwas dafür bekommen (z. B. schnelle Entscheidung)", "Es sofort verdoppeln", "Nichts – einfach geben",
      "Es heimlich zurücknehmen"],
     "Ein Zugeständnis ohne Gegenleistung lädt zum nächsten ein. Tausche immer etwas.", "verhandeln"),
    ("partner1", "Wie bereitest du ein Gespräch mit Bank oder Hersteller am besten vor?",
     ["Zahlen sammeln, Ziele des Gegenübers verstehen, eigene Grenze festlegen", "Spontan hingehen",
      "Nur die eigenen Wünsche aufschreiben", "Möglichst viel Druck aufbauen"],
     "Gute Vorbereitung und das Verständnis, was das Gegenüber intern vertreten muss, machen faire Einigungen "
     "möglich.", "partnergespraech"),
    ("entscheiden1", "Was ist „Umkehrdenken“ nach Munger?",
     ["Fragen, wie etwas garantiert schiefgeht – und das vermeiden", "Entscheidungen rückgängig machen",
      "Immer das Gegenteil von dem tun, was andere tun", "Rückwärts einparken"],
     "Statt nur zu fragen „Wie gelingt es?“ fragst du „Wie misslingt es?“ – so erkennst du Risiken früh.",
     "entscheiden"),
    ("entscheiden2", "Was ist ein „Pre-Mortem“?",
     ["Man stellt sich vor, die Entscheidung ist gescheitert, und sucht die Gründe", "Eine Nachbesprechung nach "
      "einem Fehler", "Ein Vertragsentwurf", "Eine Versicherung"],
     "Vorher statt hinterher: Wer sich das Scheitern vorstellt, findet Schwachstellen, solange man noch etwas "
     "ändern kann.", "entscheiden"),
    ("entscheiden3", "Wie behandelst du eine leicht umkehrbare Entscheidung?",
     ["Schnell treffen und nach kurzer Zeit überprüfen", "Wochenlang abwägen", "Gar nicht treffen",
      "Immer dem Chef überlassen"],
     "Umkehrbare Fragen schnell entscheiden, nicht umkehrbare gründlich – sonst bremst man sich selbst.",
     "entscheiden"),
    ("entscheiden4", "Was bedeutet „Kompetenzkreis“?",
     ["Entscheide dort, wo du dich wirklich auskennst – und kenne seine Grenzen", "Ein Kreis aus Experten",
      "Eine Schulung", "Der Kreis, in dem wir Kunden haben"],
     "Wichtig ist nicht, wie groß der Kreis ist, sondern dass du weißt, wo er endet – und dort Rat holst.",
     "entscheiden"),
    ("ankauf1", "Wie rechnest du den höchsten Ankaufspreis für ein Gebrauchtes?",
     ["Rückwärts: realistischer Verkaufspreis minus Aufbereitung, Reparatur, Standkosten und Marge",
      "Den Wunschpreis des Kunden nehmen", "Den Preis aus dem günstigsten Inserat",
      "Listenpreis minus 10 %"],
     "So bleibt ein Sicherheitsabstand – auch wenn in der Werkstatt eine Überraschung wartet.", "ankauf"),
    ("ankauf2", "Was spricht beim Ankauf am ehesten dagegen?",
     ["Wenn die Rechnung nur aufgeht, wenn alles gut läuft", "Wenn der Kunde freundlich ist",
      "Wenn das Fahrzeug gepflegt ist", "Wenn wir die Baureihe gut kennen"],
     "Ohne Puffer wird aus einem guten Einkauf schnell ein Langsteher.", "ankauf"),
    ("wochenplan1", "Was planst du in der Wochenplanung zuerst ein?",
     ["Die drei wichtigsten Ergebnisse der Woche", "Alle 40 Punkte der To-do-Liste",
      "Nur Kundentermine", "Gar nichts – es kommt eh anders"],
     "Wichtiges bekommt feste Zeit, bevor das Dringende die Woche füllt.", "wochenplanung"),
    ("covey1", "Was meint Covey mit „Das Wichtige zuerst“?",
     ["Wichtiges, aber nicht Dringendes bekommt feste Zeit", "Immer das Lauteste zuerst",
      "Erst Mails, dann Kunden", "Was der Chef sagt, zuerst"],
     "Planen, Vorbereiten, Schulen, Beziehungen pflegen – das bleibt sonst liegen.", "wochenplanung"),
    ("allen1", "Welche Aufgabe ist als „nächster konkreter Schritt“ formuliert?",
     ["„Herrn Müller wegen Besichtigungstermin anrufen“", "„Kunde Müller“", "„Verkauf“", "„Irgendwas mit Müller“"],
     "Ein nächster Schritt ist eine sichtbare Tätigkeit. „Kunde Müller“ ist ein Thema, keine Aufgabe.",
     "kopffrei"),
    ("allen2", "Was besagt die Zwei-Minuten-Regel?",
     ["Was in zwei Minuten erledigt ist, sofort machen", "Jede Aufgabe darf nur zwei Minuten dauern",
      "Alle zwei Minuten Mails prüfen", "Zwei Minuten Pause pro Stunde"],
     "Kleinigkeiten sofort erledigen ist schneller, als sie aufzuschreiben und später wieder anzufassen.",
     "kopffrei"),
    ("uebergabe1", "Was gehört zu einer sauberen Übergabe an einen Kollegen?",
     ["Stand, Zusage an den Kunden, nächster Schritt, Termin und ein Name", "Ein kurzer Zuruf im Vorbeigehen",
      "Ein Zettel ohne Datum", "Nichts – der Kollege fragt schon"],
     "Zwischen Verkauf, Werkstatt, Teilen und Büro geht am meisten verloren. Schriftlich und mit Namen übergeben.",
     "teamuebergabe"),
    ("rekla1", "Ein Kunde reklamiert verärgert. Was zuerst?",
     ["Zuhören und das Gefühl benennen", "Erklären, dass es nicht unsere Schuld ist",
      "Auf den Hersteller verweisen", "Sofort über Gewährleistung diskutieren"],
     "Erst das Gefühl, dann die Sache, dann eine Zusage, die wir halten.", "reklamation"),
    ("rekla2", "Welche Zusage ist bei einer Reklamation gut?",
     ["Ein konkreter nächster Schritt mit Termin, den wir halten können", "„Wir machen alles sofort.“",
      "„Das wird schon.“", "Gar keine"],
     "Lieber weniger zusagen und es sicher halten – so entsteht aus Ärger Vertrauen.", "reklamation"),
    ("uebergabe2", "Was macht eine Fahrzeugübergabe zum Erlebnis?",
     ["Die erste Reise gemeinsam durchgehen und den Kunden selbst machen lassen", "Ein langer Technik-Vortrag",
      "Möglichst schnell fertig werden", "Nur die Papiere übergeben"],
     "Sicherheit für die erste Reise und ein Anruf danach – daran erinnert sich der Kunde jahrelang.",
     "fahrzeuguebergabe"),
    ("eos1", "Was prüfst du nach Wickman, wenn jemand nicht liefert?",
     ["Versteht er die Aufgabe, will er sie, kann er sie?", "Wie lange er schon im Betrieb ist",
      "Ob er pünktlich Feierabend macht", "Wie viel er verdient"],
     "Fehlt eins davon, hilft Druck nicht. Erst Klarheit schaffen, dann Leistung einfordern.", "erwartungen"),
    ("eos2", "Wie viele Zahlen hat eine gute Scorecard nach Wickman ungefähr?",
     ["Etwa fünf bis fünfzehn", "Eine", "Über hundert", "Gar keine"],
     "Wenige Wochenzahlen zeigen früh, ob es läuft – bevor es in der Buchhaltung auffällt.", "wochenrunde"),
    ("eos3", "Was passiert in der Wochenrunde mit einem Problem?",
     ["Benennen, kurz besprechen, lösen – mit Aufgabe, Name und Datum", "Jede Woche erneut diskutieren",
      "Vertagen", "Nur protokollieren"],
     "Probleme lösen statt besprechen: So steht nicht jede Woche dieselbe Diskussion an.", "wochenrunde"),
    ("harnish1", "Was empfiehlt Harnish für den Takt im Team?",
     ["Kurz und regelmäßig: täglich wenige Minuten, wöchentlich eine Runde", "Eine große Runde pro Jahr",
      "Nur bei Problemen treffen", "Möglichst lange Besprechungen"],
     "Ein fester Rhythmus schafft Ruhe – gerade in der Saison.", "wochenrunde"),
    ("sinek1", "Womit beginnt man nach Simon Sinek?",
     ["Mit dem Warum", "Mit dem Preis", "Mit den technischen Daten", "Mit dem Rabatt"],
     "Menschen folgen dem Warum – erst danach interessieren das Wie und das Was.", "warumfuehren"),
]
