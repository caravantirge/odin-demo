"""
Auftragsbestätigungen (Hersteller1, Hersteller2) lesen.

Ergebnis ist eine AB mit Kopfdaten (Nummern, Termine, FIN, Zahlung) und Positionen
(Artikelnummer, Bezeichnung, Preise). Gewichte und Rechtstexte werden bewusst nicht gelesen.
"""

import os
import re
from dataclasses import dataclass, field

import pdfplumber

from .sicher import pruefe_pdf, seitentexte

BETRAG = r"-?\d{1,3}(?:\.\d{3})*,\d{2}"


@dataclass
class Position:
    pos: str
    artikel: str
    text: str
    einzelpreis: str = ""
    gesamtpreis: str = ""
    inhalt: list = field(default_factory=list)   # Paketinhalt (Hersteller2 "bestehend aus")
    menge: str = ""                               # z. B. "1" (Hersteller1 „1Stück“, Hersteller2 „1 ST“)
    rabatt: str = ""                              # Hersteller1: „Qualitäts-Bonus -2,50 % (-1.342,42 €)“


@dataclass
class AB:
    datei: str = ""
    hersteller: str = ""
    belegart: str = ""            # Auftragsvormerkung / Auftragsbestätigung
    datum: str = ""               # TT.MM.JJJJ, Stand dieser Fassung
    interne_id: str = ""
    auftragsnummer: str = ""      # Auftragsnummer des Herstellers (Ordnername), Hersteller2: BelegNr
    modelljahr: str = ""
    weitere_nummern: list = field(default_factory=list)   # z. B. Hersteller3 Online-Bestellnr., nur zum Finden
    fassung: int = 0              # Ausfertigung / Änderungsstand, ordnet ABs vom selben Tag
    kopf: dict = field(default_factory=dict)      # Feld -> Wert, z. B. "Liefertermin"
    positionen: list = field(default_factory=list)
    hinweise: list = field(default_factory=list)  # Bemerkungszeilen ohne Positionsnummer, werden nicht verglichen
    fehler: str = ""

    @property
    def iso_datum(self) -> str:
        t, m, j = (self.datum.split(".") + ["", "", ""])[:3]
        if len(j) == 2:
            j = "20" + j
        return f"{j}-{m}-{t}" if j else ""


def _feld(text, muster, gruppe=1):
    m = re.search(muster, text, re.M)
    return m.group(gruppe).strip() if m else ""


BEKANNTE_PRAEFIXE = ("DETKW", "DETRM", "DETWW", "DWWA", "DRM", "DKW", "SLKW", "SLRM", "SLWW", "SLR", "GW")
ID_MUSTER = re.compile(r"\b([A-Z]{2,6}\d{4,6})(?:AF)?\b")          # Hersteller2 hängt teils „AF“ an


def ist_interne_id(wert: str) -> bool:
    """Interne IDs bestehen aus Buchstaben und Ziffern, z. B. DRM00285, SLKW00243, H90897 –
    kein Freitext wie „Kunde“ oder „Lager“."""
    return bool(re.fullmatch(r"[A-Z]{1,6}\d{3,6}", (wert or "").strip().upper()))


def extrahiere_interne_id(text: str) -> str:
    """Holt die Interne ID aus Feldern wie 'VFW/b1/DRM00285', 'SLKW00243 AF' oder 'Müller - SLRM00261'."""
    treffer = ID_MUSTER.findall(text or "")
    bekannte = [t for t in treffer if t.startswith(BEKANNTE_PRAEFIXE)]
    return (bekannte or treffer or [""])[-1]


# ---------------- Hersteller1 ----------------

H1_POS = re.compile(rf"^(\d{{1,3}}0) (\S+) (\d+)\s?Stück(?: ({BETRAG}))?(?: ({BETRAG}))?\s*$")
H1_HINWEIS = re.compile(r"^(V\d{4,})\s+\d+\s?Stück\s*$")      # z. B. "V349999 1Stück" + "Bemerkung Motorcaravan"
H1_RABATT = re.compile(rf"^(.+?) in % (-?\d+,\d+) ({BETRAG})\s*$")   # „Qualitäts-Bonus in % -2,50 -1.342,42“
H1_SEITENKOPF = re.compile(
    r"^(Auftrags(vormerkung|bestätigung) \d+ vom|Kundennummer \d+ Seite|Pos Artikel|EUR EUR|Übertrag\b)")


def ohne_seitenkoepfe(text: str) -> str:
    """Entfernt die bei jedem Seitenwechsel wiederholten Kopfzeilen, damit Felder und Positionen,
    die über eine Seitengrenze laufen, zusammenhängend gelesen werden."""
    zeilen, erste_kopfzeile = [], True
    for zeile in text.split("\n"):
        z = zeile.strip()
        if z.startswith("Pos Artikel") and erste_kopfzeile:
            erste_kopfzeile = False
            zeilen.append(z)          # die erste Tabellenüberschrift markiert den Beginn der Positionen
            continue
        if H1_SEITENKOPF.match(z):
            continue
        zeilen.append(z)
    return "\n".join(zeilen)


def lies_hersteller1(text: str, ab: AB):
    text = ohne_seitenkoepfe(text)
    ab.hersteller = "Hersteller1"
    ab.belegart = _feld(text, r"^(Auftragsvormerkung|Auftragsbestätigung)\s*$")
    ab.auftragsnummer = _feld(text, r"^Nr (\d+)")
    bestelltext = _feld(text, r"^Bestelltext (.+)$")
    ab.interne_id = extrahiere_interne_id(bestelltext)       # Freitext wie „Kunde Müller“ ist keine ID
    ab.datum = _feld(text, r"^Druckdatum (\d{2}\.\d{2}\.\d{2,4})") or _feld(text, r"^vom (\d{2}\.\d{2}\.\d{4})")
    ab.modelljahr = _feld(text, r"\bMJ (\d{4})") or _feld(text, r"^(20\d{2}) [A-Z]\s*$")
    fassung = _feld(text, r"^(\d+)\. Ausfertigung")
    ab.fassung = int(fassung) if fassung else 0

    k = ab.kopf
    k["Belegart"] = ab.belegart
    k["Ausfertigung"] = f"{fassung}. Ausfertigung" if fassung else ""
    k["Bestelltext"] = bestelltext
    k["Serien-Nr."] = _feld(text, r"Serien-Nr\. ?([\d ]*?) ?Fahrgestell-Nr\.")
    k["Fahrgestell-Nr."] = _feld(text, r"Fahrgestell-Nr\. ?(\S*)\s*$")
    k["Produktionstermin"] = _feld(text, r"Prod\.Termin ca\. KW ?(\S*?) ?Liefertermin")
    k["Liefertermin"] = _feld(text, r"Liefertermin ca\. KW ?(\S*)\s*$")
    k["Summe"] = _feld(text, rf"^Summe ({BETRAG})")
    k["Lieferbedingung"] = _feld(text, r"^Lieferbedingung (.+)$")
    zahlung = re.search(r"^Zahlung (.*?)\n(?:Alle Kaufgegenstände|\d+\. Ausfertigung|Druckdatum)", text, re.S | re.M)
    k["Zahlungsbedingungen"] = " ".join(zahlung.group(1).split()) if zahlung else ""

    aktuell = None
    in_positionen = False
    for z in text.split("\n"):
        if z.startswith("Pos Artikel"):
            in_positionen = True
            continue
        if not in_positionen or not z:
            continue
        if z.startswith(("Summe", "Korrektur für Preise")):
            break
        m = H1_POS.match(z)
        if m:
            aktuell = Position(pos=m.group(1), artikel=m.group(2), text="", menge=m.group(3),
                               einzelpreis=m.group(4) or "", gesamtpreis=m.group(5) or m.group(4) or "")
            ab.positionen.append(aktuell)
            continue
        m = H1_RABATT.match(z)
        if m and aktuell is not None:                    # Rabatt gehört zur Position, nicht in die Bezeichnung
            eintrag = f"{m.group(1).strip()} {m.group(2)} % ({m.group(3)} €)"
            aktuell.rabatt = f"{aktuell.rabatt}; {eintrag}" if aktuell.rabatt else eintrag
            continue
        m = H1_HINWEIS.match(z)
        if m:
            aktuell = Position(pos="", artikel=m.group(1), text="")
            ab.hinweise.append(aktuell)
            continue
        if aktuell is not None:
            aktuell.text = f"{aktuell.text} {z}".strip()


# ---------------- Hersteller2 ----------------

SL_POS = re.compile(rf"^(\d{{1,3}}) (\d+) (.+?) (\d+) ST(?: ({BETRAG}))?(?: ({BETRAG}))?\s*$")
SL_INHALT = re.compile(r"^(\d{5}) (.+)$")
SL_RAUSCHEN = re.compile(
    r"^(Seite|LBBW|\(BLZ|IBAN|BIC|Hersteller2 GmbH|Ölmühlestr|88299|Auftrags(vormerkung|bestätigung)|"
    r"BelegNr|Serie/KlassNr|Pos\. TeileNr|bestehend aus|Diese Fahrzeugversion)")


def lies_hersteller2(text: str, ab: AB):
    ab.hersteller = "Hersteller2"
    ab.belegart = _feld(text, r"^(Auftragsvormerkung|Auftragsbestätigung)\s*$")
    ab.auftragsnummer = _feld(text, r"BelegNr : (\d+)")
    kommission = _feld(text, r"Kommission : (.*?)$")
    ab.interne_id = extrahiere_interne_id(kommission)
    ab.datum = _feld(text, r"BelegNr : \d+ / (\d{2}\.\d{2}\.\d{4})")
    aenderung = _feld(text, r"^(\d+)\. Änderung vom")
    ab.fassung = int(aenderung) if aenderung else 0
    ab.modelljahr = _feld(text, r"\bMj(\d{2})\b")
    if ab.modelljahr:
        ab.modelljahr = "20" + ab.modelljahr

    k = ab.kopf
    k["Belegart"] = ab.belegart
    k["Änderungsstand"] = f"{aenderung}. Änderung" if aenderung else ""
    k["Kommission"] = kommission
    k["Seriennummer"] = _feld(text, r"Serie/KlassNr : \d+ / (\d+)")
    k["Fahrgestell-Nr."] = _feld(text, r"^FahrgestellNr : ?(\S*)\s*$")
    k["Aufbau-Nr."] = _feld(text, r"^AufbauNr : ?(\S*)\s*$")
    k["Liefertermin"] = re.sub(r"[\s⠀]+$", "", _feld(text, r"^Liefertermin : (.*)$"))
    k["Nettobetrag"] = _feld(text, rf"Nettobetrag: ({BETRAG})")
    k["Zahlungsbedingungen"] = _feld(text, r"^Zahlungsbedingungen : (.*?\b(?:zinsfrei|netto|Skonto)\b)")
    k["Lieferbedingungen"] = re.sub(r"\s*ungültig\..*$", "", _feld(text, r"Lieferbedingungen : (.*)$")).strip()

    aktuell = None
    for zeile in text.split("\n"):
        z = zeile.strip()
        if z.startswith(("Lieferbedingungen", "Nettobetrag", "Klassifizierungsnr")):
            aktuell = None
            continue
        m = SL_POS.match(z)
        if m and not z.startswith("Seite"):
            aktuell = Position(pos=m.group(1), artikel=m.group(2), text=m.group(3).strip(), menge=m.group(4),
                               einzelpreis=m.group(5) or "", gesamtpreis=m.group(6) or m.group(5) or "")
            ab.positionen.append(aktuell)
            continue
        if aktuell is None or SL_RAUSCHEN.match(z):
            continue
        m = SL_INHALT.match(z)
        if m:
            aktuell.inhalt.append(f"{m.group(1)} {m.group(2)}")


# ---------------- Hersteller3 ----------------
# Die Positionen stehen in Spalten: Code (links), Bezeichnung (ab ca. x=190), Preis (rechtsbündig).
# Umbrüche passieren innerhalb einer Spalte, deshalb werden die Zeilen mit Spaltengrenzen "|" gelesen.

MONATE = {"januar": 1, "februar": 2, "märz": 3, "april": 4, "mai": 5, "juni": 6, "juli": 7,
          "august": 8, "september": 9, "oktober": 10, "november": 11, "dezember": 12}
HERSTELLER3_BESCHREIBUNG_X = 185
HERSTELLER3_PREIS_X1 = 540
HERSTELLER3_FUSS = re.compile(r"^(Geschäftsführer|Christian Geiger|Kreissparkasse|Sparkasse|Hausbank|Postbank)")
# Ab dem Summenblock kommt nur noch Kleingedrucktes (Preisänderungsklausel, „Wir bedanken uns …“). Weil sich der
# Seitenkopf („Model …“) auf jeder Seite wiederholt, würde es sonst als lauter neue Positionen gelesen.
HERSTELLER3_ENDE = re.compile(r"Gesamtbetrag EUR|^Es gilt der zum Zeitpunkt|^Wir bedanken uns|^Erhöht oder verringert sich")


def hersteller3_spaltentext(pdf) -> str:
    """Positionszeilen als 'Code | Bezeichnung | Preis'. Fehlt der Code, beginnt die Zeile mit '|'."""
    zeilen = []
    for seite in pdf.pages:
        gruppen = {}
        for w in seite.extract_words():
            gruppen.setdefault(round(w["top"] / 3), []).append(w)
        for schluessel in sorted(gruppen):
            woerter = sorted(gruppen[schluessel], key=lambda w: w["x0"])
            code = [w["text"] for w in woerter if w["x0"] < HERSTELLER3_BESCHREIBUNG_X]
            rest = [w for w in woerter if w["x0"] >= HERSTELLER3_BESCHREIBUNG_X]
            preis = ""
            if rest and re.fullmatch(BETRAG, rest[-1]["text"]) and rest[-1]["x1"] > HERSTELLER3_PREIS_X1:
                preis = rest.pop()["text"]
            teile = [" ".join(code), " ".join(w["text"] for w in rest)]
            zeile = " | ".join(teile).strip()
            if preis:
                zeile += f" | {preis}"
            zeilen.append(zeile)
    return "\n".join(zeilen)


def hersteller3_vertragstext(rest: str) -> str:
    """Das Kleingedruckte nach dem Summenblock (Mehrwertsteuer, Preisänderungsklausel, Rücktrittsrecht) als ein
    Text: ändert Hersteller3 dort etwas, zeigt der Vergleich es als eine Änderung mit markierten Wörtern."""
    zeilen = []
    for zeile in rest.split("\n"):
        z = zeile.strip()
        if not z or HERSTELLER3_FUSS.match(z) or z.startswith(("Seite ", "Hersteller3 Freizeit", "Hersteller", "Serien", "Model")):
            continue
        if z.startswith("Wir bedanken uns"):
            break
        zeilen.append(z)
    text = ""
    for z in zeilen:                                    # Trennstriche am Zeilenende wieder zusammenfügen
        text = text[:-1] + z if text.endswith("-") and z[:1].islower() else (f"{text} {z}" if text else z)
    return " ".join(text.split())


def _deutsches_datum(text: str) -> str:
    m = re.search(r"(\d{1,2})\. (\w+) (\d{4})", text)
    if not m or m.group(2).lower() not in MONATE:
        return ""
    return f"{int(m.group(1)):02d}.{MONATE[m.group(2).lower()]:02d}.{m.group(3)}"


def lies_hersteller3(text: str, ab: AB, spalten: str = ""):
    ab.hersteller = "Hersteller3"
    # nur die Überschrift zählt – „Auftragsbestätigung“ steht auch im Kleingedruckten (z. B. einer Rechnung)
    ab.belegart = ("Auftragsbestätigung" if re.search(r"Auftragsbestätigung Seite \d|^Auftragsbestätigung\s*$", text, re.M)
                   else "")
    # Ordner: "Ihre Auftragsnummer" (= Interne ID) + Online-Bestellnr., die es schon vor der AB gibt.
    # Die Hersteller3-Auftrags-/Bestellnr. (POVAB…) dient nur zum Wiederfinden.
    povab = _feld(text, r"Auftrags-/Bestellnr\. (\S+)")
    online = _feld(text, r"Online-Bestellnr\. (\S+)")
    ab.auftragsnummer = online or povab
    ab.weitere_nummern = [povab] if online and povab else []
    ab.interne_id = _feld(text, r"Ihre Auftragsnummer (\S+)")
    ab.datum = _deutsches_datum(_feld(text, r"Belegdatum (.+?)$"))
    ab.modelljahr = _feld(text, r"^Modelljahr (\d{4})")

    k = ab.kopf
    k["Belegart"] = ab.belegart
    k["Modell"] = _feld(text, r"^(HERSTELLER3, .+?)(?: Auftrags-/Bestellnr\.|$)")
    k["Fahrgestell"] = _feld(text, r"^Fahrgestell (.+?)(?: Ihre Auftragsnummer|$)")
    k["Liefertermin"] = _feld(text, r"Liefertermin: (.*)$")
    k["Hersteller3-Bestellnr."] = povab
    k["Zahlungsbedingungen"] = _feld(text, r"Zahlungsbedingung:\s*(.*)$")
    summe = re.search(rf"^({BETRAG}) ({BETRAG}) ({BETRAG})\s*$", text, re.M)
    k["Gesamtbetrag netto"] = summe.group(1) if summe else ""
    k["Vertragsbedingungen"] = hersteller3_vertragstext(text[summe.end():]) if summe else ""

    aktuell = None
    in_positionen = False
    nummer = 0
    for zeile in (spalten or "").split("\n"):
        z = zeile.strip()
        ohne_spalten = " ".join(z.replace("|", " ").split())
        if HERSTELLER3_ENDE.search(ohne_spalten):
            break
        if ohne_spalten.startswith(("Ihre Referenz", "Model ")):
            in_positionen = True
            continue
        if ohne_spalten.startswith("Zahlungsbedingung") or HERSTELLER3_FUSS.match(ohne_spalten):
            in_positionen = False
            aktuell = None
            continue
        if not in_positionen or not z:
            continue
        teile = [t.strip() for t in z.split("|")]
        code, beschreibung = teile[0], teile[1] if len(teile) > 1 else ""
        preis = teile[2] if len(teile) > 2 else ""
        if code and (beschreibung or preis):
            code = re.sub(r"^\d+ ", "", code)          # führende Menge/Positionsnummer
            nummer += 1
            aktuell = Position(pos=str(nummer), artikel=code, text=beschreibung,
                               einzelpreis=preis, gesamtpreis=preis)
            ab.positionen.append(aktuell)
        elif aktuell is not None and code:              # Code bricht in die nächste Zeile um
            aktuell.artikel = f"{aktuell.artikel} {code}"
        elif aktuell is not None and beschreibung:      # Bezeichnung bricht um
            trenner = "" if aktuell.text.endswith("-") else " "
            aktuell.text = f"{aktuell.text}{trenner}{beschreibung}"


# ---------------- Einstieg ----------------

def erkenne_hersteller(text: str) -> str:
    if "Hersteller1 GmbH" in text:
        return "Hersteller1"
    if "Hersteller2 GmbH" in text:
        return "Hersteller2"
    if "Hersteller3 Freizeit und Sport GmbH" in text or "Hersteller3 Freizeit und Sport GmbH" in text:
        return "Hersteller3"
    return ""


def werte_ab_text_aus(text: str, datei: str = "", spalten: str = "", nur_kopf: bool = False) -> AB:
    """nur_kopf: nur die erste Seite ohne Positionen (schnelles Vorfiltern) – dann fehlen Positionen nicht."""
    ab = AB(datei=datei)
    hersteller = erkenne_hersteller(text)
    if hersteller == "Hersteller1":
        lies_hersteller1(text, ab)
    elif hersteller == "Hersteller2":
        lies_hersteller2(text, ab)
    elif hersteller == "Hersteller3":
        lies_hersteller3(text, ab, spalten)
        if not ab.belegart:
            ab.fehler = "Hersteller3-Dokument, aber keine Auftragsbestätigung (z. B. Rechnung) – nicht verarbeitet."
    else:
        ab.fehler = "Hersteller nicht erkannt – ist das eine Auftragsbestätigung?"
    if ab.interne_id and not ist_interne_id(ab.interne_id):       # z. B. Hersteller3 „Ihre Auftragsnummer Kunde“
        ab.kopf.setdefault("Ihre Auftragsnummer", ab.interne_id)
        ab.interne_id = ""
    if not ab.fehler and not ab.positionen and not nur_kopf:
        ab.fehler = "Keine Positionen gefunden – Layout der AB unbekannt."
    if not ab.fehler and not (ab.auftragsnummer or ab.interne_id):
        ab.fehler = "Weder Auftragsnummer noch Interne ID gefunden."
    return ab


def lesefehler(e: Exception) -> str:
    """Verständliche Meldung, wenn eine PDF nicht geöffnet werden kann. pdfplumber verpackt die eigentliche
    Ursache, z. B. PdfminerException(PDFPasswordIncorrect()) – mit leerem Text."""
    kette = [e]                                            # e und alles, was darin verpackt ist
    for x in kette:                                        # (die Liste wächst beim Durchlaufen)
        kette += [a for a in (*x.args, x.__cause__, x.__context__) if isinstance(a, BaseException) and a not in kette]
    from .sicher import DateiZuGross
    zu_gross = next((x for x in kette if isinstance(x, DateiZuGross)), None)
    if zu_gross:
        return str(zu_gross)
    if any("password" in f"{type(x).__name__} {x}".lower() or "encrypt" in str(x).lower() for x in kette):
        return "PDF ist mit einem Passwort geschützt – bitte ungeschützt speichern."
    if any(isinstance(x, OSError) for x in kette):         # gesperrt, fehlt, noch nicht von OneDrive geladen
        return "PDF gerade nicht lesbar (z. B. noch nicht von OneDrive geladen oder geöffnet) – gleich noch einmal versuchen."
    # pdfminer meldet auf Englisch („No /Root object!“) – für Menschen reicht: kaputt oder keine PDF
    grund = next((str(x).strip() for x in kette if str(x).strip()), "") or type(kette[-1]).__name__
    return f"PDF beschädigt oder keine richtige PDF – bitte neu speichern bzw. neu herunterladen. (Technisch: {grund})"


def kommission(ab: AB) -> str:
    """Freitext zur Bestellung (Bestelltext, Kommission), hilft bei Fahrzeugen ohne Interne ID."""
    return (ab.kopf.get("Bestelltext") or ab.kopf.get("Kommission") or ab.kopf.get("Ihre Auftragsnummer") or "").strip()


def lies_ab_kopf(quelle, datei: str = "") -> AB:
    """Nur die erste Seite: reicht für Hersteller und Nummern. Schnell – zum Vorfiltern vieler ABs."""
    datei = datei or os.path.basename(str(quelle))
    try:
        pruefe_pdf(quelle)
        with pdfplumber.open(quelle) as pdf:
            text = (pdf.pages[0].extract_text() or "") if pdf.pages else ""
    except Exception as e:
        return AB(datei=datei, fehler=lesefehler(e))
    return werte_ab_text_aus(text, datei, nur_kopf=True)


def ab_nummern(ab: AB) -> set:
    """Alle Nummern, unter denen das Fahrzeug einer AB gefunden werden kann."""
    return {n.strip().upper() for n in (ab.interne_id, ab.auftragsnummer, *ab.weitere_nummern) if n and n.strip()}


def lies_ab(quelle, datei: str = "") -> AB:
    datei = datei or os.path.basename(str(quelle))
    try:
        pruefe_pdf(quelle)
        with pdfplumber.open(quelle) as pdf:
            text = "\n".join(seitentexte(pdf))
            spalten = hersteller3_spaltentext(pdf) if erkenne_hersteller(text) == "Hersteller3" else ""
    except Exception as e:
        return AB(datei=datei, fehler=lesefehler(e))
    return werte_ab_text_aus(text, datei, spalten)
