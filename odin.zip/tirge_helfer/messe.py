"""
Messe-Personal: wer zur ABF (und zur Hausmesse) mitfährt – Einsatzzeitraum, Verkaufsbereiche, Hotel, Wohnmobil,
Essen und Westengröße. Eine Zeile je Person, Export als Excel-kompatible CSV.

Gespeichert wird wie bei Urlaub und Projekten im Ordner „Fahrzeuge“ unter _ODIN/ (per OneDrive/SharePoint auf allen
Rechnern gleich – das ist die gemeinsame ODIN-Datenbank; eine zentrale SQL-Datenbank gibt es nicht):
- _ODIN/Messen/<messe>/personen/<id>.json   je Person eine Datei – zwei Rechner überschreiben sich nie gegenseitig
- _ODIN/Messen/<messe>/messe.json           optional: Name, Zeitraum, Ort von Hand überschreiben (z. B. Hausmesse)
Jede Person hat eine feste, zufällige ID (Dateiname = ID). Die laufende Nummer in der Tabelle wird beim Lesen aus
der Reihenfolge des Anlegens berechnet und nie gespeichert – nach dem Entfernen stimmt sie sofort wieder.

Datenformat („Migration“): jede Datei trägt "version": 1 und "messe": "<schlüssel>". Beim Lesen wird jede Datei in
feste Form gebracht: fehlende Version gilt als 1, Verkaufsbereiche dürfen auch als Text („Hersteller3, Wohnwagen“) in
einer von Hand bearbeiteten Datei stehen, unbekannte Werte werden zu „Offen“ bzw. fallen weg. Eine Datei, deren
Messe nicht zum Ordner passt oder die keine gültige ID hat, bleibt draußen. Spätere Jahrgänge bekommen einen eigenen
Schlüssel (z. B. abf-2028) und damit einen eigenen Ordner.

Rechte (geprüft hier, nicht nur in der Oberfläche):
- Lesen und Export: jede Person, die in ODIN ausgewählt bzw. per Microsoft angemeldet ist.
- Anlegen, Ändern, Entfernen: die Verwalter – wie bei den Tagesfragen die Urlaubs-Genehmiger. Solange es noch
  keinen Genehmiger gibt, darf jede Person schreiben (sonst ließe sich der Plan ohne Urlaubsregeln nie füllen).
Im Browser (Handy/Tablet) ist nicht sicher, wer am Gerät sitzt: dort sperrt web.py das Schreiben (NUR_AM_RECHNER).
Wie überall in ODIN gilt: wer die Dateien im Ordner öffnen kann, kann sie lesen.
"""

import csv
import datetime as dt
import io
import json
import os
import re
import secrets

from .projekte import ProjektFehler
from .urlaub_antraege import UrlaubFehler

VERSION = 1
STANDARD_MESSE = "abf-2027"
# Eingebaute Messen. Name, Zeitraum und Ort lassen sich je Messe in messe.json überschreiben.
MESSEN = {
    "abf-2027": {"name": "ABF 2027", "titel": "ABF 2027", "zeitraum": "10. bis 14. Februar 2027",
                 "ort": "Messegelände Hannover", "beginn": "2027-02-10", "ende": "2027-02-14",
                 "datei": "ABF-2027-Personalplanung"},
    "hausmesse-2027": {"name": "Hausmesse", "titel": "Hausmesse 2027", "zeitraum": "23. bis 25. April 2027",
                       "ort": "Caravan Muster", "beginn": "2027-04-23", "ende": "2027-04-25", "datei": "Hausmesse-2027-Personalplanung"},
}
BEREICHE = ("Wohnwagen", "Hersteller3", "Hersteller1 Reisemobile", "Hersteller1 Kastenwagen", "Hersteller2 Reisemobile",
            "Hersteller2 Kastenwagen")
AUSWAHL = ("Offen", "Ja", "Nein")
JA_NEIN_FELDER = ("hotel", "wohnmobil", "essen")
SPALTEN = ("Nr.", "Name", "Einsatzzeitraum", "Verkaufsbereiche", "Hotel benötigt", "Mit Wohnmobil",
           "Beim Essen dabei", "Westengröße")
NAME_MAX, ZEITRAUM_MAX, WESTE_MAX = 80, 60, 20
HOECHSTENS = 500                                 # Personen je Messe – fängt Fehlbedienung und volle Ordner ab
ID_MUSTER = re.compile(r"[0-9a-f]{12}")
MESSE_MUSTER = re.compile(r"[a-z0-9]+(-[a-z0-9]+){0,4}")
FORMEL_ANFANG = ("=", "+", "-", "@", "\t", "\r")


class MesseFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


# ---------------------------------------------------------------- kleine Helfer

def _text(wert, laenge: int) -> str:
    return " ".join(str(wert if isinstance(wert, (str, int, float)) and not isinstance(wert, bool) else "").split())[:laenge]


def _bereiche(wert, streng: bool = False) -> list:
    """Liste (oder von Hand: Text mit Komma) → erlaubte Bereiche in fester Reihenfolge, ohne Doppelte."""
    if isinstance(wert, str):
        wert = wert.split(",")
    if wert is None:
        wert = []
    if not isinstance(wert, list):
        if streng:
            raise MesseFehler("Verkaufsbereiche: ungültige Angabe.")
        wert = []
    gewaehlt = set()
    for b in wert:
        name = _text(b, 40)
        if name in BEREICHE:
            gewaehlt.add(name)
        elif streng and name:
            raise MesseFehler(f"Unbekannter Verkaufsbereich „{name}“.")
    return [b for b in BEREICHE if b in gewaehlt]


def _auswahl(wert, was: str, streng: bool = False) -> str:
    text = _text(wert, 10).capitalize() if isinstance(wert, str) else ""
    if wert in (None, ""):
        return "Offen"
    if text in AUSWAHL:
        return text
    if streng:
        raise MesseFehler(f"{was}: bitte „Offen“, „Ja“ oder „Nein“ wählen.")
    return "Offen"


def eintrag_form(roh, messe: str):
    """Eine gelesene Personendatei in fester Form – oder None, wenn sie nicht (mehr) zu dieser Messe gehört."""
    if not isinstance(roh, dict) or not ID_MUSTER.fullmatch(str(roh.get("id") or "")):
        return None
    if roh.get("messe", messe) != messe:
        return None
    name = _text(roh.get("name"), NAME_MAX)
    if not name:
        return None
    e = {"version": VERSION, "id": roh["id"], "messe": messe, "name": name,
         "zeitraum": _text(roh.get("zeitraum"), ZEITRAUM_MAX), "bereiche": _bereiche(roh.get("bereiche")),
         "weste": _text(roh.get("weste"), WESTE_MAX)}
    for feld in JA_NEIN_FELDER:
        e[feld] = _auswahl(roh.get(feld), feld)
    for feld in ("angelegt_am", "angelegt_von", "geaendert_am", "geaendert_von"):
        e[feld] = roh[feld] if isinstance(roh.get(feld), str) else ""
    return e


def _zelle(wert) -> str:
    """CSV-Zelle gegen Formeln in Excel schützen: Text, der mit = + - @ beginnt, bekommt ein ' davor."""
    text = str(wert)
    return "'" + text if text.startswith(FORMEL_ANFANG) else text


def csv_text(eintraege: list) -> str:
    """Excel-kompatible CSV (Semikolon, deutsche Spaltenköpfe, CRLF). Das BOM setzt, wer die Datei schreibt."""
    puffer = io.StringIO()
    w = csv.writer(puffer, delimiter=";", lineterminator="\r\n", quoting=csv.QUOTE_MINIMAL)
    w.writerow(SPALTEN)
    for e in eintraege:
        w.writerow([e["nr"]] + [_zelle(x) for x in (e["name"], e["zeitraum"], ", ".join(e["bereiche"]), e["hotel"],
                                                    e["wohnmobil"], e["essen"], e["weste"])])
    return puffer.getvalue()


# ---------------------------------------------------------------- Messe-Personal

class MessePersonal:
    """`projekte` liefert Personen, „ich“ und den Ordner, `urlaub_fabrik()` das Urlaub-Objekt (Genehmiger = Verwalter).
    `jetzt` lässt sich für Tests ersetzen."""

    def __init__(self, projekte, urlaub_fabrik, jetzt=None):
        self._projekte = projekte
        self._urlaub_fabrik = urlaub_fabrik
        self._jetzt = jetzt or dt.datetime.now

    # ---------------- Orte ----------------
    @staticmethod
    def _messe(messe) -> str:
        messe = STANDARD_MESSE if messe in (None, "") else str(messe)
        if not MESSE_MUSTER.fullmatch(messe) or len(messe) > 40 or messe not in MESSEN:
            raise MesseFehler("Unbekannte Messe.")
        return messe

    def _ordner(self, messe: str) -> str:
        return os.path.join(self._projekte._basis()[0], "Messen", messe)

    def _personen_ordner(self, messe: str) -> str:
        return os.path.join(self._ordner(messe), "personen")

    def _pfad(self, messe: str, eid: str) -> str:
        if not ID_MUSTER.fullmatch(str(eid or "")):
            raise MesseFehler("Unbekannter Eintrag.")
        return os.path.join(self._personen_ordner(messe), f"{eid}.json")

    def _zeit(self) -> str:
        # Mikrosekunden: mehrere Personen in derselben Sekunde angelegt behalten ihre Reihenfolge (= Nummer)
        return self._jetzt().isoformat(timespec="microseconds")

    @staticmethod
    def _lies(pfad: str):
        from .speicher import lies_json
        try:
            return lies_json(pfad)
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as e:
            raise MesseFehler(f"„{os.path.basename(pfad)}“ ist gerade nicht lesbar ({e}). "
                              "Synchronisiert OneDrive noch? Bitte gleich nochmal versuchen.") from None

    @staticmethod
    def _schreibe(pfad: str, daten):
        os.makedirs(os.path.dirname(pfad), exist_ok=True)
        tmp = f"{pfad}.{secrets.token_hex(3)}.tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(daten, f, ensure_ascii=False, indent=1)
            os.replace(tmp, pfad)
        except OSError as e:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise MesseFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None

    def _info(self, messe: str) -> dict:
        """Eingebaute Angaben der Messe, überschrieben von messe.json (nur Text-Felder, gekürzt)."""
        info = {"id": messe, **MESSEN[messe]}
        try:
            roh = self._lies(os.path.join(self._ordner(messe), "messe.json"))
        except MesseFehler:
            roh = None
        if isinstance(roh, dict):
            for feld in ("name", "titel", "zeitraum", "ort"):
                wert = _text(roh.get(feld), 80) if isinstance(roh.get(feld), str) else ""
                if wert:
                    info[feld] = wert
        return info

    # ---------------- Personen und Rechte ----------------
    def _lauf(self) -> dict:
        try:
            personen = {p["id"]: p for p in self._projekte.personen()}
            ich = self._projekte.ich()
        except ProjektFehler as e:
            raise MesseFehler(str(e)) from None
        ich = ich if ich in personen else ""
        if not ich:
            raise MesseFehler("Bitte zuerst auswählen, wer du bist.")
        return {"personen": personen, "ich": ich}

    def _bearbeiter_pfad(self) -> str:
        return os.path.join(os.path.dirname(self._ordner("abf-2027")), "bearbeiter.json")

    def _bearbeiter(self, lauf: dict) -> list:
        """Festgelegte Bearbeiter (für alle Messen gemeinsam), nur bekannte Personen."""
        try:
            roh = self._lies(self._bearbeiter_pfad())
        except MesseFehler:
            roh = None
        ids = roh.get("bearbeiter") if isinstance(roh, dict) else None
        return [i for i in (ids if isinstance(ids, list) else []) if isinstance(i, str) and i in lauf["personen"]]

    def _genehmiger(self, lauf: dict) -> list:
        try:
            regeln = self._urlaub_fabrik().regeln()
        except (UrlaubFehler, ProjektFehler) as e:
            raise MesseFehler(str(e)) from None
        return [g for g in regeln.get("genehmiger") or [] if g in lauf["personen"]]

    def _rechte(self, lauf: dict) -> tuple:
        """(darf schreiben, fehlt noch jeder Verwalter). Sind Bearbeiter festgelegt, dürfen nur sie ändern;
        sonst die Urlaubs-Genehmiger – und solange es keine gibt, jede Person."""
        bearbeiter = self._bearbeiter(lauf)
        if bearbeiter:
            return lauf["ich"] in bearbeiter, False
        verwalter = self._genehmiger(lauf)
        return (lauf["ich"] in verwalter or not verwalter), not verwalter

    def _darf_bearbeiter(self, lauf: dict) -> bool:
        """Die Bearbeiterliste ändern: wer selbst Bearbeiter oder Urlaubs-Genehmiger ist (ohne beides: jede Person)."""
        bearbeiter, verwalter = self._bearbeiter(lauf), self._genehmiger(lauf)
        return lauf["ich"] in bearbeiter or lauf["ich"] in verwalter or (not bearbeiter and not verwalter)

    def bearbeiter_setzen(self, ids) -> dict:
        lauf = self._lauf()
        if not self._darf_bearbeiter(lauf):
            raise MesseFehler("Die Bearbeiter legen nur Bearbeiter oder Urlaubs-Genehmiger fest.")
        if not isinstance(ids, list) or len(ids) > 50:
            raise MesseFehler("Ungültige Auswahl.")
        neu = [i for i in dict.fromkeys(ids) if isinstance(i, str) and i in lauf["personen"]]
        if neu and lauf["ich"] not in neu and lauf["ich"] not in self._genehmiger(lauf):
            raise MesseFehler("Du würdest dich selbst aussperren – nimm dich mit in die Liste.")
        self._schreibe(self._bearbeiter_pfad(), {"version": 1, "bearbeiter": neu, "geaendert_von": lauf["ich"],
                                                 "geaendert_am": self._zeit()})
        return self.start()

    def _schreib_pflicht(self) -> dict:
        lauf = self._lauf()
        if not self._rechte(lauf)[0]:
            raise MesseFehler("Die Messe-Personalplanung ändern nur Verwalter (die Urlaubs-Genehmiger).")
        return lauf

    # ---------------- Lesen ----------------
    def _alle(self, messe: str) -> tuple:
        """(Einträge in Reihenfolge des Anlegens mit laufender Nummer ab 1, Zahl unlesbarer Dateien)."""
        ordner = self._personen_ordner(messe)
        try:
            namen = sorted(n for n in os.listdir(ordner) if n.endswith(".json") and ID_MUSTER.fullmatch(n[:-5]))
        except OSError:
            return [], 0
        eintraege, kaputt = [], 0
        for n in namen:
            try:
                e = eintrag_form(self._lies(os.path.join(ordner, n)), messe)
            except MesseFehler:
                e = None
            if e is None or e["id"] != n[:-5]:
                kaputt += 1
                continue
            eintraege.append(e)
        eintraege.sort(key=lambda e: (e["angelegt_am"], e["id"]))
        for nr, e in enumerate(eintraege, start=1):
            e["nr"] = nr
        return eintraege, kaputt

    def start(self, messe=None) -> dict:
        """Alles für die Seite: Messe, Einträge mit Nummer, Summen, Auswahlwerte und Rechte."""
        messe = self._messe(messe)
        lauf = self._lauf()
        darf, fehlt = self._rechte(lauf)
        eintraege, kaputt = self._alle(messe)
        summe = {"personen": len(eintraege),
                 **{f: sum(1 for e in eintraege if e[f] == "Ja") for f in JA_NEIN_FELDER},
                 "offen": sum(1 for e in eintraege if any(e[f] == "Offen" for f in JA_NEIN_FELDER))}
        return {"messe": self._info(messe), "messen": [{"id": k, "name": self._info(k)["name"]} for k in MESSEN],
                "eintraege": eintraege, "summe": summe, "kaputt": kaputt,
                "bereiche": list(BEREICHE), "auswahl": list(AUSWAHL),
                "ich": lauf["ich"], "darf_schreiben": darf, "verwalter_fehlt": fehlt,
                "bearbeiter": self._bearbeiter(lauf), "darf_bearbeiter": self._darf_bearbeiter(lauf),
                "personen": sorted(({"id": p["id"], "name": p["name"]} for p in lauf["personen"].values()),
                                   key=lambda p: p["name"].casefold()),
                "namen": sorted((p["name"] for p in lauf["personen"].values()), key=str.casefold),
                "gemeinsam": not self._projekte._basis()[1]}

    # ---------------- Schreiben ----------------
    @staticmethod
    def _pruefe(eingabe) -> dict:
        """Eingabe aus dem Formular prüfen. Nur der Name ist Pflicht."""
        if not isinstance(eingabe, dict):
            raise MesseFehler("Ungültige Angaben.")
        name = _text(eingabe.get("name"), NAME_MAX + 1)
        if not name:
            raise MesseFehler("Bitte den Namen eingeben.")
        if len(name) > NAME_MAX:
            raise MesseFehler(f"Der Name ist zu lang (höchstens {NAME_MAX} Zeichen).")
        zeitraum = _text(eingabe.get("zeitraum"), ZEITRAUM_MAX + 1)
        if len(zeitraum) > ZEITRAUM_MAX:
            raise MesseFehler(f"Einsatzzeitraum: höchstens {ZEITRAUM_MAX} Zeichen.")
        weste = _text(eingabe.get("weste"), WESTE_MAX + 1)
        if len(weste) > WESTE_MAX:
            raise MesseFehler(f"Westengröße: höchstens {WESTE_MAX} Zeichen.")
        felder = {"name": name, "zeitraum": zeitraum, "weste": weste,
                  "bereiche": _bereiche(eingabe.get("bereiche"), streng=True)}
        namen = {"hotel": "Hotel benötigt", "wohnmobil": "Mit Wohnmobil", "essen": "Beim Essen dabei"}
        for feld in JA_NEIN_FELDER:
            felder[feld] = _auswahl(eingabe.get(feld), namen[feld], streng=True)
        return felder

    def anlegen(self, messe, eingabe) -> dict:
        messe = self._messe(messe)
        lauf = self._schreib_pflicht()
        felder = self._pruefe(eingabe)
        if len(self._alle(messe)[0]) >= HOECHSTENS:
            raise MesseFehler(f"Mehr als {HOECHSTENS} Personen je Messe gehen nicht.")
        jetzt = self._zeit()
        eintrag = {"version": VERSION, "id": secrets.token_hex(6), "messe": messe, **felder,
                   "angelegt_am": jetzt, "angelegt_von": lauf["ich"], "geaendert_am": jetzt, "geaendert_von": lauf["ich"]}
        self._schreibe(self._pfad(messe, eintrag["id"]), eintrag)
        return {**self.start(messe), "neu": eintrag["id"]}

    def aendern(self, messe, eid, eingabe) -> dict:
        messe = self._messe(messe)
        lauf = self._schreib_pflicht()
        felder = self._pruefe(eingabe)
        pfad = self._pfad(messe, eid)
        alt = eintrag_form(self._lies(pfad), messe)           # frisch gelesen: Änderungen anderer Rechner zählen
        if alt is None or alt["id"] != eid:
            raise MesseFehler("Diesen Eintrag gibt es nicht mehr – vielleicht hat ihn jemand entfernt.")
        alt.update(felder)
        alt["geaendert_am"], alt["geaendert_von"] = self._zeit(), lauf["ich"]
        self._schreibe(pfad, alt)
        return self.start(messe)

    def entfernen(self, messe, eid) -> dict:
        messe = self._messe(messe)
        self._schreib_pflicht()
        pfad = self._pfad(messe, eid)
        try:
            os.remove(pfad)
        except FileNotFoundError:
            pass                                               # schon weg (anderer Rechner) – Ergebnis ist dasselbe
        except OSError as e:
            raise MesseFehler(f"Entfernen hat nicht geklappt ({e}). Ist die Datei gerade geöffnet?") from None
        return self.start(messe)

    # ---------------- Export ----------------
    def csv(self, messe=None) -> dict:
        """{"name": Dateiname, "text": CSV} – lesen darf jede ausgewählte Person."""
        messe = self._messe(messe)
        self._lauf()
        eintraege, _ = self._alle(messe)
        return {"name": f"{MESSEN[messe]['datei']}_{self._jetzt().date().isoformat()}.csv", "text": csv_text(eintraege)}
