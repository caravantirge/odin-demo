"""
Einstellungen, die man ohne Programmierung anpassen kann.

Sie liegen im Benutzerordner (Windows: %APPDATA%\\ODIN, Mac: ~/Library/Application Support/ODIN)
in 'einstellungen.json'. Beim ersten Start wird die Datei mit den Standardwerten angelegt.
Änderungen dort (z. B. ein neuer Gebührenbegriff) gelten beim nächsten Start.
"""

import json
import os
import shutil
import sys

STANDARD = {
    "hersteller": ["Hersteller1", "Hersteller2", "Hersteller3", "Hersteller3", "Hersteller11", "Hersteller13"],
    # Positionen, die nie in den Fließtext gehören (Kleinschreibung, Teilwort genügt)
    "gebuehren": [
        "zulassungsdokumente", "überführung", "ueberfuehrung", "versicherung",
        "zusatzbetankung", "aktionsprämie", "aktionspraemie", "tageszulassung",
    ],
    # Pakete, bei denen der Inhalt mit in den Fließtext kommt
    "pakete_mit_inhalt": ["Hersteller3 Monte Paket"],
    # Begriffe, die in der Excel-Ausgabe rot markiert werden
    "rot_markieren": [
        "Automatikgetriebe", "ICONIC MUSTER Edition", "Solaranlage",
        "Combi 6 E", "Combi 6E", "Rückfahrkamera",
    ],
    # Synchronisierter SharePoint-Ordner "Fahrzeuge" (wird im Programm gewählt)
    "fahrzeuge_ordner": "",
    # Erscheinungsbild: "auto" (wie das Betriebssystem), "hell" oder "dunkel"
    "design": "auto",
    # Gestaltung: "v3" (ODIN 3, neu) oder "v2" (ODIN 2) – unten in der Seitenleiste umschaltbar
    "stil": "v3",
    # Cockpit: welche Excel-Datei welche Liste ist (je Rechner, wird im Programm unter „Datenquellen“ gewählt)
    "cockpit_quellen": {},
    # Projekte: wer an diesem Rechner arbeitet (bis zur Anmeldung mit Login)
    "projekte_ich": "",
    # Persönliche Ansicht (z. B. Anordnung der Kacheln auf der Übersicht) – je Rechner
    "oberflaeche": {},
    # Rechtsfälle: eigener, zugriffsbeschränkter Ordner (leer = im Ordner „Fahrzeuge“ unter _ODIN/Rechtsfaelle)
    "rechtsfaelle_ordner": "",
    # Microsoft-Anmeldung: {"client_id": …, "tenant_id": …} – gilt nur, wenn im Ordner „Fahrzeuge“ nichts steht
    # (dort trägt man es einmal für alle Rechner ein). Keine Geheimnisse; die Anmeldung selbst liegt verschlüsselt
    # in microsoft-anmeldung.json.
    "microsoft_app": {},
}


def einstellungsordner() -> str:
    if sys.platform == "win32":
        basis = os.environ.get("APPDATA") or os.path.expanduser("~")
    elif sys.platform == "darwin":
        basis = os.path.expanduser("~/Library/Application Support")
    else:
        basis = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(basis, "ODIN")


def _uebernimm_alte_einstellungen():
    """Bis Oktober 2026 hieß das Programm „Muster Helfer“: dessen Einstellungen einmalig übernehmen."""
    neu = os.path.join(einstellungsordner(), "einstellungen.json")
    alt = os.path.join(os.path.dirname(einstellungsordner()), "Muster Helfer", "einstellungen.json")
    if not os.path.exists(neu) and os.path.exists(alt):
        try:
            os.makedirs(einstellungsordner(), exist_ok=True)
            shutil.copyfile(alt, neu)
        except OSError:
            pass


def _pfad() -> str:
    return os.path.join(einstellungsordner(), "einstellungen.json")


def _lies() -> dict:
    with open(_pfad(), "rb") as f:
        roh = f.read()
    try:
        text, ansi = roh.decode("utf-8-sig"), False       # „-sig“: Windows-Editor speichert oft mit BOM
    except UnicodeDecodeError:
        text, ansi = roh.decode("cp1252"), True           # im Editor „ANSI“ gespeichert – kein Grund zum Verwerfen
    daten = json.loads(text)
    if not isinstance(daten, dict):
        raise ValueError("Die Einstellungsdatei enthält keine Einstellungen.")
    if ansi:
        try:
            _schreibe(daten)                              # gleich wieder als UTF-8 speichern
        except OSError:
            pass
    return daten


def _passende_typen(geladen: dict) -> dict:
    """Nur Werte mit dem richtigen Typ übernehmen – ein Tippfehler bei einem Eintrag lässt die anderen gelten."""
    ok = {}
    for k, v in geladen.items():
        standard = STANDARD.get(k)
        if isinstance(standard, list):
            if isinstance(v, list) and all(isinstance(x, str) for x in v):
                ok[k] = v
        elif isinstance(standard, str):
            if isinstance(v, str):
                ok[k] = v
        elif isinstance(standard, dict):
            if isinstance(v, dict) and (k != "cockpit_quellen" or all(isinstance(x, str) for x in v.values())):
                ok[k] = v
        else:
            ok[k] = v
    return ok


def _sichere_defekte_datei():
    """Unlesbare Datei nicht überschreiben, sondern als einstellungen.json.defekt aufheben."""
    try:
        os.replace(_pfad(), _pfad() + ".defekt")
    except OSError:
        pass


def lade_einstellungen() -> dict:
    _uebernimm_alte_einstellungen()
    werte = {k: (list(v) if isinstance(v, list) else dict(v) if isinstance(v, dict) else v) for k, v in STANDARD.items()}
    try:
        if os.path.exists(_pfad()):
            werte.update(_passende_typen(_lies()))
        else:
            _schreibe(werte)
    except ValueError:
        _sichere_defekte_datei()                           # kaputtes JSON: Standardwerte, Datei aufheben
    except OSError:
        pass                                               # nicht lesbar/schreibbar: Standardwerte
    werte["gebuehren"] = [g.lower() for g in werte["gebuehren"]]
    return werte


def _schreibe(werte: dict):
    os.makedirs(einstellungsordner(), exist_ok=True)
    tmp = _pfad() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(werte, f, ensure_ascii=False, indent=2)
    os.replace(tmp, _pfad())


def speichere(schluessel: str, wert) -> bool:
    """Speichert einen Wert. Gibt False zurück, wenn die Datei nicht geschrieben werden konnte
    (der Wert gilt dann nur bis zum Programmende)."""
    EINSTELLUNGEN[schluessel] = wert
    try:
        gespeichert = _lies()
    except (OSError, ValueError):
        gespeichert = {k: v for k, v in EINSTELLUNGEN.items()}
    gespeichert[schluessel] = wert
    try:
        _schreibe(gespeichert)
        return True
    except OSError:
        return False


EINSTELLUNGEN = lade_einstellungen()
