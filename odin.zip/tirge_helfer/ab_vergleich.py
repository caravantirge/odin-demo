"""
Zwei Fassungen einer AB vergleichen.

Wichtig: Ausstattung, Bezeichnungen, Preise, Summe, Zahlungs- und Lieferbedingungen, ein
geänderter (nicht erstmals genannter) Liefertermin.
Info: erstmals genannte Termine, FIN, Serien-/Aufbau-Nr., Belegart, Fassung, Bestelltext/Kommission.
Nicht verglichen: Gewichte, Rechtstexte, Bemerkungszeilen ohne Positionsnummer (z. B. V349999).
Bezeichnungen werden ohne Leerzeichen-Unterschiede und ohne "MJ 2027" ↔ "2027 D" verglichen.
"""

import difflib
import re
from dataclasses import dataclass

from .ab_lesen import AB, Position

WICHTIG, INFO = "wichtig", "info"

KOPF_WICHTIG = {"Summe", "Nettobetrag", "Gesamtbetrag netto", "Zahlungsbedingungen", "Lieferbedingungen", "Vertragsbedingungen",
                "Lieferbedingung", "Modell", "Fahrgestell"}
# geändert wichtig, erstmals genannt nur Info (FIN/Seriennummer kommen oft erst mit einer späteren Fassung)
WICHTIG_WENN_GEAENDERT = {"Liefertermin", "Fahrgestell-Nr.", "Serien-Nr.", "Seriennummer", "Aufbau-Nr."}


def vergleichstext(s: str) -> str:
    """Gleicht reine Schreibvarianten aus, die keine inhaltliche Änderung sind."""
    s = " ".join((s or "").split())
    s = re.sub(r"\bMJ (20\d{2})\b", r"\1", s)        # Hersteller1 Vormerkung: "MJ 2027"
    s = re.sub(r"\b(20\d{2}) D\b", r"\1", s)          # Hersteller1 Bestätigung: "2027 D"
    s = re.sub(r"\s+%", "%", s)                         # Hersteller2: „-1 %“ und „-1%“
    return s


@dataclass
class Aenderung:
    stufe: str          # "wichtig" oder "info"
    bereich: str        # z. B. "Pos. 60 SM.WOHWEL13726" oder "Liefertermin"
    art: str            # z. B. "Preis entfallen"
    alt: str = ""
    neu: str = ""
    titel: str = ""     # Bezeichnung der Position, z. B. „Faltverdunkelung“ (bei Kopffeldern leer)
    stumm: bool = False  # per Regel stumm geschaltet: wird als Info gezeigt


def _ordne_positionen_zu(alt: list, neu: list):
    """Erst über die Artikelnummer, übrig gebliebene über die Positionsnummer."""
    paare, rest_alt, rest_neu = [], list(alt), list(neu)
    for p in list(rest_neu):
        treffer = next((a for a in rest_alt if a.artikel == p.artikel), None)
        if treffer:
            paare.append((treffer, p))
            rest_alt.remove(treffer)
            rest_neu.remove(p)
    for p in list(rest_neu):
        treffer = next((a for a in rest_alt if a.pos == p.pos), None)
        if treffer:
            paare.append((treffer, p))
            rest_alt.remove(treffer)
            rest_neu.remove(p)
    return paare, rest_alt, rest_neu


def _name(p: Position) -> str:
    return f"Pos. {p.pos} · {p.artikel}"


def _titel(p: Position) -> str:
    return " ".join((p.text or "").split())


def _vergleiche_preis(a: Position, n: Position, feld: str, titel: str, liste: list):
    va, vn = getattr(a, feld), getattr(n, feld)
    if va == vn:
        return
    if not va:
        liste.append(Aenderung(INFO, _name(n), f"{titel} nachgetragen", "", vn, _titel(n)))
    elif not vn:
        liste.append(Aenderung(WICHTIG, _name(n), f"{titel} entfallen", va, "", _titel(n)))
    else:
        liste.append(Aenderung(WICHTIG, _name(n), f"{titel} geändert", va, vn, _titel(n)))


def ist_seriennummer_vergeben(a: Position, n: Position, ab_neu: AB) -> bool:
    """Hersteller1 ersetzt die Artikelnummer der Basis durch S + Seriennummer. Nur das erste Mal ist das Info –
    eine andere Seriennummer (anderes Fahrzeug!) ist wichtig."""
    serie = re.sub(r"\D", "", ab_neu.kopf.get("Serien-Nr.", ""))
    return bool(serie) and n.artikel == f"S{serie}" and not re.fullmatch(r"S\d+", a.artikel or "")


def vergleiche(alt: AB, neu: AB) -> list:
    aenderungen = []

    for feld in dict.fromkeys(list(alt.kopf) + list(neu.kopf)):
        va, vn = alt.kopf.get(feld, ""), neu.kopf.get(feld, "")
        if vergleichstext(va) != vergleichstext(vn):
            art = "neu angegeben" if not va else ("entfallen" if not vn else "geändert")
            # Erstmals genannte Werte (z. B. Summe, Termin in der ersten richtigen AB) sind Info
            stufe = WICHTIG if va and (feld in KOPF_WICHTIG or feld in WICHTIG_WENN_GEAENDERT) else INFO
            aenderungen.append(Aenderung(stufe, feld, art, va, vn))

    paare, entfallen, hinzu = _ordne_positionen_zu(alt.positionen, neu.positionen)
    for a, n in sorted(paare, key=lambda x: int(x[1].pos) if x[1].pos.isdigit() else 0):
        if a.artikel != n.artikel:
            stufe = INFO if ist_seriennummer_vergeben(a, n, neu) else WICHTIG
            aenderungen.append(Aenderung(stufe, _name(n), "Artikelnummer geändert", a.artikel, n.artikel, _titel(n)))
        if vergleichstext(a.text) != vergleichstext(n.text):
            aenderungen.append(Aenderung(WICHTIG, _name(n), "Bezeichnung geändert", a.text, n.text, _titel(n)))
        if a.inhalt != n.inhalt:
            aenderungen.append(Aenderung(WICHTIG, _name(n), "Paketinhalt geändert",
                                         "; ".join(a.inhalt), "; ".join(n.inhalt), _titel(n)))
        if a.menge and n.menge and a.menge != n.menge:
            aenderungen.append(Aenderung(WICHTIG, _name(n), "Menge geändert", a.menge, n.menge, _titel(n)))
        if vergleichstext(a.rabatt) != vergleichstext(n.rabatt):
            art = "Rabatt neu" if not a.rabatt else "Rabatt entfallen" if not n.rabatt else "Rabatt geändert"
            aenderungen.append(Aenderung(WICHTIG, _name(n), art, a.rabatt, n.rabatt, _titel(n)))
        _vergleiche_preis(a, n, "einzelpreis", "Einzelpreis", aenderungen)
        # Gesamtpreis extra, wenn er sich anders als der Einzelpreis bewegt (z. B. Sonderrabatt auf 0,00)
        eigener_gesamtpreis = a.gesamtpreis != a.einzelpreis or n.gesamtpreis != n.einzelpreis
        if a.gesamtpreis != n.gesamtpreis and (a.einzelpreis == n.einzelpreis or eigener_gesamtpreis):
            _vergleiche_preis(a, n, "gesamtpreis", "Gesamtpreis", aenderungen)
    for a in entfallen:
        aenderungen.append(Aenderung(WICHTIG, _name(a), "Position entfallen", a.text, "", _titel(a)))
    for n in hinzu:
        aenderungen.append(Aenderung(WICHTIG, _name(n), "Position neu", "", n.text, _titel(n)))

    aenderungen.sort(key=lambda x: x.stufe != WICHTIG)
    return aenderungen


def _kurz(s: str, n: int = 36) -> str:
    s = " ".join((s or "").split())
    return s if len(s) <= n else s[:n - 1].rstrip(" ,;-") + "…"


def _unterschied(alt: str, neu: str):
    """Nur die Wörter, die sich unterscheiden – aus langen Texten wird so „150 → 360“.
    Gibt (vorher, nachher) zurück; ist nur etwas dazugekommen oder weggefallen, ist die andere Seite leer."""
    links, rechts = wortdiff(vergleichstext(alt), vergleichstext(neu))
    a = " ".join(w for w, g in links if g)
    n = " ".join(w for w, g in rechts if g)
    return a, n


def _differenz(alt: str, neu: str, laenge: int) -> str:
    """„150 → 360“, „+ 4,0 m“ (nur ergänzt) oder „− mit Backofen“ (nur gestrichen)."""
    a, n = _unterschied(alt, neu)
    if a and n:
        return f"{_kurz(a, laenge)} → {_kurz(n, laenge)}"
    if n:
        return f"+ {_kurz(n, 2 * laenge)}"
    if a:
        return f"− {_kurz(a, 2 * laenge)}"
    return f"{_kurz(alt, laenge)} → {_kurz(neu, laenge)}"


def kurztext(a: Aenderung) -> str:
    """Eine Zeile für die Übersicht: „Faltverdunkelung entfallen“, „Nettobetrag 50.974,21 → 50.486,88“."""
    if not a.bereich.startswith("Pos."):
        if a.art == "entfallen":
            return f"{a.bereich} entfallen"
        if a.art != "geändert":
            return f"{a.bereich} {_kurz(a.neu)}"
        if len(a.alt) + len(a.neu) <= 44:
            return f"{a.bereich} {a.alt} → {a.neu}"
        return f"{a.bereich} {_differenz(a.alt, a.neu, 22)}"
    name = _kurz(a.titel or a.alt or a.neu)
    if a.art == "Position entfallen":
        return f"{_kurz(a.alt or a.titel)} entfallen"
    if a.art == "Position neu":
        return f"{_kurz(a.neu or a.titel)} neu"
    if a.art == "Bezeichnung geändert":
        a_, n_ = _unterschied(a.alt, a.neu)
        if a_ and n_:
            return f"{_kurz(a_, 28)} → {_kurz(n_, 28)}"
        return f"{_kurz(a.alt, 30)}: {_differenz(a.alt, a.neu, 28)}"
    if a.art == "Menge geändert":
        return f"{name}: Menge {a.alt} → {a.neu}"
    if a.art.startswith("Rabatt"):
        if a.art != "Rabatt geändert":
            return f"{_kurz(a.neu or a.alt, 48)} {'neu' if a.art == 'Rabatt neu' else 'entfallen'}"
        bez_alt, _, rest_alt = a.alt.partition(" -")
        bez_neu, _, rest_neu = a.neu.partition(" -")
        if bez_alt == bez_neu and rest_alt and rest_neu:          # „Frühdisporabatt -1,50 % (…) → -2,00 % (…)“
            return f"{bez_neu} -{rest_alt} → -{rest_neu}"
        return f"{_kurz(a.alt, 40)} → {_kurz(a.neu, 40)}"
    if a.art.endswith("preis entfallen"):
        return f"{name}: Preis entfallen"
    if a.art.endswith("preis geändert"):
        return f"{name}: {a.alt} → {a.neu} €"
    if a.art == "Artikelnummer geändert":
        return f"{name}: Art.-Nr. {a.alt} → {a.neu}"
    if a.art == "Paketinhalt geändert":
        return f"{name}: Paketinhalt geändert"
    return f"{name}: {a.art}"



def zusammenfassung(aenderungen: list) -> str:
    wichtig = sum(a.stufe == WICHTIG for a in aenderungen)
    info = len(aenderungen) - wichtig
    if not aenderungen:
        return "Keine Änderung"
    teile = []
    if wichtig:
        teile.append(f"{wichtig} wichtige Änderung{'en' if wichtig != 1 else ''}")
    if info:
        teile.append(f"{info} Info")
    return ", ".join(teile)


def wortdiff(alt: str, neu: str):
    """Zerlegt beide Texte in Wörter und markiert, was sich unterscheidet.

    Gibt zwei Listen [(wort, geaendert), ...] zurück – eine für alt, eine für neu.
    """
    a, n = (alt or "").split(), (neu or "").split()
    links, rechts = [], []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(a=a, b=n, autojunk=False).get_opcodes():
        gleich = op == "equal"
        links += [(w, not gleich) for w in a[i1:i2]]
        rechts += [(w, not gleich) for w in n[j1:j2]]
    return links, rechts
