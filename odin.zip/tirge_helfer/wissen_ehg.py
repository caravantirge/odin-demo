"""In der Demo leer: die Schulungsinhalte sind nur für den internen Gebrauch."""
BILDER = frozenset()
EINSTEIGER = "Hersteller-Portal für Einsteiger"
ERSATZTEILE = "Hersteller-Portal: Ersatzteilkatalog"
LEADS = "Hersteller-Portal: Leads bearbeiten"
NUTZUNG = "Hersteller-Akademie nutzen"
VERWALTUNG = "Hersteller-Akademie: Mitarbeitende verwalten"
TRAININGS = "Hersteller-Akademie: Trainings buchen"
ANLEITUNGEN = []
