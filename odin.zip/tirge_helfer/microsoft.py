"""
Microsoft-Anmeldung je Benutzer (Microsoft Entra ID, delegiert) – ODIN ist ein „öffentlicher Client“ ohne Geheimnis.

- Angemeldet wird im Browser des Systems (Umleitung an http://localhost). Geht das nicht (kein Browser, Zeit
  abgelaufen), zeigt ODIN einen Code für microsoft.com/devicelogin. Danach holt ODIN neue Schlüssel still.
- Berechtigungen: nur User.Read (wer bin ich) und Mail.Send (Erinnerung ans eigene Postfach). Weitere kommen später
  in BERECHTIGUNGEN dazu – Microsoft fragt dann beim nächsten Anmelden einmal nach.
- „In ODIN arbeiten“ über Excel Online braucht zusätzlich Files.ReadWrite.All (BERECHTIGUNGEN_DATEIEN). Das gilt nur,
  wenn es unter Einstellungen eingeschaltet ist ('dateien()' liefert True) – sonst fragt ODIN gar nicht danach.
- Client-ID und Tenant-ID sind keine Geheimnisse (sie stehen in jeder Anmeldeadresse). Ein Client-Geheimnis gibt es
  nicht und braucht es nicht.
- Die Anmeldung (Token-Cache von MSAL) liegt je Windows-Benutzer im Einstellungsordner: unter Windows mit DPAPI
  verschlüsselt, auf dem Mac im Schlüsselbund – wie beim Syscara-Zugang (zugang.py). Ohne sicheren Speicher
  (Schlüsselbund gesperrt, Linux) gilt die Anmeldung nur bis zum Schließen und landet nie als Datei. Ältere Dateien
  mit bloß kodiertem Cache werden übernommen (sicher) oder weiter gelesen, aber nicht mehr geschrieben.
  Schlüssel und Cache kommen nie ins Protokoll, dort stehen höchstens Fehlercodes.
- Alles mit Zeitlimit und im Hintergrund: ist Microsoft nicht erreichbar, gibt es eine Meldung – ODIN hängt nicht.
"""

import base64
import datetime as dt
import json
import os
import re
import socket
import ssl
import subprocess
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

from . import zugang

BERECHTIGUNGEN = ("User.Read", "Mail.Send")
BERECHTIGUNGEN_DATEIEN = ("Files.ReadWrite.All",)     # Excel-Listen in SharePoint/OneDrive ändern (Excel Online)
GRAPH = "https://graph.microsoft.com/v1.0"
ANMELDE_ADRESSE = "https://login.microsoftonline.com/"
ZEITLIMIT = 20                      # Sekunden je Aufruf bei Microsoft
BROWSER_ZEIT = 150                  # so lange wartet ODIN auf die Anmeldung im Browser, dann weiter mit Code
CACHE_DATEI = "microsoft-anmeldung.json"
KONTO_DATEI = "microsoft-konto.json"
DIENST = "ODIN Microsoft"           # Eintrag im Mac-Schlüsselbund
SCHLUESSELBUND_KONTO = "token-cache"
GUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
CODE_SEITEN = ("microsoft.com", "microsoftonline.com")

# Seiten, die der Browser nach der Anmeldung zeigt (MSAL setzt $error/$error_description sicher maskiert ein)
_SEITE = ('<!doctype html><html lang="de"><head><meta charset="utf-8"><title>ODIN</title></head>'
          '<body style="font-family:system-ui,sans-serif;padding:32px;max-width:520px">{}</body></html>')
SEITE_OK = _SEITE.format("<h1 style=\"font-size:20px\">Angemeldet</h1><p>Du kannst dieses Fenster schließen und zu "
                         "ODIN zurückkehren.</p>")
SEITE_FEHLER = _SEITE.format("<h1 style=\"font-size:20px\">Anmeldung nicht geklappt</h1><p>$error_description</p>"
                             "<p>Du kannst dieses Fenster schließen – ODIN zeigt, wie es weitergeht.</p>")

KEINE_VERBINDUNG = "Keine Verbindung zu Microsoft – bitte Internet prüfen und später noch einmal versuchen."
BITTE_NEU = "Bitte neu anmelden – die gespeicherte Anmeldung gilt nicht mehr."


class MicrosoftFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche. 'status' ist der HTTP-Status (falls es einen gab)."""

    def __init__(self, text: str, status: int = None):
        super().__init__(text)
        self.status = status


class NeuAnmelden(MicrosoftFehler):
    """Die gespeicherte Anmeldung gilt nicht mehr (abgelaufen, widerrufen, abgemeldet)."""


def guid(wert, feld: str = "ID") -> str:
    """GUID prüfen und in Kleinbuchstaben zurückgeben („1234abcd-…“). Leer bleibt leer."""
    text = str(wert or "").strip().strip("{}").lower()
    if text and not GUID.fullmatch(text):
        raise MicrosoftFehler(f"Die {feld} hat nicht das richtige Format – sie sieht so aus: "
                              "1a2b3c4d-1234-5678-9abc-1234567890ab.")
    return text


def _netzfehler(e: BaseException) -> bool:
    if isinstance(e, (ConnectionError, TimeoutError, socket.timeout, ssl.SSLError, urllib.error.URLError)):
        return True
    try:
        import requests
        return isinstance(e, requests.exceptions.RequestException)
    except ImportError:                                  # ohne msal/requests gibt es auch keine Anfragen
        return False


def fehlertext(erg: dict) -> str:
    """Antwort von Microsoft mit „error“ → verständlicher Satz (ohne Einzelheiten, die niemand braucht)."""
    erg = erg if isinstance(erg, dict) else {}
    fehler = str(erg.get("error") or "")
    beschreibung = str(erg.get("error_description") or "")
    codes = set(re.findall(r"AADSTS(\d+)", beschreibung)) | {str(c) for c in (erg.get("error_codes") or [])}
    if codes & {"65001", "65004"} and fehler != "access_denied":
        return ("Für ODIN fehlt noch die Zustimmung: In Microsoft Entra bei der App-Registrierung unter "
                "„API-Berechtigungen“ auf „Administratorzustimmung erteilen“ klicken.")
    if "700016" in codes:
        return "Microsoft kennt diese Client-ID in eurem Mandanten nicht – bitte Client-ID und Tenant-ID prüfen."
    if "7000218" in codes or fehler == "invalid_client":
        return ("In der App-Registrierung muss unter „Authentifizierung“ die Einstellung „Öffentliche Clientflows "
                "zulassen“ auf „Ja“ stehen.")
    if codes & {"90002", "900023"}:
        return "Microsoft kennt diese Tenant-ID nicht – bitte unter „Einrichtung“ prüfen."
    if codes & {"50020", "90072", "50034"}:
        return "Dieses Konto gehört nicht zu eurem Microsoft-Mandanten – bitte mit dem Firmenkonto anmelden."
    if "50011" in codes:
        return ("In der App-Registrierung fehlt die Umleitungs-URI http://localhost (Plattform „Mobilgerät- und "
                "Desktopanwendungen“).")
    if codes & {"50076", "50079", "50158", "53003"}:
        return "Microsoft verlangt eine zusätzliche Bestätigung oder lässt die Anmeldung hier nicht zu – bitte neu anmelden."
    if fehler in ("access_denied", "authorization_declined"):
        return "Anmeldung abgebrochen."
    if fehler in ("expired_token", "code_expired", "bad_verification_code"):
        return "Der Code ist abgelaufen – bitte noch einmal anmelden."
    if fehler in ("invalid_grant", "interaction_required", "login_required", "consent_required"):
        return BITTE_NEU
    return f"Microsoft hat die Anmeldung abgelehnt ({fehler or 'ohne Angabe'}" + \
        (f", AADSTS{sorted(codes)[0]}" if codes else "") + ")."


# ---------------- Microsoft Graph ----------------

def _ssl_kontext():
    kontext = ssl.create_default_context()           # Windows: Zertifikate des Systems
    if sys.platform == "darwin" or getattr(sys, "frozen", False):
        try:                                         # Mac/fertiges Programm: ohne certifi kennt Python keine Zertifikate
            import certifi
            kontext.load_verify_locations(certifi.where())
        except (ImportError, OSError):
            pass
    return kontext


def _graph_fehlercode(e: urllib.error.HTTPError) -> str:
    try:
        antwort = json.loads(e.read().decode("utf-8", "replace") or "{}")
        return str((antwort.get("error") or {}).get("code") or "")[:80]
    except (OSError, ValueError, AttributeError):
        return ""


def graph_anfrage(methode: str, pfad: str, token: str, daten=None, roh: bytes = None, inhaltstyp: str = None,
                  basis: str = GRAPH, kopf_extra: dict = None):
    """Ein Aufruf an Microsoft Graph. Antwort als JSON (leer: {}); Fehler als MicrosoftFehler mit verständlichem Text.
    'kopf_extra': zusätzliche Kopfzeilen, z. B. „workbook-session-id“ für Excel Online."""
    kopf = {"Authorization": f"Bearer {token}", "Accept": "application/json", "User-Agent": "ODIN"}
    for name, wert in (kopf_extra or {}).items():
        if isinstance(name, str) and isinstance(wert, str) and name.lower() not in ("authorization", "host"):
            kopf[name] = wert
    koerper = None
    if daten is not None:
        koerper = json.dumps(daten, ensure_ascii=False).encode("utf-8")
        kopf["Content-Type"] = "application/json"
    elif roh is not None:
        koerper = roh
        kopf["Content-Type"] = inhaltstyp or "text/plain"
    anfrage = urllib.request.Request(basis.rstrip("/") + pfad, data=koerper, headers=kopf, method=methode)
    try:
        kontext = _ssl_kontext() if anfrage.full_url.startswith("https:") else None
        with urllib.request.urlopen(anfrage, timeout=ZEITLIMIT, context=kontext) as antwort:
            inhalt = antwort.read()
    except urllib.error.HTTPError as e:
        code = _graph_fehlercode(e)
        if e.code == 401:
            raise NeuAnmelden(BITTE_NEU, 401) from None
        if e.code == 403:
            raise MicrosoftFehler("Microsoft erlaubt ODIN das nicht – fehlt die Berechtigung „Mail.Send“ oder die "
                                  "Zustimmung des Administrators?", 403) from None
        if code in ("MailboxNotEnabledForRESTAPI", "ResourceNotFound", "ErrorMailboxNotFound") or e.code == 404:
            raise MicrosoftFehler("Zu deinem Konto gibt es kein Exchange-Postfach, über das ODIN senden kann.",
                                  e.code) from None
        if e.code in (429, 502, 503, 504):
            raise MicrosoftFehler("Microsoft ist gerade ausgelastet – bitte später noch einmal versuchen.", e.code) from None
        raise MicrosoftFehler(f"Microsoft antwortet mit Fehler {e.code}" + (f" ({code})" if code else "") + ".",
                              e.code) from None
    except ssl.SSLError as e:
        raise MicrosoftFehler(f"Keine sichere Verbindung zu Microsoft möglich ({e.reason or e}).") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise MicrosoftFehler(KEINE_VERBINDUNG) from None
    try:
        return json.loads(inhalt.decode("utf-8-sig")) if inhalt.strip() else {}
    except (UnicodeDecodeError, ValueError):
        raise MicrosoftFehler("Microsoft hat keine lesbare Antwort geschickt.") from None


def mime_nachricht(an: str, betreff: str, text: str, html: str) -> bytes:
    """Mail mit Text- und HTML-Teil (multipart/alternative) – so, wie Graph sie im MIME-Format annimmt."""
    m = EmailMessage()
    m["To"] = an
    m["From"] = an
    m["Subject"] = betreff
    m["Date"] = formatdate(localtime=True)
    m["Message-ID"] = make_msgid(domain="odin.local")
    m.set_content(text)
    m.add_alternative(html, subtype="html")
    return m.as_bytes()


# ---------------- Ablage der Anmeldung ----------------

class TokenSpeicher:
    """Token-Cache von MSAL für den angemeldeten Benutzer – verschlüsselt wie der Syscara-Zugang."""

    def __init__(self, ordner: str, plattform: str = None, dienst: str = DIENST):
        self.ordner = ordner
        self.plattform = plattform or sys.platform
        self.dienst = dienst
        self._sitzung = None                    # Cache ohne sicheren Speicher: nur bis Programmende

    @property
    def pfad(self) -> str:
        return os.path.join(self.ordner, CACHE_DATEI)

    def vorhanden(self) -> bool:
        return self._sitzung is not None or os.path.exists(self.pfad)

    def _schreibe(self, daten: dict):
        os.makedirs(self.ordner, exist_ok=True)
        tmp = self.pfad + ".tmp"
        with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8") as f:
            json.dump(daten, f)
        os.replace(tmp, self.pfad)

    def _sicher_ablegen(self, roh: bytes) -> str:
        """Windows: DPAPI, Mac: Schlüsselbund – „verschlüsselt“/„Schlüsselbund“, sonst "" (kein sicherer Speicher)."""
        if self.plattform == "win32":
            self._schreibe({"art": "dpapi", "daten": base64.b64encode(zugang._dpapi(roh, True)).decode()})
            return "verschlüsselt"
        if self.plattform == "darwin":
            try:
                zugang._security("add-generic-password", "-U", "-s", self.dienst, "-a", SCHLUESSELBUND_KONTO, "-w",
                                 base64.b64encode(roh).decode())
                self._schreibe({"art": "schluesselbund"})
                return "Schlüsselbund"
            except (OSError, subprocess.SubprocessError):
                return ""                               # z. B. Schlüsselbund gesperrt
        return ""

    def speichere(self, cache: str) -> str:
        """Gibt zurück, wie gespeichert wurde: „verschlüsselt“, „Schlüsselbund“ oder „Sitzung“ (nur bis zum
        Schließen im Arbeitsspeicher – eine ältere Datei bleibt lesbar, wird aber nicht mehr geschrieben)."""
        wie = self._sicher_ablegen(cache.encode("utf-8"))
        if wie:
            self._sitzung = None
            return wie
        self._sitzung = cache
        return "Sitzung"

    def lade(self) -> str:
        """Der gespeicherte Cache als Text – leer, wenn nichts da oder nicht (mehr) lesbar. Ein älterer, nur kodierter
        Cache wird dabei – wenn möglich – in den sicheren Speicher übernommen (die Datei damit ersetzt)."""
        if self._sitzung is not None:
            return self._sitzung
        try:
            with open(self.pfad, encoding="utf-8") as f:
                daten = json.load(f)
        except (OSError, ValueError):
            return ""
        art = daten.get("art") if isinstance(daten, dict) else ""
        try:
            if art == "dpapi":
                return zugang._dpapi(base64.b64decode(daten["daten"]), False).decode("utf-8")
            if art == "schluesselbund":
                roh = zugang._security("find-generic-password", "-s", self.dienst, "-a", SCHLUESSELBUND_KONTO, "-w")
                return base64.b64decode(roh.strip(), validate=True).decode("utf-8")
            if art == "datei":
                roh = base64.b64decode(daten["daten"])
                try:
                    self._sicher_ablegen(roh)
                except (OSError, ValueError):
                    pass                                # weiter lesen, nicht schreiben – sicherheit() warnt
                return roh.decode("utf-8")
        except (OSError, KeyError, TypeError, ValueError, subprocess.SubprocessError):
            return ""
        return ""

    def sicherheit(self) -> dict:
        """Wie liegt die Anmeldung? {"art": "dpapi"|"schluesselbund"|"sitzung"|"datei"|"", "hinweis", "warnung"}."""
        if self._sitzung is not None:
            return {"art": "sitzung", "warnung": False, "hinweis": "Auf diesem Rechner gibt es keinen sicheren "
                    "Speicher – die Anmeldung wird nur bis zum Schließen von ODIN gemerkt."}
        try:
            with open(self.pfad, encoding="utf-8") as f:
                art = (json.load(f) or {}).get("art", "")
        except (OSError, ValueError, AttributeError):
            art = ""
        if art == "datei":
            return {"art": "datei", "warnung": True, "hinweis": "Die Anmeldung liegt noch in einer älteren, nicht "
                    "verschlüsselten Datei. Bitte abmelden und unter Windows oder mit entsperrtem Mac-Schlüsselbund "
                    "neu anmelden."}
        return {"art": art, "warnung": False, "hinweis": ""}

    def loesche(self):
        self._sitzung = None
        if self.plattform == "darwin":
            try:
                zugang._security("delete-generic-password", "-s", self.dienst, "-a", SCHLUESSELBUND_KONTO)
            except (OSError, subprocess.SubprocessError):
                pass
        for pfad in (self.pfad, self.pfad + ".tmp"):
            try:
                os.remove(pfad)
            except FileNotFoundError:
                pass


# ---------------- Anmeldung ----------------

class Anmeldung:
    """Anmelden, abmelden, still neue Schlüssel holen, /me lesen und Mails an sich selbst senden.

    'konfig()' liefert {"client_id", "tenant_id"} (leer = noch nicht eingerichtet). 'bei_anmeldung(konto)' wird nach
    einer erfolgreichen Anmeldung aufgerufen (z. B. Person verknüpfen) und kann eine Meldung zurückgeben.
    'msal_modul' und 'graph' sind nur für Tests (ohne Netzwerk)."""

    def __init__(self, ordner: str, konfig, protokoll=None, msal_modul=None, graph=None, plattform: str = None,
                 browser=None, dateien=None):
        self.ordner = ordner
        self._dateien = dateien or (lambda: False)     # Excel Online („In ODIN arbeiten“) eingeschaltet?
        self._konfig = konfig
        self._protokoll = protokoll or (lambda text: None)
        self._msal_modul = msal_modul
        self._graph = graph or graph_anfrage
        self._browser = browser or webbrowser.open
        self.speicher = TokenSpeicher(ordner, plattform)
        self.bei_anmeldung = None
        self._sperre = threading.RLock()        # Zustand des Anmeldevorgangs – nie während eines Netzaufrufs halten
        self._app_sperre = threading.Lock()     # Aufbau der MSAL-App (kann ein paar Sekunden dauern)
        self._konto_sperre = threading.Lock()
        self._app = None
        self._app_fuer = None
        self._cache = None
        self._flow = None
        self._vorgang = {"nr": 0, "laeuft": False, "art": "", "code": None, "fehler": "", "meldung": ""}

    # ---------- MSAL ----------
    def _msal(self):
        if self._msal_modul is not None:
            return self._msal_modul
        try:
            import msal
        except ImportError:
            raise MicrosoftFehler("Die Microsoft-Anmeldung fehlt in dieser ODIN-Version – bitte die aktuelle Version "
                                  "installieren.") from None
        self._msal_modul = msal
        return msal

    def berechtigungen(self) -> list:
        try:
            mit_dateien = bool(self._dateien())
        except Exception:                             # noqa: BLE001 – Einstellung nicht lesbar: ohne Dateien
            mit_dateien = False
        return list(BERECHTIGUNGEN) + (list(BERECHTIGUNGEN_DATEIEN) if mit_dateien else [])

    def graph(self, methode: str, pfad: str, token: str, daten=None, kopf_extra: dict = None):
        """Graph-Aufruf für andere Module (z. B. Excel Online in aktionen/excel.py)."""
        if kopf_extra:
            return self._graph(methode, pfad, token, daten=daten, kopf_extra=kopf_extra)
        return self._graph(methode, pfad, token, daten=daten)

    def verfuegbar(self) -> bool:
        try:
            self._msal()
            return True
        except MicrosoftFehler:
            return False

    def _konfig_pflicht(self) -> dict:
        k = self._konfig() or {}
        if not k.get("client_id") or not k.get("tenant_id"):
            raise MicrosoftFehler("Die Microsoft-Anmeldung ist noch nicht eingerichtet – unter „Einrichtung“ "
                                  "Client-ID und Tenant-ID eintragen.")
        return k

    def _app_holen(self):
        k = self._konfig_pflicht()
        schluessel = (k["client_id"], k["tenant_id"])
        with self._app_sperre:
            if self._app is not None and self._app_fuer == schluessel:
                return self._app
            msal = self._msal()
            cache = msal.SerializableTokenCache()
            roh = self.speicher.lade()
            if roh:
                try:
                    cache.deserialize(roh)
                except Exception:                     # noqa: BLE001 – kaputter Cache: einfach neu anmelden
                    self._protokoll("Microsoft: gespeicherte Anmeldung nicht lesbar – neu anmelden nötig")
            try:
                app = msal.PublicClientApplication(k["client_id"], authority=ANMELDE_ADRESSE + k["tenant_id"],
                                                   token_cache=cache, timeout=ZEITLIMIT)
            except Exception as e:                    # noqa: BLE001
                if _netzfehler(e):
                    raise MicrosoftFehler(KEINE_VERBINDUNG) from None
                if isinstance(e, ValueError):
                    raise MicrosoftFehler("Microsoft kennt diese Tenant-ID nicht – bitte unter „Einrichtung“ prüfen.") from None
                self._protokoll(f"Microsoft: Anmeldung ließ sich nicht vorbereiten ({type(e).__name__})")
                raise MicrosoftFehler("Die Microsoft-Anmeldung ließ sich nicht starten – Details stehen im Protokoll.") from None
            self._app, self._app_fuer, self._cache = app, schluessel, cache
            return app

    def zuruecksetzen(self):
        """Nach geänderter Einrichtung: die MSAL-App neu aufbauen (die gespeicherte Anmeldung bleibt)."""
        with self._app_sperre:
            self._app = self._app_fuer = self._cache = None

    def _cache_sichern(self):
        cache = self._cache
        if cache is None or not getattr(cache, "has_state_changed", False):
            return
        try:
            self.speicher.speichere(cache.serialize())
            cache.has_state_changed = False
        except Exception as e:                        # noqa: BLE001 – dann gilt die Anmeldung nur bis Programmende
            self._protokoll(f"Microsoft: Anmeldung ließ sich nicht speichern ({type(e).__name__})")

    # ---------- wer angemeldet ist (nicht geheim, ohne Netzwerk) ----------
    @property
    def _konto_pfad(self) -> str:
        return os.path.join(self.ordner, KONTO_DATEI)

    def konto(self) -> dict:
        try:
            with open(self._konto_pfad, encoding="utf-8") as f:
                daten = json.load(f)
        except (OSError, ValueError):
            return {}
        return daten if isinstance(daten, dict) else {}

    def konto_aendern(self, **felder) -> dict:
        with self._konto_sperre:
            daten = {**self.konto(), **felder}
            os.makedirs(self.ordner, exist_ok=True)
            tmp = self._konto_pfad + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(daten, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self._konto_pfad)
            return daten

    def _konto_loeschen(self):
        with self._konto_sperre:
            try:
                os.remove(self._konto_pfad)
            except FileNotFoundError:
                pass

    def angemeldet(self) -> bool:
        """Schnell und ohne Netzwerk: Gibt es eine gespeicherte Anmeldung? (Ob sie noch gilt, zeigt erst token().)"""
        return bool(self.konto().get("email")) and self.speicher.vorhanden()

    def status(self) -> dict:
        konto = self.konto()
        k = self._konfig() or {}
        angemeldet = self.angemeldet()
        with self._sperre:
            v = dict(self._vorgang)
        geaendert = angemeldet and bool(konto.get("client_id")) and \
            (konto.get("client_id"), konto.get("tenant_id")) != (k.get("client_id"), k.get("tenant_id"))
        return {"verfuegbar": self.verfuegbar(), "eingerichtet": bool(k.get("client_id") and k.get("tenant_id")),
                "angemeldet": angemeldet, "name": konto.get("name", "") if angemeldet else "",
                "email": konto.get("email", "") if angemeldet else "",
                "angemeldet_am": konto.get("angemeldet_am", "") if angemeldet else "",
                "einrichtung_geaendert": geaendert,
                "speicher": self.speicher.sicherheit() if angemeldet else {"art": "", "warnung": False, "hinweis": ""},
                "vorgang": {"laeuft": v["laeuft"], "art": v["art"], "code": v["code"], "fehler": v["fehler"],
                            "meldung": v["meldung"]}}

    # ---------- anmelden ----------
    def anmelden(self, art: str = "browser") -> dict:
        """Startet die Anmeldung im Hintergrund (Browser oder Code). Den Fortschritt zeigt status()."""
        if art not in ("browser", "code"):
            raise MicrosoftFehler("Unbekannte Anmeldeart.")
        self._msal()
        self._konfig_pflicht()
        with self._sperre:
            v = self._vorgang
            if v["laeuft"] and (art == "browser" or v["art"] == "code"):
                return self.status()                  # läuft schon
            nr = v["nr"] + 1
            self._vorgang = {"nr": nr, "laeuft": True, "art": art, "code": None, "fehler": "", "meldung": ""}
        threading.Thread(target=self._lauf, args=(nr, art), name="ODIN-Anmeldung", daemon=True).start()
        return self.status()

    def _aktuell(self, nr: int) -> bool:
        with self._sperre:
            return self._vorgang["nr"] == nr and self._vorgang["laeuft"]

    def _ende(self, nr: int, fehler: str = "", meldung: str = ""):
        with self._sperre:
            if self._vorgang["nr"] == nr:
                self._vorgang.update(laeuft=False, code=None, fehler=fehler, meldung=meldung)

    def _lauf(self, nr: int, art: str):
        try:
            app = self._app_holen()
            erg = None
            if art == "browser":
                erg = self._im_browser(app)
                if erg is None:
                    if not self._aktuell(nr):
                        return                        # inzwischen mit Code angemeldet oder abgebrochen
                    self._protokoll("Microsoft: keine Antwort aus dem Browser – weiter mit Code")
                    with self._sperre:
                        self._vorgang["art"] = "code"
                    art = "code"
            if art == "code":
                erg = self._mit_code(app, nr)
                if erg is None:
                    return
            self._fertig(erg, nr)
        except MicrosoftFehler as e:
            self._ende(nr, fehler=str(e))
        except Exception as e:                        # noqa: BLE001 – der Faden darf nie mit einem Fehler enden
            self._protokoll(f"Microsoft: Anmeldung fehlgeschlagen ({type(e).__name__})")
            self._ende(nr, fehler=KEINE_VERBINDUNG if _netzfehler(e)
                       else "Die Anmeldung hat nicht geklappt – Details stehen im Protokoll.")

    def _im_browser(self, app):
        """Anmeldung im Browser des Systems. None: Browser ging nicht oder keine Antwort – dann weiter mit Code."""
        try:
            erg = app.acquire_token_interactive(self.berechtigungen(), prompt="select_account", timeout=BROWSER_ZEIT,
                                                success_template=SEITE_OK, error_template=SEITE_FEHLER)
        except Exception as e:                        # noqa: BLE001 – kein Browser, Port belegt, Zeit abgelaufen …
            if _netzfehler(e):
                raise MicrosoftFehler(KEINE_VERBINDUNG) from None
            return None
        if not isinstance(erg, dict):
            return None
        if "access_token" not in erg:
            self._protokoll(f"Microsoft: Anmeldung im Browser abgelehnt ({erg.get('error') or '?'})")
            raise MicrosoftFehler(fehlertext(erg))
        return erg

    def _mit_code(self, app, nr: int):
        flow = app.initiate_device_flow(scopes=self.berechtigungen())
        if not isinstance(flow, dict) or "user_code" not in flow:
            self._protokoll(f"Microsoft: kein Anmeldecode ({(flow or {}).get('error') or '?'})")
            raise MicrosoftFehler(fehlertext(flow or {}))
        with self._sperre:
            if not self._aktuell(nr):
                return None
            self._flow = flow
            self._vorgang["code"] = {"code": str(flow["user_code"]),
                                     "adresse": str(flow.get("verification_uri") or "https://microsoft.com/devicelogin"),
                                     "bis": int(flow.get("expires_at") or 0)}
        erg = app.acquire_token_by_device_flow(flow)  # wartet, bis angemeldet, abgelaufen oder abgebrochen
        with self._sperre:
            if self._flow is flow:
                self._flow = None
        if flow.get("odin_abgebrochen") or not self._aktuell(nr):
            return None
        if not isinstance(erg, dict) or "access_token" not in erg:
            self._protokoll(f"Microsoft: Anmeldung mit Code abgelehnt ({(erg or {}).get('error') or '?'})")
            raise MicrosoftFehler(fehlertext(erg or {}))
        return erg

    def _fertig(self, erg: dict, nr: int):
        """Angemeldet: Cache sichern, /me lesen, Konto merken, Person verknüpfen."""
        self._cache_sichern()
        anspruch = erg.get("id_token_claims") or {}
        try:
            ich = self._graph("GET", "/me?$select=id,displayName,mail,userPrincipalName", erg["access_token"])
        except MicrosoftFehler as e:                  # dann eben aus dem ID-Token
            self._protokoll(f"Microsoft: /me nicht lesbar ({e.status or 'ohne Status'})")
            ich = {}
        email = str(ich.get("mail") or ich.get("userPrincipalName") or anspruch.get("preferred_username") or "")
        email = email.strip().casefold()
        if not email:
            raise MicrosoftFehler("Microsoft hat keine E-Mail-Adresse zu diesem Konto geliefert.")
        k = self._konfig() or {}
        konto = self.konto_aendern(
            name=str(ich.get("displayName") or anspruch.get("name") or email), email=email,
            benutzername=str(ich.get("userPrincipalName") or anspruch.get("preferred_username") or email).casefold(),
            oid=str(ich.get("id") or anspruch.get("oid") or ""), client_id=k.get("client_id", ""),
            tenant_id=k.get("tenant_id", ""), angemeldet_am=dt.datetime.now().isoformat(timespec="seconds"))
        meldung = f"Angemeldet als {konto['name']}."
        if self.bei_anmeldung:
            try:
                meldung = self.bei_anmeldung(konto) or meldung
            except Exception as e:                    # noqa: BLE001 – verknüpfen geht notfalls auch von Hand
                self._protokoll(f"Microsoft: nach der Anmeldung: {type(e).__name__}: {e}")
        with self._sperre:
            if self._flow is not None:                # angemeldet, während noch ein Code wartete
                self._flow["odin_abgebrochen"] = True
                self._flow["expires_at"] = 0
            if self._vorgang["laeuft"] or self._vorgang["nr"] == nr:    # nicht, wenn inzwischen abgemeldet
                self._vorgang.update(laeuft=False, code=None, fehler="", meldung=meldung)

    def abbrechen(self) -> dict:
        with self._sperre:
            if self._flow is not None:
                self._flow["odin_abgebrochen"] = True
                self._flow["expires_at"] = 0
            self._vorgang.update(nr=self._vorgang["nr"] + 1, laeuft=False, code=None, fehler="",
                                 meldung="Anmeldung abgebrochen.")
        return self.status()

    def code_seite_oeffnen(self) -> bool:
        """Die Seite für den Anmeldecode im Browser öffnen – nur die Adresse, die Microsoft dafür genannt hat."""
        with self._sperre:
            code = self._vorgang.get("code") or {}
        adresse = str(code.get("adresse") or "")
        teile = urllib.parse.urlparse(adresse)
        host = (teile.hostname or "").lower()
        if teile.scheme != "https" or not any(host == s or host.endswith("." + s) for s in CODE_SEITEN):
            raise MicrosoftFehler("Gerade wartet keine Anmeldung mit Code.")
        return bool(self._browser(adresse))

    def abmelden(self) -> dict:
        """Löscht die gespeicherte Anmeldung dieses Benutzers (Cache und Konto) – ohne Netzwerk."""
        with self._sperre:
            if self._flow is not None:
                self._flow["odin_abgebrochen"] = True
                self._flow["expires_at"] = 0
            self._vorgang = {"nr": self._vorgang["nr"] + 1, "laeuft": False, "art": "", "code": None, "fehler": "",
                             "meldung": "Abgemeldet."}
        with self._app_sperre:
            self._app = self._app_fuer = self._cache = None
        self.speicher.loesche()
        self._konto_loeschen()
        return self.status()

    # ---------- danach: still ----------
    def token(self) -> str:
        """Gültiger Schlüssel für Graph – still aus dem Cache, wenn nötig erneuert. Sonst NeuAnmelden/MicrosoftFehler."""
        konto = self.konto()
        if not konto.get("email") or not self.speicher.vorhanden():
            raise NeuAnmelden("Bitte zuerst mit Microsoft anmelden.")
        app = self._app_holen()
        try:
            konten = app.get_accounts() or []
            namen = {konto.get("benutzername"), konto.get("email")}
            wahl = next((a for a in konten if str(a.get("username") or "").casefold() in namen), None)
            if wahl is None and len(konten) == 1:
                wahl = konten[0]
            if wahl is None:
                raise NeuAnmelden(BITTE_NEU)
            erg = app.acquire_token_silent(self.berechtigungen(), account=wahl)
        except MicrosoftFehler:
            raise
        except Exception as e:                        # noqa: BLE001
            if _netzfehler(e):
                raise MicrosoftFehler(KEINE_VERBINDUNG) from None
            self._protokoll(f"Microsoft: stilles Anmelden fehlgeschlagen ({type(e).__name__})")
            raise MicrosoftFehler("Die Anmeldung bei Microsoft hat nicht geklappt – bitte neu anmelden.") from None
        if not erg:
            raise NeuAnmelden(BITTE_NEU)
        if "access_token" not in erg:
            self._protokoll(f"Microsoft: stilles Anmelden abgelehnt ({erg.get('error') or '?'})")
            text = fehlertext(erg)
            raise (NeuAnmelden(text) if text == BITTE_NEU else MicrosoftFehler(text))
        self._cache_sichern()
        return erg["access_token"]

    def ich(self) -> dict:
        """Name und Adresse aus Microsoft (GET /me)."""
        ich = self._graph("GET", "/me?$select=id,displayName,mail,userPrincipalName", self.token())
        return {"name": ich.get("displayName") or "", "email": str(ich.get("mail") or ich.get("userPrincipalName") or "").casefold()}

    def mail_an_mich(self, betreff: str, text: str, html: str):
        """Mail an die eigene Adresse über das eigene Postfach (POST /me/sendMail). Erst als MIME mit Text- und
        HTML-Teil; lehnt Microsoft das Format ab, als HTML-Nachricht."""
        an = self.konto().get("email")
        token = self.token()
        if not an:
            raise NeuAnmelden("Bitte zuerst mit Microsoft anmelden.")
        try:
            self._graph("POST", "/me/sendMail", token, roh=base64.b64encode(mime_nachricht(an, betreff, text, html)),
                        inhaltstyp="text/plain")
            return
        except MicrosoftFehler as e:
            if e.status not in (400, 415):
                raise
            self._protokoll(f"Microsoft: Mail im MIME-Format abgelehnt ({e.status}) – sende als HTML")
        self._graph("POST", "/me/sendMail", token, daten={
            "message": {"subject": betreff, "body": {"contentType": "HTML", "content": html},
                        "toRecipients": [{"emailAddress": {"address": an}}]},
            "saveToSentItems": False})
