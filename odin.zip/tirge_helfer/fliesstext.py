"""
Preisschild-PDF (Muster-Layout) -> Interne ID, Hersteller, Modell und Fließtext.

Regeln (Stand: Jan-Abstimmung):
1. Position mit Preis in der Kopfzeile und Inhaltsliste darunter (Paket)
   -> nur der Paketname, Inhalt verworfen.
   Ausnahme: Pakete aus INHALT_PAKETE (z. B. Hersteller3 Monte Paket) -> Name + Inhalt.
2. Verschachtelte Unterpakete ohne eigenen Preis (zwischen "+ -"-Zeilen)
   -> verworfen, nur das Hauptpaket bleibt.
3. Gebühren (Zulassungsdokumente, Überführung, Versicherung ...) -> verworfen.
4. Lange unbepreiste Blöcke (Serien-/Basisausstattung, Aktionstexte) -> verworfen.
5. Farbe -> immer übernehmen (wenn sie als eigene Zeile vorhanden ist).
6. Kurze unbepreiste Einzelauswahl (Wohnwelt, Dekor) -> übernehmen.
7. Normale bepreiste Einzelposten -> übernehmen.
Motor/Getriebe stehen genau einmal vorne in der Basiszeile.
"""

import re
from dataclasses import dataclass, field

import pdfplumber

from .einstellungen import EINSTELLUNGEN

PREIS_RE = re.compile(r"([\d.]+(?:,\d{2})?)\s?€\s*$")

HAENGENDE_WOERTER = {
    "und", "mit", "inkl", "inkl.", "für", "von", "im", "in", "auf",
    "sowie", "ohne", "bei", "zur", "zum", "der", "die", "das", "des", "dem", "als",
}

ID_WERT = r"[A-Z]{1,6}\d{3,6}"


@dataclass
class Ergebnis:
    datei: str
    interne_id: str = ""
    hersteller: str = ""
    modell: str = ""
    fliesstext: str = ""
    hinweise: list = field(default_factory=list)      # Warnungen -> Status "Prüfen"
    weggelassen: list = field(default_factory=list)   # nur zur Info
    fehler: str = ""
    werbe_optionen: list = field(default_factory=list)  # mobile.de: erkannte Merkmale, wertvollste zuerst
    pfad: str = ""                                     # PDF zum Öffnen (bei hineingezogenen Dateien eine Kopie)
    modell_kurz: str = ""                              # mobile.de: Vorschlag fürs Modell-Feld, z. B. „540“
    werbetext: str = ""                                # mobile.de: Modell + Kürzel, höchstens 48 Zeichen
    quelle: str = ""                                   # "" = Preisschild-PDF, "Syscara" = aus der Schnittstelle

    @property
    def status(self) -> str:
        if self.fehler:
            return "Fehler"
        if self.hinweise:
            return "Prüfen"
        return "OK"


# ---------------- Kopf und technische Daten (Seite 1) ----------------

def lies_hersteller_modell(seite1: str):
    """Hersteller steht als eigene Zeile, das Modell in der Zeile darunter."""
    zeilen = [z.strip() for z in seite1.split("\n") if z.strip()]
    for i, z in enumerate(zeilen):
        for h in EINSTELLUNGEN["hersteller"]:
            if z.lower() == h.lower() and i + 1 < len(zeilen):
                return h, zeilen[i + 1]
    return "", ""


def lies_technische_daten(seite1: str) -> dict:
    """Liest die Kernfelder der Technische-Daten-Tabelle anhand ihrer Bezeichnungen."""
    t = re.sub(r"\s+", " ", seite1)
    labels = (
        r"Modell-/Baujahr|Motordetails|Leistung|Länge|Breite|Höhe|Gesamtmasse|"
        r"Getriebe|Sitzgruppe|Betten|Schlafplätze|Sitze mit Gurt|Interne ID"
    )
    td = {}
    m = re.search(rf"Basisfahrzeug\s+(.+?)\s+(?:{labels})", t)
    td["basisfahrzeug"] = m.group(1).strip() if m else ""
    m = re.search(r"Leistung\s+(\d+)\s*kW\s*/\s*(\d+)\s*PS", t)
    td["kw"], td["ps"] = (m.group(1), m.group(2)) if m else ("", "")
    m = re.search(r"Gesamtmasse\s+([\d.,]+)\s*kg", t)
    td["gesamtmasse"] = m.group(1) if m else ""
    # Werte nur aus derselben Zeile – ist das Feld leer, darf nicht das nächste Wort genommen werden
    m = re.search(rf"Getriebe[ \t]+(?!(?:{labels})\b)(\S+)", seite1)
    td["getriebe"] = m.group(1) if m else ""
    m = re.search(rf"Interne ID[ \t]+({ID_WERT})\b", seite1)
    td["interne_id"] = m.group(1) if m else ""
    return td


def baue_basiszeile(td: dict) -> str:
    """z. B. 'Fiat Ducato (140 PS / 103 kW), 3.500 kg zul. Gesamtgewicht, Automatikgetriebe'"""
    teile = []
    if td.get("basisfahrzeug"):
        s = td["basisfahrzeug"]
        if td.get("ps") and td.get("kw"):
            s += f" ({td['ps']} PS / {td['kw']} kW)"
        teile.append(s)
    if td.get("gesamtmasse"):
        teile.append(f"{td['gesamtmasse']} kg zul. Gesamtgewicht")
    g = td.get("getriebe", "").lower()
    if "automatik" in g:
        teile.append("Automatikgetriebe")
    elif "schalt" in g or "manuell" in g:
        teile.append("Schaltgetriebe")
    elif g:
        teile.append(td["getriebe"])
    return ", ".join(teile)


# ---------------- Sonderausstattung (ab Seite 2) ----------------

def ist_kopfzeilen_rauschen(zeile: str) -> bool:
    """Seitenkopf der Preisschilder: www.beispiel.example, :NIF/:DI/:NS und Codes wie 57609G."""
    z = zeile.strip()
    if not z or z.startswith("www."):
        return True
    if re.fullmatch(r":[A-Z]{2,4}", z):
        return True
    if re.fullmatch(r"\d+", z):
        return True
    return bool(re.fullmatch(r"[A-Z0-9]{5,25}", z) and re.search(r"\d", z))


UEBERSCHRIFT_RE = re.compile(r"Sonderausstattungen\s+[\d.]+\s?€")


def schneide_sonderausstattung(seiten) -> str:
    """Text zwischen der Überschrift 'Sonderausstattungen X €' und 'Weitere Sonderausstattung'.
    seiten: Text je Seite (oder ein Text am Stück).

    Die Überschrift steht auch in der Kurzübersicht auf Seite 1, deshalb zählt auf einer Seite der letzte
    Treffer, und Seite 1 nur, wenn keine spätere Seite die Überschrift hat. Der Satz 'Weitere Sonderausstattung
    rüsten wir …' steht unten auf jeder Seite: bei drei und mehr Seiten läuft die Liste auf der nächsten weiter
    (auf Seiten mit '+'-Zeilen, die Überschrift kann sich dort wiederholen).
    """
    if isinstance(seiten, str):
        seiten = [seiten]
    mit_ueberschrift = [i for i, s in enumerate(seiten) if UEBERSCHRIFT_RE.search(s)]
    if not mit_ueberschrift:
        raise ValueError("Kein Block 'Sonderausstattungen … €' gefunden – anderes Layout?")
    start = next((i for i in mit_ueberschrift if i > 0), 0)
    teile = []
    for seite in seiten[start:]:
        treffer = list(UEBERSCHRIFT_RE.finditer(seite))
        if treffer:
            seite = seite[treffer[-1].end():]
        elif not re.search(r"^\s*\+", seite, re.M):
            continue                                      # keine Fortsetzung der Liste
        ende = re.search(r"Weitere Sonderausstattung", seite)
        teile.append(seite[: ende.start()] if ende else seite)
    return "\n".join(teile)


def zerlege_positionen(block: str):
    """Jede '+ …'-Zeile beginnt eine neue Position, Folgezeilen sind ihr Inhalt."""
    positionen, aktuell = [], None
    for zeile in block.split("\n"):
        if ist_kopfzeilen_rauschen(zeile):
            continue
        zeile = zeile.strip()
        if zeile.startswith("+"):
            aktuell = {"kopf": zeile[1:].strip(), "inhalt": []}
            positionen.append(aktuell)
        elif aktuell is not None:
            aktuell["inhalt"].append(zeile)
    return positionen


def ist_gebuehr(kopf: str) -> bool:
    k = kopf.lower()
    return any(g in k for g in EINSTELLUNGEN["gebuehren"])


def ist_inhalt_paket(name: str) -> bool:
    return any(p.lower() in name.lower() for p in EINSTELLUNGEN["pakete_mit_inhalt"])


def laeuft_weiter(name: str, inhalt: list) -> bool:
    """Endet der Positionsname mitten im Satz, gehört die nächste Zeile noch zum Namen.

    Erkennbar an einem Füllwort ("und", "mit", "inkl.") oder an einem kleingeschriebenen
    Adjektiv wie "elektrischem", "digitalem" – deutsche Positionsnamen enden sonst auf ein
    Substantiv, eine Zahl oder eine Klammer.
    """
    woerter = name.split()
    if not woerter:
        return False
    letztes = woerter[-1].strip(",")
    if letztes.lower().strip(".") in HAENGENDE_WOERTER or letztes.lower() in HAENGENDE_WOERTER:
        return len(inhalt) == 1 or len(inhalt[0]) < 60
    return (letztes.isalpha() and letztes[0].islower() and len(letztes) >= 4
            and letztes.endswith(("em", "en", "er", "es")))


def schliesse_klammern(name: str) -> str:
    """Bricht ein Klammertext in die nächsten Zeilen um, z. B. '10" Radio mit Rückfahrkamera (10" Radio und
    Navigationssystem (DAB+) inkl.' – dann ist das die Beschreibung des Pakets: sie wird wie ein Paketinhalt
    weggelassen, übrig bleibt '10" Radio mit Rückfahrkamera'."""
    tiefe, schnitt = 0, None
    for i, c in enumerate(name):
        if c == "(":
            if tiefe == 0:
                schnitt = i
            tiefe += 1
        elif c == ")" and tiefe:
            tiefe -= 1
            if tiefe == 0:
                schnitt = None
    if tiefe and schnitt:
        return name[:schnitt].rstrip(" ,;-")
    return name


def werte_positionen_aus(positionen):
    """Wendet die Regeln an. Gibt (übernommene Namen, verworfene Blöcke) zurück."""
    namen, verworfen = [], []
    for p in positionen:
        kopf, inhalt = p["kopf"], p["inhalt"]
        if kopf in ("", "-") or ist_gebuehr(kopf):
            continue

        preis = PREIS_RE.search(kopf)
        if preis:
            name = kopf[: preis.start()].strip().rstrip(",").strip()
            if ist_inhalt_paket(name):
                inhalt_text = " ".join(inhalt).strip()
                name = f"{name}, {inhalt_text}" if inhalt_text else name
            elif inhalt and not PREIS_RE.search(inhalt[0]) and laeuft_weiter(name, inhalt):
                # Name läuft nach dem Preis in der nächsten Zeile weiter
                name = f"{name} {inhalt[0]}"
            namen.append(schliesse_klammern(re.sub(r"\s+", " ", name).strip()))
            continue

        # Preis auf eigener Zeile (sehr lange, umgebrochene Namen)
        preis_zeile = next((c for c in inhalt if PREIS_RE.fullmatch(c.strip())), None)
        if preis_zeile:
            rest = [c for c in inhalt if c is not preis_zeile]
            namen.append(re.sub(r"\s+", " ", " ".join([kopf] + rest)).strip())
        elif not inhalt:
            namen.append(kopf)            # Farbe, Wohnwelt, Dekor
        else:
            verworfen.append(kopf)        # Serienausstattung, Unterpaket, Aktionstext
    return namen, verworfen


def ist_fahrgestellzeile(n: str) -> bool:
    """Motor-/Fahrgestellbeschreibung wie 'Citroën Jumper 3.500 kg | 2.2 | 103 kW | 140 PS …'
    oder 'Fiat Ducato MultiJet 140 (2,2 l / 140 PS / 103 kW)'. Die steht schon in der Basiszeile."""
    return bool(re.search(r"\d\s*kW\b", n) and re.search(r"\d\s*PS\b", n))


def entferne_fahrgestell_dubletten(namen, td):
    """Motor/Getriebe stehen schon in der Basiszeile und sollen nicht doppelt auftauchen."""
    marke = td.get("basisfahrzeug", "").split()[0].lower() if td.get("basisfahrzeug") else ""
    getriebe_bekannt = bool(td.get("getriebe"))
    ergebnis = []
    for n in namen:
        if td.get("basisfahrzeug") and ist_fahrgestellzeile(n):
            continue
        if marke and n.lower().startswith(marke) and re.search(r"\bPS\b|\bkW\b|getriebe", n, re.I):
            continue
        if getriebe_bekannt and re.search(r"getriebe", n, re.I) and len(n.split()) <= 4:
            continue  # z. B. "Automatikgetriebe AT8", "8-Gang Automatikgetriebe"
        ergebnis.append(n)
    return ergebnis


# ---------------- Gesamtablauf ----------------

def werte_seiten_aus(seiten: list, datei: str = "") -> Ergebnis:
    """Kern ohne PDF-Zugriff: bekommt den Text jeder Seite."""
    erg = Ergebnis(datei=datei)
    seite1 = seiten[0] if seiten else ""
    td = lies_technische_daten(seite1)
    erg.hersteller, erg.modell = lies_hersteller_modell(seite1)
    erg.interne_id = td.get("interne_id", "")

    try:
        block = schneide_sonderausstattung(seiten)
    except ValueError as e:
        erg.fehler = str(e) if any(s.strip() for s in seiten) else (
            "Die PDF enthält keinen Text (eingescannt?) – bitte das Original-Preisschild als PDF nehmen.")
        return erg

    namen, verworfen = werte_positionen_aus(zerlege_positionen(block))
    namen = entferne_fahrgestell_dubletten(namen, td)

    basis = baue_basiszeile(td)
    erg.fliesstext = ", ".join([t for t in [basis] + namen if t])

    if not erg.interne_id:
        erg.hinweise.append("Keine Interne ID im Preisschild gefunden")
    if not (erg.hersteller and erg.modell):
        erg.hinweise.append("Hersteller/Modell nicht erkannt – bitte prüfen")
    if not basis:
        erg.hinweise.append("Basisfahrzeug/Motor nicht erkannt")
    # Keine Farbe ist kein Grund zum Prüfen: die meisten Fahrzeuge sind weiß (Serienfarbe, steht nicht auf dem Schild)
    erg.weggelassen = verworfen
    from .werbetext import baue, modell_kurz, optionen
    erg.werbe_optionen = optionen(seiten, td)
    erg.modell_kurz = modell_kurz(erg.modell)
    # ohne Modell kein fertiger Text – die Merkmale stehen trotzdem zur Auswahl, sobald das Modell eingetippt ist
    erg.werbetext = baue(erg.werbe_optionen, erg.modell_kurz)["text"] if erg.modell_kurz else ""
    return erg


def teile_nach_fahrzeugen(seiten: list) -> list:
    """Eine PDF kann mehrere Preisschilder enthalten (z. B. '2er.pdf'). Jedes Fahrzeug beginnt mit
    einer Vorderseite, auf der die Technischen Daten stehen; die folgenden Seiten gehören dazu."""
    gruppen = []
    for seite in seiten:
        ist_vorderseite = "Technische Daten" in seite
        if ist_vorderseite or not gruppen:
            gruppen.append([seite])
        else:
            gruppen[-1].append(seite)
    return gruppen


def lies_preisschilder(quelle, datei: str = "") -> list:
    """Liest alle Preisschilder einer PDF. quelle: Pfad oder Datei-Objekt (z. B. aus Drag & Drop)."""
    import os
    datei = datei or os.path.basename(str(quelle))
    try:
        from .sicher import pruefe_pdf
        pruefe_pdf(quelle)
        with pdfplumber.open(quelle) as pdf:
            from .sicher import seitentexte
            seiten = seitentexte(pdf)
    except Exception as e:  # beschädigte oder gesperrte PDF
        from .ab_lesen import lesefehler
        return [Ergebnis(datei=datei, fehler=lesefehler(e))]
    if not seiten:
        return [Ergebnis(datei=datei, fehler="Die PDF hat keine Seiten.")]
    gruppen = teile_nach_fahrzeugen(seiten)
    if len(gruppen) == 1:
        return [werte_seiten_aus(gruppen[0], datei)]
    return [werte_seiten_aus(g, f"{datei} ({i}/{len(gruppen)})") for i, g in enumerate(gruppen, start=1)]


def lies_preisschild(quelle, datei: str = "") -> Ergebnis:
    """Erstes Preisschild einer PDF (für Aufrufer, die nur eines erwarten)."""
    return lies_preisschilder(quelle, datei)[0]
