"""
Beirat & Coaching: Zugriff auf die mitgelieferten Inhalte (beirat_inhalte.py), Stichwortsuche mit Synonymen,
Gedanke des Tages und der Wegweiser für den Fragen-Assistenten.

Alles ist statisch und mitgeliefert – kein Online-Dienst, keine KI, nichts verlässt den Rechner. Lesen dürfen alle
(auch im Browser auf Handy und Tablet); es gibt nichts zu speichern. Texte gehen als reine Daten an die Oberfläche,
dort wird jeder Text maskiert (beirat.js).
"""

import datetime as dt
import functools
import re

from . import beirat_inhalte as inhalte
from . import hausregeln

ID_MUSTER = re.compile(r"[a-z0-9]{2,40}")
MODUL_ID = re.compile(r"[a-z0-9]{6,32}")
MAX_SUCHE = 200                          # Zeichen einer Suchanfrage
MIN_TREFFER = 3                          # Punkte, ab denen etwas als Treffer gilt …
ANTEIL_VOM_BESTEN = 0.35                 # … und mindestens dieser Anteil der Punkte des besten Treffers

# Wörter ohne Aussage für die Suche (nach dem Vereinfachen: ä → ae usw.)
_FUELL = set("""der die das den dem des ein eine einen einem einer und oder aber ich du er sie es wir ihr mir mich dir
dich uns euch was wie wo wer wann warum soll sollte sollen will wollen kann koennen muss muessen ist sind war hat habe
haben hatte nicht noch mal bei beim fuer von vom zu zum zur auf aus im in an am mit ohne nach dann denn doch so sehr
gerade jetzt immer heute schon bitte gibt geht macht mache machen tun tue sagt sagen sagte meint meine mein dein
sein seine ihre unser unsere kunde kunden kundin man gut gute guter einfach eigentlich ganz genau also wenn weil dass
ob oder als auch nur nun viel viele etwas alles""".split())

# Synonymgruppen (vereinfachte Schreibweise). Ein Wort der Anfrage, das zu einer Gruppe passt, zählt auch für ihre
# übrigen Wörter – schwächer als ein direkter Treffer.
SYNONYME = [
    {"teuer", "preis", "preise", "kosten", "kostet", "betrag", "geld", "billig", "billiger", "guenstig", "guenstiger"},
    {"rabatt", "nachlass", "prozente", "skonto", "handeln", "runterhandeln", "verhandeln", "verhandlung"},
    {"ueberlegen", "nachdenken", "bedenkzeit", "zoegern", "zoegert", "unentschlossen", "schlafen"},
    {"reklamation", "reklamiert", "beschwerde", "beschwert", "mangel", "maengel", "kaputt", "defekt", "aerger",
     "veraergert", "wuetend", "sauer", "undicht"},
    {"verzetteln", "verzettele", "verzettelt", "chaos", "stress", "ueberfordert", "durcheinander", "prioritaet",
     "prioritaeten", "organisieren", "selbstorganisation", "zettel", "vergesse", "vergessen"},
    {"mitarbeiter", "mitarbeiterin", "kollege", "kollegin", "kollegen", "team", "azubi", "monteur"},
    {"entscheiden", "entscheidung", "entscheide", "abwaegen", "zweifel", "dilemma", "unsicher"},
    {"finanzierung", "finanzieren", "finanziert", "kredit", "rate", "raten", "monatsrate", "darlehen", "leasing",
     "barkauf", "barzahlung"},
    {"ankauf", "ankaufen", "zukaufen", "gebraucht", "gebrauchtfahrzeug", "gebrauchtwagen", "gebrauchten"},
    {"inzahlungnahme", "eintausch", "inzahlung", "eintauschen"},
    {"zubehoer", "upselling", "mehrverkauf", "markise", "solar", "solaranlage", "fahrradtraeger", "zusatz"},
    {"nachfassen", "nachhaken", "rueckruf", "funkstille", "ghosting"},
    {"besprechung", "besprechungen", "meeting", "runde", "wochenrunde", "sitzung", "teamrunde"},
    {"motivation", "stimmung", "muede", "frust", "erschoepft", "ueberlastet"},
    {"probefahrt", "testfahrt", "vorfuehrung", "probe", "besichtigung", "besichtigen", "sitzprobe"},
    {"reservieren", "reservierung", "reserviert", "zuruecklegen", "zurueckstellen", "festhalten", "freihalten"},
    {"abschluss", "abschliessen", "unterschrift", "kaufvertrag", "auftrag", "zusage"},
    {"akquise", "neukunden", "anfragen", "flaute", "ruhig", "leer"},
    {"partner", "partnerin", "frau", "mann", "ehefrau", "ehemann"},
    {"lieferverzug", "verspaetung", "verschoben", "liefertermin", "lieferung"},
    {"langsteher", "standzeit", "standtage", "ladenhueter"},
    {"bank", "hersteller", "lieferant", "lieferanten", "linie", "konditionen", "bonus"},
    {"einarbeitung", "einarbeiten", "onboarding", "neuer", "neue"},
    {"fehler", "versehen", "verbockt", "vergessen", "falsch"},
]

# Fragen an den Assistenten, die nach Rat klingen (nicht nach Daten)
RAT_FRAGE = re.compile(
    r"was (w(ü|ue)rde|sagt|sagen|meint|r(ä|ae)t|denkt)\b|\bbeirat|coaching|verkaufstraining|vollprofi|"
    r"kunde (sagt|meint|will|m(ö|oe)chte|findet|sagte|hat|muss|meldet|z(ö|oe)gert)|einwand|einw(ä|ae)nde|zu teuer|"
    r"wie (reagiere|antworte|gehe|entscheide|(ü|ue)berzeuge|verhandle|f(ü|ue)hre|motiviere|organisiere|bleibe|"
    r"bekomme|biete|erkl(ä|ae)re|sage|spreche|frage)|soll ich|verzettel|\btipps?\b|\brat\b|ratschlag|"
    r"was (mache|tue|tu) ich|ich schaffe|mitarbeiter liefert|liefert nicht|(ü|ue)berlegen")


# ---------------------------------------------------------------- Hilfen

def _einfach(text) -> str:
    t = str(text or "").lower()
    for alt, neu in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(alt, neu)
    return " ".join(re.split(r"[^0-9a-z]+", t)).strip()


def _woerter(text) -> list:
    return [w for w in _einfach(text).split() if len(w) >= 3 and w not in _FUELL]


def _passt(a: str, b: str) -> bool:
    """Gleiches Wort, das kürzere ist Anfang des längeren („preis“ – „preise“) oder beide teilen fast den ganzen
    Wortstamm („entscheide“ – „entscheidung“, aber nicht „ueberlegen“ – „ueberfordert“)."""
    if a == b:
        return True
    kurz, lang = sorted((a, b), key=len)
    if len(kurz) < 5:
        return False
    if lang.startswith(kurz):
        return True
    gleich = 0
    for x, y in zip(kurz, lang):
        if x != y:
            break
        gleich += 1
    return gleich >= max(6, len(kurz) - 3)


def _synonyme(wort: str) -> set:
    mehr = set()
    for gruppe in SYNONYME:
        if any(_passt(wort, s) for s in gruppe):
            mehr |= gruppe
    return mehr - {wort}


# ---------------------------------------------------------------- Inhalte aufbereiten (einmal, sie ändern sich nie)

@functools.lru_cache(maxsize=1)
def _alles() -> dict:
    mitglieder = [{"id": m["id"], "name": m["name"], "kuerzel": m["kuerzel"], "bekannt": m["bekannt"],
                   "fuer": m["fuer"], "steckbrief": m["steckbrief"],
                   "kernideen": [{"titel": t, "text": x} for t, x in m["kernideen"]],
                   "leitsatz": m.get("leitsatz") or "", "muster": list(m["muster"])} for m in inhalte.MITGLIEDER]
    module = [{"id": m["id"], "thema": m["thema"], "titel": m["titel"], "mitglieder": list(m["mitglieder"]),
               "kernidee": m["kernidee"], "schritte": list(m["schritte"]), "beispiel": m["beispiel"],
               "fehler": list(m["fehler"]), "formulierungen": list(m.get("formulierungen") or []),
               "hausregeln": [hausregeln.kurz(h) for h in m.get("hausregeln") or [] if hausregeln.kurz(h)]}
              for m in inhalte.MODULE]
    situationen = [{"id": s["id"], "thema": s["thema"], "titel": s["titel"], "lage": s["lage"],
                    "stichworte": list(s["stichworte"]), "module": list(s["module"]),
                    "perspektiven": [{"mitglied": m, "kern": k, "schritte": list(st), "formulierungen": list(fo)}
                                     for m, k, st, fo in s["perspektiven"]]} for s in inhalte.SITUATIONEN]
    # Querverweise: wo taucht ein Mitglied auf, welche Situationen nutzen ein Modul
    for m in mitglieder:
        m["module"] = [x["id"] for x in module if m["id"] in x["mitglieder"]]
        m["situationen"] = [s["id"] for s in situationen if any(p["mitglied"] == m["id"] for p in s["perspektiven"])]
    for x in module:
        x["situationen"] = [s["id"] for s in situationen if x["id"] in s["module"]]
    return {"version": inhalte.VERSION, "stand": inhalte.STAND, "hinweis": inhalte.HINWEIS,
            "themen": [dict(t) for t in inhalte.THEMEN], "mitglieder": mitglieder, "module": module,
            "situationen": situationen, "alias": dict(inhalte.MODUL_ALIAS),
            "hausregeln": [{k: r[k] for k in ("id", "titel", "regel")} for r in hausregeln.alle()]}


def _je_id(art: str) -> dict:
    return {x["id"]: x for x in _alles()[art]}


def mitglied_name(mid: str) -> str:
    m = _je_id("mitglieder").get(mid)
    return m["name"] if m else ""


def modul_titel(mid: str) -> str:
    m = _je_id("module").get(inhalte.MODUL_ALIAS.get(mid, mid))
    return m["titel"] if m else ""


def module_kurz() -> list:
    """Für Verweise (z. B. Einarbeitungspläne): [{"id", "titel", "thema"}]."""
    return [{"id": m["id"], "titel": m["titel"], "thema": m["thema"]} for m in _alles()["module"]]


def modul_id(mid) -> str:
    """Aktuelle Kennung eines Moduls – auch für umbenannte (MODUL_ALIAS). Unbekannt: ""."""
    if not isinstance(mid, str) or not MODUL_ID.fullmatch(mid):
        return ""
    mid = inhalte.MODUL_ALIAS.get(mid, mid)
    return mid if mid in _je_id("module") else ""


def ist_modul(mid) -> bool:
    """Bekanntes Modul – auch unter seiner alten Kennung (dann über modul_id() die neue holen)."""
    return bool(modul_id(mid))


# ---------------------------------------------------------------- Prüfung (Tests und Selbsttest)

def pruefen() -> list:
    """Liste von Problemen in den Inhalten – leer, wenn alles stimmig ist."""
    p = []
    a = _alles()
    themen = {t["id"] for t in a["themen"]}
    mitglieder = {m["id"] for m in a["mitglieder"]}
    module = {m["id"] for m in a["module"]}
    for art, ids in (("mitglieder", [m["id"] for m in a["mitglieder"]]), ("module", [m["id"] for m in a["module"]]),
                     ("situationen", [s["id"] for s in a["situationen"]]), ("themen", [t["id"] for t in a["themen"]])):
        if len(set(ids)) != len(ids):
            p.append(f"{art}: doppelte Kennung")
        p += [f"{art}: ungültige Kennung {i!r}" for i in ids if not ID_MUSTER.fullmatch(i)]
    p += [f"Modul {m}: Kennung nicht 6–32 Zeichen a–z/0–9" for m in module if not MODUL_ID.fullmatch(m)]
    for alt, neu in inhalte.MODUL_ALIAS.items():
        if alt in module or neu not in module or not MODUL_ID.fullmatch(alt):
            p.append(f"Alias {alt} → {neu}: alte Kennung noch vergeben oder Ziel unbekannt")
    for m in inhalte.MODULE:
        p += [f"Modul {m['id']}: unbekannte Hausregel {h}" for h in m.get("hausregeln") or [] if not hausregeln.kurz(h)]
    for m in a["module"]:
        if m["thema"] not in themen:
            p.append(f"Modul {m['id']}: unbekanntes Thema {m['thema']}")
        if not 3 <= len(m["schritte"]) <= 5:
            p.append(f"Modul {m['id']}: {len(m['schritte'])} Schritte (3–5 erwartet)")
        if not m["fehler"] or not m["beispiel"] or not m["kernidee"]:
            p.append(f"Modul {m['id']}: Kernidee, Beispiel oder typische Fehler fehlen")
        p += [f"Modul {m['id']}: unbekanntes Mitglied {x}" for x in m["mitglieder"] if x not in mitglieder]
    for s in a["situationen"]:
        if s["thema"] not in themen:
            p.append(f"Situation {s['id']}: unbekanntes Thema {s['thema']}")
        if not 2 <= len(s["perspektiven"]) <= 3:
            p.append(f"Situation {s['id']}: {len(s['perspektiven'])} Perspektiven (2–3 erwartet)")
        if len({x["mitglied"] for x in s["perspektiven"]}) != len(s["perspektiven"]):
            p.append(f"Situation {s['id']}: ein Mitglied doppelt")
        p += [f"Situation {s['id']}: unbekanntes Mitglied {x['mitglied']}" for x in s["perspektiven"]
              if x["mitglied"] not in mitglieder]
        p += [f"Situation {s['id']}: Perspektive ohne Schritte" for x in s["perspektiven"] if not x["schritte"]]
        p += [f"Situation {s['id']}: unbekanntes Modul {x}" for x in s["module"] if x not in module]
        if not s["module"] or not s["stichworte"]:
            p.append(f"Situation {s['id']}: Module oder Stichworte fehlen")
    for m in a["mitglieder"]:
        if not m["kernideen"] or not m["muster"] or not m["steckbrief"]:
            p.append(f"Mitglied {m['id']}: Steckbrief, Kernideen oder Übertragung fehlen")
    for mid, text, modul in inhalte.GEDANKEN:
        if mid not in mitglieder or modul not in module or not text:
            p.append(f"Gedanke {text[:30]!r}: Mitglied oder Modul unbekannt")
    for fid, frage, antworten, erklaerung, modul in inhalte.FRAGEN:
        if modul not in module:
            p.append(f"Frage {fid}: unbekanntes Modul {modul}")
        if len(antworten) != 4 or len({_einfach(x) for x in antworten}) != 4 or not all(antworten):
            p.append(f"Frage {fid}: nicht vier verschiedene Antworten")
        if len(frage) > 300 or len(erklaerung) > 600 or any(len(x) > 160 for x in antworten) or len(erklaerung) < 20:
            p.append(f"Frage {fid}: Text zu lang oder Erklärung zu kurz")
    if len({f[0] for f in inhalte.FRAGEN}) != len(inhalte.FRAGEN):
        p.append("Fragen: doppelte Kennung")
    return p


# ---------------------------------------------------------------- Schnittstelle (für alle lesbar)

def start(datum=None) -> dict:
    """Alle Inhalte auf einmal (wenige hundert Kilobyte höchstens) und der Gedanke des Tages."""
    a = _alles()
    return {**a, "impuls": impuls(datum),
            "anzahl": {"mitglieder": len(a["mitglieder"]), "module": len(a["module"]),
                       "situationen": len(a["situationen"]), "fragen": len(inhalte.FRAGEN)}}


def _tag(datum) -> dt.date:
    if isinstance(datum, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", datum):
        try:
            return dt.date.fromisoformat(datum)
        except ValueError:
            pass
    return dt.date.today()


def impuls(datum=None) -> dict:
    """Gedanke des Tages – fest nach Datum (gleicher Tag, gleicher Gedanke auf jedem Rechner)."""
    tag = _tag(datum)
    mid, text, modul = inhalte.GEDANKEN[tag.toordinal() % len(inhalte.GEDANKEN)]
    m = _je_id("mitglieder")[mid]
    return {"datum": tag.isoformat(), "text": text, "mitglied": mid, "name": m["name"], "kuerzel": m["kuerzel"],
            "modul": modul, "modul_titel": modul_titel(modul)}


def _punkte(anfrage: str, woerter: list, extra: set, felder: list) -> int:
    """felder: [(Gewicht, Text)] – Phrasen-Treffer zählen mehr als einzelne Wörter."""
    punkte = 0
    gesehen = set()
    for gewicht, text in felder:
        t = _einfach(text)
        if not t:
            continue
        tw = t.split()
        if len(anfrage) >= 4 and (f" {anfrage} " in f" {t} " or (len(t) >= 6 and f" {t} " in f" {anfrage} ")):
            punkte += 3 * gewicht
        for w in woerter:
            if w not in gesehen and any(_passt(w, x) for x in tw):
                punkte += gewicht
                gesehen.add(w)
        for w in extra:
            if ("syn", w) not in gesehen and any(_passt(w, x) for x in tw):
                punkte += 1
                gesehen.add(("syn", w))
    return punkte


def suche(text, grenze: int = 8) -> dict:
    """Situationen, Module und Mitglieder zu einer Frage in normaler Sprache – einfache Stichwortsuche mit Synonymen,
    keine KI. {"text", "situationen": [{"id", "punkte"}], "module": [...], "mitglieder": [...]}"""
    roh = str(text or "")[:MAX_SUCHE]
    anfrage = _einfach(roh)
    woerter = list(dict.fromkeys(_woerter(roh)))
    leer = {"text": roh, "situationen": [], "module": [], "mitglieder": []}
    if not woerter and len(anfrage) < 3:
        return leer
    extra = set()
    for w in woerter:
        extra |= _synonyme(w)
    extra -= set(woerter)
    a = _alles()
    themen = {t["id"]: t["titel"] for t in a["themen"]}
    namen = {m["id"]: m["name"] for m in a["mitglieder"]}

    def rangliste(eintraege, felder):
        liste = []
        for e in eintraege:
            n = _punkte(anfrage, woerter, extra, felder(e))
            if n >= MIN_TREFFER:
                liste.append({"id": e["id"], "punkte": n})
        liste.sort(key=lambda x: -x["punkte"])
        if liste:                                  # weit abgeschlagene Zufallstreffer weglassen
            schwelle = liste[0]["punkte"] * ANTEIL_VOM_BESTEN
            liste = [x for x in liste if x["punkte"] >= schwelle]
        return liste[:max(1, int(grenze))]

    situationen = rangliste(a["situationen"], lambda s: [
        (4, s["titel"]), *((3, x) for x in s["stichworte"]), (1, s["lage"]),
        *((1, namen.get(p["mitglied"], "")) for p in s["perspektiven"])])
    module = rangliste(a["module"], lambda m: [(4, m["titel"]), (2, themen.get(m["thema"], "")), (1, m["kernidee"])])
    mitglieder = rangliste(a["mitglieder"], lambda m: [(5, m["name"]), (2, m["fuer"]), (1, m["bekannt"])])
    return {"text": roh, "situationen": situationen, "module": module, "mitglieder": mitglieder}


# ---------------------------------------------------------------- Wegweiser für den Fragen-Assistenten

WO = "Team & Projekte → Beirat & Coaching"


def _genannt(frage: str) -> list:
    """Mitglieder, die in der Frage namentlich vorkommen (Nachname reicht)."""
    f = _einfach(frage)
    treffer = []
    for m in _alles()["mitglieder"]:
        nachname = _einfach(m["name"].split()[-1])
        if re.search(rf"\b{re.escape(nachname)}\b", f):
            treffer.append(m["id"])
    return treffer


def assistent_antwort(frage: str):
    """Antwort im Format des Assistenten ({"text", "daten", "werkzeug": "beirat", "modus", "ziel"}) oder None.
    Greift bei Rat-Fragen („Kunde sagt zu teuer“, „Wie entscheide ich mich …“, „Was würde Buffett sagen …“),
    nicht bei Datenfragen."""
    f = str(frage or "")[:MAX_SUCHE]
    genannt = _genannt(f)
    rat = bool(RAT_FRAGE.search(f.lower()))
    if not genannt and not rat:
        return None
    erg = suche(f, 3)
    sit = _je_id("situationen")
    beste = erg["situationen"][0] if erg["situationen"] else None
    if beste and beste["punkte"] >= 6:
        s = sit[beste["id"]]
        perspektiven = sorted(s["perspektiven"], key=lambda p: p["mitglied"] not in genannt)
        zeilen = [f"• {mitglied_name(p['mitglied'])}: {p['kern']}" for p in perspektiven]
        text = (f"Dazu hat der Beirat Rat – Situation „{s['titel']}“:\n" + "\n".join(zeilen) +
                f"\nErster Schritt: {perspektiven[0]['schritte'][0]}\n"
                f"Schritte und Formulierungen findest du unter {WO}.")
        return {"text": text, "daten": None, "werkzeug": "beirat", "modus": "regel",
                "ziel": f"#/beirat/situation/{s['id']}"}
    if genannt:
        m = _je_id("mitglieder")[genannt[0]]
        ideen = "; ".join(k["titel"] for k in m["kernideen"][:3])
        text = (f"{m['name']} ({m['bekannt']}) steht im Beirat für {m['fuer']}. Kernideen: {ideen}. "
                f"Wie wir das auf Muster übertragen: {m['muster'][0]} Mehr unter {WO}.")
        return {"text": text, "daten": None, "werkzeug": "beirat", "modus": "regel",
                "ziel": f"#/beirat/mitglied/{m['id']}"}
    if erg["module"] and erg["module"][0]["punkte"] >= 6:
        m = _je_id("module")[erg["module"][0]["id"]]
        text = (f"Dazu gibt es im Beirat das Modul „{m['titel']}“: {m['kernidee']} "
                f"Schritte, Praxisbeispiel und Formulierungen unter {WO}.")
        return {"text": text, "daten": None, "werkzeug": "beirat", "modus": "regel",
                "ziel": f"#/beirat/modul/{m['id']}"}
    if re.search(r"beirat|coaching|verkaufstraining|vollprofi", f.lower()):
        return {"text": f"Beirat & Coaching findest du links in der Seitenleiste unter {WO}: Situationen mit Rat aus "
                        "mehreren Perspektiven, Coaching-Module zu Verkauf, Verhandeln, Entscheiden, Struktur, "
                        "Service und Führung.", "daten": None, "werkzeug": "beirat", "modus": "regel",
                "ziel": "#/beirat"}
    return None
