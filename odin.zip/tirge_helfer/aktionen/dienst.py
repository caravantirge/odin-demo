"""
Der Aktionsdienst: Satz → (Rückfrage) → Vorschau → Ausführen → Rückgängig. Alles, was app.py über
aktionen_aufruf anbietet, läuft hier durch – mit Rechten, Gehirn, Sicherung, Protokoll und sofortigem Neu-Einlesen.
"""

import datetime as dt
import os
import secrets
import threading
import time

from . import excel as xl
from . import gehirn, sprache
from .auslieferung import AKTIONEN as AUSLIEFERUNG
from .basis import AktionsFehler, Kontext, Plan, Rueckfrage
from .deuter import KiDeuter, RegelDeuter
from .protokoll import Protokoll, neue_id
from .teile import AKTIONEN as TEILE
from .weitere import AKTIONEN as WEITERE

KATALOG = AUSLIEFERUNG + TEILE + WEITERE
ENTWURF_SEKUNDEN = 30 * 60
STANDARD_EINSTELLUNGEN = {"uebergabe_minuten": 90, "excel_online": False, "deuter": "regel"}
SCHREIBWEG_TEXT = {"graph": "Excel Online (Microsoft 365)", "excel": "Excel auf diesem Rechner",
                   "openpyxl": "Datei direkt (ohne Excel)", "odin": "nur in ODIN"}


def aktion_nach_kennung(kennung: str):
    return next((a for a in KATALOG if a.kennung == kennung), None)


class Aktionsdienst:
    def __init__(self, cockpit, projekte=None, urlaub=None, messe=None, tickets=None, anmeldung=None,
                 einstellungen=None, speichere=None, protokoll=None, com_lader=None, einstellungsordner=""):
        self.cockpit = cockpit
        self._projekte = projekte
        self._urlaub = urlaub
        self._messe = messe
        self._tickets = tickets
        self._anmeldung = anmeldung                     # Funktion -> microsoft.Anmeldung (oder None)
        self._einstellungen = einstellungen if einstellungen is not None else {}
        self._speichere = speichere or (lambda k, v: None)
        self._log = protokoll or (lambda text: None)
        self._einstellungsordner = einstellungsordner
        self._entwuerfe = {}
        self._offen = {}
        self._sperre = threading.RLock()
        self.deuter = RegelDeuter()
        self.ki = KiDeuter()
        self.protokoll = Protokoll(self._protokoll_ordner)
        self._graph_dateien = {}
        self.schreiber = [
            xl.GraphSchreiber(self._graph, self._graph_token, self._graph_datei,
                              eingeschaltet=lambda: bool(self.einstellungen().get("excel_online"))),
            xl.ComSchreiber(lade=com_lader),
            xl.OpenpyxlSchreiber(),
        ]

    # ------------------------------------------------------------------------------- Einstellungen ---
    def einstellungen(self) -> dict:
        roh = self._einstellungen.get("aktionen") if hasattr(self._einstellungen, "get") else None
        return {**STANDARD_EINSTELLUNGEN, **(roh if isinstance(roh, dict) else {})}

    def einstellungen_speichern(self, werte) -> dict:
        if not isinstance(werte, dict):
            raise AktionsFehler("Ungültige Einstellungen.")
        e = self.einstellungen()
        if "uebergabe_minuten" in werte:
            try:
                n = int(werte["uebergabe_minuten"])
            except (TypeError, ValueError):
                raise AktionsFehler("Übergabedauer bitte als Zahl (Minuten).") from None
            if not 15 <= n <= 480:
                raise AktionsFehler("Übergabedauer: 15 bis 480 Minuten.")
            e["uebergabe_minuten"] = n
        if "excel_online" in werte:
            e["excel_online"] = bool(werte["excel_online"])
        if werte.get("deuter") == "ki":
            raise AktionsFehler("Die Deutung mit einem Sprachmodell (Variante B) kommt später – sie ist noch nicht "
                                "eingebaut.")
        e["deuter"] = "regel"
        self._speichere("aktionen", e)
        return {"ok": True, "einstellungen": self.einstellungen(), "wege": self.schreibwege()}

    def schreibwege(self) -> list:
        aus = []
        for s in self.schreiber:
            try:
                ok, grund = s.verfuegbar()
            except Exception as e:                       # noqa: BLE001
                ok, grund = False, str(e)
            aus.append({"name": s.name, "titel": s.titel, "verfuegbar": ok, "grund": grund})
        return aus

    # ---------------------------------------------------------------------------------- Ordner ---
    def _basis(self) -> str:
        ordner = self._einstellungen.get("fahrzeuge_ordner") if hasattr(self._einstellungen, "get") else ""
        if ordner and os.path.isdir(ordner):
            return ordner
        return self._einstellungsordner or os.path.expanduser("~")

    def _protokoll_ordner(self) -> str:
        return os.path.join(self._basis(), "_ODIN", "Aenderungen")

    # ----------------------------------------------------------------------------------- Graph ---
    def _anm(self):
        a = self._anmeldung() if callable(self._anmeldung) else self._anmeldung
        if a is None:
            raise AktionsFehler("Microsoft-Anmeldung ist nicht eingerichtet.")
        return a

    def _graph(self, methode, pfad, token, daten=None, kopf_extra=None):
        return self._anm().graph(methode, pfad, token, daten=daten, kopf_extra=kopf_extra)

    def _graph_token(self):
        return self._anm().token()

    def _graph_datei(self, pfad: str):
        schluessel = os.path.normcase(os.path.abspath(pfad))
        if schluessel not in self._graph_dateien:
            self._graph_dateien[schluessel] = xl.graph_datei_finden(self._graph, self._graph_token, pfad)
        return self._graph_dateien[schluessel]

    # --------------------------------------------------------------------------- Hilfen für Aktionen ---
    def urlaub(self):
        return self._urlaub()

    def messe(self):
        return self._messe()

    def tickets(self):
        return self._tickets()

    def personen(self) -> list:
        try:
            return [{"id": p.get("id"), "name": p.get("name")} for p in (self._projekte.personen() or [])]
        except Exception:                                # noqa: BLE001
            return []

    def cashback_ordner(self) -> str:
        return self.cockpit.cashback_ordner()

    def cashback_lesen(self, ordner):
        return self.cockpit._cashback_lesen(ordner)

    def vermerk_anlegen(self, vermerk: dict) -> int:
        def neu(d):
            liste = d.setdefault("vermerke", [])
            vid = max([int(x.get("id") or 0) for x in liste] + [0]) + 1
            liste.append({**vermerk, "id": vid, "am": dt.datetime.now().isoformat(timespec="seconds")})
            return vid
        return self.cockpit._aendere(neu)

    def vermerk_entfernen(self, vid):
        def weg(d):
            d["vermerke"] = [x for x in d.get("vermerke", []) if x.get("id") != vid]
        self.cockpit._aendere(weg)

    def abloesung_erledigen(self, fid: str, datum: str) -> dict:
        def erledige(d):
            a = next((x for x in d["abloesungen"] if x.get("vehicle_internal_id") == fid and not x.get("erledigt")), None)
            if a:
                a["erledigt"], a["erledigt_am"] = 1, datum
                return {"fid": fid, "id": a.get("id"), "neu": False}
            nid = max([int(x.get("id") or 0) for x in d["abloesungen"]] + [0]) + 1
            d["abloesungen"].append({"id": nid, "vehicle_internal_id": fid, "bank": None, "geplant_am": datum,
                                     "betrag": None, "grund": "in ODIN als abgelöst vermerkt", "erledigt": 1,
                                     "erledigt_am": datum, "angelegt_am": datum})
            return {"fid": fid, "id": nid, "neu": True}
        return self.cockpit._aendere(erledige)

    def abloesung_zuruecksetzen(self, e: dict):
        def zurueck(d):
            if e.get("neu"):
                d["abloesungen"] = [x for x in d["abloesungen"] if x.get("id") != e.get("id")]
            else:
                for x in d["abloesungen"]:
                    if x.get("id") == e.get("id"):
                        x["erledigt"], x["erledigt_am"] = 0, None
        self.cockpit._aendere(zurueck)

    def frist_stand(self, fid) -> dict:
        def lies(d):
            f = next((x for x in d["fristen"] if x.get("id") == int(fid)), None)
            return {k: f.get(k) for k in ("faellig_am", "erledigt", "erledigt_am")} if f else None
        return self.cockpit._aendere(lies)

    def frist_zuruecksetzen(self, fid, vorher: dict):
        def zurueck(d):
            f = next((x for x in d["fristen"] if x.get("id") == int(fid)), None)
            if f:
                f.update(vorher)
                if f.get("historie"):
                    f["historie"] = f["historie"][:-1]
        self.cockpit._aendere(zurueck)

    # --------------------------------------------------------------------------------- Kontext ---
    def _kontext(self, db, stichtag, beispiel, finanzen, im_web, ich, ich_name, satz="") -> Kontext:
        heute = dt.date.fromisoformat(str(stichtag)[:10]) if stichtag else dt.date.today()
        jetzt = dt.datetime.now()
        if jetzt.date() != heute:
            jetzt = dt.datetime.combine(heute, jetzt.time())
        return Kontext(db=db, heute=heute, jetzt=jetzt, quellen=self.cockpit.quellen() if not beispiel else {},
                       finanzen=bool(finanzen), im_web=bool(im_web), ich=ich or "", ich_name=ich_name or "",
                       einstellungen=self.einstellungen(), dienst=self, beispiel=bool(beispiel), satz=satz)

    def _mit_db(self, arbeit):
        return self.cockpit.mit_daten(arbeit)

    def katalog(self, finanzen=False) -> dict:
        return {"aktionen": [a.katalog() for a in KATALOG if finanzen or a.recht != "finanzen"],
                "deuter": [{"name": self.deuter.name, "titel": self.deuter.titel, "aktiv": True},
                           {"name": self.ki.name, "titel": self.ki.titel, "aktiv": False}],
                "einstellungen": self.einstellungen(), "wege": self.schreibwege()}

    # -------------------------------------------------------------------------------- Verstehen ---
    def verstehen(self, text, kontext=None, finanzen=False, im_web=False, ich="", ich_name="") -> dict:
        """{"art": "keine"} (dann beantwortet der Fragen-Assistent), "rueckfrage", "vorschau" oder "fehler"."""
        text = " ".join(str(text or "").split())[:500]
        kontext = kontext if isinstance(kontext, dict) else {}
        with self._sperre:
            self._aufraeumen()

            def arbeit(db, stichtag, beispiel):
                k = self._kontext(db, stichtag, beispiel, finanzen, im_web, ich, ich_name, text)
                offen = self._offen.pop(str(kontext.get("rueckfrage") or ""), None)
                if offen:
                    k.satz = offen["satz"]
                    if offen["feld"] == "__aktion":
                        aktion = next((a for a in KATALOG if a.kennung == text or a.kennung == kontext.get("wert")), None)
                        if aktion is None:
                            return {"art": "fehler", "text": "Diese Aktion kenne ich nicht."}
                        return self._weiter(aktion, aktion.lies(offen["satz"], k), k)
                    aktion = aktion_nach_kennung(offen["aktion"])
                    p = offen["p"]
                    aktion.antwort(p, offen["feld"], str(kontext.get("wert") if kontext.get("wert") is not None else text), k)
                    return self._weiter(aktion, p, k)
                if kontext.get("aktion"):                       # Knopf in einer Tabelle: Aktion und Angaben stehen fest
                    aktion = aktion_nach_kennung(str(kontext["aktion"]))
                    if aktion is None:
                        return {"art": "fehler", "text": "Diese Aktion kenne ich nicht."}
                    p = {str(a)[:40]: b for a, b in (kontext.get("parameter") or {}).items()
                         if isinstance(b, (str, int, float, bool)) or b is None}
                    k.satz = text or aktion.titel
                    return self._weiter(aktion, p, k)
                d = self.deuter.deute(text, k, KATALOG)
                if d is None:
                    return {"art": "keine"}
                if d.rueckfrage is not None:
                    return self._frage(None, {}, d.rueckfrage, k)
                return self._weiter(d.aktion, d.parameter, k)
            try:
                return self._mit_db(arbeit)
            except AktionsFehler as e:
                return {"art": "fehler", "text": str(e)}
            except xl.SchreibFehler as e:
                return {"art": "fehler", "text": str(e)}

    def _frage(self, aktion, p, frage: Rueckfrage, k) -> dict:
        fid = secrets.token_hex(8)
        self._offen[fid] = {"aktion": aktion.kennung if aktion else None, "p": p, "feld": frage.feld, "satz": k.satz,
                            "zeit": time.time()}
        return {"art": "rueckfrage", "id": fid, "aktion": aktion.kennung if aktion else "",
                "titel": aktion.titel if aktion else "", **frage.als_dict()}

    def _weiter(self, aktion, p: dict, k) -> dict:
        if aktion.recht == "finanzen" and not k.finanzen:
            return {"art": "fehler", "text": f"„{aktion.titel}“ ist eine Finanzaktion – das dürfen nur Personen mit "
                                             "Finanzrecht (Assistent → „Finanzfragen beantwortet der Assistent für“), und "
                                             "nur am Rechner."}
        for _ in range(6):                                   # Schritte, bis alles klar ist (oder eine Rückfrage)
            frage = aktion.schritt(p, k)
            if frage is not None:
                return self._frage(aktion, p, frage, k)
            break
        plan = aktion.plane(p, k)
        hinweise = list(plan.hinweise) + list(aktion.pruefe(p, plan, k) or [])
        weg, andere = None, []
        if plan.zellen and not plan.nur_vorschau:
            weg, andere = xl.schreibweg_waehlen(self.schreiber, plan.datei, plan.zellen)
            if weg is None:
                plan.nur_vorschau = "Keiner der Schreibwege kann diese Änderung sicher schreiben: " + \
                    " · ".join(f"{t}: {g}" for t, g in andere if g)
            hinweise += gehirn.regel_datei(plan.datei, weg.name if weg else "")
        hinweise = _ohne_doppelte(hinweise)
        eid = secrets.token_hex(8)
        im_browser_nicht = k.im_web and not aktion.im_browser
        self._entwuerfe[eid] = {"aktion": aktion.kennung, "p": p, "plan": plan, "hinweise": hinweise,
                                "weg": weg.name if weg else ("odin" if not plan.zellen else ""), "satz": k.satz,
                                "zeit": time.time()}
        return {
            "art": "vorschau", "id": eid, "aktion": aktion.kennung, "titel": aktion.titel, "bereich": aktion.bereich,
            "zusammenfassung": plan.zusammenfassung, "liste": plan.liste,
            "datei": os.path.basename(plan.datei) if plan.datei else "",
            "zellen": [_zelle_anzeige(z) for z in plan.zellen], "odin": plan.odin,
            "hinweise": hinweise, "schwere": gehirn.schwerste(hinweise),
            "weg": weg.name if weg else ("odin" if not plan.zellen and not plan.nur_vorschau else ""),
            "weg_text": SCHREIBWEG_TEXT.get(weg.name if weg else ("odin" if not plan.zellen else ""), ""),
            "andere_wege": [{"titel": t, "grund": g} for t, g in andere],
            "ausfuehrbar": not plan.nur_vorschau and not im_browser_nicht,
            "grund": plan.nur_vorschau or ("Das geht nur am Rechner in ODIN – im Browser ist nicht sicher, wer am Gerät "
                                           "sitzt. Am Rechner im Assistenten bestätigen." if im_browser_nicht else ""),
            "trotzdem_noetig": gehirn.schwerste(hinweise) == "kritisch",
            "parameter": {a: b for a, b in p.items() if isinstance(b, (str, int, float, bool)) and not a.startswith("_")},
        }

    def _aufraeumen(self):
        grenze = time.time() - ENTWURF_SEKUNDEN
        for d in (self._entwuerfe, self._offen):
            for schluessel in [k for k, v in d.items() if v["zeit"] < grenze]:
                d.pop(schluessel, None)

    def abbrechen(self, eid) -> dict:
        with self._sperre:
            self._entwuerfe.pop(str(eid or ""), None)
            self._offen.pop(str(eid or ""), None)
        return {"ok": True}

    # -------------------------------------------------------------------------------- Ausführen ---
    def ausfuehren(self, eid, trotzdem=False, finanzen=False, im_web=False, ich="", ich_name="") -> dict:
        with self._sperre:
            e = self._entwuerfe.get(str(eid or ""))
            if not e:
                return {"ok": False, "fehler": "Diese Vorschau ist abgelaufen – bitte den Satz noch einmal eingeben."}
            aktion = aktion_nach_kennung(e["aktion"])
            plan: Plan = e["plan"]
            if aktion.recht == "finanzen" and not finanzen:
                return {"ok": False, "fehler": "Dafür fehlt das Finanzrecht."}
            if im_web and not aktion.im_browser:
                return {"ok": False, "fehler": "Das geht nur am Rechner in ODIN – im Browser ist nicht sicher, wer am "
                                               "Gerät sitzt."}
            if plan.nur_vorschau:
                return {"ok": False, "fehler": plan.nur_vorschau}
            if gehirn.schwerste(e["hinweise"]) == "kritisch" and not trotzdem:
                return {"ok": False, "fehler": "Es gibt einen kritischen Hinweis – bitte ausdrücklich „Trotzdem ausführen“."}

            def arbeit(db, stichtag, beispiel):
                k = self._kontext(db, stichtag, beispiel, finanzen, im_web, ich, ich_name, e["satz"])
                return self._ausfuehren(aktion, e, plan, k)
            try:
                ergebnis = self._mit_db(arbeit)
            except (AktionsFehler, xl.SchreibFehler) as fehler:
                return {"ok": False, "fehler": str(fehler), "geaendert": isinstance(fehler, xl.ListeGeaendert)}
            self._entwuerfe.pop(str(eid), None)
            return ergebnis

    def _excel_schreiben(self, datei: str, zellen: list, schluessel: list, bevorzugt: str = "") -> tuple:
        """Sicherung, Prüfung des Stands, Schreiben – mit dem ersten Weg, der kann. (Weg, Sicherung)"""
        sicherung = xl.sicherung_anlegen(datei, self._basis())
        gruende = []
        wege = sorted(self.schreiber, key=lambda s: 0 if s.name == bevorzugt else 1)
        for s in wege:
            try:
                ok, grund = s.eignung(datei, zellen)
            except Exception as e:                       # noqa: BLE001
                ok, grund = False, str(e)
            if not ok:
                gruende.append(f"{s.titel}: {grund}")
                continue
            stand = s.lese(datei, list(schluessel) + list(zellen))
            xl.pruefe_stand(zellen, stand, schluessel)
            s.schreibe(datei, zellen)
            return s.name, sicherung
        raise xl.SchreibFehler("Nicht geschrieben – " + " · ".join(gruende))

    def _ausfuehren(self, aktion, e, plan: Plan, k) -> dict:
        eintrag = {"id": neue_id(), "am": dt.datetime.now().isoformat(timespec="seconds"), "von": k.ich,
                   "von_name": k.ich_name, "aktion": aktion.kennung, "titel": aktion.titel, "bereich": aktion.bereich,
                   "satz": e["satz"], "zusammenfassung": plan.zusammenfassung, "hinweise": e["hinweise"],
                   "datei": plan.datei, "dateiname": os.path.basename(plan.datei) if plan.datei else "",
                   "liste": plan.liste, "zellen": [z.als_dict() for z in plan.zellen], "schluessel": [z.als_dict() for z in plan.schluessel],
                   "odin": plan.odin, "overlay": plan.overlay, "weg": "odin", "status": "ausgefuehrt",
                   "im_browser": k.im_web}
        if plan.zellen:
            weg, sicherung = self._excel_schreiben(plan.datei, plan.zellen, plan.schluessel, e.get("weg") or "")
            eintrag["weg"], eintrag["sicherung"] = weg, sicherung
            if weg == "graph" and plan.overlay:
                # Excel Online ist geändert – ODIN zeigt es sofort, bis OneDrive die Datei hierher synchronisiert hat
                self.cockpit.schwebend_dazu(plan.datei, plan.overlay)
        try:
            eintrag["odin_ergebnis"] = aktion.odin_ausfuehren(plan, k) or {}
        except Exception as fehler:                      # noqa: BLE001
            eintrag["status"] = "teilweise" if plan.zellen else "fehlgeschlagen"
            eintrag["fehler"] = str(fehler)[:300]
            self._protokoll_schreiben(eintrag)
            raise AktionsFehler(("Excel ist geändert, aber der ODIN-Teil hat nicht geklappt: " if plan.zellen else "")
                                + str(fehler)) from None
        self._protokoll_schreiben(eintrag)
        self.cockpit.neu_laden()
        weg_text = SCHREIBWEG_TEXT.get(eintrag["weg"], "")
        return {"ok": True, "eintrag": eintrag["id"], "weg": eintrag["weg"], "weg_text": weg_text,
                "text": f"Erledigt: {plan.zusammenfassung}." + (f" Geschrieben über: {weg_text}." if plan.zellen else ""),
                "rueckgaengig": aktion.kennung != "ticket"}

    def _protokoll_schreiben(self, eintrag):
        try:
            self.protokoll.schreibe(eintrag)
        except OSError as fehler:
            self._log(f"Aktionen: Protokoll nicht geschrieben: {fehler!r}")

    # ------------------------------------------------------------------------------- Rückgängig ---
    def rueckgaengig(self, eintrag_id, finanzen=False, im_web=False, ich="", ich_name="") -> dict:
        with self._sperre:
            e = self.protokoll.lies(str(eintrag_id or ""))
            if not e:
                return {"ok": False, "fehler": "Diesen Eintrag gibt es nicht (mehr)."}
            if e.get("status") != "ausgefuehrt":
                return {"ok": False, "fehler": "Das ist schon rückgängig gemacht oder nicht ausgeführt worden."}
            aktion = aktion_nach_kennung(e.get("aktion"))
            if aktion is None:
                return {"ok": False, "fehler": "Diese Aktion gibt es nicht mehr."}
            if aktion.recht == "finanzen" and not finanzen:
                return {"ok": False, "fehler": "Dafür fehlt das Finanzrecht."}
            if im_web:
                return {"ok": False, "fehler": "Rückgängig geht nur am Rechner in ODIN."}

            def arbeit(db, stichtag, beispiel):
                k = self._kontext(db, stichtag, beispiel, finanzen, im_web, ich, ich_name, e.get("satz") or "")
                neu = {"id": neue_id(), "am": dt.datetime.now().isoformat(timespec="seconds"), "von": k.ich,
                       "von_name": k.ich_name, "aktion": e["aktion"], "titel": "Rückgängig: " + (e.get("titel") or ""),
                       "bereich": e.get("bereich"), "satz": "", "zusammenfassung": "Rückgängig: " + (e.get("zusammenfassung") or ""),
                       "hinweise": [], "datei": e.get("datei"), "dateiname": e.get("dateiname"), "zellen": [],
                       "odin": [{"was": o.get("was"), "alt": o.get("neu"), "neu": o.get("alt")} for o in e.get("odin") or []
                                if o.get("alt")],
                       "liste": e.get("liste"),
                       "weg": "odin", "status": "rueckgaengig_von", "bezug": e["id"]}
                zellen = [xl.Zelle.aus_dict(z).umgekehrt() for z in e.get("zellen") or []]
                if zellen:
                    if not e.get("datei") or not os.path.isfile(e["datei"]):
                        raise AktionsFehler("Die Excel-Datei ist nicht erreichbar.")
                    schluessel = [xl.Zelle.aus_dict(z) for z in e.get("schluessel") or []]
                    weg, sicherung = self._excel_schreiben(e["datei"], zellen, schluessel, e.get("weg") or "")
                    neu.update(weg=weg, sicherung=sicherung, zellen=[z.als_dict() for z in zellen])
                    if weg == "graph" and e.get("overlay"):
                        self.cockpit.schwebend_weg(e["datei"])
                aktion.odin_rueckgaengig(e, k)
                return neu
            try:
                neu = self._mit_db(arbeit)
            except xl.ListeGeaendert as fehler:
                return {"ok": False, "fehler": str(fehler).replace("Bitte die Aktion neu ansehen.",
                                                                    "Inzwischen hat jemand die Zelle geändert – "
                                                                    "ODIN macht deshalb nichts rückgängig.")}
            except (AktionsFehler, xl.SchreibFehler) as fehler:
                return {"ok": False, "fehler": str(fehler)}
            self._protokoll_schreiben(neu)
            try:
                self.protokoll.aendere(e["id"], status="rueckgaengig", rueckgaengig_am=neu["am"], rueckgaengig_von=neu["von"],
                                       rueckgaengig_eintrag=neu["id"])
            except (KeyError, OSError):
                pass
            self.cockpit.neu_laden()
            return {"ok": True, "eintrag": neu["id"], "text": "Rückgängig gemacht: " + (e.get("zusammenfassung") or "")}

    # ------------------------------------------------------------------------------- Protokoll ---
    def liste(self, filter_=None, finanzen=False) -> dict:
        f = filter_ if isinstance(filter_, dict) else {}
        eintraege = []
        for e in self.protokoll.liste():
            aktion = aktion_nach_kennung(e.get("aktion"))
            if aktion and aktion.recht == "finanzen" and not finanzen:
                continue
            if f.get("bereich") and e.get("bereich") != f["bereich"]:
                continue
            if f.get("status") and e.get("status") != f["status"]:
                continue
            if f.get("suche"):
                heu = sprache.einfach(" ".join(str(e.get(x) or "") for x in ("zusammenfassung", "satz", "von_name", "dateiname")))
                if sprache.einfach(f["suche"]) not in heu:
                    continue
            eintraege.append({k: e.get(k) for k in ("id", "am", "von", "von_name", "aktion", "titel", "bereich", "satz",
                                                    "zusammenfassung", "hinweise", "dateiname", "liste", "weg", "status", "odin",
                                                    "rueckgaengig_am", "bezug", "fehler")}
                             | {"zellen": [_zelle_anzeige(xl.Zelle.aus_dict(z)) for z in e.get("zellen") or []],
                                "weg_text": SCHREIBWEG_TEXT.get(e.get("weg"), ""),
                                "rueckgaengig_moeglich": e.get("status") == "ausgefuehrt" and e.get("aktion") != "ticket"})
        bereiche = sorted({e.get("bereich") for e in eintraege if e.get("bereich")})
        return {"eintraege": eintraege[:300], "bereiche": bereiche, "ordner": self._protokoll_ordner()}


def _zelle_anzeige(z) -> dict:
    return {"blatt": z.blatt, "adresse": z.adresse, "label": z.label or z.feld, "alt": z.alt_text or "leer",
            "neu": z.neu_text or "leer", "formel": xl.ist_formel(z.alt_wert)}


def _ohne_doppelte(hinweise: list) -> list:
    gesehen, aus = set(), []
    for h in hinweise:
        schluessel = (h.get("regel"), h.get("titel"))
        if schluessel not in gesehen:
            gesehen.add(schluessel)
            aus.append(h)
    rang = {"kritisch": 0, "warnung": 1, "info": 2}
    return sorted(aus, key=lambda h: rang.get(h.get("schwere"), 3))
