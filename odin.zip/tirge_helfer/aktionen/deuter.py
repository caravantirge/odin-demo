"""
Wer versteht den Satz? Ein „Deuter“ macht aus einem Satz eine Aktion mit Parametern – mehr nicht. Was danach
passiert (Ziel finden, Gehirn, Vorschau, Bestätigung, Schreiben), ist für jeden Deuter dieselbe geprüfte Strecke.

Variante A (aktiv): RegelDeuter – Satzmuster und Synonyme je Aktion, alles im Haus, keine Daten nach außen.
Variante B (vorbereitet, aus): KiDeuter – später könnte ein Sprachmodell (z. B. über die Claude-API) Absicht und
Parameter liefern. An das Modell ginge dann nur: der eingegebene Satz, das heutige Datum und die Liste der Aktionen
mit ihren Parameternamen (Katalog) – keine Listen, keine Kundendaten aus ODIN. Zurück käme JSON
{"aktion": "<kennung>", "parameter": {...}}; ausgeführt würde ausschließlich über dieselben Aktionen, mit Prüfung
durch das Gehirn und erst nach Bestätigung. Es gibt hier bewusst keinen Netzaufruf.
"""

import json
import re
from dataclasses import dataclass, field

from .basis import AktionsFehler, Rueckfrage, option
from .finden import finde_fahrzeug_id

# Fragen sind keine Aufträge („Ist DETKW00142 bezahlt?“ – das beantwortet der Fragen-Assistent)
FRAGE_ANFANG = re.compile(r"^\s*(ist|sind|hat|haben|wurde|wurden|wann|wie|was|welche[rsmn]?|wo|wer|wieso|warum|gibt|"
                          r"steht|stehen|kann ich|darf ich|muss|müssen|zeig|liste)\b", re.IGNORECASE)
HOEFLICH = re.compile(r"^\s*(kannst du|könntest du|koenntest du|würdest du|wuerdest du|bitte|kümmer|kuemmer|"
                      r"mach|setz|trag|verschieb|erinner|leg)\b", re.IGNORECASE)
SCHWELLE = 5
FAHRZEUG_BEREICHE = ("Auslieferungen", "Bestand", "Finanzierung", "Cashback")


@dataclass
class Deutung:
    aktion: object = None
    parameter: dict = field(default_factory=dict)
    sicherheit: float = 0.0
    rueckfrage: Rueckfrage = None


class Deuter:
    name = ""
    titel = ""

    def deute(self, text: str, k, katalog: list):
        raise NotImplementedError


class RegelDeuter(Deuter):
    name = "regel"
    titel = "Regelwerk (im Haus)"

    def ist_frage(self, text: str) -> bool:
        t = text.strip()
        return bool(FRAGE_ANFANG.search(t)) and not HOEFLICH.search(t) and (t.endswith("?") or len(t.split()) <= 6
                                                                              or not re.search(r"\b(auf|um|an)\b", t))

    def deute(self, text: str, k, katalog: list):
        t = (text or "").strip()
        if not t or self.ist_frage(t):
            return None
        fid = finde_fahrzeug_id(k.db, t)
        teilecode = bool(re.search(r"\b[A-Za-z]{2}\d{5}\b", t)) and not fid
        wertung = []
        for a in katalog:
            p = a.punkte(t)
            if p and fid and a.bereich in FAHRZEUG_BEREICHE:
                p += 2
            if p and teilecode and a.bereich == "Teile & Montage":
                p += 2
            if p and a.braucht_fahrzeug and not fid:
                p -= 3
            if p >= SCHWELLE:
                wertung.append((p, a))
        if not wertung:
            return None
        wertung.sort(key=lambda x: -x[0])
        beste, aktion = wertung[0]
        gleich = [a for p, a in wertung if p >= beste - 1]
        if len(gleich) > 1:
            return Deutung(rueckfrage=Rueckfrage("Was soll ich tun?", "__aktion",
                                                 [option(a.kennung, a.titel, a.bereich) for a in gleich[:5]]),
                           parameter={"__kandidaten": [a.kennung for a in gleich[:5]]})
        return Deutung(aktion=aktion, parameter=aktion.lies(t, k), sicherheit=min(1.0, beste / 12))


class KiDeuter(Deuter):
    """Platzhalter für Variante B. Ist ausgeschaltet und ruft nichts auf."""
    name = "ki"
    titel = "Sprachmodell (Claude-API) – kommt später"
    eingeschaltet = False

    @staticmethod
    def anfrage(text: str, heute: str, katalog: list) -> dict:
        """Was an das Modell ginge – nur zur Anzeige und für Tests. Kein Netzaufruf."""
        return {"satz": str(text or "")[:500], "heute": heute,
                "aktionen": [{"kennung": a.kennung, "titel": a.titel, "parameter": [n for n, _ in a.parameter_info]}
                             for a in katalog],
                "antwortformat": {"aktion": "<kennung>", "parameter": {}}}

    @staticmethod
    def antwort_lesen(roh: str, katalog: list):
        """Antwort des Modells prüfen: nur bekannte Aktion, nur einfache Werte. Ergebnis wie RegelDeuter."""
        try:
            d = json.loads(roh)
        except (TypeError, ValueError):
            return None
        if not isinstance(d, dict):
            return None
        aktion = next((a for a in katalog if a.kennung == d.get("aktion")), None)
        if aktion is None:
            return None
        parameter = {str(k)[:40]: v for k, v in (d.get("parameter") or {}).items()
                     if isinstance(v, (str, int, float, bool)) and len(str(v)) <= 300}
        return Deutung(aktion=aktion, parameter=parameter, sicherheit=0.5)

    def deute(self, text: str, k, katalog: list):
        raise AktionsFehler("Die Deutung mit einem Sprachmodell (Variante B) ist noch nicht eingeschaltet.")
