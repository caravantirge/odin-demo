"""
Deutsch verstehen, ohne Sprachmodell: Datum und Uhrzeit („morgen“, „nächsten Freitag 15 Uhr“, „28.11.2026 15:00“),
Dauern („2 Stunden mehr“, „30 Minuten“, „5 AW“), Beträge („5.000 €“) und Namen (Umlaute, Groß/Klein, Tippfehler).

Alles hier ist rein: keine Datei, keine Datenbank – deshalb gut zu testen.
"""

import datetime as dt
import re
import unicodedata
from dataclasses import dataclass

WOCHENTAGE = {"montag": 0, "mo": 0, "dienstag": 1, "di": 1, "mittwoch": 2, "mi": 2, "donnerstag": 3, "do": 3,
              "freitag": 4, "fr": 4, "samstag": 5, "sa": 5, "sonnabend": 5, "sonntag": 6, "so": 6}
WOCHENTAG_KURZ = ("Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa.", "So.")
WOCHENTAG_LANG = ("Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag")
MONATE = {"januar": 1, "jan": 1, "februar": 2, "feb": 2, "märz": 3, "maerz": 3, "mär": 3, "mrz": 3, "april": 4,
          "apr": 4, "mai": 5, "juni": 6, "jun": 6, "juli": 7, "jul": 7, "august": 8, "aug": 8, "september": 9,
          "sept": 9, "sep": 9, "oktober": 10, "okt": 10, "november": 11, "nov": 11, "dezember": 12, "dez": 12}
ZAHLWOERTER = {"ein": 1, "eine": 1, "einen": 1, "einer": 1, "eins": 1, "zwei": 2, "drei": 3, "vier": 4, "fünf": 5,
               "fuenf": 5, "sechs": 6, "sieben": 7, "acht": 8, "neun": 9, "zehn": 10, "elf": 11, "zwölf": 12,
               "zwoelf": 12, "anderthalb": 1.5, "eineinhalb": 1.5, "zweieinhalb": 2.5, "halbe": 0.5, "halben": 0.5}


# ------------------------------------------------------------------------------------------------ Text ---

def einfach(text) -> str:
    """Zum Vergleichen: klein, Umlaute ausgeschrieben, ohne Akzente, Satzzeichen als Leerzeichen."""
    t = str(text or "").lower().replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = unicodedata.normalize("NFKD", t)
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def woerter(text) -> list:
    return einfach(text).split()


def abstand(a: str, b: str, grenze: int = 2) -> int:
    """Levenshtein-Abstand, abgebrochen über `grenze` (dann grenze + 1)."""
    if abs(len(a) - len(b)) > grenze:
        return grenze + 1
    vorher = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        jetzt = [i]
        for j, cb in enumerate(b, 1):
            jetzt.append(min(vorher[j] + 1, jetzt[j - 1] + 1, vorher[j - 1] + (ca != cb)))
        if min(jetzt) > grenze:
            return grenze + 1
        vorher = jetzt
    return vorher[-1]


def wort_passt(wort: str, kandidat: str) -> bool:
    """„mueller“ ~ „müller“ ~ „Muller“ (ein Tippfehler bei längeren Wörtern erlaubt)."""
    if not wort or not kandidat:
        return False
    if wort == kandidat:
        return True
    if len(wort) >= 5 and len(kandidat) >= 5:
        return abstand(wort, kandidat, 1) <= 1
    # „muller“ (ohne Umlaut-e) gegen „mueller“
    return wort.replace("ue", "u").replace("ae", "a").replace("oe", "o") == \
        kandidat.replace("ue", "u").replace("ae", "a").replace("oe", "o")


ANREDEN = {"fam", "familie", "herr", "herrn", "frau", "hr", "fr", "kunde", "kundin", "firma", "gmbh", "und", "u",
           "co", "kg", "dr", "von", "der", "die", "das"}


def namensteile(text) -> list:
    return [w for w in woerter(text) if len(w) >= 2 and w not in ANREDEN and not w.isdigit()]


def name_im_text(name, text) -> int:
    """Wie viele Teile eines Namens („Thomas Müller“, „Fam. Müller“) im Text vorkommen (tolerant)."""
    teile = namensteile(name)
    t = woerter(text)
    return sum(1 for n in teile if len(n) >= 3 and any(wort_passt(w, n) for w in t))


# -------------------------------------------------------------------------------------------- Zahlen ---

def zahl_aus(text):
    """„1.234,50“ → 1234.5, „2,5“ → 2.5, „1234.5“ → 1234.5, Zahlwörter („zwei“) → 2."""
    if text is None:
        return None
    t = str(text).strip().lower()
    if t in ZAHLWOERTER:
        return float(ZAHLWOERTER[t])
    t = t.replace("€", "").replace("eur", "").replace(" ", "")
    if re.fullmatch(r"-?\d{1,3}(\.\d{3})+(,\d+)?", t):
        t = t.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"-?\d+,\d+", t):
        t = t.replace(",", ".")
    try:
        return float(t)
    except ValueError:
        return None


_ZAHL = r"(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d+)?|" + "|".join(sorted(ZAHLWOERTER, key=len, reverse=True)) + ")"
BETRAG = re.compile(r"(?<![\d.,])(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:,\d{1,2})?)\s*(?:€|eur\b|euro\b)", re.IGNORECASE)
BETRAG_VORNE = re.compile(r"(?:€|eur|euro)\s*(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:,\d{1,2})?)", re.IGNORECASE)


def finde_betrag(text):
    m = BETRAG.search(text) or BETRAG_VORNE.search(text)
    return zahl_aus(m.group(1)) if m else None


@dataclass
class Dauer:
    minuten: float            # Betrag der Änderung oder der neue Wert, in Minuten
    richtung: str             # "+" (mehr), "-" (weniger) oder "=" (auf diesen Wert)
    einheit: str              # "Stunden", "Minuten" oder "AW"
    roh: str


_DAUER = re.compile(_ZAHL + r"\s*(stunden|stunde|std\.?|h\b|minuten|minute|min\.?|aw\b|arbeitswerte?)",
                    re.IGNORECASE)
_HALBE_STUNDE = re.compile(r"\b(eine|ne)?\s*halbe\s+stunde", re.IGNORECASE)


def finde_dauer(text):
    """„2 Stunden mehr“, „30 Minuten weniger“, „auf 3 Stunden“, „+5 AW“, „um eine halbe Stunde kürzen“ → Dauer."""
    t = str(text or "")
    m = _DAUER.search(t)
    if m:
        wert = zahl_aus(m.group(1))
        einheit_roh = m.group(2).lower()
        if wert is None:
            return None
        if einheit_roh.startswith(("st", "h")):
            minuten, einheit = wert * 60, "Stunden"
        elif einheit_roh.startswith("m"):
            minuten, einheit = wert, "Minuten"
        else:
            minuten, einheit = wert * 6, "AW"
        start, ende = m.span()
    else:
        h = _HALBE_STUNDE.search(t)
        if not h:
            return None
        minuten, einheit = 30, "Minuten"
        start, ende = h.span()
    vorne, hinten = t[max(0, start - 30):start].lower(), t[ende:ende + 40].lower()
    zeichen = t[max(0, start - 2):start]
    if "-" in zeichen or re.search(r"weniger|kürz|kuerz|abzieh|reduzier|verringer|runter|minus|senk", hinten + " " + vorne):
        richtung = "-"
    elif "+" in zeichen or re.search(r"mehr|länger|laenger|zusätzlich|zusaetzlich|dazu|plus|erhöh|erhoeh|rauf|aufschlag", hinten + " " + vorne):
        richtung = "+"
    elif re.search(r"\bauf\s*$", vorne) or re.search(r"\b(setz|stell|änder|aender)\w*\b[^.]*\bauf\s*$", vorne):
        richtung = "="
    elif re.search(r"\bum(\s+eine?)?\s*$", vorne):
        richtung = "+"
    else:
        richtung = "="
    return Dauer(minuten=float(minuten), richtung=richtung, einheit=einheit, roh=t[start:ende])


# --------------------------------------------------------------------------------------- Datum, Zeit ---

@dataclass
class Termin:
    datum: dt.date
    uhrzeit: str = None       # "HH:MM" oder None
    start: int = 0
    ende: int = 0
    roh: str = ""
    genau: bool = True        # False: Jahr geraten, relative Angabe o. Ä.

    def als_datetime(self) -> dt.datetime:
        h, m = (int(x) for x in (self.uhrzeit or "00:00").split(":"))
        return dt.datetime.combine(self.datum, dt.time(h, m))


def _jahr_raten(tag: int, monat: int, heute: dt.date):
    """Ohne Jahr: dieses Jahr, wenn der Tag höchstens 60 Tage zurückliegt – sonst das nächste."""
    for jahr in (heute.year, heute.year + 1):
        try:
            d = dt.date(jahr, monat, tag)
        except ValueError:
            continue
        if d >= heute - dt.timedelta(days=60) or jahr == heute.year + 1:
            return d
    return None


_DATUM_ZAHL = re.compile(r"(?<![\d.,])(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2}(?!\d))?|(?<![\d.,])(\d{1,2})\.(\d{1,2})(?![\d.,])")
_DATUM_ISO = re.compile(r"(?<!\d)(20\d{2})-(\d{2})-(\d{2})(?!\d)")
_DATUM_MONAT = re.compile(r"(?<!\d)(\d{1,2})\.?\s*(" + "|".join(sorted(MONATE, key=len, reverse=True)) +
                          r")\.?(?:\s+(20\d{2}))?(?![a-zäöü])", re.IGNORECASE)
_UHR = re.compile(r"(?<![\d.,])([01]?\d|2[0-3])[:.]([0-5]\d)(?:\s*uhr)?(?![\d,])|(?<![\d.,])([01]?\d|2[0-3])\s*(?:uhr|h\b)"
                  r"(?:\s*([0-5]\d)(?!\s*(?:min|minuten)))?|\bum\s+([01]?\d|2[0-3])(?![\d.:,]|\s*(?:tag|stund|minut|aw|uhr))",
                  re.IGNORECASE)
_RELATIV = re.compile(r"\b(heute|morgen|übermorgen|uebermorgen|gestern)\b", re.IGNORECASE)
_IN_TAGEN = re.compile(r"\bin\s+" + _ZAHL + r"\s+(tag|tagen|woche|wochen)\b", re.IGNORECASE)
_WOCHENTAG = re.compile(r"\b((?:nächste[nmr]?|naechste[nmr]?|kommende[nmr]?|diese[nmr]?|übernächste[nmr]?|"
                        r"uebernaechste[nmr]?)\s+)?(montag|dienstag|mittwoch|donnerstag|freitag|samstag|sonnabend|"
                        r"sonntag)(s)?(\s+(?:nächste|naechste|kommende)\s+woche)?\b", re.IGNORECASE)
_WOCHE = re.compile(r"\b(ende|anfang)\s+(?:der\s+)?(nächsten|naechsten|nächster|naechster|dieser|kommenden)\s+woche\b", re.IGNORECASE)


def _uhrzeiten(text: str) -> list:
    """[(start, ende, "HH:MM")] – „15 Uhr“, „15:30“, „15.30 Uhr“, „um 15“."""
    ergebnis = []
    for m in _UHR.finditer(text):
        if m.group(1) is not None:
            h, mi = int(m.group(1)), int(m.group(2))
            # „15.30“ ohne „Uhr“ könnte ein Datum sein (15. März) – nur mit Doppelpunkt oder „Uhr“ als Zeit lesen
            if "." in m.group(0) and "uhr" not in m.group(0).lower():
                continue
        elif m.group(3) is not None:
            h, mi = int(m.group(3)), int(m.group(4) or 0)
        else:
            h, mi = int(m.group(5)), 0
        ergebnis.append((m.start(), m.end(), f"{h:02d}:{mi:02d}"))
    return ergebnis


def finde_termine(text: str, heute: dt.date) -> list:
    """Alle Termine im Text, in der Reihenfolge des Vorkommens. Eine Uhrzeit gehört zum Datum direkt davor
    (oder, steht sie vorn, zum Datum danach: „um 15 Uhr am Freitag“)."""
    t = str(text or "")
    gefunden = []

    def dazu(start, ende, datum, genau=True):
        if datum and not any(s < ende and start < e for s, e, *_ in gefunden):
            gefunden.append((start, ende, datum, genau))

    for m in _DATUM_ISO.finditer(t):
        try:
            dazu(m.start(), m.end(), dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
        except ValueError:
            pass
    for m in _DATUM_ZAHL.finditer(t):
        if m.group(1):
            tag, monat, jahr = int(m.group(1)), int(m.group(2)), m.group(3)
        else:
            tag, monat, jahr = int(m.group(4)), int(m.group(5)), None
            vorne = t[max(0, m.start() - 12):m.start()].lower()
            # „28.11“ ohne Punkt nur mit Hinweis davor – sonst ist „2.5 Stunden“ kein 2. Mai
            if not re.search(r"\b(am|auf|zum|vom|bis|den|ab|von|nach|für|fuer)\s*$", vorne):
                continue
        if not (1 <= tag <= 31 and 1 <= monat <= 12):
            continue
        try:
            if jahr:
                j = int(jahr) + (2000 if len(jahr) == 2 else 0)
                dazu(m.start(), m.end(), dt.date(j, monat, tag))
            else:
                dazu(m.start(), m.end(), _jahr_raten(tag, monat, heute), genau=False)
        except ValueError:
            pass
    for m in _DATUM_MONAT.finditer(t):
        monat = MONATE.get(m.group(2).lower())
        try:
            d = dt.date(int(m.group(3)), monat, int(m.group(1))) if m.group(3) else _jahr_raten(int(m.group(1)), monat, heute)
            dazu(m.start(), m.end(), d, bool(m.group(3)))
        except (ValueError, TypeError):
            pass
    for m in _RELATIV.finditer(t):
        w = m.group(1).lower()
        tage = {"heute": 0, "morgen": 1, "übermorgen": 2, "uebermorgen": 2, "gestern": -1}[w]
        # „morgen früh“ ist morgen; „morgen“ als Teil von „übermorgen“ fängt \b schon ab
        dazu(m.start(), m.end(), heute + dt.timedelta(days=tage))
    for m in _IN_TAGEN.finditer(t):
        n = zahl_aus(m.group(1))
        if n is None:
            continue
        tage = int(n * (7 if m.group(2).lower().startswith("woche") else 1))
        dazu(m.start(), m.end(), heute + dt.timedelta(days=tage))
    for m in _WOCHE.finditer(t):
        montag = heute - dt.timedelta(days=heute.weekday())
        if m.group(2).lower() in ("nächsten", "naechsten", "nächster", "naechster", "kommenden"):
            montag += dt.timedelta(days=7)
        dazu(m.start(), m.end(), montag + dt.timedelta(days=4 if m.group(1).lower() == "ende" else 0))
    for m in _WOCHENTAG.finditer(t):
        ziel = WOCHENTAGE[m.group(2).lower()]
        zusatz = (m.group(1) or "").lower()
        naechste_woche = bool(m.group(4)) or zusatz.startswith(("nächste", "naechste", "übernächste", "uebernaechste"))
        if naechste_woche:
            montag = heute - dt.timedelta(days=heute.weekday()) + dt.timedelta(days=7)
            if zusatz.startswith(("übernächste", "uebernaechste")):
                montag += dt.timedelta(days=7)
            d = montag + dt.timedelta(days=ziel)
        else:
            tage = (ziel - heute.weekday()) % 7
            d = heute + dt.timedelta(days=tage or (0 if zusatz.startswith("diese") else 7))
        dazu(m.start(), m.end(), d)

    gefunden.sort(key=lambda x: x[0])
    termine = [Termin(datum=d, start=s, ende=e, roh=t[s:e], genau=g) for s, e, d, g in gefunden]
    # Uhrzeiten zuordnen: die nächste Uhrzeit nach einem Datum (vor dem nächsten Datum), sonst eine davor
    zeiten = [z for z in _uhrzeiten(t) if not any(tm.start <= z[0] < tm.ende for tm in termine)]
    frei = list(zeiten)
    for i, tm in enumerate(termine):
        grenze = termine[i + 1].start if i + 1 < len(termine) else len(t)
        nach = [z for z in frei if tm.ende <= z[0] < grenze and z[0] - tm.ende <= 25]
        if nach:
            tm.uhrzeit = nach[0][2]
            tm.ende = max(tm.ende, nach[0][1])
            tm.roh = t[tm.start:tm.ende]
            frei.remove(nach[0])
    for tm in termine:
        if tm.uhrzeit is None:
            vor = [z for z in frei if z[1] <= tm.start and tm.start - z[1] <= 12]
            if vor:
                tm.uhrzeit = vor[-1][2]
                frei.remove(vor[-1])
    return termine


def nur_uhrzeit(text: str):
    """Eine Uhrzeit ohne Datum („auf 15 Uhr“) – für „nur die Uhrzeit ändern“."""
    zeiten = _uhrzeiten(str(text or ""))
    return zeiten[-1][2] if zeiten else None


def datum_text(d, mit_jahr=True, mit_wochentag=False) -> str:
    if isinstance(d, str):
        d = dt.date.fromisoformat(d[:10])
    s = f"{d.day:02d}.{d.month:02d}." + (str(d.year) if mit_jahr else "")
    return (WOCHENTAG_KURZ[d.weekday()] + " " + s) if mit_wochentag else s


def termin_text(datum, uhrzeit=None, mit_wochentag=True) -> str:
    if not datum:
        return "–"
    return datum_text(datum, True, mit_wochentag) + (f", {uhrzeit} Uhr" if uhrzeit else "")


def eur_text(n, stellen=2) -> str:
    if n is None:
        return "–"
    s = f"{abs(n):,.{stellen}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("-" if n < 0 else "") + s + " €"


def minuten_text(m) -> str:
    if m is None:
        return "–"
    m = float(m)
    h, rest = divmod(abs(m), 60)
    vorz = "-" if m < 0 else ""
    if h and rest:
        return f"{vorz}{int(h)} Std. {int(round(rest))} Min."
    if h:
        return f"{vorz}{int(h)} Std."
    return f"{vorz}{int(round(rest))} Min."
