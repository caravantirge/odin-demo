"""
Änderungsprotokoll: je ausgeführter Aktion eine JSON-Datei unter _ODIN/Aenderungen/<JJJJ-MM>/<id>.json im Ordner
„Fahrzeuge“ (per OneDrive auf allen Rechnern gleich; ohne Ordner im Einstellungsordner dieses Rechners).

Eine Datei je Aktion – zwei Rechner überschreiben sich nie gegenseitig. Inhalt: wer, wann, welche Aktion, der Satz,
Datei/Blatt/Zelle mit alt und neu, die Hinweise des Gehirns, der Schreibweg, die Sicherungskopie und der Status
(ausgeführt / rückgängig gemacht / fehlgeschlagen). „Rückgängig“ schreibt einen eigenen Eintrag und markiert den alten.
"""

import datetime as dt
import json
import os
import re
import secrets

VERSION = 1
ID = re.compile(r"[0-9]{8}-[0-9]{6}-[0-9a-f]{6}")
HOECHSTENS = 400


def neue_id() -> str:
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)


class Protokoll:
    def __init__(self, ordner):
        self._ordner = ordner            # Funktion: liefert den Basisordner (…/_ODIN/Aenderungen)

    def ordner(self) -> str:
        return self._ordner()

    def _pfad(self, eid: str) -> str:
        if not ID.fullmatch(str(eid or "")):
            raise ValueError("ungültige Kennung")
        monat = f"{eid[:4]}-{eid[4:6]}"
        return os.path.join(self.ordner(), monat, eid + ".json")

    def schreibe(self, eintrag: dict) -> dict:
        eintrag = {"version": VERSION, **eintrag}
        pfad = self._pfad(eintrag["id"])
        os.makedirs(os.path.dirname(pfad), exist_ok=True)
        tmp = pfad + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(eintrag, f, ensure_ascii=False, indent=1, default=str)
        os.replace(tmp, pfad)
        return eintrag

    def lies(self, eid: str):
        try:
            with open(self._pfad(eid), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) and d.get("id") == eid else None
        except (OSError, ValueError):
            return None

    def aendere(self, eid: str, **felder) -> dict:
        e = self.lies(eid)
        if e is None:
            raise KeyError(eid)
        e.update(felder)
        return self.schreibe(e)

    def liste(self, anzahl: int = HOECHSTENS) -> list:
        basis = self.ordner()
        if not os.path.isdir(basis):
            return []
        dateien = []
        for monat in sorted(os.listdir(basis), reverse=True):
            unter = os.path.join(basis, monat)
            if not re.fullmatch(r"\d{4}-\d{2}", monat) or not os.path.isdir(unter):
                continue
            for name in sorted(os.listdir(unter), reverse=True):
                if name.endswith(".json") and ID.fullmatch(name[:-5]):
                    dateien.append(os.path.join(unter, name))
            if len(dateien) >= anzahl:
                break
        eintraege = []
        for pfad in dateien[:anzahl]:
            try:
                with open(pfad, encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict) and d.get("id"):
                    eintraege.append(d)
            except (OSError, ValueError):
                continue
        eintraege.sort(key=lambda e: str(e.get("am") or ""), reverse=True)
        return eintraege
