"""
Das „Gehirn“ hinter den Aktionen: Prüfregeln, die vor dem Ausführen mitdenken.

Jede Regel bekommt, was sie braucht (Datenbank des Cockpits, Stichtag, die betroffene Zeile, den neuen Wert) und
liefert Hinweise mit Schwere und Begründung:
- info      – gut zu wissen (z. B. „an dem Tag sind schon zwei Übergaben“)
- warnung   – bitte prüfen (Überschneidung, Urlaub, Teile noch nicht da)
- kritisch  – so eher nicht (Termin in der Vergangenheit, Zulassungsfrist überschritten). Ausführen geht trotzdem,
              aber nur mit ausdrücklichem „Trotzdem ausführen“.
Die Regeln lesen nur – sie ändern nichts.
"""

import datetime as dt
import re

from ..cockpit.demo import feiertage
from . import sprache

STANDARD_UEBERGABE_MINUTEN = 90
GROSSE_AENDERUNG = 0.30          # ab 30 % Preis- oder Zeitänderung fragt das Gehirn nach
OEFFNUNG = ("08:00", "18:00")


def hinweis(schwere: str, titel: str, text: str, regel: str) -> dict:
    return {"schwere": schwere, "titel": titel, "text": text, "regel": regel}


def _iso(d) -> str:
    return d.isoformat() if isinstance(d, (dt.date, dt.datetime)) else str(d or "")[:10]


def _tag(d) -> dt.date:
    return d if isinstance(d, dt.date) and not isinstance(d, dt.datetime) else dt.date.fromisoformat(_iso(d)[:10])


def _minuten(uhrzeit):
    if not uhrzeit:
        return None
    h, m = str(uhrzeit).split(":")[:2]
    return int(h) * 60 + int(m)


def feiertag_name(d: dt.date):
    from ..urlaub_antraege import feiertag_namen
    try:
        return feiertag_namen(d.year).get(d.isoformat())
    except Exception:                                   # noqa: BLE001 – ohne Namen reicht „Feiertag“
        return "Feiertag" if d in feiertage(d.year) else None


# ------------------------------------------------------------------------------- Allgemeine Regeln ---

def regel_vergangenheit(datum, uhrzeit, jetzt: dt.datetime) -> list:
    d = _tag(datum)
    if d < jetzt.date():
        return [hinweis("kritisch", "Termin liegt in der Vergangenheit",
                        f"Der {sprache.datum_text(d)} ist schon vorbei – vermutlich ein Tippfehler beim Datum.",
                        "vergangenheit")]
    if d == jetzt.date() and uhrzeit and _minuten(uhrzeit) < jetzt.hour * 60 + jetzt.minute:
        return [hinweis("warnung", "Uhrzeit ist heute schon vorbei",
                        f"Heute {uhrzeit} Uhr ist bereits vorbei.", "vergangenheit")]
    return []


def regel_ruhetag(datum) -> list:
    d = _tag(datum)
    name = feiertag_name(d)
    if name:
        return [hinweis("warnung", f"Feiertag ({name})",
                        f"Der {sprache.datum_text(d)} ist in Niedersachsen ein gesetzlicher Feiertag – der Betrieb ist zu.",
                        "feiertag")]
    if d.weekday() == 6:
        return [hinweis("warnung", "Sonntag", f"Der {sprache.datum_text(d)} ist ein Sonntag.", "sonntag")]
    if d.weekday() == 5:
        return [hinweis("info", "Samstag", "Samstags ist nur eingeschränkt besetzt – passt das?", "samstag")]
    return []


def regel_oeffnungszeit(uhrzeit) -> list:
    m = _minuten(uhrzeit)
    if m is None:
        return []
    if m < _minuten(OEFFNUNG[0]) or m > _minuten(OEFFNUNG[1]):
        return [hinweis("info", "Außerhalb der üblichen Zeiten",
                        f"{uhrzeit} Uhr liegt außerhalb von {OEFFNUNG[0]}–{OEFFNUNG[1]} Uhr.", "oeffnungszeit")]
    return []


def regel_grosse_aenderung(alt, neu, was: str) -> list:
    if alt in (None, 0) or neu is None:
        return []
    anteil = (neu - alt) / abs(alt)
    if abs(anteil) > GROSSE_AENDERUNG:
        prozent = f"{anteil * 100:+.0f} %"
        return [hinweis("warnung", f"Große Änderung ({prozent})",
                        f"{was} ändert sich um {abs(anteil) * 100:.0f} % – bitte prüfen, ob die Zahl stimmt.",
                        "grosse_aenderung")]
    return []


def regel_datei(pfad: str, weg: str) -> list:
    from .excel import gesperrt, sperrdatei
    if not pfad:
        return []
    grund = gesperrt(pfad)
    if not grund:
        return []
    if weg == "graph" and sperrdatei(pfad):
        return [hinweis("info", "Datei ist geöffnet",
                        grund.split(" – ")[0] + ". Excel Online schreibt trotzdem mit – die Änderung erscheint dort.",
                        "datei_offen")]
    return [hinweis("kritisch", "Datei gerade gesperrt", grund, "datei_gesperrt")]


# --------------------------------------------------------------------------------- Übergabetermine ---

def _verkaeufer_abwesend(db, verkaeufer, d: dt.date):
    if not verkaeufer:
        return None
    zeilen = db.execute("SELECT mitarbeiter, art FROM abwesenheiten WHERE datum = ?", (d.isoformat(),)).fetchall()
    for z in zeilen:
        teile = sprache.namensteile(z["mitarbeiter"])
        if teile and any(sprache.wort_passt(t, w) for t in teile for w in sprache.namensteile(verkaeufer)):
            return z
    return None


def pruefe_termin(db, jetzt: dt.datetime, uebergabe: dict, neu_datum, neu_uhrzeit, einstellungen=None) -> list:
    """Alle Regeln für eine verschobene Übergabe. 'uebergabe' ist die Zeile aus deliveries (dict)."""
    einstellungen = einstellungen or {}
    dauer = int(einstellungen.get("uebergabe_minuten") or STANDARD_UEBERGABE_MINUTEN)
    d = _tag(neu_datum)
    iso = d.isoformat()
    fid = uebergabe.get("vehicle_internal_id")
    aus = []
    aus += regel_vergangenheit(d, neu_uhrzeit, jetzt)
    aus += regel_ruhetag(d)
    aus += regel_oeffnungszeit(neu_uhrzeit)

    # Andere Übergaben am selben Tag: mit Uhrzeit eine echte Überschneidung, sonst nur zur Kenntnis
    andere = [dict(r) for r in db.execute(
        "SELECT id, vehicle_internal_id, customer, planned_date, uhrzeit, verkaeufer FROM deliveries "
        "WHERE date(planned_date) = date(?) AND actual_date IS NULL AND id IS NOT ?", (iso, uebergabe.get("id")))]
    neu_min = _minuten(neu_uhrzeit)
    knapp = []
    for o in andere:
        om = _minuten(o.get("uhrzeit"))
        if neu_min is not None and om is not None and abs(om - neu_min) < dauer:
            knapp.append(o)
    if knapp:
        namen = ", ".join(f"{o['customer'] or o['vehicle_internal_id']} um {o['uhrzeit']} Uhr" for o in knapp)
        aus.append(hinweis("warnung", "Überschneidung mit einer anderen Übergabe",
                           f"Am {sprache.datum_text(d)} ist schon {namen} – eine Übergabe dauert etwa {dauer} Minuten.",
                           "ueberschneidung"))
    elif andere:
        namen = ", ".join(f"{o['customer'] or o['vehicle_internal_id']}" + (f" ({o['uhrzeit']})" if o.get("uhrzeit") else "")
                          for o in andere[:4])
        schwere = "warnung" if len(andere) >= 3 else "info"
        aus.append(hinweis(schwere, f"{len(andere) + 1}. Übergabe an diesem Tag",
                           f"Am {sprache.datum_text(d)} stehen schon: {namen}.", "tagesauslastung"))

    # Verkäufer im genehmigten Urlaub (Urlaubsplaner oder ODIN-Urlaubsanträge)
    abw = _verkaeufer_abwesend(db, uebergabe.get("verkaeufer"), d)
    if abw:
        aus.append(hinweis("warnung", f"{uebergabe.get('verkaeufer')} ist nicht da",
                           f"{abw['mitarbeiter']} hat am {sprache.datum_text(d)} {abw['art'] or 'Urlaub'} – wer übergibt?",
                           "urlaub"))
    werkstatt_weg = db.execute("SELECT COUNT(*) FROM abwesenheiten a JOIN mitarbeiter m ON m.name = a.mitarbeiter "
                               "WHERE a.datum = ? AND m.bereich = 'Werkstatt'", (iso,)).fetchone()[0]
    werkstatt = db.execute("SELECT COUNT(*) FROM mitarbeiter WHERE bereich = 'Werkstatt' AND aktiv = 1").fetchone()[0]
    if werkstatt and werkstatt_weg and werkstatt_weg >= max(1, werkstatt // 2):
        aus.append(hinweis("info", "Werkstatt dünn besetzt",
                           f"Am {sprache.datum_text(d)} fehlen {werkstatt_weg} von {werkstatt} in der Werkstatt.", "werkstatt"))

    if fid:
        # Zulassungsfrist (Ausnahmegenehmigung): Übergabe danach geht nicht
        frist = db.execute("SELECT frist, ausnahme_art FROM zulassungsfristen WHERE vehicle_internal_id = ?",
                           (fid,)).fetchone()
        if frist and frist["frist"] and frist["frist"] < iso:
            aus.append(hinweis("kritisch", "Zulassungsfrist überschritten",
                               f"{fid} muss bis {sprache.datum_text(frist['frist'])} zugelassen sein"
                               + (f" ({frist['ausnahme_art']})" if frist["ausnahme_art"] else "") +
                               " – die Übergabe läge danach.", "zulassungsfrist"))
        # Zinsfreiheit endet vor der Übergabe
        fin = db.execute("SELECT bank, interest_free_until FROM financings WHERE vehicle_internal_id = ? AND "
                         "COALESCE(status,'offen') = 'offen' AND interest_free_until IS NOT NULL", (fid,)).fetchone()
        if fin and fin["interest_free_until"] < iso and (not uebergabe.get("planned_date")
                                                        or fin["interest_free_until"] >= _iso(uebergabe["planned_date"])):
            aus.append(hinweis("warnung", "Zinsfreiheit endet vorher",
                               f"Die Finanzierung ({fin['bank']}) ist nur bis {sprache.datum_text(fin['interest_free_until'])} "
                               "zinsfrei – durch die Verschiebung fallen Zinsen an.", "zinsfrei"))
        # Fahrzeug noch nicht da: Liefer-KW aus der Bestandsliste nach der Übergabe
        fz = db.execute("SELECT lieferstatus, lieferblock FROM vehicles WHERE internal_id = ?", (fid,)).fetchone()
        if fz and fz["lieferstatus"] in ("geplant", "im Werk"):
            kw = re.search(r"KW\s*(\d{1,2})", str(fz["lieferblock"] or ""))
            if kw:
                montag = _montag_der_kw(int(kw.group(1)), d)
                if montag and montag > d:
                    aus.append(hinweis("kritisch", "Fahrzeug kommt später",
                                       f"{fid} wird laut Bestandsliste erst in KW {int(kw.group(1))} erwartet "
                                       f"(ab {sprache.datum_text(montag)}).", "liefertermin"))
            else:
                aus.append(hinweis("warnung", "Fahrzeug noch nicht da",
                                   f"{fid} steht in der Bestandsliste als „{fz['lieferstatus']}“.", "liefertermin"))
        if uebergabe.get("verfuegbarkeit") == "im Werk offen":
            aus.append(hinweis("warnung", "Fahrzeug im Werk noch offen",
                               "In der Auslieferungsliste ist das Modell rot (im Werk offen).", "liefertermin"))
        # Teile und Einbauten
        auftrag = db.execute("SELECT teilestatus FROM werkstattauftraege WHERE vehicle_internal_id = ? AND "
                             "art = 'Auslieferung' ORDER BY id LIMIT 1", (fid,)).fetchone()
        bald = (d - jetzt.date()).days <= 7
        if auftrag and auftrag["teilestatus"] in ("nicht bestellt", "bestellt") and bald:
            aus.append(hinweis("warnung", "Teile noch nicht da",
                               f"Teilestatus: {auftrag['teilestatus']} – die Übergabe ist in "
                               f"{max(0, (d - jetzt.date()).days)} Tagen.", "teile"))
        offen = db.execute("SELECT position FROM einbauten WHERE vehicle_internal_id = ? AND status <> 'erledigt'",
                           (fid,)).fetchall()
        if offen and bald:
            aus.append(hinweis("warnung", "Einbauten offen", "Noch offen: " + ", ".join(o["position"] for o in offen) + ".",
                               "einbauten"))
        # Bank hat noch nicht ausgezahlt
        try:
            from ..cockpit.auswertungen import bank_zahlt_aus
            if uebergabe.get("id") in bank_zahlt_aus(db) and uebergabe.get("zahlstatus") != "bezahlt":
                aus.append(hinweis("info", "Bank zahlt noch aus",
                                   "Die Kundenfinanzierung ist laut Finanzaufstellung noch nicht ausgezahlt.", "bank"))
        except Exception:                               # noqa: BLE001 – Zusatzprüfung, darf nie aufhalten
            pass
    if (d - jetzt.date()).days <= 3 and d >= jetzt.date():
        offen = []
        if uebergabe.get("papiere_status") not in (None, "beim Kunden"):
            offen.append(f"Papiere ({uebergabe.get('papiere_status')})")
        if uebergabe.get("tuev_faellig"):
            offen.append("TÜV")
        if uebergabe.get("zahlstatus") not in ("bezahlt",):
            offen.append(f"Zahlung ({uebergabe.get('zahlstatus') or 'offen'})")
        if offen:
            aus.append(hinweis("info", "Kurzfristig – noch offen", ", ".join(offen) + ".", "offen_kurzfristig"))
    # Sonderfahrten, Lehrgänge, Hinweise am selben Tag
    for s in db.execute("SELECT text, art FROM sonderfahrten WHERE date(datum) = date(?) OR "
                        "(bis IS NOT NULL AND date(?) BETWEEN date(datum) AND date(bis))", (iso, iso)).fetchall()[:3]:
        aus.append(hinweis("info", "Am selben Tag: " + ("Lehrgang" if s["art"] == "lehrgang" else "Sonderfahrt"
                                                        if s["art"] == "sonderfahrt" else "Hinweis"),
                           str(s["text"])[:140], "sonderfahrt"))
    if uebergabe.get("planned_date"):
        verschoben = (d - _tag(uebergabe["planned_date"])).days
        if abs(verschoben) > 30:
            aus.append(hinweis("info", "Große Verschiebung",
                               f"Der Termin wandert um {abs(verschoben)} Tage {'nach hinten' if verschoben > 0 else 'nach vorn'}.",
                               "verschiebung"))
    return aus


def _montag_der_kw(kw: int, bezug: dt.date):
    for jahr in (bezug.year, bezug.year + 1, bezug.year - 1):
        try:
            montag = dt.date.fromisocalendar(jahr, kw, 1)
        except ValueError:
            continue
        if abs((montag - bezug).days) <= 200:
            return montag
    return None


def schwerste(hinweise: list) -> str:
    rang = {"info": 0, "warnung": 1, "kritisch": 2}
    return max((h["schwere"] for h in hinweise), key=lambda s: rang.get(s, 0), default="")
