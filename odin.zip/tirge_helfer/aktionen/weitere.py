"""Weitere Aktionen: Bestand (Fahrzeuge), Finanzierung, Cashback und ODIN-interne Aktionen (Aufgaben, Fristen,
Urlaub, Messe, Tickets)."""

import datetime as dt
import os
import re

from .. import hausregeln
from ..cockpit.excel import legende
from . import excel as xl
from . import gehirn, sprache
from .basis import (Aktion, AktionsFehler, ExcelZeile, Plan, Rueckfrage, farbe, finde_listenzeile, id_gleich,
                    ohne_datei_grund, option, quelle)
from .finden import fahrzeug_finden, fahrzeug_frage, finde_fahrzeug_id, person_finden

FRAGE = r"^\s*(ist|sind|hat|haben|wann|wie|was|welche|welcher|wo|wer)\b.*\?\s*$"


# ----------------------------------------------------------------------------------------- Bestand ---

class FahrzeugAktion(Aktion):
    bereich = "Bestand"
    art = "bestandsliste"

    def lies(self, text, k):
        return {"fid": finde_fahrzeug_id(k.db, text)}

    def antwort(self, p, feld, wert, k):
        if feld == "fid":
            fid = finde_fahrzeug_id(k.db, wert) or str(wert).strip().upper()
            p["fid"] = fid
            return
        super().antwort(p, feld, wert, k)

    def schritt(self, p, k):
        if not p.get("fid"):
            fid, kandidaten = fahrzeug_finden(k.db, k.satz)
            if fid:
                p["fid"] = fid
            elif len(kandidaten) == 1:
                p["fid"] = kandidaten[0]["internal_id"]
            else:
                return fahrzeug_frage(kandidaten)
        if not self.fahrzeug(p, k):
            raise AktionsFehler(f"{p['fid']} steht nicht in der Bestandsliste.")
        return None

    def fahrzeug(self, p, k):
        r = k.db.execute("SELECT * FROM vehicles WHERE internal_id = ?", (p.get("fid"),)).fetchone()
        return dict(r) if r else None

    def zeile(self, v, k):
        pfad = quelle(k, self.art)
        if not pfad:
            return None
        fid = v["internal_id"]
        return finde_listenzeile(pfad, self.art, lambda w: id_gleich(w.get("internal_id"), fid)
                                 or (not w.get("internal_id") and id_gleich(w.get("kommission_roh"), fid)),
                                 v.get("source_sheet"))

    def feld_plan(self, p, k, v, feld, label, neu, neu_text, alt_text, overlay, titel):
        plan = Plan(titel, liste="Bestandsliste")
        plan.odin = [{"was": f"{label} ({v['internal_id']})", "alt": alt_text, "neu": neu_text}]
        plan.overlay = overlay
        z = self.zeile(v, k)
        if z is None:
            plan.nur_vorschau = ohne_datei_grund(k, self.art)
            return plan
        if feld not in z.spalten:
            plan.nur_vorschau = f"Die Bestandsliste hat keine Spalte „{label}“ – das müsste erst in Excel angelegt werden."
            return plan
        plan.datei = z.datei
        plan.zellen = [z.ziel(feld, label, neu_wert=neu, neu_text=neu_text, alt_text=alt_text)]
        plan.schluessel = z.schluessel(["internal_id"])
        return plan


def _text_nach(text: str, woerter: str):
    m = re.search(r"[„\"“»](.+?)[“\"”«]", text)
    if m:
        return m.group(1).strip()
    m = re.search(rf"(?:{woerter})\s*(?:ist|jetzt|:|=)*\s*(?:in|auf|nach|zu|bei|im)?\s*(?:der|die|das|den)?\s*(.+?)\s*[.!]?$",
                  text, re.IGNORECASE)
    if m:
        rest = re.sub(r"\b(stellen|umstellen|setzen|ändern|aendern|bringen|verstellen|parken)\b.*$", "", m.group(1),
                      flags=re.IGNORECASE).strip(" ,.")
        rest = re.sub(r"^[A-Za-z]{2,6}\s?-?\d{3,6}\s*", "", rest).strip(" ,.:;")
        rest = re.sub(r"^(ist|jetzt|in|auf|nach|im|zu)\s+", "", rest, flags=re.IGNORECASE).strip()
        return rest or None
    return None


class StandortAendern(FahrzeugAktion):
    kennung = "standort"
    titel = "Standort ändern"
    beschreibung = "Neuer Standort/Stellplatz eines Fahrzeugs (Spalte „Standort“ der Bestandsliste)."
    beispiele = ("DETKW00142 steht jetzt in Halle 2", "Standort DRM00245: Platz 14")
    ausloeser = ((r"standort|stellplatz|steht jetzt|umgestellt|umparken|abgestellt", 6),)
    gegen = (FRAGE, r"\bwo steht\b")
    direkt_felder = ({"name": "standort", "typ": "text", "label": "Neuer Standort"},)

    def lies(self, text, k):
        p = super().lies(text, k)
        s = _text_nach(text, r"standort|stellplatz|steht jetzt|steht|umgestellt|abgestellt")
        if s:
            p["standort"] = s[:60]
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if not p.get("standort"):
            return Rueckfrage("Wo steht das Fahrzeug jetzt?", "standort", frei=True, platzhalter="z. B. Halle 2")
        return None

    def plane(self, p, k):
        v = self.fahrzeug(p, k)
        return self.feld_plan(p, k, v, "location", "Standort", p["standort"], p["standort"], v.get("location") or "–",
                              [{"tabelle": "vehicles", "setze": {"location": p["standort"]}, "wo": {"internal_id": v["internal_id"]}}],
                              f"Standort {v['internal_id']}: {v.get('location') or '–'} → {p['standort']}")


class FahrzeugPreisAendern(FahrzeugAktion):
    braucht_fahrzeug = True
    kennung = "fahrzeugpreis"
    titel = "Fahrzeugpreis ändern"
    recht = "finanzen"
    beschreibung = "VK max./Listenpreis (brutto) oder Internetpreis eines Fahrzeugs in der Bestandsliste."
    beispiele = ("Preis DETKW00191 auf 71.900 €", "Internetpreis DRM00312 auf 89.900 €")
    ausloeser = ((r"preis|vk max|vk liste|listenpreis|internetpreis|internet", 4), (r"\d\s*(€|eur|euro)", 3))
    gegen = (FRAGE, r"teil|montage|einbau|arbeitszeit")
    direkt_felder = ({"name": "betrag", "typ": "zahl", "label": "Neuer Preis (€ brutto)"},
                     {"name": "art", "typ": "wahl", "label": "Preis", "optionen": ["list_price_gross", "internet_price"],
                      "texte": ["VK max. / Liste", "Internet"]})

    def lies(self, text, k):
        p = super().lies(text, k)
        p["betrag"] = sprache.finde_betrag(text)
        p["art"] = "internet_price" if re.search(r"internet|syscara|mobile", text, re.IGNORECASE) else "list_price_gross"
        return p

    def schritt(self, p, k):
        if not p.get("fid") and not finde_fahrzeug_id(k.db, k.satz):
            # ohne Fahrzeugnummer ist es eher ein Teilepreis – den übernimmt „Teilepreis ändern“
            fid, kandidaten = fahrzeug_finden(k.db, k.satz)
            if not fid and not kandidaten:
                raise AktionsFehler("Welches Fahrzeug? Bitte mit interner Nummer, z. B. „Preis DETKW00191 auf 71.900 €“.")
        frage = super().schritt(p, k)
        if frage:
            return frage
        if not p.get("betrag"):
            return Rueckfrage("Welcher neue Preis (brutto)?", "betrag", frei=True, platzhalter="z. B. 71.900 €")
        return None

    def antwort(self, p, feld, wert, k):
        if feld == "betrag":
            p["betrag"] = sprache.finde_betrag(f"{wert} €") or sprache.zahl_aus(wert)
            return
        super().antwort(p, feld, wert, k)

    def plane(self, p, k):
        v = self.fahrzeug(p, k)
        feld = p.get("art") if p.get("art") in ("list_price_gross", "internet_price") else "list_price_gross"
        label = "VK max./Liste" if feld == "list_price_gross" else "Internetpreis"
        neu = float(sprache.zahl_aus(p["betrag"]) if isinstance(p["betrag"], str) else p["betrag"])
        plan = self.feld_plan(p, k, v, feld, label, neu, sprache.eur_text(neu, 0), sprache.eur_text(v.get(feld), 0),
                              [{"tabelle": "vehicles", "setze": {feld: neu}, "wo": {"internal_id": v["internal_id"]}}],
                              f"{label} {v['internal_id']}: {sprache.eur_text(v.get(feld), 0)} → {sprache.eur_text(neu, 0)}")
        plan.daten = {"alt": v.get(feld), "neu": neu, "feld": feld}
        return plan

    def pruefe(self, p, plan, k):
        v = self.fahrzeug(p, k)
        aus = gehirn.regel_grosse_aenderung(plan.daten.get("alt"), plan.daten.get("neu"), "Der Preis")
        neu = plan.daten.get("neu")
        if v.get("vk_min") and neu and neu / 1.19 < v["vk_min"]:
            aus.append(gehirn.hinweis("warnung", "Unter VK min.",
                                      f"Netto {sprache.eur_text(neu / 1.19, 0)} liegt unter dem Mindestverkaufspreis "
                                      f"({sprache.eur_text(v['vk_min'], 0)}).", "vk_min"))
        return aus


class StatusAendern(FahrzeugAktion):
    kennung = "fahrzeugstatus"
    titel = "Fahrzeugstatus ändern"
    beschreibung = ("Verkauft (mit Kunde → Spalte Kommission) oder wieder frei. „Reserviert“ gibt es nicht – "
                    "Hausregel VERKAUF-002.")
    beispiele = ("DETKW00191 ist verkauft an Fam. Berger", "DRM00312 ist wieder frei")
    ausloeser = ((r"verkauft an|ist verkauft|wieder frei|freigeben|zurück in den bestand|storniert|reservier|kommission", 6),)
    gegen = (FRAGE, r"stück|stueck|lager(bestand)?\b|teil")
    direkt_felder = ({"name": "status", "typ": "wahl", "label": "Status", "optionen": ["Verkauft", "Bestand"]},
                     {"name": "kunde", "typ": "text", "label": "Kunde (bei Verkauft)"})

    def lies(self, text, k):
        p = super().lies(text, k)
        t = text.lower()
        if re.search(r"reservier", t):
            p["status"] = "Reserviert"
        elif re.search(r"wieder frei|freigeben|zurück in den bestand|storniert|lager", t):
            p["status"] = "Bestand"
        elif re.search(r"verkauft|kommission", t):
            p["status"] = "Verkauft"
            m = re.search(r"(?:verkauft an|an|für|fuer|kunde)\s+((?:fam\.?|familie|herrn?|frau)?\s*[A-ZÄÖÜ][\w\-äöüß]+"
                          r"(?:\s+[A-ZÄÖÜ][\w\-äöüß]+)?)", text)
            if m:
                p["kunde"] = m.group(1).strip()
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if p.get("status") not in ("Verkauft", "Bestand", "Reserviert"):
            return Rueckfrage("Welcher Status?", "status", [option("Verkauft", "Verkauft"), option("Bestand", "Wieder frei")])
        if p["status"] == "Verkauft" and not p.get("kunde"):
            return Rueckfrage("An wen verkauft?", "kunde", frei=True, platzhalter="Kundenname")
        return None

    def plane(self, p, k):
        v = self.fahrzeug(p, k)
        if p["status"] == "Reserviert":
            regel = hausregeln.regel("VERKAUF-002") if hasattr(hausregeln, "regel") else None
            plan = Plan(f"{v['internal_id']} reservieren", liste="Bestandsliste")
            plan.nur_vorschau = ("Reservierungen sind nicht vorgesehen (Hausregel VERKAUF-002) – auch nicht kurz oder übers "
                                 "Wochenende. ODIN bietet „reserviert“ deshalb nicht an.")
            plan.daten["regel"] = regel
            return plan
        neu_status = p["status"]
        kommission = p.get("kunde") if neu_status == "Verkauft" else None
        alt_text = f"{v.get('status')}" + (f" ({v.get('kommission_name')})" if v.get("kommission_name") else "")
        neu_text = neu_status + (f" ({kommission})" if kommission else "")
        if alt_text == neu_text:
            raise AktionsFehler(f"{v['internal_id']} steht schon auf {neu_text}.")
        plan = Plan(f"Status {v['internal_id']}: {alt_text} → {neu_text}", liste="Bestandsliste")
        plan.odin = [{"was": f"Status {v['internal_id']}", "alt": alt_text, "neu": neu_text}]
        plan.overlay = [{"tabelle": "vehicles", "setze": {"status": neu_status, "kommission_name": kommission,
                                                         "kommission_art": "Kommission" if kommission else "Lager",
                                                         "customer": kommission},
                         "wo": {"internal_id": v["internal_id"]}}]
        z = self.zeile(v, k)
        if z is None:
            plan.nur_vorschau = ohne_datei_grund(k, self.art)
            return plan
        plan.datei = z.datei
        plan.schluessel = z.schluessel(["internal_id"])
        if "status" in z.spalten:
            plan.zellen.append(z.ziel("status", "Status", neu_wert=neu_status, neu_text=neu_status))
        if "kommission_roh" in z.spalten:
            plan.zellen.append(z.ziel("kommission_roh", "Kommission", neu_wert=kommission, neu_text=kommission or "leer"))
        if not plan.zellen:
            plan.nur_vorschau = "Die Bestandsliste hat weder eine Spalte „Status“ noch „Kommission“."
        return plan

    def pruefe(self, p, plan, k):
        v = self.fahrzeug(p, k)
        aus = []
        if p["status"] == "Reserviert":
            aus.append(gehirn.hinweis("kritisch", "Hausregel VERKAUF-002: keine Reservierungen",
                                      "Ausnahme nur: Kunde ruft direkt vor seiner Anfahrt an – dann für die bestätigte "
                                      "Fahrtzeit zurückhalten, ohne Eintrag.", "hausregel"))
        if p["status"] == "Bestand" and k.db.execute("SELECT 1 FROM deliveries WHERE vehicle_internal_id = ? AND "
                                                     "actual_date IS NULL", (v["internal_id"],)).fetchone():
            aus.append(gehirn.hinweis("warnung", "Übergabe geplant",
                                      "Für das Fahrzeug steht noch eine Übergabe in der Auslieferungsliste.", "uebergabe"))
        return aus


class FahrzeugEingetroffen(FahrzeugAktion):
    kennung = "eingetroffen"
    titel = "Fahrzeug eingetroffen"
    beschreibung = "Fahrzeug ist da: Schlüsselnummer eintragen und die Zelle grün (frei) statt rot färben."
    beispiele = ("DETKW00238 ist angekommen, Schlüssel 4420", "DRM00312 eingetroffen")
    ausloeser = ((r"eingetroffen|angekommen|angeliefert|ist da\b|ist gekommen|geliefert worden", 5),
                 (r"schlüssel|schluessel|fahrzeug|wohnmobil|wohnwagen|kastenwagen|[a-z]{2,5}\d{3,5}", 2))
    gegen = (FRAGE, r"\bteile\b|papiere|brief|zahlung|geld")
    direkt_felder = ({"name": "schluessel", "typ": "text", "label": "Schlüsselnummer"},)

    def lies(self, text, k):
        p = super().lies(text, k)
        m = re.search(r"schl(?:ü|ue)ssel(?:nummer|nr\.?)?\s*:?\s*(\d{1,6})", text, re.IGNORECASE)
        if m:
            p["schluessel"] = m.group(1)
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if not p.get("schluessel"):
            return Rueckfrage("Welche Schlüsselnummer bekommt das Fahrzeug?", "schluessel", frei=True,
                              platzhalter="z. B. 4420")
        return None

    def plane(self, p, k):
        v = self.fahrzeug(p, k)
        nr = str(p["schluessel"]).strip()
        plan = Plan(f"{v['internal_id']} ist eingetroffen – Schlüssel {nr}", liste="Bestandsliste")
        plan.odin = [{"was": f"Lieferstatus {v['internal_id']}", "alt": v.get("lieferstatus") or "–", "neu": "angeliefert"},
                     {"was": "Schlüsselnummer", "alt": v.get("schluessel_nr") or v.get("lieferblock") or "–", "neu": nr}]
        plan.overlay = [{"tabelle": "vehicles", "setze": {"schluessel_nr": nr, "lieferstatus": "angeliefert",
                                                         "lieferblock": None}, "wo": {"internal_id": v["internal_id"]}}]
        z = self.zeile(v, k)
        if z is None:
            plan.nur_vorschau = ohne_datei_grund(k, self.art)
            return plan
        if "schluessel_roh" not in z.spalten:
            plan.nur_vorschau = "Die Bestandsliste hat keine Spalte für die Schlüsselnummer."
            return plan
        wert = int(nr) if nr.isdigit() else nr
        plan.datei = z.datei
        plan.zellen = [z.ziel("schluessel_roh", "Liefer-KW/Schlüsselnr.", neu_wert=wert,
                              neu_text=f"{nr} · Farbe frei", neu_fuellung=farbe("bestand_zeile", "frei"))]
        plan.schluessel = z.schluessel(["internal_id"])
        return plan


# --------------------------------------------------------------------------------------- Finanzen ---

class TilgungGezahlt(FahrzeugAktion):
    kennung = "tilgung"
    titel = "Tilgung gezahlt"
    bereich = "Finanzierung"
    recht = "finanzen"
    beschreibung = ("Tilgungsrate als bezahlt vermerken (ODIN-Vermerk – die Finanzaufstellung hat dafür keine "
                    "eigene Spalte).")
    beispiele = ("Tilgung für DETKW00142 ist bezahlt", "Rate DRM00245 vom 15.12. gezahlt")
    ausloeser = ((r"tilgung|\brate\b|abschlag", 6), (r"bezahlt|gezahlt|überwiesen|ueberwiesen|erledigt", 2))
    gegen = (FRAGE,)

    def lies(self, text, k):
        p = super().lies(text, k)
        termine = sprache.finde_termine(text, k.heute)
        if termine:
            p["faellig_am"] = termine[0].datum.isoformat()
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        offen = [dict(r) for r in k.db.execute("SELECT faellig_am, betrag, bank FROM tilgungen WHERE vehicle_internal_id "
                                               "= ? AND bezahlt_am IS NULL ORDER BY faellig_am", (p["fid"],))]
        if not offen:
            raise AktionsFehler(f"Für {p['fid']} ist keine offene Tilgungsrate eingetragen.")
        if p.get("faellig_am"):
            passend = [o for o in offen if o["faellig_am"] == p["faellig_am"]]
            if passend:
                return None
        if len(offen) == 1:
            p["faellig_am"] = offen[0]["faellig_am"]
            return None
        return Rueckfrage("Welche Rate?", "faellig_am", [option(o["faellig_am"], sprache.datum_text(o["faellig_am"]),
                                                                sprache.eur_text(o["betrag"], 0)) for o in offen[:6]])

    def plane(self, p, k):
        r = k.db.execute("SELECT * FROM tilgungen WHERE vehicle_internal_id = ? AND faellig_am = ? AND bezahlt_am IS NULL",
                         (p["fid"], p["faellig_am"])).fetchone()
        if not r:
            raise AktionsFehler("Diese Rate ist schon bezahlt oder gibt es nicht.")
        plan = Plan(f"Tilgung {p['fid']} ({sprache.datum_text(r['faellig_am'])}, {sprache.eur_text(r['betrag'], 0)}) "
                    "als bezahlt vermerken", liste="")
        plan.odin = [{"was": f"Rate {sprache.datum_text(r['faellig_am'])} ({r['bank'] or 'Bank'})",
                      "alt": "offen", "neu": f"bezahlt am {sprache.datum_text(k.heute)} (Vermerk)"}]
        plan.daten = {"vermerk": {"art": "tilgung_bezahlt", "bezug": p["fid"], "datum": k.heute.isoformat(),
                                  "faellig_am": r["faellig_am"], "betrag": r["betrag"],
                                  "text": f"Tilgung {sprache.datum_text(r['faellig_am'])} bezahlt"}}
        return plan

    def pruefe(self, p, plan, k):
        if p["faellig_am"] > (k.heute + dt.timedelta(days=30)).isoformat():
            return [gehirn.hinweis("info", "Rate ist erst später fällig",
                                   f"Fällig am {sprache.datum_text(p['faellig_am'])} – vorzeitig bezahlt?", "frueh")]
        return []

    def odin_ausfuehren(self, plan, k):
        return {"vermerk": k.dienst.vermerk_anlegen(plan.daten["vermerk"])}

    def odin_rueckgaengig(self, eintrag, k):
        vid = (eintrag.get("odin_ergebnis") or {}).get("vermerk")
        if vid:
            k.dienst.vermerk_entfernen(vid)


class AbloesungErledigt(FahrzeugAktion):
    kennung = "abloesung"
    titel = "Ablösung erledigt"
    bereich = "Finanzierung"
    recht = "finanzen"
    beschreibung = "Einkaufsfinanzierung abgelöst: die (geplante) Ablösung in ODIN als erledigt markieren."
    beispiele = ("DETKW00142 ist abgelöst", "Ablösung DRM00245 erledigt")
    ausloeser = ((r"abgelöst|abgeloest|ablösung|abloesung|ablöse|abloese", 7),)
    gegen = (FRAGE, r"plan|geplant|am \d|zum \d")

    def plane(self, p, k):
        fin = k.db.execute("SELECT bank, financed_amount FROM financings WHERE vehicle_internal_id = ? AND "
                           "COALESCE(status,'offen') = 'offen' LIMIT 1", (p["fid"],)).fetchone()
        plan = Plan(f"Ablösung {p['fid']} als erledigt markieren", liste="")
        plan.odin = [{"was": f"Ablösung {p['fid']}" + (f" ({fin['bank']})" if fin else ""), "alt": "offen",
                      "neu": f"erledigt am {sprache.datum_text(k.heute)}"}]
        plan.daten = {"fid": p["fid"]}
        if not fin:
            plan.hinweise.append(gehirn.hinweis("info", "Keine offene Finanzierung",
                                                f"Für {p['fid']} steht keine offene Finanzierung in der Finanzaufstellung.",
                                                "finanzierung"))
        return plan

    def pruefe(self, p, plan, k):
        return [gehirn.hinweis("info", "Finanzaufstellung",
                               "Die Zeile in der Finanzaufstellung bitte wie gewohnt entfernen bzw. markieren – ODIN "
                               "vermerkt die Ablösung bis dahin selbst.", "finanzaufstellung")] + plan.hinweise

    def odin_ausfuehren(self, plan, k):
        return k.dienst.abloesung_erledigen(plan.daten["fid"], k.heute.isoformat())

    def odin_rueckgaengig(self, eintrag, k):
        k.dienst.abloesung_zuruecksetzen(eintrag.get("odin_ergebnis") or {})


# ---------------------------------------------------------------------------------------- Cashback ---

class CashbackAktion(Aktion):
    bereich = "Cashback"
    status_neu = ""

    def lies(self, text, k):
        p = {"fid": finde_fahrzeug_id(k.db, text)}
        betrag = sprache.finde_betrag(text)
        if betrag:
            p["betrag"] = betrag
            p["brutto"] = bool(re.search(r"brutto", text, re.IGNORECASE))
        return p

    def vorgaenge(self, k):
        ordner = k.dienst.cashback_ordner()
        if not ordner:
            return ordner, []
        gelesen = k.dienst.cashback_lesen(ordner)
        aus = []
        for liste in gelesen.get("listen") or []:
            for v in liste.get("vorgaenge") or []:
                aus.append({**v, "datei": liste["datei"], "hersteller": liste["hersteller"]})
        return ordner, aus

    def schritt(self, p, k):
        if p.get("vorgang"):
            return None
        ordner, alle = self.vorgaenge(k)
        if not ordner:
            raise AktionsFehler("Der Cashback-Ordner ist nicht eingebunden (Cashback → Ordner wählen).")
        offen = [v for v in alle if v["status"] in ("Angelegt", "Angefordert", "Prüfen")]
        if p.get("fid"):
            treffer = [v for v in offen if id_gleich(v.get("interne_id"), p["fid"])]
        else:
            punkte = [(sprache.name_im_text(v.get("kunde"), k.satz), v) for v in offen]
            beste = max((n for n, _ in punkte), default=0)
            treffer = [v for n, v in punkte if n == beste and n > 0]
        if len(treffer) == 1:
            p["vorgang"] = f"{treffer[0]['datei']}|{treffer[0]['jahr']}|{treffer[0]['zeile']}"
            return None
        auswahl = treffer or offen
        return Rueckfrage("Welcher Cashback-Vorgang?", "vorgang", [
            option(f"{v['datei']}|{v['jahr']}|{v['zeile']}", f"{v.get('kunde') or v.get('fin')} · {v.get('modell') or ''}",
                   f"{v['hersteller']} · {v['status']}") for v in auswahl[:8]])

    def vorgang(self, p, k):
        datei, jahr, zeile = p["vorgang"].split("|")
        ordner, alle = self.vorgaenge(k)
        v = next((x for x in alle if x["datei"] == datei and str(x["jahr"]) == jahr and str(x["zeile"]) == zeile), None)
        if not v:
            raise AktionsFehler("Diesen Cashback-Vorgang gibt es nicht mehr.")
        return os.path.join(ordner, datei), v

    def zeile(self, pfad, v):
        from ..cockpit import cashback as cb
        mappe = xl.lies_mappe(pfad, max_spalte=60)
        blatt = next((n for n in mappe if cb.BLATT.match(n) and cb.BLATT.match(n).group(1) == str(v["jahr"])), None)
        if not blatt:
            raise AktionsFehler(f"Das Blatt „Aktionen {v['jahr']}“ fehlt in {os.path.basename(pfad)}.")
        rb = mappe[blatt]
        letzte = max(rb.zeilen) if rb.zeilen else 0
        reihen = [rb.werte(n) if n in rb.zeilen else [] for n in range(1, min(letzte, 12) + 1)]
        kopf, spalten = cb._kopfzeile(reihen)
        if kopf is None:
            raise AktionsFehler("In der Cashback-Liste fehlt die Überschriftenzeile.")
        sp = {f: i + 1 for f, i in spalten.items()}
        z = ExcelZeile(pfad, blatt, int(v["zeile"]), sp, mappe)
        kunde = xl.vergleich(z.zelle("kunde").ergebnis) if "kunde" in sp else ""
        if sprache.einfach(kunde) != sprache.einfach(v.get("kunde") or ""):
            raise AktionsFehler("Die Cashback-Liste hat sich geändert – bitte neu laden.")
        return z


class CashbackAngefordert(CashbackAktion):
    kennung = "cashback_angefordert"
    titel = "Gutschrift angefordert"
    beschreibung = "Cashback beim Hersteller angefordert: Status „Angefordert“ und „GS angefordert am“ = heute."
    beispiele = ("Cashback für Schou angefordert", "Gutschrift DETKW00142 beim Hersteller angefordert")
    ausloeser = ((r"cashback|gutschrift|prämie|praemie", 5), (r"angefordert|eingereicht|beantragt", 4))
    gegen = (FRAGE, r"erhalten|bekommen|eingegangen|da\b")

    def plane(self, p, k):
        pfad, v = self.vorgang(p, k)
        plan = Plan(f"Cashback {v.get('kunde')} ({v['hersteller']}): angefordert am {sprache.datum_text(k.heute)}",
                    liste=f"Cashback {v['hersteller']}")
        plan.odin = [{"was": f"Cashback {v.get('kunde')}", "alt": v["status"], "neu": "Angefordert"},
                     {"was": "Nachhaken", "alt": "", "neu": "Termin in „Heute & Woche“ wird neu berechnet"}]
        z = self.zeile(pfad, v)
        plan.datei = pfad
        plan.schluessel = z.schluessel(["kunde"])
        if "status" in z.spalten:
            plan.zellen.append(z.ziel("status", "Status", neu_wert="Angefordert", neu_text="Angefordert"))
        if "angefordert_am" in z.spalten:
            plan.zellen.append(z.ziel("angefordert_am", "GS angefordert am", neu_wert=dt.datetime.combine(k.heute, dt.time()),
                                      neu_text=sprache.datum_text(k.heute), nummernformat="DD.MM.YYYY"))
        if not plan.zellen:
            plan.nur_vorschau = "Die Cashback-Liste hat keine Spalte „Status“."
        return plan

    def pruefe(self, p, plan, k):
        pfad, v = self.vorgang(p, k)
        aus = []
        if v.get("frist") and v["frist"] < k.heute.isoformat():
            aus.append(gehirn.hinweis("warnung", "Einreichungsfrist abgelaufen",
                                      f"Die Frist war am {sprache.datum_text(v['frist'])}.", "cashback_frist"))
        if v["status"] == "Angefordert":
            aus.append(gehirn.hinweis("info", "Schon angefordert", f"Angefordert am {sprache.datum_text(v['angefordert_am']) if v.get('angefordert_am') else '?'} – Datum wird überschrieben.", "doppelt"))
        return aus


class CashbackErhalten(CashbackAktion):
    kennung = "cashback_erhalten"
    titel = "Gutschrift erhalten"
    recht = "finanzen"
    beschreibung = "Cashback-Gutschrift ist da: Status „Erledigt“, GS-Datum heute, Betrag (netto oder brutto)."
    beispiele = ("Gutschrift für Schou über 1.500 € netto erhalten", "Cashback DETKW00142 ist eingegangen")
    ausloeser = ((r"cashback|gutschrift|prämie|praemie", 5), (r"erhalten|bekommen|eingegangen|ist da|gekommen|gebucht", 4))
    gegen = (FRAGE, r"angefordert|eingereicht")

    def plane(self, p, k):
        pfad, v = self.vorgang(p, k)
        plan = Plan(f"Cashback {v.get('kunde')} ({v['hersteller']}) erhalten", liste=f"Cashback {v['hersteller']}")
        plan.odin = [{"was": f"Cashback {v.get('kunde')}", "alt": v["status"], "neu": "Erledigt"}]
        z = self.zeile(pfad, v)
        plan.datei = pfad
        plan.schluessel = z.schluessel(["kunde"])
        if "status" in z.spalten:
            plan.zellen.append(z.ziel("status", "Status", neu_wert="Erledigt", neu_text="Erledigt"))
        if "gs_datum" in z.spalten:
            plan.zellen.append(z.ziel("gs_datum", "GS-Datum", neu_wert=dt.datetime.combine(k.heute, dt.time()),
                                      neu_text=sprache.datum_text(k.heute), nummernformat="DD.MM.YYYY"))
        if p.get("betrag"):
            feld = "gs_brutto" if p.get("brutto") else "gs_netto"
            if feld in z.spalten:
                plan.zellen.append(z.ziel(feld, "GS " + ("brutto" if p.get("brutto") else "netto"),
                                          neu_wert=float(p["betrag"]), neu_text=sprache.eur_text(float(p["betrag"]))))
        plan.daten = {"soll": v.get("soll"), "betrag": p.get("betrag"), "brutto": p.get("brutto")}
        return plan

    def pruefe(self, p, plan, k):
        d = plan.daten
        if d.get("soll") and d.get("betrag") and not d.get("brutto") and abs(d["soll"] - d["betrag"]) >= 0.05:
            return [gehirn.hinweis("warnung", "Betrag weicht vom Soll ab",
                                   f"Soll {sprache.eur_text(d['soll'])}, erhalten {sprache.eur_text(d['betrag'])}.",
                                   "cashback_soll")]
        return []


# ----------------------------------------------------------------------------------- ODIN-intern ---

_BEREICHE = (("Auslieferung", r"zulassung|übergabe|uebergabe|auslieferung|papiere|brief|tüv|tuev"),
             ("Teile", r"teil|bestell|einbau"), ("Finanzierung", r"tilgung|ablös|abloes|bank|finanz"),
             ("Werkstatt", r"werkstatt|reparatur|termin"), ("Bestand", r"fahrzeug|bestand|preis"))


class AufgabeAnlegen(Aktion):
    kennung = "aufgabe"
    titel = "Aufgabe anlegen"
    bereich = "ODIN"
    im_browser = True
    beschreibung = "To-do anlegen, auf Wunsch mit Fälligkeit, Person und Fahrzeug („Erinner Tom morgen an …“)."
    beispiele = ("Erinner Tom morgen an die Zulassung von SLRM00412", "Aufgabe: Gutschein für Schou bestellen bis Freitag")
    ausloeser = ((r"erinner|aufgabe|to-?do|nicht vergessen|denk dran|denk daran|merk dir|wiedervorlage", 6),
                 (r"^\s*(bitte\s+)?(erinner|denk dran|denk daran|merk dir|wiedervorlage|aufgabe\s*:|to-?do\s*:)", 6))
    gegen = (r"^\s*(welche|was|wie viele|zeig)\b", r"erledigt|abgehakt|fertig")
    direkt_felder = ({"name": "text", "typ": "text", "label": "Aufgabe"}, {"name": "faellig_am", "typ": "date", "label": "Fällig am"})

    def lies(self, text, k):
        p = {"fid": finde_fahrzeug_id(k.db, text)}
        termine = sprache.finde_termine(text, k.heute)
        if termine:
            p["faellig_am"] = termine[0].datum.isoformat()
        personen = []
        try:
            personen = k.dienst.personen()
        except Exception:                                    # noqa: BLE001
            pass
        wer = [x for x in person_finden(personen, text) if x.get("id") != k.ich]
        if len(wer) == 1:
            p["person"] = wer[0].get("name")
        rest = text
        for t in termine:
            rest = rest.replace(t.roh, " ")
        m = re.match(r"^\s*(?:bitte\s+)?erinner\w*\s+([A-Za-zÄÖÜäöüß\-]+)\s+(?:an|daran|dass|wegen)\s+(.+)$", rest.strip(),
                     re.IGNORECASE)
        if m and m.group(1).lower() not in ("mich", "uns", "mir", "bitte"):
            p.setdefault("person", m.group(1)[0].upper() + m.group(1)[1:])
            rest = m.group(2)
        rest = re.sub(r"^\s*(bitte\s+)?(erinner\w*|aufgabe|to-?do|denk\s+(dran|daran)|merk\s+dir|nicht\s+vergessen)\s*:?\s*",
                      "", rest, flags=re.IGNORECASE)
        if p.get("person"):
            vorname = p["person"].split()[0]
            rest = re.sub(rf"^\s*{re.escape(vorname)}\w*\s+", "", rest, flags=re.IGNORECASE)
        rest = re.sub(r"^\s*(mich|uns)\s+", "", rest, flags=re.IGNORECASE)
        rest = re.sub(r"^\s*(an|daran|dass)\s+", "", rest, flags=re.IGNORECASE)
        rest = re.sub(r"^(die|den|das|der)\s+", "", rest.strip(), flags=re.IGNORECASE)
        rest = re.sub(r"\s{2,}", " ", rest).strip(" ,.:")
        if rest:
            p["text"] = rest[0].upper() + rest[1:]
        return p

    def schritt(self, p, k):
        if not (p.get("text") or "").strip():
            return Rueckfrage("Was soll in die Aufgabe?", "text", frei=True, platzhalter="z. B. Zulassung SLRM00412 klären")
        return None

    def plane(self, p, k):
        text = (f"{p['person']}: " if p.get("person") else "") + p["text"].strip()
        bereich = next((b for b, m in _BEREICHE if re.search(m, text, re.IGNORECASE)), "Allgemein")
        plan = Plan(f"Aufgabe anlegen: „{text}“" + (f", fällig {sprache.datum_text(p['faellig_am'])}" if p.get("faellig_am") else ""))
        plan.odin = [{"was": "To-do", "alt": "", "neu": text},
                     {"was": "Fällig", "alt": "", "neu": sprache.datum_text(p["faellig_am"], True, True) if p.get("faellig_am") else "ohne"},
                     {"was": "Bereich", "alt": "", "neu": bereich + (f" · {p['fid']}" if p.get("fid") else "")}]
        plan.daten = {"text": text, "bereich": bereich, "bezug_id": p.get("fid"), "faellig_am": p.get("faellig_am"),
                      "prioritaet": "normal"}
        return plan

    def pruefe(self, p, plan, k):
        aus = []
        if p.get("faellig_am"):
            d = dt.date.fromisoformat(p["faellig_am"])
            if d < k.heute:
                aus.append(gehirn.hinweis("warnung", "Fälligkeit liegt in der Vergangenheit", sprache.datum_text(d), "vergangenheit"))
            aus += [h for h in gehirn.regel_ruhetag(d) if h["schwere"] != "info"]
        return aus

    def odin_ausfuehren(self, plan, k):
        return k.dienst.cockpit.todo_anlegen(plan.daten)

    def odin_rueckgaengig(self, eintrag, k):
        tid = (eintrag.get("odin_ergebnis") or {}).get("id")
        if tid:
            k.dienst.cockpit.todo_loeschen(tid)


class AufgabeErledigen(Aktion):
    kennung = "aufgabe_erledigt"
    titel = "Aufgabe erledigt"
    bereich = "ODIN"
    im_browser = True
    beschreibung = "Ein offenes To-do abhaken."
    beispiele = ("Aufgabe Papiere nachfordern ist erledigt", "To-do Gutschein Schou abhaken")
    ausloeser = ((r"aufgabe|to-?do", 4), (r"erledigt|abhaken|abgehakt|fertig|done", 4),
                 (r"^\s*(die\s+)?(aufgabe|to-?do)\b.{0,80}(erledigt|abhaken|abgehakt|fertig)", 6))
    gegen = (FRAGE,)

    def schritt(self, p, k):
        if p.get("todo_id"):
            return None
        offen = [dict(r) for r in k.db.execute("SELECT id, text, faellig_am FROM todos WHERE erledigt = 0 ORDER BY id")]
        worte = [w for w in sprache.woerter(k.satz) if len(w) >= 4 and w not in
                 ("aufgabe", "erledigt", "abhaken", "abgehakt", "fertig", "todo", "bitte", "ist", "sind")]
        punkte = [(sum(1 for w in worte if any(sprache.wort_passt(w, x) for x in sprache.woerter(t["text"]))), t) for t in offen]
        beste = max((n for n, _ in punkte), default=0)
        treffer = [t for n, t in punkte if n == beste and n > 0]
        if len(treffer) == 1:
            p["todo_id"] = str(treffer[0]["id"])
            return None
        if not offen:
            raise AktionsFehler("Es gibt keine offenen To-dos.")
        return Rueckfrage("Welche Aufgabe ist erledigt?", "todo_id",
                          [option(t["id"], t["text"][:80], sprache.datum_text(t["faellig_am"]) if t.get("faellig_am") else "")
                           for t in (treffer or offen)[:8]])

    def plane(self, p, k):
        t = k.db.execute("SELECT * FROM todos WHERE id = ?", (int(p["todo_id"]),)).fetchone()
        if not t:
            raise AktionsFehler("Diese Aufgabe gibt es nicht mehr.")
        if t["erledigt"]:
            raise AktionsFehler("Die Aufgabe ist schon erledigt.")
        plan = Plan(f"Aufgabe „{t['text']}“ abhaken")
        plan.odin = [{"was": t["text"], "alt": "offen", "neu": "erledigt"}]
        plan.daten = {"id": t["id"]}
        return plan

    def odin_ausfuehren(self, plan, k):
        k.dienst.cockpit.todo_umschalten(plan.daten["id"])
        return {"id": plan.daten["id"]}

    def odin_rueckgaengig(self, eintrag, k):
        tid = (eintrag.get("odin_ergebnis") or {}).get("id")
        if tid:
            k.dienst.cockpit.todo_umschalten(tid)


class FristErledigt(Aktion):
    kennung = "frist"
    titel = "Frist erledigt"
    bereich = "ODIN"
    beschreibung = "Eine Betriebsfrist (Fristenkalender) erledigen – wiederkehrende rücken weiter."
    beispiele = ("Frist Prüfung Hebebühnen erledigt", "UVV-Prüfung ist gemacht")
    ausloeser = ((r"frist|prüfung|pruefung|uvv|wartung", 4), (r"erledigt|gemacht|durch|abgehakt", 4))
    gegen = (FRAGE, r"zulassung|cashback|einreich")

    def schritt(self, p, k):
        if p.get("frist_id"):
            return None
        fristen = [dict(r) for r in k.db.execute("SELECT id, titel, faellig_am FROM betriebsfristen ORDER BY faellig_am")]
        worte = [w for w in sprache.woerter(k.satz) if len(w) >= 4 and w not in ("frist", "erledigt", "gemacht", "ist")]
        punkte = [(sum(1 for w in worte if any(sprache.wort_passt(w, x) or x.startswith(w) for x in sprache.woerter(f["titel"]))), f)
                  for f in fristen]
        beste = max((n for n, _ in punkte), default=0)
        treffer = [f for n, f in punkte if n == beste and n > 0]
        if len(treffer) == 1:
            p["frist_id"] = str(treffer[0]["id"])
            return None
        if not fristen:
            raise AktionsFehler("Im Fristenkalender steht keine offene Frist.")
        return Rueckfrage("Welche Frist?", "frist_id", [option(f["id"], f["titel"], sprache.datum_text(f["faellig_am"]))
                                                       for f in (treffer or fristen)[:8]])

    def plane(self, p, k):
        f = k.db.execute("SELECT * FROM betriebsfristen WHERE id = ?", (int(p["frist_id"]),)).fetchone()
        if not f:
            raise AktionsFehler("Diese Frist gibt es nicht mehr.")
        plan = Plan(f"Frist „{f['titel']}“ erledigt")
        plan.odin = [{"was": f["titel"], "alt": f"fällig {sprache.datum_text(f['faellig_am'])}",
                      "neu": "erledigt (wiederkehrende Fristen rücken weiter)"}]
        plan.daten = {"id": f["id"]}
        return plan

    def odin_ausfuehren(self, plan, k):
        vorher = k.dienst.frist_stand(plan.daten["id"])
        r = k.dienst.cockpit.frist_erledigt(plan.daten["id"])
        return {"id": plan.daten["id"], "vorher": vorher, "naechste": r.get("naechste")}

    def odin_rueckgaengig(self, eintrag, k):
        e = eintrag.get("odin_ergebnis") or {}
        if e.get("vorher"):
            k.dienst.frist_zuruecksetzen(e["id"], e["vorher"])


class UrlaubBeantragen(Aktion):
    kennung = "urlaub"
    titel = "Urlaub beantragen"
    bereich = "ODIN"
    im_browser = True
    beschreibung = "Urlaubsantrag für mich stellen (von – bis); genehmigt wird wie immer unter Urlaub."
    beispiele = ("Ich möchte vom 22.12. bis 2.1. Urlaub", "Urlaub am Freitag beantragen")
    ausloeser = ((r"urlaub|frei nehmen|freinehmen|überstundenausgleich|ueberstundenausgleich|sonderurlaub", 5),
                 (r"beantrag|möchte|moechte|nehmen|eintragen|brauche", 2))
    gegen = (FRAGE, r"wer hat|wer ist|genehmig")

    def lies(self, text, k):
        termine = sprache.finde_termine(text, k.heute)
        p = {}
        if termine:
            p["von"] = termine[0].datum.isoformat()
            p["bis"] = termine[-1].datum.isoformat()
        t = text.lower()
        p["art"] = "Sonderurlaub" if "sonderurlaub" in t else "Überstundenausgleich" if re.search(r"überstunden|ueberstunden", t) else "Urlaub"
        p["halber_tag"] = bool(re.search(r"halbe[nr]? tag|halbtags|vormittag|nachmittag", t))
        return p

    def antwort(self, p, feld, wert, k):
        if feld == "zeitraum":
            termine = sprache.finde_termine(wert, k.heute)
            if not termine:
                raise AktionsFehler("Bitte z. B. „22.12. bis 2.1.“ oder „nächsten Freitag“.")
            p["von"], p["bis"] = termine[0].datum.isoformat(), termine[-1].datum.isoformat()
            return
        super().antwort(p, feld, wert, k)

    def schritt(self, p, k):
        if not p.get("von"):
            return Rueckfrage("Von wann bis wann?", "zeitraum", frei=True, platzhalter="z. B. 22.12. bis 2.1.")
        if p["bis"] < p["von"]:
            raise AktionsFehler("Der letzte Tag liegt vor dem ersten.")
        return None

    def plane(self, p, k):
        spanne = sprache.datum_text(p["von"]) + ("" if p["von"] == p["bis"] else f" bis {sprache.datum_text(p['bis'])}")
        plan = Plan(f"{p['art']} beantragen: {spanne}" + (" (halber Tag)" if p.get("halber_tag") else ""))
        plan.odin = [{"was": "Antrag", "alt": "", "neu": f"{p['art']} {spanne} – für {k.ich_name or 'mich'}"},
                     {"was": "Status", "alt": "", "neu": "beantragt (Genehmigung unter Urlaub)"}]
        plan.daten = {"von": p["von"], "bis": p["bis"], "art": p["art"], "halber_tag": bool(p.get("halber_tag"))}
        return plan

    def pruefe(self, p, plan, k):
        aus = []
        if p["von"] < k.heute.isoformat():
            aus.append(gehirn.hinweis("warnung", "Beginn liegt in der Vergangenheit", sprache.datum_text(p["von"]), "vergangenheit"))
        n = k.db.execute("SELECT COUNT(*) FROM deliveries WHERE actual_date IS NULL AND date(planned_date) BETWEEN date(?) AND date(?)",
                         (p["von"], p["bis"])).fetchone()[0]
        if n:
            aus.append(gehirn.hinweis("info", f"{n} Übergabe(n) in dem Zeitraum",
                                      "Bitte prüfen, ob du bei einer davon eingeplant bist.", "uebergaben"))
        return aus

    def odin_ausfuehren(self, plan, k):
        a = k.dienst.urlaub().antrag_stellen(plan.daten)
        return {"antrag": (a or {}).get("id") or ((a or {}).get("antrag") or {}).get("id")}

    def odin_rueckgaengig(self, eintrag, k):
        aid = (eintrag.get("odin_ergebnis") or {}).get("antrag")
        if aid:
            k.dienst.urlaub().antrag_zurueckziehen(aid)


class MesseHinzufuegen(Aktion):
    kennung = "messe"
    titel = "Zur Messe eintragen"
    bereich = "ODIN"
    beschreibung = "Person ins Messe-Personal (ABF oder Hausmesse) eintragen."
    beispiele = ("Nimm Jan mit zur ABF", "Uwe zur Hausmesse eintragen")
    ausloeser = ((r"\babf\b|messe|hausmesse", 5), (r"mitnehmen|nimm|eintragen|dabei|mit zur|hinzufügen|hinzufuegen", 3))
    gegen = (FRAGE, r"entfern|streich|austragen")

    def lies(self, text, k):
        p = {"messe": "hausmesse-2027" if re.search(r"hausmesse", text, re.IGNORECASE) else "abf-2027"}
        try:
            personen = k.dienst.personen()
        except Exception:                                    # noqa: BLE001
            personen = []
        wer = person_finden(personen, text)
        if len(wer) == 1:
            p["name"] = wer[0]["name"]
        elif len(wer) > 1:
            p["kandidaten"] = [x["name"] for x in wer]
        return p

    def schritt(self, p, k):
        if not p.get("name"):
            namen = p.get("kandidaten") or [x["name"] for x in (k.dienst.personen() or [])][:8]
            return Rueckfrage("Wen soll ich eintragen?", "name", [option(n, n) for n in namen], frei=True, platzhalter="Name")
        return None

    def plane(self, p, k):
        from ..messe import MESSEN
        name = MESSEN.get(p["messe"], {}).get("titel", p["messe"])
        plan = Plan(f"{p['name']} für {name} eintragen")
        plan.odin = [{"was": f"Messe-Personal {name}", "alt": "", "neu": p["name"] + " (Rest offen)"}]
        plan.daten = {"messe": p["messe"], "name": p["name"]}
        return plan

    def pruefe(self, p, plan, k):
        try:
            eintraege = k.dienst.messe().start(p["messe"]).get("eintraege") or []
        except Exception:                                    # noqa: BLE001
            return []
        if any(sprache.einfach(e.get("name")) == sprache.einfach(p["name"]) for e in eintraege):
            return [gehirn.hinweis("warnung", "Schon eingetragen", f"{p['name']} steht bereits auf der Liste.", "doppelt")]
        return []

    def odin_ausfuehren(self, plan, k):
        r = k.dienst.messe().anlegen(plan.daten["messe"], {"name": plan.daten["name"]})
        return {"messe": plan.daten["messe"], "id": r.get("neu")}

    def odin_rueckgaengig(self, eintrag, k):
        e = eintrag.get("odin_ergebnis") or {}
        if e.get("id"):
            k.dienst.messe().entfernen(e["messe"], e["id"])


class TicketAnlegen(Aktion):
    kennung = "ticket"
    titel = "Ticket anlegen"
    bereich = "ODIN"
    im_browser = True
    beschreibung = "Problem oder Idee zu ODIN als Ticket melden."
    beispiele = ("Ticket: Die Ampel bei Schou zeigt Rot, obwohl alles bezahlt ist", "Idee für ODIN: Export der Fristen als PDF")
    ausloeser = ((r"\bticket|problem melden|fehler melden|bug|idee für odin|idee fuer odin|melde (ein|einen)", 7),)
    gegen = (FRAGE, r"meine tickets|\bzeig (mir|meine|alle)")

    def lies(self, text, k):
        t = re.sub(r"^\s*(bitte\s+)?(leg\w*\s+)?(ein\s+)?(ticket|problem melden|fehler melden|melde (ein|einen) (problem|fehler)|"
                   r"idee f(ü|ue)r odin)\s*(an)?\s*[:\-–]?\s*", "", text, flags=re.IGNORECASE).strip()
        art = "idee" if re.search(r"\bidee|vorschlag|wunsch", text, re.IGNORECASE) else \
            "daten" if re.search(r"\bfalsch|stimmt nicht|falsche zahl", text, re.IGNORECASE) else "fehler"
        return {"titel": t[:120] if t else "", "beschreibung": t, "art": art}

    def schritt(self, p, k):
        if len((p.get("titel") or "").strip()) < 3:
            return Rueckfrage("Was ist das Problem bzw. die Idee?", "titel", frei=True, platzhalter="kurz beschreiben")
        return None

    def plane(self, p, k):
        from ..tickets import ARTEN
        plan = Plan(f"Ticket anlegen ({ARTEN[p['art']]}): „{p['titel']}“")
        plan.odin = [{"was": "Ticket", "alt": "", "neu": f"{ARTEN[p['art']]}: {p['titel']}"}]
        plan.daten = {"art": p["art"], "titel": p["titel"], "beschreibung": p.get("beschreibung") or ""}
        return plan

    def odin_ausfuehren(self, plan, k):
        r = k.dienst.tickets().anlegen(plan.daten, {"route": "#/assistent"})
        return {"ticket": ((r or {}).get("ticket") or {}).get("id") or (r or {}).get("id")}

    def odin_rueckgaengig(self, eintrag, k):
        raise AktionsFehler("Ein Ticket lässt sich nicht zurücknehmen – bitte im Ticket kommentieren.")


AKTIONEN = [StandortAendern(), FahrzeugPreisAendern(), StatusAendern(), FahrzeugEingetroffen(), TilgungGezahlt(),
            AbloesungErledigt(), CashbackAngefordert(), CashbackErhalten(), AufgabeAnlegen(), AufgabeErledigen(),
            FristErledigt(), UrlaubBeantragen(), MesseHinzufuegen(), TicketAnlegen()]
