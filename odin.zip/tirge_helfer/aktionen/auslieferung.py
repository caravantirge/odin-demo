"""Aktionen rund um die Auslieferungsliste: Termin verschieben, Papiere, Zahlung, Werk, Teile, TÜV, Einbauten,
Tanken, Bemerkung, Verkäufer, Zulassung."""

import datetime as dt
import re

from ..cockpit.excel import legende
from . import excel as xl
from . import gehirn, sprache
from .basis import (Aktion, AktionsFehler, Plan, Rueckfrage, bemerkung_dazu, farbe, finde_listenzeile, id_gleich,
                    neuer_terminwert, ohne_datei_grund, option, quelle)
from .finden import finde_fahrzeug_id, uebergabe_frage, uebergaben_finden

ART = "auslieferungen"


def _termin_gleich(wert, iso) -> bool:
    if not iso:
        return True
    if isinstance(wert, (dt.datetime, dt.date)):
        return (wert.date() if isinstance(wert, dt.datetime) else wert).isoformat() == str(iso)[:10]
    m = re.search(r"(\d{1,2})[./](\d{1,2})", str(wert or ""))
    if not m:
        return False
    d = dt.date.fromisoformat(str(iso)[:10])
    return (int(m.group(1)), int(m.group(2))) == (d.day, d.month)


def zeile_der_uebergabe(k, u: dict):
    """Excel-Zeile der Übergabe 'u' (Zeile aus deliveries) in der Auslieferungsliste."""
    pfad = quelle(k, ART)
    if not pfad:
        return None

    def passt(werte):
        if not xl.vergleich(werte.get("customer")) or sprache.einfach(xl.vergleich(werte.get("customer"))) != \
                sprache.einfach(u.get("customer") or ""):
            return False
        if werte.get("vehicle_internal_id") not in (None, "") and not id_gleich(werte["vehicle_internal_id"],
                                                                                u.get("vehicle_internal_id")):
            return False
        return _termin_gleich(werte.get("planned_date"), u.get("planned_date"))

    return finde_listenzeile(pfad, ART, passt, u.get("source_sheet"), u.get("zeile"))


class UebergabeAktion(Aktion):
    """Gemeinsam: welche Übergabe ist gemeint? (interne Nummer, Kundenname, altes Datum)."""
    bereich = "Auslieferungen"

    def lies(self, text, k):
        return {"fid": finde_fahrzeug_id(k.db, text)}

    def schritt(self, p, k):
        if p.get("uebergabe_id"):
            return None
        kandidaten = uebergaben_finden(k.db, k.satz, p)
        if len(kandidaten) == 1:
            p["uebergabe_id"] = str(kandidaten[0]["id"])
            return None
        if not kandidaten and p.get("fid"):
            raise AktionsFehler(f"Für {p['fid']} steht keine offene Übergabe in der Auslieferungsliste.")
        return uebergabe_frage(k.db, kandidaten, k.heute)

    def uebergabe(self, p, k) -> dict:
        r = k.db.execute("SELECT d.*, v.brand, v.model FROM deliveries d LEFT JOIN vehicles v "
                         "ON v.internal_id = d.vehicle_internal_id WHERE d.id = ?", (int(p["uebergabe_id"]),)).fetchone()
        if not r:
            raise AktionsFehler("Diese Übergabe gibt es nicht mehr – vielleicht wurde die Liste gerade neu eingelesen.")
        return dict(r)

    @staticmethod
    def wer(u) -> str:
        return f"{u.get('customer') or 'ohne Namen'} ({u.get('vehicle_internal_id')}, Übergabe " \
               f"{sprache.termin_text(u.get('planned_date'), u.get('uhrzeit'), False)})"

    def zeile(self, u, k):
        z = zeile_der_uebergabe(k, u)
        return z

    def ohne_datei(self, k) -> str:
        return ohne_datei_grund(k, ART)


# ------------------------------------------------------------------------------- Termin verschieben ---

class TerminVerschieben(UebergabeAktion):
    kennung = "termin_verschieben"
    titel = "Übergabe verschieben"
    beschreibung = "Neuer Übergabetermin (Datum und Uhrzeit) – in der Auslieferungsliste und in ODIN."
    beispiele = ("Verschieb die Auslieferung von Thomas Müller mit DETKW00331 vom 26.11.2026 10:00 auf den 28.11.2026 15:00",
                 "Übergabe Schou auf nächsten Freitag 14 Uhr", "DRM00245 auf morgen 9:30 verschieben")
    ausloeser = ((r"verschieb|verleg|umleg|neuer termin|termin (auf|ändern|aendern)|vorzieh|zieh\w* .{0,30}vor\b", 6),
                 (r"auslieferung|übergabe|uebergabe|abholung|termin", 2),
                 (r"(übergabe|uebergabe|auslieferung|abholung|termin)\b.*\b(auf|nach)\s+(den\s+)?(\d|morgen|übermorgen|"
                  r"uebermorgen|nächst|naechst|kommend|montag|dienstag|mittwoch|donnerstag|freitag|samstag)", 4))
    parameter_info = (("fahrzeug", "interne Nummer, falls genannt"), ("kunde", "Kundenname"),
                      ("alt_datum", "bisheriger Termin (optional)"), ("neu_datum", "neuer Tag (ISO)"),
                      ("neu_uhrzeit", "neue Uhrzeit HH:MM (optional)"))
    direkt_felder = ({"name": "neu_datum", "typ": "date", "label": "Neuer Tag"},
                     {"name": "neu_uhrzeit", "typ": "time", "label": "Uhrzeit"})

    def lies(self, text, k):
        p = super().lies(text, k)
        termine = sprache.finde_termine(text, k.heute)
        if len(termine) >= 2:
            p["alt_datum"] = termine[0].datum.isoformat()
            p["neu_datum"], p["neu_uhrzeit"] = termine[-1].datum.isoformat(), termine[-1].uhrzeit
        elif len(termine) == 1:
            vorne = text[max(0, termine[0].start - 6):termine[0].start].lower()
            if re.search(r"\bvom\s*$|\bvon\s*$", vorne):
                p["alt_datum"] = termine[0].datum.isoformat()
                zeit = sprache.nur_uhrzeit(text[termine[0].ende:])
                if zeit:
                    p["neu_uhrzeit_allein"] = zeit
            else:
                p["neu_datum"], p["neu_uhrzeit"] = termine[0].datum.isoformat(), termine[0].uhrzeit
        else:
            zeit = sprache.nur_uhrzeit(text)
            if zeit:
                p["neu_uhrzeit_allein"] = zeit
        return p

    def antwort(self, p, feld, wert, k):
        if feld == "neu_datum":
            termine = sprache.finde_termine(wert, k.heute)
            if termine:
                p["neu_datum"], p["neu_uhrzeit"] = termine[-1].datum.isoformat(), termine[-1].uhrzeit
            elif sprache.nur_uhrzeit(wert):
                p["neu_uhrzeit_allein"] = sprache.nur_uhrzeit(wert)
            else:
                try:
                    p["neu_datum"] = dt.date.fromisoformat(str(wert)[:10]).isoformat()
                except ValueError:
                    raise AktionsFehler(f"„{wert}“ verstehe ich nicht als Datum – z. B. „28.11. 15 Uhr“ oder "
                                        "„nächsten Freitag 10:30“.") from None
            return
        super().antwort(p, feld, wert, k)

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        u = self.uebergabe(p, k)
        if not p.get("neu_datum") and p.get("neu_uhrzeit_allein"):
            p["neu_datum"], p["neu_uhrzeit"] = u["planned_date"], p.pop("neu_uhrzeit_allein")
        if not p.get("neu_datum"):
            return Rueckfrage(f"Auf wann soll die Übergabe von {self.wer(u)} verschoben werden?", "neu_datum",
                              [option((k.heute + dt.timedelta(days=n)).isoformat(),
                                      sprache.datum_text(k.heute + dt.timedelta(days=n), False, True))
                               for n in range(1, 6)], frei=True, platzhalter="z. B. 28.11. 15 Uhr")
        if not p.get("neu_uhrzeit"):
            p["neu_uhrzeit"] = u.get("uhrzeit")           # nur das Datum genannt: die Uhrzeit bleibt
        return None

    def plane(self, p, k):
        u = self.uebergabe(p, k)
        neu = dt.date.fromisoformat(p["neu_datum"])
        uhr = p.get("neu_uhrzeit")
        alt_text = sprache.termin_text(u.get("planned_date"), u.get("uhrzeit"))
        neu_text = sprache.termin_text(neu, uhr)
        if alt_text == neu_text:
            raise AktionsFehler(f"Die Übergabe von {u.get('customer')} steht schon auf {neu_text}.")
        plan = Plan(f"Übergabe {u.get('customer')} ({u.get('vehicle_internal_id')}) von {alt_text} auf {neu_text} "
                    "verschieben", liste="Auslieferungsliste")
        plan.odin = [{"was": f"Übergabe {u.get('customer')} – Termin", "alt": alt_text, "neu": neu_text},
                     {"was": "Heute & Woche, Ampel, Kalenderwoche", "alt": "", "neu": "werden neu berechnet"}]
        plan.overlay = [{"tabelle": "deliveries", "setze": {"planned_date": neu.isoformat(), "uhrzeit": uhr},
                         "wo": {"id": u["id"]}}]
        z = self.zeile(u, k)
        if z is None:
            plan.nur_vorschau = self.ohne_datei(k)
            return plan
        roh = z.zelle("planned_date")
        wert, fmt = neuer_terminwert(roh.wert, neu, uhr, roh.format)
        plan.datei = z.datei
        plan.zellen = [z.ziel("planned_date", "Termin", alt_text=xl.anzeige(roh.ergebnis) or "leer",
                              neu_wert=wert, neu_text=xl.anzeige(wert), nummernformat=fmt)]
        plan.schluessel = z.schluessel(["customer", "vehicle_internal_id"])
        plan.daten["kw_hinweis"] = _kw_block(z, neu)
        return plan

    def pruefe(self, p, plan, k):
        u = self.uebergabe(p, k)
        hinweise = gehirn.pruefe_termin(k.db, k.jetzt, u, p["neu_datum"], p.get("neu_uhrzeit"), k.einstellungen)
        if plan.daten.get("kw_hinweis"):
            hinweise.append(plan.daten["kw_hinweis"])
        return hinweise


def _kw_block(z, neu: dt.date):
    """Steht die Zeile unter einer KW-Überschrift („KW 48“), die nicht zum neuen Tag passt? Dann ein Hinweis –
    ODIN sortiert die Liste nicht um."""
    rb = z.mappe[z.blatt]
    for nr in sorted((n for n in rb.zeilen if n < z.zeile), reverse=True)[:60]:
        texte = [str(c.ergebnis) for c in rb.zeilen[nr] if isinstance(c.ergebnis, str)]
        for t in texte:
            m = re.match(r"^\s*KW\s*(\d{1,2})\b", t, re.IGNORECASE)
            if m and len([x for x in rb.zeilen[nr] if x.ergebnis not in (None, "")]) <= 2:
                kw = int(m.group(1))
                if kw != neu.isocalendar()[1]:
                    return gehirn.hinweis("info", "Zeile steht im Block einer anderen Woche",
                                          f"Die Zeile steht unter „KW {kw}“, der neue Termin ist in KW "
                                          f"{neu.isocalendar()[1]}. ODIN ändert nur den Termin – die Zeile bei Bedarf "
                                          "in Excel verschieben.", "kw_block")
                return None
    return None


# ------------------------------------------------------------------------------ Status über Farben ---

class FarbAktion(UebergabeAktion):
    """Ein Status der Auslieferungsliste, der in einer Zellfarbe steckt (Legende in vorlagen/farben.json)."""
    feld = ""                       # Spalte (Feld der Zuordnung)
    label = ""
    gruppe = ""                     # Farblegende
    stufen = ()                     # (Bedeutung, Muster im Satz) – die erste ohne Muster ist der Standard
    odin_feld = None                # (Tabelle, Spalte) für die Anzeige in ODIN
    text_neu = None                 # Funktion (bedeutung, k) -> neuer Zelltext oder None

    def lies(self, text, k):
        p = super().lies(text, k)
        t = text.lower()
        for bedeutung, muster in self.stufen:
            if muster and re.search(muster, t):
                p["stufe"] = bedeutung
                break
        return p

    def standard(self):
        return next(b for b, m in self.stufen if m is None) if any(m is None for _, m in self.stufen) else self.stufen[0][0]

    def alt_status(self, u, k):
        return None

    def plane(self, p, k):
        u = self.uebergabe(p, k)
        stufe = p.get("stufe") or self.standard()
        alt = self.alt_status(u, k)
        stufe_text = "erledigt" if stufe == "erledigt_ohne_farbe" else stufe
        alt = "erledigt" if alt == "erledigt_ohne_farbe" else alt
        if alt == stufe_text:
            raise AktionsFehler(f"{self.label} steht bei {u.get('customer')} schon auf „{stufe}“.")
        plan = Plan(f"{self.label} bei {self.wer(u)}: {alt or 'offen'} → {stufe_text}", liste="Auslieferungsliste")
        plan.odin = [{"was": f"{self.label} ({u.get('customer')})", "alt": alt or "offen", "neu": stufe_text},
                     {"was": "Ampel der Übergabe", "alt": "", "neu": "wird neu berechnet"}]
        plan.overlay = self.overlay(u, stufe)
        z = self.zeile(u, k)
        if z is None:
            plan.nur_vorschau = self.ohne_datei(k)
            return plan
        if self.feld not in z.spalten:
            plan.nur_vorschau = f"Die Auslieferungsliste hat keine Spalte für {self.label}."
            return plan
        roh = z.zelle(self.feld)
        neu_hex = farbe(self.gruppe, stufe) if stufe != "erledigt_ohne_farbe" else ""
        zelle = z.ziel(self.feld, self.label, neu_fuellung=neu_hex,
                       alt_text=f"{xl.anzeige(roh.ergebnis) or '–'} · Farbe {alt or 'ohne'}",
                       neu_text=f"Farbe {stufe if stufe != 'erledigt_ohne_farbe' else 'ohne (erledigt)'}")
        neuer_text = self.text_neu(stufe, k, roh.ergebnis) if self.text_neu else None
        if neuer_text is not None and xl.vergleich(neuer_text) != xl.vergleich(roh.ergebnis):
            zelle.neu_wert = neuer_text
            zelle.neu_text = f"„{neuer_text}“ · " + zelle.neu_text
        plan.datei = z.datei
        plan.zellen = [zelle]
        plan.schluessel = z.schluessel(["customer", "vehicle_internal_id"])
        return plan

    def overlay(self, u, stufe):
        if not self.odin_feld:
            return []
        tabelle, spalte, wo = self.odin_feld
        wert = stufe
        return [{"tabelle": tabelle, "setze": {spalte: wert}, "wo": wo(u)}]


def _wo_uebergabe(u):
    return {"id": u["id"]}


def _wo_fahrzeug_auftrag(u):
    return {"vehicle_internal_id": u["vehicle_internal_id"], "art": "Auslieferung"}


class PapiereAktion(FarbAktion):
    kennung = "papiere"
    titel = "Fahrzeugpapiere"
    label = "Fahrzeugpapiere"
    beschreibung = "Papiere (Brief) beim Kunden, bei uns oder im Werk – Farbe der Spalte Fahrzeugpapiere."
    beispiele = ("Papiere von Schou sind beim Kunden", "Brief für DWWA00188 ist bei uns eingetroffen")
    ausloeser = ((r"papiere|fahrzeugbrief|\bbrief\b|zb ?ii|zulassungsbescheinigung", 5),
                 (r"abgeholt|beim kunden|bei uns|eingetroffen|angekommen|ausgehändigt|im werk|da\b|liegen", 2))
    gegen = (r"\bwo sind\b", r"^\s*(sind|ist|haben|hat)\b.*\?\s*$")
    feld, gruppe = "papiere_status", "papiere"
    stufen = (("bei uns", r"bei uns|eingetroffen|angekommen|(sind|ist) da|liegen (hier|bei)|bekommen|erhalten"),
              ("im Werk", r"im werk|beim werk|beim hersteller"),
              ("beim Kunden", None))
    odin_feld = ("deliveries", "papiere_status", _wo_uebergabe)
    direkt_felder = ({"name": "stufe", "typ": "wahl", "label": "Papiere", "optionen": ["beim Kunden", "bei uns", "im Werk"]},)

    def alt_status(self, u, k):
        return u.get("papiere_status")

    @staticmethod
    def _text(stufe, k, alt):
        if stufe == "beim Kunden":
            return f"Brief Kunde {k.heute.day:02d}.{k.heute.month:02d}."
        return None

    text_neu = _text


class ZahlungAktion(FarbAktion):
    kennung = "zahlung"
    titel = "Zahlung eingegangen"
    label = "Zahlung (AB/VDR)"
    recht = "finanzen"
    beschreibung = "Kundenzahlung bezahlt oder angezahlt (mit Betrag) – Farbe der Spalte AB/VDR, Betrag in die Bemerkung."
    beispiele = ("Zahlung von Schou ist eingegangen", "DWWA00188 hat 5.000 € angezahlt")
    ausloeser = ((r"bezahlt|zahlung|angezahlt|anzahlung|überwiesen|ueberwiesen|geld (ist )?(da|eingegangen)|"
                  r"restzahlung", 5),)
    gegen = (r"\bwerk\b|ans werk|tilgung|provision|gutschrift|cashback|ablös|abloes", r"^\s*(ist|sind|hat|wurde|wann)\b.*\?\s*$")
    feld, gruppe = "zahlstatus", "zahlstatus"
    stufen = (("angezahlt", r"angezahlt|anzahlung|teilzahlung|teilweise"), ("bezahlt", None))
    odin_feld = ("deliveries", "zahlstatus", _wo_uebergabe)
    direkt_felder = ({"name": "stufe", "typ": "wahl", "label": "Zahlung", "optionen": ["bezahlt", "angezahlt"]},
                     {"name": "betrag", "typ": "zahl", "label": "Betrag (€, optional)"})

    def lies(self, text, k):
        p = super().lies(text, k)
        betrag = sprache.finde_betrag(text)
        if betrag:
            p["betrag"] = betrag
        return p

    def alt_status(self, u, k):
        return u.get("zahlstatus")

    def plane(self, p, k):
        plan = super().plane(p, k)
        if p.get("betrag") and plan.zellen:
            u = self.uebergabe(p, k)
            z = self.zeile(u, k)
            if "bemerkung" in z.spalten:
                b = z.zelle("bemerkung")
                betrag = p["betrag"] if isinstance(p["betrag"], (int, float)) else sprache.zahl_aus(str(p["betrag"]))
                if betrag is None:
                    raise AktionsFehler("Der Betrag ist keine Zahl.")
                zusatz = f"{(p.get('stufe') or 'bezahlt')} {sprache.eur_text(float(betrag), 0)} am " \
                         f"{sprache.datum_text(k.heute, False)}"
                neu = bemerkung_dazu(b.ergebnis, zusatz)
                plan.zellen.append(z.ziel("bemerkung", "Bemerkung", neu_wert=neu, neu_text=neu))
                plan.odin.append({"was": "Bemerkung", "alt": xl.vergleich(b.ergebnis) or "leer", "neu": neu})
        return plan

    def pruefe(self, p, plan, k):
        u = self.uebergabe(p, k)
        aus = []
        if (p.get("stufe") or "bezahlt") == "bezahlt" and u.get("id") in _bank(k):
            aus.append(gehirn.hinweis("info", "Bank zahlt noch aus",
                                      "Laut Finanzaufstellung hat die Bank noch nicht ausgezahlt – ist das Geld wirklich da?",
                                      "bank"))
        return aus


def _bank(k):
    try:
        from ..cockpit.auswertungen import bank_zahlt_aus
        return bank_zahlt_aus(k.db)
    except Exception:                                   # noqa: BLE001
        return set()


class WerkszahlungAktion(FarbAktion):
    kennung = "werkszahlung"
    titel = "Werkszahlung erledigt"
    label = "Zahlung ans Werk"
    recht = "finanzen"
    beschreibung = "Fahrzeug ans Werk bezahlt – Farbe der Spalte „Werk bezahlt“."
    beispiele = ("Werk für DETKW00142 ist bezahlt", "Werkszahlung DWWA00188 erledigt")
    ausloeser = ((r"werkszahlung|ans werk|an das werk|werk (ist )?bezahlt|werk bezahlt|werksrechnung|"
                  r"\bwerk\b.{0,40}(bezahlt|überwiesen|ueberwiesen)|(bezahlt|überwiesen).{0,20}\b(ans|das) werk\b", 7),)
    gegen = (r"^\s*(ist|sind|wurde|wann)\b.*\?\s*$",)
    feld, gruppe = "werk_farbe", "werkszahlung"
    stufen = (("bezahlt", None),)

    def alt_status(self, u, k):
        return "bezahlt" if u.get("werk_bezahlt") else "offen"

    def overlay(self, u, stufe):
        return [{"tabelle": "deliveries", "setze": {"werk_bezahlt": 1}, "wo": {"id": u["id"]}}]


class TeileAktion(FarbAktion):
    kennung = "teile"
    titel = "Teilestatus"
    label = "Teile (Arbeitskarte)"
    beschreibung = "Teile bestellt, geliefert oder im Fahrzeug – Farbe der Arbeitskartennummer."
    beispiele = ("Teile für Schou sind da", "Teile von DRM00245 sind eingebaut", "Teile für DWWA00188 bestellt")
    ausloeser = ((r"\bteile\b|teil (ist|sind)|material", 4),
                 (r"\bda\b|geliefert|eingetroffen|angekommen|eingebaut|im fahrzeug|bestellt|verbaut", 3))
    gegen = (r"preis|kostet|einbaupreis|montagezeit|arbeitszeit|lager|bestand", r"^\s*(sind|ist|wann|welche)\b.*\?\s*$")
    feld, gruppe = "teilestatus", "teile"
    stufen = (("alle im Fahrzeug", r"eingebaut|im fahrzeug|verbaut|montiert"),
              ("teilweise geliefert", r"teilweise|ein teil|teils"),
              ("bestellt", r"\bbestellt"),
              ("geliefert", None))
    odin_feld = ("werkstattauftraege", "teilestatus", _wo_fahrzeug_auftrag)
    direkt_felder = ({"name": "stufe", "typ": "wahl", "label": "Teile",
                      "optionen": ["bestellt", "teilweise geliefert", "geliefert", "alle im Fahrzeug"]},)

    def alt_status(self, u, k):
        r = k.db.execute("SELECT teilestatus FROM werkstattauftraege WHERE vehicle_internal_id = ? AND art = "
                         "'Auslieferung' ORDER BY id LIMIT 1", (u.get("vehicle_internal_id"),)).fetchone()
        return r["teilestatus"] if r else None


class TuevAktion(FarbAktion):
    kennung = "tuev"
    titel = "TÜV erledigt"
    label = "TÜV"
    beschreibung = "TÜV vor Übergabe erledigt – die rote Markierung im Feld neu/gebraucht wird entfernt."
    beispiele = ("TÜV für DWWA00188 ist erledigt", "Hauptuntersuchung J&A Automobile gemacht")
    ausloeser = ((r"\btüv\b|\btuev\b|hauptuntersuchung|\bhu\b", 6), (r"erledigt|gemacht|durch|bestanden|neu", 1))
    gegen = (r"^\s*(ist|wann|braucht)\b.*\?\s*$",)
    feld, gruppe = "tuev_farbe", "tuev"
    stufen = (("erledigt_ohne_farbe", None),)

    def alt_status(self, u, k):
        return "fällig" if u.get("tuev_faellig") else "erledigt_ohne_farbe"

    def overlay(self, u, stufe):
        return [{"tabelle": "deliveries", "setze": {"tuev_faellig": 0}, "wo": {"id": u["id"]}}]


class TankAktion(FarbAktion):
    kennung = "tank"
    titel = "Getankt"
    label = "Tanken"
    beschreibung = "Fahrzeug fertig getankt – Farbe und Text der Spalte Tanken."
    beispiele = ("DETKW00142 ist getankt",)
    ausloeser = ((r"getankt|tanken|vollgetankt", 6),)
    gegen = (r"^\s*(ist|wann)\b.*\?\s*$",)
    feld, gruppe = "tankstatus", "tank"
    stufen = (("in Arbeit", r"in arbeit|angefangen|läuft"), ("fertig", None))
    odin_feld = ("werkstattauftraege", "tankstatus", _wo_fahrzeug_auftrag)

    def alt_status(self, u, k):
        r = k.db.execute("SELECT tankstatus FROM werkstattauftraege WHERE vehicle_internal_id = ? AND art = "
                         "'Auslieferung' ORDER BY id LIMIT 1", (u.get("vehicle_internal_id"),)).fetchone()
        return r["tankstatus"] if r else None

    @staticmethod
    def _text(stufe, k, alt):
        return "fertig getankt" if stufe == "fertig" else "in Arbeit tanken"

    text_neu = _text


EINBAU_SPALTEN = {"AHK starr": ("einbau_ahks", r"ahk ?starr|starre|\bahks\b"),
                  "AHK abnehmbar": ("einbau_ahka", r"abnehmbar|\bahka\b"),
                  "Unterboden & Hohlraum": ("einbau_ubhk", r"unterboden|hohlraum|\bubhk\b"),
                  "Sondereinbau": ("einbau_son", r"sonder|\bson\b")}


class EinbauAktion(FarbAktion):
    kennung = "einbau"
    titel = "Einbau erledigt"
    label = "Einbau"
    beschreibung = "Einbauten (AHK starr/abnehmbar, Unterboden, Sondereinbau) erledigt oder beim Einbaupartner."
    beispiele = ("AHK bei DETKW00142 ist eingebaut", "Unterbodenschutz Schou erledigt")
    ausloeser = ((r"\bahk|anhängerkupplung|anhaengerkupplung|unterboden|hohlraum|sondereinbau|einbau\b", 5),
                 (r"erledigt|eingebaut|fertig|gemacht|montiert|einbaupartner", 2))
    gegen = (r"preis|kostet|arbeitszeit|montagezeit|lohn", r"^\s*(ist|wann|welche)\b.*\?\s*$")
    gruppe = "einbau"
    stufen = (("beim Einbaupartner", r"einbaupartner|beim partner|weggebracht"), ("erledigt", None))
    direkt_felder = ({"name": "position", "typ": "wahl", "label": "Einbau", "optionen": list(EINBAU_SPALTEN)},
                     {"name": "stufe", "typ": "wahl", "label": "Stand", "optionen": ["erledigt", "beim Einbaupartner", "offen"]})

    def lies(self, text, k):
        p = super().lies(text, k)
        t = text.lower()
        for pos, (_, muster) in EINBAU_SPALTEN.items():
            if re.search(muster, t):
                p["position"] = pos
                break
        if "position" not in p and re.search(r"\bahk\b|anhängerkupplung|anhaengerkupplung", t):
            p["position_ahk"] = True
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if p.get("position") in EINBAU_SPALTEN:
            return None
        u = self.uebergabe(p, k)
        offen = [r["position"] for r in k.db.execute(
            "SELECT position FROM einbauten WHERE vehicle_internal_id = ? AND status <> 'erledigt'",
            (u["vehicle_internal_id"],))]
        if p.get("position_ahk"):
            offen = [o for o in offen if o.startswith("AHK")] or ["AHK starr", "AHK abnehmbar"]
        if len(offen) == 1:
            p["position"] = offen[0]
            return None
        return Rueckfrage(f"Welcher Einbau bei {self.wer(u)}?", "position",
                          [option(pos, pos) for pos in (offen or list(EINBAU_SPALTEN))])

    def plane(self, p, k):
        self.feld = EINBAU_SPALTEN[p["position"]][0]
        self.label = p["position"]
        return super().plane(p, k)

    def alt_status(self, u, k):
        r = k.db.execute("SELECT status FROM einbauten WHERE vehicle_internal_id = ? AND position = ?",
                         (u["vehicle_internal_id"], self.label)).fetchone()
        return r["status"] if r else None

    def overlay(self, u, stufe):
        return [{"tabelle": "einbauten", "setze": {"status": stufe},
                 "wo": {"vehicle_internal_id": u["vehicle_internal_id"], "position": self.label}}]


# --------------------------------------------------------------------------------------- Texte ---

def _text_aus_satz(text: str):
    m = re.search(r"[„\"“»](.+?)[“\"”«]", text)
    if m:
        return m.group(1).strip()
    m = re.search(r"(?:bemerkung|notiz|vermerk|anmerkung|hinweis)\b[^:]{0,40}[:–]\s*(.+)$", text, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None


class BemerkungAktion(UebergabeAktion):
    kennung = "bemerkung"
    titel = "Bemerkung ergänzen"
    beschreibung = "Text an die Bemerkung der Übergabe anhängen (der bisherige Text bleibt)."
    beispiele = ("Bemerkung bei Schou: Gutschein eingelöst", "Notiz für DRM00245: „Kunde bringt Fahrradträger mit“")
    ausloeser = ((r"bemerkung|notiz|vermerk|anmerkung", 6), (r"schreib|ergänz|ergaenz|trag", 2))
    gegen = (r"^\s*(was|welche|steht)\b.*\?\s*$",)
    direkt_felder = ({"name": "text", "typ": "text", "label": "Bemerkung"},)

    def lies(self, text, k):
        p = super().lies(text, k)
        t = _text_aus_satz(text)
        if t:
            p["text"] = t[:300]
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if not (p.get("text") or "").strip():
            return Rueckfrage(f"Was soll in die Bemerkung von {self.wer(self.uebergabe(p, k))}?", "text", frei=True,
                              platzhalter="Text der Bemerkung")
        return None

    def plane(self, p, k):
        u = self.uebergabe(p, k)
        neu = bemerkung_dazu(u.get("bemerkung"), p["text"].strip())
        plan = Plan(f"Bemerkung bei {self.wer(u)} ergänzen: „{p['text'].strip()}“", liste="Auslieferungsliste")
        plan.odin = [{"was": "Bemerkung", "alt": u.get("bemerkung") or "leer", "neu": neu}]
        plan.overlay = [{"tabelle": "deliveries", "setze": {"bemerkung": neu}, "wo": {"id": u["id"]}}]
        z = self.zeile(u, k)
        if z is None:
            plan.nur_vorschau = self.ohne_datei(k)
            return plan
        if "bemerkung" not in z.spalten:
            plan.nur_vorschau = "Die Auslieferungsliste hat keine Spalte „Bemerkung“."
            return plan
        roh = z.zelle("bemerkung")
        neu = bemerkung_dazu(roh.ergebnis, p["text"].strip())
        plan.datei = z.datei
        plan.zellen = [z.ziel("bemerkung", "Bemerkung", neu_wert=neu, neu_text=neu)]
        plan.schluessel = z.schluessel(["customer", "vehicle_internal_id"])
        return plan


class VerkaeuferAktion(UebergabeAktion):
    kennung = "verkaeufer"
    titel = "Verkäufer ändern"
    beschreibung = "Wer übergibt: steckt in der Schriftfarbe des Kundennamens (Legende „verkaeufer“)."
    beispiele = ("Übergabe Schou macht Uwe", "Verkäufer bei DWWA00188 ist Jan")
    ausloeser = ((r"verkäufer|verkaeufer|übergibt|uebergibt|macht die übergabe|zuständig", 5),
                 (r"übergabe|uebergabe|auslieferung", 1))
    gegen = (r"^\s*(wer|welcher)\b.*\?\s*$",)

    def lies(self, text, k):
        p = super().lies(text, k)
        for name in legende("verkaeufer"):
            if re.search(rf"\b{re.escape(name.lower())}\b", text.lower()):
                p["verkaeufer"] = name
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if p.get("verkaeufer") not in legende("verkaeufer"):
            return Rueckfrage("Wer soll die Übergabe machen?", "verkaeufer",
                              [option(n, n) for n in legende("verkaeufer")])
        return None

    def plane(self, p, k):
        u = self.uebergabe(p, k)
        if u.get("verkaeufer") == p["verkaeufer"]:
            raise AktionsFehler(f"{p['verkaeufer']} ist schon eingetragen.")
        plan = Plan(f"Verkäufer bei {self.wer(u)}: {u.get('verkaeufer') or 'offen'} → {p['verkaeufer']}",
                    liste="Auslieferungsliste")
        plan.odin = [{"was": "Verkäufer", "alt": u.get("verkaeufer") or "–", "neu": p["verkaeufer"]}]
        plan.overlay = [{"tabelle": "deliveries", "setze": {"verkaeufer": p["verkaeufer"]}, "wo": {"id": u["id"]}}]
        z = self.zeile(u, k)
        if z is None:
            plan.nur_vorschau = self.ohne_datei(k)
            return plan
        plan.datei = z.datei
        plan.zellen = [z.ziel("customer", "Name (Schriftfarbe = Verkäufer)",
                              alt_text=f"Schrift {u.get('verkaeufer') or 'ohne'}", neu_text=f"Schrift {p['verkaeufer']}",
                              neu_schrift=farbe("verkaeufer", p["verkaeufer"]))]
        plan.schluessel = z.schluessel(["vehicle_internal_id"])
        return plan

    def pruefe(self, p, plan, k):
        u = self.uebergabe(p, k)
        abw = gehirn._verkaeufer_abwesend(k.db, p["verkaeufer"], gehirn._tag(u["planned_date"])) if u.get("planned_date") else None
        if abw:
            return [gehirn.hinweis("warnung", f"{p['verkaeufer']} ist an dem Tag nicht da",
                                   f"{abw['mitarbeiter']}: {abw['art'] or 'Urlaub'} am {sprache.datum_text(u['planned_date'])}.",
                                   "urlaub")]
        return []


class ZulassungAktion(UebergabeAktion):
    kennung = "zulassung"
    titel = "Zulassung erledigt"
    beschreibung = ("Fahrzeug ist zugelassen: die Zulassungsfrist verschwindet aus ODIN (Vermerk), in der "
                    "Auslieferungsliste kommt „zugelassen am …“ in die Bemerkung.")
    beispiele = ("DETKW00142 ist zugelassen", "Zulassung Schou erledigt")
    ausloeser = ((r"zugelassen|zulassung", 6), (r"erledigt|gemacht|durch|ist", 1))
    gegen = (r"frist|bis wann|^\s*(ist|wann|muss)\b.*\?\s*$", r"erinner")

    def schritt(self, p, k):
        if not p.get("uebergabe_id") and p.get("fid"):
            if not uebergaben_finden(k.db, k.satz, p):
                p["nur_vermerk"] = True
                return None
        return super().schritt(p, k)

    def plane(self, p, k):
        fid = p.get("fid")
        u = None if p.get("nur_vermerk") else self.uebergabe(p, k)
        fid = (u or {}).get("vehicle_internal_id") or fid
        frist = k.db.execute("SELECT frist FROM zulassungsfristen WHERE vehicle_internal_id = ?", (fid,)).fetchone()
        zusatz = f"zugelassen am {sprache.datum_text(k.heute, False)}"
        plan = Plan(f"{fid} als zugelassen vermerken", liste="Auslieferungsliste")
        plan.odin = [{"was": f"Zulassungsfrist {fid}", "alt": sprache.datum_text(frist["frist"]) if frist else "keine",
                      "neu": "erledigt (Vermerk in ODIN)"}]
        plan.daten = {"vermerk": {"art": "zulassung_erledigt", "bezug": fid, "datum": k.heute.isoformat(),
                                  "text": zusatz}}
        if u is None:
            return plan
        z = self.zeile(u, k)
        if z is not None and "bemerkung" in z.spalten:
            roh = z.zelle("bemerkung")
            neu = bemerkung_dazu(roh.ergebnis, zusatz)
            plan.datei = z.datei
            plan.zellen = [z.ziel("bemerkung", "Bemerkung", neu_wert=neu, neu_text=neu)]
            plan.schluessel = z.schluessel(["customer", "vehicle_internal_id"])
            plan.odin.append({"was": "Bemerkung", "alt": u.get("bemerkung") or "leer", "neu": neu})
            plan.overlay = [{"tabelle": "deliveries", "setze": {"bemerkung": neu}, "wo": {"id": u["id"]}}]
        return plan

    def odin_ausfuehren(self, plan, k):
        return {"vermerk": k.dienst.vermerk_anlegen(plan.daten["vermerk"])}

    def odin_rueckgaengig(self, eintrag, k):
        vid = (eintrag.get("odin_ergebnis") or {}).get("vermerk")
        if vid:
            k.dienst.vermerk_entfernen(vid)


AKTIONEN = [TerminVerschieben(), PapiereAktion(), ZahlungAktion(), WerkszahlungAktion(), TeileAktion(), TuevAktion(),
            TankAktion(), EinbauAktion(), BemerkungAktion(), VerkaeuferAktion(), ZulassungAktion()]
