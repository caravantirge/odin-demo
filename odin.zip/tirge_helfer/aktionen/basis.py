"""
Bausteine der Aktionen: Kontext, Rückfrage, Plan und die Basisklassen.

Ablauf jeder Aktion (siehe dienst.py):
  lies(text)        – Parameter aus dem Satz (Datum, Dauer, Betrag, Fahrzeug …)
  schritt(p)        – Ziel auflösen (welche Übergabe, welches Teil …); fehlt etwas oder ist es mehrdeutig: Rückfrage
  plane(p)          – Vorschau: welche Datei, welches Blatt, welche Zelle, alt → neu; dazu ODIN-Änderungen
  pruefe(p, plan)   – Hinweise des Gehirns (gehirn.py)
  ausfuehren        – über den Dienst: Excel-Zellen mit dem gewählten Schreibweg, ODIN-Teil über die Aktion
  rueckgaengig      – genauso, umgekehrt
"""

import datetime as dt
import os
import re
from dataclasses import dataclass, field

from ..cockpit.importer import extrahiere_id, lade_mapping
from ..cockpit.excel import legende
from ..cockpit.db import normalize_internal_id
from . import excel as xl
from . import sprache


class AktionsFehler(Exception):
    """Meldung für Menschen."""


@dataclass
class Kontext:
    db: object
    heute: dt.date
    jetzt: dt.datetime
    quellen: dict = field(default_factory=dict)      # Liste -> Pfad
    finanzen: bool = False
    im_web: bool = False
    ich: str = ""                                    # Personen-ID
    ich_name: str = ""
    einstellungen: dict = field(default_factory=dict)
    dienst: object = None                            # Aktionsdienst (Zugriff auf Cockpit, Projekte, Urlaub …)
    beispiel: bool = False
    satz: str = ""


@dataclass
class Rueckfrage:
    frage: str
    feld: str
    optionen: list = field(default_factory=list)     # [{"wert", "text", "hinweis"}]
    frei: bool = False                               # freie Antwort erlaubt (z. B. Datum eintippen)
    platzhalter: str = ""

    def als_dict(self) -> dict:
        return {"frage": self.frage, "feld": self.feld, "optionen": self.optionen, "frei": self.frei,
                "platzhalter": self.platzhalter}


def option(wert, text, hinweis="") -> dict:
    return {"wert": str(wert), "text": text, "hinweis": hinweis}


@dataclass
class Plan:
    zusammenfassung: str
    datei: str = ""                                  # Excel-Datei (Pfad) – leer bei reinen ODIN-Aktionen
    liste: str = ""                                  # Name der Liste („Auslieferungsliste“)
    zellen: list = field(default_factory=list)       # [xl.Zelle]
    schluessel: list = field(default_factory=list)   # [xl.Zelle] nur zum Prüfen (alt = erwartet)
    odin: list = field(default_factory=list)         # [{"was", "alt", "neu"}] – Anzeige der ODIN-Seite
    overlay: list = field(default_factory=list)      # [{"tabelle", "setze", "wo"}] – ODIN sofort, bis die Datei nachzieht
    hinweise: list = field(default_factory=list)
    nur_vorschau: str = ""                           # Grund, warum nicht ausgeführt werden kann
    daten: dict = field(default_factory=dict)        # für den ODIN-Teil der Aktion


# ------------------------------------------------------------------------------------- Basisklasse ---

class Aktion:
    kennung = ""
    titel = ""
    bereich = ""
    beschreibung = ""
    beispiele = ()
    recht = None                  # None oder "finanzen"
    im_browser = False            # darf im Browser (Handy/Tablet) ausgeführt werden?
    ausloeser = ()                # (Muster, Punkte)
    gegen = ()                    # Muster, die diese Aktion ausschließen
    parameter_info = ()           # [(Name, Beschreibung)] – für Variante B (KI) und die Doku
    direkt_felder = ()            # Formularfelder für Knöpfe (Oberfläche)
    braucht_fahrzeug = False      # nur sinnvoll, wenn ein Fahrzeug genannt ist (sonst zählt die Aktion weniger)

    def punkte(self, text: str) -> int:
        t = text.lower()
        if any(re.search(g, t) for g in self.gegen):
            return 0
        return sum(p for m, p in self.ausloeser if re.search(m, t))

    def lies(self, text: str, k: Kontext) -> dict:
        return {}

    def schritt(self, p: dict, k: Kontext):
        return None

    def antwort(self, p: dict, feld: str, wert: str, k: Kontext):
        """Antwort auf eine Rückfrage übernehmen."""
        p[feld] = wert

    def plane(self, p: dict, k: Kontext) -> Plan:
        raise NotImplementedError

    def pruefe(self, p: dict, plan: Plan, k: Kontext) -> list:
        return []

    # ODIN-Teil (Excel schreibt der Dienst)
    def odin_ausfuehren(self, plan: Plan, k: Kontext) -> dict:
        return {}

    def odin_rueckgaengig(self, eintrag: dict, k: Kontext):
        pass

    def katalog(self) -> dict:
        return {"kennung": self.kennung, "titel": self.titel, "bereich": self.bereich,
                "beschreibung": self.beschreibung, "beispiele": list(self.beispiele),
                "recht": self.recht, "im_browser": self.im_browser,
                "parameter": [{"name": n, "beschreibung": b} for n, b in self.parameter_info],
                "felder": [dict(f) for f in self.direkt_felder]}


# ----------------------------------------------------------------------------- Excel-Zeilen finden ---

LISTEN_NAMEN = {"auslieferungen": "Auslieferungsliste", "bestandsliste": "Bestandsliste",
                "finanzierungen": "Finanzaufstellung", "teilepreise": "Teileliste"}


def quelle(k: Kontext, art: str) -> str:
    pfad = (k.quellen or {}).get(art) or ""
    return pfad if pfad and os.path.isfile(pfad) else ""


def ohne_datei_grund(k: Kontext, art: str) -> str:
    name = LISTEN_NAMEN.get(art, art)
    if k.beispiel:
        return (f"ODIN läuft mit Beispieldaten – es ist keine {name} eingebunden. Die Vorschau zeigt, was passieren "
                "würde; ausgeführt wird erst mit echten Listen (Datenquellen).")
    return f"Die {name} ist nicht eingebunden oder gerade nicht erreichbar (Datenquellen prüfen, OneDrive gestartet?)."


def _gleich(a, b) -> bool:
    return sprache.einfach(xl.vergleich(a)) == sprache.einfach(xl.vergleich(b))


@dataclass
class ExcelZeile:
    datei: str
    blatt: str
    zeile: int
    spalten: dict                     # feld -> Spalte (1-basiert)
    mappe: dict                       # Blattname -> RohBlatt

    def zelle(self, feld: str):
        sp = self.spalten.get(feld)
        return self.mappe[self.blatt].zelle(self.zeile, sp) if sp else None

    def ziel(self, feld: str, label: str, **werte) -> xl.Zelle:
        sp = self.spalten[feld]
        roh = self.mappe[self.blatt].zelle(self.zeile, sp)
        z = xl.Zelle(datei=self.datei, blatt=self.blatt, zeile=self.zeile, spalte=sp, feld=feld, label=label,
                     alt_wert=roh.wert, alt_fuellung=roh.fuellung, alt_schrift=roh.schrift,
                     alt_text=xl.anzeige(roh.ergebnis) or "leer")
        for k, v in werte.items():
            setattr(z, k, v)
        return z

    def schluessel(self, felder) -> list:
        aus = []
        for f in felder:
            sp = self.spalten.get(f)
            if not sp:
                continue
            roh = self.mappe[self.blatt].zelle(self.zeile, sp)
            aus.append(xl.Zelle(datei=self.datei, blatt=self.blatt, zeile=self.zeile, spalte=sp, feld=f,
                                label=f, alt_wert=roh.wert))
        return aus


def finde_listenzeile(pfad: str, art: str, passt, hinweis_blatt=None, hinweis_zeile=None) -> ExcelZeile:
    """Zeile einer Liste mit Zuordnung (mappings/*.json), für die passt(werte_je_feld) wahr ist. Erst an der
    gemerkten Stelle (Blatt/Zeile vom Einlesen), sonst in allen Blättern. Mehrdeutig oder nicht gefunden: Fehler."""
    mapping = lade_mapping(art)
    mappe = xl.lies_mappe(pfad)
    kandidaten = []
    for name, rb in mappe.items():
        kopfzeile, spalten = rb.kopf(mapping)
        if kopfzeile is None or len(spalten) < 2:
            continue
        reihen = [hinweis_zeile] if (name == hinweis_blatt and hinweis_zeile in rb.zeilen) else []
        reihen += [n for n in sorted(rb.zeilen) if n > kopfzeile and n != hinweis_zeile]
        for nr in reihen:
            werte = {f: rb.zelle(nr, sp).ergebnis for f, sp in spalten.items()}
            if passt(werte):
                kandidaten.append(ExcelZeile(pfad, name, nr, spalten, mappe))
                if name == hinweis_blatt and nr == hinweis_zeile:
                    return kandidaten[-1]
    if not kandidaten:
        raise AktionsFehler(f"In der {LISTEN_NAMEN.get(art, art)} finde ich die Zeile nicht (mehr) – "
                            "vielleicht hat sie jemand geändert. Bitte neu einlesen und noch einmal versuchen.")
    if len(kandidaten) > 1:
        raise AktionsFehler(f"In der {LISTEN_NAMEN.get(art, art)} passen {len(kandidaten)} Zeilen – ODIN ändert "
                            "lieber nichts. Bitte die Zeile in Excel eindeutig machen (z. B. interne Nummer eintragen).")
    return kandidaten[0]


def id_gleich(wert, iid) -> bool:
    if not iid or wert in (None, ""):
        return False
    gefunden = extrahiere_id(str(wert)) or normalize_internal_id(str(wert))
    return gefunden == iid


def farbe(gruppe: str, bedeutung: str) -> str:
    werte = legende(gruppe)
    if bedeutung not in werte:
        raise AktionsFehler(f"Die Farblegende „{gruppe}“ kennt „{bedeutung}“ nicht (vorlagen/farben.json).")
    return werte[bedeutung]


def neuer_terminwert(alt, datum: dt.date, uhrzeit, format_alt=None):
    """Neuer Wert für die Terminzelle – in derselben Form wie der alte: Datum bleibt Datum (mit Uhrzeit, wenn es eine
    gibt), Text („Di. 13.10. 10:30“) bleibt Text im selben Muster. (Wert, Zahlenformat)"""
    if isinstance(alt, str) and alt.strip() and not alt.startswith("="):
        t = alt.strip()
        wochentag = bool(re.match(r"^[A-Za-zÄÖÜäöü]{2}\.?\s", t))
        mit_jahr = bool(re.search(r"\d{1,2}\.\d{1,2}\.\d{2,4}", t))
        text = (sprache.WOCHENTAG_KURZ[datum.weekday()] + " " if wochentag else "") + \
            f"{datum.day:02d}.{datum.month:02d}." + (str(datum.year) if mit_jahr else "")
        return (text + (f" {uhrzeit}" if uhrzeit else "")), None
    h, m = (int(x) for x in (uhrzeit or "00:00").split(":"))
    wert = dt.datetime.combine(datum, dt.time(h, m))
    if uhrzeit:
        fmt = format_alt if format_alt and re.search(r"h", str(format_alt), re.I) else "DD.MM.YYYY hh:mm"
    else:
        fmt = format_alt if format_alt and format_alt != "General" else "DD.MM.YYYY"
    return wert, fmt


def bemerkung_dazu(alt, zusatz: str) -> str:
    alt = xl.vergleich(alt)
    return f"{alt} · {zusatz}" if alt else zusatz
