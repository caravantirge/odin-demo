"""
Live: eingebundene Excel-Listen (und ODINs gemeinsamer Speicher) im Hintergrund beobachten.

Alle 3 Sekunden vergleicht ODIN Änderungszeit und Größe der Dateien. Ändert sich etwas, wartet es, bis die Datei
zweimal hintereinander gleich aussieht (OneDrive schreibt große Dateien in Stücken) und liest dann neu ein. Die
Oberfläche fragt alle paar Sekunden nach der Version (live_stand) und zeichnet sich neu, ohne dass jemand klickt;
im Fenster stößt ODIN sie zusätzlich direkt an.
"""

import threading
import time

INTERVALL = 3.0
STABIL = 2                         # so oft hintereinander gleich, bevor ODIN neu einliest


class Ueberwachung:
    def __init__(self, cockpit, protokoll=None, intervall: float = INTERVALL, uhr=time.time):
        self.cockpit = cockpit
        self._log = protokoll or (lambda text: None)
        self.intervall = intervall
        self._uhr = uhr
        self.version = 1
        self._stand = None
        self._kandidat = None
        self._gleich = 0
        self._stopp = threading.Event()
        self._thread = None
        self.fehler = ""
        self.zuletzt_geprueft = 0.0

    def start(self):
        if self._thread is not None:
            return
        try:
            self._stand = self.cockpit.quellen_stand()
        except Exception:                                  # noqa: BLE001
            self._stand = None
        self._thread = threading.Thread(target=self._lauf, name="ODIN-Live", daemon=True)
        self._thread.start()

    def stopp(self):
        self._stopp.set()

    def anstossen(self):
        """Nach einer eigenen Änderung: neue Version, ohne auf die nächste Runde zu warten."""
        try:
            self._stand = self.cockpit.quellen_stand()
        except Exception:                                  # noqa: BLE001
            pass
        self.version += 1

    def pruefe(self) -> bool:
        """Eine Runde (auch für Tests): True, wenn neu eingelesen wurde."""
        self.zuletzt_geprueft = self._uhr()
        try:
            jetzt = self.cockpit.quellen_stand()
        except Exception as e:                             # noqa: BLE001 – OneDrive kurz weg: nächste Runde
            self.fehler = str(e)[:200]
            return False
        if jetzt == self._stand:
            self._kandidat, self._gleich = None, 0
            return False
        if jetzt != self._kandidat:                        # noch in Bewegung: merken und abwarten
            self._kandidat, self._gleich = jetzt, 1
            return False
        self._gleich += 1
        if self._gleich < STABIL:
            return False
        try:
            self.cockpit.daten()                           # liest nur, was sich geändert hat
            self.fehler = ""
        except Exception as e:                             # noqa: BLE001
            self.fehler = str(e)[:200]
            self._log(f"Live: Neu einlesen fehlgeschlagen: {e!r}")
            return False
        self._stand, self._kandidat, self._gleich = jetzt, None, 0
        self.version += 1
        rueckruf = getattr(self.cockpit, "bei_neuen_daten", None)
        if callable(rueckruf):
            try:
                rueckruf()
            except Exception:                              # noqa: BLE001 – Fenster zu o. Ä.
                pass
        return True

    def _lauf(self):
        while not self._stopp.wait(self.intervall):
            self.pruefe()

    def stand(self) -> dict:
        alter = max(0, int(self._uhr() - (self.cockpit._geladen_um or self._uhr())))
        return {"version": self.version, "alter": alter, "fehler": self.fehler,
                "beobachtet": self._thread is not None and self._thread.is_alive()}
