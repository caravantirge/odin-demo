"""
In Excel-Listen schreiben – sicher und nachvollziehbar.

Drei Wege, in dieser Reihenfolge (der erste, der kann, schreibt):

1. Excel Online über Microsoft Graph (`GraphSchreiber`): ändert die Zellen direkt in der SharePoint-/OneDrive-Datei
   über eine Arbeitsmappen-Sitzung. Gleichzeitiges Bearbeiten (Co-Authoring) bleibt möglich, Excel rechnet Formeln
   selbst. Braucht die Microsoft-Anmeldung mit der Berechtigung „Files.ReadWrite.All“.
2. Excel auf diesem Rechner (`ComSchreiber`, nur Windows mit pywin32 und installiertem Excel): öffnet die per
   OneDrive synchronisierte Datei unsichtbar, ändert Zellen, speichert. Formeln und Formate bleiben, Excel rechnet.
   Ist die Datei gerade offen (Sperrdatei „~$…“ oder Excel öffnet sie nur schreibgeschützt), schreibt ODIN nicht.
3. openpyxl (`OpenpyxlSchreiber`) als enger Rückfall: nur Zellen ohne Formel, auf die sich keine Formel bezieht,
   und nur in Mappen ohne Grafiken, Formen, Pivot-Tabellen oder Makros (die gingen beim Speichern verloren).
   openpyxl speichert Formeln ohne Ergebnis – ODIN trägt die zuvor gespeicherten Ergebnisse wieder ein und lässt
   Excel beim nächsten Öffnen alles neu rechnen.

Vor jedem Schreiben: Sicherungskopie (_ODIN/Sicherungen/<datei>/<zeitstempel>.xlsx, die letzten 20 bleiben) und
Prüfung, dass die Zielzeile noch die erwartete ist (Schlüsselzellen und alte Werte). Sonst: „Liste hat sich geändert“.
"""

import copy
import datetime as dt
import glob
import os
import re
import shutil
import sys
import zipfile
from dataclasses import asdict, dataclass, field

from openpyxl import load_workbook
from openpyxl.styles import Color, PatternFill
from openpyxl.utils import column_index_from_string, get_column_letter

from ..cockpit.excel import (Farbleser, finde_kopfzeile, alle_aliase, normalisiere, ordne_spalten_zu, zu_text)

SICHERUNGEN_BEHALTEN = 20
MAX_ZEILEN = 60000
UNVERAENDERT = "__unveraendert__"
EXCEL_NULL = dt.datetime(1899, 12, 30)


class SchreibFehler(Exception):
    """Meldung für Menschen: warum ODIN nicht geschrieben hat."""


class ListeGeaendert(SchreibFehler):
    """Die Zielzeile ist nicht mehr die erwartete."""


class DateiGesperrt(SchreibFehler):
    """Die Datei ist gerade geöffnet bzw. gesperrt."""


# ----------------------------------------------------------------------------------------- Werte ---

def roh_speichern(v):
    """Zellwert für JSON (Protokoll, Entwurf)."""
    if isinstance(v, dt.datetime):
        return {"t": "dt", "v": v.isoformat(timespec="minutes")}
    if isinstance(v, dt.date):
        return {"t": "d", "v": v.isoformat()}
    if isinstance(v, dt.time):
        return {"t": "z", "v": v.strftime("%H:%M")}
    return v


def roh_laden(v):
    if isinstance(v, dict) and "t" in v:
        if v["t"] == "dt":
            return dt.datetime.fromisoformat(v["v"])
        if v["t"] == "d":
            return dt.date.fromisoformat(v["v"])
        if v["t"] == "z":
            h, m = v["v"].split(":")
            return dt.time(int(h), int(m))
    return v


def vergleich(v, wie=None) -> str:
    """Zellwerte vergleichbar machen – egal ob aus openpyxl, Excel (COM) oder Excel Online (Seriennummern)."""
    if isinstance(wie, (dt.date, dt.datetime)) and isinstance(v, (int, float)) and not isinstance(v, bool):
        v = EXCEL_NULL + dt.timedelta(days=float(v))
        v = (v + dt.timedelta(seconds=30)).replace(second=0, microsecond=0)     # Seriennummern sind nie ganz genau
    if hasattr(v, "year") and hasattr(v, "hour") and not isinstance(v, dt.datetime):   # pywintypes.datetime
        v = dt.datetime(v.year, v.month, v.day, v.hour, v.minute)
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d") if (v.hour, v.minute) == (0, 0) else v.strftime("%Y-%m-%d %H:%M")
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else f"{v:.6f}".rstrip("0").rstrip(".")
    if isinstance(v, int):
        return str(v)
    return " ".join(str(v or "").split())


def anzeige(v) -> str:
    """Zellwert für Menschen: 26.11.2026 10:00, 1.234,5 – Text bleibt Text."""
    if isinstance(v, dt.datetime):
        return v.strftime("%d.%m.%Y") + ("" if (v.hour, v.minute) == (0, 0) else v.strftime(" %H:%M"))
    if isinstance(v, dt.date):
        return v.strftime("%d.%m.%Y")
    if isinstance(v, float) and not v.is_integer():
        return f"{v:.2f}".rstrip("0").rstrip(".").replace(".", ",")
    return vergleich(v)


def ist_formel(v) -> bool:
    return isinstance(v, str) and v.startswith("=")


def hex_farbe(f):
    return None if not f else str(f).lstrip("#").upper()[-6:]


# ----------------------------------------------------------------------------------- Geplante Zelle ---

@dataclass
class Zelle:
    """Eine geplante Änderung an einer Zelle. Was nicht geändert wird, bleibt UNVERAENDERT."""
    datei: str
    blatt: str
    zeile: int
    spalte: int                       # 1-basiert
    feld: str = ""
    label: str = ""
    alt_text: str = ""                # so zeigt es die Vorschau
    neu_text: str = ""
    alt_wert: object = None           # roher Wert (Formel als „=…“)
    neu_wert: object = UNVERAENDERT
    alt_fuellung: str = None          # „RRGGBB“ oder None
    neu_fuellung: object = UNVERAENDERT   # „RRGGBB“, "" = Füllung entfernen
    alt_schrift: str = None
    neu_schrift: object = UNVERAENDERT
    nummernformat: str = None
    abhaengig: list = field(default_factory=list)    # Formelzellen, die auf diese Zelle zeigen (nur Anzeige)

    @property
    def adresse(self) -> str:
        return f"{get_column_letter(self.spalte)}{self.zeile}"

    def als_dict(self) -> dict:
        d = asdict(self)
        d["adresse"] = self.adresse
        d["alt_wert"], d["neu_wert"] = roh_speichern(self.alt_wert), roh_speichern(self.neu_wert)
        return d

    @classmethod
    def aus_dict(cls, d: dict) -> "Zelle":
        felder = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        z = cls(**felder)
        z.alt_wert, z.neu_wert = roh_laden(z.alt_wert), roh_laden(z.neu_wert)
        return z

    def umgekehrt(self) -> "Zelle":
        """Für „Rückgängig“: alt und neu getauscht."""
        z = copy.deepcopy(self)
        z.alt_text, z.neu_text = self.neu_text, self.alt_text
        if self.neu_wert != UNVERAENDERT:
            z.alt_wert, z.neu_wert = self.neu_wert, self.alt_wert
        if self.neu_fuellung != UNVERAENDERT:
            z.alt_fuellung, z.neu_fuellung = (self.neu_fuellung or None), (self.alt_fuellung or "")
        if self.neu_schrift != UNVERAENDERT:
            z.alt_schrift, z.neu_schrift = (self.neu_schrift or None), (self.alt_schrift or "000000")
        return z


# ----------------------------------------------------------------------------------------- Lesen ---

@dataclass
class RohZelle:
    wert: object            # Formel („=…“) oder Wert
    ergebnis: object        # gespeichertes Ergebnis (bei Formeln), sonst = wert
    fuellung: str = None
    schrift: str = None
    format: str = None


class RohBlatt:
    def __init__(self, name: str):
        self.name = name
        self.zeilen = {}            # Excel-Zeile -> [RohZelle]

    def zelle(self, zeile: int, spalte: int) -> RohZelle:
        z = self.zeilen.get(zeile) or []
        return z[spalte - 1] if 0 < spalte <= len(z) else RohZelle(None, None)

    def werte(self, zeile: int) -> list:
        return [c.ergebnis for c in self.zeilen.get(zeile) or []]

    def kopf(self, mapping: dict):
        """(Kopfzeile, {feld: spalte (1-basiert)}) nach der Zuordnung der Liste – wie beim Einlesen."""
        nummern = sorted(self.zeilen)
        werte = [self.werte(n) for n in nummern]
        if not werte:
            return None, {}
        i = finde_kopfzeile(werte, alle_aliase(mapping))
        zuordnungen, _ = ordne_spalten_zu(werte[i], mapping)
        spalten = {}
        for z in zuordnungen:
            spalten.setdefault(z.feld, z.spalte + 1)
        return nummern[i], spalten


def lies_mappe(pfad: str, blaetter=None, max_spalte: int = 40, max_zeilen: int = MAX_ZEILEN) -> dict:
    """Blattname -> RohBlatt mit Formeln, gespeicherten Ergebnissen, Füll- und Schriftfarben (nur Zeilen mit Inhalt)."""
    try:
        wb_f = load_workbook(pfad, read_only=True, data_only=False)
        wb_w = load_workbook(pfad, read_only=True, data_only=True)
    except PermissionError:
        raise DateiGesperrt(f"„{os.path.basename(pfad)}“ ist gerade gesperrt – bitte gleich noch einmal.") from None
    try:
        leser = Farbleser(wb_f)
        ergebnis = {}
        for ws in wb_f.worksheets:
            if blaetter is not None and ws.title not in blaetter:
                continue
            ws_w = wb_w[ws.title]
            for w in (ws, ws_w):
                if hasattr(w, "reset_dimensions"):
                    w.reset_dimensions()
            rb = RohBlatt(ws.title)
            zeilen_w = ws_w.iter_rows(max_col=max_spalte, max_row=max_zeilen, values_only=True)
            for nr, zellen in enumerate(ws.iter_rows(max_col=max_spalte, max_row=max_zeilen), start=1):
                werte = next(zeilen_w, ())
                if not any(getattr(c, "value", None) not in (None, "") for c in zellen):
                    continue
                reihe = []
                for j, c in enumerate(zellen):
                    w = getattr(c, "value", None)
                    e = werte[j] if j < len(werte) else None
                    fill = getattr(c, "fill", None)
                    font = getattr(c, "font", None)
                    reihe.append(RohZelle(w, e if ist_formel(w) else w, leser.fuellfarbe(fill) if fill is not None else None,
                                          leser.schriftfarbe(font) if font is not None else None,
                                          getattr(c, "number_format", None)))
                rb.zeilen[nr] = reihe
            ergebnis[ws.title] = rb
        return ergebnis
    finally:
        wb_f.close()
        wb_w.close()


# -------------------------------------------------------------------- Formeln, die auf Zellen zeigen ---

_BEZUG = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-zÄÖÜäöüß0-9_.]+))?!?\$?([A-Z]{1,3})\$?(\d+)(?::\$?([A-Z]{1,3})\$?(\d+))?")
_SPALTEN_BEZUG = re.compile(r"(?:'((?:[^']|'')+)'!|([A-Za-zÄÖÜäöüß0-9_.]+)!)?\$?([A-Z]{1,3}):\$?([A-Z]{1,3})(?![\d])")
_UNSICHER = re.compile(r"\b(INDIRECT|INDIREKT|OFFSET|BEREICH\.VERSCHIEBEN)\s*\(", re.IGNORECASE)


def formeln_der_mappe(pfad: str, max_zellen: int = 400000) -> list:
    """[(blatt, zeile, spalte, formel)] aller Formeln einer Mappe (read-only, schnell)."""
    wb = load_workbook(pfad, read_only=True, data_only=False)
    try:
        formeln, gezaehlt = [], 0
        for ws in wb.worksheets:
            if hasattr(ws, "reset_dimensions"):
                ws.reset_dimensions()
            for nr, zeile in enumerate(ws.iter_rows(values_only=True), start=1):
                for j, w in enumerate(zeile, start=1):
                    gezaehlt += 1
                    if ist_formel(w):
                        formeln.append((ws.title, nr, j, w))
                if gezaehlt > max_zellen:
                    break
        return formeln
    finally:
        wb.close()


def zeigt_auf(formel: str, formel_blatt: str, blatt: str, zeile: int, spalte: int) -> bool:
    """Bezieht sich die Formel (im Blatt formel_blatt) auf die Zelle? Unsichere Funktionen (INDIREKT) zählen als ja."""
    if _UNSICHER.search(formel):
        return True
    text = re.sub(r'"[^"]*"', "", formel)                    # Text in Anführungszeichen ist kein Bezug
    for m in _SPALTEN_BEZUG.finditer(text):
        b = (m.group(1) or "").replace("''", "'") or m.group(2) or formel_blatt
        if b == blatt and column_index_from_string(m.group(3)) <= spalte <= column_index_from_string(m.group(4)):
            return True
    for m in _BEZUG.finditer(text):
        vor = m.group(0)
        b = (m.group(1) or "").replace("''", "'") or m.group(2)
        if b and "!" not in vor:
            b = None                                         # Funktionsname o. Ä. davor, kein Blattname
        b = b or formel_blatt
        if b != blatt:
            continue
        z1, s1 = int(m.group(4)), column_index_from_string(m.group(3))
        z2 = int(m.group(6)) if m.group(6) else z1
        s2 = column_index_from_string(m.group(5)) if m.group(5) else s1
        if min(z1, z2) <= zeile <= max(z1, z2) and min(s1, s2) <= spalte <= max(s1, s2):
            return True
    return False


def abhaengige(formeln: list, blatt: str, zeile: int, spalte: int) -> list:
    return [f"{b}!{get_column_letter(s)}{z}" for b, z, s, f in formeln if zeigt_auf(f, b, blatt, zeile, spalte)]


# ------------------------------------------------------------------------------- Sperre, Sicherung ---

def sperrdatei(pfad: str):
    """Pfad der Excel-Sperrdatei („~$Liste.xlsx“), falls vorhanden – sonst None."""
    ordner, name = os.path.split(pfad)
    for kandidat in ("~$" + name, "~$" + name[2:]):
        p = os.path.join(ordner, kandidat)
        if len(kandidat) > 2 and os.path.exists(p):
            return p
    return None


def sperre_von(pfad: str) -> str:
    """Wer hat die Datei offen? Excel schreibt den Namen vorn in die Sperrdatei (ohne Gewähr)."""
    p = sperrdatei(pfad)
    if not p:
        return ""
    try:
        with open(p, "rb") as f:
            roh = f.read(165)
        n = roh[0] if roh else 0
        name = roh[1:1 + n].decode("latin-1", "ignore").strip()
        return name if name.isprintable() else ""
    except OSError:
        return ""


def gesperrt(pfad: str):
    """Text, warum die Datei gerade nicht geschrieben werden kann – oder None."""
    if sperrdatei(pfad):
        wer = sperre_von(pfad)
        return (f"„{os.path.basename(pfad)}“ ist gerade in Excel geöffnet" + (f" (von {wer})" if wer else "") +
                " – erst schließen, dann geht es.")
    try:
        with open(pfad, "r+b"):
            pass
    except PermissionError:
        return f"„{os.path.basename(pfad)}“ ist gerade gesperrt (Excel oder OneDrive) – bitte gleich noch einmal."
    except OSError:
        return f"„{os.path.basename(pfad)}“ ist nicht erreichbar."
    return None


def sicherung_anlegen(pfad: str, basis: str) -> str:
    """Kopie nach <basis>/_ODIN/Sicherungen/<Dateiname>/<Zeitstempel>.xlsx; ältere über 20 werden entfernt."""
    name = os.path.basename(pfad)
    ordner = os.path.join(basis, "_ODIN", "Sicherungen", re.sub(r"[^\w.\- ]", "_", name))
    os.makedirs(ordner, exist_ok=True)
    stempel = dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    endung = os.path.splitext(name)[1] or ".xlsx"
    ziel = os.path.join(ordner, stempel + endung)
    n = 1
    while os.path.exists(ziel):
        n += 1
        ziel = os.path.join(ordner, f"{stempel}_{n}{endung}")
    shutil.copy2(pfad, ziel)
    alle = sorted(glob.glob(os.path.join(ordner, "*" + endung)))
    for alt in alle[:-SICHERUNGEN_BEHALTEN]:
        try:
            os.remove(alt)
        except OSError:
            pass
    return ziel


# ---------------------------------------------------------------------------------- Schreiber ---

class Schreiber:
    name = ""
    titel = ""

    def verfuegbar(self):
        """(ja/nein, Grund) – grundsätzlich auf diesem Rechner."""
        return False, ""

    def eignung(self, datei: str, zellen: list):
        """(ja/nein, Grund) – für genau diese Zellen."""
        return self.verfuegbar()

    def lese(self, datei: str, zellen: list) -> dict:
        """Adresse -> (Vergleichstext des Werts, Füllfarbe) im aktuellen Stand der Datei."""
        raise NotImplementedError

    def schreibe(self, datei: str, zellen: list):
        raise NotImplementedError


def pruefe_stand(zellen: list, stand: dict, schluessel: list = ()):
    """Stimmt die Datei noch mit dem überein, was die Vorschau gezeigt hat? Sonst ListeGeaendert."""
    for z in list(schluessel) + list(zellen):
        wert, fuellung = stand.get((z.blatt, z.adresse), (None, None))
        if vergleich(wert, z.alt_wert) != vergleich(z.alt_wert):
            raise ListeGeaendert(f"Die Liste hat sich geändert: in {z.blatt}!{z.adresse} ({z.label or z.feld}) steht "
                                 f"jetzt „{vergleich(wert, z.alt_wert) or 'leer'}“ statt „{vergleich(z.alt_wert) or 'leer'}“. "
                                 "Bitte die Aktion neu ansehen.")
        if getattr(z, "neu_fuellung", UNVERAENDERT) != UNVERAENDERT and hex_farbe(fuellung) != hex_farbe(z.alt_fuellung):
            # Farbe anders als in der Vorschau: jemand hat den Status inzwischen selbst gesetzt
            if not (hex_farbe(fuellung) in (None, "FFFFFF") and hex_farbe(z.alt_fuellung) in (None, "FFFFFF")):
                raise ListeGeaendert(f"Die Liste hat sich geändert: {z.blatt}!{z.adresse} ({z.label or z.feld}) hat "
                                     "inzwischen eine andere Farbe. Bitte die Aktion neu ansehen.")


_VERLUST = ("xl/drawings/", "xl/charts/", "xl/pivotTables/", "xl/pivotCache/", "xl/slicers/", "xl/slicerCaches/",
            "xl/ctrlProps/", "xl/vbaProject.bin", "xl/embeddings/", "xl/media/", "xl/timelines/", "xl/model/",
            "xl/externalLinks/", "customXml/")


def openpyxl_verluste(pfad: str) -> list:
    """Teile einer Mappe, die openpyxl beim Speichern nicht (sicher) mitnimmt."""
    try:
        with zipfile.ZipFile(pfad) as z:
            namen = z.namelist()
    except (zipfile.BadZipFile, OSError):
        return ["unlesbar"]
    gefunden = []
    for teil in _VERLUST:
        if any(n.startswith(teil) for n in namen):
            gefunden.append({"xl/drawings/": "Formen/Textfelder", "xl/charts/": "Diagramme",
                             "xl/pivotTables/": "Pivot-Tabellen", "xl/pivotCache/": "Pivot-Tabellen",
                             "xl/slicers/": "Datenschnitte", "xl/slicerCaches/": "Datenschnitte",
                             "xl/ctrlProps/": "Steuerelemente", "xl/vbaProject.bin": "Makros",
                             "xl/embeddings/": "eingebettete Objekte", "xl/media/": "Bilder",
                             "xl/timelines/": "Zeitachsen", "xl/model/": "Datenmodell",
                             "xl/externalLinks/": "Verknüpfungen zu anderen Dateien",
                             "customXml/": "Zusatzdaten (z. B. Vertraulichkeit)"}[teil])
    return list(dict.fromkeys(gefunden))


def _setze_openpyxl(ws, z: Zelle):
    c = ws.cell(row=z.zeile, column=z.spalte)
    if z.neu_wert != UNVERAENDERT:
        c.value = z.neu_wert
        if z.nummernformat:
            c.number_format = z.nummernformat
    if z.neu_fuellung != UNVERAENDERT:
        c.fill = PatternFill(fill_type=None) if not z.neu_fuellung else PatternFill(
            fill_type="solid", fgColor=Color(rgb="FF" + hex_farbe(z.neu_fuellung)),
            bgColor=Color(rgb="FF" + hex_farbe(z.neu_fuellung)))
    if z.neu_schrift != UNVERAENDERT:
        f = copy.copy(c.font)
        f.color = Color(rgb="FF" + (hex_farbe(z.neu_schrift) or "000000"))
        c.font = f


class OpenpyxlSchreiber(Schreiber):
    """Rückfall ohne Excel – eng begrenzt (siehe Modulbeschreibung)."""
    name = "openpyxl"
    titel = "Datei direkt (ohne Excel)"

    def verfuegbar(self):
        return True, ""

    def eignung(self, datei: str, zellen: list):
        sperre = gesperrt(datei)
        if sperre:
            return False, sperre
        verluste = openpyxl_verluste(datei)
        if verluste:
            return False, ("Ohne Excel ginge beim Speichern etwas verloren (" + ", ".join(verluste) + ") – dafür "
                           "braucht es Excel auf diesem Rechner oder Excel Online.")
        for z in zellen:
            if ist_formel(z.alt_wert) or ist_formel(z.neu_wert):
                return False, (f"{z.blatt}!{z.adresse} ({z.label or z.feld}) ist eine Formel – das darf nur Excel "
                               "selbst ändern (Excel auf diesem Rechner oder Excel Online).")
        betroffen = [z for z in zellen if z.neu_wert != UNVERAENDERT]
        if betroffen:
            formeln = formeln_der_mappe(datei)
            for z in betroffen:
                ab = abhaengige(formeln, z.blatt, z.zeile, z.spalte)
                if ab:
                    z.abhaengig = ab[:8]
                    return False, (f"Auf {z.blatt}!{z.adresse} ({z.label or z.feld}) bauen Formeln auf "
                                   f"({', '.join(ab[:3])}{' …' if len(ab) > 3 else ''}). Ohne Excel würden sie nicht neu "
                                   "gerechnet – dafür braucht es Excel auf diesem Rechner oder Excel Online.")
        return True, ""

    def lese(self, datei: str, zellen: list) -> dict:
        blaetter = {z.blatt for z in zellen}
        mappe = lies_mappe(datei, blaetter, max_spalte=max(z.spalte for z in zellen))
        return {(z.blatt, z.adresse): (mappe[z.blatt].zelle(z.zeile, z.spalte).wert,
                                       mappe[z.blatt].zelle(z.zeile, z.spalte).fuellung)
                for z in zellen if z.blatt in mappe}

    def schreibe(self, datei: str, zellen: list):
        endung = os.path.splitext(datei)[1].lower()
        ergebnisse = _gespeicherte_ergebnisse(datei)
        try:
            wb = load_workbook(datei, keep_vba=endung == ".xlsm", keep_links=True)
        except PermissionError:
            raise DateiGesperrt(gesperrt(datei) or "Die Datei ist gerade gesperrt.") from None
        for z in zellen:
            if z.blatt not in wb.sheetnames:
                raise ListeGeaendert(f"Das Blatt „{z.blatt}“ gibt es nicht mehr.")
            _setze_openpyxl(wb[z.blatt], z)
        try:
            wb.calculation.fullCalcOnLoad = True           # Excel rechnet beim nächsten Öffnen alles neu
        except AttributeError:
            pass
        tmp = datei + ".odin-tmp"
        wb.save(tmp)
        wb.close()
        _ergebnisse_eintragen(tmp, ergebnisse)
        try:
            os.replace(tmp, datei)
        except PermissionError:
            os.remove(tmp)
            raise DateiGesperrt(gesperrt(datei) or "Die Datei ist gerade gesperrt.") from None


def _gespeicherte_ergebnisse(pfad: str) -> dict:
    """(Blatt, Adresse) -> gespeichertes Formelergebnis – damit sie nach dem Speichern mit openpyxl nicht fehlen."""
    werte = {}
    wb_f = load_workbook(pfad, read_only=True, data_only=False)
    wb_w = load_workbook(pfad, read_only=True, data_only=True)
    try:
        for ws in wb_f.worksheets:
            ws_w = wb_w[ws.title]
            for w in (ws, ws_w):
                if hasattr(w, "reset_dimensions"):
                    w.reset_dimensions()
            zeilen_w = ws_w.iter_rows(values_only=True)
            for nr, zeile in enumerate(ws.iter_rows(values_only=True), start=1):
                ew = next(zeilen_w, ())
                for j, w in enumerate(zeile):
                    if ist_formel(w) and j < len(ew) and ew[j] is not None:
                        werte[(ws.title, f"{get_column_letter(j + 1)}{nr}")] = ew[j]
    finally:
        wb_f.close()
        wb_w.close()
    return werte


def _xml_text(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _ergebnisse_eintragen(pfad: str, werte: dict):
    """Formelergebnisse wieder in die gespeicherte Mappe schreiben (<v> der Formelzellen)."""
    if not werte:
        return
    with zipfile.ZipFile(pfad) as z:
        inhalte = {n: z.read(n) for n in z.namelist()}
        infos = {i.filename: i for i in z.infolist()}
    wb_xml = inhalte.get("xl/workbook.xml", b"").decode("utf-8")
    rels = inhalte.get("xl/_rels/workbook.xml.rels", b"").decode("utf-8")
    ziele = dict(re.findall(r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"', rels))
    ziele.update({k: v for v, k in re.findall(r'<Relationship[^>]*Target="([^"]+)"[^>]*Id="([^"]+)"', rels)})
    blatt_datei = {}
    for name, rid in re.findall(r'<sheet[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"', wb_xml):
        ziel = ziele.get(rid, "")
        ziel = ziel.lstrip("/")
        blatt_datei[_xml_entities(name)] = ziel if ziel.startswith("xl/") else "xl/" + ziel
    je_datei = {}
    for (blatt, adresse), wert in werte.items():
        if blatt in blatt_datei:
            je_datei.setdefault(blatt_datei[blatt], {})[adresse] = wert
    for datei, zellen in je_datei.items():
        if datei not in inhalte:
            continue
        xml = inhalte[datei].decode("utf-8")

        def ersetze(m):
            adresse = m.group(1)
            if adresse not in zellen:
                return m.group(0)
            wert = zellen[adresse]
            attrs = re.sub(r'\s+t="[^"]*"', "", m.group(2))
            if isinstance(wert, bool):
                return f'<c r="{adresse}"{attrs} t="b">{m.group(3)}<v>{int(wert)}</v></c>'
            if isinstance(wert, (int, float)):
                return f'<c r="{adresse}"{attrs}>{m.group(3)}<v>{wert}</v></c>'
            if isinstance(wert, (dt.datetime, dt.date)):
                d = wert if isinstance(wert, dt.datetime) else dt.datetime.combine(wert, dt.time())
                return f'<c r="{adresse}"{attrs}>{m.group(3)}<v>{(d - EXCEL_NULL).total_seconds() / 86400}</v></c>'
            return f'<c r="{adresse}"{attrs} t="str">{m.group(3)}<v>{_xml_text(str(wert))}</v></c>'

        xml = re.sub(r'<c r="([A-Z]+\d+)"([^>]*)>(<f[^>]*>.*?</f>|<f[^>]*/>)(?:<v>[^<]*</v>|<v\s*/>)?</c>', ersetze, xml,
                     flags=re.S)
        inhalte[datei] = xml.encode("utf-8")
    tmp = pfad + ".v"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as neu:
        for n, inhalt in inhalte.items():
            neu.writestr(infos[n], inhalt)
    os.replace(tmp, pfad)


def _xml_entities(s: str) -> str:
    return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'")


# ------------------------------------------------------------------------------------- COM ---

def _bgr(hexwert: str) -> int:
    h = hex_farbe(hexwert) or "FFFFFF"
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return r + (g << 8) + (b << 16)


def _hex_aus_bgr(wert) -> str:
    try:
        n = int(wert)
    except (TypeError, ValueError):
        return None
    return f"{n & 0xFF:02X}{(n >> 8) & 0xFF:02X}{(n >> 16) & 0xFF:02X}"


def _excel_registriert() -> bool:
    """Ist Excel als COM-Server registriert? (pywin32 allein reicht nicht – ohne Excel scheitert DispatchEx.)"""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"Excel.Application\CLSID"):
            return True
    except OSError:
        return False
    except Exception:                                       # noqa: BLE001 – kein winreg (nicht Windows)
        return False


class ComSchreiber(Schreiber):
    """Excel auf diesem Rechner über pywin32 (nur Windows). 'lade' liefert das Modul win32com.client (für Tests)."""
    name = "excel"
    titel = "Excel auf diesem Rechner"
    XL_NONE = -4142

    def __init__(self, lade=None, plattform: str = None):
        self._lade = lade
        self._plattform = plattform or sys.platform

    def _client(self):
        if self._lade is not None:
            return self._lade()
        import win32com.client                              # noqa: F401 – nur unter Windows vorhanden
        return win32com.client

    def verfuegbar(self):
        if self._plattform != "win32" and self._lade is None:
            return False, "Excel steuern geht nur unter Windows."
        try:
            self._client()
        except Exception:                                   # noqa: BLE001 – ImportError und COM-Fehler
            return False, "pywin32 ist auf diesem Rechner nicht installiert."
        if self._lade is None and not _excel_registriert():
            return False, "Microsoft Excel ist auf diesem Rechner nicht installiert."
        return True, ""

    def eignung(self, datei: str, zellen: list):
        ok, grund = self.verfuegbar()
        if not ok:
            return ok, grund
        sperre = gesperrt(datei)
        if sperre:
            return False, sperre
        return True, ""

    def _mit_mappe(self, datei: str, arbeit, speichern: bool):
        client = self._client()
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except Exception:                                   # noqa: BLE001 – außerhalb Windows bzw. im Test
            pythoncom = None
        app = client.DispatchEx("Excel.Application")
        try:
            app.Visible = False
            app.DisplayAlerts = False
            wb = app.Workbooks.Open(os.path.abspath(datei), 0, False)
            try:
                if getattr(wb, "ReadOnly", False):
                    raise DateiGesperrt(f"„{os.path.basename(datei)}“ ist gerade woanders geöffnet – Excel öffnet sie "
                                        "nur schreibgeschützt.")
                ergebnis = arbeit(wb)
                if speichern:
                    wb.Save()
                return ergebnis
            finally:
                wb.Close(False)
        finally:
            try:
                app.Quit()
            except Exception:                               # noqa: BLE001
                pass
            if pythoncom is not None:
                try:
                    pythoncom.CoUninitialize()
                except Exception:                           # noqa: BLE001
                    pass

    def lese(self, datei: str, zellen: list) -> dict:
        def arbeit(wb):
            stand = {}
            for z in zellen:
                rng = wb.Worksheets(z.blatt).Range(z.adresse)
                formel = rng.Formula
                wert = formel if ist_formel(formel) else rng.Value
                farbe = None if rng.Interior.ColorIndex == self.XL_NONE else _hex_aus_bgr(rng.Interior.Color)
                stand[(z.blatt, z.adresse)] = (wert, farbe)
            return stand
        return self._mit_mappe(datei, arbeit, speichern=False)

    def schreibe(self, datei: str, zellen: list):
        def arbeit(wb):
            for z in zellen:
                rng = wb.Worksheets(z.blatt).Range(z.adresse)
                if z.neu_wert != UNVERAENDERT:
                    if z.nummernformat:
                        rng.NumberFormat = z.nummernformat
                    rng.Value = z.neu_wert if z.neu_wert is not None else ""
                if z.neu_fuellung != UNVERAENDERT:
                    if z.neu_fuellung:
                        rng.Interior.Color = _bgr(z.neu_fuellung)
                    else:
                        rng.Interior.ColorIndex = self.XL_NONE
                if z.neu_schrift != UNVERAENDERT:
                    rng.Font.Color = _bgr(z.neu_schrift or "000000")
        self._mit_mappe(datei, arbeit, speichern=True)


# ------------------------------------------------------------------------------------- Graph ---

def _excel_seriell(v):
    if isinstance(v, dt.datetime):
        return round((v - EXCEL_NULL).total_seconds() / 86400, 6)
    if isinstance(v, dt.date):
        return (dt.datetime.combine(v, dt.time()) - EXCEL_NULL).days
    return v


def _graph_text(s: str) -> str:
    return s.replace("'", "''")


class GraphSchreiber(Schreiber):
    """Excel Online über Microsoft Graph. 'graph(methode, pfad, token, daten=None, kopf_extra=None)' und 'token()'
    kommen aus der Microsoft-Anmeldung (microsoft.py); 'datei_finden(pfad)' liefert (drive_id, item_id) zur lokal
    synchronisierten Datei. Noch nicht mit einem echten Microsoft 365 erprobt (App-Registrierung steht aus)."""
    name = "graph"
    titel = "Excel Online (Microsoft 365)"

    def __init__(self, graph, token, datei_finden, eingeschaltet=lambda: False):
        self._graph_roh = graph
        self._token = token
        self._finden = datei_finden
        self._an = eingeschaltet

    def _graph(self, methode, pfad, token, daten=None, kopf_extra=None):
        """Graph-Aufruf mit Meldungen, die zu Excel passen (statt „Postfach“ oder „Mail.Send“)."""
        try:
            return self._graph_roh(methode, pfad, token, daten=daten, kopf_extra=kopf_extra)
        except Exception as e:                              # noqa: BLE001
            status = getattr(e, "status", None)
            if status == 403:
                raise SchreibFehler("Microsoft erlaubt ODIN das Ändern der Datei nicht – fehlt die Berechtigung "
                                    "„Files.ReadWrite.All“ oder die Zustimmung des Administrators?") from None
            if status == 404:
                raise SchreibFehler("Datei oder Blatt in Excel Online nicht gefunden.") from None
            if status in (409, 423):
                raise DateiGesperrt("Die Datei ist in Excel Online gerade gesperrt – bitte gleich noch einmal.") from None
            if isinstance(e, SchreibFehler):
                raise
            raise SchreibFehler(f"Excel Online: {e}") from None

    def verfuegbar(self):
        if not self._an():
            return False, "Excel Online ist unter Einstellungen noch nicht eingeschaltet."
        try:
            self._token()
        except Exception as e:                              # noqa: BLE001 – Anmeldung fehlt oder abgelaufen
            return False, f"Microsoft-Anmeldung: {e}"
        return True, ""

    def eignung(self, datei: str, zellen: list):
        ok, grund = self.verfuegbar()
        if not ok:
            return ok, grund
        try:
            self._finden(datei)
        except Exception as e:                              # noqa: BLE001
            return False, f"Die Datei ist in Microsoft 365 nicht zu finden ({e})."
        return True, ""

    def _basis(self, datei: str) -> str:
        drive, item = self._finden(datei)
        return f"/drives/{drive}/items/{item}/workbook"

    def _bereich(self, basis: str, z: Zelle) -> str:
        return f"{basis}/worksheets('{_graph_text(z.blatt)}')/range(address='{z.adresse}')"

    def lese(self, datei: str, zellen: list) -> dict:
        token = self._token()
        basis = self._basis(datei)
        stand = {}
        for z in zellen:
            r = self._graph("GET", self._bereich(basis, z) + "?$select=formulas,values", token)
            formel = ((r.get("formulas") or [[None]])[0] or [None])[0]
            wert = formel if ist_formel(formel) else ((r.get("values") or [[None]])[0] or [None])[0]
            fill = self._graph("GET", self._bereich(basis, z) + "/format/fill", token)
            farbe = hex_farbe(fill.get("color")) if fill.get("color") else None
            stand[(z.blatt, z.adresse)] = (wert if wert != "" else None, farbe)
        return stand

    def schreibe(self, datei: str, zellen: list):
        token = self._token()
        basis = self._basis(datei)
        sitzung = self._graph("POST", basis + "/createSession", token, daten={"persistChanges": True})
        kopf = {"workbook-session-id": sitzung.get("id", "")} if sitzung.get("id") else None
        try:
            for z in zellen:
                bereich = self._bereich(basis, z)
                if z.neu_wert != UNVERAENDERT:
                    daten = {"values": [[_excel_seriell(z.neu_wert) if z.neu_wert is not None else ""]]}
                    if z.nummernformat:
                        daten["numberFormat"] = [[z.nummernformat]]
                    self._graph("PATCH", bereich, token, daten=daten, kopf_extra=kopf)
                if z.neu_fuellung != UNVERAENDERT:
                    if z.neu_fuellung:
                        self._graph("PATCH", bereich + "/format/fill", token,
                                    daten={"color": "#" + hex_farbe(z.neu_fuellung)}, kopf_extra=kopf)
                    else:
                        self._graph("POST", bereich + "/format/fill/clear", token, daten={}, kopf_extra=kopf)
                if z.neu_schrift != UNVERAENDERT:
                    self._graph("PATCH", bereich + "/format/font", token,
                                daten={"color": "#" + (hex_farbe(z.neu_schrift) or "000000")}, kopf_extra=kopf)
        finally:
            if kopf:
                try:
                    self._graph("POST", basis + "/closeSession", token, daten={}, kopf_extra=kopf)
                except Exception:                           # noqa: BLE001 – Sitzung läuft sonst nach Minuten ab
                    pass


def graph_datei_finden(graph, token, pfad: str) -> tuple:
    """(drive_id, item_id) zur lokal synchronisierten Datei: Microsoft-Suche nach dem Dateinamen, dann die Treffer,
    deren Ordnerpfad zum lokalen Pfad passt (letzte zwei Ordner) und deren Größe stimmt."""
    name = os.path.basename(pfad)
    ordner = [normalisiere(t) for t in os.path.normpath(os.path.dirname(pfad)).split(os.sep) if t][-2:]
    try:
        groesse = os.path.getsize(pfad)
    except OSError:
        groesse = None
    t = token()
    antwort = graph("POST", "/search/query", t, daten={"requests": [{
        "entityTypes": ["driveItem"], "query": {"queryString": f'filename:"{name}"'}, "size": 25}]})
    treffer = []
    for wert in antwort.get("value") or []:
        for container in wert.get("hitsContainers") or []:
            for hit in container.get("hits") or []:
                r = hit.get("resource") or {}
                if str(r.get("name", "")).casefold() != name.casefold():
                    continue
                parent = r.get("parentReference") or {}
                pfad_cloud = [normalisiere(x) for x in str(parent.get("path") or "").split(":")[-1].split("/") if x]
                punkte = sum(1 for a, b in zip(reversed(ordner), reversed(pfad_cloud)) if a == b)
                if groesse is not None and r.get("size") == groesse:
                    punkte += 1
                treffer.append((punkte, parent.get("driveId"), r.get("id")))
    treffer = [x for x in treffer if x[1] and x[2]]
    if not treffer:
        raise SchreibFehler(f"„{name}“ wurde in Microsoft 365 nicht gefunden.")
    treffer.sort(key=lambda x: -x[0])
    if len(treffer) > 1 and treffer[0][0] == treffer[1][0]:
        raise SchreibFehler(f"„{name}“ gibt es in Microsoft 365 mehrmals – bitte in den Einstellungen zuordnen.")
    return treffer[0][1], treffer[0][2]


def schreibweg_waehlen(schreiber: list, datei: str, zellen: list):
    """Der erste Schreiber, der diese Zellen schreiben kann: (schreiber, [(name, grund) der anderen])."""
    gruende = []
    for s in schreiber:
        try:
            ok, grund = s.eignung(datei, zellen)
        except Exception as e:                              # noqa: BLE001 – ein Weg darf die anderen nicht aufhalten
            ok, grund = False, str(e)
        if ok:
            return s, gruende
        gruende.append((s.titel, grund))
    return None, gruende
