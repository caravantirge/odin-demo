"""Aktionen für die Teile- und Einbaupreisliste: Arbeitszeit, Preis, Lagerbestand.

Gerechnet wird wie ODIN die Liste liest (importer._lies_teileliste, assistent.kundenpreis):
- 1 AW = 6 Minuten; Lohn VK (Spalte L) = AW × VK je AW (Spalte M, sonst Kopf „VK je AW brutto“).
- Kundenpreis inkl. Montage = festgelegter Set-Preis (H), sonst Material (J, sonst I) + Lohn VK (+ Stückliste).
Steht in einer abhängigen Zelle eine Formel, rechnet Excel selbst (dann nur über Excel oder Excel Online); steht dort
ein Wert, der zur Rechnung passt, rechnet ODIN ihn mit; passt er nicht, bleibt er und es gibt einen Hinweis.
"""

import re

from ..cockpit.importer import _artikel_nr
from . import excel as xl
from . import gehirn, sprache
from .basis import Aktion, AktionsFehler, ExcelZeile, Plan, Rueckfrage, finde_listenzeile, ohne_datei_grund, quelle
from .finden import teile_finden, teile_frage

ART = "teilepreise"
SP = {b: i + 1 for i, b in enumerate("ABCDEFGHIJKLMNOPQR")}


def _zahl(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return sprache.zahl_aus(v) if isinstance(v, str) and not v.startswith("=") else None


def _rund(x, n=2):
    return None if x is None else round(x + 0.0, n)


class TeilAktion(Aktion):
    bereich = "Teile & Montage"

    def lies(self, text, k):
        return {}

    def schritt(self, p, k):
        if p.get("sku"):
            if not self.teil(p, k, still=True):
                kandidaten = teile_finden(k.db, p["sku"])
                if len(kandidaten) == 1:
                    p["sku"] = kandidaten[0]["sku"]
                else:
                    p.pop("sku")
                    if kandidaten:
                        return teile_frage(kandidaten)
                    raise AktionsFehler("Dieses Teil finde ich in der Teileliste nicht.")
            return None
        kandidaten = teile_finden(k.db, k.satz)
        if len(kandidaten) == 1:
            p["sku"] = kandidaten[0]["sku"]
            return None
        if not kandidaten:
            return Rueckfrage("Welches Teil ist gemeint?", "sku", frei=True, platzhalter="Code oder Bezeichnung")
        return teile_frage(kandidaten)

    def teil(self, p, k, still=False):
        r = k.db.execute("SELECT p.*, a.bestand FROM parts p LEFT JOIN artikelstamm a ON a.artikel_nr = p.artikel_nr "
                         "WHERE p.sku = ?", (p.get("sku"),)).fetchone()
        if not r and not still:
            raise AktionsFehler("Dieses Teil gibt es nicht mehr – vielleicht wurde die Liste gerade neu eingelesen.")
        return dict(r) if r else None

    @staticmethod
    def positionen_vk(k, sku) -> float:
        r = k.db.execute("SELECT SUM(COALESCE(p.menge,1) * COALESCE(p.vk_brutto, a.stamm_vk, 0)) FROM parts p "
                         "LEFT JOIN artikelstamm a ON a.artikel_nr = p.artikel_nr WHERE p.gehoert_zu = ?", (sku,)).fetchone()
        return float(r[0] or 0)

    def zeile(self, t, k):
        """ExcelZeile der Teileliste: gegliedert (feste Spalten B…R) oder flach (Zuordnung)."""
        pfad = quelle(k, ART)
        if not pfad:
            return None
        if t.get("zeile") and t.get("source_sheet"):
            mappe = xl.lies_mappe(pfad, [t["source_sheet"]], max_spalte=18)
            rb = mappe.get(t["source_sheet"])
            if rb is None:
                raise AktionsFehler(f"Das Blatt „{t['source_sheet']}“ gibt es in der Teileliste nicht mehr.")

            def passt(nr):
                b, c = xl.vergleich(rb.zelle(nr, SP["B"]).ergebnis), _artikel_nr(rb.zelle(nr, SP["C"]).ergebnis)
                if t.get("code"):
                    return b.upper() == t["code"].upper()
                if t.get("artikel_nr"):
                    return c == t["artikel_nr"]
                return sprache.einfach(rb.zelle(nr, SP["D"]).ergebnis) and \
                    sprache.einfach(rb.zelle(nr, SP["D"]).ergebnis) in sprache.einfach(t.get("name"))
            nr = t["zeile"] if passt(t["zeile"]) else None
            if nr is None:
                treffer = [n for n in sorted(rb.zeilen) if n > 5 and passt(n)]
                if len(treffer) != 1:
                    raise AktionsFehler("In der Teileliste finde ich die Zeile nicht eindeutig – bitte neu einlesen.")
                nr = treffer[0]
            return ExcelZeile(pfad, t["source_sheet"], nr, {b: i for b, i in SP.items()}, mappe)
        return finde_listenzeile(pfad, ART, lambda w: xl.vergleich(w.get("sku")) == str(t["sku"]))

    @staticmethod
    def kopfwert(z: ExcelZeile, muster: str):
        rb = z.mappe[z.blatt]
        for nr in sorted(rb.zeilen)[:6]:
            reihe = rb.zeilen[nr]
            for j, c in enumerate(reihe):
                if isinstance(c.ergebnis, str) and re.search(muster, c.ergebnis, re.IGNORECASE):
                    for weiter in reihe[j + 1:j + 3]:
                        if _zahl(weiter.ergebnis) is not None:
                            return _zahl(weiter.ergebnis)
        return None

    @staticmethod
    def kundenpreis(t, lohn, material, pos_vk):
        if t.get("set_preis") is not None:
            return t["set_preis"]
        if material is None:
            return None
        return material + (lohn or 0) + pos_vk


# ---------------------------------------------------------------------------------------- Arbeitszeit ---

class ArbeitszeitAendern(TeilAktion):
    kennung = "arbeitszeit"
    titel = "Arbeitszeit ändern"
    beschreibung = ("Montagezeit eines Teils ändern (Stunden, Minuten oder AW, absolut oder +/−); Lohnanteil und "
                    "Kundenpreis inkl. Montage werden neu gerechnet.")
    beispiele = ("Kümmer dich darum, dass beim Lohnanteil der SAT-Anlage Caro Sidetrack 2 Stunden Arbeitszeit mehr "
                 "genommen werden", "Montagezeit SA00100 auf 2 Stunden", "AH00300: 30 Minuten weniger Einbauzeit")
    ausloeser = ((r"arbeitszeit|montagezeit|einbauzeit|lohnanteil|\baw\b|arbeitswert", 6),
                 (r"stunde|std\b|minute|\bmin\b|\baw\b", 3))
    gegen = (r"^\s*(wie (lange|viel)|was kostet|welche)\b", r"übergabe|uebergabe|auslieferung")
    parameter_info = (("teil", "Code oder Bezeichnung"), ("minuten", "Änderung in Minuten"),
                      ("richtung", "+ (mehr), - (weniger) oder = (neuer Wert)"))
    direkt_felder = ({"name": "richtung", "typ": "wahl", "label": "Änderung", "optionen": ["+", "-", "="],
                      "texte": ["mehr", "weniger", "neu setzen"]},
                     {"name": "menge", "typ": "zahl", "label": "Menge"},
                     {"name": "einheit", "typ": "wahl", "label": "Einheit", "optionen": ["Stunden", "Minuten", "AW"]})

    def lies(self, text, k):
        d = sprache.finde_dauer(text)
        return {"minuten": d.minuten, "richtung": d.richtung, "einheit": d.einheit} if d else {}

    def antwort(self, p, feld, wert, k):
        if feld == "dauer":
            d = sprache.finde_dauer(wert) or sprache.finde_dauer(f"{wert} Minuten")
            if not d:
                raise AktionsFehler("Bitte z. B. „2 Stunden mehr“, „auf 90 Minuten“ oder „+5 AW“.")
            p.update(minuten=d.minuten, richtung=d.richtung, einheit=d.einheit)
            return
        super().antwort(p, feld, wert, k)

    def schritt(self, p, k):
        if p.get("menge") not in (None, "") and not p.get("minuten"):
            menge = sprache.zahl_aus(p["menge"])
            faktor = {"Stunden": 60, "Minuten": 1, "AW": 6}.get(p.get("einheit") or "Minuten", 1)
            if menge is None:
                raise AktionsFehler("Die Menge ist keine Zahl.")
            p["minuten"] = menge * faktor
            p["richtung"] = p.get("richtung") if p.get("richtung") in ("+", "-", "=") else "+"
        frage = super().schritt(p, k)
        if frage:
            return frage
        if not p.get("minuten"):
            t = self.teil(p, k)
            return Rueckfrage(f"Wie soll sich die Arbeitszeit bei „{t['name']}“ ändern? Bisher "
                              f"{sprache.minuten_text(t.get('install_minutes'))}.", "dauer",
                              [{"wert": w, "text": w, "hinweis": ""} for w in ("30 Minuten mehr", "1 Stunde mehr",
                                                                              "2 Stunden mehr", "30 Minuten weniger")],
                              frei=True, platzhalter="z. B. 2 Stunden mehr")
        return None

    def rechne(self, p, k, t, z=None):
        """Alte und neue Werte: AW, Minuten, Lohn, Kundenpreis."""
        zelle = (lambda b: z.mappe[z.blatt].zelle(z.zeile, SP[b])) if z is not None and "B" in z.spalten else None
        aw_zeile = _zahl(zelle("N").ergebnis) if zelle else None
        alt_aw = aw_zeile if aw_zeile is not None else t.get("aw")
        min_zeile = _zahl(zelle("O").ergebnis) if zelle else None
        alt_min = min_zeile if min_zeile is not None else (t.get("install_minutes") if t.get("install_minutes") is not None
                                                           else (alt_aw * 6 if alt_aw is not None else None))
        if alt_aw is None and alt_min is not None:
            alt_aw = alt_min / 6
        alt_min = alt_min or 0
        m = float(p["minuten"])
        neu_min = alt_min + m if p.get("richtung") == "+" else alt_min - m if p.get("richtung") == "-" else m
        if neu_min <= 0:
            raise AktionsFehler(f"Die Arbeitszeit wäre {sprache.minuten_text(neu_min)} – das geht nicht.")
        vk_aw = (_zahl(zelle("M").ergebnis) if zelle else None) or t.get("vk_pro_aw") or \
            (self.kopfwert(z, r"vk\s*(je|/|pro)\s*aw") if z is not None and zelle else None) or \
            ((t.get("hourly_rate") or 120) / 10)
        lohn_zeile = _zahl(zelle("L").ergebnis) if zelle else None
        alt_lohn = lohn_zeile if lohn_zeile is not None else t.get("lohn_vk")
        if alt_lohn is None:
            alt_lohn = (alt_aw or 0) * vk_aw
        neu_aw = neu_min / 6
        neu_lohn = _rund(neu_aw * vk_aw)
        material = t.get("vk_brutto") if t.get("vk_brutto") is not None else t.get("preis_brutto")
        pos = self.positionen_vk(k, t["sku"])
        return {"alt_aw": alt_aw, "neu_aw": neu_aw, "alt_min": alt_min, "neu_min": neu_min, "vk_aw": vk_aw,
                "alt_lohn": alt_lohn, "neu_lohn": neu_lohn, "lohn_zeile": lohn_zeile, "aw_zeile": aw_zeile,
                "min_zeile": min_zeile, "alt_kp": self.kundenpreis(t, alt_lohn, material, pos),
                "neu_kp": self.kundenpreis(t, neu_lohn, material, pos)}

    def plane(self, p, k):
        t = self.teil(p, k)
        z = self.zeile(t, k)
        r = self.rechne(p, k, t, z)
        aw = lambda x: sprache.zahl_aus(f"{x:.2f}") if x is not None else None  # noqa: E731
        zeit = lambda m, a: f"{sprache.minuten_text(m)} ({xl.anzeige(round(float(a), 1))} AW)" if a is not None \
            else sprache.minuten_text(m)  # noqa: E731
        plan = Plan(f"Arbeitszeit „{t['name']}“: {zeit(r['alt_min'], r['alt_aw'])} → {zeit(r['neu_min'], r['neu_aw'])}",
                    liste="Teileliste")
        plan.odin = [{"was": "Arbeitszeit", "alt": zeit(r["alt_min"], r["alt_aw"]), "neu": zeit(r["neu_min"], r["neu_aw"])},
                     {"was": "Lohnanteil (brutto)", "alt": sprache.eur_text(r["alt_lohn"]),
                      "neu": sprache.eur_text(r["neu_lohn"])}]
        if t.get("set_preis") is not None:
            plan.odin.append({"was": "Kundenpreis inkl. Montage", "alt": sprache.eur_text(r["alt_kp"]),
                              "neu": sprache.eur_text(r["neu_kp"]) + " (Festpreis bleibt)"})
        elif r["alt_kp"] is not None:
            plan.odin.append({"was": "Kundenpreis inkl. Montage", "alt": sprache.eur_text(r["alt_kp"]),
                              "neu": sprache.eur_text(r["neu_kp"])})
        plan.overlay = [{"tabelle": "parts", "setze": {"aw": round(r["neu_aw"], 2), "install_minutes": int(round(r["neu_min"])),
                                                      "lohn_vk": r["neu_lohn"]}, "wo": {"sku": t["sku"]}}]
        plan.daten["rechnung"] = r
        if z is None:
            plan.nur_vorschau = ohne_datei_grund(k, ART)
            return plan
        plan.datei = z.datei
        hinweise = []
        if "B" in z.spalten:                                  # gegliederte Teileliste
            zelle = lambda b: z.mappe[z.blatt].zelle(z.zeile, SP[b])  # noqa: E731
            if xl.ist_formel(zelle("N").wert):
                plan.nur_vorschau = "Die AW dieses Teils stehen als Formel in der Liste – bitte in Excel ändern."
                return plan
            plan.zellen.append(z.ziel("N", "AW", alt_text=xl.vergleich(zelle("N").ergebnis) or
                                      f"leer (Warengruppe: {str(round(r['alt_aw'] or 0, 1)).replace('.', ',')})",
                                      neu_wert=aw(r["neu_aw"]), neu_text=xl.anzeige(aw(r["neu_aw"]))))
            if r["aw_zeile"] is None:
                hinweise.append(gehirn.hinweis("info", "AW stand bisher bei der Warengruppe",
                                               "ODIN trägt die neue Zeit nur bei diesem Artikel ein – die anderen Artikel "
                                               "der Warengruppe bleiben, wie sie sind.", "warengruppe"))
            if xl.ist_formel(zelle("O").wert):
                hinweise.append(gehirn.hinweis("info", "Minuten rechnet Excel", "Die Minuten (O) sind eine Formel.", "formel"))
            elif zelle("O").ergebnis is not None or r["min_zeile"] is None:
                plan.zellen.append(z.ziel("O", "Minuten", neu_wert=int(round(r["neu_min"])),
                                          neu_text=str(int(round(r["neu_min"])))))
            if xl.ist_formel(zelle("L").wert):
                hinweise.append(gehirn.hinweis("info", "Lohn rechnet Excel", "Der Lohn VK (L) ist eine Formel.", "formel"))
            elif r["lohn_zeile"] is None or abs(r["lohn_zeile"] - (r["alt_aw"] or 0) * r["vk_aw"]) < 0.06:
                plan.zellen.append(z.ziel("L", "Lohn VK (brutto)", alt_text=sprache.eur_text(r["lohn_zeile"]),
                                          neu_wert=r["neu_lohn"], neu_text=sprache.eur_text(r["neu_lohn"])))
            else:
                hinweise.append(gehirn.hinweis("warnung", "Lohn VK passt nicht zur Rechnung",
                                               f"In der Liste steht {sprache.eur_text(r['lohn_zeile'])}, AW × VK je AW "
                                               f"wären {sprache.eur_text((r['alt_aw'] or 0) * r['vk_aw'])} – ODIN lässt den "
                                               "Lohn stehen. Bitte in Excel prüfen.", "lohn"))
            # Set mit rotem Preis in I (= Einzelteil + Kleinteile + Lohn + Positionen): I wandert mit dem Lohn
            if t.get("set_preis") is not None or t.get("einzelteil_vk") is not None:
                i_wert = zelle("I")
                if not xl.ist_formel(i_wert.wert) and _zahl(i_wert.ergebnis) is not None and r["lohn_zeile"] is not None:
                    neu_i = _rund(_zahl(i_wert.ergebnis) + r["neu_lohn"] - r["lohn_zeile"])
                    plan.zellen.append(z.ziel("I", "Preis brutto (Kalkulation)", alt_text=sprache.eur_text(_zahl(i_wert.ergebnis)),
                                              neu_wert=neu_i, neu_text=sprache.eur_text(neu_i)))
            lohn_ek_aw = self.kopfwert(z, r"lohn.?ek\s*(je|/|pro)\s*aw")
            q = zelle("Q")
            klein = _zahl(zelle("K").ergebnis) or 0
            if lohn_ek_aw and not xl.ist_formel(q.wert) and _zahl(q.ergebnis) is not None and r["alt_aw"] is not None \
                    and abs(_zahl(q.ergebnis) - (r["alt_aw"] * lohn_ek_aw + klein)) < 0.06:
                neu_q = _rund(r["neu_aw"] * lohn_ek_aw + klein)
                plan.zellen.append(z.ziel("Q", "Lohn-EK (intern)", alt_text=sprache.eur_text(_zahl(q.ergebnis)),
                                          neu_wert=neu_q, neu_text=sprache.eur_text(neu_q)))
        else:                                                 # flache Liste: Montagezeit in Minuten
            if "install_minutes" not in z.spalten:
                plan.nur_vorschau = "Die Teileliste hat keine Spalte für die Montagezeit."
                return plan
            plan.zellen.append(z.ziel("install_minutes", "Montagezeit (Minuten)", neu_wert=int(round(r["neu_min"])),
                                      neu_text=str(int(round(r["neu_min"])))))
        plan.schluessel = []
        plan.daten["hinweise"] = hinweise
        return plan

    def pruefe(self, p, plan, k):
        r = plan.daten["rechnung"]
        aus = list(plan.daten.get("hinweise") or [])
        aus += gehirn.regel_grosse_aenderung(r["alt_min"], r["neu_min"], "Die Arbeitszeit")
        t = self.teil(p, k)
        if t.get("set_preis") is not None:
            aus.append(gehirn.hinweis("warnung", "Festpreis bleibt",
                                      f"Für „{t['name']}“ gilt ein festgelegter Preis ({sprache.eur_text(t['set_preis'])}) – "
                                      "mehr Arbeitszeit senkt die Spanne. Festpreis bei Bedarf mit „Preis ändern“ anpassen.",
                                      "festpreis"))
        if t.get("gehoert_zu"):
            aus.append(gehirn.hinweis("info", "Position einer Stückliste",
                                      "Das Teil wird mit einem Set verkauft – die Arbeitszeit steht meist beim Set.",
                                      "stueckliste"))
        return aus


# ------------------------------------------------------------------------------------------ Preis ---

class TeilPreisAendern(TeilAktion):
    kennung = "teilpreis"
    titel = "Teilepreis ändern"
    beschreibung = ("Verkaufspreis eines Teils (brutto) neu setzen – Material oder, mit „inkl. Montage“, der "
                    "Kundenpreis; bei Sets mit „Festpreis“ der Set-Preis.")
    beispiele = ("Preis für SA00100 auf 1.350 €", "Thule Omnistor weiß soll inkl. Montage 1.590 € kosten")
    ausloeser = ((r"preis|kosten|kostet|vk\b", 3), (r"\d\s*(€|eur|euro)", 3), (r"setz|änder|aender|soll|neu|auf", 1))
    gegen = (r"^\s*(was|wie viel|wieviel)\b", r"fahrzeug|wohnmobil|wohnwagen|kastenwagen|liste ?preis|internet|vk max|"
             r"übergabe|uebergabe|auslieferung|angezahlt|bezahlt")
    direkt_felder = ({"name": "betrag", "typ": "zahl", "label": "Neuer Preis (€ brutto)"},
                     {"name": "art", "typ": "wahl", "label": "Gilt für", "optionen": ["material", "gesamt", "festpreis"],
                      "texte": ["Teil (Material)", "inkl. Montage", "Set-Festpreis"]})

    def lies(self, text, k):
        t = text.lower()
        p = {"betrag": sprache.finde_betrag(text)}
        p["art"] = "festpreis" if re.search(r"festpreis|set.?preis", t) else \
            "gesamt" if re.search(r"inkl|inklusive|mit montage|mit einbau|komplett|gesamt", t) else "material"
        return p

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if not p.get("betrag"):
            return Rueckfrage("Welcher neue Preis (brutto)?", "betrag", frei=True, platzhalter="z. B. 1.350 €")
        return None

    def antwort(self, p, feld, wert, k):
        if feld == "betrag":
            p["betrag"] = sprache.finde_betrag(f"{wert} €") or sprache.zahl_aus(wert)
            return
        super().antwort(p, feld, wert, k)

    def plane(self, p, k):
        t = self.teil(p, k)
        betrag = float(sprache.zahl_aus(p["betrag"]) if isinstance(p["betrag"], str) else p["betrag"])
        pos = self.positionen_vk(k, t["sku"])
        lohn = t.get("lohn_vk") or 0
        material_alt = t.get("vk_brutto") if t.get("vk_brutto") is not None else t.get("preis_brutto")
        art = p.get("art") or "material"
        if art == "festpreis":
            spalte, label, alt, neu = "H", "Set-Preis (fest)", t.get("set_preis"), betrag
            kp_alt, kp_neu = self.kundenpreis(t, lohn, material_alt, pos), betrag
        else:
            neu_material = betrag - lohn - pos if art == "gesamt" else betrag
            if neu_material <= 0:
                raise AktionsFehler(f"Inkl. Montage ({sprache.eur_text(lohn)}) bliebe für das Material nichts übrig.")
            spalte = "J" if t.get("einzelteil_vk") is not None else "I"
            label, alt, neu = ("Einzelteil VK" if spalte == "J" else "Preis brutto"), material_alt, _rund(neu_material)
            kp_alt = self.kundenpreis(t, lohn, material_alt, pos)
            kp_neu = kp_alt if t.get("set_preis") is not None else self.kundenpreis({**t, "set_preis": None}, lohn, neu, pos)
        plan = Plan(f"Preis „{t['name']}“: {label} {sprache.eur_text(alt)} → {sprache.eur_text(neu)}", liste="Teileliste")
        plan.odin = [{"was": label, "alt": sprache.eur_text(alt), "neu": sprache.eur_text(neu)},
                     {"was": "Kundenpreis inkl. Montage", "alt": sprache.eur_text(kp_alt), "neu": sprache.eur_text(kp_neu)}]
        feld = {"H": "set_preis", "J": "einzelteil_vk", "I": "preis_brutto"}[spalte]
        setze = {feld: neu}
        if spalte in ("J", "I"):
            setze["vk_brutto"] = neu
            setze["sales_net"] = round(neu / 1.19, 2)
        plan.overlay = [{"tabelle": "parts", "setze": setze, "wo": {"sku": t["sku"]}}]
        plan.daten = {"alt": alt, "neu": neu}
        z = self.zeile(t, k)
        if z is None:
            plan.nur_vorschau = ohne_datei_grund(k, ART)
            return plan
        plan.datei = z.datei
        if "B" in z.spalten:
            plan.zellen = [z.ziel(spalte, label, alt_text=sprache.eur_text(_zahl(z.mappe[z.blatt].zelle(z.zeile, SP[spalte]).ergebnis)),
                                  neu_wert=neu, neu_text=sprache.eur_text(neu))]
        elif "sales_net" in z.spalten:
            netto = round(neu / 1.19, 2)
            plan.zellen = [z.ziel("sales_net", "VK netto", neu_wert=netto, neu_text=sprache.eur_text(netto))]
        else:
            plan.nur_vorschau = "Die Teileliste hat keine Preisspalte."
        return plan

    def pruefe(self, p, plan, k):
        return gehirn.regel_grosse_aenderung(plan.daten.get("alt"), plan.daten.get("neu"), "Der Preis")


# ---------------------------------------------------------------------------------- Lagerbestand ---

class LagerbestandKorrigieren(TeilAktion):
    kennung = "lagerbestand"
    titel = "Lagerbestand korrigieren"
    beschreibung = "Bestand eines Artikels im Artikelstamm (Blatt „Bestand“) setzen oder um eine Menge ändern."
    beispiele = ("Lagerbestand Giba2 auf 5", "2 Stück SA00100 verkauft", "Bestand Thule Omnistor weiß um 3 erhöhen")
    ausloeser = ((r"lagerbestand|lager\b|im lager|bestand (von|für|fuer|bei|des|der)|stück|stueck|stk\b", 5),
                 (r"verkauft|eingegangen|korrigier|auf \d|erhöh|erhoeh|reduzier", 2))
    gegen = (r"^\s*(wie viel|wieviel|wie viele|haben wir|ist)\b", r"fahrzeug|wohnmobil|wohnwagen|kastenwagen|bestandsliste")
    direkt_felder = ({"name": "richtung", "typ": "wahl", "label": "Änderung", "optionen": ["=", "+", "-"],
                      "texte": ["neu setzen", "dazu", "weg"]},
                     {"name": "menge", "typ": "zahl", "label": "Stück"})

    def lies(self, text, k):
        t = text.lower()
        m = re.search(r"auf\s+(\d+)", t)
        if m:
            return {"menge": float(m.group(1)), "richtung": "="}
        for m in re.finditer(r"(?<![a-z0-9])([+-]?\d+)\s*(?:stück|stueck|stk\.?)?\s*([a-zäöü]*)", t):
            zahl, wort = m.group(1), m.group(2)
            if re.fullmatch(r"\d{4,}", zahl.lstrip("+-")):
                continue                                   # Artikelnummer, keine Menge
            minus = zahl.startswith("-") or re.search(r"verkauft|raus|weniger|weg|entnommen|verbaut|reduzier|verringer",
                                                      wort + " " + t)
            return {"menge": abs(float(zahl)), "richtung": "-" if minus else "+"}
        return {}

    def schritt(self, p, k):
        frage = super().schritt(p, k)
        if frage:
            return frage
        if p.get("menge") in (None, ""):
            t = self.teil(p, k)
            return Rueckfrage(f"Wie ist der Bestand von „{t['name']}“ jetzt? Bisher: {sprache.zahl_aus(t.get('bestand')) or 0:g}.",
                              "menge", frei=True, platzhalter="Stück")
        return None

    def antwort(self, p, feld, wert, k):
        if feld == "menge":
            n = sprache.zahl_aus(wert)
            if n is None:
                raise AktionsFehler("Bitte eine Stückzahl.")
            p["menge"], p["richtung"] = n, p.get("richtung") or "="
            return
        super().antwort(p, feld, wert, k)

    def plane(self, p, k):
        t = self.teil(p, k)
        if not t.get("artikel_nr"):
            raise AktionsFehler(f"„{t['name']}“ hat keine Artikelnummer – ohne sie gibt es keinen Lagerbestand.")
        alt = float(t.get("bestand") or 0)
        menge = float(sprache.zahl_aus(p["menge"]) if isinstance(p["menge"], str) else p["menge"])
        neu = menge if p.get("richtung") in ("=", None) else alt + menge if p["richtung"] == "+" else alt - menge
        if neu < 0:
            raise AktionsFehler(f"Der Bestand wäre {neu:g} – das geht nicht.")
        plan = Plan(f"Lagerbestand „{t['name']}“ ({t['artikel_nr']}): {alt:g} → {neu:g}", liste="Teileliste (Artikelstamm)")
        plan.odin = [{"was": "Lagerbestand", "alt": f"{alt:g}", "neu": f"{neu:g}"}]
        plan.overlay = [{"tabelle": "artikelstamm", "setze": {"bestand": neu}, "wo": {"artikel_nr": t["artikel_nr"]}}]
        plan.daten = {"alt": alt, "neu": neu}
        pfad = quelle(k, ART)
        if not pfad:
            plan.nur_vorschau = ohne_datei_grund(k, ART)
            return plan
        from openpyxl import load_workbook
        wb = load_workbook(pfad, read_only=True)
        try:
            namen = wb.sheetnames
        finally:
            wb.close()
        blatt = next((n for n in namen if re.search("bestand", n, re.IGNORECASE)), None) or ("M" if "M" in namen else None)
        if not blatt:
            plan.nur_vorschau = "In der Teileliste gibt es kein Blatt mit dem Artikelstamm."
            return plan
        mappe = xl.lies_mappe(pfad, [blatt], max_spalte=5)
        rb = mappe[blatt]
        treffer = [nr for nr in sorted(rb.zeilen) if _artikel_nr(rb.zelle(nr, 1).ergebnis) == t["artikel_nr"]]
        if len(treffer) != 1:
            plan.nur_vorschau = (f"Artikel {t['artikel_nr']} steht {len(treffer)}-mal im Artikelstamm – ODIN ändert "
                                 "lieber nichts.") if treffer else f"Artikel {t['artikel_nr']} fehlt im Artikelstamm."
            return plan
        z = ExcelZeile(pfad, blatt, treffer[0], {"artikel_nr": 1, "bestand": 3}, mappe)
        wert = int(neu) if float(neu).is_integer() else neu
        plan.datei = pfad
        plan.zellen = [z.ziel("bestand", "Bestand", neu_wert=wert, neu_text=f"{neu:g}")]
        plan.schluessel = z.schluessel(["artikel_nr"])
        return plan

    def pruefe(self, p, plan, k):
        aus = gehirn.regel_grosse_aenderung(plan.daten.get("alt") or None, plan.daten.get("neu"), "Der Bestand")
        return [dict(h, schwere="info") for h in aus]


AKTIONEN = [ArbeitszeitAendern(), TeilPreisAendern(), LagerbestandKorrigieren()]
