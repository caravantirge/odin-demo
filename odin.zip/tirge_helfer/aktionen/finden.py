"""Was ist gemeint? Übergaben, Fahrzeuge, Teile und Personen tolerant finden (Umlaute, Groß/Klein, Nachname allein,
interne Nummern wie „detkw331“)."""

import datetime as dt
import re

from ..cockpit.assistent import finde_fahrzeug_id as _finde_id
from . import sprache
from .basis import Rueckfrage, option


def finde_fahrzeug_id(db, text: str):
    try:
        return _finde_id(db, text or "")
    except Exception:                                   # noqa: BLE001
        return None


def _offene_uebergaben(db) -> list:
    return [dict(r) for r in db.execute(
        "SELECT d.id, d.vehicle_internal_id, d.customer, d.planned_date, d.uhrzeit, v.model FROM deliveries d "
        "LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id WHERE d.actual_date IS NULL "
        "ORDER BY d.planned_date, d.id")]


def uebergaben_finden(db, text: str, p: dict) -> list:
    """Offene Übergaben, die zum Satz passen: interne Nummer, Kundenname, bisheriges Datum. Jeder Hinweis grenzt nur
    ein, wenn danach noch etwas übrig bleibt."""
    alle = _offene_uebergaben(db)
    kandidaten = alle
    genannt = False
    fid = p.get("fid")
    if fid:
        genannt = True
        kandidaten = [u for u in kandidaten if u["vehicle_internal_id"] == fid]
        if not kandidaten:
            return []
    punkte = [(sprache.name_im_text(u["customer"], text), u) for u in kandidaten]
    beste = max((n for n, _ in punkte), default=0)
    if beste > 0:
        genannt = True
        kandidaten = [u for n, u in punkte if n == beste]
    elif not fid:
        # Modell genannt („die Übergabe vom Alto“)?
        modell = [u for u in kandidaten if u.get("model") and any(
            len(w) >= 4 and sprache.wort_passt(w, m) for w in sprache.woerter(text) for m in sprache.woerter(u["model"]))]
        if modell:
            genannt = True
            kandidaten = modell
    alt = p.get("alt_datum")
    if alt:
        mit = [u for u in kandidaten if str(u.get("planned_date") or "")[:10] == alt]
        if mit:
            kandidaten = mit
    if not genannt:
        return []                                        # nichts genannt: die Rückfrage zeigt die nächsten Übergaben
    return kandidaten


def uebergabe_frage(db, kandidaten: list, heute: dt.date) -> Rueckfrage:
    if not kandidaten:
        kandidaten = [u for u in _offene_uebergaben(db) if str(u.get("planned_date") or "") >= heute.isoformat()]
        frage = "Welche Übergabe ist gemeint?"
    else:
        frage = "Welche Übergabe ist gemeint? Es passen mehrere."
    return Rueckfrage(frage, "uebergabe_id", [
        option(u["id"], f"{u['customer'] or 'ohne Namen'} · {u['vehicle_internal_id']}",
               sprache.termin_text(u.get("planned_date"), u.get("uhrzeit"))) for u in kandidaten[:8]])


def fahrzeug_finden(db, text: str):
    """(interne Nummer oder None, Kandidaten [{internal_id, model, customer}]) – über Nummer, Kunde oder Modell."""
    fid = finde_fahrzeug_id(db, text)
    if fid:
        return fid, []
    zeilen = [dict(r) for r in db.execute(
        "SELECT internal_id, model, brand, kommission_name, customer, status FROM vehicles ORDER BY internal_id")]
    treffer = []
    for z in zeilen:
        n = max(sprache.name_im_text(z.get("kommission_name"), text), sprache.name_im_text(z.get("customer"), text))
        if n:
            treffer.append((n, z))
    if not treffer:
        return None, []
    beste = max(n for n, _ in treffer)
    return None, [z for n, z in treffer if n == beste]


def fahrzeug_frage(kandidaten: list, frage="Welches Fahrzeug ist gemeint?") -> Rueckfrage:
    return Rueckfrage(frage, "fid", [option(z["internal_id"], f"{z['internal_id']} · {z.get('model') or ''}",
                                            z.get("kommission_name") or z.get("customer") or z.get("status") or "")
                                     for z in kandidaten[:8]], frei=True, platzhalter="interne Nummer, z. B. DETKW00142")


# ------------------------------------------------------------------------------------------- Teile ---

_FUELL = set("""der die das den dem des ein eine einen einem einer und oder bei beim von vom für fuer mit ohne auf um im in
an am zu zum zur ist sind wird werden soll sollen bitte mal kümmer kuemmer dich darum dass da mehr weniger neu neue
neuen preis preise lohnanteil lohn arbeitszeit montagezeit einbauzeit zeit stunden stunde std minuten minute min aw
setz setze setzen änder aender ändere aendere erhöh erhoeh erhöhe erhoehe reduzier reduziere senk senke genommen nehmen
rechnen gerechnet kalkulieren euro eur lager lagerbestand bestand stück stueck korrigier korrigiere teil teile artikel
anlage kosten kostet zusätzlich zusaetzlich dazu inkl inklusive montage einbau verkauft eingegangen raus rein""".split())


def teile_finden(db, text: str, limit: int = 8) -> list:
    """Teile der Teileliste, sortiert nach Übereinstimmung mit dem Satz (Code, Artikelnummer, Name, Produkt)."""
    roh = sprache.woerter(text)
    worte = [w for w in roh if w not in _FUELL and not w.isdigit() and len(w) >= 2]
    codes = {w.upper() for w in roh if re.fullmatch(r"[a-z]{2,3}\d{4,6}", w)}
    teile = [dict(r) for r in db.execute(
        "SELECT sku, code, artikel_nr, name, produkt, variante, warengruppe, fahrzeugtyp, aw, install_minutes, "
        "lohn_vk, vk_pro_aw, preis_brutto, einzelteil_vk, vk_brutto, set_preis, kleinteile, lohn_ek, purchase_net, "
        "hourly_rate, sales_net, gehoert_zu, source_sheet, zeile FROM parts")]
    ergebnis = []
    for t in teile:
        if t.get("code") and t["code"].upper() in codes or (t.get("sku") or "").upper() in codes:
            ergebnis.append((100, t))
            continue
        name = sprache.woerter(" ".join(str(t.get(f) or "") for f in ("name", "produkt", "variante", "warengruppe")))
        nummer = sprache.einfach(t.get("artikel_nr"))
        punkte = 0
        for w in worte:
            if nummer and w == nummer:
                punkte += 10
            elif w in name:
                punkte += 3 if len(w) >= 4 else 2
            elif len(w) >= 4 and any(sprache.wort_passt(w, n) or (len(n) >= 5 and n.startswith(w)) for n in name):
                punkte += 2
        # „SAT-Anlage“ und „Sat Anlage“ sind dasselbe
        zusammen = sprache.einfach(" ".join(worte)).replace(" ", "")
        if len(zusammen) >= 6 and zusammen in "".join(name):
            punkte += 2
        if punkte:
            ergebnis.append((punkte, t))
    ergebnis.sort(key=lambda x: (-x[0], x[1]["name"] or ""))
    if not ergebnis:
        return []
    beste = ergebnis[0][0]
    return [t for p, t in ergebnis if p >= max(2, beste - 1)][:limit]


def teile_frage(kandidaten: list) -> Rueckfrage:
    return Rueckfrage("Welches Teil ist gemeint?", "sku", [
        option(t["sku"], t["name"] or t["sku"], " · ".join(x for x in (t.get("code"), t.get("fahrzeugtyp")) if x))
        for t in kandidaten], frei=True, platzhalter="Code oder Bezeichnung")


# ------------------------------------------------------------------------------------------ Personen ---

def person_finden(personen: list, text: str) -> list:
    """Personen (aus den Projekten: {id, name}), deren Name im Satz vorkommt – Vorname reicht."""
    worte = sprache.woerter(text)
    treffer = []
    for p in personen:
        teile = sprache.namensteile(p.get("name"))
        n = sum(1 for t in teile if len(t) >= 3 and any(sprache.wort_passt(w, t) for w in worte))
        if n:
            treffer.append((n, p))
    if not treffer:
        return []
    beste = max(n for n, _ in treffer)
    return [p for n, p in treffer if n == beste]
