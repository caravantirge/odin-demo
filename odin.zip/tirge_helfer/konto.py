"""
Konto & Anmeldung: verbindet die Microsoft-Anmeldung (microsoft.py) mit ODIN.

- Einrichtung: Client-ID und Tenant-ID der App-Registrierung stehen einmal für alle Rechner im gemeinsamen Speicher
  (_ODIN-Cockpit.json im Ordner „Fahrzeuge“, Objekt „einstellungen“ → „microsoft_app“). Eine Kopie liegt in den
  Einstellungen dieses Rechners – für den Fall, dass OneDrive gerade nicht erreichbar ist.
- Wer „ich“ bin: nach der Anmeldung die Person mit derselben E-Mail. Passt keine, wählt man in der Oberfläche eine
  Person aus (hat sie eine PIN, muss die stimmen) oder legt sich neu an. Die Microsoft-Anmeldung ersetzt dann die PIN.
  Solange niemand mit Microsoft angemeldet ist, gilt die Anmeldung mit PIN (tresor.py).
- Die tägliche Erinnerungsmail (erinnerung.py).
Rollen und Rechte gibt es noch nicht – sie sollen später an der E-Mail-Adresse der Person hängen.
Im Browser (Handy & Tablet) gibt es nichts davon – die Aufrufe stehen dort bewusst nicht in der Freigabe.
"""

from .cockpit.daten import CockpitFehler
from .erinnerung import Erinnerung, ErinnerungFehler, inhalt_sammeln
from .microsoft import Anmeldung, MicrosoftFehler, NeuAnmelden, guid
from .projekte import ProjektFehler


class Konto:
    """Alles für die Seite „Konto & Anmeldung“. 'einstellungen'/'speichere' sind die Einstellungen dieses Rechners,
    'ich_speichern(person_id)' merkt sich die Person dieses Rechners. Weitere Schlüsselwörter gehen an Anmeldung
    (für Tests: msal_modul, graph)."""

    AKTIONEN = {"status", "anmelden", "anmelden_mit_code", "anmeldung_abbrechen", "code_seite_oeffnen", "abmelden",
                "app_speichern", "person_verknuepfen", "person_anlegen", "erinnerung_speichern", "test_mail"}

    def __init__(self, ordner: str, projekte, cockpit, einstellungen, speichere, ich_speichern, protokoll=None,
                 pin_bestaetigen=None, **anmeldung_optionen):
        self._projekte = projekte
        self._cockpit = cockpit
        self._einstellungen = einstellungen
        self._speichere = speichere
        self._ich_speichern = ich_speichern
        self._protokoll = protokoll or (lambda text: None)
        # Verknüpfen mit einer Person, die eine PIN hat: nur mit ihrer PIN (sonst wäre Microsoft ein Weg drumherum)
        self._pin_bestaetigen = pin_bestaetigen or (lambda person_id, pin: True)
        self.anmeldung = Anmeldung(ordner, self.app_konfig, self._protokoll, **anmeldung_optionen)
        self.anmeldung.bei_anmeldung = self._nach_anmeldung
        self.erinnerung = Erinnerung(ordner, self.anmeldung, self._erinnerung_inhalt, self._protokoll)

    # ---------------- Einrichtung (Client-ID, Tenant-ID) ----------------
    @staticmethod
    def _gueltig(werte) -> dict:
        if not isinstance(werte, dict):
            return {}
        try:
            cid, tid = guid(werte.get("client_id")), guid(werte.get("tenant_id"))
        except MicrosoftFehler:
            return {}
        return {"client_id": cid, "tenant_id": tid} if cid and tid else {}

    def app_konfig(self) -> dict:
        """{"client_id", "tenant_id", "quelle"}: „alle“ (Ordner „Fahrzeuge“), „rechner“ (nur hier) oder leer."""
        try:
            gemeinsam, lokal = self._cockpit.microsoft_app()
        except Exception as e:                        # noqa: BLE001 – dann eben die Kopie auf diesem Rechner
            self._protokoll(f"Microsoft-Einrichtung nicht lesbar: {e!r}")
            gemeinsam, lokal = {}, True
        # Maßgeblich ist, was auf DIESEM Rechner einmal übernommen wurde. Die gemeinsame Datei kann jeder mit
        # Schreibzugriff ändern – stünde dort plötzlich eine fremde App, liefe die nächste Anmeldung dorthin.
        eigene = self._gueltig(self._einstellungen.get("microsoft_app"))
        werte = self._gueltig(gemeinsam)
        if eigene:
            return {**eigene, "quelle": "alle" if werte == eigene and not lokal else "rechner",
                    "geaendert": bool(werte) and werte != eigene}
        if werte:                                                # erste Einrichtung auf diesem Rechner
            self._speichere("microsoft_app", werte)
            return {**werte, "quelle": "rechner" if lokal else "alle", "geaendert": False}
        return {"client_id": "", "tenant_id": "", "quelle": "", "geaendert": False}

    def app_speichern(self, client_id="", tenant_id="") -> dict:
        cid, tid = guid(client_id, "Client-ID"), guid(tenant_id, "Tenant-ID")
        if bool(cid) != bool(tid):
            raise MicrosoftFehler("Bitte beides eintragen: Client-ID und Tenant-ID.")
        werte = {"client_id": cid, "tenant_id": tid} if cid else {}
        alt = self.app_konfig()
        hinweis = ""
        try:
            lokal = self._cockpit.microsoft_app_setzen(werte)
        except CockpitFehler as e:
            lokal, hinweis = True, f" Im Ordner „Fahrzeuge“ ging es gerade nicht ({e})."
        self._speichere("microsoft_app", werte)
        if (alt["client_id"], alt["tenant_id"]) != (cid, tid):
            self.anmeldung.zuruecksetzen()
            if self.anmeldung.angemeldet():                     # die Anmeldung gehört zur alten App
                self.anmeldung.abmelden()
        if not werte:
            meldung = "Einrichtung entfernt."
        elif lokal:
            meldung = "Gespeichert – gilt erst einmal nur für diesen Rechner." + (
                hinweis or " Der Ordner „Fahrzeuge“ ist nicht verbunden.")
        else:
            meldung = "Gespeichert – gilt für alle Rechner."
        return {**self.status(), "meldung": meldung}

    # ---------------- wer bin ich ----------------
    def ich_fest(self) -> str:
        """Person aus der Microsoft-Anmeldung (leer, wenn niemand angemeldet oder noch nicht verknüpft)."""
        konto = self.anmeldung.konto()
        if not konto.get("email") or not self.anmeldung.speicher.vorhanden():
            return ""
        return str(konto.get("person_id") or "")

    def _konto_pflicht(self) -> dict:
        konto = self.anmeldung.konto()
        if not konto.get("email") or not self.anmeldung.angemeldet():
            raise NeuAnmelden("Bitte zuerst mit Microsoft anmelden.")
        return konto

    def _verknuepfe(self, person: dict):
        self.anmeldung.konto_aendern(person_id=person["id"])
        self._ich_speichern(person["id"])

    def _nach_anmeldung(self, konto: dict) -> str:
        """Gleich nach der Anmeldung: Person mit derselben E-Mail (oder demselben Namen) wird „ich“."""
        name = konto.get("name") or konto.get("email")
        try:
            erg = self._projekte.person_zur_anmeldung(konto.get("name", ""), konto["email"])
        except ProjektFehler as e:
            self.anmeldung.konto_aendern(person_id="")
            return f"Angemeldet als {name}. Mit deiner Person in ODIN verknüpfen ging gerade nicht: {e}"
        person = erg["person"]
        if not person:
            self.anmeldung.konto_aendern(person_id="")
            return f"Angemeldet als {name}. Wähle jetzt noch, wer du in ODIN bist."
        self._verknuepfe(person)
        return f"Angemeldet als {name} – in ODIN bist du „{person['name']}“." + (
            " Deine E-Mail-Adresse steht jetzt bei dieser Person." if erg["wie"] == "name" else "")

    def person_verknuepfen(self, person_id, pin="") -> dict:
        konto = self._konto_pflicht()
        if any(p["id"] == person_id and (p.get("email") or "").casefold() != konto["email"].casefold()
               for p in self._projekte.personen()):
            self._pin_bestaetigen(str(person_id or ""), pin)
        person = self._projekte.person_email_setzen(str(person_id or ""), konto["email"])
        self._verknuepfe(person)
        return {**self.status(), "meldung": f"Verknüpft – in ODIN bist du „{person['name']}“."}

    def person_anlegen(self) -> dict:
        konto = self._konto_pflicht()
        person = self._projekte.person_anlegen({"name": konto.get("name") or konto["email"].split("@")[0],
                                                "email": konto["email"]})
        self._verknuepfe(person)
        return {**self.status(), "meldung": f"Angelegt – in ODIN bist du jetzt „{person['name']}“."}

    # ---------------- Seite ----------------
    def status(self) -> dict:
        st = self.anmeldung.status()
        k = self.app_konfig()
        st["einrichtung"] = k
        personen, fehler = [], ""
        try:
            personen = self._projekte.personen()
        except ProjektFehler as e:
            fehler = str(e)
        pid = self.anmeldung.konto().get("person_id") if st["angemeldet"] else ""
        st["person"] = next((p for p in personen if p["id"] == pid), None)
        st["personen"] = [{k2: p.get(k2) for k2 in ("id", "name", "kuerzel", "farbe", "email")} for p in personen
                          if p.get("aktiv", True)]
        st["personen_fehler"] = fehler
        try:
            ich = self._projekte.ich()
        except ProjektFehler:
            ich = ""
        st["ich"] = next((p["name"] for p in personen if p["id"] == ich), "")
        st["erinnerung"] = self.erinnerung.einstellungen()
        return st

    def anmelden(self) -> dict:
        return self.anmeldung.anmelden("browser")

    def anmelden_mit_code(self) -> dict:
        return self.anmeldung.anmelden("code")

    def anmeldung_abbrechen(self) -> dict:
        self.anmeldung.abbrechen()
        return self.status()

    def code_seite_oeffnen(self) -> bool:
        return self.anmeldung.code_seite_oeffnen()

    def abmelden(self) -> dict:
        self.anmeldung.abmelden()
        return {**self.status(), "meldung": "Abgemeldet – die gespeicherte Anmeldung ist gelöscht."}

    def erinnerung_speichern(self, an=False, uhrzeit="") -> dict:
        werte = self.erinnerung.setzen(an, uhrzeit)
        if not werte["an"]:
            meldung = "Tägliche Erinnerung ist aus."
        elif self.anmeldung.angemeldet():
            meldung = f"Gespeichert – die Erinnerung kommt ab {werte['uhrzeit']} Uhr, wenn etwas ansteht."
        else:
            meldung = "Gespeichert – die Erinnerung kommt, sobald du mit Microsoft angemeldet bist."
        return {**self.status(), "meldung": meldung}

    def test_mail(self) -> dict:
        self._konto_pflicht()
        erg = self.erinnerung.test_senden()
        return {**self.status(), "meldung": erg["meldung"]}

    # ---------------- Inhalt der Erinnerung ----------------
    def _erinnerung_inhalt(self, heute: str):
        konto = self.anmeldung.konto()
        personen, projekte_ok = [], True
        try:
            personen = self._projekte.personen()
        except ProjektFehler as e:
            projekte_ok = False
            self._protokoll(f"Erinnerungsmail: Personen nicht lesbar: {e}")
        person = next((p for p in personen if p["id"] == konto.get("person_id")), None)
        wer = dict(person) if person else {"id": "", "name": konto.get("name", ""), "email": konto.get("email", "")}
        wer["email"] = wer.get("email") or konto.get("email", "")
        daten = None
        try:
            daten = self._cockpit.daten()
        except Exception as e:                        # noqa: BLE001 – dann eben ohne Cockpit
            self._protokoll(f"Erinnerungsmail: Cockpit nicht lesbar: {e!r}")
        if daten is None and not projekte_ok:
            raise ErinnerungFehler("Die Daten für die Erinnerung waren gerade nicht lesbar – ODIN versucht es "
                                   "später noch einmal.")
        aufgaben = []
        if person:
            try:
                aufgaben = self._projekte.aufgaben_von(person["id"])
            except ProjektFehler as e:
                self._protokoll(f"Erinnerungsmail: Aufgaben nicht lesbar: {e}")
        return wer, inhalt_sammeln(wer, daten, aufgaben, heute, personen)
