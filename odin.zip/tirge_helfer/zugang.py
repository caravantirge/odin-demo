"""
Zugangsdaten für die Syscara-Schnittstelle – nur auf diesem Rechner, nie im Ordner „Fahrzeuge“ (OneDrive).

- Windows: Passwort mit DPAPI verschlüsselt (nur dieses Windows-Benutzerkonto kann es lesen),
  in syscara-zugang.json im Einstellungsordner.
- Mac: Passwort im Schlüsselbund (Eintrag „ODIN Syscara“, Base64 – sonst gibt „security“ Sonderzeichen wie „€“
  als Hex-Zahlen zurück); in der Datei steht nur der Benutzername.
- Gibt es keinen sicheren Speicher (Schlüsselbund gesperrt, Linux …), merkt ODIN sich den Zugang nur bis zum Schließen
  (im Arbeitsspeicher) – nie mehr als Datei mit bloß kodiertem Passwort.
- Ältere Dateien mit kodiertem Passwort (art „datei“) werden beim Laden in den sicheren Speicher übernommen und dann
  ersetzt. Geht das nicht, wird die Datei weiter gelesen (niemand wird ausgesperrt), aber nicht mehr geschrieben –
  status() meldet das als Warnung.
"""

import base64
import json
import os
import subprocess
import sys

from .einstellungen import einstellungsordner

DATEI = "syscara-zugang.json"
DIENST = "ODIN Syscara"
NUR_SITZUNG = "Sitzung"
HINWEIS_SITZUNG = ("Auf diesem Rechner gibt es keinen sicheren Speicher – der Zugang wird nur bis zum Schließen von "
                   "ODIN gemerkt.")
HINWEIS_ALTDATEI = ("Der Zugang liegt noch in einer älteren, nicht verschlüsselten Datei. Bitte unter Windows oder mit "
                    "entsperrtem Mac-Schlüsselbund neu speichern – dann wird die Datei ersetzt.")

_sitzung = {}                       # (ordner, dienst) → (benutzer, passwort): nur bis Programmende, nie auf die Platte


def _plattform() -> str:
    return sys.platform


def sicherer_speicher(plattform: str = None) -> bool:
    """Gibt es hier einen sicheren Speicher (Windows DPAPI, Mac-Schlüsselbund)?"""
    return (plattform or _plattform()) in ("win32", "darwin")


# ---------------- Windows: DPAPI ----------------

def _dpapi(daten: bytes, verschluesseln: bool) -> bytes:
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    funktion = crypt32.CryptProtectData if verschluesseln else crypt32.CryptUnprotectData
    funktion.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                         ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
    funktion.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    puffer = ctypes.create_string_buffer(daten, len(daten))
    ein = DATA_BLOB(len(daten), ctypes.cast(puffer, ctypes.POINTER(ctypes.c_char)))
    aus = DATA_BLOB()
    if not funktion(ctypes.byref(ein), None, None, None, None, 0x1, ctypes.byref(aus)):   # 0x1: keine Rückfrage
        raise OSError(f"Windows-Verschlüsselung fehlgeschlagen (Fehler {ctypes.GetLastError()})")
    try:
        return ctypes.string_at(aus.pbData, aus.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(aus.pbData, ctypes.c_void_p))


# ---------------- Mac: Schlüsselbund ----------------

def _security(*argumente) -> str:
    erg = subprocess.run(["/usr/bin/security", *argumente], capture_output=True, text=True, timeout=20)
    if erg.returncode:
        raise OSError(erg.stderr.strip() or f"security {argumente[0]}: Fehler {erg.returncode}")
    return erg.stdout


# ---------------- gemeinsam ----------------

def _pfad(ordner: str = None) -> str:
    return os.path.join(ordner or einstellungsordner(), DATEI)


def _schreibe(daten: dict, ordner: str = None):
    pfad = _pfad(ordner)
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = pfad + ".tmp"
    with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8") as f:
        json.dump(daten, f, ensure_ascii=False)
    os.replace(tmp, pfad)


def _schluessel(ordner, dienst):
    return (os.path.abspath(ordner or einstellungsordner()), dienst)


def _sicher_ablegen(benutzer: str, passwort: str, ordner, dienst, alt_benutzer: str = "") -> str:
    """Windows: DPAPI, Mac: Schlüsselbund. Gibt „verschlüsselt“/„Schlüsselbund“ zurück, sonst "" (nicht möglich)."""
    plattform = _plattform()
    if plattform == "win32":
        geheim = base64.b64encode(_dpapi(passwort.encode("utf-8"), True)).decode()
        _schreibe({"benutzer": benutzer, "art": "dpapi", "passwort": geheim}, ordner)
        return "verschlüsselt"
    if plattform == "darwin":
        try:
            if alt_benutzer and alt_benutzer != benutzer:
                loesche_schluesselbund(alt_benutzer, dienst)
            _security("add-generic-password", "-U", "-s", dienst, "-a", benutzer, "-w",
                      base64.b64encode(passwort.encode("utf-8")).decode())
            _schreibe({"benutzer": benutzer, "art": "schluesselbund"}, ordner)
            return "Schlüsselbund"
        except (OSError, subprocess.SubprocessError):
            return ""                                       # z. B. Schlüsselbund gesperrt
    return ""


def speichere(benutzer: str, passwort: str, ordner: str = None, dienst: str = DIENST) -> str:
    """Speichert den Zugang. Gibt zurück, wie: „verschlüsselt“, „Schlüsselbund“ oder „Sitzung“ (kein sicherer
    Speicher: nur bis zum Schließen gemerkt, nichts auf der Platte)."""
    benutzer = (benutzer or "").strip()
    if not benutzer or not passwort:
        raise ValueError("Bitte Benutzername und Passwort eingeben.")
    alt = _datei(ordner)
    wie = _sicher_ablegen(benutzer, passwort, ordner, dienst, alt.get("benutzer", ""))
    if wie:
        _sitzung.pop(_schluessel(ordner, dienst), None)
        return wie
    _sitzung[_schluessel(ordner, dienst)] = (benutzer, passwort)
    if alt:                                                 # der alte (evtl. unsichere) Stand gilt nicht mehr
        _entfernen(ordner)
    return NUR_SITZUNG


def _datei(ordner=None) -> dict:
    try:
        with open(_pfad(ordner), encoding="utf-8") as f:
            daten = json.load(f)
    except (OSError, ValueError):
        return {}
    return daten if isinstance(daten, dict) else {}


def _entfernen(ordner=None):
    for pfad in (_pfad(ordner), _pfad(ordner) + ".tmp"):
        try:
            os.remove(pfad)
        except FileNotFoundError:
            pass


def lade(ordner: str = None, dienst: str = DIENST):
    """(benutzer, passwort) oder None, wenn nichts gespeichert ist. Eine ältere Datei mit kodiertem Passwort wird
    dabei – wenn möglich – in den sicheren Speicher übernommen (und damit ersetzt)."""
    if _schluessel(ordner, dienst) in _sitzung:
        return _sitzung[_schluessel(ordner, dienst)]
    daten = _datei(ordner)
    if not daten:
        return None
    benutzer, art = daten.get("benutzer", ""), daten.get("art", "")
    try:
        if art == "dpapi":
            return benutzer, _dpapi(base64.b64decode(daten["passwort"]), False).decode("utf-8")
        if art == "schluesselbund":
            roh = _security("find-generic-password", "-s", dienst, "-a", benutzer, "-w").strip()
            return benutzer, base64.b64decode(roh, validate=True).decode("utf-8")
        if art == "datei":
            passwort = base64.b64decode(daten["passwort"]).decode()
            try:
                _sicher_ablegen(benutzer, passwort, ordner, dienst)     # überschreibt die alte Datei
            except (OSError, ValueError):
                pass                                    # weiter lesen, nicht schreiben – status() warnt
            return benutzer, passwort
    except (OSError, KeyError, ValueError, subprocess.SubprocessError):
        return None
    return None


def status(ordner: str = None, dienst: str = DIENST) -> dict:
    """Wie liegt der Zugang? {"art": "dpapi"|"schluesselbund"|"sitzung"|"datei"|"", "hinweis", "warnung"}.
    „datei“ ist der ältere, unsichere Stand – das ist eine Warnung."""
    if _schluessel(ordner, dienst) in _sitzung:
        return {"art": "sitzung", "hinweis": HINWEIS_SITZUNG, "warnung": False}
    art = _datei(ordner).get("art", "")
    if art == "datei":
        return {"art": "datei", "hinweis": HINWEIS_ALTDATEI, "warnung": True}
    return {"art": art, "hinweis": "", "warnung": False}


def benutzer(ordner: str = None, dienst: str = DIENST) -> str:
    """Nur der Benutzername (ohne den Schlüsselbund zu fragen)."""
    if _schluessel(ordner, dienst) in _sitzung:
        return _sitzung[_schluessel(ordner, dienst)][0]
    try:
        with open(_pfad(ordner), encoding="utf-8") as f:
            return json.load(f).get("benutzer", "")
    except (OSError, ValueError):
        return ""


def loesche_schluesselbund(name: str, dienst: str = DIENST):
    try:
        _security("delete-generic-password", "-s", dienst, "-a", name)
    except (OSError, subprocess.SubprocessError):
        pass


def loesche(ordner: str = None, dienst: str = DIENST):
    _sitzung.pop(_schluessel(ordner, dienst), None)
    name = _datei(ordner).get("benutzer", "")
    if _plattform() == "darwin" and name:
        loesche_schluesselbund(name, dienst)
    _entfernen(ordner)
