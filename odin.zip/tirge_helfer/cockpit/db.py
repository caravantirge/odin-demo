"""
Datenbank des Cockpits (Bestand, Finanzen, Auslieferungen, Werkstatt, Teile) – im Speicher.

Übernommen aus dem muster Cockpit (lib/db.ts). Anders als dort gibt es keine Datei: ODIN liest die Excel-Listen bei
jedem Laden neu ein (die Listen bleiben die Quelle) und baut daraus diese Tabellen. Was ODIN selbst erfasst
(To-dos, geplante Ablösungen, früher auch Vorordern), liegt in einer JSON-Datei im Ordner „Fahrzeuge“ und wird mit eingespielt.
"""

import json
import os
import re
import sqlite3

VORLAGEN = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vorlagen")

SCHEMA = """
CREATE TABLE IF NOT EXISTS vehicles (
  id                INTEGER PRIMARY KEY,
  internal_id       TEXT NOT NULL UNIQUE,   -- z.B. DETKW00182 (Präfix + 5 Stellen, ohne Leerzeichen)
  vin               TEXT,                   -- Fahrgestellnummer
  serien_nr         TEXT,                   -- Seriennummer des Herstellers
  bestell_nr        TEXT,                   -- Bestellnummer beim Werk
  brand             TEXT,                   -- aus dem Präfix abgeleitet, überschreibbar
  model             TEXT,
  category          TEXT,                   -- Kastenwagen / Reisemobil / Wohnwagen
  model_year        INTEGER,
  condition         TEXT,                   -- Neu / Vorführ / Gebraucht
  status            TEXT NOT NULL,          -- Bestand / Reserviert / Verkauft / Ausgeliefert
  location          TEXT,                   -- Standort / Platz
  lieferblock       TEXT,                   -- B1/B2/B3: geplanter Produktions- bzw. Lieferblock
  schluessel_nr     TEXT,                   -- echte Schlüsselnummer, sobald das Fahrzeug da ist
  lieferstatus      TEXT,                   -- geplant / im Werk / angeliefert
  kommission_art    TEXT,                   -- Lager / kommissioniert
  kommission_name   TEXT,                   -- Händler oder Kunde, auf den kommissioniert ist
  jahrgang          INTEGER,                -- Tabellenblatt der Bestandsliste
  arrival_date      TEXT,                   -- Eingang Bestand (ISO)
  purchase_net      REAL,                   -- EK netto
  purchase_gross    REAL,
  extra_cost_net    REAL,                   -- Überführung, Zubehör, Aufbereitung
  list_price_gross  REAL,                   -- VK Liste (brutto), wie in der Bestandsliste geführt
  list_price_net    REAL,                   -- daraus gerechnet
  internet_price    REAL,                   -- aktuell in Syscara inserierter Preis
  fracht            REAL,                   -- Überführung; Pauschale je Fahrzeugart, überschreibbar
  vk_min            REAL,                   -- (EK netto + Fracht) × Faktor
  sold_net          REAL,
  sold_date         TEXT,
  customer          TEXT,
  salesperson       TEXT,
  ausstattung       TEXT,                   -- Sonderausstattung, Zubehör ab Werk
  notes             TEXT,
  caracamp_objekt   TEXT,                   -- Objektnummer aus CaraCamp
  fin_bank          TEXT,                   -- Bank aus der Spalte "Finanziert" ("WF, 08977")
  fin_vertrag       TEXT,                   -- Vertrags-/Objektnummer aus derselben Spalte
  syscara           TEXT,                   -- Inseratsstatus
  source_file       TEXT,
  source_sheet      TEXT,
  updated_at        TEXT
);

CREATE TABLE IF NOT EXISTS financings (
  id                 INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL,
  bank               TEXT NOT NULL,          -- Ostbank, Nordbank, VW Bank, Hausbank ...
  contract_no        TEXT,
  financed_amount    REAL,
  start_date         TEXT,
  interest_free_until TEXT,                  -- "zinsfrei bis"
  interest_rate_pct  REAL,                   -- Zinssatz nach Ablauf zinsfrei
  term_months        INTEGER,
  due_date           TEXT,                   -- spätestes Ablösedatum
  status             TEXT,                   -- offen / abgelöst
  notes              TEXT,
  hersteller         TEXT,                   -- aus dem Blattnamen der Finanzaufstellung („Nord. H1“ → Hersteller1)
  linie              TEXT,                   -- Blatt der Finanzaufstellung = Linie (Bank × Hersteller)
  source_file        TEXT,
  updated_at         TEXT,
  UNIQUE(vehicle_internal_id, bank, contract_no)
);

CREATE TABLE IF NOT EXISTS cash_entries (
  id            INTEGER PRIMARY KEY,
  entry_date    TEXT NOT NULL,
  kind          TEXT NOT NULL,      -- ist / plan
  direction     TEXT NOT NULL,      -- ein / aus
  category      TEXT,               -- Fahrzeugeinkauf, Löhne, Miete, Verkauf ...
  amount        REAL NOT NULL,      -- immer positiv, Richtung steht in direction
  account       TEXT,               -- Bankkonto
  description   TEXT,
  vehicle_internal_id TEXT,
  source_file   TEXT
);

CREATE TABLE IF NOT EXISTS commissions (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT,
  salesperson   TEXT NOT NULL,
  sale_date     TEXT,
  basis_amount  REAL,               -- Bemessungsgrundlage (z.B. Deckungsbeitrag)
  rate_pct      REAL,
  amount        REAL,
  status        TEXT,               -- offen / ausgezahlt
  payout_date   TEXT,
  source_file   TEXT
);

CREATE TABLE IF NOT EXISTS deliveries (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL,
  planned_date  TEXT,
  actual_date   TEXT,
  customer      TEXT,
  city          TEXT,
  status        TEXT,               -- geplant / bestätigt / ausgeliefert / verschoben
  checklist_open TEXT,              -- offene Punkte vor Übergabe
  verkaeufer    TEXT,               -- steckt in der Schriftfarbe des Kundennamens
  termin_art    TEXT,               -- Kundenabholung / extern / Verbringung
  vertragsdatum TEXT,
  fahrzeugart   TEXT,               -- neu / gebraucht
  verfuegbarkeit TEXT,              -- auf Lager / im Werk fertig / im Werk offen
  tuev_faellig  INTEGER,            -- 1 = vor Auslieferung noch TÜV nötig
  papiere_status TEXT,              -- beim Kunden / im Werk / bei uns
  papiere_text  TEXT,               -- "Brief Kunde 14.09.", "Brief/Ausnahme wir"
  zahlart       TEXT,               -- AB (Auftragsbestätigung) / VDR (Rechnung)
  zahlstatus    TEXT,               -- offen / angezahlt / bezahlt
  anzahlung     REAL,
  inzahlungnahme_fzg TEXT,          -- Fahrzeug, das der Kunde in Zahlung gibt
  inzahlungnahme_wert REAL,
  inzahlungnahme_da INTEGER,        -- 1 = Fahrzeug ist bereits bei uns
  werk_bezahlt  INTEGER,            -- 1 = von uns ans Werk bezahlt
  bemerkung     TEXT,
  uhrzeit       TEXT,               -- Uhrzeit der Übergabe („10:30“), falls im Termin genannt
  source_file   TEXT,
  source_sheet  TEXT,               -- Blatt und Excel-Zeile: Hinweis für „In ODIN arbeiten“ (Aktionen)
  zeile         INTEGER
);

CREATE TABLE IF NOT EXISTS tilgungen (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL,
  bank          TEXT,
  faellig_am    TEXT NOT NULL,
  betrag        REAL NOT NULL,
  bezahlt_am    TEXT,
  source_file   TEXT,
  UNIQUE(vehicle_internal_id, faellig_am, betrag)
);

CREATE TABLE IF NOT EXISTS bank_linien (
  id            INTEGER PRIMARY KEY,
  bank          TEXT NOT NULL,
  hersteller    TEXT NOT NULL,        -- je Bank und Hersteller ein Blatt, also auch eine Linie
  zins_pct      REAL,                 -- verhandelter Zins nach Ablauf der zinsfreien Zeit
  zinsfrei_monate INTEGER,
  limit_betrag  REAL,                 -- vereinbartes Gesamtvolumen
  hinweis       TEXT,
  linie         TEXT,                 -- Blattname in der Finanzaufstellung, z. B. „Nord. H1“
  konditionen   TEXT,                 -- Text unter dem Limit, z. B. „3,25 %=2,50 % · plus Bereitstellung 0,40 % p. a.“
  source_file   TEXT,
  UNIQUE(bank, hersteller)
);

-- Kommende Fahrzeuge: bestellt, noch nicht da, belasten die Linie aber schon (unten im Linienblatt der
-- Finanzaufstellung). Rechnungsdatum steht dort als „KW 49/2026“ oder „Okt/Nov“, Zinsfrei als „360 Tage“.
CREATE TABLE IF NOT EXISTS kommende_fahrzeuge (
  id            INTEGER PRIMARY KEY,
  bank          TEXT NOT NULL,
  hersteller    TEXT NOT NULL,
  linie         TEXT,                 -- Blattname
  kommission    TEXT,                 -- wie in der Datei: „Lager, DRM00309“, „Kunde Fernkorn“
  kommission_art TEXT,                -- Lager / Kommission
  kunde         TEXT,                 -- Händler oder Kunde, auf den kommissioniert ist
  internal_id   TEXT,                 -- interne Nummer, falls schon vergeben
  modell        TEXT,
  termin_text   TEXT,                 -- so wie in der Datei: „KW 49/2026“, „Jan/Apr“
  termin_datum  TEXT,                 -- grob, nur zum Sortieren: Montag der KW bzw. Erster des ersten Monats
  konditionen   TEXT,                 -- „360 Tage“, „Westbank 1% Skonto“
  betrag        REAL,                 -- Finanzierungsbetrag (sonst EK netto)
  ek_netto      REAL,
  source_file   TEXT,
  source_sheet  TEXT,
  zeile         INTEGER
);

-- Zu erwartende Zahlungen: Geld, das noch hereinkommt – vor allem Kundenfinanzierungen, bei denen die Bank noch
-- nicht an uns ausgezahlt hat. Steht im ersten Blatt der Finanzaufstellung (laufender Liquiditätsplan) als Freitext
-- („<Kunde> <Modell> Finanzierung“, Betrag daneben) oder in einem Block „zu erwartende Zahlungen“ mit Spaltenköpfen.
CREATE TABLE IF NOT EXISTS erwartete_zahlungen (
  id            INTEGER PRIMARY KEY,
  kunde         TEXT,
  fahrzeug      TEXT,                 -- Modell bzw. Kommission, wie in der Datei
  internal_id   TEXT,                 -- interne Nummer, falls in der Zeile erkennbar
  art           TEXT,                 -- Finanzierung / Überweisung / Anzahlung / Restzahlung / Bar / Zahlung
  bank          TEXT,                 -- bei Finanzierungen, falls genannt
  betrag        REAL,
  erwartet_am   TEXT,                 -- ISO-Datum, falls erkennbar
  erwartet_text TEXT,                 -- so wie in der Datei („bis 12.12.“, „nach Zulassung“)
  status        TEXT,                 -- „Bank zahlt noch aus“ / „offen“ / „eingegangen“
  offen         INTEGER NOT NULL DEFAULT 1,
  bemerkung     TEXT,
  text          TEXT,                 -- die ganze Zeile als Text, zum Nachlesen
  source_file   TEXT,
  source_sheet  TEXT,
  zeile         INTEGER
);

CREATE TABLE IF NOT EXISTS zulassungsfristen (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL UNIQUE,
  ausnahme_art  TEXT,               -- z.B. Stellantis EURO 6 (EA), GSRII Euro VI
  frist         TEXT,               -- bis zu diesem Tag muss zugelassen sein
  hinweis       TEXT,
  source_file   TEXT
);

CREATE TABLE IF NOT EXISTS werkstattauftraege (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL,
  arbeitskarte  TEXT,
  art           TEXT,               -- Auslieferung / Serviceauftrag
  termin        TEXT,
  geplante_minuten INTEGER,
  teilestatus   TEXT,               -- nicht bestellt / bestellt / teilweise geliefert /
                                    -- geliefert / teilweise im Fahrzeug / alle im Fahrzeug
  tankstatus    TEXT,               -- offen / in Arbeit / fertig getankt
  monteur       TEXT,
  bemerkung     TEXT,
  source_file   TEXT
);

-- Freitextzeilen der Auslieferungsliste (gelb, ohne Status und Kunde): Fahrten zu Werkstattpartnern, Hinweise
-- für einen Tag, Lehrgänge. Ohne Datum gilt die Kalenderwoche des Blocks (datum = Montag, ganze_woche = 1).
CREATE TABLE IF NOT EXISTS sonderfahrten (
  id            INTEGER PRIMARY KEY,
  datum         TEXT,
  bis           TEXT,               -- letzter Tag (Lehrgang „16.11. - 19.11.“, ganze Woche)
  ganze_woche   INTEGER DEFAULT 0,
  kw            INTEGER,
  art           TEXT,               -- sonderfahrt / hinweis / lehrgang
  text          TEXT NOT NULL,
  arbeitskarte  TEXT,
  pruefen       INTEGER DEFAULT 0,  -- 1 = Wochentag passt nicht zum Datum
  source_file   TEXT
);

CREATE TABLE IF NOT EXISTS einbauten (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL,
  position      TEXT NOT NULL,      -- AHK starr / AHK abnehmbar / Unterboden & Hohlraum / Sondereinbau
  beschreibung  TEXT,
  status        TEXT,               -- offen / beim Einbaupartner / erledigt
  source_file   TEXT,
  UNIQUE(vehicle_internal_id, position)
);

CREATE TABLE IF NOT EXISTS mitarbeiter (
  id            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL UNIQUE,
  bereich       TEXT,               -- Werkstatt / Waschplatz / Shop / Verkauf
  minuten_pro_tag INTEGER,          -- 8 Stunden = 480 Minuten
  auslieferung  INTEGER,            -- 1 = für Auslieferungen im Verkauf zuständig
  aktiv         INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS abwesenheiten (
  id            INTEGER PRIMARY KEY,
  mitarbeiter   TEXT NOT NULL,
  datum         TEXT NOT NULL,
  art           TEXT,               -- Urlaub / Feiertag / gesperrt
  bereich       TEXT,
  source_file   TEXT,
  UNIQUE(mitarbeiter, datum)
);

CREATE TABLE IF NOT EXISTS parts (
  id               INTEGER PRIMARY KEY,
  sku              TEXT UNIQUE,     -- interner Code, sonst aus Datei und Zeile gebildet
  code             TEXT,            -- interner Code, z.B. SA00100
  artikel_nr       TEXT,            -- Lieferantennummer (Movera)
  name             TEXT NOT NULL,
  fahrzeugtyp      TEXT,            -- Abschnitt der Liste, z.B. "Kastenwagen H2 Dach"
  typ_neu          TEXT,            -- feste Einteilung (fahrzeugtypen.py) aus der Zuordnung; leer = nicht zugeordnet
  warengruppe      TEXT,            -- Markisen, Solar, AHK ...
  produkt          TEXT,            -- Bezeichnung der Gruppe
  variante         TEXT,            -- weiß, silber, anthrazit ...
  category         TEXT,
  supplier         TEXT,
  movera_link      TEXT,
  gewicht          TEXT,
  set_preis        REAL,
  preis_brutto     REAL,
  einzelteil_vk    REAL,
  kleinteile       REAL,
  lohn_vk          REAL,            -- Lohnanteil brutto = AW × VK je AW
  vk_pro_aw        REAL,
  aw               REAL,            -- Arbeitswerte, 1 AW = 6 Minuten
  purchase_net     REAL,            -- EK netto des Teils
  sales_net        REAL,            -- VK netto des Teils
  vk_brutto        REAL,            -- Verkaufspreis brutto, so wie er in der Liste steht
  lohn_ek          REAL,            -- interne Lohnkosten inkl. Kleinteile
  gesamt_ek_brutto REAL,            -- (Teil-EK + Lohn-EK) × MwSt
  install_minutes  INTEGER,         -- Montagezeit
  hourly_rate      REAL,            -- Stundenverrechnungssatz
  hinweis          TEXT,            -- Anmerkung aus der Liste, z.B. Voraussetzungen
  gehoert_zu       TEXT,            -- Stückliste: sku des Set-Artikels, mit dem diese Position bestellt wird
  menge            REAL,            -- Stückliste: Menge je Set (die Teileliste hat dafür keine Spalte: 1)
  source_file      TEXT,
  source_sheet     TEXT,
  zeile            INTEGER          -- Excel-Zeile in der Teileliste (für „In ODIN arbeiten“)
);

CREATE TABLE IF NOT EXISTS artikelstamm (
  artikel_nr    TEXT PRIMARY KEY,
  bezeichnung   TEXT,
  bestand       REAL,
  stamm_ek      REAL,
  stamm_vk      REAL,
  source_file   TEXT
);

CREATE TABLE IF NOT EXISTS import_runs (
  id           INTEGER PRIMARY KEY,
  source_file  TEXT NOT NULL,
  mapping      TEXT NOT NULL,
  sheet        TEXT,
  rows_read    INTEGER,
  rows_written INTEGER,
  warnings     TEXT,
  ran_at       TEXT
);

CREATE TABLE IF NOT EXISTS vororder (
  id            INTEGER PRIMARY KEY,
  bezeichnung   TEXT NOT NULL,               -- Modell oder Beschreibung der Vororder
  hersteller    TEXT NOT NULL,               -- entscheidet, welche Linie belastet wird
  bank          TEXT NOT NULL,               -- Linie, auf der die Vororder laufen soll
  kategorie     TEXT,                        -- Kastenwagen / Reisemobil / Wohnwagen
  anzahl        INTEGER NOT NULL DEFAULT 1,
  ek_netto      REAL NOT NULL,               -- geplanter Einkaufspreis netto je Fahrzeug
  liefertermin  TEXT NOT NULL,               -- ab diesem Tag belastet die Vororder die Linie
  status        TEXT NOT NULL DEFAULT 'geplant',  -- geplant / bestellt / geliefert / storniert
  internal_id   TEXT,                        -- sobald das Fahrzeug eine interne Nummer hat
  bemerkung     TEXT,
  angelegt_am   TEXT
);

CREATE TABLE IF NOT EXISTS abloesungen (
  id            INTEGER PRIMARY KEY,
  vehicle_internal_id TEXT NOT NULL UNIQUE,  -- je Fahrzeug eine geplante Ablösung
  bank          TEXT,
  geplant_am    TEXT NOT NULL,               -- an diesem Tag wird die Linie frei
  betrag        REAL,                        -- was abgelöst wird; leer = offener Betrag
  grund         TEXT,                        -- z.B. "Linie für Vororder frei machen"
  erledigt      INTEGER NOT NULL DEFAULT 0,
  angelegt_am   TEXT
);

CREATE TABLE IF NOT EXISTS cashback_termine (
  datum         TEXT NOT NULL,               -- Einreichungsfrist oder Tag zum Nachhaken (aus den Cashback-Listen)
  titel         TEXT NOT NULL,
  text          TEXT,
  ton           TEXT,
  betrag        REAL
);

CREATE TABLE IF NOT EXISTS betriebsfristen (
  id            INTEGER PRIMARY KEY,
  titel         TEXT NOT NULL,               -- z. B. Prüfung Hebebühnen (aus ODINs Fristenkalender)
  kategorie     TEXT,
  faellig_am    TEXT,
  verantwortlich TEXT
);

CREATE TABLE IF NOT EXISTS todos (
  id           INTEGER PRIMARY KEY,
  text         TEXT NOT NULL,
  bereich      TEXT,                        -- Bestand / Finanzierung / Auslieferung / Werkstatt / Teile / Allgemein
  bezug_id     TEXT,                        -- interne Fahrzeugnummer, falls die Aufgabe an einem Fahrzeug hängt
  faellig_am   TEXT,                        -- ISO-Datum, optional
  prioritaet   TEXT,                        -- hoch / normal / niedrig
  erledigt     INTEGER NOT NULL DEFAULT 0,
  erledigt_am  TEXT,
  angelegt_von TEXT,
  angelegt_am  TEXT
);

CREATE INDEX IF NOT EXISTS idx_vor_termin ON vororder(liefertermin);
CREATE INDEX IF NOT EXISTS idx_veh_status ON vehicles(status);
CREATE INDEX IF NOT EXISTS idx_fin_veh ON financings(vehicle_internal_id);
CREATE INDEX IF NOT EXISTS idx_kommend_linie ON kommende_fahrzeuge(bank, hersteller);
CREATE INDEX IF NOT EXISTS idx_cash_date ON cash_entries(entry_date);
CREATE INDEX IF NOT EXISTS idx_del_veh ON deliveries(vehicle_internal_id);
CREATE INDEX IF NOT EXISTS idx_til_faellig ON tilgungen(faellig_am);
CREATE INDEX IF NOT EXISTS idx_wst_termin ON werkstattauftraege(termin);
CREATE INDEX IF NOT EXISTS idx_abw_datum ON abwesenheiten(datum);
CREATE INDEX IF NOT EXISTS idx_parts_set ON parts(gehoert_zu);
"""


def neue_db() -> sqlite3.Connection:
    """Leere Cockpit-Datenbank im Speicher; Zeilen kommen als sqlite3.Row (Zugriff über Spaltennamen)."""
    verbindung = sqlite3.connect(":memory:", check_same_thread=False)
    verbindung.row_factory = sqlite3.Row
    verbindung.executescript(SCHEMA)
    return verbindung


def lade_vorlage(name: str) -> dict:
    """JSON aus vorlagen/ (z. B. 'praefixe', 'farben', 'mappings/bestandsliste')."""
    with open(os.path.join(VORLAGEN, name + ".json"), encoding="utf-8") as f:
        return json.load(f)


def normalize_internal_id(roh) -> str:
    """'detkw182', 'DETKW-00182', 'DETKW 182' -> 'DETKW00182'."""
    bereinigt = re.sub(r"[^A-Z0-9]", "", str(roh).upper())
    m = re.fullmatch(r"([A-Z]+)(\d+)", bereinigt)
    if not m:
        return str(roh).strip().upper()
    return f"{m.group(1)}{m.group(2).zfill(5)}"


_STAMMDATEN = {}


def _stammdaten() -> dict:
    if not _STAMMDATEN:
        roh = lade_vorlage("praefixe")
        werkstatt = roh.get("_werkstatt") or {}
        _STAMMDATEN.update(praefixe=roh["praefixe"], parameter={
            "fracht": roh["_fracht_pauschale"], "vk_min_faktor": roh["_vk_min_faktor"], "mwst": roh["_mwst"],
            "minuten_pro_tag": werkstatt.get("minuten_pro_tag", 480),
            "planbarer_anteil": werkstatt.get("planbarer_anteil", 1)})
    return _STAMMDATEN


def praefix_info(internal_id: str):
    """Marke und Fahrzeugart aus dem Präfix der internen Nummer: {'marke': …, 'kategorie': …} oder None."""
    praefix = re.sub(r"[^A-Z]", "", str(internal_id).upper())
    return _stammdaten()["praefixe"].get(praefix)


def parameter() -> dict:
    return _stammdaten()["parameter"]


def fracht_fuer(kategorie, eigener=None) -> float:
    """Frachtpauschale der Fahrzeugart, überschreibbar durch einen Wert am Fahrzeug."""
    if eigener is not None and eigener > 0:
        return eigener
    p = parameter()["fracht"]
    return p.get(kategorie or "", p.get("_standard", 0))
