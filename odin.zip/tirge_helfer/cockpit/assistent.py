"""
Frage-Assistent des Cockpits („Wo ist DETKW00182 finanziert?“) – übernommen aus dem muster Cockpit
(lib/assistant.ts, nur Stufe 1).

Das Original hatte zwei Stufen: ein Regelwerk und optional Claude über die API. ODIN übernimmt nur das
Regelwerk – es werden keine Daten an einen Dienst geschickt, alles bleibt auf dem Rechner. Erkannte Fragemuster
werden direkt aus der Datenbank beantwortet; jede Zahl in einer Antwort kommt aus einer Abfrage. Erkennt das
Regelwerk eine Frage nicht, sagt es das und nennt Beispielfragen statt zu raten.

Gegenüber dem Original zusätzlich: Fragen nach einem Monat („im Oktober“) bei Tilgungen, die Zulassungsfrist eines
einzelnen Fahrzeugs und unbekannte Fahrzeugnummern mit bekanntem Präfix („DETKW99999“ gibt es nicht).

Datenschutz im Betrieb: Der Assistent beantwortet nur, was gefragt ist – keine Brücken zu Angaben, nach denen
niemand gefragt hat („Wie viele Wohnwagen?“ nennt die Anzahl, nicht den Einkaufswert). Finanzzahlen (Liquidität,
Provisionen, Tilgungen, Finanzierung und Zinsfreiheit, Einkaufs-, Listen- und Verkaufspreise, Deckungsbeitrag,
gebundenes Kapital) nennt er nur, wenn die fragende Person sie sehen darf (`finanzen=True`); sonst sagt er kurz ab.
Werkstattaufträge laufen über CaraCamp; danach gefragt, sagt er genau das. Bei Rat-Fragen („Kunde sagt zu teuer“,
„Wie entscheide ich mich …?“, „Was würde Buffett sagen?“) zeigt er den Weg in „Beirat & Coaching“ (beirat.py).
Geht es um eine verbindliche Hausregel („Kann ich den Neuwagen reservieren?“, „Darf ich eine Probefahrt anbieten?“),
antwortet er vor allem anderen mit der Regel, der Kundenformulierung und dem Verweis (hausregeln.py).
"""

import datetime as dt
import math
import re
from decimal import ROUND_HALF_UP, Decimal

from .. import beirat, hausregeln
from . import auswertungen as a
from . import fahrzeugtypen as ft
from .db import _stammdaten, normalize_internal_id

# --------------------------------------------------------------------------- Formate (lib/format.ts)

_MONATE_KURZ = ["Jan.", "Feb.", "März", "Apr.", "Mai", "Juni", "Juli", "Aug.", "Sept.", "Okt.", "Nov.", "Dez."]
MONATSNAMEN = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
               "November", "Dezember"]


def _leer(n) -> bool:
    return n is None or (isinstance(n, float) and (math.isnan(n) or math.isinf(n)))


def _zahl_text(n, stellen: int, feste_stellen: bool) -> str:
    # Wie Intl.NumberFormat: kaufmännisch gerundet, Tausenderpunkt, Dezimalkomma
    d = Decimal(repr(float(n))).quantize(Decimal(1).scaleb(-stellen), rounding=ROUND_HALF_UP)
    vorzeichen = "-" if d < 0 else ""
    ganz, _, rest = f"{abs(d):f}".partition(".")
    if not feste_stellen:
        rest = rest.rstrip("0")
    return vorzeichen + f"{int(ganz):,}".replace(",", ".") + ("," + rest if rest else "")


def eur(n, stellen=0) -> str:
    return "–" if _leer(n) else _zahl_text(n, stellen, True) + " €"


def zahl(n, stellen=0) -> str:
    return "–" if _leer(n) else _zahl_text(n, stellen, False)


def datum(iso) -> str:
    if not iso:
        return "–"
    t = dt.date.fromisoformat(str(iso)[:10])
    return f"{t.day:02d}.{t.month:02d}.{t.year}"


def monats_label(ym: str) -> str:
    """'2026-10' -> 'Okt. 26'"""
    jahr, monat = (int(x) for x in ym.split("-")[:2])
    return f"{_MONATE_KURZ[monat - 1]} {jahr % 100:02d}"


def tage_text(n) -> str:
    """'1 Tag' statt '1 Tage'."""
    return f"{zahl(abs(n))} {'Tag' if abs(n) == 1 else 'Tage'}"


def tagen_dativ(n) -> str:
    """Dativform: 'seit 3 Tagen'."""
    return f"{zahl(abs(n))} {'Tag' if abs(n) == 1 else 'Tagen'}"


def anzahl(n: int, einzahl: str, mehrzahl: str) -> str:
    """'1 Auslieferung' statt '1 Auslieferungen'."""
    return f"{n} {einzahl if n == 1 else mehrzahl}"


def _nicht_gefunden(fid: str) -> str:
    return (f"Zu {fid} liegt kein Fahrzeug in der Datenbank. Prüfe die interne Nummer oder lies die aktuelle "
            "Bestandsliste ein.")


def _tabelle_leer(db, tabelle: str) -> bool:
    return db.execute(f"SELECT 1 FROM {tabelle} LIMIT 1").fetchone() is None


# Antworten mit Finanzzahlen – nur für Berechtigte. Ohne Berechtigung kommt statt der Antwort ABSAGE.
ABSAGE = "Zu Finanzzahlen gebe ich hier nur Berechtigten Auskunft."
VERTRAULICH = {"liquiditaet", "provisionen", "tilgungen", "kennzahlen", "zinsfrei_ablauf", "erwartete_zahlungen"}
WERKSTATT_TEXT = "Werkstattaufträge laufen über CaraCamp."


def absage() -> dict:
    return {"text": ABSAGE, "daten": None, "werkzeug": "vertraulich", "modus": "regel", "ziel": ""}


# ------------------------------------------------------------------------------- Werkzeuge
# Jedes Werkzeug: (db, stichtag, **eingabe) -> {"text", "daten"}. Die Namen sind dieselben wie im Original,
# damit die Oberfläche („Datenabfrage: fahrzeug_details“) unverändert bleibt.


def _offene_finanzierung(details):
    fin = details["financings"]
    return next((f for f in fin if f["status"] == "offen"), fin[0] if fin else None)


def fahrzeug_details(db, stichtag, internal_id, finanzen=False):
    """Steckbrief eines Fahrzeugs. Einkauf, Listenpreis, Finanzierung, Verkaufspreis und Kunde nur mit 'finanzen'."""
    fid = normalize_internal_id(internal_id)
    d = a.get_vehicle(db, fid)
    if not d:
        return {"text": _nicht_gefunden(fid)}
    v = d["vehicle"]
    f = _offene_finanzierung(d)
    st = a.standtage(v, stichtag)
    zeilen = [
        f"{v['internal_id']} – {v['brand'] or ''} {v['model'] or ''} ({v['category'] or '-'}, {v['condition'] or '-'}, "
        f"MJ {v['model_year'] or '-'})",
        f"Status: {v['status']}" + (f", Standort {v['location']}" if v["location"] else "")
        + (f", {st} Standtage" if st is not None else ""),
    ]
    if finanzen:
        zeilen += [
        f"Einkauf netto: {eur(v['purchase_net'])}"
        + (f" + {eur(v['extra_cost_net'])} Nebenkosten (Überführung/Zubehör) = "
           f"{eur((v['purchase_net'] or 0) + v['extra_cost_net'])}" if v["extra_cost_net"] else ""),
        f"Listenpreis netto: {eur(v['list_price_net'])}",
        (f"Finanzierung: {f['bank']}, Vertrag {f['contract_no'] or '-'}, {eur(f['financed_amount'])}, "
         f"zinsfrei bis {datum(f['interest_free_until'])}"
         + (f" (danach {zahl(f['interest_rate_pct'], 1)} % p. a.)" if f["interest_rate_pct"] else "")
         + f", Status {f['status']}") if f else "Finanzierung: keine hinterlegt (Bareinkauf)",
        ]
    if v["sold_date"]:
        zeilen.append(f"Verkauft am {datum(v['sold_date'])}"
                      + (f" für {eur(v['sold_net'])} an {v['customer'] or '-'}" if finanzen else ""))
    lieferung = d["delivery"]
    if lieferung:
        zeilen.append("Auslieferung: " + (f"erfolgt am {datum(lieferung['actual_date'])}" if lieferung["actual_date"]
                                          else f"geplant {datum(lieferung['planned_date'])} ({lieferung['status']})")
                      + (f", offen: {lieferung['checklist_open']}" if lieferung["checklist_open"] else ""))
    if v["notes"] and finanzen:                      # Notizen der Bestandsliste stehen oft neben Preisen
        zeilen.append(f"Notiz: {v['notes']}")
    return {"text": "\n".join(zeilen), "daten": d if finanzen else None}


MEHRZAHL = {"Reisemobil": "Reisemobile", "Wohnwagen": "Wohnwagen", "Kastenwagen": "Kastenwagen"}


def bestand_zaehlen(db, stichtag, marke=None, kategorie=None, mit_wert=False):
    """Anzahl im Bestand. Den gebundenen Einkaufswert nur mit 'mit_wert' – also wenn danach gefragt wurde und die
    Person Finanzzahlen sehen darf."""
    if _tabelle_leer(db, "vehicles"):
        return {"text": "Es ist noch keine Bestandsliste eingelesen – dazu kann ich nichts sagen.", "daten": None}
    r = a.count_stock(db, brand=marke, category=kategorie)
    kat = (kategorie if r["anzahl"] == 1 else MEHRZAHL.get(kategorie, kategorie)) if kategorie else None
    was = " ".join(x for x in (marke, kat) if x) or ("Fahrzeug" if r["anzahl"] == 1 else "Fahrzeuge")
    if mit_wert:
        return {"text": f"{r['anzahl']} {was} im Bestand, gebundener Einkaufswert {eur(r['wert'])}.", "daten": r}
    return {"text": f"{r['anzahl']} {was} im Bestand.", "daten": {"anzahl": r["anzahl"]}}


def zinsfrei_ablauf(db, stichtag, tage=60):
    t = int(tage)
    rows = a.interest_free_expiring(db, stichtag, t)
    if not rows:
        return {"text": f"In den nächsten {t} Tagen läuft keine zinsfreie Finanzierung aus.", "daten": []}
    abgelaufen = [r for r in rows if r["tage_bis_ablauf"] < 0]
    kopf = (f"{anzahl(len(rows), 'Finanzierung', 'Finanzierungen')} "
            f"({eur(sum(r['financed_amount'] or 0 for r in rows))}), davon {len(abgelaufen)} bereits abgelaufen "
            "und damit verzinst:")
    liste = [f"• {r['vehicle_internal_id']} – {r['bank']}, {eur(r['financed_amount'])}, zinsfrei bis "
             f"{datum(r['interest_free_until'])} ("
             + (f"seit {tagen_dativ(r['tage_bis_ablauf'])} verzinst" if r["tage_bis_ablauf"] < 0
                else f"noch {tage_text(r['tage_bis_ablauf'])}") + ")" for r in rows[:15]]
    return {"text": "\n".join([kopf, *liste]), "daten": rows}


def bestandsliste(db, stichtag, marke=None, kategorie=None, suche=None, finanzen=False):
    rows = a.list_vehicles(db, status="bestand", brand=marke, category=kategorie, search=suche, limit=40)
    if not rows:
        return {"text": "Keine passenden Fahrzeuge im Bestand.", "daten": []}
    liste = [f"• {v['internal_id']} – {v['brand']} {v['model']}, {v['status']}, "
             + (f"EK {eur(v['purchase_net'])}, " if finanzen else "")
             + f"{a.standtage(v, stichtag)} Standtage" for v in rows[:20]]
    return {"text": "\n".join([f"{anzahl(len(rows), 'Treffer', 'Treffer')}:", *liste]),
            "daten": rows if finanzen else None}


def liquiditaet(db, stichtag, monate_zurueck=3, monate_voraus=3):
    rows = a.cash_series(db, stichtag, int(monate_zurueck), int(monate_voraus))
    if not rows:
        return {"text": "Für diesen Zeitraum liegen keine Liquiditätszahlen vor – ist die Finanzplanung eingelesen?",
                "daten": []}
    liste = [f"• {monats_label(r['monat'])} ({'Ist' if r['ist'] else 'Plan'}): ein {eur(r['ein'])}, "
             f"aus {eur(r['aus'])}, netto {eur(r['netto'])}, "
             f"Saldo {eur(r['saldo_ist'] if r['saldo_ist'] is not None else r['saldo_plan'])}" for r in rows]
    tief = min(r["saldo_ist"] if r["saldo_ist"] is not None else r["saldo_plan"] for r in rows)
    return {"text": "\n".join([*liste, f"Tiefster Saldo im Zeitraum: {eur(tief)}."]), "daten": rows}


def erwartete_zahlungen(db, stichtag, nur_finanzierung=False):
    """Zu erwartende Zahlungen aus der Finanzaufstellung; mit nur_finanzierung nur die Kundenfinanzierungen, die die
    Bank noch nicht ausgezahlt hat."""
    if _tabelle_leer(db, "erwartete_zahlungen"):
        return {"text": "Es liegen keine zu erwartenden Zahlungen vor – ist die Finanzaufstellung eingelesen?",
                "daten": []}
    rows = [r for r in a.erwartete_zahlungen(db, stichtag) if r["offen"]
            and (not nur_finanzierung or r["art"] == "Finanzierung")]
    if not rows:
        return {"text": "Keine Finanzierung wartet auf die Auszahlung der Bank." if nur_finanzierung
                else "Keine offenen zu erwartenden Zahlungen.", "daten": []}
    summe = sum(r["betrag"] or 0 for r in rows)
    ohne = sum(1 for r in rows if r["betrag"] is None)
    if nur_finanzierung:
        kopf = (f"{anzahl(len(rows), 'Finanzierung ist', 'Finanzierungen sind')} noch nicht ausgezahlt, zusammen "
                f"{eur(summe)}:")
    else:
        fin = [r for r in rows if r["art"] == "Finanzierung"]
        kopf = (f"{anzahl(len(rows), 'Zahlung', 'Zahlungen')} erwartet, zusammen {eur(summe)} – davon "
                f"{anzahl(len(fin), 'Finanzierung', 'Finanzierungen')} über {eur(sum(r['betrag'] or 0 for r in fin))}, "
                "die die Bank noch nicht ausgezahlt hat:")

    def zeile(r):
        teile = [" ".join(x for x in (r["kunde"], r["fahrzeug"]) if x) or "–"]
        if not nur_finanzierung:
            teile.append(r["art"])
        if r["bank"]:
            teile.append(r["bank"])
        teile.append(eur(r["betrag"]) if r["betrag"] is not None else "Betrag offen")
        if r["erwartet_am"]:
            teile.append(("war erwartet am " if r["ueberfaellig"] else "erwartet ") + datum(r["erwartet_am"]))
        elif r["erwartet_text"]:
            teile.append(r["erwartet_text"])
        if r["uebergabe"]:
            teile.append(f"Übergabe {datum(r['uebergabe']['planned_date'])}")
        return "• " + ", ".join(teile)
    liste = [zeile(r) for r in rows[:15]]
    if len(rows) > 15:
        liste.append(f"… und {len(rows) - 15} weitere (Finanzen → Liquidität)")
    if ohne:
        liste.append(f"{anzahl(ohne, 'Zeile hat', 'Zeilen haben')} keinen Betrag in der Finanzaufstellung.")
    return {"text": "\n".join([kopf, *liste]), "daten": rows}


def provisionen(db, stichtag, status=None):
    rows = a.commissions(db, status)
    if not rows:
        return {"text": "Keine Provisionen gefunden.", "daten": []}
    summe = sum(r["amount"] or 0 for r in rows)
    liste = [f"• {r['vehicle_internal_id']} – {r['salesperson']}, {eur(r['amount'])} ({zahl(r['rate_pct'], 1)} %), "
             f"{r['status']}" for r in rows[:15]]
    return {"text": "\n".join([f"{anzahl(len(rows), 'Provision', 'Provisionen')}, Summe {eur(summe)}:", *liste]),
            "daten": rows}


def auslieferungen(db, stichtag, tage=45):
    rows = a.upcoming_deliveries(db, stichtag, int(tage))
    if not rows:
        return {"text": "Keine offenen Auslieferungen im Zeitraum.", "daten": []}
    liste = [f"• {datum(r['planned_date'])} – {r['vehicle_internal_id']} ({r['brand'] or ''} {r['model'] or ''}) "
             f"an {r['customer']}, {r['city']}, {r['status']}"
             + (f", offen: {r['checklist_open']}" if r["checklist_open"] else "") for r in rows]
    return {"text": "\n".join([f"{anzahl(len(rows), 'Auslieferung', 'Auslieferungen')} geplant:", *liste]),
            "daten": rows}


def teile_und_montage(db, stichtag, suchbegriff):
    treffer = a.search_parts(db, str(suchbegriff))
    # Ganze Wörter vor Wortanfängen vor beliebigen Treffern: „Sat“ soll nicht „E-Satz“ oder „Zusatz“ finden,
    # „Solar“ aber weiter „Solaranlage“
    begriff = re.escape(str(suchbegriff).lower())
    rows = treffer
    for muster in (rf"(?<![a-zäöüß]){begriff}(?![a-zäöüß])", rf"(?<![a-zäöüß]){begriff}"):
        passend = [t for t in treffer if re.search(muster, f"{t['name']} {t['category'] or ''}".lower())]
        if passend:
            rows = passend
            break
    rows = [a.mit_lohn(t) for t in rows[:5]]
    if not rows:
        return {"text": f'Kein Teil zu "{suchbegriff}" gefunden.', "daten": []}
    liste = [f"• {p['name']} ({p['sku']}): Teil {eur(p['sales_net'])} + Montage {zahl(p['install_minutes'])} Min = "
             f"{eur(p['lohn_net'])} → gesamt {eur(p['gesamt_net'])} netto" for p in rows]
    return {"text": "\n".join(liste), "daten": rows}


def zulassungsfristen(db, stichtag, tage=180):
    t = int(tage)
    rows = a.zulassungsfristen(db, stichtag, t)
    if not rows:
        return {"text": f"In den nächsten {t} Tagen läuft keine Zulassungsfrist ab.", "daten": []}
    liste = [f"• {r['vehicle_internal_id']} ({r['brand']} {r['model']}): {r['ausnahme_art']}, Zulassung bis "
             f"{datum(r['frist'])} – noch {tage_text(r['tage_bis'])}" for r in rows]
    return {"text": "\n".join([f"{anzahl(len(rows), 'Fahrzeug', 'Fahrzeuge')} mit ablaufender Frist:", *liste]),
            "daten": rows}


def uebergabe_status(db, stichtag, internal_id=None, tage=60):
    rows = a.auslieferungs_ampel(db, stichtag, int(tage))
    fid = normalize_internal_id(internal_id) if internal_id else None
    treffer = [r for r in rows if r["vehicle_internal_id"] == fid] if fid else [r for r in rows if r["offen"] > 0]
    if not treffer:
        return {"text": f"Für {fid} steht keine Übergabe an." if fid else
                "Alle anstehenden Übergaben sind vorbereitet.", "daten": []}
    liste = []
    for r in treffer[:12]:
        offen = [p for p in r["punkte"] if p["status"] != "gut"]
        liste.append(f"• {r['vehicle_internal_id']} am {datum(r['planned_date'])} an {r['customer']}"
                     + (": " + ", ".join(f"{p['label']} ({p['text']})" for p in offen) if offen
                        else ": alles erledigt"))
    if fid and len(liste) == 1:
        return {"text": liste[0][2:] + ".", "daten": treffer}
    kopf = (f"{anzahl(len(treffer), 'Übergabe', 'Übergaben')} mit offenen Punkten:" if not fid
            else f"{anzahl(len(treffer), 'Übergabe', 'Übergaben')} für {fid}:")
    return {"text": "\n".join([kopf, *liste]), "daten": treffer}


def tilgungen(db, stichtag, tage=90):
    t = int(tage)
    if _tabelle_leer(db, "tilgungen"):
        return {"text": "Es ist kein Tilgungsplan eingelesen – dazu kann ich nichts sagen.", "daten": []}
    rows = a.tilgungen_faellig(db, stichtag, t)
    if not rows:
        return {"text": f"In den nächsten {t} Tagen ist keine Rate fällig.", "daten": []}
    summe = sum(r["betrag"] or 0 for r in rows)
    liste = [f"• {datum(r['faellig_am'])}: {r['vehicle_internal_id']} – {eur(r['betrag'])} ({r['bank']})"
             for r in rows[:12]]
    return {"text": "\n".join([f"{anzahl(len(rows), 'Rate', 'Raten')} über {eur(summe)}:", *liste]), "daten": rows}


def tilgungen_monat(db, stichtag, monat: str):
    """Alle Raten eines Kalendermonats ('2026-10'), bezahlte werden genannt, aber nicht mitgezählt."""
    jahr, nr = (int(x) for x in monat.split("-"))
    name = f"{MONATSNAMEN[nr - 1]} {jahr}"
    if _tabelle_leer(db, "tilgungen"):
        return {"text": "Es ist kein Tilgungsplan eingelesen – dazu kann ich nichts sagen.", "daten": []}
    rows = a.tilgungen_im_monat(db, monat)
    offen = [r for r in rows if not r["bezahlt_am"]]
    bezahlt = [r for r in rows if r["bezahlt_am"]]
    if not rows:
        return {"text": f"Im {name} ist laut Tilgungsplan keine Rate fällig.", "daten": []}
    if not offen:
        return {"text": f"Im {name} ist keine Rate mehr offen – alle {anzahl(len(bezahlt), 'Rate', 'Raten')} "
                        f"({eur(sum(r['betrag'] or 0 for r in bezahlt))}) sind bezahlt.", "daten": rows}
    kopf = (f"Im {name} {'ist' if len(offen) == 1 else 'sind'} {anzahl(len(offen), 'Rate', 'Raten')} über "
            f"{eur(sum(r['betrag'] or 0 for r in offen))} fällig"
            + (f" (dazu {anzahl(len(bezahlt), 'Rate', 'Raten')} über {eur(sum(r['betrag'] or 0 for r in bezahlt))}, "
               "die schon bezahlt sind)" if bezahlt else "") + ":")
    liste = [f"• {datum(r['faellig_am'])}: {r['vehicle_internal_id']} – {eur(r['betrag'])} ({r['bank']})"
             for r in offen[:15]]
    je_bank = {}
    for r in offen:
        je_bank[r["bank"]] = je_bank.get(r["bank"], 0) + (r["betrag"] or 0)
    if len(je_bank) > 1:
        liste.append("Je Bank: " + ", ".join(f"{b} {eur(s)}" for b, s in sorted(je_bank.items(), key=lambda x: -x[1]))
                     + ".")
    return {"text": "\n".join([kopf, *liste]), "daten": rows}


def kennzahlen(db, stichtag, finanzen=False):
    """Überblick. Ohne 'finanzen' nur Stückzahlen und Standtage – kein Wert, keine Finanzierung, kein Ertrag."""
    if _tabelle_leer(db, "vehicles"):
        return {"text": "Es ist noch keine Bestandsliste eingelesen – Kennzahlen gibt es erst danach.", "daten": None}
    k = a.inventory_kpis(db, stichtag)
    marken = ", ".join(f"{b['brand']}: {b['anzahl']}" for b in a.brand_breakdown(db)[:4])
    arten = ", ".join(f"{x['kategorie']}: {x['angeliefert']}" for x in a.category_breakdown(db))
    jahr = a.stichtag_oder_heute(stichtag)[:4]
    if not finanzen:
        return {"text": "\n".join([
            f"Bestand: {k['bestand_anzahl']} Fahrzeuge auf dem Hof, {k['bestellt_anzahl']} bestellt, "
            f"Ø {k['avg_standtage']} Standtage.",
            f"Nach Art: {arten}. Nach Hersteller: {marken}.",
        ]), "daten": None}
    return {"text": "\n".join([
        f"Bestand: {k['bestand_anzahl']} Fahrzeuge auf dem Hof, {k['bestellt_anzahl']} bestellt, Einkaufswert "
        f"{eur(k['bestandswert'])}, Ø {k['avg_standtage']} Standtage.",
        f"Nach Art: {arten}. Nach Hersteller: {marken}.",
        f"Finanzierung: {eur(k['finanzierung_offen'])} offen über {k['finanzierung_vertraege']} Verträge.",
        f"Zinsfreiheit läuft in 60 Tagen bei {k['zinsfrei_ablauf_60t_anzahl']} Fahrzeugen aus "
        f"({eur(k['zinsfrei_ablauf_60t_volumen'])}).",
        f"Offene Provisionen: {eur(k['provisionen_offen'])}. Deckungsbeitrag {jahr}: {eur(k['db_ytd'])} aus "
        f"{k['verkauft_ytd']} Verkäufen.",
    ]), "daten": k}


WERKZEUGE = {
    "fahrzeug_details": ("Alle Daten zu einem Fahrzeug anhand der internen Nummer: Modell, Status, Standort, "
                         "Standtage, Auslieferung; für Berechtigte Einkauf, Finanzierung und Verkauf.", fahrzeug_details),
    "bestand_zaehlen": ("Fahrzeuge im Bestand zählen, optional nach Marke und Fahrzeugart; der gebundene "
                        "Einkaufswert nur auf Nachfrage und für Berechtigte.", bestand_zaehlen),
    "zinsfrei_ablauf": ("Fahrzeuge, deren zinsfreie Einkaufsfinanzierung bald ausläuft oder abgelaufen ist.",
                        zinsfrei_ablauf),
    "bestandsliste": ("Fahrzeuge im Bestand nach Marke, Fahrzeugart oder Freitext.", bestandsliste),
    "liquiditaet": ("Einzahlungen, Auszahlungen und Saldo je Monat, Ist und Plan.", liquiditaet),
    "provisionen": ("Provisionen je Verkäufer, offen oder ausgezahlt.", provisionen),
    "erwartete_zahlungen": ("Zu erwartende Zahlungen aus der Finanzaufstellung, vor allem Kundenfinanzierungen, die "
                            "die Bank noch nicht ausgezahlt hat.", erwartete_zahlungen),
    "auslieferungen": ("Anstehende Übergaben mit offenen Punkten.", auslieferungen),
    "teile_und_montage": ("Preis und Montagezeit für ein Teil, mit Lohnanteil und Gesamtpreis.", teile_und_montage),
    "zulassungsfristen": ("Fahrzeuge, deren Ausnahmegenehmigung für die Zulassung abläuft.", zulassungsfristen),
    "uebergabe_status": ("Was einer Übergabe noch im Weg steht: Teile, Papiere, Zahlung, Werkszahlung, TÜV, "
                         "Einbauten.", uebergabe_status),
    "tilgungen": ("Fällige Tilgungsraten der Einkaufsfinanzierung.", tilgungen),
    "kennzahlen": ("Überblick über Bestand, Finanzierung, Zinsfreiheit, Provisionen und Deckungsbeitrag.",
                   kennzahlen),
}


def werkzeug(name: str, db, stichtag=None, finanzen=False, **eingabe) -> dict:
    """Ruft ein Werkzeug direkt auf (z. B. für einen Knopf in der Oberfläche). Vertrauliche nur mit 'finanzen'."""
    if name in VERTRAULICH and not finanzen:
        return absage()
    if finanzen and name in ("fahrzeug_details", "bestandsliste", "kennzahlen"):
        eingabe["finanzen"] = True
    return WERKZEUGE[name][1](db, a.stichtag_oder_heute(stichtag), **eingabe)


# ---------------------------------------------------------------------------- Regelwerk

MARKEN = {"hersteller1": "Hersteller1", "detleffs": "Hersteller1", "detlef": "Hersteller1", "hersteller4": "Hersteller4",
          "hersteller6": "Hersteller6", "hersteller6": "Hersteller6", "hersteller5": "Hersteller5", "hersteller2": "Hersteller2",
          "hersteller7": "Hersteller7", "hersteller3": "Hersteller3", "hersteller3": "Hersteller3"}
KATEGORIEN = {
    "reisemobil": "Reisemobil", "reisemobile": "Reisemobil", "wohnmobil": "Reisemobil", "wohnmobile": "Reisemobil",
    "wohnwagen": "Wohnwagen", "caravan": "Wohnwagen", "caravans": "Wohnwagen",
    "kastenwagen": "Kastenwagen", "kasten": "Kastenwagen",
}
TEILE_BEGRIFFE = ["markise", "solar", "sat", "antenne", "batterie", "klima", "heizung", "kupplung", "kamera",
                  "träger", "gibanet", "router", "wechselrichter", "ladebooster", "alarm", "navi", "fernseher", "tv",
                  "rückfahr", "lithium", "ahk"]

TEIL_FRAGE = re.compile(r"markise|solar|\bsat\b|sat-|antenne|batterie|klima|heizung|kupplung|kamera|träger|traeger|"
                        r"montage|einbau|arbeitszeit|\bahk\b|anhängerkupplung|wechselrichter|lithium|router|gibanet|"
                        r"rückfahr|navi\b|alarm|ladebooster|\btv\b|fernseher")
ALLE_FAHRZEUGE = re.compile(r"^(alle|alle fahrzeuge|alle typen|universal|-)$", re.IGNORECASE)
FUELLWOERTER = re.compile(r"\b(was|wie|viel|kostet|kosten|eine?n?|der|die|das|mit|ohne|einbau|montage|inkl\.?|inklusive|"
                          r"preis|für|fuer|bei|im|in|ein|und|zum|zur|komplett|netto|brutto|\?)\b", re.IGNORECASE)


def teil_aus_frage(frage: str) -> str:
    """„Was kostet ein Fahrradträger mit Einbau?“ -> „Fahrradträger“."""
    rest = " ".join(FUELLWOERTER.sub(" ", frage.replace("?", " ")).split())
    return rest.split(" ")[0] if rest else frage


def teil_begriff(db, frage: str) -> str:
    """Das genannte Teil: zuerst das ganze Wort aus der Frage („Fahrradträger“), wenn die Teileliste es kennt,
    sonst der bekannte Grundbegriff („träger“)."""
    wort = teil_aus_frage(re.sub(_ID_MUSTER, " ", frage))
    if wort and len(wort) >= 3 and a.teile_katalog(db, suche=wort):
        return wort
    f = frage.lower()
    return next((b for b in TEILE_BEGRIFFE if b in f), None) or wort or frage


def _typ(t: dict):
    """Fahrzeugtyp eines Teils: der feste Typ aus der Zuordnung, sonst die Bezeichnung der Teileliste."""
    return t.get("typ_neu") or t.get("fahrzeugtyp")


def _fahrzeugtypen(db) -> list:
    return [r[0] for r in db.execute("SELECT DISTINCT COALESCE(typ_neu, fahrzeugtyp) FROM parts "
                                     "WHERE fahrzeugtyp IS NOT NULL AND TRIM(fahrzeugtyp) <> '' ORDER BY 1")]


def typ_aus_text(db, text: str):
    """Fahrzeugtyp der Teileliste aus der Antwort/Frage: genau genannt, als Teil genannt, oder über die interne
    Nummer eines Fahrzeugs (dessen Art/Modell). None, wenn nichts eindeutig passt."""
    t = text.lower().strip(" ?.!")
    typen = [x for x in _fahrzeugtypen(db) if not ALLE_FAHRZEUGE.match(x.strip())]
    genau = [x for x in typen if x.lower() == t]
    if genau:
        return genau[0]
    enthalten = [x for x in typen if x.lower() in t or (len(t) >= 4 and t in x.lower())]
    if len(enthalten) == 1:
        return enthalten[0]
    erkannt = ft.erkennen(t)                         # „Kastenwagen mit Hochdach“, „H3“, „mein Wohnmobil“
    if erkannt in typen:
        return erkannt
    fid = finde_fahrzeug_id(db, text)
    if fid:
        fz = db.execute("SELECT category, model, brand FROM vehicles WHERE internal_id = ?", (fid,)).fetchone()
        if fz:
            woerter = [w for w in f"{fz['category'] or ''} {fz['model'] or ''}".lower().split() if len(w) >= 4]
            passend = [x for x in typen if any(w in x.lower() for w in woerter)]
            if len(passend) == 1:
                return passend[0]
            erkannt = ft.erkennen(f"{fz['category'] or ''} {fz['model'] or ''}")
            if erkannt in typen:
                return erkannt
    return None


def kundenpreis(t: dict):
    """(gesamt, material, einbau, festpreis) brutto – wie die Seite „Teile & Montage“: der festgelegte Preis
    (Spalte H) gilt, sonst Teil plus Montage (bei Sets plus Unterartikel)."""
    material = t.get("vk_brutto") or t.get("preis_brutto")
    lohn = t.get("lohn_vk") or 0
    if t.get("set_preis") is not None:
        return t["set_preis"], material, lohn, True
    if material is None:
        return None, None, lohn, False
    return material + lohn + (t.get("stueckliste_vk") or 0 if t.get("stueckliste") else 0), material, lohn, False


def teile_fuer_fahrzeug(db, stichtag, suchbegriff, fahrzeugtyp):
    """Passende Teile für einen Fahrzeugtyp (plus „alle Fahrzeuge“) mit dem Kundenpreis inklusive Montage."""
    treffer = a.teile_katalog(db, suche=suchbegriff)
    rows = [t for t in treffer if not _typ(t) or _typ(t) == fahrzeugtyp or ALLE_FAHRZEUGE.match(str(_typ(t)).strip())]
    if not rows:
        return {"text": f"In der Teileliste steht nichts zu „{suchbegriff}“ für {fahrzeugtyp}. "
                        "Verkäuferhandbücher und Preislisten kommen mit der Wissensdatenbank dazu.", "daten": []}
    zeilen = []
    for t in rows[:6]:
        gesamt = kundenpreis(t)[0]                    # nur der Kundenpreis – Einkauf und Marge nie im Antworttext
        zeilen.append(f"• {t['name']}: {eur(gesamt)} inkl. Montage (brutto)" if gesamt else f"• {t['name']}")
    return {"text": "\n".join([f"{anzahl(len(rows), 'Treffer', 'Treffer')} für {fahrzeugtyp}:", *zeilen]), "daten": rows}


L_CODES = {"l1": 4.96, "l2": 5.41, "l3": 5.99, "l4": 6.36}        # übliche Längen der Kastenwagen-Radstände
_LAENGE = re.compile(r"(\d{1,2}(?:[.,]\d{1,2})?)\s*(?:m\b|meter)", re.IGNORECASE)
KUNDEN_HINWEIS = re.compile(r"\bmein(en|em|er|e)?\b|\bich hab|\bkunde|\bkundin|\banfrage|\bunser(en|em)?\b")


def laenge_aus_text(text: str):
    """Fahrzeuglänge in Metern aus „6 Meter“, „5,99 m“ oder „L3“; None, wenn keine genannt ist."""
    t = str(text or "").lower()
    for m in _LAENGE.finditer(t):
        wert = float(m.group(1).replace(",", "."))
        if 3.5 <= wert <= 12:
            return wert
    m = re.search(r"\b(l[1-4])\b", t)
    return L_CODES[m.group(1)] if m else None


def _laengen_im_typ(typ: str) -> list:
    t = str(typ).lower()
    werte = [float(x.replace(",", ".")) for x in re.findall(r"(\d{1,2}[.,]\d{1,2})\s*m?", t)]
    werte += [L_CODES[c] for c in re.findall(r"\b(l[1-4])\b", t)]
    werte += [int(x) / 100 for x in re.findall(r"\b(\d{3})\b", t) if 450 <= int(x) <= 900]
    return [w for w in werte if 3.5 <= w <= 12]


def typ_aus_beschreibung(text: str, typen: list):
    """Fahrzeugtyp aus Art und Länge („Markise für meinen 6 Meter Kastenwagen“): unter den Typen der Art den mit der
    nächstliegenden Länge (höchstens 30 cm daneben), sonst den einzigen Typ dieser Art."""
    t = str(text or "").lower()
    art = next((KATEGORIEN[k] for k in KATEGORIEN if re.search(rf"\b{k}\b", t)), None)
    kandidaten = [x for x in typen if art and (art.lower() in x.lower() or ft.ART.get(x) == art)] or ([] if art else typen)
    laenge = laenge_aus_text(text)
    if laenge:
        mit = sorted((min(abs(w - laenge) for w in ws), x) for x in kandidaten if (ws := _laengen_im_typ(x)))
        if mit and mit[0][0] <= 0.3 and (len(mit) == 1 or mit[1][0] - mit[0][0] > 0.05):
            return mit[0][1]
    if art and len(kandidaten) == 1:
        return kandidaten[0]
    return None


def kunden_antwort(frage: str, typ: str, rows: list):
    """Fertiger Antworttext für den Kunden (Sie-Form) – zum Kopieren in Mail oder Chat. Preise brutto."""
    mit_preis = [(t, kundenpreis(t)) for t in rows if kundenpreis(t)[0]]
    if not mit_preis:
        return None
    laenge = laenge_aus_text(frage)
    fahrzeug = f"Ihren {typ}" + (f" mit rund {zahl(laenge, 1 if laenge % 1 else 0)} m Länge" if laenge else "")
    (erstes, (gesamt, material, lohn, fest)) = mit_preis[0]
    satz = [f"Für {fahrzeug} passt zum Beispiel: {erstes['name']}."]
    if fest or not material:
        satz.append(f"Der Preis inklusive Montage beträgt {eur(gesamt)}.")
    else:
        satz.append(f"Der Preis inklusive Montage beträgt {eur(gesamt)} (Material {eur(material)}, Einbau {eur(lohn)}).")
    weitere = [f"{t['name']} für {eur(p[0])}" for t, p in mit_preis[1:3]]
    if weitere:
        satz.append("Alternativ: " + "; ".join(weitere) + " – jeweils inklusive Montage.")
    satz.append("Gerne erstellen wir Ihnen ein verbindliches Angebot und vereinbaren direkt einen Einbautermin.")
    return " ".join(satz)


def teile_mit_rueckfrage(db, stichtag, begriff, frage):
    """Teilepreis: steht in der Teileliste je Fahrzeugtyp. Den Typ nimmt der Assistent aus der Frage (Name, interne
    Nummer, Art und Länge); erst wenn das nicht reicht, fragt er nach. Klingt die Frage nach einer Kundenanfrage
    („mein Kastenwagen“), kommt ein fertiger Antworttext dazu."""
    treffer = a.teile_katalog(db, suche=begriff)
    typen = sorted({_typ(t) for t in treffer if _typ(t) and not ALLE_FAHRZEUGE.match(str(_typ(t)).strip())})
    # Länge steht oft nur in der alten Bezeichnung der Teileliste („Kastenwagen 5,99 m“) – die gilt dann als ihr Typ
    neu_je_alt = {t["fahrzeugtyp"]: _typ(t) for t in treffer if t.get("fahrzeugtyp")
                  and not ALLE_FAHRZEUGE.match(str(_typ(t)).strip())}
    typ = (typ_aus_text(db, frage) or neu_je_alt.get(typ_aus_beschreibung(frage, sorted(neu_je_alt)))
           or typ_aus_beschreibung(frage, typen))
    if typ:
        ergebnis = teile_fuer_fahrzeug(db, stichtag, begriff, typ)
        antwort = {**ergebnis, "werkzeug": "teile_fuer_fahrzeug", "modus": "regel"}
        if KUNDEN_HINWEIS.search(str(frage).lower()) or laenge_aus_text(frage):
            text = kunden_antwort(frage, typ, ergebnis.get("daten") or [])
            if text:
                antwort["kundentext"] = text
        return antwort
    art = next((KATEGORIEN[k] for k in KATEGORIEN if re.search(rf"\b{k}\b", str(frage).lower())), None)
    if art:                                           # „mein Kastenwagen“: nur die Kastenwagen-Typen anbieten
        typen = [x for x in typen if (ft.ART[x] == art if x in ft.ART else art.lower() in x.lower())] or typen
    if len(typen) > 1:
        return {"text": f"Für welches Fahrzeug? „{begriff.capitalize()}“ steht in der Teileliste für "
                        f"{len(typen)} Fahrzeugtypen – Preis und Einbau hängen davon ab.",
                "daten": None, "werkzeug": "rueckfrage", "modus": "regel",
                "rueckfrage": {"optionen": typen, "hinweis": "Typ wählen oder eine interne Nummer eingeben",
                               "kontext": {"teil": begriff}}}
    if len(typen) == 1:
        return {**teile_fuer_fahrzeug(db, stichtag, begriff, typen[0]), "werkzeug": "teile_fuer_fahrzeug", "modus": "regel"}
    return {**teile_und_montage(db, stichtag, begriff), "werkzeug": "teile_und_montage", "modus": "regel"}

# (Frage, nur für Finanz-Berechtigte)
BEISPIELE_ALLE = [
    ("Wie viele Hersteller2 Kastenwagen habe ich?", False),
    ("Was kostet eine Markise mit Einbau?", False),
    ("Was hängt bei den nächsten Übergaben noch?", False),
    ("Bei welchen Fahrzeugen läuft die Zulassungsfrist ab?", False),
    ("Was steht heute an?", False),
    ("Wo beantrage ich Urlaub?", False),
    ("Wo ist DETKW00182 finanziert?", True),
    ("Bis wann ist DETKW00182 zinsfrei?", True),
    ("Was hat DETKW00182 netto gekostet?", True),
    ("Welche Finanzierungen laufen in 30 Tagen aus?", True),
    ("Was ist im Oktober an Tilgung fällig?", True),
    ("Wie sieht die Liquidität aus?", True),
    ("Welche Finanzierungen sind noch nicht ausgezahlt?", True),
    ("Wie hoch ist das gebundene Kapital?", True),
]
BEISPIELE = [f for f, _ in BEISPIELE_ALLE]

# Vorbereitete Fragen zum Ausprobieren, nach Bereichen: (Bereich, Fragen, nur für Finanz-Berechtigte).
# {ID} wird durch ein Fahrzeug aus den echten Daten ersetzt.
BEISPIEL_GRUPPEN = [
    ("Bestand", ["Wie viele Fahrzeuge haben wir im Bestand?", "Wie viele Hersteller1 haben wir im Bestand?",
                 "Wie viele Hersteller2 Kastenwagen habe ich?", "Wie viele Wohnwagen stehen auf dem Hof?",
                 "Zeig mir alle Reisemobile im Bestand", "Wie lange steht {ID} schon?"], False),
    ("Ein Fahrzeug", ["Wo steht {ID}?", "Was fehlt bei {UEBERGABE} noch?", "Bis wann muss {ID} zugelassen sein?",
                      "Wann wird {UEBERGABE} übergeben?"], False),
    ("Übergaben & Zulassung", ["Welche Auslieferungen stehen an?", "Was hängt bei den nächsten Übergaben noch?",
                               "Welche Übergaben sind in 14 Tagen?",
                               "Bei welchen Fahrzeugen läuft die Zulassungsfrist ab?"], False),
    ("Heute & Woche", ["Was steht heute an?", "Was steht morgen an?", "Was ist diese Woche los?",
                       "Was steht nächste Woche an?"], False),
    ("Zurechtfinden", ["Wo beantrage ich Urlaub?", "Wo trage ich eine Frist ein?", "Wo finde ich die Scorecard?",
                       "Wo sehe ich, was ein Langsteher kostet?"], False),
    ("Beirat & Coaching", ["Kunde sagt: zu teuer – was tun?", "Kunde will es sich noch überlegen",
                           "Was würde Buffett sagen?", "Wie entscheide ich mich bei einer schwierigen Frage?",
                           "Ich verzettele mich – hast du Tipps?"], False),
    ("Kundenanfragen", ["Was kostet die Markise für meinen 6 Meter Kastenwagen?",
                        "Ein Kunde fragt: Was kostet eine Solaranlage mit Einbau?"], False),
    ("Teile & Einbau", ["Was kostet eine Markise mit Einbau?", "Was kostet eine Solaranlage?",
                        "Was kostet eine Sat-Anlage mit Montage?", "Was kostet ein Fahrradträger?",
                        "Was kostet eine Rückfahrkamera?", "Was kostet eine Markise für {ID}?"], False),
    ("Finanzierung", ["Wo ist {ID} finanziert?", "Bis wann ist {ID} zinsfrei?", "Was hat {ID} netto gekostet?",
                      "Welche Finanzierungen laufen in 30 Tagen aus?", "Welche Zinsfreiheit endet in 60 Tagen?",
                      "Was ist im Oktober an Tilgung fällig?", "Welche Tilgungen sind nächsten Monat fällig?"], True),
    ("Geld", ["Wie sieht die Liquidität aus?", "Welche Finanzierungen sind noch nicht ausgezahlt?",
              "Welche Zahlungen erwarten wir noch?", "Wie hoch ist das gebundene Kapital?",
              "Wie hoch ist der Deckungsbeitrag?",
              "Welche Provisionen sind offen?", "Welche Provisionen wurden ausgezahlt?"], True),
]


def beispielfragen(db, finanzen=None) -> list:
    """Vorbereitete Fragen mit einer echten Fahrzeugnummer (am besten eins mit offener Finanzierung). Jede Gruppe
    trägt "finanzen": True, wenn sie nur für Berechtigte gedacht ist. Mit finanzen=False fallen diese weg."""
    zeile = db.execute("SELECT f.vehicle_internal_id FROM financings f JOIN vehicles v ON v.internal_id = "
                       "f.vehicle_internal_id WHERE f.status = 'offen' ORDER BY f.interest_free_until LIMIT 1").fetchone() \
        or db.execute("SELECT internal_id FROM vehicles ORDER BY internal_id LIMIT 1").fetchone()
    fid = zeile[0] if zeile else "DETKW00182"
    uebergabe = db.execute("SELECT vehicle_internal_id FROM deliveries WHERE actual_date IS NULL "
                           "ORDER BY planned_date LIMIT 1").fetchone()
    uid = uebergabe[0] if uebergabe else fid
    return [{"bereich": b, "fragen": [f.replace("{ID}", fid).replace("{UEBERGABE}", uid) for f in fragen],
             "finanzen": nur_fin}
            for b, fragen, nur_fin in BEISPIEL_GRUPPEN if finanzen is not False or not nur_fin]


_ID_MUSTER = re.compile(r"([A-Za-zÄÖÜäöü]{2,8})[\s\-_.]?(\d{2,6})\b")


def _bekannte_praefixe(db) -> set:
    praefixe = {re.sub(r"\d", "", r["internal_id"]) for r in db.execute("SELECT internal_id FROM vehicles")}
    return praefixe | set(_stammdaten()["praefixe"])


def finde_fahrzeug_id(db, frage: str):
    """Findet eine interne Nummer wie „DETKW00182“, „detkw182“, „H1-KW 182“.

    Geprüft wird das Präfix gegen die vergebenen Präfixe, damit „in 30 Tagen“ oder „KW 41“ nicht als Nummer
    gelesen werden. Eine unbekannte Nummer mit bekanntem Präfix wird zurückgegeben – die Antwort sagt dann,
    dass es das Fahrzeug nicht gibt.
    """
    praefixe = _bekannte_praefixe(db)
    for m in _ID_MUSTER.finditer(frage):
        fid = normalize_internal_id(m.group(1) + m.group(2))
        if re.sub(r"\d", "", fid) in praefixe:
            return fid
    return None


def finde_tage(frage: str, standard: int) -> int:
    m = re.search(r"(\d{1,3})\s*(tag|tagen|tage)", frage, re.I)
    if m:
        return int(m.group(1))
    if re.search(r"woche", frage, re.I):
        m = re.search(r"(\d{1,2})\s*woche", frage, re.I)
        return 7 * int(m.group(1) if m else 1)
    if re.search(r"monat", frage, re.I):
        m = re.search(r"(\d{1,2})\s*monat", frage, re.I)
        return 30 * int(m.group(1) if m else 1)
    return standard


_MONAT_MUSTER = re.compile(
    r"\b(januar|jan|februar|feb|märz|maerz|mär|april|apr|mai|juni|jun|juli|jul|august|aug|september|sept|sep|"
    r"oktober|okt|november|nov|dezember|dez)\b\.?\s*(\d{4})?")
_MONAT_NR = {"jan": 1, "feb": 2, "mär": 3, "mae": 3, "apr": 4, "mai": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9,
             "okt": 10, "nov": 11, "dez": 12}


def finde_monat(frage: str, stichtag: str):
    """'im Oktober' -> '2026-10' (nächster Oktober ab dem laufenden Monat); auch 'diesen/nächsten Monat'."""
    f = frage.lower()
    jahr, monat = int(stichtag[:4]), int(stichtag[5:7])
    if re.search(r"(diesen|laufenden|aktuellen) monat", f):
        return f"{jahr:04d}-{monat:02d}"
    if re.search(r"(nächsten|naechsten|kommenden|folgenden) monat", f):
        j, m = divmod(monat, 12)
        return f"{jahr + j:04d}-{m + 1:02d}"
    m = _MONAT_MUSTER.search(f)
    if not m:
        return None
    nr = _MONAT_NR[m.group(1)[:3]]
    if m.group(2):
        return f"{int(m.group(2)):04d}-{nr:02d}"
    return f"{jahr + (1 if nr < monat else 0):04d}-{nr:02d}"


# ---------------------------------------------------------------- Wegweiser
# „Wo finde ich …?“ – damit sich alle in ODIN zurechtfinden. Reihenfolge zählt: Spezielles vor Allgemeinem.
WEGWEISER_FRAGE = re.compile(r"\bwo (finde|findet|ist|sind|steh|seh|trag|beantrag|kann|gibt|stell|leg|mach|pfleg|änder|aender|meld)"
                             r"|\bwie (komm|find|beantrag|trag|stell|leg|mach|änder|aender|richte|meld|schalt)|\bwo geht")
NAVI = [
    (r"^(?!.*syscara).*(microsoft|office ?365|\bm365\b|anmeld|abmeld|einlogg|\blogin\b|\bkonto\b|meld\w* (ich |du )?(mich|dich) (an|ab)\b|"
     r"erinnerungsmail|erinnerung per mail|t(ä|ae)gliche mail|mail an mich|client-?id|tenant)", "Konto & Anmeldung",
     "unten links in der Seitenleiste über „Datenquellen“ (Tabellen-Symbol)", "#/konto",
     "Dort mit dem Microsoft-Konto anmelden, die eigene Person verknüpfen und die tägliche Erinnerungsmail einschalten."),
    (r"cashback|gutschrift|herstelleraktion|aktionsliste|einreichungsfrist|rundschreiben", "Cashback",
     "Finanzen → Cashback", "#/cashback",
     "Dort steht, was eingereicht werden muss, wo nachgehakt werden sollte und wie viel noch offen ist – gelesen aus den "
     "Aktionslisten je Hersteller. Eingetragen wird weiter in Excel."),
    (r"beirat|coaching|verkaufstraining", "Beirat & Coaching", "Team & Projekte → Beirat & Coaching", "#/beirat",
     "Rat aus mehreren Perspektiven zu typischen Situationen, dazu Coaching-Module zu Verkauf, Verhandeln, Entscheiden, "
     "Struktur, Service und Führung."),
    (r"\bwissen\b|anleitung|einarbeit|onboarding|checkliste|\babl(a|ä|ae)uf|wer wei(ß|ss) was", "Wissen & Einarbeitung",
     "Team & Projekte → Wissen & Einarbeitung", "#/wissen",
     "Abläufe als Checklisten zum Abhaken, Anleitungen je System, Einarbeitungspläne je Rolle – und „Wer weiß was“."),
    (r"urlaub", "Urlaub", "Team & Projekte → Urlaub", "#/urlaub",
     "Dort Zeitraum wählen und den Antrag stellen. Genehmiger finden offene Anträge im Reiter „Genehmigen“."),
    (r"tagesfrage|quiz|streak|verlosung|lose\b", "Tagesfragen", "Team & Projekte → Tagesfragen", "#/tagesfragen",
     "Jeden Arbeitstag ein paar Fragen, mit Erklärung nach jeder Antwort."),
    (r"besprechung|protokoll|wochenrunde|beschluss", "Besprechungen", "Führung → Besprechungen", "#/besprechungen",
     "Wochenrunde anlegen, Themen klären, Aufgaben direkt an Projekte geben; Beschlüsse stehen im Beschluss-Log."),
    (r"quartalsziel|\brock", "Quartalsziele", "Führung → Quartalsziele", "#/ziele",
     "3–7 Ziele je Quartal, jedes als Projekt mit Verantwortlichem."),
    (r"scorecard|kennzahl|wochenzahl", "Scorecard", "Führung → Scorecard", "#/scorecard",
     "Mit „Kennzahlen bearbeiten“ Ziele und Verantwortliche setzen oder eigene Kennzahlen anlegen."),
    (r"rechtsfall|rechtsfälle|rechtsfaelle|reklamation|abmahnung|anwalt|inkasso|mahnbescheid|gewährleistung|"
     r"gewaehrleistung|datenpanne|auskunftsersuchen", "Rechtsfälle", "Führung → Rechtsfälle", "#/rechtsfaelle",
     "Je Fall eine Akte: Mails, Dateien, Fristen, Belege, der nächste Schritt und Entwürfe – sichtbar nur für Beteiligte."),
    (r"zulassung", "Zulassungsfristen", "Finanzen → Finanzierung", "#/finanzierung",
     "Dort im Abschnitt „Zulassungsfristen“."),
    (r"\bfrist|hebebühne|hebebuehne|feuerlöscher|feuerloescher|versicherung|prüftermin|prueftermin", "Fristen",
     "Führung → Fristen", "#/fristen", "Neue Frist eintragen oder eine Vorlage wählen; „Erledigt“ rückt die nächste weiter."),
    (r"zinsuhr|langsteher|nachlass|standkosten", "Zinsuhr & Langsteher", "Finanzen → Zinsuhr & Langsteher", "#/zinsuhr",
     "Was jeder Tag Bestand kostet und welcher Nachlass sich bei Langstehern rechnet."),
    (r"bonus|staffel", "Herstellerbonus", "Finanzen → Linien & Bestellungen (unten)", "#/vororder",
     "Staffeln je Hersteller und Jahr eintragen; ODIN zählt, wie viele Fahrzeuge zur nächsten Stufe fehlen."),
    (r"vororder|linie", "Linien & Bestellungen", "Finanzen → Linien & Bestellungen", "#/vororder",
     "Die kommenden Fahrzeuge aus der Finanzaufstellung nach Monat; ODIN warnt, wenn eine Linie über das Limit läuft."),
    (r"erwartete|zu erwartende|ausgezahlt|auszahlung", "Zu erwartende Zahlungen", "Finanzen → Liquidität",
     "#/liquiditaet", "Unten auf der Seite: Kundenfinanzierungen, die die Bank noch nicht ausgezahlt hat, und die "
     "übrigen erwarteten Zahlungen aus der Finanzaufstellung."),
    (r"finanzierung|zinsfrei|tilgung|ablös|abloes", "Finanzierung", "Finanzen → Finanzierung", "#/finanzierung", ""),
    (r"liquidit|kontostand|cashflow", "Liquidität", "Finanzen → Liquidität", "#/liquiditaet", ""),
    (r"provision", "Provisionen", "Finanzen → Provisionen", "#/provisionen", ""),
    (r"auftragsbest|\bab\b|\babs\b", "Auftragsbestätigungen", "Fahrzeuge & Verkauf → Auftragsbestätigungen", "#/abs",
     "ABs aus dem Eingang einlesen; ODIN vergleicht sie mit der Bestellung."),
    (r"preisschild|fließtext|fliesstext|werbetext|mobile\.de|inserat", "Preisschilder & Texte",
     "Fahrzeuge & Verkauf → Preisschilder & Texte", "#/preisschilder", ""),
    (r"ausstattung|syscara", "Ausstattungsvergleich", "Fahrzeuge & Verkauf → Ausstattungsvergleich", "#/ausstattung", ""),
    (r"fahrzeugordner|ordner|akte", "Fahrzeugordner", "Fahrzeuge & Verkauf → Fahrzeugordner", "#/fahrzeuge", ""),
    (r"auslieferung|übergabe|uebergabe", "Auslieferungen", "Fahrzeuge & Verkauf → Auslieferungen", "#/auslieferungen",
     "Ampel je Übergabe: Teile, Papiere, Zahlung, TÜV, Einbauten."),
    (r"bestand|fahrzeugliste|standtage|fahrzeug", "Bestand", "Fahrzeuge & Verkauf → Bestand", "#/bestand", ""),
    # Werkstatt ist nicht in ODIN – nur der Hinweis, wo es weitergeht (Pfad None: der Tipp ist die ganze Antwort)
    (r"werkstatt|kapazit|engpass|monteur", "Werkstatt", None, "", WERKSTATT_TEXT),
    (r"teil|zubehör|zubehoer|montage|stückliste|stueckliste|markise|preis", "Teile & Montage",
     "Teile → Teile & Montage", "#/teile", "Suchen, nach Fahrzeugtyp filtern, Artikel aufklappen für die Stückliste."),
    (r"to-?do", "To-dos", "Team & Projekte → To-dos", "#/todos", ""),
    (r"aufgabe", "Meine Aufgaben", "Team & Projekte → Meine Aufgaben", "#/aufgaben", ""),
    (r"projekt", "Alle Projekte", "Team & Projekte → Alle Projekte", "#/projekte",
     "„Neues Projekt“ oben rechts; Mitglieder lassen sich im Projekt hinzufügen."),
    (r"heute|woche|termin|kalender", "Heute & Woche", "ganz oben in der Seitenleiste", "#/heute",
     "Alles, was mit Datum zu tun ist: Übergaben, Zulassungen, Bemerkungen, Fristen, To-dos und Aufgaben."),
    (r"excel|datenquelle|einlesen|einrichten", "Datenquellen", "unten links in der Seitenleiste (Tabellen-Symbol)", "#/excel",
     "Je Liste „Datei wählen …“; ODIN liest sofort probeweise ein und sagt, was es verstanden hat."),
    (r"dunkel|hell|design|odin 2|odin 3|aussehen", "Gestaltung", "unten links in der Seitenleiste", "",
     "„ODIN 2 / ODIN 3“ wechselt die Gestaltung, Sonne/Mond schaltet hell, dunkel oder automatisch."),
    (r"übersicht|uebersicht|dashboard|kachel|startseite", "Übersicht", "ganz oben in der Seitenleiste", "#/uebersicht",
     "Mit „Anpassen“ lassen sich die Kacheln verschieben, vergrößern und ausblenden."),
]


def wegweiser(frage: str):
    f = str(frage or "").lower()
    for muster, name, pfad, ziel, tipp in NAVI:
        if re.search(muster, f) and pfad is None:
            return {"text": tipp, "daten": None, "werkzeug": "wegweiser", "modus": "regel", "ziel": ziel}
        if re.search(muster, f):
            wo = pfad if "Seitenleiste" in pfad else f"links in der Seitenleiste unter {pfad}"
            text = f"{name} findest du {wo}." + (f" {tipp}" if tipp else "")
            return {"text": text, "daten": None, "werkzeug": "wegweiser", "modus": "regel", "ziel": ziel}
    return None


# ---------------------------------------------------------------- Wissen: Abläufe und Anleitungen finden
# „Wie mache ich den Check-in?“ – einfache Stichwortsuche über Titel und Text, keine KI. Die Einträge kommen aus
# tirge_helfer/wissen.py (stichworte()): {"art": "ablauf"|"anleitung", "id", "titel", "text", "entwurf"}.
WISSEN_FRAGE = re.compile(r"\bwie (mache?|macht|geht|funktioniert|lege?|l(ä|ae)uft|bestelle?|melde|erstelle?|pr(ü|ue)fe?|bearbeite?|buche?|"
                          r"lese?|wickle|(ü|ue)bergebe?|starte?|nehme?|kontrolliere?)\b|\bwas (muss|ist zu tun)|"
                          r"\banleitung|\babl(a|ä|ae)uf|check-?in|\bschritte\b")
_WISSEN_FUELL = set("wie was wer wo ich du wir man den der die das dem des ein eine einen einem einer mache mach macht "
                    "machen geht lege leg legt an in im zu zum zur bei beim fuer mit und oder ist sind muss tun es bitte "
                    "anleitung ablauf ablaeufe schritte funktioniert laeuft richtig ab auf von vom aus nach dann kann "
                    "soll denn eigentlich gibt mal hier bei uns".split())
_WISSEN_ID = re.compile(r"[a-z0-9]{6,32}")


def _wissen_woerter(text) -> list:
    t = str(text or "").lower()
    for alt, neu in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(alt, neu)
    return [w for w in re.split(r"[^0-9a-z]+", t) if len(w) >= 3 and w not in _WISSEN_FUELL]


def _wissen_passt(a: str, b: str) -> bool:
    """Gleiches Wort, das kürzere steckt im längeren („fahrzeug“ in „neufahrzeug“) oder gleicher Wortanfang."""
    if a == b:
        return True
    kurz, lang = sorted((a, b), key=len)
    return len(kurz) >= 5 and (kurz in lang or kurz[:5] == lang[:5])


def wissen_antwort(frage: str, eintraege):
    """Passender Ablauf oder passende Anleitung zur Frage – oder None. Ein Treffer braucht mindestens ein Wort der
    Frage im Titel; und entweder zwei davon oder alle Wörter der Frage irgendwo im Eintrag."""
    woerter = list(dict.fromkeys(_wissen_woerter(frage)))
    if "anlegen" not in woerter and re.search(r"\bleg\w*\b.*\ban\b", str(frage or "").lower()):
        woerter.append("anlegen")                                   # „lege … an“ = „anlegen“
    if not woerter or not isinstance(eintraege, (list, tuple)):
        return None
    bester = None
    for e in eintraege:
        if not isinstance(e, dict) or e.get("art") not in ("ablauf", "anleitung") or not _WISSEN_ID.fullmatch(str(e.get("id") or "")):
            continue
        titel, text = _wissen_woerter(e.get("titel")), set(_wissen_woerter(e.get("text")))
        im_titel = [w for w in woerter if any(_wissen_passt(w, t) for t in titel)]
        im_text = [w for w in woerter if w not in im_titel and any(_wissen_passt(w, t) for t in text)]
        echte = [w for w in woerter if w != "anlegen" or "anlegen" in im_titel]
        if not im_titel or not (len(im_titel) >= 2 or all(w in im_titel or w in im_text for w in echte)):
            continue
        wert = (3 * len(im_titel) + len(im_text), len(im_titel) / max(1, len(titel)), e["art"] == "ablauf")
        if bester is None or wert > bester[0]:
            bester = (wert, e)
    if not bester:
        return None
    e = bester[1]
    titel = " ".join(str(e.get("titel") or "").split())[:120]
    text = (f"Dafür gibt es den Ablauf „{titel}“ – eine Checkliste zum Abhaken, Schritt für Schritt."
            if e["art"] == "ablauf" else f"Dazu gibt es die Anleitung „{titel}“.")
    if e.get("entwurf"):
        text += " Achtung: Das ist noch ein Entwurf, den niemand aus dem Betrieb geprüft hat."
    return {"text": text + " Zu finden unter Team & Projekte → Wissen & Einarbeitung.", "daten": None,
            "werkzeug": "wissen", "modus": "regel", "ziel": f"#/wissen/{e['art']}/{e['id']}"}


# ---------------------------------------------------------------- Heute & Woche
AGENDA_FRAGE = re.compile(r"tages(ü|ue)bersicht|wochen(ü|ue)bersicht|tagesplan|wochenplan|"
                          r"(was|welche).{0,30}(steht|stehen|ansteht|anstehen|gibt es|termine|zu tun).{0,30}"
                          r"(heute|morgen|woche)|termine.{0,20}(heute|morgen|woche)|(heute|morgen|woche).{0,10}(los|zu tun)")
# Mit einem dieser Wörter ist es eine Fachfrage („Welche Übergaben sind diese Woche?“, „… seit einer Woche“)
AGENDA_BEREICH = re.compile(r"werkstatt|tilgung|rate\b|(ü|ue)bergabe|auslieferung|zinsfrei|provision|urlaub|bestand|"
                            r"\bseit\b|standtage")
_AGENDA_WORTE = {"uebergabe": ("Übergabe", "Übergaben"),
                 "zulassung": ("Zulassung zu besorgen", "Zulassungen zu besorgen"),
                 "bemerkung": ("Bemerkung zu einer Übergabe", "Bemerkungen zu Übergaben"),
                 "hinweis": ("Hinweis für den Tag", "Hinweise"), "sonderfahrt": ("Sonderfahrt", "Sonderfahrten"),
                 "lehrgang": ("Lehrgang", "Lehrgänge"),
                 "tilgung": ("Tilgung", "Tilgungen"), "zinsfrei": ("Ende der Zinsfreiheit", "Zinsfrei-Enden"),
                 "abloesung": ("Ablösung", "Ablösungen"), "vororder": ("Vororder-Liefertermin", "Vororder-Liefertermine"),
                 "frist": ("Zulassungsfrist", "Zulassungsfristen"), "todo": ("To-do", "To-dos")}


def agenda_antwort(db, tag: str, f: str, finanzen=False) -> dict:
    """„Was steht heute an?“, „Was ist nächste Woche los?“ – dieselben Daten wie die Seite „Heute & Woche“.
    Tilgungen, Zinsfrei-Enden, Ablösungen und Vororder nur mit 'finanzen'."""
    g = a.agenda(db, tag)
    if not finanzen:
        g = a.agenda_ohne_finanzen(g)
    heute = dt.date.fromisoformat(tag)
    montag = a.montag_von(tag)
    if "morgen" in f:
        von = bis = heute + dt.timedelta(days=1)
        wann = "Morgen"
    elif re.search(r"n(ä|ae)chste woche", f):
        von, bis = montag + dt.timedelta(days=7), montag + dt.timedelta(days=13)
        wann = f"Nächste Woche (KW {a.kalenderwoche(von)})"
    elif "woche" in f:
        von, bis = heute, montag + dt.timedelta(days=6)
        wann = f"Bis Sonntag (KW {a.kalenderwoche(heute)})"
    else:
        von = bis = heute
        wann = "Heute"
    v, b = von.isoformat(), bis.isoformat()
    # Punkte mit Zeitraum (Lehrgang, „ganze KW“) zählen, sobald sie den gefragten Zeitraum berühren
    punkte = [p for p in g["termine"] if p["datum"] <= b and (p.get("bis") or p["datum"]) >= v]
    ueber = [p for p in g["termine"] if p["ueberfaellig"]] if von == heute else []
    teile = []
    for art, (eins, viele) in _AGENDA_WORTE.items():
        n = sum(1 for p in punkte if p["art"] == art)
        if n:
            summe = sum(p["betrag"] or 0 for p in punkte if p["art"] == art and art == "tilgung")
            teile.append(f"{n} {eins if n == 1 else viele}" + (f" ({eur(summe)})" if summe else ""))
    fehlen = sorted({x["mitarbeiter"] for x in g["abwesend"] if v <= x["datum"] <= b})
    text = f"{wann}: " + ", ".join(teile) + "." if punkte else f"{wann} steht nichts mit Datum in den Listen an."
    if fehlen:
        text += " Abwesend: " + ", ".join(fehlen) + "."
    if ueber:
        text += (" Überfällig ist " if len(ueber) == 1 else f" Überfällig sind {len(ueber)} ") + \
            ("ein Punkt" if len(ueber) == 1 else "Punkte") + " aus den letzten 30 Tagen."
    # Erst Überfälliges, dann der Reihe nach
    reihe = ueber + sorted(punkte, key=lambda p: p["datum"])
    zeilen = [f"• {datum(p['datum'])[:6] + ' ' if von != bis or p['ueberfaellig'] else ''}{p['titel']}"
              + (f" – {p['text']}" if p["text"] else "") for p in reihe[:8]]
    if zeilen:
        text += "\n" + "\n".join(zeilen)
    if len(ueber) + len(punkte) > 8:
        text += f"\n… und {len(ueber) + len(punkte) - 8} weitere. Alles auf der Seite „Heute & Woche“."
    return {"text": text, "daten": {"termine": punkte, "ueberfaellig": ueber, "abwesend": fehlen}}


# „Welche Finanzierungen sind noch nicht ausgezahlt?“, „Was zahlt die Bank noch aus?“, „Welche Zahlungen erwarten wir?“
ERWARTET_FRAGE = re.compile(r"(nicht|noch).{0,20}ausgezahlt|ausgezahlt.{0,20}(nicht|noch)|auszahlung.{0,20}(bank|offen|aus)|"
                            r"bank.{0,25}(auszahl|zahlt.{0,10}aus)|zahlt.{0,20}bank.{0,15}aus\b|kundenfinanzierung|"
                            r"(zu )?erwartende?n? zahlung|erwartete?n? zahlung|zahlungen?.{0,15}erwart|"
                            r"offene?n? zahlung|zahlungseing(ä|ae)ng|geld.{0,20}(rein|herein)|noch.{0,10}(rein|herein)")


def regel_antwort(db, frage: str, stichtag=None, finanzen=False):
    """Antwort aus dem Regelwerk oder None, wenn kein Muster passt. Finanzzahlen nur mit 'finanzen'."""
    tag = a.stichtag_oder_heute(stichtag)
    f = frage.lower()
    fid = finde_fahrzeug_id(db, frage)
    marke = next((MARKEN[m] for m in MARKEN if m in f), None)
    kategorie = next((KATEGORIEN[k] for k in KATEGORIEN if k in f), None)

    def mk(name, ergebnis):
        return {"text": ergebnis["text"], "daten": ergebnis.get("daten"), "werkzeug": name, "modus": "regel"}

    def lauf(name, **eingabe):
        if name in VERTRAULICH and not finanzen:
            return absage()
        if name in ("fahrzeug_details", "bestandsliste", "kennzahlen"):
            eingabe["finanzen"] = finanzen
        return mk(name, WERKZEUGE[name][1](db, tag, **eingabe))

    # „Was kostet eine Markise für DETKW00182?“ ist eine Teilefrage – das Fahrzeug bestimmt nur den Typ
    if fid and TEIL_FRAGE.search(f) and re.search(r"kost|preis|einbau|montage|nachrüst", f):
        return teile_mit_rueckfrage(db, stichtag, teil_begriff(db, frage), frage)

    # Fragen zu einem konkreten Fahrzeug
    if fid:
        d = a.get_vehicle(db, fid)
        if not d:
            return mk("fahrzeug_details", {"text": _nicht_gefunden(fid)})
        v = d["vehicle"]
        fin = _offene_finanzierung(d)

        # Finanzierung, Zinsfreiheit, Einkaufs-, Listen- und Verkaufspreis: nur für Berechtigte
        if not finanzen and re.search(r"zinsfrei|zinsbindung|zinslos|finanzier|bank|kredit|gekostet|einkauf|ek\b|"
                                      r"eingekauft|netto|brutto|preis|kostet|verkauft (für|fuer|zu)|marge|rohertrag|"
                                      r"\bwert\b|abl(ö|oe)s|abgel(ö|oe)st|tilgung", f):
            return absage()
        if re.search(r"zinsfrei|zinsbindung|zinslos", f):
            if not fin:
                return mk("fahrzeug_details", {"text": f"{fid} ist nicht finanziert (Bareinkauf) – es läuft also keine "
                                                       "Zinsfreiheit.", "daten": d})
            if not fin["interest_free_until"]:
                return mk("fahrzeug_details", {"text": f"{fid} ist bei {fin['bank']} finanziert, aber ein Ende der "
                                                       "Zinsfreiheit ist nicht hinterlegt.", "daten": d})
            rest = (dt.date.fromisoformat(fin["interest_free_until"][:10]) - dt.date.fromisoformat(tag)).days
            return mk("fahrzeug_details", {
                "text": f"{fid} ist bei {fin['bank']} zinsfrei bis {datum(fin['interest_free_until'])} – "
                        + (f"noch {tage_text(rest)}." if rest >= 0 else
                           f"das war vor {tagen_dativ(rest)}, seitdem läuft der Zins von "
                           f"{zahl(fin['interest_rate_pct'], 1)} % p. a.")
                        + f" Spätestes Ablösedatum: {datum(fin['due_date'])}.", "daten": d})
        if re.search(r"finanzier|bank|kredit|einkaufsfinanz", f):
            if not fin:
                return mk("fahrzeug_details", {"text": f"{fid} ist nicht finanziert, das Fahrzeug wurde bar "
                                                       "eingekauft.", "daten": d})
            return mk("fahrzeug_details", {
                "text": f"{fid} ist bei {fin['bank']} finanziert (Vertrag {fin['contract_no'] or '-'}, "
                        f"{eur(fin['financed_amount'])}). Zinsfrei bis {datum(fin['interest_free_until'])}, "
                        f"Ablösung spätestens {datum(fin['due_date'])}, Status {fin['status']}.", "daten": d})
        if re.search(r"gekostet|einkauf|ek\b|eingekauft|netto|preis|kostet", f):
            gesamt = (v["purchase_net"] or 0) + (v["extra_cost_net"] or 0)
            return mk("fahrzeug_details", {
                "text": f"{fid} ({v['brand']} {v['model']}) hat netto {eur(v['purchase_net'])} im Einkauf gekostet, "
                        f"mit Nebenkosten (Überführung, Zubehör, Aufbereitung) {eur(v['extra_cost_net'])} sind es "
                        f"{eur(gesamt)}. Brutto {eur(v['purchase_gross'])}. Listenpreis netto "
                        f"{eur(v['list_price_net'])}, Rohertrag also {eur((v['list_price_net'] or 0) - gesamt)}.",
                "daten": d})
        if re.search(r"wo steht|standort|platz|halle", f) or re.fullmatch(r"\s*wo (steht|ist) \S+\s*\??\s*", f):
            return mk("fahrzeug_details", {
                "text": f"{fid} steht auf {v['location'] or 'keinem hinterlegten Platz'} (Status {v['status']}, "
                        f"{a.standtage(v, tag)} Standtage).", "daten": d})
        # „Was fehlt noch für die Übergabe?“ vor der reinen Terminfrage – sonst greift das Wort „Übergabe“ zuerst
        if re.search(r"fehlt|h(ä|ae)ngt|offene punkte|bereit", f):
            return lauf("uebergabe_status", internal_id=fid)
        if re.search(r"ausgeliefert|auslieferung|übergabe|uebergabe|übergeben|uebergeben|geliefert|abgeholt|abholung",
                     f):
            lieferung = d["delivery"]
            if not lieferung:
                return mk("fahrzeug_details", {"text": f"Für {fid} ist keine Auslieferung geplant "
                                                       f"(Status {v['status']}).", "daten": d})
            text = (f"{fid} wurde am {datum(lieferung['actual_date'])} an {lieferung['customer']} "
                    f"({lieferung['city']}) ausgeliefert." if lieferung["actual_date"] else
                    f"{fid} soll am {datum(lieferung['planned_date'])} an {lieferung['customer']} "
                    f"({lieferung['city']}) übergeben werden – Status {lieferung['status']}"
                    + (f", offen: {lieferung['checklist_open']}" if lieferung["checklist_open"] else "") + ".")
            return mk("fahrzeug_details", {"text": text, "daten": d})
        if re.search(r"zulassung|zugelassen|ausnahme|euro ?6|euro ?vi|frist", f):
            frist = a.fahrzeug_zusatz(db, fid)["frist"]
            if not frist or not frist["frist"]:
                art = f" ({frist['ausnahme_art']})" if frist and frist["ausnahme_art"] else ""
                return mk("zulassungsfristen", {"text": f"Für {fid} ist keine Zulassungsfrist hinterlegt{art}.",
                                                "daten": frist})
            rest = (dt.date.fromisoformat(frist["frist"][:10]) - dt.date.fromisoformat(tag)).days
            return mk("zulassungsfristen", {
                "text": f"{fid} hat die Ausnahme „{frist['ausnahme_art'] or '–'}“: zugelassen sein muss es bis "
                        f"{datum(frist['frist'])} – "
                        + (f"noch {tage_text(rest)}." if rest >= 0 else f"die Frist ist seit {tagen_dativ(rest)} "
                                                                       "abgelaufen.")
                        + (f" Hinweis: {frist['hinweis']}." if frist["hinweis"] else ""), "daten": frist})
        if re.search(r"standtage|wie lange|steht.*seit", f):
            return mk("fahrzeug_details", {
                "text": f"{fid} steht seit {datum(v['arrival_date'])} im Bestand, das sind "
                        f"{zahl(a.standtage(v, tag))} Standtage.", "daten": d})
        return lauf("fahrzeug_details", internal_id=fid)

    # „Wo finde ich …?“ – zuerst, damit „Wo trage ich Urlaub ein?“ nicht als Urlaubsfrage endet
    if WEGWEISER_FRAGE.search(f):
        weg = wegweiser(f)
        if weg:
            return weg

    # Werkstatt ist nicht in ODIN: Werkstattaufträge laufen über CaraCamp
    if re.search(r"werkstatt|monteur|ausgelastet|auslastung|kapazit", f):
        return {"text": WERKSTATT_TEXT, "daten": None, "werkzeug": "werkstatt", "modus": "regel", "ziel": ""}

    # „Was steht heute an?“ – nur ohne Bereichswort
    if AGENDA_FRAGE.search(f) and not AGENDA_BEREICH.search(f):
        return mk("tagesuebersicht", agenda_antwort(db, tag, f, finanzen))

    # Bestandsfragen ohne konkretes Fahrzeug: die Anzahl. Den Wert nur, wenn danach gefragt ist – und nur für
    # Berechtigte.
    if re.search(r"wie viele|anzahl|bestand", f) and (marke or kategorie or "bestand" in f):
        nach_wert = bool(re.search(r"wert|kapital|gebunden|einkauf|\bek\b|kostet|gekostet|euro|€", f))
        if nach_wert and not marke and not kategorie:
            return lauf("kennzahlen") if finanzen else absage()
        antwort = mk("bestand_zaehlen", bestand_zaehlen(db, tag, marke, kategorie, mit_wert=nach_wert and finanzen))
        if nach_wert and not finanzen:
            antwort["text"] += " " + ABSAGE
        return antwort
    if re.search(r"zulassung|ausnahme|euro ?6|euro ?vi|zulassungsfrist", f):
        return lauf("zulassungsfristen", tage=finde_tage(f, 180))
    if ERWARTET_FRAGE.search(f) and "provision" not in f:
        return lauf("erwartete_zahlungen", nur_finanzierung=bool(re.search(r"finanzier|bank", f)))
    if re.search(r"zinsfrei|zinsbindung|l(ä|ae|a)uf(t|en).*aus|finanzierung.*(aus|ablauf|ende|fällig|faellig)|"
                 r"abl(ö|oe)s", f):
        return lauf("zinsfrei_ablauf", tage=finde_tage(f, 60))
    if re.search(r"tilgung|rate|abschlag|ratenplan", f):
        if not finanzen:
            return absage()
        monat = finde_monat(f, tag)
        if monat:
            return mk("tilgungen", tilgungen_monat(db, tag, monat))
        return lauf("tilgungen", tage=finde_tage(f, 90))
    if re.search(r"übergabe|uebergabe|offene punkte|was fehlt|h(ä|ae)ngt", f):
        return lauf("uebergabe_status", tage=finde_tage(f, 60))
    if re.search(r"liquidit|kontostand|saldo|cashflow|liquide", f):
        return lauf("liquiditaet")
    if "provision" in f:
        status = "offen" if "offen" in f else "ausgezahlt" if re.search(r"ausgezahlt|bezahlt", f) else None
        return lauf("provisionen", status=status)
    if re.search(r"auslieferung|übergabe|uebergabe|liefertermin", f):
        return lauf("auslieferungen", tage=finde_tage(f, 45))
    # „sat“ nur als eigenes Wort, sonst landet „Umsatz“ bei den Teilen
    if TEIL_FRAGE.search(f):
        return teile_mit_rueckfrage(db, stichtag, teil_begriff(db, frage), frage)
    if not finanzen and re.search(r"bestandswert|deckungsbeitrag|marge|rohertrag|gebundene[sn]? kapital|umsatz|"
                                  r"gewinn|ertrag", f):
        return absage()
    if re.search(r"kennzahl|überblick|ueberblick|wie steht|zusammenfassung|bestandswert|deckungsbeitrag|marge|"
                 r"gebundene[sn]? kapital", f):
        return mk("kennzahlen", kennzahlen(db, tag, finanzen))
    if marke or kategorie:
        return lauf("bestand_zaehlen", marke=marke, kategorie=kategorie)
    return None


def hilfe(finanzen=False) -> dict:
    return {
        "text": "\n".join([
            "Diese Frage habe ich nicht sicher verstanden. Ich beantworte bekannte Fragemuster direkt aus den "
            "eingelesenen Listen – ohne zu raten. Zum Beispiel:",
            *(f"• {b}" for b, nur_fin in BEISPIELE_ALLE if finanzen or not nur_fin),
        ]),
        "daten": None, "werkzeug": "hilfe", "modus": "regel",
    }


def beantworte(db, frage: str, stichtag=None, kontext=None, wissen=None, finanzen=False) -> dict:
    """Antwort auf eine Frage: {"text", "daten", "werkzeug", "modus": "regel"[, "rueckfrage"]}. Mit 'kontext' aus
    einer Rückfrage (z. B. {"teil": "markise"}) wird die Antwort darauf bezogen. 'wissen' (Liste oder Funktion, die
    sie liefert) sind die Abläufe und Anleitungen für „Wie mache ich …?“. 'finanzen': darf die fragende Person
    Finanzzahlen sehen? Ohne das sagt der Assistent bei Finanzfragen kurz ab. Keine Daten verlassen den Rechner."""
    if not frage or not frage.strip():
        return {"text": "Bitte eine Frage eingeben, zum Beispiel: " + (BEISPIELE[6] if finanzen else BEISPIELE[0]),
                "daten": None,
                "werkzeug": "hilfe", "modus": "regel"}
    frage = frage.strip()
    if isinstance(kontext, dict) and kontext.get("teil"):
        typ = typ_aus_text(db, frage)
        if typ:
            return {**teile_fuer_fahrzeug(db, stichtag, kontext["teil"], typ), "werkzeug": "teile_fuer_fahrzeug",
                    "modus": "regel"}
        if len(frage.split()) <= 3 and "?" not in frage:      # kurze Antwort, aber kein bekannter Typ
            r = teile_mit_rueckfrage(db, stichtag, kontext["teil"], "")
            if r.get("rueckfrage"):
                r["text"] = f"„{frage}“ kenne ich als Fahrzeugtyp nicht. " + r["text"]
            return r
    # Verbindliche Hausregeln gehen jedem Wissen und jedem Coaching-Rat vor
    if not finde_fahrzeug_id(db, frage):
        regel = hausregeln.assistent_antwort(frage)
        if regel:
            return regel
    if wissen is not None and WISSEN_FRAGE.search(frage.lower()) and not finde_fahrzeug_id(db, frage):
        treffer = wissen_antwort(frage, wissen() if callable(wissen) else wissen)
        if treffer:
            return treffer
    # Rat statt Daten („Kunde sagt zu teuer“, „Was würde Buffett sagen?“): Wegweiser in Beirat & Coaching
    if not finde_fahrzeug_id(db, frage):
        rat = beirat.assistent_antwort(frage)
        if rat:
            return rat
    return regel_antwort(db, frage, stichtag, bool(finanzen)) or hilfe(bool(finanzen))
