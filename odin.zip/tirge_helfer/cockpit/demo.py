"""
Demo-Datenbestand des Cockpits – übernommen aus dem muster Cockpit (scripts/seed.ts).

Solange die echten Excel-Listen nicht eingerichtet sind, zeigt das Cockpit einen erfundenen Betrieb:
35 Fahrzeuge mit Finanzierungen, Tilgungsplan, Zulassungsfristen, Auslieferungen, Werkstatt, Besetzung und
Urlaub, Teilekatalog, Liquidität, Provisionen, Kreditlinien mit kommenden Fahrzeugen und To-dos. Auch die Tests
rechnen damit.

Alle Termine hängen am Stichtag, damit die Demo immer aktuell aussieht. Der Zufall ist derselbe wie im
Original (gleicher Startwert, gleiche Reihenfolge der Ziehungen, gleiche Gleitkomma-Rechnung): mit dem Stichtag
der Demo-Oberfläche (19.09.2026) entstehen genau deren Fahrzeuge, Auslieferungen und Liquiditätszahlen.
"""

import datetime as dt
import math
import re

# ------------------------------------------------------------ Zufall wie im Original


class _Zufall:
    """Linearer Kongruenzgenerator aus seed.ts – samt der Rechenweise von JavaScript.

    JavaScript multipliziert als Gleitkommazahl (über 2^53 wird gerundet) und schneidet erst danach auf 32 Bit.
    Mit Ganzzahlen gerechnet käme eine andere Folge heraus und die Demo sähe anders aus als die Oberfläche.
    """

    def __init__(self, startwert=20260918):
        self.zustand = startwert

    def __call__(self) -> float:
        x = float(self.zustand) * 1103515245.0 + 12345.0
        self.zustand = (int(x) % 2 ** 32) & 0x7FFFFFFF
        return self.zustand / 0x7FFFFFFF

    def wahl(self, liste):
        return liste[math.floor(self() * len(liste))]

    def zwischen(self, a, b) -> float:
        return a + self() * (b - a)

    def ganz(self, a, b) -> int:
        """Math.floor(between(a, b))"""
        return math.floor(self.zwischen(a, b))


def _js_runden(x: float) -> int:
    """Math.round: bei ,5 immer aufwärts (Python rundet sonst zur geraden Zahl)."""
    unten = math.floor(x)
    return unten + 1 if x - unten >= 0.5 else unten


def _runden(n: float, schritt=10):
    return _js_runden(n / schritt) * schritt


def _cent(n: float) -> float:
    return _js_runden(n * 100) / 100


def _plus_monate_js(tag: dt.date, monate: int) -> dt.date:
    """Wie Date.setMonth im Original: ein 31. läuft in den Folgemonat über (31.01. + 1 Monat = 03.03.)."""
    jahre, monat = divmod(tag.month - 1 + monate, 12)
    return dt.date(tag.year + jahre, monat + 1, 1) + dt.timedelta(days=tag.day - 1)


def _plus_monate_erster(tag: dt.date, monate: int) -> dt.date:
    """Erster des Monats – für die Monatsreihe der Liquidität, damit ab dem 29. kein Monat doppelt vorkommt."""
    jahre, monat = divmod(tag.month - 1 + monate, 12)
    return dt.date(tag.year + jahre, monat + 1, 1)


def _werktag(tag: dt.date) -> bool:
    return tag.weekday() < 5


def _ostersonntag(jahr: int) -> dt.date:
    """Gaußsche Osterformel (gregorianisch)."""
    a, b, c = jahr % 19, jahr // 100, jahr % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    monat = (h + l_ - 7 * m + 114) // 31
    tag = (h + l_ - 7 * m + 114) % 31 + 1
    return dt.date(jahr, monat, tag)


def feiertage(jahr: int) -> list:
    """Gesetzliche Feiertage in Niedersachsen und Bremen (mit Reformationstag)."""
    ostern = _ostersonntag(jahr)
    tage = [dt.date(jahr, 1, 1), ostern - dt.timedelta(days=2), ostern + dt.timedelta(days=1),
            dt.date(jahr, 5, 1), ostern + dt.timedelta(days=39), ostern + dt.timedelta(days=50),
            dt.date(jahr, 10, 3), dt.date(jahr, 10, 31), dt.date(jahr, 12, 25), dt.date(jahr, 12, 26)]
    return sorted(tage)


# ---------------------------------------------------------------- Stammdaten der Demo

MODELLE = [
    {"prefix": "DETKW", "brand": "Hersteller1", "category": "Kastenwagen",
     "models": ["Linea 600 DR", "Linea 640 HR", "Linea 600 ES Active", "Linea 540 DS Active",
                "Linea 600 DS 95 Jahre"], "ek": [43000, 62000]},
    {"prefix": "DRM", "brand": "Hersteller1", "category": "Reisemobil",
     "models": ["Trend 7057 EBL", "Just 90 T 7052 EB", "Puls Classic T 7051", "Lineo I 6", "Alto A 7820-2",
                "GB Performance T 16"], "ek": [62000, 142000]},
    {"prefix": "DWWA", "brand": "Hersteller1", "category": "Wohnwagen",
     "models": ["Viator 560 FMK", "c'way 495 QSK", "Camper 470 ER", "Sahra Scandinavia 650"], "ek": [19000, 41000]},
    {"prefix": "SLKW", "brand": "Hersteller2", "category": "Kastenwagen",
     "models": ["Vento 640", "Vento 600", "Vento 540"], "ek": [41000, 56000]},
    {"prefix": "SLRM", "brand": "Hersteller2", "category": "Reisemobil",
     "models": ["T 68", "A 72", "T 60"], "ek": [52000, 74000]},
    {"prefix": "GW", "brand": None, "category": "Gebrauchtwagen",
     "marken": ["Hersteller4", "Hersteller5", "Hersteller6", "Hersteller1", "Hersteller3"],
     "models": ["Exsis-t 580 (2019)", "Van TI Plus 650 (2020)", "Premio 490 (2018)", "Linea 600 (2021)"],
     "ek": [26000, 68000]},
]

BANKEN = ["Nordbank", "Südbank", "Westbank", "Ostbank"]
KUERZEL = {"Nordbank": "SCB", "Südbank": "CA", "Westbank": "WF", "Ostbank": "Ostbank"}
VERKAEUFER = ["M. Muster", "S. Brenner", "T. Kowalski", "A. Reimers"]
STANDORTE = ["Halle A", "Halle B", "Freigelände Nord", "Freigelände Süd", "Aufbereitung"]
ORTE = ["Bremen", "Oldenburg", "Delmenhorst", "Verden", "Vechta", "Osnabrück", "Wildeshausen"]
# Gebrauchte fehlen hier absichtlich wie im Original: ihr VK min. bleibt leer
FRACHT = {"Kastenwagen": 1290, "Reisemobil": 1490, "Wohnwagen": 690}
HAENDLER = ["Schou", "J&A Automobile", "Caravan Nord", "Reisemobile Ems", "Wohnmobilcenter Weser"]

PAKETE = {
    "Kastenwagen": ["Sondermodell-Paket", "Markise 3,5 m", "Solaranlage 150 Wp", "Fahrerhaus-Klimaautomatik",
                    "Navigation", "Rückfahrkamera", "Fahrradträger", 'Alufelgen 16"', "Dieselheizung",
                    "Zusatzbatterie 95 Ah", "Fliegenschutztür", "Tempomat", "Einparkhilfe hinten"],
    "Reisemobil": ["Chassis-Paket Light", "Hubbett", "Backofen", "Truma Combi 6 E", "Fußbodenheizung",
                   "Außendusche", "Sat-Anlage Oyster 85", "Markise 5,0 m", "Doppelboden beheizt",
                   "Garage mit Zurrsystem", "Rückfahrkamera", 'Alufelgen 16"'],
    "Wohnwagen": ["Mover", "Markise 3,5 m", "Vorzelt", "Antischlingerkupplung", "Warmwasserboiler",
                  "Winterpaket", "Fußbodenheizung", "Dachfenster Mini Heki", "Außensteckdose",
                  "Fahrradträger Deichsel"],
}

TEILESTATUS = ["nicht bestellt", "bestellt", "teilweise geliefert", "geliefert", "teilweise im Fahrzeug",
               "alle im Fahrzeug"]
EINBAU_POSITIONEN = ["AHK starr", "AHK abnehmbar", "Unterboden & Hohlraum", "Sondereinbau"]
EINBAU_STATUS = ["offen", "beim Einbaupartner", "erledigt"]
VERFUEGBARKEIT = ["auf Lager", "im Werk fertig", "im Werk offen"]

AUS = [
    ("Fahrzeugeinkauf (Anzahlungen/Barkauf)", 60000, 140000),
    ("Finanzierungsablösung", 150000, 280000),
    ("Personal", 58000, 64000),
    ("Miete & Nebenkosten", 11000, 13500),
    ("Finanzierungszinsen", 3200, 9800),
    ("Teile & Zubehör", 14000, 38000),
    ("Marketing", 2500, 9000),
    ("Sonstiges", 4000, 11000),
]
EIN = [
    ("Fahrzeugverkauf", 240000, 470000),
    ("Werkstatt & Montage", 26000, 52000),
    ("Teileverkauf", 8000, 21000),
    ("Vermietung", 4000, 17000),
]

TEILE = [
    ("ZUB-1001", "Markise Thule Omnistor 6300 – 4,0 m", "Markisen", "Thule", 1290, 1790, 180),
    ("ZUB-1002", "Markise Fiamma F80s 3,4 m", "Markisen", "Fiamma", 890, 1290, 150),
    ("ZUB-2001", "Solaranlage 200 Wp inkl. Laderegler", "Solar", "Büttner", 620, 1090, 240),
    ("ZUB-2002", "Solaranlage 400 Wp Twin inkl. MPPT", "Solar", "Büttner", 1150, 1890, 330),
    ("ZUB-3001", "Sat-Anlage Oyster 70 Premium", "Sat & TV", "Ten Haaft", 2390, 3190, 300),
    ("ZUB-3002", "Flachantenne Selfsat Snipe", "Sat & TV", "Selfsat", 990, 1490, 210),
    ("ZUB-4001", "Fahrradträger Heck 2 Räder", "Träger", "Thule", 430, 690, 120),
    ("ZUB-4002", "Dachreling Kastenwagen", "Träger", "Fiamma", 560, 890, 180),
    ("ZUB-5001", "Rückfahrkamera Funk", "Elektrik", "Waeco", 380, 620, 150),
    ("ZUB-5002", "Zweitbatterie AGM 95 Ah inkl. Einbau", "Elektrik", "Büttner", 290, 520, 120),
    ("ZUB-5003", "Lithium-Batterie 100 Ah + Booster", "Elektrik", "Büttner", 1290, 1950, 270),
    ("ZUB-6001", "Dieselheizung Nachrüstung", "Heizung", "Truma", 1690, 2390, 420),
    ("ZUB-6002", "Klimaanlage Dachaufbau 2,4 kW", "Klima", "Truma", 1790, 2490, 300),
    ("ZUB-7001", "Anhängerkupplung abnehmbar inkl. E-Satz", "Fahrwerk", "Hersteller9", 780, 1290, 330),
    ("ZUB-7002", "Zusatzluftfederung Hinterachse", "Fahrwerk", "Goldschmitt", 1190, 1790, 270),
    ("ZUB-8001", "Sicherheitsschloss Set (3 Stück)", "Sicherheit", "Thule", 210, 390, 90),
    ("ZUB-8002", "Alarmanlage mit GPS-Ortung", "Sicherheit", "Pandora", 690, 1190, 300),
    ("SER-9001", "Gasprüfung G607", "Service", "intern", 0, 89, 45),
    ("SER-9002", "Dichtigkeitsprüfung", "Service", "intern", 0, 129, 60),
    ("SER-9003", "Winterfest-Service", "Service", "intern", 35, 219, 90),
]
# Abschnitte der Teileliste: teils schon nach den festen Typen benannt (fahrzeugtypen.py), teils noch mit den alten
# Namen – die ordnet TYP_ZUORDNUNG zu; „Kastenwagen Linea auf VW Crafter“ bleibt absichtlich offen.
TYP_JE_GRUPPE = {
    "Markisen": "Kastenwagen H2 Dach", "Solar": "Kastenwagen H3", "Sat & TV": "Reisemobil",
    "Träger": "Kastenwagen Aufstelldach", "Elektrik": "Kastenwagen H2 Dach", "Heizung": "Reisemobil",
    "Klima": "Kastenwagen Hochdach Vario", "Fahrwerk": "Kastenwagen Linea auf VW Crafter", "Sicherheit": "Wohnwagen",
    "Service": "alle Fahrzeuge",
}
TYP_ZUORDNUNG = {
    "Kastenwagen H2 Dach": "Kastenwagen H2", "Reisemobil": "Wohnmobile",
    "Kastenwagen Hochdach Vario": "Kastenwagen mit Hochdach (Vario)",
    "Kastenwagen Aufstelldach": "Kastenwagen mit Aufstelldach",
}
VARIANTEN = {"Markisen": ["weiß", "anthrazit", "silber"], "Träger": ["schwarz", "silber"], "Klima": ["weiß"]}
GEWICHT = {
    "Markisen": "23 kg", "Solar": "12 kg", "Sat & TV": "18 kg", "Träger": "9 kg", "Elektrik": "6 kg",
    "Heizung": "14 kg", "Klima": "31 kg", "Fahrwerk": "17 kg", "Sicherheit": "2 kg", "Service": "–",
}
STUNDENSATZ = 119

LINIEN = [
    ("Nordbank", "Hersteller1", 7.9, 6, 900000),
    ("Nordbank", "Hersteller2", 8.2, 6, 450000),
    ("Nordbank", "Gebrauchtfahrzeuge", 9.4, 6, 300000),
    ("Südbank", "Hersteller1", 7.4, 9, 750000),
    ("Südbank", "Hersteller2", 7.6, 9, 250000),
    ("Westbank", "Hersteller1", 8.1, 6, 600000),
    ("Westbank", "Hersteller3", 8.4, 6, 350000),
    ("Ostbank", "Hersteller1", 6.9, 12, 500000),
]

MONTEURE = [f"Monteur {n}" for n in range(1, 7)]
AUSLIEFERER = MONTEURE[:3]           # nur drei fahren Auslieferungen im Verkauf
MINUTEN_PRO_TAG = 480                # 8 Stunden à 60 Minuten

# Rhythmus und Ratenzahl sind je Bank verschieden – das Modell setzt nichts voraus
RHYTHMUS = {
    "Nordbank": (6, 2, 0.15),
    "Südbank": (3, 4, 0.1),
    "Westbank": (1, 6, 0.05),
    "Ostbank": (12, 1, 1),
}

# Kommende Fahrzeuge (Modell, Hersteller, Bank, Art, Stück, EK, in Tagen, Status). Absichtlich so gelegt, dass eine
# Linie im Frühjahr kippt – sonst zeigt die Demo den interessanten Fall nie.
VORORDER = [
    ("Linea 600 DR", "Hersteller1", "Nordbank", "Kastenwagen", 4, 58900, 70, "bestellt"),
    ("Linea 640 HR", "Hersteller1", "Nordbank", "Kastenwagen", 3, 61400, 105, "bestellt"),
    ("Trend 7057 EBL", "Hersteller1", "Nordbank", "Reisemobil", 2, 74300, 140, "geplant"),
    ("c'way 495 QSK", "Hersteller1", "Ostbank", "Wohnwagen", 5, 20800, 95, "geplant"),
    ("Vento 640 Hersteller2", "Hersteller2", "Südbank", "Kastenwagen", 3, 49700, 120, "bestellt"),
    ("Adventure Edition", "Hersteller2", "Südbank", "Reisemobil", 2, 63200, 175, "geplant"),
    ("Hersteller3 Strada R", "Hersteller3", "Westbank", "Kastenwagen", 4, 52400, 85, "bestellt"),
]

BANK_KUERZEL = {"Nordbank": "Nord.", "Südbank": "CA", "Westbank": "WF", "Ostbank": "Ostbank"}
HERSTELLER_KUERZEL = {"Hersteller1": "H1", "Hersteller2": "SL", "Hersteller3": "Hersteller3", "Gebrauchtfahrzeuge": "Gebr."}
KOMMISSIONEN = ["Lager", "Kunde Albers", "Lager", "Wohnmobile Ems", "Lager", "Kunde Fernkorn", "Lager",
                "Caravan Nord"]
KONDITIONEN_KOMMEND = {"Nordbank": "360 Tage", "Südbank": "CA 270 Tage",
                       "Westbank": "Westbank 180 Tage", "Ostbank": "Ostbank 1% Skonto"}
MONATSKUERZEL = ["Jan", "Feb", "Mär", "Apr", "Mai", "Juni", "Juli", "Aug", "Sep", "Okt", "Nov", "Dez"]


def _linienname(bank: str, hersteller: str) -> str:
    """Blattname wie in der Finanzaufstellung: „Nord. H1“, „WF Hersteller3“."""
    return f"{BANK_KUERZEL.get(bank, bank)} {HERSTELLER_KUERZEL.get(hersteller, hersteller)}"


TODOS = [
    ("Ablösung der zinsfreien Verträge mit der Bank besprechen", "Finanzierung", None, 3, "hoch"),
    ("Zulassungsbescheinigung Teil II nachfordern", "Auslieferung", 1, 5, "hoch"),
    ("Langsteher für die Herbstaktion auspreisen", "Bestand", None, 12, "normal"),
    ("Solaranlage für Übergabe bestellen", "Teile", 3, 7, "normal"),
    ("Urlaubsplanung Monteure für den nächsten Monat abstimmen", "Werkstatt", None, 9, "normal"),
    ("Inseratsbilder in Syscara aktualisieren", "Bestand", 5, -2, "normal"),
    ("Anzahlung beim Kunden nachfassen", "Auslieferung", 7, -1, "hoch"),
    ("Provisionsabrechnung Vormonat prüfen", "Allgemein", None, 20, "niedrig"),
]

QUELLE = "seed-demo"

FELDER_FAHRZEUG = [
    "internal_id", "vin", "serien_nr", "bestell_nr", "brand", "model", "category", "model_year", "condition",
    "status", "location", "lieferblock", "schluessel_nr", "lieferstatus", "kommission_art", "kommission_name",
    "jahrgang", "arrival_date", "purchase_net", "purchase_gross", "extra_cost_net", "list_price_gross",
    "list_price_net", "internet_price", "fracht", "vk_min", "sold_net", "sold_date", "customer", "salesperson",
    "notes", "caracamp_objekt", "fin_bank", "fin_vertrag", "ausstattung", "syscara", "source_file", "source_sheet",
    "updated_at"]
FELDER_AUSLIEFERUNG = [
    "vehicle_internal_id", "planned_date", "actual_date", "customer", "city", "status", "checklist_open",
    "verkaeufer", "termin_art", "vertragsdatum", "fahrzeugart", "verfuegbarkeit", "tuev_faellig", "papiere_status",
    "papiere_text", "zahlart", "zahlstatus", "anzahlung", "inzahlungnahme_fzg", "inzahlungnahme_wert",
    "inzahlungnahme_da", "werk_bezahlt", "bemerkung", "source_file"]
FELDER_TEIL = [
    "sku", "code", "artikel_nr", "name", "fahrzeugtyp", "warengruppe", "produkt", "variante", "category",
    "supplier", "movera_link", "gewicht", "preis_brutto", "lohn_vk", "vk_pro_aw", "aw", "purchase_net",
    "sales_net", "vk_brutto", "lohn_ek", "gesamt_ek_brutto", "install_minutes", "hourly_rate", "hinweis",
    "source_file", "source_sheet"]

# Was die Demo ersetzt; die Artikelverwaltung gehört dazu, sonst bleiben alte Lagerbestände stehen
TABELLEN = ["vehicles", "financings", "cash_entries", "commissions", "deliveries", "parts", "artikelstamm",
            "import_runs", "tilgungen", "zulassungsfristen", "werkstattauftraege", "sonderfahrten", "einbauten", "mitarbeiter",
            "abwesenheiten", "bank_linien", "kommende_fahrzeuge", "erwartete_zahlungen", "vororder", "abloesungen",
            "todos"]


def _einfuegen(db, tabelle: str, zeile: dict, art="INSERT"):
    spalten = list(zeile)
    db.execute(f"{art} INTO {tabelle} ({','.join(spalten)}) VALUES ({','.join(':' + s for s in spalten)})", zeile)


def _tag_monat(tag: dt.date) -> str:
    """'14.09.' – so steht der Versand des Briefs in der Auslieferungsliste."""
    return f"{tag.day:02d}.{tag.month:02d}."


# --------------------------------------------------------------------------- Aufbau


def fuelle_demo(db, stichtag=None) -> dict:
    """Ersetzt den Inhalt der Cockpit-Datenbank durch den Demo-Betrieb; Termine relativ zum Stichtag.

    Gibt die Anzahl der erzeugten Zeilen je Tabelle zurück.
    """
    heute = dt.date.fromisoformat(str(stichtag)[:10]) if stichtag else dt.date.today()
    zeitpunkt = f"{heute.isoformat()}T08:00:00"
    z = _Zufall()
    tage = dt.timedelta

    for t in TABELLEN:
        db.execute(f"DELETE FROM {t}")

    zaehler = {"DETKW": 220, "DRM": 285, "DWWA": 205, "SLKW": 290, "SLRM": 320, "GW": 440}
    erzeugt = []   # wie „created“ im Original: Grundlage für Finanzierungen, Auslieferungen, Fristen

    def ausstattung_fuer(kategorie):
        pool = PAKETE.get(kategorie) or PAKETE["Kastenwagen"]
        anzahl = 4 + math.floor(z() * 5)
        gewaehlt = []
        while len(gewaehlt) < anzahl:
            paket = pool[math.floor(z() * len(pool))]
            if paket not in gewaehlt:
                gewaehlt.append(paket)
        return ", ".join(gewaehlt)

    def neues_fahrzeug():
        m = z.wahl(MODELLE)
        zaehler[m["prefix"]] += 1
        fid = f"{m['prefix']}{zaehler[m['prefix']]:05d}"
        ek = _runden(z.zwischen(*m["ek"]), 100)
        extra = _runden(z.zwischen(900, 5200), 50)
        alter = z.ganz(10, 430)                                  # Standtage
        eingang = heute - tage(alter)
        zustand = "Neu" if z() < 0.72 else ("Vorführ" if z() < 0.5 else "Gebraucht")
        liste = _runden(ek * z.zwischen(1.14, 1.27), 100)

        # Lebenszyklus: je älter, desto wahrscheinlicher verkauft oder ausgeliefert
        r = z()
        status = "Bestand"
        if alter > 300 and r < 0.45:
            status = "Ausgeliefert"
        elif r < 0.16:
            status = "Reserviert"
        elif r < 0.58:
            status = "Verkauft"
        verkauft = status in ("Verkauft", "Ausgeliefert")
        verkauf = eingang + tage(z.ganz(alter * 0.4, alter * 0.9)) if verkauft else None
        verkauf_netto = _runden(liste * z.zwischen(0.93, 1.02), 100) if verkauft else None
        kaeufer = None
        if verkauft:
            anrede = z.wahl(["Fam.", "Herr", "Frau"])
            kaeufer = f"{anrede} " + z.wahl(["Ahrens", "Bode", "Cordes", "Dierks", "Eggers", "Frerichs", "Gerdes",
                                            "Hinrichs", "Janssen", "Köhler", "Lüders", "Meyer"])
        verkaeufer = z.wahl(VERKAEUFER) if verkauft or status == "Reserviert" else None
        angeliefert = z() < 0.78
        kommissioniert = status != "Bestand"

        # Reihenfolge der Ziehungen wie im Objekt des Originals – sonst verschiebt sich der ganze Zufall
        v = {"internal_id": fid}
        v["vin"] = f"ZFA25000{z.ganz(1000, 9999)}"
        v["vin"] += f"SM{z.ganz(10000, 99999)}"
        a = z.ganz(25, 27)
        b = z.ganz(100, 999)
        v["serien_nr"] = f"{a} {b} {z.ganz(1, 99):03d}"
        v["bestell_nr"] = str(z.ganz(1454100, 1454399))
        v["brand"] = m["brand"] if m["brand"] is not None else z.wahl(m["marken"])
        v["model"] = z.wahl(m["models"])
        v["category"] = m["category"]
        v["model_year"] = 2025 + z.ganz(0, 3)
        v["condition"] = zustand
        v["status"] = status
        v["location"] = None if status == "Ausgeliefert" else (z.wahl(STANDORTE) if angeliefert else None)
        v["lieferblock"] = None if angeliefert else z.wahl(["B1", "B2", "B3"])
        v["schluessel_nr"] = str(z.ganz(2000, 5999)) if angeliefert else None
        v["lieferstatus"] = "angeliefert" if angeliefert else "geplant"
        v["kommission_art"] = "Kommission" if kommissioniert else "Lager"
        v["kommission_name"] = (kaeufer if kaeufer is not None else z.wahl(HAENDLER)) if kommissioniert else None
        v["jahrgang"] = 2025 + z.ganz(0, 3)
        v["arrival_date"] = eingang.isoformat()
        v["purchase_net"] = ek
        v["purchase_gross"] = _runden(ek * 1.19, 1)
        v["extra_cost_net"] = extra
        v["list_price_gross"] = _runden(liste * 1.19, 100)
        v["list_price_net"] = liste
        v["internet_price"] = _runden(liste * 1.19 * 0.98, 100) if z() < 0.6 else None
        v["fracht"] = None
        v["vk_min"] = _runden((ek + FRACHT[m["category"]]) * 1.1, 10) if m["category"] in FRACHT else None
        v["sold_net"] = verkauf_netto
        v["sold_date"] = verkauf.isoformat() if verkauf else None
        v["customer"] = kaeufer
        v["salesperson"] = verkaeufer
        v["notes"] = None
        # „Finanziert“: meist Bank und Vertragsnummer, sonst die CaraCamp-Objektnummer
        r = z()
        if r < 0.6:
            v["fin_bank"] = z.wahl(BANKEN)
            v["fin_vertrag"] = f"{z.ganz(8000, 62000):05d}"
            v["caracamp_objekt"] = None
        elif r < 0.85:
            v["fin_bank"] = v["fin_vertrag"] = None
            v["caracamp_objekt"] = str(z.ganz(114000, 115999))
        else:
            v["fin_bank"] = v["fin_vertrag"] = v["caracamp_objekt"] = None
        v["ausstattung"] = ausstattung_fuer(m["category"])
        v["syscara"] = "inseriert" if z() < 0.5 else None
        v.update(source_file=QUELLE, source_sheet="Demo", updated_at=heute.isoformat())
        _einfuegen(db, "vehicles", {f: v.get(f) for f in FELDER_FAHRZEUG})
        erzeugt.append({"id": fid, "status": status, "ek": ek, "extra": extra, "eingang": eingang,
                        "verkauf": verkauf, "kaeufer": kaeufer, "verkaeufer": verkaeufer, "liste": liste})

    # ---- Referenzfahrzeug aus den Beispielfragen: DETKW00182
    ek_ref = 58016.88
    _einfuegen(db, "vehicles", {
        "internal_id": "DETKW00182", "vin": "ZFA250009TG022785", "serien_nr": "26 656 024", "bestell_nr": "1454182",
        "brand": "Hersteller1", "model": "Linea 600 ER", "category": "Kastenwagen", "model_year": 2026,
        "condition": "Neu", "status": "Bestand", "location": "Halle A",
        "lieferblock": None, "schluessel_nr": "4417", "lieferstatus": "angeliefert",
        "kommission_art": "Lager", "kommission_name": None, "jahrgang": 2026,
        "arrival_date": (heute - tage(212)).isoformat(), "purchase_net": ek_ref,
        "purchase_gross": _runden(ek_ref * 1.19, 1), "extra_cost_net": 3450,
        "list_price_gross": 76900, "list_price_net": _runden(76900 / 1.19, 1),
        "internet_price": 75900, "fracht": None, "vk_min": _runden((ek_ref + 1290) * 1.1, 10),
        "sold_net": None, "sold_date": None, "customer": None, "salesperson": None,
        "notes": "Vorführfahrzeug-Kandidat, Markise + Solar nachgerüstet",
        "caracamp_objekt": None, "fin_bank": "Westbank", "fin_vertrag": "08977",
        "ausstattung": "Sondermodell-Paket, Markise 4,0 m, Solaranlage 150 Wp, Fahrerhaus-Klimaautomatik, "
                       'Navigation, Rückfahrkamera, Fahrradträger, Alufelgen 16", Dieselheizung, Fliegenschutztür',
        "syscara": "inseriert", "source_file": QUELLE, "source_sheet": "Demo", "updated_at": heute.isoformat(),
    })
    erzeugt.append({"id": "DETKW00182", "status": "Bestand", "ek": ek_ref, "extra": 3450,
                    "eingang": heute - tage(212), "verkauf": None, "kaeufer": None, "verkaeufer": None,
                    "liste": _runden(76900 / 1.19, 1)})
    _einfuegen(db, "financings", {
        "vehicle_internal_id": "DETKW00182", "bank": "Ostbank", "contract_no": "Ostbank-2026-004417",
        "financed_amount": ek_ref, "start_date": (heute - tage(212)).isoformat(),
        "interest_free_until": (heute + tage(34)).isoformat(), "interest_rate_pct": 7.9, "term_months": 12,
        "due_date": (heute + tage(153)).isoformat(), "status": "offen",
        "notes": "Einkaufsfinanzierung, 8 Monate zinsfrei", "source_file": QUELLE, "updated_at": heute.isoformat(),
    })

    for _ in range(34):
        neues_fahrzeug()

    # ---- Finanzierungen
    for v in erzeugt:
        if v["id"] == "DETKW00182" or z() < 0.12:            # bar eingekauft
            continue
        bank = z.wahl(BANKEN)
        beginn = v["eingang"] + tage(z.ganz(0, 9))
        zinsfrei_tage = z.wahl([180, 240, 270, 300, 365])
        abgeloest = v["status"] == "Ausgeliefert" or (v["status"] == "Verkauft" and z() < 0.5)
        vertrag = f"{KUERZEL[bank]}-2026-{z.ganz(1000, 9999)}"
        betrag = _runden(v["ek"] * z.zwischen(0.85, 1.0), 100)
        _einfuegen(db, "financings", {
            "vehicle_internal_id": v["id"], "bank": bank, "contract_no": vertrag, "financed_amount": betrag,
            "start_date": beginn.isoformat(), "interest_free_until": (beginn + tage(zinsfrei_tage)).isoformat(),
            "interest_rate_pct": _runden(z.zwischen(6.4, 9.2), 0.1), "term_months": 12,
            "due_date": (beginn + tage(zinsfrei_tage + 180)).isoformat(),
            "status": "abgelöst" if abgeloest else "offen", "notes": None, "source_file": QUELLE,
            "updated_at": heute.isoformat(),
        })

    # ---- Auslieferungen und Provisionen
    def auslieferung(v, geplant, erledigt):
        """Eine Zeile mit allen Statusfeldern, wie sie die echte Liste über Farben führt."""
        bezahlt = erledigt is not None or z() < 0.35
        angezahlt = not bezahlt and z() < 0.5
        in_zahlung = z() < 0.25
        rechnung = bezahlt or z() < 0.6
        d = {"vehicle_internal_id": v["id"], "planned_date": geplant.isoformat(),
             "actual_date": erledigt.isoformat() if erledigt else None,
             "customer": v["kaeufer"] if v["kaeufer"] is not None else "-"}
        d["city"] = z.wahl(ORTE)
        d["status"] = "ausgeliefert" if erledigt else ("bestätigt" if z() < 0.6 else "geplant")
        d["checklist_open"] = None if erledigt else z.wahl(
            ["Zulassung offen", "Zubehörmontage offen", None, "Gasprüfung offen"])
        d["verkaeufer"] = v["verkaeufer"] if v["verkaeufer"] is not None else z.wahl(VERKAEUFER)
        d["termin_art"] = "Kundenabholung" if z() < 0.82 else z.wahl(["extern", "Verbringung"])
        d["vertragsdatum"] = v["verkauf"].isoformat() if v["verkauf"] else None
        d["fahrzeugart"] = "neu" if z() < 0.8 else "gebraucht"
        d["verfuegbarkeit"] = "auf Lager" if erledigt else z.wahl(VERFUEGBARKEIT)
        d["tuev_faellig"] = 1 if z() < 0.15 else 0
        # Papierstatus und Beschriftung gehören zusammen, wie in der echten Liste
        papiere = "beim Kunden" if erledigt else z.wahl(["beim Kunden", "im Werk", "bei uns"])
        versandt = geplant - tage(z.ganz(2, 20))
        if papiere == "beim Kunden":
            text = f"Brief Kunde {_tag_monat(versandt)}"
        elif papiere == "im Werk":
            text = "Brief Hersteller1"
        else:
            text = z.wahl(["Brief wir – Tageszulassung", "Brief/Ausnahme wir"])
        d["papiere_status"], d["papiere_text"] = papiere, text
        d["zahlart"] = "VDR" if rechnung else "AB"
        d["zahlstatus"] = "bezahlt" if bezahlt else ("angezahlt" if angezahlt else "offen")
        d["anzahlung"] = _runden(z.zwischen(2000, 15000), 100) if angezahlt else None
        d["inzahlungnahme_fzg"] = z.wahl(["Hersteller4 Exsis-t 580 (2017)", "Hersteller5 Sky TI (2016)",
                                          "Hersteller6 Premio (2015)", "VW T6 California (2018)"]) if in_zahlung else None
        d["inzahlungnahme_wert"] = _runden(z.zwischen(18000, 62000), 500) if in_zahlung else None
        d["inzahlungnahme_da"] = (1 if z() < 0.5 else 0) if in_zahlung else None
        d["werk_bezahlt"] = 1 if z() < 0.75 else 0
        d["bemerkung"] = z.wahl([None, "Gutschein 250 € offen", "Restzahlung bei Übergabe",
                                 "Kunde bringt Altfahrzeug mit", None])
        d["source_file"] = QUELLE
        return d

    for v in erzeugt:
        if v["status"] == "Ausgeliefert" and v["verkauf"]:
            geplant = v["verkauf"] + tage(21)
            _einfuegen(db, "deliveries", auslieferung(v, geplant, v["verkauf"] + tage(z.ganz(18, 40))))
        elif v["status"] == "Verkauft" and v["verkauf"]:
            _einfuegen(db, "deliveries", auslieferung(v, heute + tage(z.ganz(3, 55)), None))
        if v["verkauf"]:
            db_betrag = (v["liste"] or 0) - v["ek"] - v["extra"]
            satz = _runden(z.zwischen(8, 14), 0.5)
            ausgezahlt = v["status"] == "Ausgeliefert"
            _einfuegen(db, "commissions", {
                "vehicle_internal_id": v["id"],
                "salesperson": v["verkaeufer"] if v["verkaeufer"] is not None else z.wahl(VERKAEUFER),
                "sale_date": v["verkauf"].isoformat(), "basis_amount": _runden(db_betrag, 10), "rate_pct": satz,
                "amount": _runden((db_betrag * satz) / 100, 5), "status": "ausgezahlt" if ausgezahlt else "offen",
                "payout_date": _plus_monate_js(v["verkauf"], 1).isoformat() if ausgezahlt else None,
                "source_file": QUELLE,
            })

    # ---- Liquidität: 6 Monate Ist, 6 Monate Plan
    _einfuegen(db, "cash_entries", {
        "entry_date": _plus_monate_js(heute, -7).isoformat(), "kind": "ist", "direction": "ein",
        "category": "Anfangsbestand", "amount": 268000, "account": "Sparkasse 4711",
        "description": "Saldovortrag", "source_file": QUELLE})
    for m in range(-6, 7):
        monat = _plus_monate_erster(heute, m)
        art = "ist" if m <= 0 else "plan"
        saison = 1 + 0.28 * math.sin(((monat.month - 1 - 2) / 12) * 2 * math.pi)   # Frühjahr stark
        zusatz = " (Plan)" if art == "plan" else ""
        for kategorie, minimum, maximum in EIN:
            _einfuegen(db, "cash_entries", {
                "entry_date": monat.replace(day=12).isoformat(), "kind": art, "direction": "ein",
                "category": kategorie, "amount": _runden(z.zwischen(minimum, maximum) * saison, 100),
                "account": "Sparkasse 4711", "description": kategorie + zusatz, "vehicle_internal_id": None,
                "source_file": QUELLE})
        for kategorie, minimum, maximum in AUS:
            faktor = saison if re.search(r"Fahrzeugeinkauf|Finanzierungsabl", kategorie) else 1
            _einfuegen(db, "cash_entries", {
                "entry_date": monat.replace(day=20).isoformat(), "kind": art, "direction": "aus",
                "category": kategorie, "amount": _runden(z.zwischen(minimum, maximum) * faktor, 100),
                "account": "Sparkasse 4711", "description": kategorie + zusatz, "vehicle_internal_id": None,
                "source_file": QUELLE})

    # ---- Teile-, Einbau- und Montagezeitenliste
    vk_je_aw = _cent(STUNDENSATZ / 10)        # 1 AW = 6 Minuten
    teile_zaehler = 100
    for _sku, name, gruppe, lieferant, ek, vk, minuten in TEILE:
        code = f"SA{teile_zaehler:05d}"
        teile_zaehler += 10
        artikel_nr = None if lieferant == "intern" else f"99{z.ganz(100000, 999999)}"
        aw = _js_runden((minuten / 6) * 10) / 10
        lohn_vk = _cent(aw * vk_je_aw)
        # interne Lohnkosten: knapp die Hälfte des Lohnverkaufs, plus Kleinteile
        lohn_ek = _cent(lohn_vk * 0.46 + 12)
        _einfuegen(db, "parts", dict(zip(FELDER_TEIL, [
            code, code, artikel_nr, name, TYP_JE_GRUPPE.get(gruppe, "alle Fahrzeuge"), gruppe, name,
            z.wahl(VARIANTEN[gruppe]) if gruppe in VARIANTEN else None, gruppe, lieferant,
            f"https://www.movera.com/DE/de/product/{artikel_nr}" if artikel_nr else None, GEWICHT.get(gruppe),
            _cent(vk * 1.19), lohn_vk, vk_je_aw, aw, ek, vk, _cent(vk * 1.19), lohn_ek, _cent((ek + lohn_ek) * 1.19),
            minuten, STUNDENSATZ,
            "Wird beim Kastenwagen mit Hochdach nur in Verbindung mit Dachverstärkung verbaut."
            if gruppe == "Klima" else None,
            QUELLE, "Preisliste"])))
        if artikel_nr:
            _einfuegen(db, "artikelstamm", {
                "artikel_nr": artikel_nr, "bezeichnung": name,
                "bestand": z.ganz(1, 9) if z() < 0.55 else 0,
                "stamm_ek": ek, "stamm_vk": _cent(vk * 1.19), "source_file": QUELLE}, "INSERT OR REPLACE")

    # ---- Kreditlinien je Bank und Hersteller – wie die Linienblätter der Finanzaufstellung („Nord. H1“)
    for bank, hersteller, zins, monate, limit in LINIEN:
        _einfuegen(db, "bank_linien", {
            "bank": bank, "hersteller": hersteller, "zins_pct": zins, "zinsfrei_monate": monate,
            "limit_betrag": limit, "hinweis": None, "linie": _linienname(bank, hersteller),
            "konditionen": f"{zins:g} %".replace(".", ",") + " nach Ablauf"
                           + (" · plus Bereitstellung 0,40 % p. a." if bank == "Nordbank" else ""),
            "source_file": QUELLE}, "INSERT OR REPLACE")
    # Hersteller und Linie an der Finanzierung, wie sie der Import aus dem Blattnamen liest (ohne neue Zufallszahlen)
    db.execute("""UPDATE financings SET hersteller = (
                      SELECT CASE WHEN v.category = 'Gebrauchtwagen' THEN 'Gebrauchtfahrzeuge' ELSE v.brand END
                      FROM vehicles v WHERE v.internal_id = financings.vehicle_internal_id)""")
    db.execute("""UPDATE financings SET linie = (SELECT bl.linie FROM bank_linien bl
                                                 WHERE bl.bank = financings.bank AND bl.hersteller = financings.hersteller)""")

    # ---- Mitarbeiter: Testbesetzung, bis die echten Namen feststehen
    besetzung = [(n, "Werkstatt", 1 if i < 3 else 0) for i, n in enumerate(MONTEURE)]
    besetzung += [(n, "Waschplatz", 0) for n in ("Waschplatz 1", "Waschplatz 2")]
    besetzung += [(n, "Shop", 0) for n in ("Shop 1", "Shop 2")]
    besetzung += [(n, "Verkauf", 0) for n in VERKAEUFER]
    for name, bereich, auslieferung_ja in besetzung:
        _einfuegen(db, "mitarbeiter", {"name": name, "bereich": bereich, "minuten_pro_tag": MINUTEN_PRO_TAG,
                                       "auslieferung": auslieferung_ja, "aktiv": 1})

    # ---- Feiertage und Urlaub, wie sie aus dem Jahresplaner kommen. Das Original hatte feste Daten
    # (2026/27); hier die echten Feiertage der nächsten gut acht Monate, damit die Demo zu jedem Stichtag passt.
    bis = heute + tage(250)
    for jahr in range(heute.year, bis.year + 1):
        for tag in feiertage(jahr):
            if heute <= tag <= bis:
                for name, _bereich, _a in besetzung:
                    _einfuegen(db, "abwesenheiten", {"mitarbeiter": name, "datum": tag.isoformat(),
                                                     "art": "Feiertag", "bereich": None, "source_file": QUELLE},
                               "INSERT OR IGNORE")
    for name in [*MONTEURE, "Waschplatz 1", "Shop 1"]:
        wochen = 1 + math.floor(z() * 2)
        for _ in range(wochen):
            beginn = heute + tage(z.ganz(7, 130))
            for t in range(5):
                tag = beginn + tage(t)
                if not _werktag(tag):
                    continue
                _einfuegen(db, "abwesenheiten", {
                    "mitarbeiter": name, "datum": tag.isoformat(), "art": "Urlaub",
                    "bereich": "Werkstatt" if name.startswith("Monteur") else None, "source_file": QUELLE},
                    "INSERT OR IGNORE")

    # ---- Werkstattaufträge: Auslieferungen und normale Serviceaufträge
    offene = db.execute("SELECT vehicle_internal_id, planned_date FROM deliveries WHERE actual_date IS NULL "
                        "ORDER BY id").fetchall()
    for d in offene:
        _einfuegen(db, "werkstattauftraege", {
            "vehicle_internal_id": d["vehicle_internal_id"], "arbeitskarte": str(z.ganz(692000, 694999)),
            "art": "Auslieferung", "termin": d["planned_date"],
            "geplante_minuten": _runden(z.zwischen(120, 720), 30),
            "teilestatus": z.wahl(TEILESTATUS), "tankstatus": z.wahl(["offen", "in Arbeit", "fertig getankt"]),
            "monteur": z.wahl(AUSLIEFERER), "bemerkung": None, "source_file": QUELLE})
        # Zubehör, das vor der Übergabe eingebaut sein muss
        anzahl = 1 + math.floor(z() * 3)
        for position in EINBAU_POSITIONEN[:anzahl]:
            _einfuegen(db, "einbauten", {
                "vehicle_internal_id": d["vehicle_internal_id"], "position": position,
                "beschreibung": z.wahl(["Savico Vario LED", "Alarmanlage mit GPS", "Zusatzluftfederung"])
                if position == "Sondereinbau" else None,
                "status": z.wahl(EINBAU_STATUS), "source_file": QUELLE})

    werkstatt_fahrzeuge = [v for v in erzeugt if v["status"] != "Ausgeliefert"]
    for _ in range(110):
        v = z.wahl(werkstatt_fahrzeuge)
        termin = heute + tage(z.ganz(1, 56))
        while not _werktag(termin):                         # auf den nächsten Werktag schieben
            termin += tage(1)
        _einfuegen(db, "werkstattauftraege", {
            "vehicle_internal_id": v["id"], "arbeitskarte": str(z.ganz(692000, 694999)),
            "art": "Serviceauftrag", "termin": termin.isoformat(),
            "geplante_minuten": _runden(z.zwischen(90, 720), 30),
            "teilestatus": z.wahl(TEILESTATUS), "tankstatus": "offen", "monteur": z.wahl(MONTEURE),
            "bemerkung": z.wahl(["Gasprüfung", "Dichtigkeitsprüfung", "Solaranlage nachrüsten", "Markise montieren",
                                 "Winterfest-Service"]),
            "source_file": QUELLE})

    # Ein knappes Drittel der Übergaben ist vollständig vorbereitet – sonst zeigt die Ampel nie den grünen Fall.
    for d in db.execute("SELECT id, vehicle_internal_id, planned_date FROM deliveries WHERE actual_date IS NULL "
                        "ORDER BY id").fetchall():
        if z() > 0.3:
            continue
        versandt = dt.date.fromisoformat(d["planned_date"]) - tage(z.ganz(3, 15))
        db.execute("""UPDATE deliveries SET papiere_status = 'beim Kunden', papiere_text = :text,
                      zahlart = 'VDR', zahlstatus = 'bezahlt', anzahlung = NULL, werk_bezahlt = 1,
                      tuev_faellig = 0, status = 'bestätigt', checklist_open = NULL WHERE id = :id""",
                   {"id": d["id"], "text": f"Brief Kunde {_tag_monat(versandt)}"})
        db.execute("""UPDATE werkstattauftraege SET teilestatus = 'alle im Fahrzeug', tankstatus = 'fertig getankt'
                      WHERE vehicle_internal_id = ? AND art = 'Auslieferung'""", (d["vehicle_internal_id"],))
        db.execute("UPDATE einbauten SET status = 'erledigt' WHERE vehicle_internal_id = ?",
                   (d["vehicle_internal_id"],))

    # ---- Tilgungsplan: Rhythmus und Anzahl je Bank verschieden
    for f in db.execute("""SELECT vehicle_internal_id, bank, financed_amount, interest_free_until
                           FROM financings WHERE status = 'offen' ORDER BY id""").fetchall():
        monate, raten, anteil = RHYTHMUS.get(f["bank"], (3, 3, 0.1))
        beginn = dt.date.fromisoformat(f["interest_free_until"])
        for i in range(1, raten + 1):
            faellig = _plus_monate_js(beginn, i * monate)
            # bis einschließlich Stichtag fällige Raten sind bezahlt (das Original rechnete ab Mitternacht)
            bezahlt = (faellig + tage(z.ganz(0, 5))).isoformat() if faellig <= heute else None
            _einfuegen(db, "tilgungen", {
                "vehicle_internal_id": f["vehicle_internal_id"], "bank": f["bank"],
                "faellig_am": faellig.isoformat(), "betrag": _runden(f["financed_amount"] * anteil, 1),
                "bezahlt_am": bezahlt, "source_file": QUELLE}, "INSERT OR IGNORE")

    # ---- Zulassungsfristen aus Ausnahmegenehmigungen. Das Original nannte feste Tage (30.06.2027, 31.12.2027);
    # hier dieselben Abstände zum Stichtag: Monatsende in neun Monaten und Jahresende im Folgejahr.
    frist_kurz = _plus_monate_erster(heute, 10) - tage(1)
    frist_lang = dt.date(heute.year + 1, 12, 31)
    for v in erzeugt:
        if v["status"] == "Ausgeliefert":
            continue
        r = z()
        if r < 0.45:
            frist = {"ausnahme_art": "Stellantis EURO 6 (EA)", "frist": frist_kurz.isoformat(),
                     "hinweis": "muss bis zum Fristende zugelassen sein"}
        elif r < 0.62:
            frist = {"ausnahme_art": "GSRII Euro VI", "frist": frist_lang.isoformat(), "hinweis": None}
        elif r < 0.72:
            frist = {"ausnahme_art": "Stellantis EURO 6 (EA)",
                     "frist": (heute + tage(z.ganz(20, 110))).isoformat(),
                     "hinweis": "kurze Frist, Zulassung einplanen"}
        else:
            frist = {"ausnahme_art": "keine Ausnahme", "frist": None, "hinweis": None}
        _einfuegen(db, "zulassungsfristen", {"vehicle_internal_id": v["id"], **frist, "source_file": QUELLE},
                   "INSERT OR REPLACE")

    # ---- Kommende Fahrzeuge: unten in den Linienblättern der Finanzaufstellung, je Fahrzeug eine Zeile. Bestellte
    # mit KW, nur geplante mit einem Zeitraum wie „Feb/Mär“ – so steht es auch in der echten Liste.
    nr = 0
    for bezeichnung, hersteller, bank, _kategorie, anzahl, ek, in_tagen, status in VORORDER:
        termin = heute + tage(in_tagen)
        if status == "bestellt":
            jahr, woche, _ = termin.isocalendar()
            text = f"KW {woche}/{jahr}"
        else:
            text = f"{MONATSKUERZEL[termin.month - 1]}/{MONATSKUERZEL[termin.month % 12]}"
        for _ in range(anzahl):
            kommission = KOMMISSIONEN[nr % len(KOMMISSIONEN)]
            nr += 1
            art, kunde = ("Lager", None) if kommission == "Lager" else ("Kommission", kommission.removeprefix("Kunde "))
            _einfuegen(db, "kommende_fahrzeuge", {
                "bank": bank, "hersteller": hersteller, "linie": _linienname(bank, hersteller),
                "kommission": kommission, "kommission_art": art, "kunde": kunde, "internal_id": None,
                "modell": bezeichnung, "termin_text": text, "termin_datum": termin.isoformat(),
                "konditionen": KONDITIONEN_KOMMEND.get(bank), "betrag": ek, "ek_netto": ek,
                "source_file": QUELLE, "source_sheet": _linienname(bank, hersteller), "zeile": None})

    # ---- Zu erwartende Zahlungen (erstes Blatt der Finanzaufstellung): Kundenfinanzierungen, die die Bank noch nicht
    # ausgezahlt hat, und Überweisungen. Drei gehören zu offenen Übergaben, zwei Kunden sind erfunden und ohne Übergabe.
    # Ohne Zufall, damit die übrigen Demo-Zahlen gleich bleiben.
    offen_uebergaben, namen = [], set()
    for d in db.execute("""
            SELECT d.vehicle_internal_id, d.customer, d.planned_date, v.model, v.list_price_gross
            FROM deliveries d JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
            WHERE d.actual_date IS NULL AND d.zahlstatus <> 'bezahlt' AND d.customer <> '-'
            ORDER BY d.planned_date, d.id""").fetchall():
        name = str(d["customer"]).split(" ")[-1]
        if name not in namen and len(offen_uebergaben) < 3:            # drei verschiedene Kunden
            namen.add(name)
            offen_uebergaben.append(d)
    erwartet = []
    for nr, d in enumerate(offen_uebergaben):
        art, bank, am = [("Finanzierung", "Nordbank", heute + tage(2)),
                         ("Finanzierung", None, None), ("Überweisung", None, dt.date.fromisoformat(d["planned_date"]))][nr]
        erwartet.append({"kunde": str(d["customer"]).split(" ")[-1], "fahrzeug": d["model"],
                         "internal_id": d["vehicle_internal_id"], "art": art, "bank": bank,
                         "betrag": _runden((d["list_price_gross"] or 60000) * 0.8, 10),
                         "erwartet_am": am.isoformat() if am else None,
                         "erwartet_text": f"bis {_tag_monat(am)}" if am else "nach Zulassung",
                         "status": "Bank zahlt noch aus" if art == "Finanzierung" else "offen", "offen": 1,
                         "bemerkung": "Unterlagen bei der Bank" if nr == 0 else None})
    erwartet += [
        {"kunde": "Iwersen", "fahrzeug": "Linea 600 DR", "internal_id": None, "art": "Finanzierung",
         "bank": "Südbank", "betrag": 61900.0, "erwartet_am": (heute + tage(5)).isoformat(),
         "erwartet_text": f"bis {_tag_monat(heute + tage(5))}", "status": "Bank zahlt noch aus", "offen": 1,
         "bemerkung": None},
        {"kunde": "Janssen", "fahrzeug": "Vento 540", "internal_id": None, "art": "Überweisung", "bank": None,
         "betrag": 18400.0, "erwartet_am": None, "erwartet_text": None, "status": "eingegangen", "offen": 0,
         "bemerkung": "bezahlt"},
    ]
    for zeile_nr, e in enumerate(erwartet, start=5):
        _einfuegen(db, "erwartete_zahlungen", {
            **e, "text": " ".join(x for x in (e["kunde"], e["fahrzeug"], e["art"]) if x), "source_file": QUELLE,
            "source_sheet": "Finanzaufstellung", "zeile": zeile_nr})

    # ---- To-dos
    for text, bereich, fahrzeug, in_tagen, prioritaet in TODOS:
        _einfuegen(db, "todos", {
            "text": text, "bereich": bereich,
            "bezug_id": erzeugt[fahrzeug % len(erzeugt)]["id"] if fahrzeug is not None else None,
            "faellig_am": (heute + tage(in_tagen)).isoformat(), "prioritaet": prioritaet, "erledigt": 0,
            "erledigt_am": None, "angelegt_von": "Demo", "angelegt_am": zeitpunkt})
    _einfuegen(db, "todos", {
        "text": "Bestandsliste Jahrgang 2027 eingelesen", "bereich": "Bestand", "bezug_id": None,
        "faellig_am": None, "prioritaet": "niedrig", "erledigt": 1,
        "erledigt_am": (heute - tage(4)).isoformat(), "angelegt_von": "Demo", "angelegt_am": zeitpunkt})

    # ---- Sonderfahrten, Hinweise und Lehrgänge (Freitextzeilen der Auslieferungsliste)
    montag = heute - tage(heute.weekday())
    kw = montag.isocalendar()[1]
    for datum, bis, woche, art, text in (
            (heute + tage(1), None, 0, "sonderfahrt", "Abgabe IVECO Langenhagen, undichte Frontscheibe"),
            (heute + tage(2), None, 0, "sonderfahrt", "Servicetermin VW Podbi, Abgabe 10:00 Uhr"),
            (montag, montag + tage(6), 1, "sonderfahrt", "Instandsetzung Mietwagen Lineo I 6"),
            (montag + tage(10), None, 0, "hinweis", "KEINE AUSLIEFERUNGEN!!!"),
            (montag + tage(7), montag + tage(9), 0, "lehrgang", "Monteur 1 und Monteur 2 im Werk Hersteller1")):
        _einfuegen(db, "sonderfahrten", {
            "datum": datum.isoformat(), "bis": bis.isoformat() if bis else None, "ganze_woche": woche,
            "kw": kw if woche else datum.isocalendar()[1], "art": art, "text": text, "arbeitskarte": None,
            "pruefen": 0, "source_file": QUELLE})

    _einfuegen(db, "import_runs", {
        "source_file": QUELLE, "mapping": "demo", "sheet": "-", "rows_read": len(erzeugt),
        "rows_written": len(erzeugt), "warnings": None, "ran_at": zeitpunkt})
    db.commit()
    return {t: db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in TABELLEN}
