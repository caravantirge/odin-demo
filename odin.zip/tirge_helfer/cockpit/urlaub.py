"""
Urlaubsplaner lesen: Kreuztabelle mit Monatsblöcken und Tagesspalten → Abwesenheiten je Mitarbeiter und Tag.

Im muster Cockpit gab es dafür noch keinen Leser (dort standen Testdaten). Ein Blatt je Jahr und Bereich („2027
Werkstatt“, „2027 Vorne“), Zeilen sind Bereiche oder Teams, Spalten die Tage 1–31, in der Zelle steht der Name dessen,
der Urlaub hat. Die Füllfarben sagen Wochenende, Feiertag, Schulferien, Urlaub möglich, nicht möglich oder belegt.

Zwei Aufbauten werden erkannt:
- Der echte Jahresplaner (Bildschirmfoto des Inhabers): EINE Kopfzeile mit den Tageszahlen 1–31 für das ganze Blatt,
  darunter je Monat ein Block – Monatszeile („Jan“ in Spalte A, in den Tagesspalten „Fr“, „Sa“, „Mo 1“ mit der
  Kalenderwoche am Montag), eine Notizzeile (Feiertagsnamen, „Hausmesse“, Messen) und die Bereichszeilen
  („Werkstatt“ zwei- bis dreimal, „Waschplatz“, „Shop“). „Alle“ in einer Zelle heißt Betriebsurlaub. Unten steht ein
  Textfeld mit den Urlaubsregeln (Gruppen, Hausmesse) – das kommt als Hinweis in den Bericht und auf Wunsch als
  Regelvorschlag für die Urlaubsanträge (regel_vorschlag_aus_planer).
- Ältere/andere Pläne: je Monat eine eigene Reihe Tageszahlen (oder echte Datumswerte), der Monat steht darüber,
  links daneben oder im Datum; Blöcke nebeneinander (12 × 31 Spalten) oder untereinander.
Was der Leser verstanden hat, steht als Hinweis im Bericht.

Farben: zuerst gilt die Legende im Blatt selbst („Legende:“ mit farbigen Zellen), dann die Legende „urlaub“ in
vorlagen/farben.json. So stimmt auch ein Ton, den farben.json nicht kennt (das Khaki der „zweiten Stufe“).

Ergebnis in der Datenbank:
- Urlaub: eine Zeile je Person und Tag (art „Urlaub“), Bereich aus der Zeile oder dem Blattnamen;
- „Alle“: art „Betriebsurlaub“ für jeden aus dem Blatt und jeden Mitarbeiter derselben Bereiche;
- Feiertage (rosa, Feiertagsname in der Notizzeile an einem gesetzlichen Feiertag) und Betriebsruhe: art „Feiertag“
  für jeden Mitarbeiter, damit die Kapazität stimmt;
- rot („Urlaub nicht möglich“): art „gesperrt“ unter dem Namen „Urlaubssperre <Zeile>“ – bewusst kein Personenname,
  denn die Kapazitätsrechnung zählt jede Abwesenheit, und eine Urlaubssperre heißt ja gerade: alle sind da.
"""

import posixpath
import re
import zipfile
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from xml.etree import ElementTree

from .db import parameter
from .demo import feiertage as gesetzliche_feiertage
from .excel import (MONATSNAMEN, deute_farbe, farbabstand, ist_neutral, lies_arbeitsmappe, monat_aus_text,
                    normalisiere, spaltenbuchstabe, zu_text)

BEREICHE = {"werkstatt": "Werkstatt", "waschplatz": "Waschplatz", "shop": "Shop", "verkauf": "Verkauf",
            "vorne": "Vorne", "buero": "Büro", "lager": "Lager", "aufbereitung": "Aufbereitung",
            "service": "Service", "verwaltung": "Verwaltung", "buchhaltung": "Buchhaltung", "teile": "Teile",
            "teiledienst": "Teiledienst", "werkstattbuero": "Werkstattbüro", "annahme": "Annahme"}
WOCHENTAGE = {"mo", "di", "mi", "do", "fr", "sa", "so", "mon", "tue", "wed", "thu", "fri", "sat", "sun",
              "montag", "dienstag", "mittwoch", "donnerstag", "freitag", "samstag", "sonntag"}
KUERZEL_WOCHENTAG = ("mo", "di", "mi", "do", "fr", "sa", "so")
# Zelle einer Monatszeile im echten Plan: „Fr“, „Sa“, „Mo 1“ (Montag mit Kalenderwoche)
WOCHENTAG_ZELLE = re.compile(r"^(mo|di|mi|do|fr|sa|so)\.?(?:\s*(?:kw\s*)?(\d{1,2}))?$", re.IGNORECASE)
# Beschriftungen, die keine Team- oder Bereichszeile sind (Kalenderwochen, Legende, Summen …)
META = re.compile(r"^(kw|kalenderwoche|woche|legende|summe|gesamt|tag|tage|datum|feiertage?|schulferien|ferien|"
                  r"wochenende|urlaubsplan(er)?|jahresplan(er)?|monat|anzahl|notiz(en)?|bemerkung(en)?)\b",
                  re.IGNORECASE)
# Text in Tageszellen, der kein Name ist (Legende, Erklärungen)
KEIN_NAME = re.compile(r"wochenende|feiertag|ferien|m(ö|oe)glich|belegt|gesperrt|sperre|legende|urlaubsplan",
                       re.IGNORECASE)
KUERZEL = re.compile(r"(x|u|ur|url|urlaub|✓|✔|1|0[.,]5|½|ganz|halb)", re.IGNORECASE)
BETRIEBSRUHE = re.compile(r"betriebs(urlaub|ferien|ruhe)|geschlossen", re.IGNORECASE)
ALLE = re.compile(r"alle|alle mitarbeiter|alle urlaub|ganzer betrieb", re.IGNORECASE)
# Termine statt Personen (stehen manchmal auch in den Bereichszeilen)
TERMIN = re.compile(r"messe\b|schulung|inventur|seminar|betriebsausflug|weihnachtsfeier", re.IGNORECASE)
# Feiertagsnamen in der Notizzeile, so abgekürzt wie im echten Plan („Karfreit.“, „Dt.Einh“, „Heil.Ab.“)
FEIERTAG_NOTIZ = re.compile(r"neujahr|karfreit|oster|tag\s*der\s*ar|1\.\s*mai|maifeiertag|christi|himmelf|pfingst|"
                            r"dt\.?\s*einh|einheit|reformat|reformtag|weihn|heil\.?\s*ab|heiligab|silvester|"
                            r"feiertag", re.IGNORECASE)
LEGENDE_KOPF = re.compile(r"^\s*legende\b", re.IGNORECASE)
TRENNER = re.compile(r"\s*(?:/|,|;|\+|&|\bund\b|\n)\s*", re.IGNORECASE)
MAX_ZEILEN_JE_MONAT = 15             # echter Plan: 6 Zeilen je Monat, im Dezember ein paar mehr
TEXTZEILE_AB = 40                    # so lange Texte sind Erklärungen (Textfeld unten), keine Namen


def _tag(w):
    """Tageszahl einer Kopfzelle: (Tag, Datum oder None) oder None."""
    if w is None or isinstance(w, bool):
        return None
    if isinstance(w, datetime):
        return w.day, w.date()
    if isinstance(w, date):
        return w.day, w
    if isinstance(w, (int, float)):
        return (int(w), None) if float(w).is_integer() and 1 <= w <= 31 else None
    if isinstance(w, str):
        m = re.fullmatch(r"\s*(\d{1,2})\.?\s*", w)
        if m and 1 <= int(m.group(1)) <= 31:
            return int(m.group(1)), None
    return None


def _laeufe(blatt, i: int) -> list:
    """Reihen aufsteigender Tageszahlen in nebeneinanderliegenden Spalten (auch nur Werktage: 2, 5, 6 …)."""
    laeufe, aktuell = [], []
    for j, w in enumerate(blatt.zeilen[i] + [None]):
        t = _tag(w)
        if t and aktuell and j == aktuell[-1][0] + 1 and 1 <= t[0] - aktuell[-1][1] <= 3:
            aktuell.append((j, t[0], t[1]))
            continue
        if len(aktuell) >= 19 and aktuell[0][1] <= 4 and aktuell[-1][1] >= 26:
            laeufe.append(aktuell)
        aktuell = [(j, t[0], t[1])] if t else []
    return laeufe


def hat_tageszeile(blatt) -> bool:
    """Für die Erkennung des Listentyps: gibt es eine Reihe Tageszahlen 1 bis 28–31?"""
    return any(_laeufe(blatt, i) for i in range(len(blatt.zeilen)))


@dataclass
class Monatsblock:
    zeile: int                       # Index der Tageszeile (echter Plan: der Monatszeile) in blatt.zeilen
    spalten: dict                    # Tag → Spaltenindex
    daten: dict                      # Tag → Datum, wenn die Tageszeile echte Datumswerte hat
    start: int
    ende: int
    monat: int = None
    jahr: int = None
    herkunft: str = ""               # Datum / Kopf / Nachbar / Reihenfolge / Monatszeile
    zeilen: list = field(default_factory=list)
    gestapelt: bool = False          # Monate untereinander unter einer gemeinsamen Tageszeile (echter Plan)
    kopfzeile: int = None            # dann: Index dieser gemeinsamen Tageszeile

    @property
    def bereich_text(self) -> str:
        return f"{spaltenbuchstabe(self.start)}:{spaltenbuchstabe(self.ende)}"


def _monat_wert(w):
    if isinstance(w, (datetime, date)):
        return w.month, w.year
    if isinstance(w, str) and len(w) <= 30:
        return monat_aus_text(w)
    return None


def _monat_ueber(blatt, b: Monatsblock):
    """Monat aus den Zeilen über der Tageszeile (bis drei Zeilen) oder links daneben in derselben Zeile."""
    kandidaten = []
    for k in range(b.zeile - 1, -1, -1):
        abstand = blatt.zeilennr[b.zeile] - blatt.zeilennr[k]
        if abstand > 3:
            break
        for j in range(max(0, b.start - 2), b.ende + 1):
            m = _monat_wert(blatt.wert(k, j))
            if m:
                kandidaten.append((abstand, abs(j - b.start), m))
    for j in range(max(0, b.start - 3), b.start):
        m = _monat_wert(blatt.wert(b.zeile, j))
        if m:
            kandidaten.append((0, b.start - j, m))
    return min(kandidaten, key=lambda x: (x[0], x[1]))[2] if kandidaten else None


def _jahr_aus(text):
    m = re.search(r"(?<!\d)(20\d{2})(?!\d)", text or "")
    return int(m.group(1)) if m else None


def _links(blatt, k: int, start: int):
    """Erster Text links vor Spalte `start` in Zeile k – Beschriftung einer Zeile."""
    for j in range(start - 1, -1, -1):
        w = blatt.wert(k, j)
        if isinstance(w, str) and w.strip():
            return re.sub(r"\s+", " ", w.strip())
    return None


def _monatszeile(blatt, k: int, kopf: Monatsblock):
    """
    (Monat, Jahr, {Tag: Datum}) einer Monatszeile des echten Plans: Monatsname links, Wochentage („Fr“, „Mo 5“) in
    den Tagesspalten. Stehen dort echte Datumswerte (als „TTT“ formatiert, Excel zeigt dann auch nur „Fr“), zählt
    deren Monat.
    """
    daten = {}
    for tag, j in kopf.spalten.items():
        w = blatt.wert(k, j)
        if isinstance(w, date) and w.day == tag:
            daten[tag] = w.date() if isinstance(w, datetime) else w
    if len(daten) >= 20 and len({(d.year, d.month) for d in daten.values()}) == 1:
        d = next(iter(daten.values()))
        return d.month, d.year, daten
    label = _links(blatt, k, kopf.start)
    if not label or len(label) > 14:
        return None
    m = monat_aus_text(label)
    if not m:
        return None
    werte = [zu_text(blatt.wert(k, j)) for j in kopf.spalten.values()]
    werte = [w for w in werte if w]
    if len(werte) >= 20 and sum(bool(WOCHENTAG_ZELLE.match(w)) for w in werte) >= len(werte) * 0.6:
        return m[0], m[1], {}
    return None


def _ist_textzeile(blatt, k: int) -> bool:
    return any(isinstance(w, str) and len(w.strip()) >= TEXTZEILE_AB for w in blatt.zeilen[k])


def _gestapelte_monate(blatt, kopfbloecke: list) -> list:
    """
    Echter Jahresplaner: unter einer gemeinsamen Tageszeile 1–31 stehen die Monate untereinander. Jede Monatszeile
    wird ein eigener Block mit den Spalten der Tageszeile. Weniger als zwei Monatszeilen: anderer Aufbau.
    """
    # nur Zeilen mit Tageszahlen sind Köpfe – Monatszeilen mit Datumswerten sehen sonst selbst wie einer aus
    kopfzeilen = sorted({b.zeile for b in kopfbloecke if not b.daten})
    monate = []
    for kopf in kopfbloecke:
        if kopf.daten:
            continue
        bis = next((z for z in kopfzeilen if z > kopf.zeile), len(blatt.zeilen))
        for k in range(kopf.zeile + 1, bis):
            m = _monatszeile(blatt, k, kopf)
            if m:
                monate.append(Monatsblock(zeile=k, spalten=dict(kopf.spalten), daten=m[2], start=kopf.start,
                                          ende=kopf.ende, monat=m[0], jahr=m[1], herkunft="Monatszeile",
                                          gestapelt=True, kopfzeile=kopf.zeile))
    return monate if len(monate) >= 2 else []


def finde_monatsbloecke(blatt, hinweise: list) -> list:
    """Alle Monatsblöcke eines Blatts mit Monat, Jahr und Datenzeilen."""
    bloecke = []
    for i in range(len(blatt.zeilen)):
        for lauf in _laeufe(blatt, i):
            bloecke.append(Monatsblock(zeile=i, spalten={t: j for j, t, _ in lauf},
                                       daten={t: d for _, t, d in lauf if d}, start=lauf[0][0], ende=lauf[-1][0]))
    if not bloecke:
        return []
    gestapelt = _gestapelte_monate(blatt, bloecke)
    if gestapelt:
        bloecke = gestapelt
    for b in bloecke:
        if b.gestapelt:
            continue
        if b.daten:
            d = next(iter(b.daten.values()))
            b.monat, b.jahr, b.herkunft = d.month, d.year, "Datum"
        else:
            m = _monat_ueber(blatt, b)
            if m:
                (b.monat, b.jahr), b.herkunft = m, "Kopf"

    reihe = sorted(bloecke, key=lambda b: (b.zeile, b.start))
    if not any(b.monat for b in reihe):
        if len(reihe) <= 12:
            for n, b in enumerate(reihe, start=1):
                b.monat, b.herkunft = n, "Reihenfolge"
            hinweise.append(f"Blatt „{blatt.name}“: keine Monatsnamen gefunden – Monate nach der Reihenfolge "
                            f"angenommen (erster Block = Januar)")
    else:
        for vorher, b in zip(reihe, reihe[1:]):
            if not b.monat and vorher.monat:
                b.monat, b.herkunft = vorher.monat % 12 + 1, "Nachbar"
        for nachher, b in zip(reihe[::-1], reihe[-2::-1]):
            if not b.monat and nachher.monat:
                b.monat, b.herkunft = (nachher.monat - 2) % 12 + 1, "Nachbar"

    # Jahr: Blattname, sonst Monatskopf, sonst Titelzeilen; läuft der Plan über den Jahreswechsel, zählt es hoch
    jahr = _jahr_aus(blatt.name) or next((b.jahr for b in reihe if b.jahr), None)
    if jahr is None:
        for i in range(min(5, len(blatt.zeilen))):
            jahr = next((_jahr_aus(zu_text(w)) for w in blatt.zeilen[i] if _jahr_aus(zu_text(w))), None)
            if jahr:
                break
    if jahr is None:
        hinweise.append(f"Blatt „{blatt.name}“: kein Jahr im Blattnamen oder in den Kopfzeilen – übersprungen")
        return []
    vorheriger = None
    for b in reihe:
        if b.jahr and b.herkunft in ("Datum", "Kopf", "Monatszeile"):
            jahr = b.jahr
        elif vorheriger and b.monat and b.monat < vorheriger:
            jahr += 1
        b.jahr = jahr
        vorheriger = b.monat
    reihe = [b for b in reihe if b.monat]

    # Datenzeilen: bis zur nächsten Tageszeile, die dieselben Spalten belegt
    tageszeilen = sorted({b.zeile for b in reihe})
    for b in reihe:
        naechste = next((k for k in tageszeilen if k > b.zeile and any(
            o.zeile == k and o.start <= b.ende and o.ende >= b.start for o in reihe)), len(blatt.zeilen))
        b.zeilen = list(range(b.zeile + 1, naechste))
        if b.gestapelt:
            # nach dem letzten Monat kommen Erklärungen (Textfeld) – die sind keine Bereichszeilen
            zeilen = []
            for k in b.zeilen:
                if _ist_textzeile(blatt, k) or blatt.zeilennr[k] - blatt.zeilennr[b.zeile] > MAX_ZEILEN_JE_MONAT:
                    break
                zeilen.append(k)
            b.zeilen = zeilen
    return reihe


@dataclass
class Planerblatt:
    name: str
    jahr: int = None
    bereich: str = None
    bloecke: list = field(default_factory=list)
    urlaub: list = field(default_factory=list)          # (Name, Datum, Bereich)
    sperren: set = field(default_factory=set)           # (Urlaubssperre <Zeile>, Datum, Bereich)
    feiertage: set = field(default_factory=set)
    alle: set = field(default_factory=set)              # (Datum, Bereich) mit „Alle“ = Betriebsurlaub
    zeilenbereiche: set = field(default_factory=set)    # Bereiche, die als Zeilen im Blatt stehen
    personen: dict = field(default_factory=dict)        # Name → Bereich
    beschriftungen: list = field(default_factory=list)
    statistik: Counter = field(default_factory=Counter)
    unbekannte_farben: Counter = field(default_factory=Counter)
    legende: dict = field(default_factory=dict)         # Füllfarbe → {Bedeutungen} aus dem Blatt selbst
    notizen: list = field(default_factory=list)         # (Datum, Text) aus der Notizzeile – Messen, Termine
    feiertag_notizen: list = field(default_factory=list)    # (Datum, Text, gesetzlich?)
    termine: Counter = field(default_factory=Counter)   # Einträge in Bereichszeilen, die Termine sind
    rote_zeilen: list = field(default_factory=list)     # (Excel-Zeile, Beschriftung, Monat)
    texte: list = field(default_factory=list)           # Erklärungen außerhalb der Monatsblöcke


def _bereich_aus_blattname(name: str):
    rest = re.sub(r"(?<!\d)20\d{2}(?!\d)", " ", name)
    rest = re.sub(r"urlaub(splan(er)?)?|jahresplan(er)?", " ", rest, flags=re.IGNORECASE)
    rest = re.sub(r"[\s_\-–]+", " ", rest).strip()
    if not rest:
        return None
    return BEREICHE.get(normalisiere(rest), rest)


def _ist_wochentagszeile(blatt, k: int, b: Monatsblock) -> bool:
    werte = [zu_text(blatt.wert(k, j)) for j in b.spalten.values()]
    werte = [w.lower().rstrip(".") for w in werte if w]
    return bool(werte) and sum(w in WOCHENTAGE for w in werte) >= len(werte) / 2


def _namen(text: str) -> list:
    t = re.sub(r"½|\b1/2\b|\(halb\w*\)|\bhalb(er)?\s+tag\b|\bvorm\.?(?=\s|$)|\bnachm\.?(?=\s|$)", " ", text,
               flags=re.IGNORECASE)
    teile = [x.strip(" .:-") for x in TRENNER.split(t)]
    return [x for x in teile if x and not re.fullmatch(r"[\d\s.,:-]+", x)]


# ---------------------------------------------------------------------------------------- Legende im Blatt ---

def _legende_bedeutung(text):
    """Text einer Legendenzelle → Bedeutung wie in farben.json („belegt“, „nicht möglich“ …) oder None."""
    t = (text or "").lower()
    if re.search(r"nicht\s+m(ö|oe)glich|gesperrt|sperre", t):
        return "nicht möglich"
    if "belegt" in t:
        return "belegt"
    if re.search(r"m(ö|oe)glich", t):
        return "Shop möglich" if "shop" in t else "möglich"
    if "wochenende" in t:
        return "Wochenende"
    if "feiertag" in t:
        return "Feiertag"
    if "ferien" in t:
        return "Schulferien"
    return None


def _legende_zeile(blatt, k: int) -> list:
    """
    Einträge einer Legendenzeile als (Farbe, Bedeutung). Drei Formen: farbige Zelle mit Text darin, farbige Zelle mit
    Text rechts daneben, farbige Zelle ohne Text (zweiter Ton derselben Bedeutung wie der Nachbar).
    """
    zellen = []
    for j in range(blatt.breite):
        w = blatt.wert(k, j)
        text = w.strip() if isinstance(w, str) else ""
        fuell = blatt.farbe(k, j)[0]
        zellen.append((j, fuell if fuell and fuell != "FFFFFF" else None, text, _legende_bedeutung(text)))
    eintraege, offen, verbraucht = {}, [], set()
    for n, (j, fuell, text, bedeutung) in enumerate(zellen):
        if j in verbraucht:
            continue
        if fuell and bedeutung:
            eintraege[j] = (fuell, bedeutung)
        elif fuell and not text:
            rechts = zellen[n + 1] if n + 1 < len(zellen) else None
            if rechts and not rechts[1] and rechts[3]:
                eintraege[j] = (fuell, rechts[3])
                verbraucht.add(rechts[0])
            else:
                offen.append((j, fuell))
    # Farbe ohne eigenen Text: gehört zum linken oder rechten Nachbarn – der, zu dem auch farben.json passt,
    # sonst der linke (die „zweite Stufe“ steht hinter der ersten)
    for j, fuell in offen:
        links = next((eintraege[x][1] for x in range(j - 1, max(-1, j - 3), -1) if x in eintraege), None)
        rechts = next((eintraege[x][1] for x in range(j + 1, j + 3) if x in eintraege), None)
        allgemein = deute_farbe(fuell, "urlaub")
        wahl = next((b for b in (links, rechts) if b and b == allgemein), None) or links or rechts
        if wahl:
            eintraege[j] = (fuell, wahl)
    return list(eintraege.values())


def _legende_aus_blatt(blatt) -> tuple:
    """
    Die Legende im Blatt selbst: ({Farbe: {Bedeutungen}}, Zeilenindizes der Legende). Sie sagt sicherer als jede Liste
    mit Farbwerten, was ein Ton in genau dieser Datei bedeutet. Legende nebeneinander („Legende:“ und dahinter die
    Farben) oder untereinander („Legende“, darunter je Zeile Farbe und Text).
    """
    legende, zeilen = {}, set()
    for i, zeile in enumerate(blatt.zeilen):
        if not any(isinstance(w, str) and LEGENDE_KOPF.match(w) for w in zeile):
            continue
        for k in range(i, min(i + 11, len(blatt.zeilen))):
            eintraege = _legende_zeile(blatt, k)
            if not eintraege and k > i:
                break
            zeilen.add(k)
            for farbe, bedeutung in eintraege:
                legende.setdefault(farbe, set()).add(bedeutung)
    return legende, zeilen


def _deute(fuell, legende: dict, zweifel: list = None, datum=None, mit_text: bool = False):
    """Bedeutung einer Füllfarbe: erst die Legende im Blatt, dann farben.json."""
    if not fuell:
        return None
    treffer = legende.get(fuell)
    if treffer is None and legende:
        naechste = min(legende, key=lambda f: farbabstand(fuell, f))
        if farbabstand(fuell, naechste) <= 10:
            treffer = legende[naechste]
    if not treffer:
        return deute_farbe(fuell, "urlaub", zweifel)
    if len(treffer) == 1:
        return next(iter(treffer))
    # derselbe Ton mit zwei Bedeutungen (gelb: Wochenende und belegt) – Wochentag und Inhalt entscheiden
    if "Wochenende" in treffer and datum and datum.weekday() >= 5:
        return "Wochenende"
    if "belegt" in treffer and mit_text:
        return "belegt"
    rest = treffer - {"Wochenende"} if datum and datum.weekday() < 5 else treffer
    return next(iter(rest)) if len(rest) == 1 else None


def _ist_rot(hexwert) -> bool:
    if not hexwert or ist_neutral(hexwert):
        return False
    return farbabstand(hexwert, "FF0000") <= 25


# ---------------------------------------------------------------------------------------------- Ein Blatt ---

def lies_planerblatt(blatt, bekannte: dict = None) -> tuple:
    """Ein Blatt des Urlaubsplaners: (Planerblatt, Hinweise). `bekannte`: kleingeschriebener Name → Schreibweise."""
    hinweise, zweifel = [], []
    ergebnis = Planerblatt(blatt.name)
    ergebnis.bloecke = finde_monatsbloecke(blatt, hinweise)
    if not ergebnis.bloecke:
        return ergebnis, hinweise
    ergebnis.jahr = ergebnis.bloecke[0].jahr
    ergebnis.bereich = _bereich_aus_blattname(blatt.name)
    ergebnis.legende, legendenzeilen = _legende_aus_blatt(blatt)
    bekannte = dict(bekannte or {})
    spannen = [(b.start, b.ende) for b in ergebnis.bloecke]

    def frei(j):
        return not any(s <= j <= e for s, e in spannen)

    def beschriftung(k):
        """Text links vor dem ersten Block dieser Zeile – Team oder Bereich."""
        erster = min((b.start for b in ergebnis.bloecke if k in b.zeilen), default=blatt.breite)
        for j in range(erster - 1, -1, -1):
            w = blatt.wert(k, j)
            if frei(j) and isinstance(w, str) and w.strip():
                return re.sub(r"\s+", " ", w.strip())
        return None

    def kanonisch(name):
        schluessel = name.lower()
        if schluessel not in bekannte:
            bekannte[schluessel] = name
        return bekannte[schluessel]

    def deute(fuell, datum=None, mit_text=False):
        return _deute(fuell, ergebnis.legende, zweifel, datum, mit_text)

    # Echter Plan: Zeilen vor der ersten Bereichszeile eines Monats sind Notizzeilen (Feiertage, Messen)
    # (ohne jede beschriftete Zeile im Monat gibt es keine Notizzeile – dann sind alle Zeilen Namenszeilen)
    notizzeilen = set()
    for b in ergebnis.bloecke:
        erste = next((k for k in b.zeilen if beschriftung(k)), None) if b.gestapelt else None
        for k in b.zeilen if erste is not None else []:
            if k == erste:
                break
            notizzeilen.add(k)
            _notizzeile(blatt, k, b, ergebnis, deute)
    # Was in der Notizzeile steht (Hausmesse, Messen), ist in einer Bereichszeile ein Termin, kein Mitarbeiter
    termine = {normalisiere(t) for _, text in ergebnis.notizen for t in _namen(text)} - set(map(normalisiere, bekannte))

    zeileninfo = {}
    for b in ergebnis.bloecke:
        # Farben der Tageszeile selbst: oft sind Feiertage und Wochenenden schon dort markiert
        for tag, j in b.spalten.items():
            datum = _datum(b, tag)
            if datum and deute(blatt.farbe(b.zeile, j)[0], datum) == "Feiertag":
                ergebnis.feiertage.add(datum.isoformat())
        if b.gestapelt:
            _wochentage_pruefen(blatt, b, ergebnis)
        zuletzt = None
        for k in b.zeilen:
            if k in notizzeilen:
                continue
            label = beschriftung(k)
            if b.gestapelt:
                # verbundene Zellen in Spalte A („Werkstatt“ über drei Zeilen): leere Beschriftung = die von oben
                label = label or zuletzt
                zuletzt = label
                _rote_beschriftung(blatt, k, b, label, ergebnis)
            if k not in zeileninfo:
                zeileninfo[k] = _zeile_verstehen(label, ergebnis, kanonisch)
            info = zeileninfo[k]
            if info is None or _ist_wochentagszeile(blatt, k, b):
                continue
            label, bereich, team = info
            for tag, j in b.spalten.items():
                datum = _datum(b, tag)
                if datum is None:
                    continue
                _zelle(blatt, k, j, datum, label, bereich, team, ergebnis, kanonisch, deute, termine)

    # Erklärungen außerhalb der Monatsblöcke (Titelzeile mit dem Betriebsurlaub, Regeln unten im Plan) – nur im
    # echten Plan; bei den anderen Aufbauten stehen über den Blöcken die Monatsnamen
    belegt = legendenzeilen | {b.zeile for b in ergebnis.bloecke} | {k for b in ergebnis.bloecke for k in b.zeilen}
    belegt |= {b.kopfzeile for b in ergebnis.bloecke if b.kopfzeile is not None}
    for k in range(len(blatt.zeilen) if any(b.gestapelt for b in ergebnis.bloecke) else 0):
        if k in belegt:
            continue
        for w in blatt.zeilen[k]:
            text = zu_text(w) if isinstance(w, str) else None
            if text and len(text) >= 3 and not re.match(r"(jahres|urlaubs)plan(er)?\b", text, re.IGNORECASE) \
                    and not LEGENDE_KOPF.match(text):
                ergebnis.texte.append(text)

    hinweise += [f"Blatt „{blatt.name}“: {z}" for z in zweifel]
    return ergebnis, hinweise


def _datum(b: Monatsblock, tag: int):
    if tag in b.daten:
        return b.daten[tag]
    try:
        return date(b.jahr, b.monat, tag)
    except (TypeError, ValueError):
        return None                       # 30. Februar und Ähnliches in 31er-Blöcken


def _notizzeile(blatt, k, b, ergebnis, deute):
    """Notizzeile des echten Plans: Feiertagsnamen (nur gesetzliche zählen), sonst Termine wie Hausmesse und Messen."""
    for tag, j in b.spalten.items():
        datum = _datum(b, tag)
        text = zu_text(blatt.wert(k, j))
        if datum is None:
            continue
        if deute(blatt.farbe(k, j)[0], datum, bool(text)) == "Feiertag":
            ergebnis.feiertage.add(datum.isoformat())
        if not text:
            continue
        if FEIERTAG_NOTIZ.search(text):
            gesetzlich = datum in gesetzliche_feiertage(datum.year)
            ergebnis.feiertag_notizen.append((datum.isoformat(), text, gesetzlich))
            if gesetzlich:
                ergebnis.feiertage.add(datum.isoformat())
        else:
            ergebnis.notizen.append((datum.isoformat(), text))


def _wochentage_pruefen(blatt, b, ergebnis):
    """Stimmen „Fr“, „Sa“, „Mo 5“ der Monatszeile mit dem Kalender? So fällt ein falsches Jahr sofort auf."""
    st = ergebnis.statistik
    for tag, j in b.spalten.items():
        m = WOCHENTAG_ZELLE.match(zu_text(blatt.wert(b.zeile, j)) or "")
        datum = _datum(b, tag)
        if not m or datum is None:
            continue
        st["wochentag_passt" if m.group(1).lower() == KUERZEL_WOCHENTAG[datum.weekday()] else "wochentag_falsch"] += 1
        if m.group(2):
            st["kw_passt" if int(m.group(2)) == datum.isocalendar()[1] else "kw_falsch"] += 1


def _rote_beschriftung(blatt, k, b, label, ergebnis):
    """Rote Schrift oder Füllung in der Beschriftungsspalte – Bedeutung unbekannt, nur als Hinweis."""
    for j in range(0, b.start):
        fuell, schrift = blatt.farbe(k, j)
        if _ist_rot(fuell) or _ist_rot(schrift):
            ergebnis.rote_zeilen.append((blatt.zeilennr[k], label or "", b.monat))
            return


def _zeile_verstehen(label, ergebnis, kanonisch):
    """(Beschriftung, Bereich, Teammitglieder) einer Datenzeile – None für Monats-, Legenden- und Summenzeilen."""
    if label and (META.match(label) or monat_aus_text(label) and len(label) <= 20):
        return None
    if label and len(label) >= TEXTZEILE_AB:
        return None                                         # eine Erklärung, keine Zeilenbeschriftung
    bereich = ergebnis.bereich
    team = []
    if label:
        n = normalisiere(label)
        if n in BEREICHE:
            bereich = BEREICHE[n]
        elif not re.search(r"\d", label):
            # „Kai/Uwe/Jan“ ist ein Team, „Sina“ eine einzelne Person
            team = [kanonisch(t) for t in _namen(label) if not KEIN_NAME.search(t)]
        if label not in ergebnis.beschriftungen:
            ergebnis.beschriftungen.append(label)
    for person in team:
        ergebnis.personen.setdefault(person, bereich)
    if bereich:
        ergebnis.zeilenbereiche.add(bereich)
    return label, bereich, team


def _zelle(blatt, k, j, datum, label, bereich, team, ergebnis, kanonisch, deute, termine=frozenset()):
    wert = blatt.wert(k, j)
    fuell = blatt.farbe(k, j)[0]
    deutung = deute(fuell, datum, isinstance(wert, str) and bool(wert.strip()))
    iso = datum.isoformat()
    st = ergebnis.statistik
    if deutung == "Feiertag":
        ergebnis.feiertage.add(iso)
    elif deutung == "nicht möglich":
        ergebnis.sperren.add((f"Urlaubssperre {label or bereich or blatt.name}", iso, bereich))
    elif deutung == "Wochenende":
        st["wochenende"] += 1
        if datum.weekday() < 5:
            st["wochenende_werktag"] += 1
    elif deutung is None and fuell and not ist_neutral(fuell):
        ergebnis.unbekannte_farben[fuell] += 1

    namen = []
    if isinstance(wert, (int, float)) and not isinstance(wert, bool):
        namen = ["x"]                                       # 1 oder 0,5 als Kürzel für „hat Urlaub“
    elif isinstance(wert, str) and wert.strip():
        namen = _namen(wert)
    personen = []
    for t in namen:
        if ALLE.fullmatch(t):
            ergebnis.alle.add((iso, bereich))               # Betriebsurlaub: alle aus diesem Blatt
        elif BETRIEBSRUHE.search(t):
            ergebnis.feiertage.add(iso)
            st["betriebsruhe"] += 1
        elif KEIN_NAME.search(t):
            continue
        elif TERMIN.search(t) or normalisiere(t) in termine:
            ergebnis.termine[t] += 1
        elif KUERZEL.fullmatch(t):
            if len(team) == 1:
                personen.append(team[0])                    # Zeile einer einzelnen Person: „x“ heißt sie
            else:
                st["kuerzel_ohne_namen"] += 1
        else:
            personen.append(kanonisch(t))
    for p in personen:
        ergebnis.personen.setdefault(p, bereich)
        ergebnis.urlaub.append((p, iso, bereich))
    if deutung == "belegt" and not personen and not namen:
        st["belegt_ohne_namen"] += 1


def _tage_text(tage: list) -> str:
    """Sortierte ISO-Daten → „24.12.–31.12.2027“ (Spanne von erstem bis letztem Tag)."""
    erster, letzter = tage[0], tage[-1]
    if erster == letzter:
        return f"{erster[8:10]}.{erster[5:7]}.{erster[:4]}"
    return f"{erster[8:10]}.{erster[5:7]}.–{letzter[8:10]}.{letzter[5:7]}.{letzter[:4]}"


def _blatt_hinweise(e: Planerblatt) -> list:
    if not e.bloecke:
        return []
    monate = sorted({b.monat for b in e.bloecke})
    tageszeilen = sorted({b.zeile for b in e.bloecke})
    gestapelt = any(b.gestapelt for b in e.bloecke)
    anordnung = ("untereinander unter einer gemeinsamen Tageszeile" if gestapelt else
                 "nebeneinander" if len(tageszeilen) == 1 and len(e.bloecke) > 1 else
                 "untereinander" if len(e.bloecke) > 1 else "ein Block")
    herkunft = Counter(b.herkunft for b in e.bloecke)
    woher = {"Kopf": "Monatsnamen", "Datum": "Datumswerte", "Nachbar": "Nachbarblock", "Reihenfolge": "Reihenfolge",
             "Monatszeile": "Monatsnamen in Spalte A"}
    if monate == list(range(monate[0], monate[-1] + 1)):
        spanne = (f"{MONATSNAMEN[monate[0] - 1]}–{MONATSNAMEN[monate[-1] - 1]}" if len(monate) > 1
                  else MONATSNAMEN[monate[0] - 1])
    else:
        spanne = ", ".join(MONATSNAMEN[m - 1] for m in monate)
    texte = [f"Blatt „{e.name}“: Jahr {e.jahr}" + (f", Bereich {e.bereich}" if e.bereich else "")
             + f" – {len(e.bloecke)} Monatsblöcke {anordnung} ({spanne}; Monat aus "
             + ", ".join(woher[h] for h in herkunft) + f"), Zeilen: {', '.join(e.beschriftungen) or 'ohne Namen'}"]
    tage_je_person = Counter(p for p, _, _ in e.urlaub)
    texte.append(f"Blatt „{e.name}“: {len(e.urlaub)} Urlaubstage"
                 + (" (" + ", ".join(f"{p} {n}" for p, n in tage_je_person.most_common()) + ")" if e.urlaub else "")
                 + f", {len(e.feiertage)} Feiertage, {len(e.sperren)} Sperrtage (Urlaub nicht möglich)")
    st = e.statistik
    if st["wochenende"]:
        if st["wochenende_werktag"] > st["wochenende"] * 0.2:
            texte.append(f"Blatt „{e.name}“: Achtung – {st['wochenende_werktag']} von {st['wochenende']} "
                         f"Wochenend-Zellen fallen auf Werktage. Stimmen Jahr und Monate?")
        else:
            texte.append(f"Blatt „{e.name}“: Wochenendfarbe passt zum Kalender ({st['wochenende']} Zellen)")
    geprueft = st["wochentag_passt"] + st["wochentag_falsch"]
    if geprueft:
        if st["wochentag_falsch"] > geprueft * 0.1:
            texte.append(f"Blatt „{e.name}“: Achtung – {st['wochentag_falsch']} von {geprueft} Wochentagen in den "
                         f"Monatszeilen passen nicht zum Jahr {e.jahr}. Stimmt das Jahr im Blattnamen?")
        else:
            texte.append(f"Blatt „{e.name}“: Wochentage der Monatszeilen passen zum Kalender {e.jahr} "
                         f"({geprueft} Tage" + (f", {st['kw_passt']} Kalenderwochen" if st["kw_passt"] else "") + ")")
        if st["kw_falsch"]:
            texte.append(f"Blatt „{e.name}“: {st['kw_falsch']} Kalenderwochen („Mo 5“) passen nicht zum Kalender")
    if e.legende:
        teile = [f"#{f} {'/'.join(sorted(b))}" for f, b in e.legende.items()]
        texte.append(f"Blatt „{e.name}“: Legende im Blatt gelesen – " + ", ".join(teile))
    if e.alle:
        tage = sorted({d for d, _ in e.alle})
        texte.append(f"Blatt „{e.name}“: „Alle“ an {len(tage)} Tagen ({_tage_text(tage)}) – als Betriebsurlaub für "
                     "alle aus diesem Blatt übernommen")
    if e.feiertag_notizen:
        nicht = [f"„{t}“ ({d[8:10]}.{d[5:7]}.)" for d, t, gesetzlich in e.feiertag_notizen if not gesetzlich]
        if nicht:
            texte.append(f"Blatt „{e.name}“: {', '.join(nicht)} – kein gesetzlicher Feiertag, nicht als Feiertag "
                         "übernommen")
    if e.notizen:
        je_text = {}
        for d, t in e.notizen:
            je_text.setdefault(t, []).append(d)
        texte.append(f"Blatt „{e.name}“: Notizen im Plan – " + ", ".join(
            f"{t} ({_tage_text(sorted(ds))})" for t, ds in je_text.items()) + " (nicht übernommen)")
    if e.termine:
        texte.append(f"Blatt „{e.name}“: " + ", ".join(f"„{t}“ ({n}×)" for t, n in e.termine.most_common())
                     + " in Bereichszeilen als Termin gelesen, nicht als Mitarbeiter")
    if e.rote_zeilen:
        teile = [f"{nr} ({label or 'ohne Beschriftung'}, {MONATSNAMEN[monat - 1]})"
                 for nr, label, monat in e.rote_zeilen]
        texte.append(f"Blatt „{e.name}“: Beschriftung rot markiert in Zeile {', '.join(teile)} – Bedeutung unklar, "
                     "nichts daraus übernommen. Bitte sagen, was Rot dort heißt.")
    if st["belegt_ohne_namen"]:
        texte.append(f"Blatt „{e.name}“: {st['belegt_ohne_namen']} Tage als belegt gefärbt, aber ohne Namen – "
                     "nicht übernommen")
    if st["kuerzel_ohne_namen"]:
        texte.append(f"Blatt „{e.name}“: {st['kuerzel_ohne_namen']} Einträge wie „x“ in Zeilen mit mehreren "
                     "Personen – nicht zuzuordnen")
    if st["betriebsruhe"]:
        texte.append(f"Blatt „{e.name}“: Betriebsruhe als Feiertag übernommen")
    for farbe, n in e.unbekannte_farben.most_common(5):
        texte.append(f"Blatt „{e.name}“: Farbe #{farbe} ({n} Zellen) steht weder in der Legende des Blatts noch in "
                     "der Legende „urlaub“ (vorlagen/farben.json)")
    return texte


# ------------------------------------------------------------------------------- Textfelder (Zeichnungen) ---

_REL_ID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"


def _lokal(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def textfelder(pfad) -> dict:
    """
    Text aus Textfeldern und Formen je Blatt: {Blattname: [Text, …]}. openpyxl liest die Zeichnungsebene nicht –
    im echten Jahresplaner stehen dort aber die Urlaubsregeln („Aus folgenden Gruppen …“). Nicht lesbar: {}.
    """
    try:
        with zipfile.ZipFile(pfad) as archiv:
            namen = set(archiv.namelist())

            def xml(name):
                return ElementTree.fromstring(archiv.read(name))

            def verweise(name) -> dict:
                ordner = posixpath.dirname(name)
                rels = posixpath.join(ordner, "_rels", posixpath.basename(name) + ".rels")
                if rels not in namen:
                    return {}
                aus = {}
                for r in xml(rels):
                    ziel = r.get("Target") or ""
                    # absolut („/xl/drawings/…“) oder relativ zum Ordner der Datei („../drawings/…“)
                    ziel = ziel.lstrip("/") if ziel.startswith("/") else posixpath.normpath(
                        posixpath.join(ordner, ziel))
                    aus[r.get("Id")] = (r.get("Type") or "", ziel)
                return aus

            mappe = verweise("xl/workbook.xml")
            ergebnis = {}
            for blatt in xml("xl/workbook.xml").iter():
                if _lokal(blatt.tag) != "sheet":
                    continue
                ziel = mappe.get(blatt.get(_REL_ID), ("", ""))[1]
                texte = []
                for art, zeichnung in (verweise(ziel).values() if ziel in namen else []):
                    if not art.endswith("/drawing") or zeichnung not in namen:
                        continue
                    for form in xml(zeichnung).iter():
                        if _lokal(form.tag) != "sp":
                            continue
                        absaetze = ["".join(t.text or "" for t in p.iter() if _lokal(t.tag) == "t")
                                    for p in form.iter() if _lokal(p.tag) == "p"]
                        text = "\n".join(a.strip() for a in absaetze if a.strip())
                        if text:
                            texte.append(text)
                if texte:
                    ergebnis[blatt.get("name")] = texte
            return ergebnis
    except (OSError, KeyError, ValueError, zipfile.BadZipFile, ElementTree.ParseError):
        return {}


# ----------------------------------------------------------------------------------------------- Import ---

def importiere_urlaub(db, pfad, quelle: str, bericht: dict, hinweis=None):
    """Liest den Urlaubsplaner nach `abwesenheiten` und `mitarbeiter` und füllt den Bericht."""
    hinweis = hinweis or bericht["hinweise"].append
    bekannte = {r[0].lower(): r[0] for r in db.execute("SELECT name FROM mitarbeiter")}
    felder = textfelder(pfad)
    ergebnisse = []
    for blatt in lies_arbeitsmappe(pfad, mit_farben=True):
        e, texte = lies_planerblatt(blatt, bekannte)
        for t in texte:
            hinweis(t)
        if not e.bloecke:
            if len(blatt.zeilen) >= 2:
                hinweis(f"Blatt „{blatt.name}“: keine Tageszahlen (1, 2, 3 …) gefunden – übersprungen")
            continue
        for t in _blatt_hinweise(e):
            hinweis(t)
        erklaerungen = e.texte + felder.get(blatt.name, [])
        if erklaerungen:
            hinweis(f"Blatt „{blatt.name}“: Text im Plan – " + " | ".join(" ".join(t.split()) for t in erklaerungen)
                    + " – Gruppen und Sperrzeiten bitte in die Urlaubsregeln von ODIN übernehmen")
            for t in _betriebsurlaub(e, erklaerungen)[1]:
                hinweis(t)
        for name in e.personen:
            bekannte.setdefault(name.lower(), name)
        ergebnisse.append(e)
        bericht["blaetter"].append(blatt.name)
        if not bericht["spalten_erkannt"]:
            bericht["spalten_erkannt"] = {f"{MONATSNAMEN[b.monat - 1]} {b.jahr}": b.bereich_text
                                          for b in e.bloecke}
    if not ergebnisse:
        bericht["spalten_fehlen"] = ["Tageszahlen 1–31 je Monat"]
        bericht["fehler"] = "Kein Monatsblock gefunden – erwartet werden Tageszahlen 1, 2, 3 … nebeneinander."
        return

    minuten = parameter().get("minuten_pro_tag", 480)
    geschrieben = 0
    db.execute("DELETE FROM abwesenheiten WHERE source_file = ?", (quelle,))
    personen = {}
    for e in ergebnisse:
        for name, bereich in e.personen.items():
            personen.setdefault(name, bereich)
    for name, bereich in personen.items():
        # Vorhandene Angaben (Bereich, Minuten, Auslieferung) bleiben; neu Angelegte fahren keine Auslieferungen
        c = db.execute("INSERT INTO mitarbeiter (name, bereich, minuten_pro_tag, auslieferung, aktiv) "
                       "VALUES (?,?,?,0,1) ON CONFLICT(name) DO UPDATE SET "
                       "bereich = COALESCE(mitarbeiter.bereich, excluded.bereich), "
                       "minuten_pro_tag = COALESCE(mitarbeiter.minuten_pro_tag, excluded.minuten_pro_tag)",
                       (name, bereich, minuten))
        geschrieben += c.rowcount
    einfuegen = ("INSERT OR IGNORE INTO abwesenheiten (mitarbeiter, datum, art, bereich, source_file) "
                 "VALUES (?,?,?,?,?)")
    team = db.execute("SELECT name, bereich FROM mitarbeiter WHERE aktiv = 1").fetchall()
    urlaub = [(n, d, "Urlaub", b, quelle) for e in ergebnisse for n, d, b in e.urlaub]
    sperren = [(n, d, "gesperrt", b, quelle) for e in ergebnisse for n, d, b in sorted(e.sperren)]
    # „Alle“: jeder aus dem Blatt und jeder Mitarbeiter der Bereiche, die als Zeilen im Blatt stehen – auch wer in
    # diesem Jahr noch nichts eingetragen hat
    betriebsurlaub = set()
    for e in ergebnisse:
        if not e.alle:
            continue
        bereiche = ({b for _, b in e.alle} | e.zeilenbereiche | set(e.personen.values()) | {e.bereich}) - {None}
        wer = dict(e.personen)
        wer.update({m[0]: m[1] for m in team if m[1] in bereiche and m[0] not in wer})
        betriebsurlaub |= {(n, d, "Betriebsurlaub", b, quelle) for d, _ in e.alle for n, b in wer.items()}
    betriebsurlaub = sorted(betriebsurlaub)
    for zeilen in (urlaub, sperren, betriebsurlaub):
        vorher = db.total_changes
        db.executemany(einfuegen, zeilen)
        geschrieben += db.total_changes - vorher
    feiertage = sorted({d for e in ergebnisse for d in e.feiertage})
    vorher = db.total_changes
    db.executemany(einfuegen, [(m[0], d, "Feiertag", m[1], quelle) for d in feiertage for m in team])
    geschrieben += db.total_changes - vorher

    bericht["zeilen_gelesen"] = len(urlaub) + len(sperren) + len(betriebsurlaub) + len(feiertage)
    bericht["zeilen_geschrieben"] = geschrieben
    alle_tage = len({d for e in ergebnisse for d, _ in e.alle})
    hinweis(f"Urlaubsplaner: {len(urlaub)} Urlaubstage von {len({u[0] for u in urlaub})} Personen, "
            f"{len(feiertage)} Feiertage, {len(sperren)} Sperrtage"
            + (f", {alle_tage} Tage Betriebsurlaub" if alle_tage else "")
            + f"; {len(personen)} Mitarbeiter aus dem Plan")


def blockbeschreibung(blatt) -> list:
    """Für den Strukturbericht: wo die Monatsblöcke liegen – ohne Namen und ohne Zellinhalte."""
    hinweise = []
    bloecke = finde_monatsbloecke(blatt, hinweise)
    legende, _ = _legende_aus_blatt(blatt)
    aus = []
    for b in bloecke:
        farben = Counter()
        for k in [b.zeile] + b.zeilen:
            for j in b.spalten.values():
                f = blatt.farbe(k, j)[0]
                if f:
                    farben[f] += 1
        aus.append({"monat": b.monat, "jahr": b.jahr, "monat_aus": b.herkunft, "spalten": b.bereich_text,
                    "tageszeile": blatt.zeilennr[b.zeile], "tage": len(b.spalten), "datenzeilen": len(b.zeilen),
                    "fuellfarben": {f: {"anzahl": n, "deutung": _deute(f, legende)}
                                    for f, n in farben.most_common()}})
    return aus


# ------------------------------------------------------------------------- Regelvorschlag für die Anträge ---

DATUM_TEXT = r"(\d{1,2})\.(\d{1,2})\.(\d{2,4})?"
SPANNE = re.compile(DATUM_TEXT + r"\s*(?:bis|-|–)\s*" + DATUM_TEXT, re.IGNORECASE)
ANZAHL = {"eine": 1, "ein": 1, "einer": 1, "zwei": 2, "drei": 3, "vier": 4}


def _datum_aus(tag, monat, jahr_text, jahr: int):
    j = int(jahr_text) if jahr_text else jahr
    j = j + 2000 if j < 100 else j
    try:
        return date(j, int(monat), int(tag))
    except ValueError:
        return None


def _gruppen_aus_text(text: str) -> list:
    """„Aus folgenden Gruppen kann immer nur eine Person gleichzeitig Urlaub machen: 1. A-B-C 2. D-E“ → Gruppen."""
    m = re.search(r"gruppen\b[^:]*:\s*(.*)", text, re.IGNORECASE | re.DOTALL)
    if not m:
        return []
    zahl = re.search(r"nur\s+(\d|eine?r?|zwei|drei|vier)\s+person", text[:m.start(1)], re.IGNORECASE)
    hoechstens = 1
    if zahl:
        hoechstens = int(zahl.group(1)) if zahl.group(1).isdigit() else ANZAHL.get(zahl.group(1).lower(), 1)
    # Ende der Aufzählung: der nächste Satz ohne Nummer („Während Hausmesse …“)
    rest = re.split(r"\b(?:während|waehrend|in der zeit|bitte|hinweis|achtung)\b", m.group(1), maxsplit=1,
                    flags=re.IGNORECASE)[0]
    teile = re.split(r"(?:^|\s)(\d{1,2})[.)]\s+", rest)
    gruppen = []
    for nr, inhalt in zip(teile[1::2], teile[2::2]):
        namen = [n.strip(" .,;:") for n in re.split(r"\s*[-–/,;]\s*|\s+und\s+|\n", inhalt.strip())]
        namen = [n for n in namen if n and len(n) <= 30 and len(n.split()) <= 3]
        if len(namen) >= 2:
            gruppen.append({"name": f"Gruppe {nr}", "namen": namen, "max_gleichzeitig": hoechstens})
    return gruppen


def _sperrzeiten_aus_text(text: str, jahr: int, hinweise: list) -> list:
    """„Während Hausmesse 19.04. bis 28.04. kein Urlaub“ → Sperrzeit; Datum ohne Jahr = Jahr des Blatts."""
    aus = []
    for zeile in re.split(r"\n|(?<=[a-zäöüß])\.\s+", text):
        if not re.search(r"kein(en)?\s+urlaub|urlaubssperre", zeile, re.IGNORECASE):
            continue
        m = SPANNE.search(zeile)
        if not m:
            continue
        von = _datum_aus(*m.group(1, 2, 3), jahr)
        bis = _datum_aus(*m.group(4, 5, 6), jahr)
        if not von or not bis:
            continue
        if bis < von:
            hinweise.append(f"Sperrzeit „{zeile.strip()}“: Ende vor Beginn – bitte prüfen")
            continue
        vor = re.split(r"\bwährend\b|\bwaehrend\b|\bin der zeit( der| des)?\b|[:\n]", zeile[:m.start()],
                       flags=re.IGNORECASE)[-1]
        grund = re.sub(r"^(der|die|das|vom|von|zur|zum)\s+", "", vor.strip(" -–,"), flags=re.IGNORECASE)
        aus.append({"von": von.isoformat(), "bis": bis.isoformat(),
                    "grund": grund if 0 < len(grund) <= 40 else "Sperrzeit", "bereiche": []})
    return aus


def _zusammenhaengend(tage: list) -> list:
    """Sortierte ISO-Tage → [(von, bis)]; Lücken nur aus Wochenenden und Feiertagen verbinden."""
    spannen = []
    for t in tage:
        d = date.fromisoformat(t)
        if spannen:
            letzter = date.fromisoformat(spannen[-1][1])
            dazwischen = [letzter + timedelta(days=n) for n in range(1, (d - letzter).days)]
            if all(x.weekday() >= 5 or x in gesetzliche_feiertage(x.year) for x in dazwischen):
                spannen[-1][1] = t
                continue
        spannen.append([t, t])
    return [tuple(s) for s in spannen]


BETRIEBSURLAUB_TEXT = re.compile(r"urlaub\s+f(?:ü|ue)r\s+" + DATUM_TEXT + r"\s*(?:bis|-|–)\s*" + DATUM_TEXT,
                                 re.IGNORECASE)


def _betriebsurlaub(e: Planerblatt, texte: list) -> tuple:
    """
    Betriebsurlaub eines Blatts als ([(von, bis)], Hinweise): aus den Zellen „Alle“. Der Text „Urlaub für 24.12.27 bis
    31.12.26 (5 Tage)“ wird nur verglichen – im echten Plan stimmt das Jahr darin nicht. Ohne „Alle“ dient er als
    Ersatz, ein Ende vor dem Beginn wird dann aufs Jahr des Beginns gesetzt (mit Hinweis).
    """
    hinweise = []
    aus_plan = _zusammenhaengend(sorted({d for d, _ in e.alle}))
    aus_text = []
    for t in texte:
        m = BETRIEBSURLAUB_TEXT.search(t)
        if not m:
            continue
        von, bis = _datum_aus(*m.group(1, 2, 3), e.jahr), _datum_aus(*m.group(4, 5, 6), e.jahr)
        laut_text = f"{von:%d.%m.%Y} bis {bis:%d.%m.%Y}" if von and bis else m.group(0)
        if aus_plan:
            if not von or not bis or (von.isoformat(), bis.isoformat()) not in aus_plan:
                hinweise.append(f"Blatt „{e.name}“: Text sagt Betriebsurlaub {laut_text}, im Plan steht „Alle“ "
                                f"{', '.join(_tage_text([a, b]) for a, b in aus_plan)} – der Plan gilt")
        elif von and bis:
            if bis < von and von.month <= bis.month:
                bis = bis.replace(year=von.year)
                hinweise.append(f"Blatt „{e.name}“: Betriebsurlaub aus dem Text {laut_text} – Jahr des Endes auf "
                                f"{von.year} korrigiert, bitte prüfen")
            if von <= bis:
                aus_text.append((von.isoformat(), bis.isoformat()))
    return aus_plan or aus_text, hinweise


def regel_vorschlag_aus_planer(pfad) -> dict:
    """
    VORSCHLAG für die Urlaubsregeln in ODIN aus dem Jahresplaner – nichts davon gilt automatisch:
    - Gruppen aus dem Text „Aus folgenden Gruppen kann immer nur eine Person gleichzeitig Urlaub machen: 1. … 2. …“
      (Namen so, wie sie im Plan stehen; Personen muss jemand zuordnen),
    - Sperrzeiten aus „Während Hausmesse 19.04. bis 28.04. kein Urlaub“ (Jahr des Blatts),
    - Betriebsurlaub aus den Zellen „Alle“ (nicht aus dem Text „Urlaub für 24.12.27 bis 31.12.26“ – der hat im
      echten Plan einen Tippfehler im Jahr; nur ohne „Alle“-Zellen dient er als Ersatz, mit Hinweis),
    - Bereich je Name aus den Zeilen (Werkstatt, Waschplatz, Shop).
    """
    hinweise = []
    felder = textfelder(pfad)
    gruppen, sperrzeiten, betriebsurlaub, texte, bereiche = [], [], [], [], {}
    for blatt in lies_arbeitsmappe(pfad, mit_farben=True):
        e, _ = lies_planerblatt(blatt)
        if not e.bloecke:
            continue
        blatttexte = e.texte + felder.get(blatt.name, [])
        texte += [{"blatt": blatt.name, "text": t} for t in blatttexte]
        gesamt = "\n".join(blatttexte)
        for g in _gruppen_aus_text(gesamt):
            if not any(x["namen"] == g["namen"] for x in gruppen):
                gruppen.append(g)
        for s in _sperrzeiten_aus_text(gesamt, e.jahr, hinweise):
            if not any((x["von"], x["bis"]) == (s["von"], s["bis"]) for x in sperrzeiten):
                sperrzeiten.append({**s, "blatt": blatt.name})
        spannen, texte_bu = _betriebsurlaub(e, blatttexte)
        hinweise += texte_bu
        for von, bis in spannen:
            if not any((x["von"], x["bis"]) == (von, bis) for x in betriebsurlaub):
                betriebsurlaub.append({"von": von, "bis": bis, "grund": "Betriebsurlaub", "blatt": blatt.name})
        for name, bereich in e.personen.items():
            if bereich:
                bereiche.setdefault(name, bereich)
    return {"vorschlag": True,
            "hinweis": "Nur ein Vorschlag aus dem Urlaubsplaner – bitte prüfen und Personen zuordnen, bevor er als "
                       "Urlaubsregel gespeichert wird.",
            "gruppen": gruppen, "sperrzeiten": sperrzeiten, "betriebsurlaub": betriebsurlaub, "bereiche": bereiche,
            "texte": texte, "hinweise": hinweise}
