"""
Fahrzeugtypen für Teile und Einbaupreise – die eine Stelle für die feste Einteilung.

Die Teileliste ist in Abschnitte je Fahrzeugtyp gegliedert („Kastenwagen H2 Dach (Standard)“, „Reisemobile“ …).
Verkauft und beraten wird nach sechs festen Typen. Welcher Abschnitt der Liste zu welchem Typ gehört, legt der
Inhaber in ODIN fest (Teile & Montage → Fahrzeugtypen zuordnen); gespeichert wird das im gemeinsamen Speicher
(_ODIN-Cockpit.json, Objekt „einstellungen“ → „fahrzeugtyp_zuordnung“), damit alle Rechner dieselbe Einteilung sehen.

Heißt ein Abschnitt schon genau wie ein fester Typ, gilt er ohne Zuordnung. Alles andere bleibt unter seinem
bisherigen Namen sichtbar und ist „noch nicht zugeordnet“.
"""

import re

FAHRZEUGTYPEN = (
    "Kastenwagen H2",
    "Kastenwagen H3",
    "Kastenwagen mit Hochdach (Vario)",
    "Kastenwagen mit Aufstelldach",
    "Wohnmobile",
    "Wohnwagen",
)
ALLE = "Alle Fahrzeuge"                 # Abschnitte, die für jedes Fahrzeug gelten (z. B. Service)
ZIELE = (*FAHRZEUGTYPEN, ALLE)
SCHLUESSEL = "fahrzeugtyp_zuordnung"    # im Objekt „einstellungen“ des gemeinsamen Speichers

# Art im Bestand (vehicles.category) je Typ – für Fragen wie „6 Meter Kastenwagen“ oder „mein Wohnmobil“
ART = {
    "Kastenwagen H2": "Kastenwagen", "Kastenwagen H3": "Kastenwagen",
    "Kastenwagen mit Hochdach (Vario)": "Kastenwagen", "Kastenwagen mit Aufstelldach": "Kastenwagen",
    "Wohnmobile": "Reisemobil", "Wohnwagen": "Wohnwagen",
}
_ALLE_MUSTER = re.compile(r"^(alle|alle fahrzeuge|alle typen|universal|-)$", re.IGNORECASE)
# Woran man einen Typ im Text erkennt (Frage an den Assistenten, Modellname eines Fahrzeugs)
_MERKMALE = (
    ("Kastenwagen H2", re.compile(r"\bh2\b")),
    ("Kastenwagen H3", re.compile(r"\bh3\b")),
    ("Kastenwagen mit Hochdach (Vario)", re.compile(r"hochdach|\bvario\b")),
    ("Kastenwagen mit Aufstelldach", re.compile(r"aufstelldach|schlafdach|hubdach|pop-?top")),
    ("Wohnmobile", re.compile(r"wohnmobil|reisemobil|teilintegriert|vollintegriert|\bintegriert|alkoven")),
    ("Wohnwagen", re.compile(r"wohnwagen|caravan")),
)
MAX_EINTRAEGE = 300
MAX_LAENGE = 80


def _norm(text) -> str:
    return " ".join(str(text or "").split())


def zuordnung_lesen(einstellungen) -> dict:
    """Gespeicherte Zuordnung {bisherige Bezeichnung: neuer Typ}, bereinigt: nur bekannte Ziele, nur Text."""
    roh = (einstellungen or {}).get(SCHLUESSEL) if isinstance(einstellungen, dict) else None
    if not isinstance(roh, dict):
        return {}
    aus = {}
    for alt, neu in list(roh.items())[:MAX_EINTRAEGE]:
        alt = _norm(alt)[:MAX_LAENGE]
        if alt and neu in ZIELE:
            aus[alt] = neu
    return aus


def gleichnamig(alt):
    """Der feste Typ, wenn die Bezeichnung schon so heißt (oder „alle Fahrzeuge“ meint), sonst None."""
    name = _norm(alt)
    if not name:
        return None
    if _ALLE_MUSTER.match(name):
        return ALLE
    return next((z for z in ZIELE if z.casefold() == name.casefold()), None)


def neuer_typ(alt, zuordnung: dict):
    """Neuer Typ zu einer Bezeichnung der Teileliste – oder None (noch nicht zugeordnet)."""
    name = _norm(alt)
    return (zuordnung or {}).get(name) or gleichnamig(name)


def erkennen(text):
    """Fester Typ aus einem Text („Markise für meinen Kastenwagen H3“, „Hersteller3 Vario“); None, wenn keiner oder
    mehrere passen."""
    t = str(text or "").lower()
    treffer = [typ for typ, muster in _MERKMALE if muster.search(t)]
    return treffer[0] if len(treffer) == 1 else None


def anwenden(db, zuordnung: dict):
    """Neuen Typ in parts.typ_neu schreiben (leer = noch nicht zugeordnet)."""
    alte = [r[0] for r in db.execute("SELECT DISTINCT fahrzeugtyp FROM parts WHERE fahrzeugtyp IS NOT NULL")]
    db.execute("UPDATE parts SET typ_neu = NULL")
    for alt in alte:
        neu = neuer_typ(alt, zuordnung)
        if neu:
            db.execute("UPDATE parts SET typ_neu = ? WHERE fahrzeugtyp = ?", (neu, alt))


def uebersicht(db, zuordnung: dict) -> dict:
    """Für die Karte „Fahrzeugtypen zuordnen“: die festen Typen und jede Bezeichnung der Teileliste mit Anzahl,
    neuem Typ und woher er kommt („zuordnung“, „gleichnamig“ oder None = noch nicht zugeordnet)."""
    zeilen = db.execute("""
        SELECT TRIM(fahrzeugtyp) AS name, COUNT(*) AS n FROM parts
        WHERE fahrzeugtyp IS NOT NULL AND TRIM(fahrzeugtyp) <> '' AND gehoert_zu IS NULL
        GROUP BY TRIM(fahrzeugtyp) ORDER BY MIN(id)""").fetchall()
    bezeichnungen = []
    for name, n in zeilen:
        name = _norm(name)
        if name in (zuordnung or {}):
            bezeichnungen.append({"name": name, "n": n, "typ": zuordnung[name], "herkunft": "zuordnung"})
        else:
            g = gleichnamig(name)
            bezeichnungen.append({"name": name, "n": n, "typ": g, "herkunft": "gleichnamig" if g else None})
    return {"liste": list(FAHRZEUGTYPEN), "alle": ALLE, "bezeichnungen": bezeichnungen}


def zuordnung_setzen(einstellungen: dict, alt, neu) -> dict:
    """Neue Zuordnung im Objekt „einstellungen“ (leerer Typ: Zuordnung entfernen). Wirft ValueError mit einer
    Meldung für Menschen."""
    name = _norm(alt)
    if not name or len(name) > MAX_LAENGE:
        raise ValueError("Unbekannte Bezeichnung.")
    neu = _norm(neu)
    if neu and neu not in ZIELE:
        raise ValueError("Diesen Fahrzeugtyp gibt es nicht.")
    zuordnung = zuordnung_lesen(einstellungen)
    if neu:
        if name not in zuordnung and len(zuordnung) >= MAX_EINTRAEGE:
            raise ValueError("Zu viele Zuordnungen.")
        zuordnung[name] = neu
    else:
        zuordnung.pop(name, None)
    return {**(einstellungen or {}), SCHLUESSEL: zuordnung}
