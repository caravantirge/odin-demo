"""
Aufbau einer Excel-Liste ohne Werte – zum Weitergeben statt der Datei mit Firmendaten.

Übernommen aus dem muster Cockpit (scripts/inspect-excel.ts), aber ohne Beispielwerte: je Blatt die erkannte
Kopfzeile, die Spaltennamen und welche Füll- und Schriftfarben in jeder Spalte vorkommen – mit Anzahl, Herkunft
(RGB, Design-Farbe mit Tint, Palette) und dem, was der Import daraus liest. Zellinhalte stehen nicht darin, nur
gezählt nach Art (Text, Zahl, Datum). Beim Urlaubsplaner stehen statt Spalten die gefundenen Monatsblöcke drin,
ohne Namen.

Dazu der ID-Helfer (scripts/ids-vorschlagen.ts): schreibt eine Kopie der Auslieferungsliste mit gefüllter Spalte
„Interne ID“; das Original bleibt unverändert.
"""

import os
import re
from collections import Counter
from datetime import date, datetime, time

from openpyxl import load_workbook
from openpyxl.styles import Font

from . import urlaub
from .excel import (deute_farbe, finde_kopfzeile, lies_arbeitsmappe, normalisiere, ordne_spalten_zu,
                    spaltenbuchstabe, zu_text)
from .importer import (MAPPINGS, ErwarteteZahlungen, Linienblatt, _ausstattung, _erkenne, alle_aliase, blatt_info,
                       fahrzeug_vorschlag, ist_liquiditaetsblatt, lade_mapping)

HINWEIS = ("Enthält nur Blattnamen, Spaltenüberschriften, Farben und Anzahlen – keine Zellinhalte. "
           "Farben als RRGGBB; „Design“ = Excel-Designfarbe mit Aufhellung (Tint).")


def _art_des_werts(w) -> str:
    if w is None or (isinstance(w, str) and not w.strip()):
        return "leer"
    if isinstance(w, bool):
        return "wahr_falsch"
    if isinstance(w, (datetime, date, time)):
        return "datum"
    if isinstance(w, (int, float)):
        return "zahl"
    return "text"


def _kopfzeile_raten(zeilen: list):
    """Port aus inspect-excel.ts, vorsichtiger: kurze Texte, überwiegend keine Zahlen, in den ersten 10 Zeilen.
    Sonst lieber gar keine Überschriften melden – eine falsch geratene Zeile wären Daten."""
    for i, zeile in enumerate(zeilen[:10]):
        werte = [w for w in zeile if zu_text(w)]
        if len(werte) < 3 or i + 1 >= len(zeilen):
            continue
        texte = [w for w in werte if isinstance(w, str) and not re.fullmatch(r"[\d.,\s€%\-]+", w)]
        if len(texte) / len(werte) > 0.7 and all(len(t.strip()) <= 40 for t in texte):
            return i
    return None


def _beste_zuordnung(blatt):
    """(Name, Kopfzeilen-Index, Zuordnungen) der passendsten Liste oder (None, None, [])."""
    beste = (None, None, [])
    punkte = 1
    for name in MAPPINGS:
        mapping = lade_mapping(name)
        k = finde_kopfzeile(blatt.zeilen, alle_aliase(mapping))
        zuordnungen, _ = ordne_spalten_zu(blatt.zeilen[k], mapping)
        n = len({z.spalte for z in zuordnungen})
        if n > punkte:
            beste, punkte = (name, k, zuordnungen), n
    return beste


def _quelle(quellen: dict, farbe: str, beschreibung: str):
    """Dieselbe Farbe kann als RGB, Design-Farbe oder Palette gespeichert sein – alle Herkünfte zählen."""
    eintrag = quellen.setdefault(farbe, [])
    if beschreibung not in eintrag:
        eintrag.append(beschreibung)


def _spalte(blatt, j: int, ab: int, kopf, felder, farbfelder, quellen):
    arten, fuell, schrift = Counter(), Counter(), Counter()
    for i in range(ab, len(blatt.zeilen)):
        w = blatt.wert(i, j)
        arten[_art_des_werts(w)] += 1
        f, s = blatt.farbe(i, j)
        fill, font = blatt.stil(i, j)
        if f:
            fuell[f] += 1
            _quelle(quellen, f, blatt._leser.beschreibe(blatt._leser.fuellung(fill)[1]))
        if s and _art_des_werts(w) != "leer":
            schrift[s] += 1
            _quelle(quellen, s, blatt._leser.beschreibe(font.color))

    def mit_deutung(zaehler, typ):
        aus = {}
        for farbe, n in zaehler.most_common():
            eintrag = {"anzahl": n}
            deutung = {f: deute_farbe(farbe, legende) for f, t, legende in farbfelder if t == typ}
            if deutung:
                eintrag["deutung"] = deutung
            aus[farbe] = eintrag
        return aus

    eintrag = {"spalte": spaltenbuchstabe(j)}
    if kopf is not None:
        eintrag["kopf"] = kopf
    if felder:
        eintrag["felder"] = felder
    eintrag["werte"] = {a: n for a, n in arten.items() if n}
    if fuell:
        eintrag["fuellfarben"] = mit_deutung(fuell, "fuellfarbe")
    if schrift:
        eintrag["schriftfarben"] = mit_deutung(schrift, "schriftfarbe")
    return eintrag


def _blatt_struktur(blatt) -> dict:
    aus = {"name": blatt.name, "zeilen_mit_inhalt": len(blatt.zeilen), "spalten": blatt.breite}
    if not blatt.zeilen:
        return aus
    info = blatt_info(blatt.name)
    if info["bank"] or info["hersteller"] or info["ueberspringen"]:
        aus["blattname_gelesen_als"] = {k: v for k, v in info.items() if v}

    if urlaub.hat_tageszeile(blatt):
        aus["art"] = "Urlaubsplaner (Kreuztabelle)"
        aus["monatsbloecke"] = urlaub.blockbeschreibung(blatt)
        return aus

    name, k, zuordnungen = _beste_zuordnung(blatt)
    sicher = name is not None
    if not info["bank"]:
        # Liquiditätsplan der Finanzaufstellung bzw. Block „zu erwartende Zahlungen“: nur Anzahlen, keine Namen
        leser = ErwarteteZahlungen(blatt)
        if leser.ueberschrift is not None or (name != "finanzierungen" and ist_liquiditaetsblatt(blatt)):
            saetze = leser.lesen("", lambda _t: None)
            aus["erwartete_zahlungen"] = {
                "ueberschrift_zeile": blatt.zeilennr[leser.ueberschrift] if leser.ueberschrift is not None else None,
                "zeilen": len(saetze), "offen": sum(1 for z in saetze if z["offen"]),
                "finanzierungen": sum(1 for z in saetze if z["offen"] and z["art"] == "Finanzierung"),
                "ohne_betrag": sum(1 for z in saetze if z["betrag"] is None),
                "ohne_datum": sum(1 for z in saetze if not z["erwartet_am"])}
    if not sicher:
        k = _kopfzeile_raten(blatt.zeilen)
    if k is None:
        aus["kopfzeile"] = None
        aus["hinweis"] = "Keine Kopfzeile erkannt – Überschriften werden nicht gezeigt."
        quellen = {}
        aus["spalten_ohne_kopf"] = [_spalte(blatt, j, 0, None, [], [], quellen) for j in range(blatt.breite)]
        aus["farbquellen"] = quellen
        return aus
    aus["zuordnung"] = name
    aus["kopfzeile"] = blatt.zeilennr[k]
    aus["kopf_sicher"] = sicher
    aus["datenzeilen"] = len(blatt.zeilen) - k - 1
    if name == "bestandsliste":
        aus["ausstattungszeilen"] = sum(1 for i in range(k + 1, len(blatt.zeilen))
                                        if _ausstattung(blatt, i, zuordnungen))
    if name == "finanzierungen" and info["bank"] and not info["ueberspringen"]:
        # Linienblatt: wie der Import die Zeilen versteht – nur Anzahlen, kein Limit und keine Konditionen im Wortlaut
        linie = Linienblatt(blatt, k, zuordnungen, info)
        for i in range(k + 1, len(blatt.zeilen)):
            linie.zeilenart(i)
        fuss = linie.fuss_lesen()
        aus["linienblatt"] = {"finanzierte_fahrzeuge": linie.anzahl["finanziert"],
                              "kommende_fahrzeuge": linie.anzahl["kommend"], "fusszeilen": len(linie.fuss),
                              "finanzierungsspalte": linie.finanzierungsspalte,
                              "limit_gefunden": fuss["limit_betrag"] is not None,
                              "konditionen_gefunden": bool(fuss["konditionen"])}
    kopf = blatt.zeilen[k]
    quellen = {}
    spalten, weitere = [], []
    for j in range(blatt.breite):
        felder = [z.feld for z in zuordnungen if z.spalte == j]
        farbfelder = [(z.feld, z.typ, z.legende) for z in zuordnungen
                      if z.spalte == j and z.typ in ("fuellfarbe", "schriftfarbe")]
        text = zu_text(kopf[j])
        if text:
            spalten.append(_spalte(blatt, j, k + 1, text, felder, farbfelder, quellen))
        elif any(blatt.wert(i, j) is not None for i in range(k + 1, len(blatt.zeilen))):
            weitere.append(_spalte(blatt, j, k + 1, None, [], [], quellen))
    aus["spalten_mit_kopf"] = spalten
    if weitere:
        aus["spalten_ohne_kopf"] = weitere
    aus["farbquellen"] = quellen
    return aus


MAX_ZEILEN = 5000      # der Artikelstamm hat 50.000 Zeilen; für Farben und Spaltenarten reicht der Anfang


def struktur(pfad) -> dict:
    """Aufbau der Mappe für die Fehlersuche – Blätter, Kopfzeile, Spaltennamen, Farben je Spalte, keine Werte."""
    blaetter = lies_arbeitsmappe(pfad, mit_farben=True, max_zeilen=MAX_ZEILEN)
    aus = []
    for b in blaetter:
        eintrag = _blatt_struktur(b)
        if b.zeilennr and b.zeilennr[-1] >= MAX_ZEILEN:
            eintrag["nur_ausgewertet_bis_zeile"] = MAX_ZEILEN
        aus.append(eintrag)
    return {"hinweis": HINWEIS, "dateityp": os.path.splitext(str(pfad))[1].lower(),
            "erkannt_als": _erkenne(blaetter), "blaetter": aus}


# ------------------------------------------------------------------------------------------- ID-Helfer ---

MODELL = ["Modell", "Model", "Fahrzeug"]
KUNDE = ["Name", "Kunde", "Käufer", "Kundenname"]


def _finde(kopf: list, namen: list) -> int:
    gesucht = {normalisiere(n) for n in namen}
    return next((j for j, k in enumerate(kopf) if normalisiere(zu_text(k)) in gesucht), -1)


def ids_vorschlagen(pfad_auslieferungsliste, db, ziel_pfad=None, spalte: str = "Interne ID") -> dict:
    """
    Schlägt für eine Auslieferungsliste die internen Fahrzeugnummern vor (über Modell und Kunde, mit den Fahrzeugen
    aus `db`) und schreibt sie in eine Kopie. Eindeutige Treffer stehen drin, mehrdeutige rot mit „?“ und Grund.
    Das Original wird nie verändert. Ergebnis: {"ziel", "zeilen", "gesetzt", "offen", "unklar", "hinweise", "fehler"}.
    """
    pfad = str(pfad_auslieferungsliste)
    endung = os.path.splitext(pfad)[1].lower() or ".xlsx"
    ziel = str(ziel_pfad or (os.path.splitext(pfad)[0] + "-mit-ID" + endung))
    bericht = {"ziel": ziel, "zeilen": 0, "gesetzt": 0, "offen": 0, "unklar": [], "hinweise": [], "fehler": ""}
    if os.path.abspath(ziel) == os.path.abspath(pfad) or (
            os.path.exists(ziel) and os.path.samefile(ziel, pfad)):
        bericht["fehler"] = "Die Kopie darf nicht das Original sein – das Original bleibt unverändert."
        return bericht
    werte = lies_arbeitsmappe(pfad, mit_farben=False)        # Formelergebnisse zum Lesen
    from ..sicher import pruefe_xlsx
    pruefe_xlsx(pfad)
    wb = load_workbook(pfad, keep_vba=endung == ".xlsm")      # Formeln bleiben Formeln in der Kopie
    rot = Font(color="FFC00000")
    for b in werte:
        if len(b.zeilen) < 2:
            continue
        ws = wb[b.name]
        k = finde_kopfzeile(b.zeilen, MODELL + KUNDE)
        kopf = b.zeilen[k]
        i_modell, i_kunde = _finde(kopf, MODELL), _finde(kopf, KUNDE)
        if i_modell < 0:
            bericht["hinweise"].append(f"Blatt „{b.name}“: keine Modellspalte – übersprungen")
            continue
        i_ziel = _finde(kopf, [spalte])
        if i_ziel < 0:
            i_ziel = b.breite                                  # neue Spalte rechts neben allem, was belegt ist
            c = ws.cell(row=b.zeilennr[k], column=i_ziel + 1, value=spalte)
            c.font = Font(bold=True)
        bericht["hinweise"].append(f"Blatt „{b.name}“: Kopfzeile {b.zeilennr[k]}, Spalte „{spalte}“ in "
                                   f"{spaltenbuchstabe(i_ziel)}")
        for i in range(k + 1, len(b.zeilen)):
            modell = zu_text(b.wert(i, i_modell))
            kunde = zu_text(b.wert(i, i_kunde)) if i_kunde >= 0 else None
            if not modell:
                continue
            bericht["zeilen"] += 1
            if zu_text(b.wert(i, i_ziel)):
                bericht["gesetzt"] += 1
                continue
            vid, grund = fahrzeug_vorschlag(db, modell, kunde)
            zelle = ws.cell(row=b.zeilennr[i], column=i_ziel + 1)
            if vid:
                zelle.value = vid
                bericht["gesetzt"] += 1
            else:
                zelle.value = f"? {grund}"
                zelle.font = rot
                bericht["offen"] += 1
                bericht["unklar"].append({"blatt": b.name, "zeile": b.zeilennr[i], "modell": modell,
                                          "kunde": kunde, "grund": grund})
    wb.save(ziel)
    wb.close()
    return bericht
