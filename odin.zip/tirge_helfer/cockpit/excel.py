"""
Excel-Listen lesen: Blätter, Kopfzeile, Werte und Zellfarben.

Übernommen aus dem muster Cockpit (lib/excel.ts). Für jede Liste gibt es eine Zuordnung (vorlagen/mappings/*.json),
die sagt „Spalte ‚EK netto‘ ist das Feld purchase_net“. Ändert sich eine Excel-Datei, wird nur die Zuordnung um die
neue Schreibweise ergänzt – nicht der Code.

Ein Teil der Information steckt in den Zellfarben. Verglichen wird der Farbton, nicht der Farbwert: ein etwas anderes
Rot bleibt Rot. Anders als ExcelJS im Original liest ODIN auch Design-Farben (Design-Index plus Aufhellung, wie Excel
sie für „Gold, Akzent 4, heller 80 %“ speichert) und die alten Palettenfarben (indexed).
"""

import colorsys
import math
import re
import zipfile
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from xml.etree import ElementTree

from openpyxl import load_workbook
from openpyxl.styles.colors import COLOR_INDEX
from openpyxl.utils.exceptions import InvalidFileException

from .db import lade_vorlage

# Fehlerwerte aus Formeln (deutsch und englisch) gelten als leer
FEHLERWERTE = {"#N/A", "#NV", "#DIV/0!", "#WERT!", "#VALUE!", "#BEZUG!", "#REF!", "#NAME?", "#ZAHL!", "#NUM!",
               "#NULL!", "#SPILL!", "#ÜBERLAUF!", "#CALC!", "#GETTING_DATA"}

MONATE = {
    "januar": 1, "jan": 1, "jänner": 1, "jaenner": 1, "january": 1,
    "februar": 2, "feb": 2, "february": 2,
    "märz": 3, "maerz": 3, "mär": 3, "mrz": 3, "march": 3, "mar": 3,
    "april": 4, "apr": 4,
    "mai": 5, "may": 5,
    "juni": 6, "jun": 6, "june": 6,
    "juli": 7, "jul": 7, "july": 7,
    "august": 8, "aug": 8,
    "september": 9, "sept": 9, "sep": 9,
    "oktober": 10, "okt": 10, "october": 10, "oct": 10,
    "november": 11, "nov": 11,
    "dezember": 12, "dez": 12, "december": 12, "dec": 12,
}
MONATSNAMEN = ("Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
               "November", "Dezember")
_MONAT_MUSTER = re.compile(
    r"(?<![a-zäöü])(" + "|".join(sorted(MONATE, key=len, reverse=True)) + r")(?![a-zäöü])\.?", re.IGNORECASE)


# ------------------------------------------------------------------------------------------- Werte umwandeln ---

def normalisiere(s) -> str:
    """Spaltenkopf zum Vergleichen: klein, ohne Leerzeichen und Satzzeichen, Umlaute ausgeschrieben."""
    t = re.sub(r"[\s._\-/()]", "", str("" if s is None else s).lower())
    return t.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")


def zu_text(wert):
    if wert is None:
        return None
    if isinstance(wert, bool):
        return "ja" if wert else "nein"
    if isinstance(wert, datetime):
        if wert.time() == time(0, 0):
            return wert.date().isoformat()
        return wert.strftime("%Y-%m-%d %H:%M")
    if isinstance(wert, date):
        return wert.isoformat()
    if isinstance(wert, time):
        return wert.strftime("%H:%M")
    if isinstance(wert, float):
        if not math.isfinite(wert):
            return None
        # 4417.0 aus Excel ist die Schlüsselnummer 4417, nicht „4417.0“
        return str(int(wert)) if wert.is_integer() else format(wert, ".12g")
    s = str(wert).strip()
    if not s or s in FEHLERWERTE:
        return None
    return s


def zu_zahl(wert):
    """'61.900,00 €', '61900', '−6.904,01', '7,9 %' → Zahl; Unlesbares → None."""
    if wert is None or isinstance(wert, (bool, datetime, date, time, timedelta)):
        return None
    if isinstance(wert, (int, float)):
        return float(wert) if math.isfinite(wert) else None
    s = str(wert).strip()
    if not s or s in FEHLERWERTE:
        return None
    s = s.replace("−", "-").replace("–", "-")      # typografisches Minus aus Word/Excel
    hinten_minus = s.endswith("-") and len(s) > 1              # „6.904,01-“ wie in Kontoauszügen
    s = re.sub(r"(?i)euro|eur|€|%|\s", "", s)
    if hinten_minus and s.endswith("-"):
        s = "-" + s[:-1].lstrip("-")
    if s in ("", "-", "+"):
        return None
    if "," in s and "." in s:
        # was zuletzt steht, trennt die Nachkommastellen: 61.900,50 (deutsch) oder 61,900.50 (englisch)
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        # ein Komma ist in deutschen Listen das Dezimalkomma; mehrere sind Tausendertrennzeichen
        s = s.replace(",", ".") if s.count(",") == 1 else s.replace(",", "")
    elif re.fullmatch(r"[-+]?\d{1,3}(\.\d{3})+", s):
        s = s.replace(".", "")                                  # 61.900 ohne Nachkommastellen
    try:
        n = float(s)
    except ValueError:
        return None
    return n if math.isfinite(n) else None


def _datum_oder_none(jahr, monat, tag):
    try:
        return date(jahr, monat, tag).isoformat()
    except ValueError:
        return None


def zu_datum(wert):
    """Datum als ISO-Text: Excel-Datum, Seriennummer, 'TT.MM.JJJJ', 'TT.MM.JJ', '2026-10-22', '1. März 2026'."""
    if wert is None or wert == "" or isinstance(wert, bool):
        return None
    if isinstance(wert, datetime):
        return wert.date().isoformat()
    if isinstance(wert, date):
        return wert.isoformat()
    if isinstance(wert, (int, float)):
        # Excel-Seriennummer (Tage seit 30.12.1899); nur in einem plausiblen Bereich, damit „2026“ kein Datum wird
        if not math.isfinite(wert) or not 18264 <= wert <= 73051:          # 1950 bis 2100
            return None
        return (datetime(1899, 12, 30) + timedelta(days=float(wert))).date().isoformat()
    s = str(wert).strip()
    m = re.match(r"^(\d{1,2})[./](\d{1,2})[./](\d{2,4})(?!\d)", s)                  # 31.12.2026 (auch mit Uhrzeit)
    if m:
        jahr = int(m.group(3))
        jahr = 2000 + jahr if len(m.group(3)) == 2 else jahr
        return _datum_oder_none(jahr, int(m.group(2)), int(m.group(1)))
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})", s)                                   # ISO
    if m:
        return _datum_oder_none(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.match(r"^(\d{1,2})\.?\s*([A-Za-zÄÖÜäöü]+)\.?\s*(\d{4})$", s)               # 1. März 2026
    if m and m.group(2).lower() in MONATE:
        return _datum_oder_none(int(m.group(3)), MONATE[m.group(2).lower()], int(m.group(1)))
    return None


JA = {"ja", "j", "x", "yes", "y", "true", "wahr", "1", "ok", "erledigt", "bezahlt", "✓", "✔"}
NEIN = {"nein", "n", "no", "false", "falsch", "0", "-", "offen"}


def zu_bool(wert):
    """Ja/Nein-Spalten: 1 = ja, 0 = nein, None = unbekannt."""
    if wert is None:
        return None
    if isinstance(wert, bool):
        return int(wert)
    if isinstance(wert, (int, float)):
        return 1 if wert else 0
    t = str(wert).strip().lower()
    return 1 if t in JA else 0 if t in NEIN else None


def _runde(n: float) -> int:
    """Kaufmännisch runden wie Math.round im Original (2,5 → 3), nicht wie Pythons round()."""
    return int(math.floor(n + 0.5))


def konvertiere(wert, typ: str = "text"):
    if typ == "zahl":
        return zu_zahl(wert)
    if typ == "ganzzahl":
        n = zu_zahl(wert)
        return None if n is None else _runde(n)
    if typ == "prozent":
        n = zu_zahl(wert)
        if n is None:
            return None
        # Excel speichert 7,9 % als 0,079 – ohne Prozentzeichen ist ein Wert bis 1 ein Anteil
        return n * 100 if abs(n) <= 1 and n != 0 and "%" not in str(wert) else n
    if typ == "datum":
        return zu_datum(wert)
    if typ == "id":
        t = zu_text(wert)
        return t.upper() if t else None
    if typ == "bool":
        return zu_bool(wert)
    return zu_text(wert)


def ist_leer(satz: dict) -> bool:
    return all(v is None or v == "" for v in satz.values())


def monat_aus_text(text):
    """'Januar', 'Jan. 26', 'März 2027' → (Monat, Jahr oder None); sonst None."""
    if not isinstance(text, str):
        return None
    m = _MONAT_MUSTER.search(text)
    if not m:
        return None
    monat = MONATE[m.group(1).lower()]
    j = re.search(r"(?<!\d)(20\d{2}|\d{2})(?!\d)", text[m.end():])
    jahr = None
    if j:
        jahr = int(j.group(1))
        jahr = 2000 + jahr if jahr < 100 else jahr
    return monat, jahr


# -------------------------------------------------------------------------------------------------- Farben ---
# Design-Farben: Excel zählt den Design-Index nicht in der Reihenfolge der Datei (dk1, lt1, dk2, lt2, …),
# sondern tauscht die ersten beiden Paare: 0 = lt1 (Hintergrund 1), 1 = dk1 (Text 1), 2 = lt2, 3 = dk2.
# Belegt durch die Standardschrift, die als theme="1" gespeichert ist und schwarz erscheint.
THEMEN_INDEX = ("lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6",
                "hlink", "folHlink")
# Office-Design ab Excel 2016, falls eine Datei kein eigenes Design mitbringt
STANDARD_THEMA = {"dk1": "000000", "lt1": "FFFFFF", "dk2": "44546A", "lt2": "E7E6E6", "accent1": "4472C4",
                  "accent2": "ED7D31", "accent3": "A5A5A5", "accent4": "FFC000", "accent5": "5B9BD5",
                  "accent6": "70AD47", "hlink": "0563C1", "folHlink": "954F72"}
_SYSTEMFARBEN = {"windowtext": "000000", "window": "FFFFFF", "buttonface": "F0F0F0", "buttontext": "000000"}
_DML = "{http://schemas.openxmlformats.org/drawingml/2006/main}"


def themenfarben(xml) -> list:
    """Farben des Designs in Excels Index-Reihenfolge (lt1, dk1, lt2, dk2, accent1–6, hlink, folHlink)."""
    farben = dict(STANDARD_THEMA)
    if xml:
        try:
            wurzel = ElementTree.fromstring(xml)
        except ElementTree.ParseError:
            wurzel = None
        schema = wurzel.find(f".//{_DML}clrScheme") if wurzel is not None else None
        for eintrag in list(schema) if schema is not None else []:
            name = eintrag.tag.replace(_DML, "")
            for farbe in eintrag:
                art = farbe.tag.replace(_DML, "")
                if art == "srgbClr" and farbe.get("val"):
                    farben[name] = farbe.get("val").upper()
                elif art == "sysClr":
                    wert = farbe.get("lastClr") or _SYSTEMFARBEN.get((farbe.get("val") or "").lower())
                    if wert:
                        farben[name] = wert.upper()
    return [farben[n] for n in THEMEN_INDEX]


def mit_tint(hexwert: str, tint: float) -> str:
    """Aufhellen/Abdunkeln wie Excel: Helligkeit im HLS-Farbraum, Tint −1…+1 (ECMA-376, ±1 je Kanal)."""
    if not tint:
        return hexwert
    r, g, b = (int(hexwert[i:i + 2], 16) / 255 for i in (0, 2, 4))
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    l = l * (1 + tint) if tint < 0 else l * (1 - tint) + tint
    r, g, b = colorsys.hls_to_rgb(h, min(max(l, 0.0), 1.0), s)
    return "%02X%02X%02X" % tuple(_runde(x * 255) for x in (r, g, b))


class Farbleser:
    """Übersetzt openpyxl-Farben (rgb, Design + Tint, Palette) in 'RRGGBB'. Braucht Design und Palette der Mappe."""

    def __init__(self, wb=None):
        self.thema = themenfarben(getattr(wb, "loaded_theme", None))
        palette = getattr(wb, "_colors", None) or COLOR_INDEX
        self.palette = [str(p)[-6:].upper() for p in palette]

    def hex(self, farbe):
        if farbe is None:
            return None
        art = getattr(farbe, "type", None)
        wert = None
        if art == "rgb":
            roh = farbe.rgb
            if isinstance(roh, str) and re.fullmatch(r"[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?", roh):
                wert = roh[-6:].upper()       # Alphakanal zählt bei Zellfarben nicht
        elif art == "theme":
            i = farbe.theme
            wert = self.thema[i] if isinstance(i, int) and 0 <= i < len(self.thema) else None
        elif art == "indexed":
            i = farbe.indexed
            if i == 64:
                wert = "000000"               # Systemvordergrund
            elif i == 65:
                wert = "FFFFFF"               # Systemhintergrund
            elif isinstance(i, int) and 0 <= i < len(self.palette):
                wert = self.palette[i]
        # 'auto' = automatische Farbe: bewusst None, Excel entscheidet selbst
        if wert is None:
            return None
        return mit_tint(wert, farbe.tint or 0)

    def beschreibe(self, farbe) -> str:
        """Woher eine Farbe kommt – für den Strukturbericht, ohne Zellinhalte."""
        art = getattr(farbe, "type", None)
        tint = getattr(farbe, "tint", 0) or 0
        zusatz = f", Tint {tint:+.2f}" if tint else ""
        if art == "theme":
            i = farbe.theme
            name = THEMEN_INDEX[i] if isinstance(i, int) and 0 <= i < len(THEMEN_INDEX) else "?"
            return f"Design {i} ({name}){zusatz}"
        if art == "indexed":
            return f"Palette {farbe.indexed}{zusatz}"
        return f"RGB{zusatz}"

    def fuellung(self, fill):
        """(Farbe, openpyxl-Farbe) der Füllung oder (None, None) ohne Füllung."""
        if fill is None:
            return None, None
        muster = getattr(fill, "patternType", None)
        if muster is not None or hasattr(fill, "fgColor"):
            if not muster or muster == "none":
                return None, None
            farbe = fill.fgColor
            wert = self.hex(farbe)
            if wert is None and muster != "solid":
                farbe = fill.bgColor          # Schraffur ohne Vordergrund: Hintergrund zählt
                wert = self.hex(farbe)
            return wert, farbe
        stops = getattr(fill, "stop", None)   # Farbverlauf: erste Farbe
        if stops:
            return self.hex(stops[0].color), stops[0].color
        return None, None

    def fuellfarbe(self, fill):
        return self.fuellung(fill)[0]

    def schriftfarbe(self, font):
        return self.hex(font.color) if font is not None and font.color is not None else None


# Legende aus vorlagen/farben.json, einmal geladen
_LEGENDEN = {}
BUNT = 0.18   # ab dieser Sättigung gilt eine Farbe als farbig


def _legenden() -> dict:
    if not _LEGENDEN:
        roh = lade_vorlage("farben")
        gruppen = {}
        for gruppe, werte in roh.items():
            if gruppe.startswith("_") or not isinstance(werte, dict):
                continue
            gruppen[gruppe] = {name: str(f)[-6:].upper() for name, f in werte.items() if not name.startswith("_")}
        ignorieren = [str(f)[-6:].upper() for name, f in (roh.get("_ignorieren") or {}).items()
                      if not name.startswith("_")]
        _LEGENDEN.update(toleranz=float(roh.get("_toleranz", 70)), gruppen=gruppen, ignorieren=ignorieren)
    return _LEGENDEN


def legende(gruppe: str) -> dict:
    return dict(_legenden()["gruppen"].get(gruppe, {}))


def _rgb(hexwert: str):
    h = hexwert.lstrip("#")[-6:]
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _hsv(rgb):
    h, s, v = colorsys.rgb_to_hsv(*(x / 255 for x in rgb))
    return h * 360, s, v


def farbabstand(a: str, b: str) -> float:
    """
    Farbabstand über den Farbton statt über RGB: helleres oder dunkleres Rot bleibt Rot. Sättigung und Helligkeit
    zählen mit, damit die Legende zwei Töne derselben Farbe trennen kann. Ist genau eine Farbe neutral (weiß, grau,
    schwarz), wird der Abstand bewusst groß.
    """
    h1, s1, v1 = _hsv(_rgb(a))
    h2, s2, v2 = _hsv(_rgb(b))
    if s1 < BUNT or s2 < BUNT:
        beide_neutral = s1 < BUNT and s2 < BUNT
        return 120 * abs(s1 - s2) + 90 * abs(v1 - v2) + (0 if beide_neutral else 60)
    dh = abs(h1 - h2)
    if dh > 180:
        dh = 360 - dh
    return dh * 0.55 + 45 * abs(s1 - s2) + 35 * abs(v1 - v2)


def ist_neutral(hexwert: str) -> bool:
    """Weiß, Grau, Schwarz – Farben ohne Farbton."""
    return _hsv(_rgb(hexwert))[1] < BUNT


def bedeutung(name: str) -> str:
    """'belegt (gelb)' → 'belegt': mehrere Töne derselben Bedeutung stehen mit Zusatz in Klammern in der Legende."""
    return re.sub(r"\s*\([^)]*\)\s*$", "", name)


def deute_farbe(hexwert, gruppe: str, zweifel: list = None):
    """
    Ordnet einen Farbwert der nächstliegenden Farbe einer Legende zu. Zwei fast gleich nahe Legendenfarben werden
    in `zweifel` gemeldet, statt still eine Seite zu wählen. Neutrale Farben bedeuten nichts, außer die Legende führt
    sie selbst – dann gewinnt die Legende bei Gleichstand.
    """
    if not hexwert:
        return None
    daten = _legenden()
    eintraege = daten["gruppen"].get(gruppe)
    if not eintraege:
        return None
    abstaende = sorted(((farbabstand(hexwert, f), name) for name, f in eintraege.items()), key=lambda x: x[0])
    beste_d, beste = abstaende[0]
    if beste_d > daten["toleranz"]:
        return None
    naechste_neutrale = min((farbabstand(hexwert, f) for f in daten["ignorieren"]), default=math.inf)
    if beste_d > naechste_neutrale:
        return None
    if zweifel is not None:
        andere = [(d, n) for d, n in abstaende[1:] if bedeutung(n) != bedeutung(beste)]
        if andere and andere[0][0] - beste_d < 8:
            hinweis = (f"Farbe #{hexwert[-6:]} in „{gruppe}“: {bedeutung(beste)} oder {bedeutung(andere[0][1])}? "
                       f"– als {bedeutung(beste)} gelesen")
            if hinweis not in zweifel:
                zweifel.append(hinweis)
    return bedeutung(beste)


def farb_abstand_zur_legende(hexwert, gruppe: str):
    eintraege = _legenden()["gruppen"].get(gruppe)
    if not hexwert or not eintraege:
        return None
    return min(farbabstand(hexwert, f) for f in eintraege.values())


# ------------------------------------------------------------------------------------------------- Mappen ---

class UnlesbareDatei(Exception):
    """Die Datei ist keine (lesbare) Excel-Mappe."""


def oeffne_mappe(pfad, nur_lesen: bool = True, nur_werte: bool = True):
    """
    Mappe mit den von Excel gespeicherten Formelergebnissen (data_only). Nach Gebrauch wb.close().
    Eine kaputte oder fremde Datei ergibt UnlesbareDatei; eine gesperrte Datei bleibt PermissionError.
    """
    try:
        from ..sicher import pruefe_xlsx
        pruefe_xlsx(pfad)
        return load_workbook(pfad, read_only=nur_lesen, data_only=nur_werte)
    except PermissionError:
        raise
    except (zipfile.BadZipFile, InvalidFileException, KeyError, EOFError, ValueError, TypeError,
            ElementTree.ParseError, OSError) as e:
        raise UnlesbareDatei(str(e) or type(e).__name__) from e


def blattnamen(pfad):
    """
    Blattnamen direkt aus xl/workbook.xml, ohne die Mappe zu öffnen. Schneller: openpyxl liest beim Öffnen jedes
    Blatt an (bei Dateien ohne Größenangabe ganz – beim 50.000-Zeilen-Artikelstamm eine Sekunde). None, wenn die
    Datei anders aufgebaut ist; dann bleibt nur das Öffnen.
    """
    try:
        with zipfile.ZipFile(pfad) as archiv:
            xml = archiv.read("xl/workbook.xml")
        wurzel = ElementTree.fromstring(xml)
    except PermissionError:
        raise
    except (KeyError, zipfile.BadZipFile, OSError, ElementTree.ParseError):
        return None
    return [e.get("name") for e in wurzel.iter() if e.tag.rsplit("}", 1)[-1] == "sheet" and e.get("name")]


def _hat_wert(w) -> bool:
    return w is not None and not (isinstance(w, str) and not w.strip())


@dataclass
class Blatt:
    """Ein Tabellenblatt: nur Zeilen mit Inhalt, jede gleich breit, dazu die echte Excel-Zeilennummer."""
    name: str
    zeilen: list = field(default_factory=list)
    zeilennr: list = field(default_factory=list)
    _stile: list = None                      # je Zelle (Füllung, Schrift) als openpyxl-Objekte
    _leser: Farbleser = None
    _cache: dict = field(default_factory=dict)

    @property
    def breite(self) -> int:
        return len(self.zeilen[0]) if self.zeilen else 0

    def wert(self, i: int, spalte: int):
        zeile = self.zeilen[i]
        return zeile[spalte] if 0 <= spalte < len(zeile) else None

    def stil(self, i: int, spalte: int):
        if self._stile is None or spalte >= len(self._stile[i]):
            return None, None
        return self._stile[i][spalte] or (None, None)

    def farbe(self, i: int, spalte: int):
        """(Füllfarbe, Schriftfarbe) als 'RRGGBB' oder None – so wie in der Datei gesetzt."""
        fill, font = self.stil(i, spalte)
        if fill is None and font is None:
            return None, None
        schluessel = (id(fill), id(font))
        if schluessel not in self._cache:
            self._cache[schluessel] = (self._leser.fuellfarbe(fill), self._leser.schriftfarbe(font))
        return self._cache[schluessel]


def lies_blatt(ws, leser: Farbleser = None, max_zeilen: int = None) -> Blatt:
    """Liest ein Blatt einer read-only geöffneten Mappe; leere Zeilen fallen weg, die Zeilennummer bleibt."""
    if hasattr(ws, "reset_dimensions"):
        ws.reset_dimensions()       # manche Programme schreiben falsche Abmessungen – dann nicht abschneiden
    blatt = Blatt(ws.title, _stile=[] if leser else None, _leser=leser)
    for nr, zeile in enumerate(ws.iter_rows(max_row=max_zeilen, values_only=leser is None), start=1):
        werte = list(zeile) if leser is None else [z.value for z in zeile]
        if not any(_hat_wert(w) for w in werte):
            continue
        blatt.zeilen.append(werte)
        blatt.zeilennr.append(nr)
        if leser is not None:
            blatt._stile.append([(z.fill, z.font) if getattr(z, "fill", None) is not None else None for z in zeile])
    breite = max((len(z) for z in blatt.zeilen), default=0)
    for i, z in enumerate(blatt.zeilen):
        if len(z) < breite:
            z.extend([None] * (breite - len(z)))
            if leser is not None:
                blatt._stile[i].extend([None] * (breite - len(blatt._stile[i])))
    return blatt


def lies_arbeitsmappe(pfad, mit_farben: bool = True, blaetter=None, max_zeilen: int = None) -> list:
    """Alle (oder die genannten) Blätter einer Mappe; mit_farben=False ist deutlich schneller."""
    wb = oeffne_mappe(pfad)
    try:
        leser = Farbleser(wb) if mit_farben else None
        return [lies_blatt(ws, leser, max_zeilen) for ws in wb.worksheets
                if blaetter is None or ws.title in blaetter]
    finally:
        wb.close()


# ------------------------------------------------------------------------------------------ Zuordnungen ---

def regeln(mapping: dict) -> dict:
    """Spaltenregeln einheitlich als dict: Kurzform ["A", "B"] wird zu {"quelle": ["A", "B"]}."""
    return {feld: (r if isinstance(r, dict) else {"quelle": list(r)}) for feld, r in mapping["spalten"].items()}


def alle_aliase(mapping: dict) -> list:
    return [q for r in regeln(mapping).values() for q in r["quelle"]]


def finde_kopfzeile(zeilen: list, aliase: list, suchtiefe: int = 25) -> int:
    """Die erste Zeile, in der mindestens zwei erwartete Spaltennamen stehen (sonst die erste Zeile)."""
    gesucht = {normalisiere(a) for a in aliase}
    for i, zeile in enumerate(zeilen[:suchtiefe]):
        if sum(1 for z in zeile if normalisiere(zu_text(z)) in gesucht) >= 2:
            return i
    return 0


@dataclass
class Zuordnung:
    feld: str
    spalte: int
    quelle: str
    typ: str
    legende: str = None


def ordne_spalten_zu(kopf: list, mapping: dict):
    """Ordnet die Felder der Zuordnung den Spalten zu: (zuordnungen, fehlende Pflichtfelder)."""
    kopf_norm = [normalisiere(zu_text(k)) for k in kopf]
    zuordnungen, fehlend = [], []
    for feld, r in regeln(mapping).items():
        spalte = next((kopf_norm.index(q) for q in map(normalisiere, r["quelle"]) if q and q in kopf_norm), None)
        if spalte is None:
            if r.get("pflicht"):
                fehlend.append(feld)
            continue
        zuordnungen.append(Zuordnung(feld, spalte, zu_text(kopf[spalte]), r.get("typ", "text"),
                                     r.get("legende", feld)))
    return zuordnungen, fehlend


def zellfarbe_fuer_deutung(blatt: Blatt, i: int, spalte: int, typ: str):
    """
    Farbe, wie das Auge sie sieht: eine Zelle mit Inhalt ohne Füllung ist weiß, ohne Schriftfarbe schwarz.
    Sonst ginge „weiß = Kundenabholung“ und „schwarz = Kai“ verloren, denn so sieht jede unformatierte Zelle aus.
    Die Schriftfarbe einer leeren Zelle bedeutet nichts.
    """
    fuell, schrift = blatt.farbe(i, spalte)
    hat_wert = _hat_wert(blatt.wert(i, spalte))
    if typ == "schriftfarbe":
        return (schrift or "000000") if hat_wert else None
    return fuell or ("FFFFFF" if hat_wert else None)


def zeile_zu_datensatz(blatt: Blatt, i: int, zuordnungen: list, feste: dict = None, zweifel: list = None) -> dict:
    """Eine Zeile als dict Feld → Wert; Farbfelder werden über die Legende gedeutet."""
    satz = dict(feste or {})
    for z in zuordnungen:
        if z.typ in ("fuellfarbe", "schriftfarbe"):
            satz[z.feld] = deute_farbe(zellfarbe_fuer_deutung(blatt, i, z.spalte, z.typ), z.legende, zweifel)
        else:
            satz[z.feld] = konvertiere(blatt.wert(i, z.spalte), z.typ)
    return satz


def spaltenbuchstabe(spalte: int) -> str:
    """0 → 'A', 27 → 'AB'."""
    s, n = "", spalte + 1
    while n:
        n, rest = divmod(n - 1, 26)
        s = chr(65 + rest) + s
    return s
