"""
Führungswerkzeuge im Cockpit: Wochen-Scorecard, Fristenkalender des Betriebs, Zinsuhr mit Nachlass-Rahmen für
Langsteher und Herstellerbonus-Staffeln. (Werkstattaufträge laufen über CaraCamp, nicht über ODIN.)

Alles rechnet aus der Cockpit-Datenbank (eingelesene Listen) und den eigenen Einträgen aus ODINs Speicher
(Ziele, Fristen, Staffeln). Die Funktionen ändern nichts; gespeichert wird in daten.py.

Herkunft der Ideen (Beirat): Scorecard und Wochenrunde nach Wickman (EOS) und Harnish,
Preisnachlass gegen Standkosten nach Hermann Simon.
"""

import datetime as dt

from .auswertungen import IN_STOCK, _alle, _eine, js_runden, kalenderwoche, montag_von, stichtag_oder_heute

# --------------------------------------------------------------------------------------------- Scorecard

SCORECARD_WOCHEN = 13

# Kennzahlen, die ODIN selbst aus den Listen rechnet – auch rückwirkend für die letzten 13 Wochen.
AUTO_KENNZAHLEN = {
    "verkaeufe": {"name": "Verkäufe", "einheit": "Fzg.", "richtung": ">=",
                  "erklaerung": "Fahrzeuge mit Verkaufsdatum in der Woche (Bestandsliste)"},
    "uebergaben": {"name": "Übergaben", "einheit": "Fzg.", "richtung": ">=",
                   "erklaerung": "Tatsächlich übergebene Fahrzeuge (Auslieferungsliste)"},
    "bestand": {"name": "Bestand auf dem Hof", "einheit": "Fzg.", "richtung": "<=",
                "erklaerung": "Angelieferte, noch nicht übergebene Fahrzeuge am Sonntag der Woche"},
    "standtage": {"name": "Ø Standtage", "einheit": "Tage", "richtung": "<=",
                  "erklaerung": "Durchschnittliche Standzeit dieser Fahrzeuge am Sonntag der Woche"},
    "langsteher": {"name": "Langsteher", "einheit": "Fzg.", "richtung": "<=",
                   "erklaerung": "Fahrzeuge, die länger als die eingestellte Grenze stehen (Standard 180 Tage)"},
    "zinspflichtig": {"name": "Fahrzeuge mit laufenden Zinsen", "einheit": "Fzg.", "richtung": "<=",
                      "erklaerung": "Finanzierte Fahrzeuge im Bestand, deren Zinsfreiheit abgelaufen ist"},
    "gebraucht_90": {"name": "Gebrauchte über 90 Standtage", "einheit": "Fzg.", "richtung": "<=",
                     "erklaerung": "Gebrauchtfahrzeuge auf dem Hof, die länger als 90 Tage stehen"},
}

# Vorschläge für eigene Kennzahlen: die 14 Wochenzahlen aus Wickmans Übertragung auf Muster (Beirat,
# wickman-traction/caravanhandel-transfer.md Nr. 3; Einheit/Richtung teils abgeleitet, Ziele saisonal je Quartal).
SCORECARD_VORLAGEN = [
    {"name": "Qualifizierte Anfragen", "einheit": "Anz.", "richtung": ">=", "verantwortlich": "Verkaufsleitung"},
    {"name": "Besichtigungen / Beratungstermine", "einheit": "Anz.", "richtung": ">=", "verantwortlich": "Verkaufsleitung"},
    {"name": "Kaufverträge Neu", "einheit": "Anz.", "richtung": ">=", "verantwortlich": "Verkaufsleitung"},
    {"name": "Kaufverträge Gebraucht", "einheit": "Anz.", "richtung": ">=", "verantwortlich": "Verkaufsleitung"},
    {"name": "Werkstatt: verkaufte vs. anwesende Stunden", "einheit": "%", "richtung": ">=", "verantwortlich": "Meister"},
    {"name": "Termintreue Werkstatt", "einheit": "%", "richtung": ">=", "verantwortlich": "Meister"},
    {"name": "Nacharbeit / Rückkehrer", "einheit": "Anz.", "richtung": "<=", "verantwortlich": "Meister"},
    {"name": "Übergabeinspektionen fertig (nächste 14 Tage)", "einheit": "%", "richtung": ">=",
     "verantwortlich": "Serviceleitung"},
    {"name": "Garantie-/Kulanzanträge älter als 30 Tage", "einheit": "Anz.", "richtung": "<=",
     "verantwortlich": "Serviceannahme"},
    {"name": "Rohertrag Teile & Zubehör", "einheit": "€", "richtung": ">=", "verantwortlich": "Teile/Zubehör"},
    {"name": "Belegte Stellplätze Einlagerung", "einheit": "%", "richtung": ">=", "verantwortlich": "Serviceannahme"},
    {"name": "Kontostand", "einheit": "€", "richtung": ">=", "verantwortlich": "Büro"},
    {"name": "Forderungen älter als 30 Tage", "einheit": "€", "richtung": "<=", "verantwortlich": "Büro"},
    {"name": "Bewertungen der Woche", "einheit": "Anz.", "richtung": ">=", "verantwortlich": "Geschäftsführung"},
    {"name": "Beschwerden der Woche", "einheit": "Anz.", "richtung": "<=", "verantwortlich": "Geschäftsführung"},
]
STANDARD_REIHENFOLGE = ["verkaeufe", "uebergaben", "bestand", "standtage", "langsteher", "gebraucht_90",
                        "zinspflichtig"]


def woche_schluessel(tag) -> str:
    t = dt.date.fromisoformat(str(tag)[:10]) if not isinstance(tag, dt.date) else tag
    jahr, woche, _ = t.isocalendar()
    return f"{jahr}-W{woche:02d}"


def standard_scorecard() -> dict:
    return {"kennzahlen": [{"id": k, "quelle": "auto", "name": AUTO_KENNZAHLEN[k]["name"],
                            "einheit": AUTO_KENNZAHLEN[k]["einheit"], "richtung": AUTO_KENNZAHLEN[k]["richtung"],
                            "ziel": None, "verantwortlich": "", "aktiv": True} for k in STANDARD_REIHENFOLGE],
            "werte": {}}


def _bestand_am(db, tag: str, langsteher_tage: int) -> dict:
    """Angelieferte Fahrzeuge, die am Tag noch nicht übergeben waren: Anzahl, Ø Standtage, Langsteher, verzinst."""
    zeilen = _alle(db, f"""
        SELECT v.internal_id, v.arrival_date, v.status, v.sold_date, v.condition,
               (SELECT MIN(d.actual_date) FROM deliveries d WHERE d.vehicle_internal_id = v.internal_id
                  AND d.actual_date IS NOT NULL) AS uebergeben,
               (SELECT MIN(f.interest_free_until) FROM financings f WHERE f.vehicle_internal_id = v.internal_id
                  AND f.status = 'offen') AS zinsfrei_bis
        FROM vehicles v
        WHERE v.arrival_date IS NOT NULL AND date(v.arrival_date) <= date(:tag)""", {"tag": tag})
    stehen = []
    for z in zeilen:
        weg = z["uebergeben"] or (z["sold_date"] if z["status"] == "Ausgeliefert" else None)
        if z["status"] == "Ausgeliefert" and not weg:
            continue                                   # übergeben, Datum unbekannt – zählt nicht mehr
        if weg and str(weg)[:10] <= tag:
            continue
        stehen.append(z)
    t = dt.date.fromisoformat(tag)
    tage = [(t - dt.date.fromisoformat(str(z["arrival_date"])[:10])).days for z in stehen]
    gebraucht = [x for z, x in zip(stehen, tage) if str(z["condition"] or "").lower().startswith("gebr")]
    return {
        "bestand": len(stehen),
        "standtage": js_runden(sum(tage) / len(tage)) if tage else None,
        "langsteher": sum(1 for x in tage if x > langsteher_tage),
        "gebraucht_90": sum(1 for x in gebraucht if x > 90),
        "zinspflichtig": sum(1 for z in stehen if z["zinsfrei_bis"] and str(z["zinsfrei_bis"])[:10] < tag),
    }


def _auto_werte(db, wochen: list, langsteher_tage: int) -> dict:
    werte = {k: {} for k in AUTO_KENNZAHLEN}
    for w in wochen:
        von, bis, s = w["von"], w["bis"], w["woche"]
        werte["verkaeufe"][s] = _eine(db, "SELECT COUNT(*) AS n FROM vehicles WHERE date(sold_date) BETWEEN date(?) "
                                          "AND date(?)", (von, bis))["n"]
        werte["uebergaben"][s] = _eine(db, "SELECT COUNT(*) AS n FROM deliveries WHERE date(actual_date) BETWEEN "
                                           "date(?) AND date(?)", (von, bis))["n"]
        stand = _bestand_am(db, bis, langsteher_tage)
        for k in ("bestand", "standtage", "langsteher", "gebraucht_90", "zinspflichtig"):
            werte[k][s] = stand[k]
    return werte


def ampel(wert, ziel, richtung) -> str:
    if wert is None or ziel is None:
        return ""
    return "gut" if (wert >= ziel if richtung == ">=" else wert <= ziel) else "schlecht"


def scorecard(db, stichtag, einstellung: dict, langsteher_tage: int = 180) -> dict:
    """13 Wochen bis einschließlich der laufenden. Je Kennzahl Ziel, Richtung, Verantwortlicher, Werte und Ampel.
    Eigene Kennzahlen bekommen ihre Werte aus der Wocheneingabe; ODINs Kennzahlen rechnen sich selbst."""
    tag = stichtag_oder_heute(stichtag)
    montag = montag_von(tag)
    wochen = []
    for i in range(SCORECARD_WOCHEN - 1, -1, -1):
        start = montag - dt.timedelta(days=7 * i)
        ende = start + dt.timedelta(days=6)
        wochen.append({"woche": woche_schluessel(start), "kw": kalenderwoche(start), "von": start.isoformat(),
                       "bis": min(ende.isoformat(), tag) if i == 0 else ende.isoformat(), "laufend": i == 0})
    cfg = einstellung if einstellung and einstellung.get("kennzahlen") else standard_scorecard()
    auto = _auto_werte(db, wochen, langsteher_tage)
    zeilen = []
    for k in cfg["kennzahlen"]:
        if not k.get("aktiv", True):
            continue
        quelle = AUTO_KENNZAHLEN.get(k["id"]) if k.get("quelle") == "auto" else None
        if k.get("quelle") == "auto" and not quelle:
            continue                                     # unbekannte Auto-Kennzahl (älterer Stand)
        eigene = (einstellung or {}).get("werte", {}).get(str(k["id"]), {})
        werte = [{"woche": w["woche"], "wert": (auto[k["id"]].get(w["woche"]) if quelle else eigene.get(w["woche"]))}
                 for w in wochen]
        for w in werte:
            w["ampel"] = ampel(w["wert"], k.get("ziel"), k.get("richtung", ">="))
        rot_folge = 0
        for w in reversed(werte[:-1] if werte and werte[-1]["wert"] is None else werte):
            if w["ampel"] != "schlecht":
                break
            rot_folge += 1
        zeilen.append({**k, "erklaerung": quelle["erklaerung"] if quelle else "Eigene Kennzahl – Wert je Woche "
                                                                              "eintragen",
                       "werte": werte, "rot_in_folge": rot_folge})
    aktuell = [z["werte"][-1]["ampel"] for z in zeilen]
    return {"wochen": wochen, "kennzahlen": zeilen,
            "im_ziel": sum(1 for x in aktuell if x == "gut"), "mit_ziel": sum(1 for x in aktuell if x),
            "rot_seit_3": sum(1 for z in zeilen if z["rot_in_folge"] >= 3),
            "verfuegbar": [{"id": k, **v} for k, v in AUTO_KENNZAHLEN.items()],
            # ohne Auto-Kennzahlen, die es nicht mehr gibt (z. B. „werkstatt“) – sonst kämen sie beim Speichern als
            # eigene Kennzahl zurück
            "konfiguration": [k for k in cfg["kennzahlen"]
                              if k.get("quelle") != "auto" or k.get("id") in AUTO_KENNZAHLEN],
            "vorlagen": SCORECARD_VORLAGEN}


# ------------------------------------------------------------------------------------- Fristenkalender

FRIST_KATEGORIEN = ["Prüfung & Wartung", "Versicherung", "Vertrag", "Schulung & Nachweis", "Steuer & Behörde",
                    "Sonstiges"]
# Vorschläge zum schnellen Anlegen. Intervalle sind Startwerte – im Betrieb bitte prüfen und anpassen.
FRIST_VORLAGEN = [
    {"titel": "Prüfung Hebebühnen", "kategorie": "Prüfung & Wartung", "intervall_monate": 12},
    {"titel": "Prüfung Feuerlöscher", "kategorie": "Prüfung & Wartung", "intervall_monate": 24},
    {"titel": "Prüfung elektrischer Geräte (ortsveränderlich)", "kategorie": "Prüfung & Wartung",
     "intervall_monate": 12},
    {"titel": "Sachkunde Gasprüfung auffrischen", "kategorie": "Schulung & Nachweis", "intervall_monate": 60},
    {"titel": "Erste-Hilfe-Ausbildung Ersthelfer", "kategorie": "Schulung & Nachweis", "intervall_monate": 24},
    {"titel": "Betriebshaftpflicht prüfen", "kategorie": "Versicherung", "intervall_monate": 12},
    {"titel": "Vertrag Hersteller verlängern", "kategorie": "Vertrag", "intervall_monate": 12},
]


def plus_monate(tag: dt.date, monate: int) -> dt.date:
    jahr, monat = divmod(tag.month - 1 + int(monate), 12)
    jahr, monat = tag.year + jahr, monat + 1
    letzter = (dt.date(jahr + monat // 12, monat % 12 + 1, 1) - dt.timedelta(days=1)).day
    return dt.date(jahr, monat, min(tag.day, letzter))


def fristen_status(fristen: list, stichtag) -> list:
    """Fristen mit Zustand: ueberfaellig, bald (innerhalb des Vorlaufs), ok, erledigt (einmalige)."""
    tag = dt.date.fromisoformat(stichtag_oder_heute(stichtag))
    aus = []
    for f in fristen:
        if not f.get("faellig_am"):
            continue
        faellig = dt.date.fromisoformat(str(f["faellig_am"])[:10])
        rest = (faellig - tag).days
        vorlauf = int(f.get("vorlauf_tage") or 30)
        if f.get("erledigt"):
            zustand = "erledigt"
        elif rest < 0:
            zustand = "ueberfaellig"
        elif rest <= vorlauf:
            zustand = "bald"
        else:
            zustand = "ok"
        aus.append({**f, "tage_bis": rest, "zustand": zustand})
    rang = {"ueberfaellig": 0, "bald": 1, "ok": 2, "erledigt": 3}
    return sorted(aus, key=lambda f: (rang[f["zustand"]], f["faellig_am"], f.get("titel") or ""))


# ------------------------------------------------------------------------------------------- Zinsuhr

def zinsuhr(db, stichtag, kalk_zins_pct=5.0, langsteher_tage=180, vorzieh_tage=60) -> dict:
    """Was der Bestand jeden Tag kostet: echte Zinsen nach Ende der Zinsfreiheit und – kalkulatorisch – das
    gebundene Kapital. Für Langsteher der Nachlass, der sich rechnet, wenn er den Verkauf um `vorzieh_tage` vorzieht
    (Hermann Simon: lieber gezielt und begründet nachlassen als pauschal), gedeckelt durch die Preisuntergrenze."""
    tag = stichtag_oder_heute(stichtag)
    t = dt.date.fromisoformat(tag)
    zeilen = _alle(db, f"""
        SELECT v.internal_id, v.brand, v.model, v.category, v.status, v.arrival_date, v.purchase_net,
               v.extra_cost_net, v.list_price_net, v.vk_min, v.internet_price,
               f.bank, f.financed_amount, f.interest_rate_pct, f.interest_free_until
        FROM vehicles v
        LEFT JOIN financings f ON f.vehicle_internal_id = v.internal_id AND f.status = 'offen'
        WHERE v.status IN {IN_STOCK} AND (v.lieferstatus IS NULL OR v.lieferstatus = 'angeliefert')
        ORDER BY v.internal_id""")
    fahrzeuge = {}
    for z in zeilen:                                     # mehrere offene Verträge je Fahrzeug zusammenfassen
        f = fahrzeuge.setdefault(z["internal_id"], {**z, "zins_tag": 0.0, "zins_bisher": 0.0, "zins_seit": None})
        bis = z["interest_free_until"]
        if z["financed_amount"] and z["interest_rate_pct"] and bis and str(bis)[:10] < tag:
            pro_tag = z["financed_amount"] * z["interest_rate_pct"] / 100 / 365
            seit = dt.date.fromisoformat(str(bis)[:10])
            f["zins_tag"] += pro_tag
            f["zins_bisher"] += pro_tag * (t - seit).days
            f["zins_seit"] = min(filter(None, [f["zins_seit"], seit.isoformat()]))
    liste = []
    for f in fahrzeuge.values():
        einstand = (f["purchase_net"] or 0) + (f["extra_cost_net"] or 0)
        kapital_tag = einstand * float(kalk_zins_pct) / 100 / 365
        standtage = (t - dt.date.fromisoformat(str(f["arrival_date"])[:10])).days if f["arrival_date"] else None
        kosten_tag = f["zins_tag"] + kapital_tag
        eintrag = {"internal_id": f["internal_id"], "brand": f["brand"], "model": f["model"], "status": f["status"],
                   "bank": f["bank"], "standtage": standtage, "einstand": einstand,
                   "zins_tag": round(f["zins_tag"], 2), "zins_bisher": round(f["zins_bisher"], 2),
                   "zins_seit": f["zins_seit"], "kapital_tag": round(kapital_tag, 2),
                   "kosten_tag": round(kosten_tag, 2), "kosten_monat": round(kosten_tag * 30, 2),
                   "list_price_net": f["list_price_net"], "vk_min": f["vk_min"], "nachlass": None}
        langsteher = (standtage or 0) > int(langsteher_tage) or f["zins_tag"] > 0
        if f["status"] == "Bestand" and langsteher:
            rahmen = kosten_tag * int(vorzieh_tage)
            spielraum = (f["list_price_net"] - f["vk_min"]) if f["list_price_net"] and f["vk_min"] else None
            eintrag["nachlass"] = {
                "rahmen": js_runden(rahmen / 50) * 50,
                "spielraum": js_runden(spielraum) if spielraum is not None else None,
                "vorschlag": js_runden(max(0, min(rahmen, spielraum)) / 50) * 50 if spielraum is not None
                else js_runden(rahmen / 50) * 50,
                "untergrenze": f["vk_min"],
            }
        liste.append(eintrag)
    liste.sort(key=lambda e: -e["kosten_tag"])
    return {
        "parameter": {"kalk_zins_pct": float(kalk_zins_pct), "langsteher_tage": int(langsteher_tage),
                      "vorzieh_tage": int(vorzieh_tage)},
        "zins_tag": round(sum(e["zins_tag"] for e in liste), 2),
        "kapital_tag": round(sum(e["kapital_tag"] for e in liste), 2),
        "kosten_monat": round(sum(e["kosten_tag"] for e in liste) * 30, 2),
        "zins_bisher": round(sum(e["zins_bisher"] for e in liste), 2),
        "mit_zins": sum(1 for e in liste if e["zins_tag"] > 0),
        "fahrzeuge": liste,
        "langsteher": [e for e in liste if e["nachlass"]],
    }


# --------------------------------------------------------------------------------- Herstellerbonus

def _staffeln(cfg: dict) -> list:
    aus = []
    for s in cfg.get("staffeln") or []:
        try:
            ab, prozent = int(s.get("ab")), float(s.get("prozent"))
        except (TypeError, ValueError):
            continue
        if ab > 0 and prozent >= 0:
            aus.append({"ab": ab, "prozent": prozent})
    return sorted(aus, key=lambda s: s["ab"])


def herstellerbonus(db, stichtag, konfiguration: list) -> list:
    """Je eingetragener Staffel (Hersteller + Jahr): gezählte Fahrzeuge aus dem Jahresblatt der Bestandsliste, dazu
    kommende Fahrzeuge aus der Finanzaufstellung mit Termin im Jahr (Schlüssel heißen weiter „vororder“); erreichte
    Stufe, fehlende Stück bis zur nächsten und der Bonus in Euro (Prozent auf den Einkauf netto)."""
    aus = []
    for cfg in konfiguration or []:
        hersteller, jahr = str(cfg.get("hersteller") or "").strip(), int(cfg.get("jahr") or 0)
        staffeln = _staffeln(cfg)
        if not hersteller or not jahr or not staffeln:
            continue
        fz = _eine(db, """SELECT COUNT(*) AS n, COALESCE(SUM(purchase_net),0) AS ek FROM vehicles
                          WHERE LOWER(brand) = LOWER(?) AND jahrgang = ?""", (hersteller, jahr))
        # Kommende Fahrzeuge aus der Finanzaufstellung mit Termin im Jahr – außer sie stehen mit ihrer Nummer schon
        # im Jahresblatt (dann sind sie oben schon gezählt)
        vo = _eine(db, """SELECT COUNT(*) AS n, COALESCE(SUM(COALESCE(k.ek_netto, k.betrag)),0) AS ek
                          FROM kommende_fahrzeuge k
                          WHERE LOWER(k.hersteller) = LOWER(?) AND strftime('%Y', k.termin_datum) = ?
                            AND NOT EXISTS (SELECT 1 FROM vehicles v WHERE v.internal_id = k.internal_id
                                            AND v.jahrgang = ?)""", (hersteller, str(jahr), jahr))
        anzahl, ek = fz["n"], fz["ek"]
        mit_vo, ek_vo = anzahl + vo["n"], ek + vo["ek"]
        schnitt = (ek_vo / mit_vo) if mit_vo else 0

        def stufe(n):
            erreicht = [s for s in staffeln if s["ab"] <= n]
            return erreicht[-1] if erreicht else None

        jetzt, mit = stufe(anzahl), stufe(mit_vo)
        naechste = next((s for s in staffeln if s["ab"] > mit_vo), None)
        bonus_mit = (mit["prozent"] if mit else 0) / 100 * ek_vo
        eintrag = {"id": cfg.get("id"), "hersteller": hersteller, "jahr": jahr, "staffeln": staffeln,
                   "notiz": cfg.get("notiz") or "", "anzahl": anzahl, "vororder": vo["n"], "mit_vororder": mit_vo,
                   "ek": round(ek, 2), "ek_mit_vororder": round(ek_vo, 2),
                   "stufe": jetzt, "stufe_mit_vororder": mit,
                   "bonus": round((jetzt["prozent"] if jetzt else 0) / 100 * ek, 2),
                   "bonus_mit_vororder": round(bonus_mit, 2), "naechste": None}
        if naechste:
            fehlen = naechste["ab"] - mit_vo
            bonus_dann = naechste["prozent"] / 100 * (ek_vo + fehlen * schnitt)
            eintrag["naechste"] = {**naechste, "fehlen": fehlen, "mehr_bonus": round(bonus_dann - bonus_mit, 2)}
        aus.append(eintrag)
    return sorted(aus, key=lambda e: (-e["jahr"], e["hersteller"]))
