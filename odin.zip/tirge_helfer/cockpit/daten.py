"""
Cockpit-Daten für die Oberfläche.

- Die Excel-Listen (Bestandsliste, Finanzaufstellung, Auslieferungsliste …) bleiben die Quelle. Welche Datei
  welche Liste ist, wird je Rechner einmal gewählt (die OneDrive-Pfade unterscheiden sich zwischen Windows und Mac).
- Beim Laden liest ODIN alle Listen in eine Datenbank im Arbeitsspeicher. Hat sich keine Datei geändert, bleibt das
  letzte Ergebnis stehen – so ist der Wechsel zwischen den Seiten sofort da.
- Was es nur in ODIN gibt (To-dos, Vorordern, geplante Ablösungen), liegt als JSON im Ordner „Fahrzeuge“: so sehen
  alle Rechner dieselben Einträge. Ohne diesen Ordner bleibt es auf diesem Rechner.
- Syscara ergänzt nur, was in der Bestandsliste leer ist (FIN, Modell, Modelljahr …). Die Excel-Liste hat Vorrang.
- Ist noch keine Liste eingerichtet, zeigt ODIN erfundene Beispieldaten; Änderungen daran bleiben im Speicher.
"""

import datetime as dt
import getpass
import json
import os
import re
import secrets
import sqlite3
import threading
import time

from . import db as cdb
from . import fahrzeugtypen

# Reihenfolge = Einleseordnung: die Bestandsliste zuerst, damit die anderen Listen ihre Fahrzeuge finden
LISTEN = [
    {"art": "bestandsliste", "name": "Bestandsliste", "ziel": "Bestand, Einkaufswerte, Verkäufe"},
    {"art": "finanzierungen", "name": "Finanzaufstellung", "ziel": "Einkaufsfinanzierung, Tilgungen, Zulassungsfristen"},
    {"art": "auslieferungen", "name": "Auslieferungsliste", "ziel": "Übergaben, Papiere, Bemerkungen, Einbauten"},
    {"art": "finanzplanung", "name": "Finanzplanung", "ziel": "Liquidität"},
    {"art": "provisionen", "name": "Provisionen", "ziel": "Provisionen"},
    {"art": "teilepreise", "name": "Teileliste", "ziel": "Teile & Montage, Artikelstamm"},
    {"art": "urlaubsplaner", "name": "Urlaubsplaner", "ziel": "Urlaub, wer fehlt"},
]
ARTEN = [l["art"] for l in LISTEN]
# Diese Listen hängen an keinem Fahrzeug: einmal gelesen, bleiben sie zwischengespeichert, bis sich die Datei ändert
UNABHAENGIG = {"teilepreise", "urlaubsplaner"}
EXCEL_ENDUNGEN = (".xlsx", ".xlsm")

SPEICHER_DATEI = "_ODIN-Cockpit.json"
SYSCARA_DATEI = "syscara-cockpit.json"
SYSCARA_ALTER = 20 * 3600            # einmal am Tag frisch aus Syscara (nur wenn ein Zugang gespeichert ist)

PRIORITAETEN = ("hoch", "normal", "niedrig")
VORORDER_STATUS = ("geplant", "bestellt", "geliefert", "storniert")
ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")


class CockpitFehler(Exception):
    """Meldung für Menschen – geht so an die Oberfläche."""


def _heute() -> str:
    return dt.date.today().isoformat()


def _datum_oder_none(wert, feld: str):
    if wert in (None, ""):
        return None
    wert = str(wert).strip()[:10]
    if not ISO_DATUM.fullmatch(wert):
        raise CockpitFehler(f"{feld}: bitte ein Datum wählen.")
    try:
        dt.date.fromisoformat(wert)
    except ValueError:
        raise CockpitFehler(f"{feld}: dieses Datum gibt es nicht.") from None
    return wert


def _benutzername() -> str:
    try:
        return getpass.getuser()
    except Exception:                               # kein Benutzername ermittelbar (selten, z. B. Dienstkonto)
        return ""


# ---------------- Speicher für To-dos, Vorordern und Ablösungen ----------------

LISTEN_IM_SPEICHER = ("todos", "vororder", "abloesungen", "fristen", "bonus", "vermerke")
OBJEKTE_IM_SPEICHER = ("scorecard", "einstellungen")


def _leerer_speicher() -> dict:
    return {"version": 1, "todos": [], "vororder": [], "abloesungen": [], "fristen": [], "bonus": [], "vermerke": [],
            "scorecard": {}, "einstellungen": {}}


def _vervollstaendigen(daten: dict) -> dict:
    """Ältere Stände (nur To-dos, Vorordern, Ablösungen) um die neuen Bereiche ergänzen."""
    voll = _leerer_speicher()
    if isinstance(daten, dict):
        for k in LISTEN_IM_SPEICHER:
            if isinstance(daten.get(k), list):
                voll[k] = [x for x in daten[k] if isinstance(x, dict)]
        for k in OBJEKTE_IM_SPEICHER:
            if isinstance(daten.get(k), dict):
                voll[k] = daten[k]
    return voll


class DateiSpeicher:
    """Eine JSON-Datei im Ordner „Fahrzeuge“ (oder im Einstellungsordner). Vor jeder Änderung frisch lesen,
    damit Einträge von einem anderen Rechner nicht überschrieben werden."""

    def __init__(self, pfad: str, lokal: bool):
        self.pfad = pfad
        self.lokal = lokal

    def stand(self):
        try:
            s = os.stat(self.pfad)
            return (s.st_mtime_ns, s.st_size)
        except OSError:
            return None

    def lade(self) -> dict:
        try:
            with open(self.pfad, encoding="utf-8") as f:
                daten = json.load(f)
        except FileNotFoundError:
            return _leerer_speicher()
        except (OSError, ValueError, RecursionError) as e:
            raise CockpitFehler(f"Die Datei „{os.path.basename(self.pfad)}“ ist nicht lesbar ({str(e)[:120]}). "
                                "Bitte prüfen, ob OneDrive gerade synchronisiert.") from None
        return _vervollstaendigen(daten)

    def schreibe(self, daten: dict):
        os.makedirs(os.path.dirname(self.pfad), exist_ok=True)
        tmp = f"{self.pfad}.{secrets.token_hex(4)}.tmp"     # nie derselbe Name für zwei Schreiber
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(daten, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.pfad)
        except OSError as e:
            raise CockpitFehler(f"Speichern hat nicht geklappt ({e}). Ist der Ordner „Fahrzeuge“ erreichbar?") from None


class SpeicherImArbeitsspeicher:
    """Für die Beispieldaten: Änderungen gelten bis zum Programmende."""

    lokal = True
    pfad = ""

    def __init__(self, daten: dict):
        self._daten = daten
        self._zaehler = 0

    def stand(self):
        return ("speicher", self._zaehler)

    def lade(self) -> dict:
        return _vervollstaendigen(json.loads(json.dumps(self._daten)))

    def schreibe(self, daten: dict):
        self._daten = json.loads(json.dumps(daten))
        self._zaehler += 1


def _naechste_id(liste) -> int:
    return max([x["id"] for x in liste if isinstance(x.get("id"), int) and not isinstance(x.get("id"), bool)] + [0]) + 1


# ---------------- Syscara-Ergänzung ----------------

def _syscara_auszug(fz: dict) -> dict:
    """Nur die Felder, die die Bestandsliste ergänzen dürfen."""
    kennung, modell = fz.get("identifier") or {}, fz.get("model") or {}
    t = lambda w: " ".join(str(w or "").split())
    jahr = modell.get("modelyear")
    try:
        jahr = int(jahr) if jahr not in (None, "", 0, "0") else None
    except (TypeError, ValueError):
        jahr = None
    return {"vin": t(kennung.get("vin")) or None, "serien_nr": t(kennung.get("serial")) or None,
            "bestell_nr": t(kennung.get("order")) or None, "brand": t(modell.get("producer")) or None,
            "model": t(" ".join(t(modell.get(k)) for k in ("series", "model", "model_add"))) or None,
            "model_year": jahr, "syscara": str(fz.get("id") or "") or None}


def syscara_ergaenze(conn, auszuege: dict) -> int:
    """Leere Felder der Fahrzeuge aus Syscara füllen. Gibt die Zahl der ergänzten Fahrzeuge zurück."""
    ergaenzt = 0
    for zeile in conn.execute("SELECT * FROM vehicles").fetchall():
        a = auszuege.get(cdb.normalize_internal_id(zeile["internal_id"]))
        if not a:
            continue
        neu = {k: v for k, v in a.items() if v not in (None, "") and zeile[k] in (None, "")}
        if not neu:
            continue
        conn.execute(f"UPDATE vehicles SET {', '.join(k + ' = ?' for k in neu)} WHERE id = ?",
                     [*neu.values(), zeile["id"]])
        ergaenzt += any(k != "syscara" for k in neu)
    return ergaenzt


# ---------------- Tabellen kopieren (für zwischengespeicherte Listen) ----------------

def _tabellen(conn) -> list:
    return [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]


def _auszug(conn) -> dict:
    """Alle Zeilen aller nicht leeren Tabellen (ohne die laufende id, die vergibt das Ziel neu)."""
    aus = {}
    for t in _tabellen(conn):
        spalten = [r[1] for r in conn.execute(f"PRAGMA table_info({t})") if r[1] != "id"]
        zeilen = conn.execute(f"SELECT {', '.join(spalten)} FROM {t}").fetchall()
        if zeilen:
            aus[t] = (spalten, [tuple(z) for z in zeilen])
    return aus


def _einspielen(conn, auszug: dict):
    for t, (spalten, zeilen) in auszug.items():
        conn.executemany(f"INSERT OR IGNORE INTO {t} ({', '.join(spalten)}) VALUES ({', '.join('?' * len(spalten))})",
                         zeilen)


# ---------------- Das Cockpit ----------------

class Cockpit:
    """Hält die eingelesenen Daten. 'einstellungen' ist ein dict-artiges Objekt, 'speichere(schluessel, wert)'
    schreibt eine Einstellung, 'zugang_laden()' liefert (benutzer, passwort) oder None."""

    def __init__(self, einstellungen, speichere, einstellungsordner: str, zugang_laden=None, protokoll=None,
                 urlaub=None, wissen=None):
        self.einstellungen = einstellungen
        self._speichere = speichere
        self.einstellungsordner = einstellungsordner
        self._zugang_laden = zugang_laden or (lambda: None)
        self._urlaub = urlaub                 # liefert das Urlaub-Objekt (genehmigte Anträge -> Abwesenheiten)
        self._wissen = wissen                 # liefert Abläufe und Anleitungen für den Fragen-Assistenten (oder None)
        self._protokoll = protokoll or (lambda text: None)
        self._sperre = threading.RLock()
        self._signatur = None
        self._daten = None
        self._berichte = {}                 # art -> (dateistand, bericht)
        self._auszuege = {}                 # art -> (dateistand, auszug) für unabhängige Listen
        self._demo_speicher = None
        self._syscara_laeuft = False
        self._syscara_fehler = ""
        self._syscara_versucht = 0.0
        self._conn = None                   # Datenbank des letzten Aufbaus – für den Fragen-Assistenten
        self._stichtag = ""
        self._cashback_cache = None         # (ordner, stand, gelesen) – die Aktionslisten nur neu lesen, wenn gespeichert
        self._schwebend = []                # Änderungen über Excel Online, bis OneDrive die Datei hierher gebracht hat
        self._geladen_um = 0.0              # time.time() des letzten Aufbaus – für „aktualisiert vor x s“
        self._live = None                   # Überwachung der Listen (aktionen/live.py), startet beim ersten Fragen
        self.bei_neuen_daten = None         # Rückruf (z. B. Fenster anstoßen), wenn die Überwachung neu eingelesen hat

    # ---------- Quellen ----------
    def quellen(self) -> dict:
        roh = self.einstellungen.get("cockpit_quellen") or {}
        return {k: v for k, v in roh.items() if k in ARTEN and isinstance(v, str) and v}

    def quelle_setzen(self, art: str, pfad: str):
        if art not in ARTEN:
            raise CockpitFehler("Unbekannte Liste.")
        q = self.quellen()
        if pfad:
            q[art] = pfad
        else:
            q.pop(art, None)
        self._speichere("cockpit_quellen", q)
        self._signatur = None

    def pruefe_datei(self, art: str, pfad: str) -> dict:
        """Vor dem Übernehmen einmal einlesen: passt die Datei überhaupt zu dieser Liste?"""
        if not pfad.lower().endswith(EXCEL_ENDUNGEN):
            raise CockpitFehler("Bitte eine Excel-Datei (.xlsx oder .xlsm) wählen. Alte .xls-Dateien bitte "
                                "in Excel einmal als .xlsx speichern.")
        from . import importer
        try:
            erkannt = importer.erkenne_art(pfad)
        except Exception:
            erkannt = None
        test = cdb.neue_db()
        if art in ("finanzierungen", "auslieferungen"):          # sie suchen ihre Fahrzeuge in der Bestandsliste
            bestand = self.quellen().get("bestandsliste")
            if bestand and os.path.exists(bestand):
                try:
                    importer.importiere(test, bestand, "bestandsliste", os.path.basename(bestand))
                except Exception:
                    pass
        bericht = importer.importiere(test, pfad, art, os.path.basename(pfad))
        name = next(l["name"] for l in LISTEN if l["art"] == art)
        if bericht.get("fehler"):
            raise CockpitFehler(f"{name}: {bericht['fehler']}")
        warnung = ""
        if erkannt and erkannt != art:
            anders = next((l["name"] for l in LISTEN if l["art"] == erkannt), erkannt)
            warnung = f" Achtung: die Datei sieht eher nach „{anders}“ aus."
        if not bericht.get("zeilen_geschrieben"):
            fehlen = ", ".join(bericht.get("spalten_fehlen") or [])
            raise CockpitFehler(f"{name}: in dieser Datei wurde nichts erkannt"
                                + (f" (es fehlen die Spalten {fehlen})" if fehlen else "") + "." + warnung)
        return {"meldung": f"{name} übernommen: {bericht['zeilen_geschrieben']} Zeilen eingelesen." + warnung,
                "fehler": bool(warnung)}

    # ---------- Speicher ----------
    def _speicher(self, beispiel: bool):
        if beispiel:
            return self._demo_speicher
        ordner = self.einstellungen.get("fahrzeuge_ordner") or ""
        if ordner and os.path.isdir(ordner):
            return DateiSpeicher(os.path.join(ordner, SPEICHER_DATEI), lokal=False)
        return DateiSpeicher(os.path.join(self.einstellungsordner, SPEICHER_DATEI), lokal=True)

    def _ist_beispiel(self) -> bool:
        return not self.quellen()

    # ---------- Laden ----------
    @staticmethod
    def _dateistand(pfad: str):
        try:
            s = os.stat(pfad)
            return (s.st_mtime_ns, s.st_size)
        except OSError:
            return None

    def _syscara_pfad(self) -> str:
        return os.path.join(self.einstellungsordner, SYSCARA_DATEI)

    def _syscara_cache(self) -> dict:
        try:
            with open(self._syscara_pfad(), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) and isinstance(d.get("fahrzeuge"), dict) else {}
        except (OSError, ValueError):
            return {}

    def daten(self, neu: bool = False) -> dict:
        with self._sperre:
            beispiel = self._ist_beispiel()
            if beispiel and self._demo_speicher is None:
                self._demo_speicher = self._demo_grundstock()
            speicher = self._speicher(beispiel)
            quellen = self.quellen()
            heute = _heute()
            signatur = (heute, beispiel, tuple(sorted((a, p, self._dateistand(p)) for a, p in quellen.items())),
                        speicher.pfad, speicher.stand(), self._dateistand(self._syscara_pfad()), self._urlaub_stand(),
                        self._cashback_stand())
            if neu:
                self._berichte.clear()
                self._auszuege.clear()
            if not neu and signatur == self._signatur and self._daten is not None:
                return self._daten
            self._daten = self._baue(beispiel, quellen, speicher, heute)
            self._signatur = signatur
        self._syscara_im_hintergrund()
        return self._daten

    def _demo_grundstock(self):
        """To-dos und Vorordern aus den Beispieldaten als Startstand für den Arbeitsspeicher."""
        from .demo import fuelle_demo
        conn = cdb.neue_db()
        fuelle_demo(conn, _heute())
        daten = _leerer_speicher()
        daten["todos"] = [dict(r) for r in conn.execute("SELECT * FROM todos ORDER BY id")]
        daten["vororder"] = [dict(r) for r in conn.execute("SELECT * FROM vororder ORDER BY id")]
        daten["abloesungen"] = []
        daten["fristen"], daten["bonus"] = fuehrung_demo(_heute())
        from .demo import TYP_ZUORDNUNG
        daten["einstellungen"] = {fahrzeugtypen.SCHLUESSEL: dict(TYP_ZUORDNUNG)}
        return SpeicherImArbeitsspeicher(daten)

    def _importiere(self, conn, art: str, pfad: str) -> dict:
        stand = self._dateistand(pfad)
        name = os.path.basename(pfad)
        if stand is None:
            return {"art": art, "fehler": "Datei nicht gefunden – liegt sie noch an diesem Ort, und ist OneDrive "
                                          "gestartet?", "vorhanden": False}
        from . import importer
        if art in UNABHAENGIG:
            gemerkt = self._auszuege.get(art)
            if gemerkt and gemerkt[0] == (pfad, stand):
                _einspielen(conn, gemerkt[1])
                return self._berichte[art][1]
            eigene = cdb.neue_db()
            bericht = self._sicher_importieren(importer, eigene, pfad, art, name)
            auszug = _auszug(eigene)
            eigene.close()
            _einspielen(conn, auszug)
            if not bericht.get("fehler"):
                self._auszuege[art] = ((pfad, stand), auszug)
        else:
            bericht = self._sicher_importieren(importer, conn, pfad, art, name)
        bericht["vorhanden"] = True
        self._berichte[art] = ((pfad, stand), bericht)
        return bericht

    def _sicher_importieren(self, importer, conn, pfad, art, name) -> dict:
        try:
            return dict(importer.importiere(conn, pfad, art, name))
        except PermissionError:
            return {"art": art, "fehler": "Die Datei ist gerade gesperrt (z. B. von OneDrive). Gleich nochmal versuchen."}
        except Exception as e:                  # eine kaputte Liste darf die anderen nicht aufhalten
            self._protokoll(f"Cockpit: {name} ({art}) nicht lesbar: {e!r}")
            return {"art": art, "fehler": f"Nicht lesbar: {e}"}

    def _baue(self, beispiel: bool, quellen: dict, speicher, heute: str) -> dict:
        from .export import daten_fuer_oberflaeche
        conn = cdb.neue_db()
        berichte = {}
        syscara_info = {"angemeldet": bool(self._zugang_benutzer()), "benutzer": self._zugang_benutzer(),
                        "stand": "", "ergaenzt": 0, "fehler": self._syscara_fehler}
        if beispiel:
            from .demo import fuelle_demo
            fuelle_demo(conn, heute)
        else:
            for art in ARTEN:
                if art in quellen:
                    berichte[art] = self._importiere(conn, art, quellen[art])
            cache = self._syscara_cache()
            if cache.get("fahrzeuge"):
                syscara_info["ergaenzt"] = syscara_ergaenze(conn, cache["fahrzeuge"])
                syscara_info["stand"] = cache.get("stand_text", "")
            self._schwebend_anwenden(conn)
        eigene = speicher.lade()
        self._eigene_einspielen(conn, eigene, ersetzen=beispiel)
        zuordnung = fahrzeugtypen.zuordnung_lesen(eigene.get("einstellungen"))
        fahrzeugtypen.anwenden(conn, zuordnung)
        if not beispiel:
            self._urlaub_einspielen(conn, heute)
        cashback = self._cashback(conn, heute, beispiel, eigene)
        conn.commit()

        d = daten_fuer_oberflaeche(conn, heute)
        d["fahrzeugtypen"] = fahrzeugtypen.uebersicht(conn, zuordnung)
        from .assistent import beispielfragen
        d["beispielfragen"] = beispielfragen(conn)
        if self._conn is not None:
            self._conn.close()
        self._conn, self._stichtag = conn, heute
        d["quelle"] = "beispiel" if beispiel else "excel"
        d["stichtag"] = d.get("stichtag") or heute
        d["abloesungen"] = [{"internal_id": a.get("vehicle_internal_id"), "datum": a.get("geplant_am")}
                            for a in eigene["abloesungen"] if not a.get("erledigt")]
        d["quellen"] = [self._quelle_info(l, quellen.get(l["art"]), berichte.get(l["art"])) for l in LISTEN]
        d["syscara"] = syscara_info
        d.update(self._fuehrung(conn, heute, eigene))
        d["cashback"] = cashback
        d["speicher"] = {"lokal": speicher.lokal, "pfad": speicher.pfad}
        d["geladen"] = dt.datetime.now().strftime("%d.%m. %H:%M")
        self._geladen_um = time.time()
        d["live"] = {"version": self._live.version if self._live else 0}
        return d

    def _urlaub_ordner(self):
        try:
            u = self._urlaub() if self._urlaub else None
            return u._ordner() if u else ""
        except Exception:
            return ""

    def _urlaub_stand(self):
        """Änderungsstand der Urlaubsanträge (neuester Zeitstempel), damit genehmigter Urlaub sofort zählt."""
        ordner = self._urlaub_ordner()
        if not ordner or not os.path.isdir(ordner):
            return None
        neueste = 0
        for wurzel, _, dateien in os.walk(ordner):
            for d in dateien:
                try:
                    neueste = max(neueste, os.stat(os.path.join(wurzel, d)).st_mtime_ns)
                except OSError:
                    pass
        return neueste

    def _urlaub_einspielen(self, conn, heute: str):
        """Genehmigte Urlaubsanträge (dieses und nächstes Jahr) als Abwesenheiten; Personen mit Bereich kommen in
        die Besetzung, damit „Heute & Woche“ sie kennt. Excel-Planer und Anträge ergänzen sich."""
        if not self._urlaub:
            return
        try:
            u = self._urlaub()
            jahr = int(heute[:4])
            zeilen = [z for j in (jahr, jahr + 1) for z in u.abwesenheiten(j)]
            minuten = cdb.parameter().get("minuten_pro_tag", 480)
        except Exception as e:                 # Urlaub darf das Cockpit nie aufhalten
            self._protokoll(f"Cockpit: Urlaubsanträge nicht lesbar: {e!r}")
            return
        bereiche = {}
        for z in zeilen:
            bereiche.setdefault(z.get("mitarbeiter"), z.get("bereich"))
        for name, bereich in bereiche.items():
            if name and bereich:                # ohne Bereich (z. B. Büro ohne Eintrag) zählt niemand zur Werkstatt
                conn.execute("INSERT OR IGNORE INTO mitarbeiter (name, bereich, minuten_pro_tag, auslieferung, aktiv) "
                             "VALUES (?, ?, ?, 0, 1)", (name, bereich, minuten))
        conn.executemany("INSERT OR IGNORE INTO abwesenheiten (mitarbeiter, datum, art, bereich, source_file) "
                         "VALUES (?, ?, ?, ?, 'ODIN-Urlaubsanträge')",
                         [(z.get("mitarbeiter"), z.get("datum"), z.get("art") or "Urlaub", z.get("bereich"))
                          for z in zeilen if z.get("mitarbeiter") and z.get("datum")])

    @staticmethod
    def _eigene_einspielen(conn, eigene: dict, ersetzen: bool):
        """To-dos, Vorordern und Ablösungen aus ODINs Speicher in die Datenbank."""
        for f in eigene.get("fristen", []):
            if f.get("faellig_am") and not f.get("erledigt"):
                try:
                    conn.execute("INSERT INTO betriebsfristen (id, titel, kategorie, faellig_am, verantwortlich) "
                                 "VALUES (?, ?, ?, ?, ?)", (f.get("id"), f.get("titel") or "Frist", f.get("kategorie"),
                                                            f.get("faellig_am"), f.get("verantwortlich")))
                except sqlite3.Error:
                    pass
        # Vermerke aus „In ODIN arbeiten“ (Aktionen), für die es in den Excel-Listen keine Spalte gibt
        for v in eigene.get("vermerke", []):
            try:
                if v.get("art") == "zulassung_erledigt" and v.get("bezug"):
                    conn.execute("DELETE FROM zulassungsfristen WHERE vehicle_internal_id = ?", (v["bezug"],))
                elif v.get("art") == "tilgung_bezahlt" and v.get("bezug") and v.get("faellig_am"):
                    conn.execute("UPDATE tilgungen SET bezahlt_am = COALESCE(bezahlt_am, ?) WHERE vehicle_internal_id = ? "
                                 "AND faellig_am = ?", (v.get("datum"), v["bezug"], v["faellig_am"]))
            except sqlite3.Error:
                pass
        if ersetzen:                                         # Beispieldaten: der Arbeitsspeicher ist maßgeblich
            conn.execute("DELETE FROM todos")
            conn.execute("DELETE FROM vororder")
            conn.execute("DELETE FROM abloesungen")
        felder = {
            "todos": ["id", "text", "bereich", "bezug_id", "faellig_am", "prioritaet", "erledigt", "erledigt_am",
                      "angelegt_von", "angelegt_am"],
            "vororder": ["id", "bezeichnung", "hersteller", "bank", "kategorie", "anzahl", "ek_netto", "liefertermin",
                         "status", "internal_id", "bemerkung", "angelegt_am"],
            "abloesungen": ["id", "vehicle_internal_id", "bank", "geplant_am", "betrag", "grund", "erledigt",
                            "angelegt_am"],
        }
        for tabelle, spalten in felder.items():
            for eintrag in eigene.get(tabelle, []):
                werte = [eintrag.get(s) for s in spalten]
                if tabelle == "abloesungen":                    # Bank und Betrag aus der Finanzierung ergänzen
                    fin = conn.execute("SELECT bank, financed_amount FROM financings WHERE vehicle_internal_id = ? "
                                       "AND status = 'offen' LIMIT 1", (eintrag.get("vehicle_internal_id"),)).fetchone()
                    if fin:
                        werte[2] = werte[2] or fin["bank"]
                        werte[4] = werte[4] if werte[4] is not None else fin["financed_amount"]
                try:
                    conn.execute(f"INSERT OR REPLACE INTO {tabelle} ({', '.join(spalten)}) "
                                 f"VALUES ({', '.join('?' * len(spalten))})", werte)
                except sqlite3.Error:
                    pass                                         # ein kaputter Eintrag (z. B. von Hand bearbeitet)
                if tabelle == "abloesungen" and eintrag.get("erledigt") and eintrag.get("vehicle_internal_id"):
                    # in ODIN als abgelöst vermerkt: zählt nicht mehr als offene Finanzierung (bis die Liste nachzieht)
                    try:
                        conn.execute("UPDATE financings SET status = 'abgelöst' WHERE vehicle_internal_id = ? AND "
                                     "COALESCE(status,'offen') = 'offen'", (eintrag["vehicle_internal_id"],))
                    except sqlite3.Error:
                        pass

    # ---------- „In ODIN arbeiten“: Zugriff für die Aktionen, sofort sichtbare Änderungen, Überwachung ----------
    def mit_daten(self, arbeit):
        """arbeit(conn, stichtag, beispiel) mit der aktuellen Datenbank – unter der Sperre, damit sie währenddessen
        nicht neu aufgebaut (und geschlossen) wird."""
        with self._sperre:
            self.daten()
            return arbeit(self._conn, self._stichtag, self._ist_beispiel())

    def neu_laden(self):
        """Nach einer Aktion: sofort neu einlesen (geänderte Datei bzw. ODIN-Speicher)."""
        with self._sperre:
            self._signatur = None
            self._berichte.pop("teilepreise", None)
            self._auszuege.pop("teilepreise", None)
            d = self.daten()
        if self._live is not None:
            self._live.anstossen()
        return d

    def schwebend_dazu(self, pfad: str, overlay: list, sekunden: int = 900):
        """Über Excel Online geändert: ODIN zeigt die Änderung sofort, bis die synchronisierte Datei sich ändert
        (dann steht sie dort drin) – höchstens 'sekunden' lang."""
        with self._sperre:
            self._schwebend.append({"pfad": pfad, "stand": self._dateistand(pfad), "bis": time.time() + sekunden,
                                    "overlay": list(overlay or [])})
            self._signatur = None

    def schwebend_weg(self, pfad: str):
        with self._sperre:
            self._schwebend = [s for s in self._schwebend if s["pfad"] != pfad]
            self._signatur = None

    _BEZEICHNER = re.compile(r"[a-z_]{2,40}")

    def _schwebend_anwenden(self, conn):
        jetzt = time.time()
        self._schwebend = [s for s in self._schwebend if s["bis"] > jetzt and self._dateistand(s["pfad"]) == s["stand"]]
        for s in self._schwebend:
            for o in s["overlay"]:
                tabelle, setze, wo = o.get("tabelle"), o.get("setze") or {}, o.get("wo") or {}
                namen = [tabelle, *setze, *wo]
                if not setze or not wo or not all(isinstance(n, str) and self._BEZEICHNER.fullmatch(n) for n in namen):
                    continue
                try:
                    conn.execute(f"UPDATE {tabelle} SET " + ", ".join(f"{k} = ?" for k in setze) + " WHERE " +
                                 " AND ".join(f"{k} = ?" for k in wo), [*setze.values(), *wo.values()])
                except sqlite3.Error:
                    pass

    def quellen_stand(self):
        """Fingerabdruck aller eingebundenen Dateien (Listen, ODIN-Speicher, Cashback) – für die Überwachung."""
        quellen = self.quellen()
        teile = [(a, p, self._dateistand(p)) for a, p in sorted(quellen.items())]
        try:
            sp = self._speicher(self._ist_beispiel())
            teile.append(("speicher", sp.pfad if sp else "", sp.stand() if sp else None))
        except Exception:                                   # noqa: BLE001
            pass
        teile.append(("cashback", self._cashback_stand()))
        teile.append(("urlaub", self._urlaub_stand()))
        return tuple(teile)

    def live_stand(self) -> dict:
        """Für die Oberfläche (alle paar Sekunden): Version der Daten und wie alt sie sind. Startet die Überwachung."""
        if self._live is None:
            from ..aktionen.live import Ueberwachung
            self._live = Ueberwachung(self, protokoll=self._protokoll)
            self._live.start()
        return self._live.stand()

    @staticmethod
    def _quelle_info(liste: dict, pfad, bericht) -> dict:
        info = {**liste, "pfad": pfad or "", "datei": os.path.basename(pfad) if pfad else "", "vorhanden": False,
                "stand": "", "uhrzeit": "", "gelesen": None, "geschrieben": None, "hinweise": [], "verstanden": [],
                "fehler": ""}
        if not pfad:
            info["leer"] = "Noch keine Datei gewählt."
            return info
        try:
            s = os.stat(pfad)
            info["vorhanden"] = True
            zeit = dt.datetime.fromtimestamp(s.st_mtime)
            info["stand"], info["uhrzeit"] = zeit.date().isoformat(), zeit.strftime("%H:%M")
        except OSError:
            pass
        if bericht:
            info["fehler"] = bericht.get("fehler") or ""
            info["gelesen"] = bericht.get("zeilen_gelesen")
            info["geschrieben"] = bericht.get("zeilen_geschrieben")
            # Der Bericht mischt „was verstanden wurde“ (Kopfzeile, Zahl der Zeilen) mit echten Hinweisen zu
            # einzelnen Zeilen; technische Zeilen („Nebenbei: … in vehicles“) bleiben weg.
            hinweise = [f"Spalte fehlt: {s}" for s in bericht.get("spalten_fehlen") or []]
            for h in (str(x) for x in bericht.get("hinweise") or []):
                if h.startswith("Nebenbei:"):
                    continue
                if re.search(r"Zeile \d+:|fehlt|unklar|nicht erkannt|übersprungen|zweifel|nicht gelesen", h, re.I) \
                        and not re.search(r": \d+ Datenzeilen", h):
                    hinweise.append(h)
                else:
                    info["verstanden"].append(h)
            info["hinweise"] = hinweise
        return info

    # ---------- Fragen-Assistent ----------
    ZIELE = {"fahrzeug_details": "#/fahrzeug/{id}", "bestand_zaehlen": "#/bestand", "bestandsliste": "#/bestand",
             "zinsfrei_ablauf": "#/finanzierung", "tilgungen": "#/finanzierung", "tilgungen_monat": "#/finanzierung",
             "liquiditaet": "#/liquiditaet", "provisionen": "#/provisionen", "auslieferungen": "#/auslieferungen",
             "uebergabe_status": "#/auslieferungen", "teile_und_montage": "#/teile", "teile_fuer_fahrzeug": "#/teile",
             "zulassungsfristen": "#/finanzierung", "kennzahlen": "#/uebersicht",
             "tagesuebersicht": "#/heute"}

    def frage(self, text: str, kontext=None, finanzen=False) -> dict:
        """Frage an das Regelwerk (lokal, ohne fremden Dienst). Nicht verstandene Fragen werden notiert, damit
        das Regelwerk gezielt erweitert werden kann. 'finanzen': darf die fragende Person Finanzzahlen sehen?
        Das entscheidet der Aufrufer (app.py) aus assistent_finanzen() und der angemeldeten Person."""
        from .assistent import beantworte, finde_fahrzeug_id
        with self._sperre:
            if self._conn is None:
                self.daten()
            antwort = beantworte(self._conn, str(text or "")[:500], self._stichtag, kontext, wissen=self._wissen,
                                 finanzen=finanzen is True)
            ziel = antwort["ziel"] if "ziel" in antwort else self.ZIELE.get(antwort.get("werkzeug"), "")
            if "{id}" in ziel:
                fid = finde_fahrzeug_id(self._conn, str(text or ""))
                ziel = ziel.replace("{id}", fid) if fid else ""
        if antwort.get("werkzeug") == "hilfe" and text and str(text).strip():
            self._unverstanden_merken(str(text).strip())
        return {"text": antwort.get("text", ""), "werkzeug": antwort.get("werkzeug", ""), "ziel": ziel,
                "rueckfrage": antwort.get("rueckfrage"), "kundentext": antwort.get("kundentext"),
                "kundentext_hinweis": antwort.get("kundentext_hinweis")}

    def _unverstanden_merken(self, text: str, gemeldet: bool = False):
        """Nicht verstandene Frage notieren. 'gemeldet': jemand hat sie mit „Lücke melden“ ausdrücklich gemeldet –
        dann wird der letzte Eintrag mit derselben Frage markiert statt die Frage doppelt zu zählen. Angezeigt wird
        die Liste (bereinigt um mögliche Kundendaten) unter Wissen & Einarbeitung → Offene Fragen."""
        # im Ordner „Fahrzeuge“, damit die Fragen aller Rechner an einer Stelle landen
        wurzel = self.einstellungen.get("fahrzeuge_ordner") or ""
        ordner = os.path.join(wurzel, "_ODIN") if wurzel and os.path.isdir(wurzel) else self.einstellungsordner
        pfad = os.path.join(ordner, "fragen-unverstanden.json")
        try:
            with open(pfad, encoding="utf-8") as f:
                liste = json.load(f)
            if not isinstance(liste, list):
                liste = []
        except (OSError, ValueError):
            liste = []
        text = text[:500]
        letzter = next((e for e in reversed(liste[-50:]) if isinstance(e, dict) and e.get("frage") == text), None) \
            if gemeldet else None
        if letzter is not None:
            letzter["gemeldet"] = True
        else:
            liste.append({"am": dt.datetime.now().isoformat(timespec="seconds"), "frage": text,
                          **({"gemeldet": True} if gemeldet else {})})
        try:
            os.makedirs(ordner, exist_ok=True)
            with open(pfad, "w", encoding="utf-8") as f:
                json.dump(liste[-500:], f, ensure_ascii=False, indent=1)
        except OSError:
            pass

    def luecke_melden(self, text) -> dict:
        """„Lücke melden“ im Assistenten: die Frage für die Verantwortlichen sichtbar markieren."""
        text = str(text or "").strip()
        if not text:
            return {"ok": False, "fehler": "Keine Frage zum Melden."}
        self._unverstanden_merken(text, gemeldet=True)
        return {"ok": True}

    # ---------- Syscara ----------
    def _zugang_benutzer(self) -> str:
        try:
            z = self._zugang_laden()
        except Exception:
            return ""
        return z[0] if z else ""

    def syscara_abgleich(self) -> dict:
        """Alle Fahrzeuge aus Syscara holen und die Ergänzungsdaten zwischenspeichern."""
        from .. import syscara_api
        z = self._zugang_laden()
        if not z:
            raise CockpitFehler("Kein Syscara-Zugang gespeichert.")
        antwort = syscara_api.hole("/sale/vehicles/", {}, *z)
        fahrzeuge = {}
        for fz in syscara_api._liste(antwort):
            kennung = syscara_api._norm_id(syscara_api._kennung(fz))
            if kennung:
                fahrzeuge[cdb.normalize_internal_id(kennung)] = _syscara_auszug(fz)
        jetzt = dt.datetime.now()
        os.makedirs(self.einstellungsordner, exist_ok=True)
        tmp = self._syscara_pfad() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"stand": jetzt.isoformat(timespec="seconds"), "stand_text": jetzt.strftime("%d.%m.%Y %H:%M"),
                       "fahrzeuge": fahrzeuge}, f, ensure_ascii=False)
        os.replace(tmp, self._syscara_pfad())
        self._syscara_fehler = ""
        with self._sperre:
            self._signatur = None
        return {"meldung": f"Syscara: {len(fahrzeuge)} Fahrzeuge abgeglichen.", "fehler": False}

    def _syscara_im_hintergrund(self):
        """Einmal am Tag still nachholen – nur mit gespeichertem Zugang und echten Listen."""
        if self._syscara_laeuft or self._ist_beispiel() or not self._zugang_benutzer():
            return
        stand = self._dateistand(self._syscara_pfad())
        if stand and time.time() - stand[0] / 1e9 < SYSCARA_ALTER:
            return
        if self._syscara_fehler and self._syscara_versucht > time.time() - 3600:
            return                                       # nach einem Fehler höchstens stündlich erneut

        def lauf():
            try:
                self.syscara_abgleich()
            except Exception as e:
                self._syscara_fehler = f"Syscara-Abgleich nicht möglich: {e}"
                self._protokoll(self._syscara_fehler)
            finally:
                self._syscara_laeuft = False
        self._syscara_laeuft = True
        self._syscara_versucht = time.time()
        threading.Thread(target=lauf, daemon=True).start()

    # ---------- Änderungen (To-dos, Vorordern, Ablösungen) ----------
    def _aendere(self, aenderung):
        with self._sperre:
            beispiel = self._ist_beispiel()
            if beispiel and self._demo_speicher is None:
                self._demo_speicher = self._demo_grundstock()
            speicher = self._speicher(beispiel)
            daten = speicher.lade()
            ergebnis = aenderung(daten)
            speicher.schreibe(daten)
            self._signatur = None
            return ergebnis

    def todo_anlegen(self, eingabe: dict) -> dict:
        text = " ".join(str((eingabe or {}).get("text") or "").split())
        if not text:
            raise CockpitFehler("Bitte die Aufgabe in ein paar Worten beschreiben.")
        if len(text) > 500:
            raise CockpitFehler("Die Aufgabe ist zu lang (höchstens 500 Zeichen).")
        prio = eingabe.get("prioritaet") if eingabe.get("prioritaet") in PRIORITAETEN else "normal"
        faellig = _datum_oder_none(eingabe.get("faellig_am"), "Fällig am")
        bereich = " ".join(str(eingabe.get("bereich") or "Allgemein").split())[:40] or "Allgemein"
        bezug = cdb.normalize_internal_id(eingabe["bezug_id"]) if eingabe.get("bezug_id") else None

        def neu(d):
            eintrag = {"id": _naechste_id(d["todos"]), "text": text, "bereich": bereich, "bezug_id": bezug,
                       "faellig_am": faellig, "prioritaet": prio, "erledigt": 0, "erledigt_am": None,
                       "angelegt_von": _benutzername(), "angelegt_am": _heute()}
            d["todos"].append(eintrag)
            return {"ok": True, "id": eintrag["id"]}
        return self._aendere(neu)

    def todo_umschalten(self, todo_id) -> dict:
        def um(d):
            t = next((x for x in d["todos"] if x.get("id") == int(todo_id)), None)
            if not t:
                raise CockpitFehler("Diese Aufgabe gibt es nicht mehr – vielleicht auf einem anderen Rechner gelöscht.")
            t["erledigt"] = 0 if t.get("erledigt") else 1
            t["erledigt_am"] = _heute() if t["erledigt"] else None
            return {"ok": True}
        return self._aendere(um)

    def todo_loeschen(self, todo_id) -> dict:
        def weg(d):
            d["todos"] = [x for x in d["todos"] if x.get("id") != int(todo_id)]
            return {"ok": True}
        return self._aendere(weg)

    def vororder_anlegen(self, eingabe: dict) -> dict:
        e = eingabe or {}
        bezeichnung = " ".join(str(e.get("bezeichnung") or "").split())[:120]
        if not bezeichnung:
            raise CockpitFehler("Bitte eine Bezeichnung eingeben (z. B. „Lineo T 4 Modelljahr 2027“).")
        hersteller = " ".join(str(e.get("hersteller") or "").split())[:40]
        bank = " ".join(str(e.get("bank") or "").split())[:60]
        if not hersteller or not bank:
            raise CockpitFehler("Bitte Hersteller und Bank wählen.")
        try:
            anzahl = int(e.get("anzahl") or 1)
            ek = float(e.get("ek_netto") or 0)
        except (TypeError, ValueError):
            raise CockpitFehler("Anzahl und Einkaufspreis bitte als Zahl.") from None
        if not 1 <= anzahl <= 500 or ek < 0:
            raise CockpitFehler("Anzahl (1–500) und Einkaufspreis (≥ 0) prüfen.")
        termin = _datum_oder_none(e.get("liefertermin"), "Liefertermin")
        if not termin:
            raise CockpitFehler("Bitte den Liefertermin angeben.")
        status = e.get("status") if e.get("status") in VORORDER_STATUS else "geplant"

        def neu(d):
            eintrag = {"id": _naechste_id(d["vororder"]), "bezeichnung": bezeichnung, "hersteller": hersteller,
                       "bank": bank, "kategorie": e.get("kategorie") or None, "anzahl": anzahl, "ek_netto": ek,
                       "liefertermin": termin, "status": status,
                       "internal_id": cdb.normalize_internal_id(e["internal_id"]) if e.get("internal_id") else None,
                       "bemerkung": (str(e.get("bemerkung") or "").strip()[:300] or None), "angelegt_am": _heute()}
            d["vororder"].append(eintrag)
            return {"ok": True, "id": eintrag["id"]}
        return self._aendere(neu)

    def vororder_loeschen(self, vororder_id) -> dict:
        def weg(d):
            d["vororder"] = [x for x in d["vororder"] if x.get("id") != int(vororder_id)]
            return {"ok": True}
        return self._aendere(weg)

    def abloesung_planen(self, internal_id: str, datum: str) -> dict:
        iid = cdb.normalize_internal_id(internal_id or "")
        tag = _datum_oder_none(datum, "Ablösedatum")
        if not iid or not tag:
            raise CockpitFehler("Fahrzeug und Datum fehlen.")

        def plan(d):
            vorhanden = next((x for x in d["abloesungen"] if x.get("vehicle_internal_id") == iid and not x.get("erledigt")), None)
            if vorhanden:
                vorhanden["geplant_am"] = tag
            else:
                d["abloesungen"].append({"id": _naechste_id(d["abloesungen"]), "vehicle_internal_id": iid, "bank": None,
                                         "geplant_am": tag, "betrag": None, "grund": "in ODIN geplant",
                                         "erledigt": 0, "angelegt_am": _heute()})
            return {"ok": True}
        return self._aendere(plan)

    def abloesung_loeschen(self, internal_id: str) -> dict:
        iid = cdb.normalize_internal_id(internal_id or "")

        def weg(d):
            d["abloesungen"] = [x for x in d["abloesungen"] if x.get("vehicle_internal_id") != iid]
            return {"ok": True}
        return self._aendere(weg)

    # ---------------- Führung: Scorecard, Fristen, Bonus, Einstellungen ----------------
    # ---------- Cashback-Aktionen ----------
    def cashback_ordner(self) -> str:
        wert = self.einstellungen.get("cashback_ordner") or ""
        return wert if isinstance(wert, str) else ""

    def _cashback_stand(self):
        from . import cashback as cb
        ordner = self.cashback_ordner()
        return (ordner, cb.stand(ordner)) if ordner else None

    def _cashback_lesen(self, ordner: str) -> dict:
        from . import cashback as cb
        stand = cb.stand(ordner)
        if self._cashback_cache and self._cashback_cache[:2] == (ordner, stand):
            return self._cashback_cache[2]
        gelesen = cb.lies_ordner(ordner, self._protokoll)
        self._cashback_cache = (ordner, stand, gelesen)
        return gelesen

    def _cashback(self, conn, heute: str, beispiel: bool, eigene: dict) -> dict:
        """Cashback-Aktionen auswerten und ihre Termine für „Heute & Woche“ in die Datenbank legen. Ein Fehler hält
        das Cockpit nie auf – die Seite zeigt ihn dann."""
        from . import cashback as cb
        ordner = self.cashback_ordner()
        verantwortlich = (eigene.get("einstellungen") or {}).get("cashback_verantwortlich") or ""
        try:
            if ordner:
                aus = cb.auswerten(self._cashback_lesen(ordner), heute, ordner)
            elif beispiel:
                aus = {**cb.auswerten(cb.demo(heute), heute, ""), "beispiel": True}
            else:
                aus = cb.auswerten({}, heute, "")
        except cb.CashbackFehler as e:
            aus = {**cb.auswerten({}, heute, ordner), "fehler": str(e)}
        except Exception as e:                              # noqa: BLE001
            self._protokoll(f"Cockpit: Cashback nicht lesbar: {e!r}")
            aus = {**cb.auswerten({}, heute, ordner), "fehler": "Die Cashback-Listen ließen sich nicht lesen."}
        aus["verantwortlich"] = verantwortlich
        for t in cb.termine(aus):
            if verantwortlich:
                t["text"] = t["text"] + " · " + verantwortlich
            try:
                conn.execute("INSERT INTO cashback_termine (datum, titel, text, ton, betrag) VALUES (?, ?, ?, ?, ?)",
                             (t["datum"], t["titel"], t["text"], t["ton"], t["betrag"]))
            except sqlite3.Error:
                pass
        return aus

    def cashback_ordner_setzen(self, ordner: str) -> dict:
        """Ordner mit den Aktionslisten übernehmen – vorher einmal lesen: liegt dort überhaupt eine Liste?"""
        from . import cashback as cb
        if not ordner:
            self._speichere("cashback_ordner", "")
            self._cashback_cache = None
            self._signatur = None
            return {"ok": True, "meldung": "Cashback-Ordner entfernt."}
        try:
            gelesen = cb.lies_ordner(ordner, self._protokoll)
        except cb.CashbackFehler as e:
            raise CockpitFehler(str(e)) from None
        if not gelesen["listen"]:
            raise CockpitFehler("In diesem Ordner liegt keine Aktionsliste (Blatt „Aktionen JJJJ“ mit Hersteller). "
                                "Bitte den Ordner „GUTSCHRIFTEN Cashback Aktionen“ wählen.")
        self._speichere("cashback_ordner", ordner)
        self._cashback_cache = None
        self._signatur = None
        namen = ", ".join(l["hersteller"] for l in gelesen["listen"])
        vorgaenge = sum(len(l["vorgaenge"]) for l in gelesen["listen"])
        return {"ok": True, "meldung": f"Cashback übernommen: {namen} – {vorgaenge} Vorgänge."}

    # ---------- Wer darf Finanzzahlen im Assistenten sehen? ----------
    # Bis es eine Anmeldung mit Rechten gibt, ein einfacher Schutz: eine Liste von Personen-IDs (Projekte) im
    # gemeinsamen Speicher. Ist sie leer, darf jede Person am Rechner sie setzen; sonst nur, wer selbst darin steht.
    # Wie die Microsoft-Anmeldung immer im echten Speicher, auch solange nur Beispieldaten laufen.
    def assistent_finanzen(self) -> list:
        """Personen-IDs, für die der Assistent Finanzfragen beantwortet. Nicht lesbar: leere Liste."""
        with self._sperre:
            try:
                wert = (self._speicher(False).lade().get("einstellungen") or {}).get("assistent_finanzen")
            except CockpitFehler:
                return []
        return [str(x) for x in wert if isinstance(x, str) and x] if isinstance(wert, list) else []

    def assistent_finanzen_setzen(self, personen, ich: str, bekannte) -> dict:
        """Liste ersetzen. 'ich' ist die Person am Rechner, 'bekannte' alle Personen-IDs aus den Projekten."""
        if not isinstance(personen, list) or len(personen) > 100:
            raise CockpitFehler("Bitte eine Liste von Personen übergeben.")
        bekannte = set(bekannte or [])
        neu = list(dict.fromkeys(str(p) for p in personen if isinstance(p, str)))
        if any(p not in bekannte for p in neu):
            raise CockpitFehler("Diese Person gibt es nicht.")
        if not ich:
            raise CockpitFehler("Bitte zuerst unter „Projekte“ auswählen, wer du bist.")

        with self._sperre:
            speicher = self._speicher(False)
            daten = speicher.lade()
            alt = daten["einstellungen"].get("assistent_finanzen")
            alt = [x for x in alt if isinstance(x, str)] if isinstance(alt, list) else []
            if alt and ich not in alt:
                raise CockpitFehler("Das dürfen nur Personen ändern, die selbst schon freigegeben sind.")
            daten["einstellungen"] = {**daten["einstellungen"], "assistent_finanzen": neu}
            speicher.schreibe(daten)
            self._signatur = None
            return {"ok": True, "personen": neu}

    def cashback_verantwortlich(self, name) -> dict:
        """Wer sich um die Gutschriften kümmert – steht bei den Terminen in „Heute & Woche“."""
        name = " ".join(str(name or "").split())[:40]

        def setze(d):
            d["einstellungen"] = {**d["einstellungen"], "cashback_verantwortlich": name}
            return {"ok": True}
        return self._aendere(setze)

    def fahrzeugtyp_zuordnen(self, alt, neu) -> dict:
        """Bezeichnung aus der Teileliste einem der festen Fahrzeugtypen zuordnen (leerer Typ: Zuordnung entfernen).
        Gilt für alle Rechner (gemeinsamer Speicher). Rechte gibt es noch keine – im Browser ist es gesperrt."""
        if not isinstance(alt, str) or not isinstance(neu, str):
            raise CockpitFehler("Unbekannte Bezeichnung.")

        def setze(d):
            try:
                d["einstellungen"] = fahrzeugtypen.zuordnung_setzen(d["einstellungen"], alt, neu)
            except ValueError as e:
                raise CockpitFehler(str(e)) from None
            return {"ok": True}
        return self._aendere(setze)

    # ---------- Microsoft-Anmeldung: App-Registrierung einmal für alle Rechner ----------
    def microsoft_app(self):
        """(werte, lokal): Client-ID und Tenant-ID aus dem gemeinsamen Speicher – nie aus den Beispieldaten. Ist die
        Datei gerade nicht lesbar (OneDrive), ({}, lokal); 'lokal' heißt: ohne Ordner „Fahrzeuge“ nur dieser Rechner."""
        speicher = self._speicher(False)
        try:
            wert = (speicher.lade().get("einstellungen") or {}).get("microsoft_app")
        except CockpitFehler:
            return {}, speicher.lokal
        return (dict(wert) if isinstance(wert, dict) else {}), speicher.lokal

    def microsoft_app_setzen(self, werte: dict) -> bool:
        """Client-ID und Tenant-ID in den gemeinsamen Speicher schreiben (leeres dict: entfernen). Gibt 'lokal' zurück."""
        with self._sperre:
            speicher = self._speicher(False)
            daten = speicher.lade()
            einstellungen = {k: v for k, v in daten["einstellungen"].items() if k != "microsoft_app"}
            if werte:
                einstellungen["microsoft_app"] = dict(werte)
            daten["einstellungen"] = einstellungen
            speicher.schreibe(daten)
            self._signatur = None
            return speicher.lokal

    def _fuehrung(self, conn, heute: str, eigene: dict) -> dict:
        """Scorecard, Fristen, Zinsuhr und Herstellerbonus fürs Datenpaket. Ein Fehler in einem
        Teil hält das Cockpit nie auf – der Teil bleibt dann leer und der Fehler steht im Protokoll."""
        from . import fuehrung as fu
        e = {**FUEHRUNG_STANDARD, **(eigene.get("einstellungen") or {})}
        aus = {"fristVorlagen": fu.FRIST_VORLAGEN, "fristKategorien": fu.FRIST_KATEGORIEN, "bonusRoh": eigene["bonus"],
               "fuehrungEinstellungen": e}
        teile = {
            "scorecard": lambda: fu.scorecard(conn, heute, eigene.get("scorecard"), e["langsteher_tage"]),
            "fristen": lambda: fu.fristen_status(eigene["fristen"], heute),
            "zinsuhr": lambda: fu.zinsuhr(conn, heute, e["kalk_zins_pct"], e["langsteher_tage"], e["vorzieh_tage"]),
            "bonus": lambda: fu.herstellerbonus(conn, heute, eigene["bonus"]),
        }
        for name, rechne in teile.items():
            try:
                aus[name] = rechne()
            except Exception as fehler:                     # noqa: BLE001 – ein Teil darf das Cockpit nicht stoppen
                self._protokoll(f"Cockpit: {name} nicht berechenbar: {fehler!r}")
                aus[name] = None
        return aus

    def scorecard_speichern(self, kennzahlen) -> dict:
        """Ganze Kennzahlenliste speichern (Reihenfolge, Ziele, Verantwortliche, eigene Kennzahlen)."""
        from .fuehrung import AUTO_KENNZAHLEN
        if not isinstance(kennzahlen, list) or len(kennzahlen) > 30:
            raise CockpitFehler("Höchstens 30 Kennzahlen – weniger ist mehr.")

        def text(wert, laenge):
            return " ".join(str(wert or "").split())[:laenge]

        def neu(d):
            alt = d["scorecard"] if d["scorecard"].get("kennzahlen") else {}
            vorhandene = {str(k.get("id")) for k in alt.get("kennzahlen", [])}
            naechste = max([int(str(i)[1:]) for i in vorhandene if str(i).startswith("e") and str(i)[1:].isdigit()]
                           + [0]) + 1
            liste = []
            for k in kennzahlen:
                if not isinstance(k, dict):
                    continue
                kid = str(k.get("id") or "")
                if k.get("quelle") == "auto" and kid not in AUTO_KENNZAHLEN:
                    continue                             # Auto-Kennzahl, die es nicht mehr gibt (z. B. „werkstatt“)
                auto = k.get("quelle") == "auto"
                if not auto and not kid.startswith("e"):
                    kid = f"e{naechste}"
                    naechste += 1
                name = text(k.get("name"), 60) or (AUTO_KENNZAHLEN[kid]["name"] if auto else "")
                if not name:
                    raise CockpitFehler("Jede Kennzahl braucht einen Namen.")
                try:
                    ziel = None if k.get("ziel") in (None, "") else float(str(k["ziel"]).replace(",", "."))
                except ValueError:
                    raise CockpitFehler(f"Ziel bei „{name}“ bitte als Zahl.") from None
                liste.append({"id": kid, "quelle": "auto" if auto else "manuell", "name": name,
                              "einheit": text(k.get("einheit"), 12), "richtung": "<=" if k.get("richtung") == "<=" else ">=",
                              "ziel": ziel, "verantwortlich": text(k.get("verantwortlich"), 60),
                              "aktiv": bool(k.get("aktiv", True))})
            d["scorecard"] = {"kennzahlen": liste, "werte": d["scorecard"].get("werte", {})}
            return {"ok": True}
        return self._aendere(neu)

    def scorecard_wert(self, kennzahl_id, woche, wert) -> dict:
        """Wochenwert einer eigenen Kennzahl eintragen (leer = löschen)."""
        if not re.fullmatch(r"\d{4}-W\d{2}", str(woche or "")):
            raise CockpitFehler("Unbekannte Woche.")
        try:
            zahl = None if wert in (None, "") else float(str(wert).replace(",", "."))
        except ValueError:
            raise CockpitFehler("Bitte eine Zahl eintragen.") from None

        def setze(d):
            kennzahlen = d["scorecard"].get("kennzahlen") or []
            if not any(str(k.get("id")) == str(kennzahl_id) and k.get("quelle") == "manuell" for k in kennzahlen):
                raise CockpitFehler("Werte lassen sich nur bei eigenen Kennzahlen eintragen.")
            werte = d["scorecard"].setdefault("werte", {}).setdefault(str(kennzahl_id), {})
            if zahl is None:
                werte.pop(woche, None)
            else:
                werte[woche] = zahl
            return {"ok": True}
        return self._aendere(setze)

    def frist_speichern(self, eingabe: dict) -> dict:
        from .fuehrung import FRIST_KATEGORIEN
        e = eingabe or {}
        titel = " ".join(str(e.get("titel") or "").split())[:120]
        if not titel:
            raise CockpitFehler("Bitte beschreiben, was fällig wird (z. B. „Prüfung Hebebühnen“).")
        faellig = _datum_oder_none(e.get("faellig_am"), "Fällig am")
        if not faellig:
            raise CockpitFehler("Bitte das Fälligkeitsdatum angeben.")
        try:
            intervall = int(e.get("intervall_monate") or 0)
            vorlauf = int(e.get("vorlauf_tage") if e.get("vorlauf_tage") not in (None, "") else 30)
        except (TypeError, ValueError):
            raise CockpitFehler("Intervall und Vorlauf bitte als ganze Zahl.") from None
        if not 0 <= intervall <= 120 or not 0 <= vorlauf <= 365:
            raise CockpitFehler("Intervall 0–120 Monate (0 = einmalig), Vorlauf 0–365 Tage.")
        felder = {"titel": titel, "kategorie": e.get("kategorie") if e.get("kategorie") in FRIST_KATEGORIEN else "Sonstiges",
                  "faellig_am": faellig, "intervall_monate": intervall, "vorlauf_tage": vorlauf,
                  "verantwortlich": " ".join(str(e.get("verantwortlich") or "").split())[:60],
                  "notiz": str(e.get("notiz") or "").strip()[:500]}

        def neu(d):
            if e.get("id"):
                f = next((x for x in d["fristen"] if x.get("id") == int(e["id"])), None)
                if not f:
                    raise CockpitFehler("Diese Frist gibt es nicht mehr – vielleicht auf einem anderen Rechner gelöscht.")
                f.update(felder)
                return {"ok": True, "id": f["id"]}
            eintrag = {"id": _naechste_id(d["fristen"]), **felder, "erledigt": 0, "historie": [],
                       "angelegt_von": _benutzername(), "angelegt_am": _heute()}
            d["fristen"].append(eintrag)
            return {"ok": True, "id": eintrag["id"]}
        return self._aendere(neu)

    def frist_erledigt(self, frist_id) -> dict:
        """Erledigt: wiederkehrende Fristen rücken um ihr Intervall weiter – pünktlich erledigt im alten Rhythmus,
        verspätet ab heute. Einmalige Fristen werden als erledigt markiert."""
        from .fuehrung import plus_monate
        heute = dt.date.fromisoformat(_heute())

        def erledige(d):
            f = next((x for x in d["fristen"] if x.get("id") == int(frist_id)), None)
            if not f:
                raise CockpitFehler("Diese Frist gibt es nicht mehr – vielleicht auf einem anderen Rechner gelöscht.")
            faellig = dt.date.fromisoformat(str(f["faellig_am"])[:10])
            f.setdefault("historie", []).append({"erledigt_am": heute.isoformat(), "faellig_war": faellig.isoformat(),
                                                 "von": _benutzername()})
            f["historie"] = f["historie"][-20:]
            if int(f.get("intervall_monate") or 0) > 0:
                basis = faellig if heute <= faellig else heute
                f["faellig_am"] = plus_monate(basis, int(f["intervall_monate"])).isoformat()
            else:
                f["erledigt"], f["erledigt_am"] = 1, heute.isoformat()
            return {"ok": True, "naechste": None if f.get("erledigt") else f["faellig_am"]}
        return self._aendere(erledige)

    def frist_loeschen(self, frist_id) -> dict:
        def weg(d):
            d["fristen"] = [x for x in d["fristen"] if x.get("id") != int(frist_id)]
            return {"ok": True}
        return self._aendere(weg)

    def bonus_speichern(self, eingabe: dict) -> dict:
        e = eingabe or {}
        hersteller = " ".join(str(e.get("hersteller") or "").split())[:40]
        try:
            jahr = int(e.get("jahr") or 0)
            staffeln = [{"ab": int(s["ab"]), "prozent": float(str(s["prozent"]).replace(",", "."))}
                        for s in (e.get("staffeln") or []) if str(s.get("ab") or "").strip() != ""]
        except (TypeError, ValueError, KeyError):
            raise CockpitFehler("Staffeln bitte als „ab Stück“ (ganze Zahl) und Prozent (Zahl).") from None
        if not hersteller or not 2000 <= jahr <= 2100:
            raise CockpitFehler("Bitte Hersteller und Jahr angeben.")
        if not staffeln or any(not 1 <= s["ab"] <= 10000 or not 0 <= s["prozent"] <= 50 for s in staffeln):
            raise CockpitFehler("Mindestens eine Staffel: ab 1–10.000 Stück, 0–50 %.")
        felder = {"hersteller": hersteller, "jahr": jahr, "staffeln": sorted(staffeln, key=lambda s: s["ab"]),
                  "notiz": str(e.get("notiz") or "").strip()[:300]}

        def neu(d):
            if e.get("id"):
                b = next((x for x in d["bonus"] if x.get("id") == int(e["id"])), None)
                if not b:
                    raise CockpitFehler("Diese Staffel gibt es nicht mehr.")
                b.update(felder)
                return {"ok": True, "id": b["id"]}
            if any(x.get("hersteller", "").lower() == hersteller.lower() and x.get("jahr") == jahr for x in d["bonus"]):
                raise CockpitFehler(f"Für {hersteller} {jahr} gibt es schon eine Staffel – bitte dort ändern.")
            eintrag = {"id": _naechste_id(d["bonus"]), **felder, "angelegt_am": _heute()}
            d["bonus"].append(eintrag)
            return {"ok": True, "id": eintrag["id"]}
        return self._aendere(neu)

    def bonus_loeschen(self, bonus_id) -> dict:
        def weg(d):
            d["bonus"] = [x for x in d["bonus"] if x.get("id") != int(bonus_id)]
            return {"ok": True}
        return self._aendere(weg)

    def fuehrung_einstellungen(self, eingabe: dict) -> dict:
        """Kalkulatorischer Zins, Grenze für Langsteher und wie viele Tage ein Nachlass den Verkauf vorziehen soll."""
        e = eingabe or {}
        try:
            werte = {"kalk_zins_pct": float(str(e.get("kalk_zins_pct", FUEHRUNG_STANDARD["kalk_zins_pct"])).replace(",", ".")),
                     "langsteher_tage": int(e.get("langsteher_tage", FUEHRUNG_STANDARD["langsteher_tage"])),
                     "vorzieh_tage": int(e.get("vorzieh_tage", FUEHRUNG_STANDARD["vorzieh_tage"]))}
        except (TypeError, ValueError):
            raise CockpitFehler("Bitte Zahlen eintragen.") from None
        if not (0 <= werte["kalk_zins_pct"] <= 20 and 30 <= werte["langsteher_tage"] <= 1000
                and 7 <= werte["vorzieh_tage"] <= 365):
            raise CockpitFehler("Zins 0–20 %, Langsteher ab 30–1000 Tagen, Vorziehen 7–365 Tage.")

        def setze(d):
            d["einstellungen"] = {**d["einstellungen"], **werte}
            return {"ok": True}
        return self._aendere(setze)


FUEHRUNG_STANDARD = {"kalk_zins_pct": 5.0, "langsteher_tage": 180, "vorzieh_tage": 60}


def fuehrung_demo(heute: str):
    """Beispiel-Fristen und eine Beispiel-Bonusstaffel für die Beispieldaten."""
    t = dt.date.fromisoformat(heute)
    fristen = [
        {"id": 1, "titel": "Prüfung Hebebühnen", "kategorie": "Prüfung & Wartung",
         "faellig_am": (t + dt.timedelta(days=9)).isoformat(), "intervall_monate": 12, "vorlauf_tage": 30,
         "verantwortlich": "Werkstattleitung", "notiz": "", "erledigt": 0, "historie": []},
        {"id": 2, "titel": "Prüfung Feuerlöscher", "kategorie": "Prüfung & Wartung",
         "faellig_am": (t - dt.timedelta(days=4)).isoformat(), "intervall_monate": 24, "vorlauf_tage": 30,
         "verantwortlich": "Büro", "notiz": "", "erledigt": 0, "historie": []},
        {"id": 3, "titel": "Betriebshaftpflicht prüfen", "kategorie": "Versicherung",
         "faellig_am": (t + dt.timedelta(days=75)).isoformat(), "intervall_monate": 12, "vorlauf_tage": 45,
         "verantwortlich": "Geschäftsführung", "notiz": "", "erledigt": 0, "historie": []},
    ]
    bonus = [{"id": 1, "hersteller": "Hersteller1", "jahr": t.year, "notiz": "Beispielstaffel",
              "staffeln": [{"ab": 8, "prozent": 0.5}, {"ab": 15, "prozent": 1.0}, {"ab": 25, "prozent": 1.5}]}]
    return fristen, bonus
