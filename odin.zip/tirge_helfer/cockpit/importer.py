"""
Excel-Listen ins Cockpit einlesen.

Übernommen aus dem muster Cockpit (scripts/import.ts und scripts/import-teileliste.ts). Ohne Angabe wird der
Listentyp an Blattnamen und Spaltenköpfen erkannt. Der Import ist wiederholbar: dieselbe Datei noch einmal einlesen
aktualisiert die vorhandenen Zeilen, statt sie zu verdoppeln. Schlechte Daten brechen nie ab – was nicht passt,
steht als Hinweis im Bericht. Nur eine Datei, die sich gar nicht öffnen lässt, ergibt einen Fehler im Bericht.

Abweichungen vom Original stehen jeweils an der Stelle; die wichtigsten:
- Zeilen aus anderen Tabellen (Tilgungen, Fristen, Werkstatt, Einbauten) werden je Datei einmal ersetzt, nicht je
  Blatt – sonst blieben bei mehreren Blättern nur die Zeilen des letzten übrig.
- Finanzierungen ohne Vertragsnummer werden beim zweiten Einlesen wiedererkannt (NULL ist in SQLite nie gleich).
- Neu: Tilgungsplan aus den Datums-/Betragspaaren der Finanzaufstellung, der echte Aufbau der Bestandsliste
  (Ausstattungszeile unter jedem Fahrzeug, Formeln in Spalte P) und der Urlaubsplaner (eigener Leser in urlaub.py).
- Neu: Linienblätter der Finanzaufstellung (je Bank × Hersteller ein Blatt): Linie mit Limit und Konditionen aus
  den Zeilen unter der Summe, finanzierte Fahrzeuge mit ihrer Linie und darunter die kommenden Fahrzeuge (bestellt,
  noch nicht da; Termin als „KW 49/2026“ oder „Okt/Nov“) als eigene Einträge.
- Neu: Stücklisten in der Teileliste – Unterartikel direkt unter einem Set (GIBAnet: Giba1 → Giba2, Giba3) hängen
  am Set statt als eigene Artikel im Katalog zu stehen. Eine Zeile ohne Code mit eigenem Text heißt nach diesem Text,
  nicht nach dem Produkt der Warengruppe.
"""

import datetime as dt
import os
import re
from datetime import date, datetime

from . import urlaub
from .db import fracht_fuer, lade_vorlage, normalize_internal_id, parameter, praefix_info
from .excel import (Farbleser, UnlesbareDatei, Zuordnung, alle_aliase, blattnamen, farbabstand, finde_kopfzeile,
                    ist_leer, ist_neutral, lies_arbeitsmappe, monat_aus_text, normalisiere, oeffne_mappe,
                    ordne_spalten_zu, regeln, zeile_zu_datensatz, zu_datum, zu_text, zu_zahl)

ARTEN = ("bestandsliste", "finanzierungen", "auslieferungen", "finanzplanung", "provisionen", "teilepreise",
         "urlaubsplaner")
MAPPINGS = ("bestandsliste", "finanzierungen", "auslieferungen", "finanzplanung", "provisionen", "teilepreise")
STUNDENSATZ = 119              # Stundenverrechnungssatz, wenn die Teileliste keinen nennt (im Original aus .env)
MAX_HINWEISE = 300             # mehr liest niemand; der Rest wird nur gezählt

# Tabellen, die beim Import einer Liste nebenbei entstehen – sie werden je Datei ersetzt
NEBENTABELLEN = {"financings": ("tilgungen", "zulassungsfristen", "bank_linien", "kommende_fahrzeuge",
                                "erwartete_zahlungen"),
                 "deliveries": ("werkstattauftraege", "einbauten", "sonderfahrten")}

_ID_MUSTER = re.compile(r"(?<![A-Za-z0-9])([A-Za-z]{2,6})\s?-?\s?(\d{3,6})(?!\d)")


# --------------------------------------------------------------------------------------------- Hilfen ---

_MAPPINGS = {}


def lade_mapping(name: str) -> dict:
    if name not in _MAPPINGS:
        _MAPPINGS[name] = lade_vorlage("mappings/" + name)
    return _MAPPINGS[name]


def _text(wert):
    return None if wert is None else str(wert)


def _finde_id(text):
    """Treffer der internen Nummer in Freitext. Bekannte Präfixe zuerst, sonst der letzte Treffer
    („Auto 2000, DETKW00182“ soll DETKW00182 ergeben, nicht AUTO02000)."""
    if not text:
        return None
    treffer = list(_ID_MUSTER.finditer(str(text)))
    if not treffer:
        return None
    bekannt = [m for m in treffer if praefix_info(m.group(1))]
    return bekannt[0] if bekannt else treffer[-1]


def extrahiere_id(text):
    """'Lager, DETKW00182', 'Schou, DRM00245', 'SLKW00272 AF', 'NICHT BERECHNEN / SLKW00272' → interne Nummer."""
    m = _finde_id(text)
    return normalize_internal_id(m.group(1) + m.group(2)) if m else None


def trenne_kommission(text):
    """Kommission = Lager oder Händler/Kunde, oft mit der Nummer in derselben Zelle: (Art, Name)."""
    rest = str(text)
    m = _finde_id(rest)
    if m:
        rest = rest[:m.start()] + rest[m.end():]
    rest = re.sub(r"^[\s,;/]+|[\s,;/]+$", "", rest).strip()
    if not rest or re.fullmatch(r"lager(fahrzeug)?", rest, re.IGNORECASE):
        return "Lager", None
    return "Kommission", rest


_BANKEN = {}


def _banken() -> dict:
    if not _BANKEN:
        try:
            _BANKEN.update(lade_vorlage("banken"))
        except (OSError, ValueError):
            _BANKEN.update(_blaetter_ueberspringen=[], banken={}, hersteller={})
    return _BANKEN


def blatt_info(name: str) -> dict:
    """
    Die Finanzaufstellung führt je Bank und Hersteller ein Blatt („Nord. H1“, „CA SL“): beides steht im Namen.
    Übersprungen werden Auswertungsblätter („WF HG Umsatz“) und Hilfsblätter mit Hersteller, aber ohne Bank
    („Hersteller3 360“ ist nur eine Liste, keine Linie).
    """
    b = _banken()
    ueberspringen = any(w.lower() in name.lower() for w in b.get("_blaetter_ueberspringen", []))

    def treffer(tabelle):
        for k in sorted(tabelle, key=len, reverse=True):
            if re.search(r"(^|\s)" + re.escape(k) + r"(\s|$)", name, re.IGNORECASE):
                return tabelle[k]
        return None
    bank, hersteller = treffer(b.get("banken", {})), treffer(b.get("hersteller", {}))
    return {"bank": bank, "hersteller": hersteller, "ueberspringen": ueberspringen or bool(hersteller and not bank)}


_KEINE_INFO = {"bank": None, "hersteller": None, "ueberspringen": False}


def bank_name(kuerzel: str):
    """Kürzel aus der Spalte „Finanziert“ auflösen: 'WF' → 'Westbank'."""
    k = kuerzel.strip().rstrip(".").lower()
    for ab, name in _banken().get("banken", {}).items():
        if ab.rstrip(".").lower() == k:
            return name
    return None


def _liefer_kw(text: str):
    """'KW 14', 'KW14/26', '14. KW', '14/2026' → 'KW 14' bzw. 'KW 14/2026'; sonst None."""
    t = text.strip()
    m = (re.fullmatch(r"KW\s*(\d{1,2})(?:\s*[/.\-]\s*(\d{2,4}))?", t, re.IGNORECASE)
         or re.fullmatch(r"(\d{1,2})\.?\s*KW(?:\s*[/.\-]?\s*(\d{2,4}))?", t, re.IGNORECASE)
         or re.fullmatch(r"(\d{1,2})\s*/\s*(20\d{2}|\d{2})", t))
    if not m or not 1 <= int(m.group(1)) <= 53:
        return None
    return f"KW {int(m.group(1))}" + (f"/{m.group(2)}" if m.group(2) else "")


def _vergleich(s) -> str:
    return normalisiere(s) if s else ""


def fahrzeug_vorschlag(db, modell, kunde=None):
    """
    Fahrzeug zu einer Zeile ohne interne Nummer: über Modell und Kunde, sonst ein eindeutiges Modell.
    (id oder None, Grund). Kunde zählt auch, wenn er in der Bestandsliste als Kommission steht.
    """
    if not modell:
        return None, "kein Modell"
    m = _vergleich(modell)
    kandidaten = [r for r in db.execute(
        "SELECT internal_id, model, customer, kommission_name, status FROM vehicles WHERE model IS NOT NULL")
        if _vergleich(r["model"]) == m]
    if kunde:
        k = _vergleich(kunde)
        treffer = [r for r in kandidaten if k and k in (_vergleich(r["customer"]), _vergleich(r["kommission_name"]))]
        if len(treffer) == 1:
            return treffer[0]["internal_id"], "Modell und Kunde"
    offen = [r for r in kandidaten if r["status"] != "Ausgeliefert"]
    if len(offen) == 1:
        return offen[0]["internal_id"], "Modell eindeutig"
    if len(offen) > 1:
        return None, "mehrdeutig: " + ", ".join(sorted(r["internal_id"] for r in offen))
    return None, "kein Fahrzeug gefunden"


def _neuer_bericht(art, quelle) -> dict:
    return {"art": art, "datei": quelle, "blaetter": [], "zeilen_gelesen": 0, "zeilen_geschrieben": 0,
            "hinweise": [], "spalten_erkannt": {}, "spalten_fehlen": [], "fehler": ""}


def _jetzt() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------------------------- Ein Lauf ---

class _Lauf:
    """Zustand eines Imports: Bericht, Zeilen für Nebentabellen, bereits ersetzte Tabellen."""

    def __init__(self, db, quelle: str, bericht: dict):
        self.db = db
        self.quelle = quelle
        self.bericht = bericht
        self.nebenzeilen = []                  # (tabelle, satz, modus)
        self.geleert = set()
        self.bereits_finanziert = set()        # Fahrzeuge, die in diesem Lauf schon aus einem Bankblatt kamen
        self.linien = {}                       # (Bank, Hersteller) → Blatt, aus dem die Linie kam
        self.heute = _heute()
        self._spalten = {}
        self._uebrige_hinweise = 0

    def hinweis(self, text: str):
        if len(self.bericht["hinweise"]) < MAX_HINWEISE:
            self.bericht["hinweise"].append(text)
        else:
            self._uebrige_hinweise += 1

    def abschliessen(self):
        if self._uebrige_hinweise:
            self.bericht["hinweise"].append(f"… und {self._uebrige_hinweise} weitere Hinweise")

    def spalten(self, tabelle: str) -> set:
        if tabelle not in self._spalten:
            self._spalten[tabelle] = {r[1] for r in self.db.execute(f"PRAGMA table_info({tabelle})")}
        return self._spalten[tabelle]

    def leere(self, tabelle: str):
        """Zeilen dieser Datei einmal je Import löschen – beim erneuten Einlesen entsteht nichts doppelt."""
        if tabelle not in self.geleert:
            self.db.execute(f"DELETE FROM {tabelle} WHERE source_file = ?", (self.quelle,))
            self.geleert.add(tabelle)

    def import_lauf(self, mapping: str, blatt: str, gelesen: int, geschrieben: int, warnungen: list):
        self.db.execute(
            "INSERT INTO import_runs (source_file, mapping, sheet, rows_read, rows_written, warnings, ran_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (self.quelle, mapping, blatt, gelesen, geschrieben, " | ".join(warnungen[:50]) or None, _jetzt()))

    # ---------------------------------------------------------------------------------------- Schreiben ---
    def _felder(self, tabelle: str, saetze: list) -> list:
        erlaubt = self.spalten(tabelle)
        alle = list(dict.fromkeys(k for s in saetze for k in s))
        fremd = [f for f in alle if f not in erlaubt]
        if fremd:
            self.hinweis(f"Felder ohne Spalte in {tabelle} ignoriert: {', '.join(fremd)} (Zuordnung prüfen)")
        return [f for f in alle if f in erlaubt]

    def schreibe(self, saetze: list, mapping: dict) -> int:
        """
        Upsert wie im Original: vorhandene Zeile (gleicher Schlüssel) wird ergänzt, leere Felder überschreiben
        nichts. Anders als ON CONFLICT erkennt der Vergleich mit IS auch Schlüssel mit leerer Vertragsnummer.
        """
        tabelle = mapping["ziel"]
        if mapping.get("ersetze_nach_quelle"):
            self.leere(tabelle)
        if not saetze:
            return 0
        felder = self._felder(tabelle, saetze)
        schluessel = [k for k in mapping.get("schluessel") or [] if k in felder]
        einfuegen = f"INSERT INTO {tabelle} ({', '.join(felder)}) VALUES ({', '.join('?' * len(felder))})"
        if not schluessel:
            self.db.executemany(einfuegen, [[s.get(f) for f in felder] for s in saetze])
            return len(saetze)
        andere = [f for f in felder if f not in schluessel]
        suche = f"SELECT id FROM {tabelle} WHERE " + " AND ".join(f"{k} IS ?" for k in schluessel)
        aendern = (f"UPDATE {tabelle} SET " + ", ".join(f"{f} = COALESCE(?, {f})" for f in andere) + " WHERE id = ?")
        for s in saetze:
            vorhanden = self.db.execute(suche, [s.get(k) for k in schluessel]).fetchone()
            if vorhanden and andere:
                self.db.execute(aendern, [s.get(f) for f in andere] + [vorhanden[0]])
            elif not vorhanden:
                self.db.execute(einfuegen, [s.get(f) for f in felder])
        return len(saetze)

    def neben(self, tabelle: str, satz: dict, modus: str = "ersetzen"):
        self.nebenzeilen.append((tabelle, satz, modus))

    def schreibe_nebenzeilen(self) -> int:
        """Zeilen, die beim Import nebenbei entstehen (Werkstatt, Einbauten, Tilgungen, Fristen, Fahrzeuge)."""
        gruppen = {}
        for tabelle, satz, modus in self.nebenzeilen:
            gruppen.setdefault((tabelle, modus), []).append(satz)
        n = 0
        for (tabelle, modus), zeilen in gruppen.items():
            if modus != "ignorieren":
                self.leere(tabelle)
            felder = self._felder(tabelle, zeilen)
            # Fahrzeuge werden nur angelegt, wenn sie fehlen – vorhandene bleiben unangetastet
            verb = "INSERT OR IGNORE" if modus == "ignorieren" else "INSERT OR REPLACE"
            self.db.executemany(
                f"{verb} INTO {tabelle} ({', '.join(felder)}) VALUES ({', '.join('?' * len(felder))})",
                [[z.get(f) for f in felder] for z in zeilen])
            n += len(zeilen)
            self.hinweis(f"Nebenbei: {len(zeilen)} Zeilen in {tabelle}")
        self.nebenzeilen.clear()
        return n

    # ----------------------------------------------------------------------------- Nachbearbeitung ---
    def nachbearbeiten(self, satz: dict, mapping: dict, warn, nr: int, blatt: str, kontext: dict):
        """Feldwerte vereinheitlichen, damit Auswertungen verlässlich sind; None = Zeile überspringen."""
        for feld in ("internal_id", "vehicle_internal_id"):
            if not satz.get(feld):
                continue
            roh = str(satz[feld]).strip()
            if roh.startswith("?"):             # mit „?“ markierte Vorschläge aus dem ID-Helfer gelten als leer
                satz[feld] = None
                continue
            satz[feld] = extrahiere_id(roh) or normalize_internal_id(roh)
        ziel = mapping["ziel"]
        if ziel == "vehicles":
            return self._fahrzeug(satz, warn, nr, blatt, kontext)
        if ziel == "financings":
            return self._finanzierung(satz, warn, nr, blatt)
        if ziel == "cash_entries":
            return self._zahlung(satz, warn, nr)
        if ziel == "commissions":
            return self._provision(satz)
        if ziel == "deliveries":
            return self._auslieferung(satz, warn, nr, blatt)
        if ziel == "parts":
            return self._teil(satz, warn, nr)
        return satz

    def _fahrzeug(self, satz, warn, nr, blatt, kontext):
        kommission = _text(satz.get("kommission_roh"))
        if not satz.get("internal_id"):
            satz["internal_id"] = extrahiere_id(kommission)
        if not satz.get("internal_id"):
            werte = [v for k, v in satz.items() if v is not None and not k.startswith("schluessel_farbe")]
            if werte and all(isinstance(v, (int, float)) for v in werte):
                return None                     # Summenzeile: nur Zahlen, keine Nummer – kein Hinweis nötig
            warn(f"Zeile {nr}: ohne interne Nummer – übersprungen")
            return None
        iid = normalize_internal_id(satz["internal_id"])
        satz["internal_id"] = iid

        # Marke und Fahrzeugart stecken im Präfix, sofern die Datei sie nicht selbst führt
        info = praefix_info(iid)
        if not info:
            warn(f"Zeile {nr}: Präfix von {iid} ist in vorlagen/praefixe.json nicht hinterlegt")
        if satz.get("brand") is None:
            satz["brand"] = (info or {}).get("marke")
        if satz.get("category") is None:
            satz["category"] = (info or {}).get("kategorie")

        # Schlüssel-Nr. führt zwei Dinge: geplanter Lieferblock (B1/B2/B3, im echten Aufbau auch die Liefer-KW)
        # oder die echte Schlüsselnummer. Rot hinterlegt heißt: noch nicht auf Lager.
        schluessel = (_text(satz.get("schluessel_roh")) or "").strip() or None
        rot = satz.get("schluessel_farbe") == "nicht auf Lager"
        if schluessel:
            kw = _liefer_kw(schluessel)
            if re.fullmatch(r"B\s?\d", schluessel, re.IGNORECASE):
                satz["lieferblock"] = schluessel.upper().replace(" ", "")
            elif kw:
                satz["lieferblock"] = kw
            elif rot and re.fullmatch(r"\d{1,2}", schluessel) and 1 <= int(schluessel) <= 53:
                satz["lieferblock"] = f"KW {int(schluessel)}"     # rote kleine Zahl: Liefer-KW, kein Schlüssel
            else:
                satz["schluessel_nr"] = schluessel
        if satz.get("schluessel_nr"):
            satz["lieferstatus"] = "im Werk" if rot else "angeliefert"
        elif satz.get("lieferblock") or rot:
            satz["lieferstatus"] = "geplant"
        else:
            satz["lieferstatus"] = None

        # Kommission: „Lager“ oder Name des Händlers/Kunden, oft mit der Nummer in derselben Zelle.
        # Im echten Aufbau bleibt sie bei Lagerfahrzeugen leer – dann ist es eben ein Lagerfahrzeug.
        if kommission is not None:
            satz["kommission_art"], satz["kommission_name"] = trenne_kommission(kommission)
        elif kontext.get("kommission_spalte"):
            satz["kommission_art"] = "Lager"

        # VK Liste wird brutto geführt; netto daraus rechnen. VK min. = (EK netto + Fracht) × Faktor
        p = parameter()
        if satz.get("list_price_gross") and not satz.get("list_price_net"):
            satz["list_price_net"] = satz["list_price_gross"] / p["mwst"]
        if not satz.get("vk_min") and satz.get("purchase_net"):
            fracht = fracht_fuer(_text(satz.get("category")), satz.get("fracht"))
            satz["vk_min"] = (satz["purchase_net"] + fracht) * p["vk_min_faktor"]

        s = (_text(satz.get("status")) or "").lower()
        if s.startswith("ausgel"):
            satz["status"] = "Ausgeliefert"
        elif s.startswith("verkauf"):
            satz["status"] = "Verkauft"
        elif s.startswith("reserv"):
            satz["status"] = "Reserviert"
        elif s:
            satz["status"] = "Bestand"
        elif satz.get("sold_date"):
            satz["status"] = "Verkauft"
        elif satz.get("kommission_art") == "Kommission":
            satz["status"] = "Verkauft" if satz.get("lieferstatus") == "angeliefert" else "Reserviert"
        else:
            satz["status"] = "Bestand"

        # Spalte „Finanziert“: „WF, 08977“ = Bank und Vertragsnummer, eine reine Zahl = CaraCamp-Objektnummer
        finanziert = (_text(satz.get("caracamp_objekt")) or "").strip() or None
        if finanziert:
            m = re.fullmatch(r"([A-Za-zÄÖÜäöüß.&\s-]{1,24}?)\s*[,;/]\s*(\d{3,10})", finanziert)
            if m:
                satz["fin_bank"] = bank_name(m.group(1)) or m.group(1).strip()
                satz["fin_vertrag"] = m.group(2)
                satz["caracamp_objekt"] = None
            elif re.fullmatch(r"\d{3,10}", finanziert):
                satz["caracamp_objekt"] = finanziert
            elif bank_name(finanziert):
                satz["fin_bank"] = bank_name(finanziert)
                satz["caracamp_objekt"] = None

        jahr = re.search(r"(20\d{2})", blatt)
        if jahr:
            satz["jahrgang"] = int(jahr.group(1))
        satz["source_sheet"] = blatt
        satz["updated_at"] = self.heute.isoformat()
        for hilfsfeld in ("schluessel_roh", "kommission_roh", "schluessel_farbe", "lfd_nr"):
            satz.pop(hilfsfeld, None)
        return satz

    def _finanzierung(self, satz, warn, nr, blatt):
        kommission = _text(satz.get("kommission_roh"))
        tilgungen = satz.pop("_tilgungen", [])
        iid = extrahiere_id(kommission) or satz.get("vehicle_internal_id")
        if not iid:
            warn(f"Zeile {nr}: keine interne Nummer in „{kommission or ''}“ – übersprungen")
            return None
        satz["vehicle_internal_id"] = iid
        bank_bekannt = bool(satz.get("bank"))
        if not bank_bekannt:
            satz["bank"] = "nicht angegeben"
        # Steht das Fahrzeug schon aus einem Bankblatt da, ist die Zeile aus der Übersicht eine Dublette
        if not bank_bekannt and iid in self.bereits_finanziert:
            warn(f"Zeile {nr}: {iid} steht schon im Bankblatt – Zeile aus der Übersicht übersprungen")
            return None
        if bank_bekannt:
            self.bereits_finanziert.add(iid)

        satz["status"] = "abgelöst" if satz.get("abgeloest_am") else "offen"
        if not satz.get("interest_free_until"):
            warn(f"Zeile {nr}: kein zinsfrei-Datum – {iid} fehlt in der Ablaufwarnung")
        satz["updated_at"] = self.heute.isoformat()

        # Fahrzeuge, die in keiner Bestandsliste stehen (Gebrauchtwagen), hier anlegen
        vorhanden = self.db.execute("SELECT 1 FROM vehicles WHERE internal_id = ?", (iid,)).fetchone()
        if not vorhanden:
            info = praefix_info(iid) or {}
            art = (_text(satz.get("fzg_art")) or "").lower()
            k_art, k_name = trenne_kommission(kommission or "")
            self.neben("vehicles", {
                "internal_id": iid, "model": satz.get("fzg_model"), "serien_nr": satz.get("fzg_serien_nr"),
                "vin": satz.get("fzg_vin"), "brand": info.get("marke") or satz.get("blatt_hersteller"),
                "category": info.get("kategorie") or ("Gebrauchtwagen" if "gebraucht" in art else None),
                "condition": "Gebraucht" if "gebraucht" in art else "Neu" if art else None,
                "status": "Verkauft" if satz.get("zeilenfarbe") == "verkauft" else "Bestand",
                "lieferstatus": "angeliefert", "kommission_art": k_art, "kommission_name": k_name,
                "purchase_net": satz.get("fzg_ek_netto"), "arrival_date": satz.get("start_date"),
                "source_file": self.quelle, "source_sheet": blatt, "updated_at": self.heute.isoformat(),
            }, "ignorieren")
            warn(f"Zeile {nr}: {iid} war unbekannt und wurde aus der Finanzaufstellung angelegt")
        elif satz.get("zeilenfarbe") == "verkauft":
            self.db.execute("UPDATE vehicles SET status = 'Verkauft' WHERE internal_id = ? AND status = 'Bestand'",
                            (iid,))

        # „Stellantis EURO 6 (EA) bis 30.06.2027“ → Art und Frist
        ausnahme = (_text(satz.get("ausnahme")) or "").strip()
        if ausnahme:
            m = re.fullmatch(r"(.*?)\s*\bbis\s*(\S+)\s*", ausnahme, re.IGNORECASE)
            frist = zu_datum(m.group(2)) if m else None
            if not m and zu_datum(ausnahme):
                art_text, frist = "Ausnahmegenehmigung", zu_datum(ausnahme)     # nur ein Datum in der Zelle
            else:
                art_text = (m.group(1) if m and frist else ausnahme).strip() or "Ausnahmegenehmigung"
            self.neben("zulassungsfristen", {"vehicle_internal_id": iid, "ausnahme_art": art_text, "frist": frist,
                                             "hinweis": None, "source_file": self.quelle})

        # Tilgungsplan: Datums- und Betragspaare rechts; eine Zeile je Rate
        for faellig, betrag in tilgungen:
            self.neben("tilgungen", {"vehicle_internal_id": iid, "bank": satz["bank"], "faellig_am": faellig,
                                     "betrag": betrag, "bezahlt_am": satz.get("abgeloest_am"),
                                     "source_file": self.quelle})

        for hilfsfeld in ("fzg_model", "fzg_serien_nr", "fzg_vin", "fzg_ek_netto", "fzg_art", "ausnahme",
                          "zeilenfarbe", "abgeloest_am", "kommission_roh", "blatt_hersteller"):
            satz.pop(hilfsfeld, None)
        return satz

    def _zahlung(self, satz, warn, nr):
        if not satz.get("entry_date"):
            warn(f"Zeile {nr}: ohne Datum – übersprungen")
            return None
        betrag = satz.get("amount") or 0
        r = (_text(satz.get("direction")) or "").lower()
        if re.search(r"aus|abgang|ausgab|zahlung raus|-", r):
            satz["direction"] = "aus"
        elif re.search(r"ein|eingang|einnahm", r):
            satz["direction"] = "ein"
        else:
            satz["direction"] = "aus" if betrag < 0 else "ein"
        satz["amount"] = abs(betrag)
        k = (_text(satz.get("kind")) or "").lower()
        if re.search(r"plan|budget|forecast|prognose", k):
            satz["kind"] = "plan"
        elif re.search(r"ist|bank|gebucht", k):
            satz["kind"] = "ist"
        else:
            satz["kind"] = "ist" if satz["entry_date"] <= self.heute.isoformat() else "plan"
        return satz

    def _provision(self, satz):
        if satz.get("amount") is None and satz.get("basis_amount") is not None and satz.get("rate_pct") is not None:
            satz["amount"] = satz["basis_amount"] * satz["rate_pct"] / 100
        s = (_text(satz.get("status")) or "").lower()
        satz["status"] = "ausgezahlt" if re.search(r"ausgez|bezahlt|erledigt|ja", s) else "offen"
        return satz

    def _termin(self, roh, blatt: str):
        """Termin steht oft als „Di. 29.09. 14:30“ in der Zelle; ohne Jahr gilt das Jahr im Blattnamen,
        sonst das, mit dem der Tag am nächsten an heute liegt (das Original nahm stur das laufende Jahr)."""
        if isinstance(roh, (datetime, date)):
            return zu_datum(roh)
        text = zu_text(roh)
        if not text:
            return None
        m = re.search(r"(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?", text)
        if not m:
            return zu_datum(text)
        if m.group(3):
            return zu_datum(m.group(0))
        tag, monat = int(m.group(1)), int(m.group(2))
        jahr = re.search(r"(20\d{2})", blatt)
        if jahr:
            return zu_datum(f"{tag}.{monat}.{jahr.group(1)}")
        kandidaten = [d for d in (zu_datum(f"{tag}.{monat}.{j}") for j in range(self.heute.year - 1,
                                                                                    self.heute.year + 2)) if d]
        return min(kandidaten, key=lambda d: abs((dt.date.fromisoformat(d) - self.heute).days), default=None)

    def _auslieferung(self, satz, warn, nr, blatt):
        roh = satz.pop("_termin_roh", satz.get("planned_date"))
        if _hat_wert(roh):
            satz["planned_date"] = self._termin(roh, blatt)
            satz["uhrzeit"] = termin_uhrzeit(roh)
            if not satz["planned_date"]:
                warn(f"Zeile {nr}: Termin „{zu_text(roh)}“ nicht lesbar")
        satz["source_sheet"], satz["zeile"] = blatt, nr

        if not satz.get("vehicle_internal_id"):
            satz["vehicle_internal_id"], _ = fahrzeug_vorschlag(self.db, satz.get("model"), satz.get("customer"))
        if not satz.get("vehicle_internal_id"):
            warn(f"Zeile {nr}: kein Fahrzeug zuzuordnen ({satz.get('model') or 'ohne Modell'}) – übersprungen")
            return None
        fahrzeug = normalize_internal_id(satz["vehicle_internal_id"])
        satz["vehicle_internal_id"] = fahrzeug

        satz["tuev_faellig"] = 1 if satz.get("tuev_farbe") == "fällig" else 0
        satz["werk_bezahlt"] = 1 if satz.get("werk_farbe") == "bezahlt" else 0
        satz["status"] = "ausgeliefert" if satz.get("actual_date") else "geplant"
        if satz.get("termin_art") == "Urlaub":
            warn(f"Zeile {nr}: rosa Zeile, sieht nach Urlaubseintrag aus")

        # Werkstattauftrag aus derselben Zeile – er hängt am Fahrzeug, nicht an der Auslieferung
        if satz.get("arbeitskarte") or satz.get("geplante_minuten"):
            tank = satz.get("tankstatus")
            if not tank and "fertig" in (_text(satz.get("tank_text")) or "").lower():
                tank = "fertig"
            self.neben("werkstattauftraege", {
                "vehicle_internal_id": fahrzeug, "arbeitskarte": satz.get("arbeitskarte"), "art": "Auslieferung",
                "termin": satz.get("planned_date"), "geplante_minuten": satz.get("geplante_minuten"),
                "teilestatus": satz.get("teilestatus"), "tankstatus": tank, "monteur": None, "bemerkung": None,
                "source_file": self.quelle})

        # Einbauten: je Spalte eine Position, der Status steckt in der Farbe
        for position, feld, beschreibung in (("AHK starr", "einbau_ahks", None),
                                             ("AHK abnehmbar", "einbau_ahka", None),
                                             ("Unterboden & Hohlraum", "einbau_ubhk", None),
                                             ("Sondereinbau", "einbau_son", _text(satz.get("einbau_son_text")))):
            if satz.get(feld):
                self.neben("einbauten", {"vehicle_internal_id": fahrzeug, "position": position,
                                         "beschreibung": beschreibung, "status": satz[feld],
                                         "source_file": self.quelle})

        for hilfsfeld in ("tank_text", "tuev_farbe", "werk_farbe", "teilestatus", "tankstatus", "arbeitskarte",
                          "geplante_minuten", "einbau_ahks", "einbau_ahka", "einbau_ubhk", "einbau_son",
                          "einbau_son_text", "model"):
            satz.pop(hilfsfeld, None)
        return satz

    def _teil(self, satz, warn, nr):
        if not satz.get("sku") or not satz.get("name"):
            warn(f"Zeile {nr}: Artikelnummer oder Bezeichnung fehlt – übersprungen")
            return None
        if not satz.get("hourly_rate"):
            satz["hourly_rate"] = STUNDENSATZ
        return satz


# ------------------------------------------------------------------- Linienblätter der Finanzaufstellung ---
# Ein Blatt je Linie (Bank × Hersteller). Oben die finanzierten Fahrzeuge, darunter nach Leerzeilen die kommenden
# (Rechnungsdatum „KW 49/2026“ oder „Okt/Nov“, Zinsfrei „360 Tage“), ganz unten Summe, Limit (negative Zahl in der
# Finanzierungsspalte), Rest und die Konditionen als Text.

_KW = re.compile(r"\bKW\s*(\d{1,2})(?:\s*[/.\-]\s*(\d{2,4}))?", re.IGNORECASE)
_MONAT_ZAHL = re.compile(r"(?<![\d.])(\d{1,2})\s*/\s*(20\d{2})(?!\d)")
_FUSSTEXT = re.compile(r"%|\bp\.\s?a\b|^\s*(plus|zzgl|zins|limit|summe|gesamt|frei|über|ueber|rest|kondition)",
                       re.IGNORECASE)
_LIMIT_WORT = re.compile(r"\blimit|\brahmen|\bkreditlinie", re.IGNORECASE)
_KONDITION = re.compile(r"%|bereitstell|skonto", re.IGNORECASE)


def termin_uhrzeit(roh):
    """Uhrzeit aus einem Termin: „Di. 13.10. 10:30“ → „10:30“, „14 Uhr“ → „14:00“, datetime mit Zeit → „HH:MM“."""
    if isinstance(roh, datetime):
        return roh.strftime("%H:%M") if (roh.hour, roh.minute) != (0, 0) else None
    if isinstance(roh, dt.time):
        return roh.strftime("%H:%M")
    text = zu_text(roh) if not isinstance(roh, date) else None
    if not text:
        return None
    rest = re.sub(r"\d{1,2}[./]\d{1,2}(?:[./]\d{2,4})?\.?", " ", text)       # Datum weg, damit „13.10“ keine Zeit ist
    m = re.search(r"(?<!\d)([01]?\d|2[0-3])[:.]([0-5]\d)(?!\d)", rest) or re.search(
        r"(?<!\d)([01]?\d|2[0-3])\s*(?:uhr|h\b)", rest, re.IGNORECASE)
    if not m:
        return None
    minute = m.group(2) if m.lastindex and m.lastindex >= 2 else "00"
    return f"{int(m.group(1)):02d}:{minute}"


def _jahr_fuer(monat: int, heute: date) -> int:
    """Monat ohne Jahr: dieses Jahr, solange er höchstens zwei Monate zurückliegt – sonst das nächste."""
    return heute.year if heute.month - monat <= 2 else heute.year + 1


def grobes_datum(wert, heute: date = None):
    """
    Liefertermin eines kommenden Fahrzeugs als grobes ISO-Datum (nur zum Sortieren und für die Zeitleiste):
    echtes Datum; „KW 49/2026“ → Montag der KW; „KW 3“ → nächstes Vorkommen; „Okt/Nov“, „Juni/Aug.“, „Dez. 2026“,
    „12/2026“ → Erster des (ersten) Monats. Unlesbares → None.
    """
    heute = heute or date.today()
    if wert is None or isinstance(wert, bool):
        return None
    if isinstance(wert, (datetime, date)):
        return zu_datum(wert)
    text = str(wert).strip()
    if not text:
        return None
    echt = zu_datum(text)
    if echt:
        return echt
    m = _KW.search(text)
    if m:
        woche = int(m.group(1))
        if m.group(2):
            jahre = [int(m.group(2)) + (2000 if len(m.group(2)) == 2 else 0)]
        else:
            jahre = [heute.year, heute.year + 1]
        for jahr in jahre:
            try:
                tag = date.fromisocalendar(jahr, woche, 1)
            except ValueError:
                continue
            if m.group(2) or tag >= heute - dt.timedelta(days=60):
                return tag.isoformat()
        return None
    m = _MONAT_ZAHL.search(text)
    if m and 1 <= int(m.group(1)) <= 12:
        return date(int(m.group(2)), int(m.group(1)), 1).isoformat()
    monat = monat_aus_text(text)
    if monat:
        nummer, jahr = monat
        return date(jahr or _jahr_fuer(nummer, heute), nummer, 1).isoformat()
    return None


def _zahl_aus(wert):
    """Zahl aus einer Zelle; Prozentangaben („4,99 %“) sind keine Beträge."""
    if isinstance(wert, str) and "%" in wert:
        return None
    return zu_zahl(wert)


def _finanzierungsspalte(kopf: list, zuordnungen: list, bank: str):
    """Die Spalte mit dem Finanzierungsbetrag heißt „Finanzierung“, „S-Kredit“ – oder wie die Bank („Nordbank“)."""
    if any(z.feld == "financed_amount" for z in zuordnungen):
        return zuordnungen
    namen = {normalisiere(bank), normalisiere(bank.split()[0])}
    namen |= {normalisiere(k) for k, v in _banken().get("banken", {}).items() if v == bank}
    belegt = {z.spalte for z in zuordnungen}
    for j, k in enumerate(kopf):
        if j not in belegt and normalisiere(zu_text(k)) in namen:
            return zuordnungen + [Zuordnung("financed_amount", j, zu_text(k), "zahl")]
    return zuordnungen


class Linienblatt:
    """
    Liest ein Linienblatt Zeile für Zeile: welche Zeile ist ein finanziertes Fahrzeug, welche ein kommendes, welche
    gehört zum Fuß (Summe, Limit, Konditionen)? Wird vom Import und vom Strukturbericht benutzt.
    """

    def __init__(self, blatt, kopfzeile: int, zuordnungen: list, info: dict, heute: date = None):
        self.blatt = blatt
        self.bank = info["bank"]
        self.hersteller = info["hersteller"] or blatt.name
        self.heute = heute or date.today()
        self.zuordnungen = _finanzierungsspalte(blatt.zeilen[kopfzeile], zuordnungen, self.bank)
        self.spalte = {}
        for z in self.zuordnungen:
            if z.typ not in ("fuellfarbe", "schriftfarbe"):
                self.spalte.setdefault(z.feld, z.spalte)
        self.fuss = []                 # Zeilen ohne Fahrzeug unter bzw. zwischen den Fahrzeugen
        self.anzahl = {"finanziert": 0, "kommend": 0}
        self._daten = False
        self._nach_luecke = False
        self._letzte_nr = blatt.zeilennr[kopfzeile]

    def wert(self, i: int, feld: str):
        j = self.spalte.get(feld)
        return None if j is None else self.blatt.wert(i, j)

    @property
    def finanzierungsspalte(self):
        z = next((z for z in self.zuordnungen if z.feld == "financed_amount"), None)
        return z.quelle if z else None

    def _kommission(self, i: int):
        return zu_text(self.wert(i, "kommission_roh")) or zu_text(self.wert(i, "vehicle_internal_id"))

    def zeilenart(self, i: int) -> str:
        """'finanziert', 'kommend' oder 'fuss'. Zeilen der Reihe nach abfragen – Leerzeilen zählen mit."""
        nr = self.blatt.zeilennr[i]
        if self._daten and nr - self._letzte_nr > 1:
            self._nach_luecke = True
        self._letzte_nr = nr
        kommission, modell = self._kommission(i), zu_text(self.wert(i, "fzg_model"))
        if (not kommission and not modell) or (
                kommission and not modell and not extrahiere_id(kommission) and _FUSSTEXT.search(kommission)):
            if self._daten:
                self.fuss.append(i)
            return "fuss"
        self._daten = True
        rechnung, zinsfrei = self.wert(i, "start_date"), self.wert(i, "interest_free_until")
        if zu_datum(rechnung):
            art = "finanziert"
        elif ((isinstance(rechnung, str) and rechnung.strip())
              or (isinstance(zinsfrei, str) and zinsfrei.strip() and not zu_datum(zinsfrei))
              or self._nach_luecke):
            self._nach_luecke = True                 # ab hier stehen die bestellten Fahrzeuge
            art = "kommend"
        else:
            art = "finanziert"
        self.anzahl[art] += 1
        return art

    def kommend(self, i: int, warn, quelle: str) -> dict:
        nr = self.blatt.zeilennr[i]
        kommission = self._kommission(i)
        art, kunde = trenne_kommission(kommission) if kommission else (None, None)
        if kunde:
            kunde = re.sub(r"^(kunde|kd\.?)\s+", "", kunde, flags=re.IGNORECASE).strip() or kunde
        termin_roh, zinsfrei = self.wert(i, "start_date"), self.wert(i, "interest_free_until")
        termin_text = zu_text(termin_roh)
        termin = grobes_datum(termin_roh, self.heute)
        if termin_text and not termin:
            warn(f"Zeile {nr}: Termin „{termin_text}“ ist weder KW noch Monat – steht unter „ohne Termin“")
        ek = _zahl_aus(self.wert(i, "fzg_ek_netto"))
        betrag = _zahl_aus(self.wert(i, "financed_amount"))
        betrag = abs(betrag) if betrag else (abs(ek) if ek else None)
        if betrag is None:
            warn(f"Zeile {nr}: kommendes Fahrzeug ohne Betrag (weder Finanzierung noch EK) – zählt nicht für "
                 f"die Linie")
        konditionen = (f"zinsfrei bis {datum_de(zu_datum(zinsfrei))}" if isinstance(zinsfrei, (datetime, date))
                       else zu_text(zinsfrei))
        return {"bank": self.bank, "hersteller": self.hersteller, "linie": self.blatt.name,
                "kommission": kommission, "kommission_art": art, "kunde": kunde,
                "internal_id": extrahiere_id(kommission) if kommission else None,
                "modell": zu_text(self.wert(i, "fzg_model")), "termin_text": termin_text, "termin_datum": termin,
                "konditionen": konditionen, "betrag": betrag, "ek_netto": abs(ek) if ek else None,
                "source_file": quelle, "source_sheet": self.blatt.name, "zeile": nr}

    def fuss_lesen(self) -> dict:
        """Limit (erste negative Zahl der Finanzierungsspalte im Fuß, sonst eine Zahl neben „Limit“) und Konditionen."""
        j = self.spalte.get("financed_amount")
        limit, mit_wort, konditionen = None, None, []
        for i in self.fuss:
            texte = [t for t in (zu_text(w) for w in self.blatt.zeilen[i] if isinstance(w, str)) if t]
            for t in texte:
                if _KONDITION.search(t) and t not in konditionen:
                    konditionen.append(t)
            zahl = _zahl_aus(self.blatt.wert(i, j)) if j is not None else None
            if zahl is None or abs(zahl) < 1000:
                continue
            if mit_wort is None and any(_LIMIT_WORT.search(t) for t in texte):
                mit_wort = abs(zahl)
            if limit is None and zahl < 0:
                limit = abs(zahl)
        limit = mit_wort if mit_wort is not None else limit
        prozente = {p.replace(".", ",") for t in konditionen if not re.search(r"bereitstell|skonto", t, re.IGNORECASE)
                    for p in re.findall(r"(\d{1,2}(?:[.,]\d{1,3})?)\s*%", t)}
        zins = zu_zahl(prozente.pop()) if len(prozente) == 1 else None
        return {"limit_betrag": limit, "konditionen": " · ".join(konditionen) or None, "zins_pct": zins}

    def linie(self, quelle: str) -> dict:
        return {"bank": self.bank, "hersteller": self.hersteller, "linie": self.blatt.name, **self.fuss_lesen(),
                "zinsfrei_monate": None, "hinweis": None, "source_file": quelle}


def datum_de(iso) -> str:
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if iso else ""


# ------------------------------------------------------- Zu erwartende Zahlungen (Finanzaufstellung) ---
# Das erste Blatt der Finanzaufstellung ist der laufende Liquiditätsplan: Spalte A ein Text, B der Betrag (+ kommt
# herein, − geht hinaus), rechts daneben laufende Salden als Formeln, ganz rechts manchmal eine Bemerkung. Ganz oben
# stehen die zu erwartenden Zahlungen der Kunden – „<Kunde> <Modell> Finanzierung“ heißt: die Bank hat noch nicht
# an uns ausgezahlt; daneben „… Überweisung“, „… Anzahlung“. Eine Überschrift gibt es dort (noch) nicht. Steht
# irgendwann ein Block mit der Überschrift „zu erwartende Zahlungen“ in einer Mappe – mit oder ohne Spaltenköpfe –,
# wird nur dieser Block gelesen. Inzahlungnahmen („Inz. … (Wert)“ mit 0 €) und Auszahlungen sind kein Geldeingang.

_ERWARTET_KOPF = re.compile(r"^(zu)?erwartende?n?zahlung|^erwartetezahlung|^offenezahlung", re.IGNORECASE)
_ZAHLART = re.compile(r"\b(finanzierung|finanziert|bankfinanzierung|leasing|überweisung|ueberweisung|"
                      r"anzahlung|restzahlung|barzahlung|bar)\b", re.IGNORECASE)
_SUMME_ZEILE = re.compile(r"^\s*(summe|gesamt|zwischensumme|total)\b", re.IGNORECASE)
_EINGEGANGEN = re.compile(r"\b(bezahlt|eingegangen|ausgezahlt|erledigt|gutgeschrieben|überwiesen|ueberwiesen|"
                          r"erhalten)\b", re.IGNORECASE)
_NOCH_NICHT = re.compile(r"\b(nicht|noch nicht|kein|offen|fehlt|ausstehend)\b", re.IGNORECASE)
_TEXT_DATUM = re.compile(r"(?:\b(?:bis|ab|am|zum|ca\.?)\s+)?(?<![\d.])(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})?(?![\d])",
                         re.IGNORECASE)
_KLAMMER = re.compile(r"\(\s*-?[\d.,\s]+(?:€|eur)?\s*\)", re.IGNORECASE)
_ANREDE = re.compile(r"^(fam\.?|familie|herr|frau|hr\.?|fr\.?|kunde|kd\.?|firma)$", re.IGNORECASE)
# Spaltenköpfe, falls der Block eine Kopfzeile hat (normalisiert verglichen)
_ERWARTET_SPALTEN = {
    "kunde": ("Kunde", "Name", "Käufer", "Kundenname"),
    "fahrzeug": ("Fahrzeug", "Modell", "Kommission"),
    "internal_id": ("Interne Nr", "Interne ID", "Fahrzeug-ID", "Interne Nummer"),
    "bank": ("Bank", "Finanzierer", "Finanzierungsbank", "Institut"),
    "betrag": ("Betrag", "Auszahlung", "Auszahlungsbetrag", "Finanzierungsbetrag", "Summe Finanzierung", "Betrag €"),
    "erwartet": ("erwartet am", "erwartet", "Datum", "Termin", "Auszahlung am", "fällig", "fällig am", "Eingang"),
    "status": ("Status", "Stand"),
    "bemerkung": ("Bemerkung", "Bemerkungen", "Notiz", "Info", "Hinweis"),
    "art": ("Zahlungsart", "Art", "Zahlung"),
}


def _erwartet_ueberschrift(zeile) -> bool:
    texte = [t for t in (zu_text(w) for w in zeile if isinstance(w, str)) if t]
    return len(texte) == 1 and bool(_ERWARTET_KOPF.match(normalisiere(texte[0])))


def _erwartet_kopf(zeile) -> dict:
    """Spaltenköpfe des Blocks: {feld: spalte}, wenn mindestens zwei erkannt werden (sonst leer)."""
    kopf = [normalisiere(zu_text(w)) for w in zeile]
    spalten = {}
    for feld, namen in _ERWARTET_SPALTEN.items():
        for n in map(normalisiere, namen):
            if n in kopf and kopf.index(n) not in spalten.values():
                spalten[feld] = kopf.index(n)
                break
    return spalten if len(spalten) >= 2 and "betrag" in spalten else {}


def _bank_im_text(text: str):
    for k in sorted(_banken().get("banken", {}), key=len, reverse=True):
        if re.search(r"(?<![\w.])" + re.escape(k.rstrip(".")) + r"\.?(?!\w)", text, re.IGNORECASE):
            return _banken()["banken"][k], k
    return None, None


def _erwartet_datum(roh, heute: date):
    """(ISO-Datum oder None, Text wie in der Datei). Ein Datum ohne Jahr gehört ins nächste passende Jahr."""
    if roh is None:
        return None, None
    if isinstance(roh, (datetime, date)) or (isinstance(roh, (int, float)) and not isinstance(roh, bool)):
        iso = zu_datum(roh)                           # echtes Datum oder Excel-Seriennummer
        return iso, datum_de(iso) if iso else zu_text(roh)
    text = zu_text(roh)
    if not text:
        return None, None
    iso = zu_datum(text)
    if not iso:
        m = _TEXT_DATUM.search(text)
        if m:
            tag_, monat = int(m.group(1)), int(m.group(2))
            jahr = m.group(3)
            jahr = (int(jahr) + (2000 if len(jahr) == 2 else 0)) if jahr else _jahr_fuer(monat, heute)
            try:
                iso = date(jahr, monat, tag_).isoformat()
            except ValueError:
                iso = None
    if not iso:
        iso = grobes_datum(text, heute)
    return iso, text


def _kunde_und_fahrzeug(rest: str):
    """„Müller Vento 600“ → („Müller“, „Vento 600“); „Fam. Müller, Vento 600“ → („Fam. Müller“, „Vento 600“)."""
    rest = re.sub(r"\s+", " ", rest).strip(" ,;:-–/")
    if not rest:
        return None, None
    if "," in rest:
        kunde, _, fahrzeug = rest.partition(",")
        return kunde.strip() or None, fahrzeug.strip(" ,;") or None
    teile = rest.split(" ")
    n = 2 if len(teile) > 1 and _ANREDE.match(teile[0]) else 1
    return " ".join(teile[:n]), " ".join(teile[n:]) or None


def _bekannte_id(text):
    """Interne Nummer nur mit bekanntem Präfix – „Vento 600“ ist ein Modell, keine Nummer."""
    for m in _ID_MUSTER.finditer(str(text or "")):
        if praefix_info(m.group(1)):
            return normalize_internal_id(m.group(1) + m.group(2))
    return None


def _zahlungsart(text: str) -> str:
    t = (text or "").lower()
    if re.search(r"finanzier|leasing", t):
        return "Finanzierung"
    for wort, art in (("anzahlung", "Anzahlung"), ("restzahlung", "Restzahlung"), ("überweisung", "Überweisung"),
                      ("ueberweisung", "Überweisung"), ("bar", "Bar")):
        if re.search(r"\b" + wort, t):
            return art
    return "Zahlung"


def _erwartet_status(art: str, status_text, bemerkung):
    """(Status, offen). Eine Bemerkung wie „bezahlt“ oder „ausgezahlt 20.11.“ schließt die Zahlung – „noch nicht
    ausgezahlt“ nicht."""
    for t in (status_text, bemerkung):
        t = zu_text(t)
        if t and _EINGEGANGEN.search(t) and not _NOCH_NICHT.search(t):
            return "eingegangen", 0
    if status_text and zu_text(status_text):
        return zu_text(status_text), 1
    return ("Bank zahlt noch aus" if art == "Finanzierung" else "offen"), 1


class ErwarteteZahlungen:
    """Liest zu erwartende Zahlungen aus einem Blatt der Finanzaufstellung (siehe oben)."""

    def __init__(self, blatt, heute: date = None):
        self.blatt = blatt
        self.heute = heute or date.today()
        self.ueberschrift = next((i for i, z in enumerate(blatt.zeilen) if _erwartet_ueberschrift(z)), None)

    def _zeilen(self):
        """(Index, Kopf-Spalten) der Zeilen, die gelesen werden. Mit Überschrift: bis zur Summe, zwei Leerzeilen oder
        der nächsten Überschrift; ohne: das ganze Blatt."""
        b = self.blatt
        if self.ueberschrift is None:
            return [(i, {}) for i in range(len(b.zeilen))]
        start = self.ueberschrift + 1
        kopf = _erwartet_kopf(b.zeilen[start]) if start < len(b.zeilen) else {}
        if kopf:
            start += 1
        zeilen, letzte = [], b.zeilennr[start - 1]
        for i in range(start, len(b.zeilen)):
            nr = b.zeilennr[i]
            texte = [t for t in (zu_text(w) for w in b.zeilen[i] if isinstance(w, str)) if t]
            if nr - letzte > 2 or any(_SUMME_ZEILE.match(t) for t in texte[:2]) or _erwartet_ueberschrift(b.zeilen[i]):
                break
            if (len(texte) == 1 and not any(isinstance(w, (int, float)) and not isinstance(w, bool)
                                             for w in b.zeilen[i]) and texte[0].rstrip().endswith(":")):
                break                                  # nächste Zwischenüberschrift „Kosten:“
            zeilen.append((i, kopf))
            letzte = nr
        return zeilen

    def lesen(self, quelle: str, warn) -> list:
        mit_block = self.ueberschrift is not None
        ergebnis = []
        for i, kopf in self._zeilen():
            satz = self._kopfzeile(i, kopf, warn) if kopf else self._freitext(i, mit_block, warn)
            if satz:
                ergebnis.append({**satz, "source_file": quelle, "source_sheet": self.blatt.name,
                                 "zeile": self.blatt.zeilennr[i]})
        return ergebnis

    def _freitext(self, i: int, mit_block: bool, warn):
        b, nr = self.blatt, self.blatt.zeilennr[i]
        zeile = b.zeilen[i]
        j = next((j for j, w in enumerate(zeile) if isinstance(w, str) and zu_text(w)), None)
        if j is None:
            return None
        text = re.sub(r"\s+", " ", zu_text(zeile[j]))
        if _SUMME_ZEILE.match(text):
            return None
        # Betrag: die Zelle direkt rechts vom Text. Weiter rechts stehen die laufenden Salden – die dürfen bei leerem
        # Betrag nicht nachrutschen.
        roh = zeile[j + 1] if j + 1 < len(zeile) else None
        betrag = None if isinstance(roh, (bool, datetime, date)) else zu_zahl(roh)
        bemerkung = " · ".join(t for t in (zu_text(w) for w in zeile[j + 1:] if isinstance(w, str)) if t
                               and zu_zahl(t) is None) or None
        zahlart = _ZAHLART.search(text)
        if not mit_block and not zahlart:
            return None                               # Kosten, Zinsen, Bankbewegungen – keine Kundenzahlung
        rest = _KLAMMER.sub(" ", text)
        rest = _ZAHLART.sub(" ", rest)
        datum_treffer = _TEXT_DATUM.search(rest) or _KW.search(rest)          # „bis 12.12.“ oder „KW 50“
        erwartet_am, erwartet_text = (_erwartet_datum(datum_treffer.group(0), self.heute) if datum_treffer
                                      else (None, None))
        if datum_treffer:
            rest = rest[:datum_treffer.start()] + " " + rest[datum_treffer.end():]
        bank, kuerzel = _bank_im_text(rest)
        if kuerzel:
            rest = re.sub(r"(?<![\w.])" + re.escape(kuerzel.rstrip(".")) + r"\.?(?!\w)", " ", rest, count=1,
                          flags=re.IGNORECASE)
        rest = re.sub(r"\b(inz\.?|ex\.?)\b.*$", " ", rest, flags=re.IGNORECASE)    # „Inz. Hersteller8 (…)“ ist Ware
        if not re.search(r"[A-Za-zÄÖÜäöüß]{2,}", rest):
            return None                               # nur „Überweisung“ oder „EC“: Kasse, kein Kunde
        art = _zahlungsart(text)
        if betrag is None or betrag == 0:
            # ohne Betrag zählt nur, was ausdrücklich eine Zahlung ist (im Liquiditätsplan nur Finanzierungen –
            # „Inz. …“ und „Überweisung 0“ sind dort Platzhalter)
            if not zahlart or (not mit_block and art != "Finanzierung"):
                return None
            warn(f"Zeile {nr}: zu erwartende Zahlung ohne Betrag – steht ohne Summe in der Liste")
        elif betrag < 0:
            if mit_block:
                warn(f"Zeile {nr}: negativer Betrag – das ist eine Auszahlung, keine erwartete Zahlung")
            return None
        kunde, fahrzeug = _kunde_und_fahrzeug(rest)
        status, offen = _erwartet_status(art, None, bemerkung)
        return {"kunde": kunde, "fahrzeug": fahrzeug, "internal_id": _bekannte_id(text), "art": art, "bank": bank,
                "betrag": betrag if betrag else None, "erwartet_am": erwartet_am, "erwartet_text": erwartet_text,
                "status": status, "offen": offen, "bemerkung": bemerkung, "text": text}

    def _kopfzeile(self, i: int, kopf: dict, warn):
        b, nr = self.blatt, self.blatt.zeilennr[i]

        def feld(name):
            return b.wert(i, kopf[name]) if name in kopf else None
        kunde, fahrzeug = zu_text(feld("kunde")), zu_text(feld("fahrzeug"))
        if not kunde and not fahrzeug:
            return None
        betrag_roh = feld("betrag")
        betrag = zu_zahl(betrag_roh)
        if betrag is None:
            if zu_text(betrag_roh):
                warn(f"Zeile {nr}: Betrag „{zu_text(betrag_roh)}“ ist keine Zahl – steht ohne Summe in der Liste")
            else:
                warn(f"Zeile {nr}: zu erwartende Zahlung ohne Betrag – steht ohne Summe in der Liste")
        elif betrag < 0:
            warn(f"Zeile {nr}: negativer Betrag – das ist eine Auszahlung, keine erwartete Zahlung")
            return None
        erwartet_am, erwartet_text = _erwartet_datum(feld("erwartet"), self.heute)
        if erwartet_text and not erwartet_am:
            warn(f"Zeile {nr}: „{erwartet_text}“ ist kein Datum – steht unter „ohne Datum“")
        bank_roh = zu_text(feld("bank"))
        bank = (bank_name(bank_roh) or bank_roh) if bank_roh else _bank_im_text(f"{kunde or ''} {fahrzeug or ''}")[0]
        art_text = " ".join(x for x in (zu_text(feld("art")), zu_text(feld("status")), kunde, fahrzeug) if x)
        art = _zahlungsart(art_text)
        if art == "Zahlung" and bank_roh:
            art = "Finanzierung"
        bemerkung = zu_text(feld("bemerkung"))
        status, offen = _erwartet_status(art, feld("status"), bemerkung)
        text = " ".join(x for x in (kunde, fahrzeug) if x)
        return {"kunde": kunde, "fahrzeug": fahrzeug,
                "internal_id": (normalize_internal_id(zu_text(feld("internal_id"))) if zu_text(feld("internal_id"))
                                else _bekannte_id(text)),
                "art": art, "bank": bank, "betrag": betrag, "erwartet_am": erwartet_am, "erwartet_text": erwartet_text,
                "status": status, "offen": offen, "bemerkung": bemerkung, "text": text}


def ist_liquiditaetsblatt(blatt) -> bool:
    """Das erste Blatt der echten Finanzaufstellung: kein Spaltenkopf, Text in A, Betrag in B, laufende Salden."""
    return bool(re.search(r"finanzaufstellung|liquidit", blatt.name, re.IGNORECASE)) or any(
        isinstance(w, str) and "formelzeile" in w.lower() for z in blatt.zeilen[:10] for w in z)


# ------------------------------------------------------------------------------------- Listen-Import ---

# ------------------------------------------------------- Sonderfahrten in der Auslieferungsliste ---
# Zwischen den Übergaben stehen gelb hinterlegte Freitextzeilen ohne Status und ohne Kunden: Fahrten zu
# Werkstattpartnern („Mi. 25.11. Abgabe Di. 24.11. IVECO Langenhagen …“), Hinweise für einen Tag („Do. 10.12. KEINE
# AUSLIEFERUNGEN!!!“) und unter „Lehrgänge“ Schulungen mit Zeitraum. Die Liste ist in Blöcke je Woche geteilt
# („KW 47 November“, später „2026“, „2027“, „Lehrgänge“). Erkannt wird über den Aufbau, nicht über die Farbe.

_WOCHENTAGE = {"mo": 0, "di": 1, "mi": 2, "do": 3, "fr": 4, "sa": 5, "so": 6}
_FREI_DATUM = re.compile(r"(?:\b(mo|di|mi|do|fr|sa|so)[a-zä]*\.?,?\s*)?(?<![\d.])(\d{1,2})\.\s?(\d{1,2})\."
                         r"(?:\s?(\d{4}|\d{2})(?![\d:]))?", re.IGNORECASE)
_FREI_BIS = re.compile(r"\s*(?:-|–|bis)\s*(?:(?:mo|di|mi|do|fr|sa|so)[a-zä]*\.?\s*)?(\d{1,2})\.\s?(\d{1,2})\.",
                       re.IGNORECASE)
_BLOCK_KW = re.compile(r"^\s*kw\s*(\d{1,2})\b", re.IGNORECASE)
_BLOCK_JAHR = re.compile(r"^\s*(20\d{2})\s*$")
_BLOCK_LEHRGANG = re.compile(r"^\s*(lehrg(ä|ae)nge?|schulungen?)\s*:?\s*$", re.IGNORECASE)
_ABWESEND = re.compile(r"\burlaub|\bkrank|\babwesend", re.IGNORECASE)        # kommt aus dem Urlaubsplaner
_HINWEIS = re.compile(r"\bkeine\b.{0,30}\b(auslieferung|übergabe|uebergabe|termin)|!!", re.IGNORECASE)
_LEHRGANG = re.compile(r"lehrgang|schulung|seminar|training", re.IGNORECASE)


def _heute() -> dt.date:
    return dt.date.today()


def _plausibles_datum(tag: int, monat: int, wochentag, heute: dt.date, jahr=None, kw=None):
    """(Datum, pruefen) zu „Mi. 25.11.“: ohne Jahr das passende Jahr um heute – erst nach dem Wochentag, dann nach
    der Kalenderwoche des Blocks, dann am nächsten an heute. pruefen = Wochentag passt zu keinem Jahr."""
    jahre = [jahr] if jahr else [heute.year - 1, heute.year, heute.year + 1]
    daten = []
    for j in jahre:
        try:
            daten.append(dt.date(j, monat, tag))
        except ValueError:
            pass
    if not daten:
        return None, False
    pool, pruefen = daten, False
    if wochentag is not None:
        passend = [d for d in daten if d.weekday() == wochentag]
        pool, pruefen = (passend, False) if passend else (daten, True)
    if kw:
        nah = [d for d in pool if min(abs(d.isocalendar()[1] - kw), 53 - abs(d.isocalendar()[1] - kw)) <= 1]
        pool = nah or pool
    return min(pool, key=lambda d: abs((d - heute).days)), pruefen


def _montag_der_kw(kw: int, heute: dt.date, jahr=None):
    tage = []
    for j in ([jahr] if jahr else [heute.year - 1, heute.year, heute.year + 1]):
        try:
            tage.append(dt.date.fromisocalendar(j, kw, 1))
        except ValueError:
            pass
    return min(tage, key=lambda d: abs((d - heute).days)) if tage else None


def sonderfahrt_aus_text(text: str, heute: dt.date, block: dict = None, arbeitskarte=None):
    """Eine Freitextzeile als Termin {datum, bis, ganze_woche, kw, art, text, arbeitskarte, pruefen} – oder None,
    wenn sie nicht in „Heute & Woche“ gehört (Urlaub kommt aus dem Urlaubsplaner, ohne Datum und Woche kein Tag)."""
    block = block or {}
    text = " ".join(str(text or "").split())[:300]
    if len(text) < 3 or _ABWESEND.search(text):
        return None
    art = ("lehrgang" if block.get("lehrgang") or _LEHRGANG.search(text)
           else "hinweis" if _HINWEIS.search(text) else "sonderfahrt")
    satz = {"datum": None, "bis": None, "ganze_woche": 0, "kw": block.get("kw"), "art": art, "text": text,
            "arbeitskarte": arbeitskarte, "pruefen": 0}
    m = _FREI_DATUM.search(text)
    if m:
        wochentag = _WOCHENTAGE.get((m.group(1) or "").lower()[:2])
        jahr = block.get("jahr")
        if m.group(4):
            jahr = int(m.group(4)) + (2000 if len(m.group(4)) == 2 else 0)
        datum, pruefen = _plausibles_datum(int(m.group(2)), int(m.group(3)), wochentag, heute, jahr, block.get("kw"))
        if datum:
            satz["datum"], satz["pruefen"] = datum.isoformat(), int(pruefen)
            satz["kw"] = datum.isocalendar()[1]
            b = _FREI_BIS.match(text, m.end())
            if b:
                try:
                    ende = dt.date(datum.year, int(b.group(2)), int(b.group(1)))
                    if ende < datum:
                        ende = dt.date(datum.year + 1, ende.month, ende.day)
                    if (ende - datum).days <= 31:
                        satz["bis"] = ende.isoformat()
                except ValueError:
                    pass
            # Ein Datum vorne ist der Termin – im Titel steht dann der Rest
            if m.start() == 0 and len(text[m.end():].strip(" ,:-–")) >= 3 and not satz["bis"]:
                satz["text"] = text[m.end():].strip(" ,:-–")
            return satz
    if block.get("kw"):
        montag = _montag_der_kw(block["kw"], heute, block.get("jahr"))
        if montag:
            satz.update(datum=montag.isoformat(), bis=(montag + dt.timedelta(days=6)).isoformat(), ganze_woche=1)
            return satz
    return None


def _block_ueberschrift(text: str, block: dict) -> bool:
    """„KW 47 November“, „2026“, „Lehrgänge“: neuer Block; True, wenn die Zeile eine Überschrift war."""
    m = _BLOCK_KW.match(text)
    if m and 1 <= int(m.group(1)) <= 53:
        j = re.search(r"\b(20\d{2})\b", text)
        block.update(kw=int(m.group(1)), lehrgang=False, jahr=int(j.group(1)) if j else block.get("jahr_basis"))
        return True
    m = _BLOCK_JAHR.match(text)
    if m:
        block.update(kw=None, lehrgang=False, jahr=int(m.group(1)), jahr_basis=int(m.group(1)))
        return True
    if _BLOCK_LEHRGANG.match(text):
        block.update(kw=None, lehrgang=True, jahr=None)      # Lehrgänge stehen mit Datum, das Jahr kommt vom Datum
        return True
    return False


def _freitextzeile(b, i: int, spalten: dict):
    """(text, arbeitskarte) einer Zeile ohne Status, ohne Kunde und ohne Modell – sonst None."""
    for feld in ("customer", "model", "tank_text"):
        if feld in spalten and _hat_wert(b.wert(i, spalten[feld])):
            return None
    ohne = {spalten[f] for f in ("arbeitskarte", "geplante_minuten") if f in spalten}
    teile = []
    for j in range(b.breite):
        w = b.wert(i, j)
        if j in ohne or not _hat_wert(w) or isinstance(w, (datetime, date, bool)):
            continue
        if isinstance(w, (int, float)):
            if w == int(w) and 2000 <= w <= 2099:        # Blocküberschrift „2026“ als Zahl
                teile.append(str(int(w)))
            continue
        teile.append(" ".join(str(w).split()))
    text = " ".join(teile)
    if not re.search(r"[A-Za-zÄÖÜäöü]{2}", text) and not _BLOCK_JAHR.match(text):
        return None
    ak = zu_text(b.wert(i, spalten["arbeitskarte"])) if "arbeitskarte" in spalten else None
    return text, ak


def _hat_wert(w) -> bool:
    return w is not None and not (isinstance(w, str) and not w.strip())


def _ist_datum(w):
    if isinstance(w, (datetime, date)):
        return zu_datum(w)
    if isinstance(w, str) and re.fullmatch(r"\s*(\d{1,2}[./]\d{1,2}[./]\d{2,4}|\d{4}-\d{2}-\d{2})\s*", w):
        return zu_datum(w.strip())
    return None


def _ist_betrag(w):
    if isinstance(w, bool) or w is None or isinstance(w, (datetime, date)):
        return None
    if isinstance(w, (int, float)):
        return float(w) if w else None
    if isinstance(w, str) and re.search(r"\d", w) and not _ist_datum(w):
        n = zu_zahl(w)
        return n if n else None
    return None


def tilgungspaare(blatt, i: int, belegt: set) -> list:
    """Datums- und Betragspaare außerhalb der zugeordneten Spalten: [(fällig am, Betrag positiv), …]."""
    paare = []
    j, breite = 0, blatt.breite
    while j < breite - 1:
        if j in belegt or j + 1 in belegt:
            j += 1
            continue
        a, b = blatt.wert(i, j), blatt.wert(i, j + 1)
        datum, betrag = _ist_datum(a), _ist_betrag(b)
        if not (datum and betrag is not None):
            datum, betrag = _ist_datum(b), _ist_betrag(a)
        if datum and betrag is not None:
            paare.append((datum, round(abs(betrag), 2)))
            j += 2
        else:
            j += 1
    return paare


def _ausstattung(blatt, i: int, zuordnungen: list):
    """
    Text einer Ausstattungszeile oder None. Zwei Formen:
    - wie im Original: genau ein längerer Text in der ganzen Zeile (verbundene Zelle über die Breite);
    - echter Aufbau: von den zugeordneten Spalten ist nur Modell (Spalte B) gefüllt – lfd. Nr., Auftragsnr. und
      Interne ID sind leer. Andere Spalten (Formeln in P) dürfen Werte haben.
    """
    texte = list(dict.fromkeys(t for t in (zu_text(w) for w in blatt.zeilen[i]) if t))
    if len(texte) == 1:
        t = texte[0]
        if len(t) >= 15 and not extrahiere_id(t) and not re.fullmatch(r"[\d.,\s€%\-]+", t):
            return re.sub(r"\s+", " ", t)
    textfelder = {z.feld: z.spalte for z in zuordnungen if z.typ not in ("fuellfarbe", "schriftfarbe")}
    belegt = {f: blatt.wert(i, s) for f, s in textfelder.items() if _hat_wert(blatt.wert(i, s))}
    # Text in Spalte B (Modell) – oder, wenn die verbundene Zelle schon in A beginnt, ein langer Text in lfd. Nr.
    if not belegt or not set(belegt) <= {"model", "ausstattung", "lfd_nr"}:
        return None
    if not all(isinstance(w, str) for w in belegt.values()):
        return None
    texte = list(dict.fromkeys(w.strip() for w in belegt.values()))
    t = texte[0]
    if len(texte) != 1 or ("lfd_nr" in belegt and len(t) < 15):
        return None
    if extrahiere_id(t) or re.fullmatch(r"[\d.,\s€%\-]+", t):
        return None
    return re.sub(r"\s+", " ", t)


def _importiere_liste(lauf: _Lauf, pfad: str, mapping: dict):
    bericht = lauf.bericht
    ziel = mapping["ziel"]
    blaetter = lies_arbeitsmappe(pfad, mit_farben=True)
    aliase = alle_aliase(mapping)
    alle_regeln = regeln(mapping)
    if ziel == "financings":
        # Bankblätter zuerst: die Übersicht liefert danach nur noch, was dort fehlt
        blaetter.sort(key=lambda b: blatt_info(b.name)["bank"] is None)
    fehlend_gesamt = []
    vorbereitet = False

    for b in blaetter:
        if len(b.zeilen) < 2:
            continue
        info = blatt_info(b.name) if ziel == "financings" else _KEINE_INFO
        # Liquiditätsplan (erstes Blatt) oder ein Block „zu erwartende Zahlungen“: Kundenzahlungen, die noch kommen.
        # Die Überschrift zählt auch auf einem Blatt, das sonst als Auswertung übersprungen würde („Übersicht“).
        leser = ErwarteteZahlungen(b, lauf.heute) if ziel == "financings" and not info["bank"] else None
        if info["ueberspringen"] and not (leser and leser.ueberschrift is not None):
            lauf.hinweis(f"Blatt „{b.name}“: übersprungen (Auswertungsblatt)")
            continue
        k = finde_kopfzeile(b.zeilen, aliase)
        kopf = b.zeilen[k]
        zuordnungen, fehlend = ordne_spalten_zu(kopf, mapping)
        if leser is not None:
            if leser.ueberschrift is not None or ((len(zuordnungen) < 2 or fehlend) and ist_liquiditaetsblatt(b)):
                if not vorbereitet:
                    for t in NEBENTABELLEN.get(ziel, ()):
                        lauf.leere(t)
                    vorbereitet = True
                _erwartete_einlesen(lauf, b, leser, mapping)
                continue
        if len(zuordnungen) < 2:
            lauf.hinweis(f"Blatt „{b.name}“: keine passenden Spalten – übersprungen")
            continue
        if fehlend:
            namen = [alle_regeln[f]["quelle"][0] for f in fehlend]
            lauf.hinweis(f"Blatt „{b.name}“: Pflichtspalte fehlt – " + "; ".join(
                f"{alle_regeln[f]['quelle'][0]} (erwartet: {' / '.join(alle_regeln[f]['quelle'])})" for f in fehlend))
            fehlend_gesamt += [n for n in namen if n not in fehlend_gesamt]
            continue
        linienblatt = None
        if ziel == "financings" and info["bank"]:
            linienblatt = Linienblatt(b, k, zuordnungen, info, lauf.heute)
            zuordnungen = linienblatt.zuordnungen           # ggf. mit der Finanzierungsspalte „Nordbank“
        for z in zuordnungen:
            bericht["spalten_erkannt"].setdefault(z.feld, z.quelle)
        if not vorbereitet:
            # Nebentabellen dieser Datei einmal leeren – auch wenn die neue Fassung dort nichts mehr hat
            for t in NEBENTABELLEN.get(ziel, ()):
                lauf.leere(t)
            vorbereitet = True

        belegt = {z.spalte for z in zuordnungen}
        unbenutzt = [zu_text(kk) for j, kk in enumerate(kopf) if zu_text(kk) and j not in belegt]
        kopf_text = (f"Blatt „{b.name}“: Kopfzeile {b.zeilennr[k]}"
                     + (f", Bank aus dem Blattnamen: {info['bank']}" if info["bank"] else "")
                     + (f" ({info['hersteller']})" if info["hersteller"] else "")
                     + (f"; nicht verwendet: {', '.join(unbenutzt)}" if unbenutzt else ""))
        lauf.hinweis(kopf_text)

        warnungen = []
        zweifel = []
        saetze = []
        letztes = None                  # Fahrzeug direkt darüber – nur daran hängt eine Ausstattungszeile
        letzte_nr = None                # Excel-Zeile, die zuletzt zu diesem Fahrzeug gehörte
        uebersprungen_darueber = False
        kontext = {"kommission_spalte": any(z.feld == "kommission_roh" for z in zuordnungen)}
        termin_spalte = next((z.spalte for z in zuordnungen if z.feld == "planned_date"), None)
        spalten = {z.feld: z.spalte for z in zuordnungen}
        jahr_blatt = re.search(r"(20\d{2})", b.name)
        block = {"kw": None, "jahr": None, "lehrgang": False,
                 "jahr_basis": int(jahr_blatt.group(1)) if jahr_blatt else None}
        sonder = 0
        kommende = 0
        for i in range(k + 1, len(b.zeilen)):
            nr = b.zeilennr[i]
            if linienblatt is not None:
                zeilenart = linienblatt.zeilenart(i)
                if zeilenart == "fuss":
                    continue                    # Summe, Limit, Konditionen – liest fuss_lesen() am Ende
                if zeilenart == "kommend":
                    lauf.neben("kommende_fahrzeuge", linienblatt.kommend(i, warnungen.append, lauf.quelle))
                    kommende += 1
                    continue
            if ziel == "deliveries":
                frei = _freitextzeile(b, i, spalten)
                if frei:
                    if not _block_ueberschrift(frei[0], block):
                        termin = sonderfahrt_aus_text(frei[0], lauf.heute, block, frei[1])
                        if termin:
                            lauf.neben("sonderfahrten", {**termin, "source_file": lauf.quelle})
                            sonder += 1
                            if termin["pruefen"]:
                                warnungen.append(f"Zeile {nr}: Wochentag passt nicht zum Datum – bitte prüfen")
                    continue
            if ziel == "vehicles":
                zusatz = _ausstattung(b, i, zuordnungen)
                if zusatz:
                    if letztes is not None and nr == letzte_nr + 1:
                        letztes["ausstattung"] = f"{letztes['ausstattung']} {zusatz}" if letztes.get(
                            "ausstattung") else zusatz
                        letzte_nr = nr
                    elif not (uebersprungen_darueber and nr == letzte_nr + 1):
                        warnungen.append(f"Zeile {nr}: Text ohne Fahrzeug direkt darüber – übersprungen")
                    continue
            satz = zeile_zu_datensatz(b, i, zuordnungen, mapping.get("feste_werte"), zweifel)
            if ist_leer(satz):
                continue
            if info["bank"] and not satz.get("bank"):
                satz["bank"] = info["bank"]
            if info["hersteller"]:
                satz["blatt_hersteller"] = info["hersteller"]
            if linienblatt is not None:
                satz["linie"], satz["hersteller"] = b.name, linienblatt.hersteller
            if ziel == "financings":
                satz["_tilgungen"] = tilgungspaare(b, i, belegt)
            if termin_spalte is not None:
                satz["_termin_roh"] = b.wert(i, termin_spalte)
            fertig = lauf.nachbearbeiten(satz, mapping, warnungen.append, nr, b.name, kontext)
            if fertig:
                fertig["source_file"] = lauf.quelle
                saetze.append(fertig)
            letztes = fertig
            letzte_nr = nr
            uebersprungen_darueber = fertig is None

        warnungen += zweifel
        anzahl_saetze = len(saetze)
        if linienblatt is not None:
            linie = linienblatt.linie(lauf.quelle)
            schluessel = (linie["bank"], linie["hersteller"])
            if schluessel in lauf.linien:
                warnungen.append(f"dieselbe Linie ({linie['bank']} · {linie['hersteller']}) steht schon im Blatt "
                                 f"„{lauf.linien[schluessel]}“ – Limit und Konditionen gelten von dort")
            else:
                lauf.linien[schluessel] = b.name
                lauf.neben("bank_linien", linie)
            if linienblatt.finanzierungsspalte is None:
                warnungen.append("keine Spalte mit dem Finanzierungsbetrag (Finanzierung, S-Kredit oder Name der "
                                 "Bank)")
            elif linie["limit_betrag"] is None:
                warnungen.append("kein Limit gefunden (erwartet: negative Zahl unter der Summe in der Spalte "
                                 f"„{linienblatt.finanzierungsspalte}“)")
            limit = linie["limit_betrag"]
            lauf.hinweis(f"Blatt „{b.name}“: Linie {linie['bank']} · {linie['hersteller']}, "
                         + (f"Limit {limit:,.0f} €".replace(",", ".") if limit else "ohne Limit")
                         + f", {kommende} kommende Fahrzeuge")
        lauf.hinweis(f"Blatt „{b.name}“: {anzahl_saetze} Datenzeilen"
                     + (f", {sonder} Sonderfahrten, Hinweise und Lehrgänge" if sonder else "")
                     + (f", {len(warnungen)} Hinweise" if warnungen else ""))
        for w in warnungen:
            lauf.hinweis(f"Blatt „{b.name}“, {w}")
        geschrieben = lauf.schreibe(saetze, mapping)
        geschrieben += lauf.schreibe_nebenzeilen()
        bericht["blaetter"].append(b.name)
        bericht["zeilen_gelesen"] += anzahl_saetze + kommende
        bericht["zeilen_geschrieben"] += geschrieben
        lauf.import_lauf(mapping["name"], b.name, anzahl_saetze, geschrieben, warnungen)

    if not bericht["blaetter"]:
        bericht["spalten_fehlen"] = fehlend_gesamt
        bericht["fehler"] = (f"Kein Blatt passt zur Liste „{mapping['name']}“"
                             + (f" – es fehlen: {', '.join(fehlend_gesamt)}" if fehlend_gesamt else "")
                             + ". Fehlende Schreibweisen lassen sich in vorlagen/mappings ergänzen.")


def _erwartete_einlesen(lauf: _Lauf, b, leser: "ErwarteteZahlungen", mapping: dict):
    warnungen = []
    saetze = leser.lesen(lauf.quelle, warnungen.append)
    if not saetze and leser.ueberschrift is None:
        lauf.hinweis(f"Blatt „{b.name}“: Liquiditätsplan – keine zu erwartenden Kundenzahlungen erkannt")
        return
    for s in saetze:
        lauf.neben("erwartete_zahlungen", s)
    offen = [s for s in saetze if s["offen"]]
    bank = [s for s in offen if s["art"] == "Finanzierung"]
    lauf.hinweis(f"Blatt „{b.name}“: " + ("Block „zu erwartende Zahlungen“" if leser.ueberschrift is not None
                                          else "Liquiditätsplan")
                 + f", {len(saetze)} zu erwartende Zahlungen ({len(offen)} offen, davon {len(bank)} Finanzierungen, "
                   "die die Bank noch nicht ausgezahlt hat)")
    for w in warnungen:
        lauf.hinweis(f"Blatt „{b.name}“, {w}")
    geschrieben = lauf.schreibe_nebenzeilen()
    lauf.bericht["blaetter"].append(b.name)
    lauf.bericht["zeilen_gelesen"] += len(saetze)
    lauf.bericht["zeilen_geschrieben"] += geschrieben
    lauf.import_lauf(mapping["name"], b.name, len(saetze), geschrieben, warnungen)


# ------------------------------------------------------------------------------------- Teileliste ---

MOVERA_BASIS = "https://www.movera.com/DE/de/product/"
# Fette Zeilen ohne weitere Angaben sind Abschnitt, Produktüberschrift oder Anmerkung; Anmerkungen sind Sätze
ANMERKUNG = re.compile(r"\b(wird|werden|benötigt|benoetigt|muss|müssen|bitte|achtung|hinweis|nur bei|werksseitig|"
                       r"erforderlich|vorausgesetzt|beachten)\b", re.IGNORECASE)
_SPALTE = {b: i for i, b in enumerate("ABCDEFGHIJKLMNOPQR")}


def _ist_code(s) -> bool:
    return bool(s and re.fullmatch(r"[A-Z]{2,3}\d{4,6}", s.strip(), re.IGNORECASE))


def _stammblatt(wb):
    return (next((ws for ws in wb.worksheets if re.search("bestand", ws.title, re.IGNORECASE)), None)
            or next((ws for ws in wb.worksheets if ws.title == "M"), None))


def _teileblatt(wb, stamm):
    return (next((ws for ws in wb.worksheets if re.search("teileliste|einbau", ws.title, re.IGNORECASE)), None)
            or next((ws for ws in wb.worksheets if ws is not stamm and ws.title not in ("M", "Tabelle1")), None))


def _ist_gegliederte_teileliste(namen: list) -> bool:
    """Die echte Teileliste: Blatt „Teileliste“ und/oder Artikelstamm „Bestand (2)“ statt einer flachen Tabelle."""
    return any(re.search(r"teileliste|einbaukatalog|^bestand\b", n, re.IGNORECASE) for n in namen)


def _artikel_nr(wert):
    t = zu_text(wert)
    if not t:
        return None
    return t.lstrip("0") or t


def _lies_artikelstamm(lauf: _Lauf, ws) -> int:
    """Artikelstamm (rund 50.000 Zeilen): nur Werte, ohne Formate – sonst dauert es Minuten."""
    if hasattr(ws, "reset_dimensions"):
        ws.reset_dimensions()
    zeilen = []
    kopfwoerter = {"artikelnummer", "artikelnr", "nummer", "artnr"}
    for nr, z in enumerate(ws.iter_rows(min_row=1, max_col=5, values_only=True), start=1):
        if nr == 1 or not z:
            continue
        nummer = _artikel_nr(z[0])
        if not nummer or normalisiere(nummer) in kopfwoerter:
            continue
        werte = list(z) + [None] * (5 - len(z))
        zeilen.append((nummer, zu_text(werte[1]), zu_zahl(werte[2]) or 0, zu_zahl(werte[3]), zu_zahl(werte[4]),
                       lauf.quelle))
    lauf.db.executemany("INSERT OR REPLACE INTO artikelstamm (artikel_nr, bezeichnung, bestand, stamm_ek, stamm_vk, "
                        "source_file) VALUES (?,?,?,?,?,?)", zeilen)
    return len(zeilen)


def _lies_teileliste(lauf: _Lauf, ws, leser: Farbleser = None) -> tuple:
    """
    Einbaukatalog: Abschnitte je Fahrzeugtyp, darin Warengruppen mit Produkt, darunter Varianten mit Code.
    Felder mit „_“ vorn (Excel-Zeile, eigener Text, Füllfarbe der Bezeichnung, AW/Minuten der Zeile selbst) braucht
    nur die Stücklisten-Erkennung; sie kommen nicht in die Datenbank.
    """
    if hasattr(ws, "reset_dimensions"):
        ws.reset_dimensions()
    fahrzeugtyp = warengruppe = produkt = hinweis = None
    gruppen_minuten = gruppen_aw = None
    saetze = []
    abschnitte = gruppen = 0
    for nr, zellen in enumerate(ws.iter_rows(min_row=1, max_col=18), start=1):
        zellen = list(zellen) + [None] * (18 - len(zellen))
        werte = [getattr(z, "value", None) for z in zellen]
        if nr <= 5 or not any(_hat_wert(w) for w in werte):
            continue                                  # Kopf- und Parameterzeilen
        w = lambda s: werte[_SPALTE[s]]
        B, C, D = zu_text(w("B")), zu_text(w("C")), zu_text(w("D"))
        preise = [zu_zahl(w(s)) for s in "HIJP"]
        aw, minuten = zu_zahl(w("N")), zu_zahl(w("O"))
        hat_werte = any(p is not None for p in preise) or aw is not None or minuten is not None

        if not B and not C and D and not hat_werte:
            font = getattr(zellen[_SPALTE["D"]], "font", None)
            fett = bool(font is not None and font.b)
            if fett and len(D) <= 50:
                fahrzeugtyp, produkt, hinweis = D, None, None
                abschnitte += 1
            elif fett and ANMERKUNG.search(D):
                hinweis = D                         # gilt nur bis zur nächsten Warengruppe
            elif fett:
                produkt, hinweis = D, None          # lange Produktüberschrift
            continue
        if B and not _ist_code(B) and not C:
            # Warengruppe in B ohne Artikelnummer daneben; mit Nummer wäre B Fließtext einer Artikelzeile
            warengruppe, hinweis = B, None
            if D:
                produkt = D
            gruppen_aw, gruppen_minuten = aw, minuten
            gruppen += 1
            if not hat_werte:
                continue
        if not D and not C:
            continue
        artikel_nr = _artikel_nr(C) if C else None
        code = B.strip() if _ist_code(B) else None
        # Auch ohne Code ist ein eigener Text in D die Bezeichnung der Zeile – sonst hieße ein Fremdartikel oder eine
        # Stücklisten-Position wie das Produkt der Warengruppe (so war es im Original)
        variante = D if code or (D and D != produkt) else None
        link_wert = zu_text(w("E"))
        if artikel_nr and re.fullmatch(r"99\d+", artikel_nr):
            link = MOVERA_BASIS + artikel_nr        # Movera-Nummern beginnen mit 99 – so baut es auch die Datei
        elif link_wert and link_wert.startswith("http"):
            link = link_wert
        else:
            link = None
        brutto = zu_zahl(w("J"))
        brutto = brutto if brutto is not None else zu_zahl(w("I"))
        lohn_ek, teil_ek = zu_zahl(w("Q")), zu_zahl(w("P"))
        gesamt = zu_zahl(w("R"))
        if gesamt is None:
            # wie die Formel der Datei: WENN(ISTLEER(Q); I; P+Q) × 1,19
            basis = zu_zahl(w("I")) if lohn_ek is None else (teil_ek or 0) + lohn_ek
            gesamt = None if basis is None else round(basis * 1.19, 2)
        vk_pro_aw = zu_zahl(w("M"))
        fuellung = leser.fuellfarbe(getattr(zellen[_SPALTE["D"]], "fill", None)) if leser else None
        saetze.append({
            "sku": code or f"{lauf.quelle}-{nr}", "code": code, "artikel_nr": artikel_nr,
            "name": " – ".join(x for x in (produkt, variante) if x) or D or produkt or "ohne Bezeichnung",
            "fahrzeugtyp": fahrzeugtyp, "warengruppe": warengruppe, "produkt": produkt, "variante": variante,
            "category": warengruppe, "supplier": None, "movera_link": link, "gewicht": zu_text(w("G")),
            "set_preis": zu_zahl(w("H")), "preis_brutto": zu_zahl(w("I")), "einzelteil_vk": zu_zahl(w("J")),
            "kleinteile": zu_zahl(w("K")), "lohn_vk": zu_zahl(w("L")), "vk_pro_aw": vk_pro_aw,
            "aw": aw if aw is not None else gruppen_aw, "purchase_net": teil_ek,
            # J und I sind Bruttopreise und bleiben brutto – im Verkauf zählt brutto
            "sales_net": None if brutto is None else round(brutto / 1.19, 2), "vk_brutto": brutto,
            "lohn_ek": lohn_ek, "gesamt_ek_brutto": gesamt,
            "install_minutes": None if (minuten if minuten is not None else gruppen_minuten) is None
            else int(round(minuten if minuten is not None else gruppen_minuten)),
            "hinweis": hinweis,
            "hourly_rate": (vk_pro_aw if vk_pro_aw is not None else 12) * 10,   # VK je AW × 10 AW je Stunde
            "source_file": lauf.quelle, "source_sheet": ws.title, "zeile": nr,
            "_zeile": nr, "_text": D, "_aw_zeile": aw, "_minuten_zeile": minuten,
            "_fuellung": None if fuellung is None or ist_neutral(fuellung) else fuellung,   # weiß heißt: keine
        })
    return saetze, abschnitte, gruppen


# ---------------------------------------------------------------------------------- Stücklisten ---
# Ein Set (z. B. GIBAnet 5G) wird als ein Artikel verkauft; bestellt und kalkuliert werden muss es mit seinen
# Unterartikeln. In der Teileliste stehen die direkt unter dem Set, ohne eigenen Code, und ihre Artikelnummer setzt
# die des Sets fort: Giba1 (Set, Code SA09550) → Giba2, Giba3. Eine Mengenspalte hat die Liste nicht – Spalte F ist der
# Lagerbestand per Verweis auf den Artikelstamm –, also zählt jede Position einmal (so rechnet auch die Datei: der rote
# Preis in I ist Einzelteil-VK + Lohn + Kleinteile + je einmal der Preis der Positionen).

_LAUFNUMMER = re.compile(r"([A-Za-zÄÖÜäöüß]{2,})[\s._/-]*(\d{1,6})")
# Farbabstand, bis zu dem zwei Füllungen als dieselbe gelten: fängt Rundung zwischen Design- und RGB-Farbe ab, trennt
# aber schon „heller 60 %“ von „heller 40 %“ desselben Grüns (Abstand gut 8)
_GLEICHE_FARBE = 3


def _laufnummer(artikel_nr):
    """'Giba2' → ('giba', 2). Reine Ziffern (Movera 990012345) haben kein Präfix: (None, None)."""
    m = _LAUFNUMMER.fullmatch((artikel_nr or "").strip())
    return (m.group(1).lower(), int(m.group(2))) if m else (None, None)


def _gleich_hinterlegt(a, b) -> bool:
    return bool(a and b and farbabstand(a, b) < _GLEICHE_FARBE)


def _bezeichnung(satz) -> str:
    return satz["artikel_nr"] + (f" ({satz['code']})" if satz["code"] else "")


def _stuecklisten(lauf: _Lauf, saetze: list, blatt: str) -> tuple:
    """
    Hängt Stücklisten-Positionen an ihr Set (gehoert_zu = sku des Sets, menge = 1). Rückgabe (Sets, Positionen).
    Eine Zeile gehört nur dann zum Set darüber, wenn alles passt:
    - kein eigener Code – mit SA-Nummer ist sie ein eigener Artikel, den man auch allein verkauft;
    - ihre Artikelnummer hat das Buchstaben-Präfix der Set-Nummer, die laufende Nummer steigt;
    - sie steht direkt unter dem Set oder seiner letzten Position (keine Leer- oder Überschriftzeile dazwischen);
    - die Bezeichnung ist nicht anders hinterlegt als beim Set; hat das Set selbst keinen Code, muss sie sogar gleich
      hinterlegt sein – sonst sind es eher zwei Artikel mit ähnlichen Nummern.
    Passt nur ein Teil, bleibt die Zeile ein eigener Artikel und der Bericht sagt warum: lieber einmal nachsehen als
    still falsch kalkulieren.
    """
    kopf = kopf_praefix = None  # letzter Artikel mit Präfix-Nummer: an ihn würde angehängt
    sperre = None               # warum an diesen Kopf nichts mehr angehängt wird
    set_ende = set_zahl = None  # Excel-Zeile und laufende Nummer des Kopfs bzw. seiner letzten Position
    positionen = {}             # id(Kopf) → (Kopf, [Positionen])

    def hinweis(s, text):
        lauf.hinweis(f"Blatt „{blatt}“, Zeile {s['_zeile']}: {s['artikel_nr'] or s['_text'] or s['name']} {text}")

    for s in saetze:
        praefix, zahl = _laufnummer(s["artikel_nr"])
        direkt = set_ende is not None and s["_zeile"] == set_ende + 1
        fortsetzung = kopf is not None and praefix is not None and praefix == kopf_praefix
        neue_sperre = None
        if fortsetzung and not s["code"]:
            gruende = [sperre] if sperre else []
            if not direkt:
                gruende.append("steht nicht direkt darunter")
            if zahl <= set_zahl:
                gruende.append("die laufende Nummer steigt nicht")
            if s["_fuellung"] and kopf["_fuellung"] and not _gleich_hinterlegt(s["_fuellung"], kopf["_fuellung"]):
                gruende.append("die Bezeichnung ist anders hinterlegt")
            elif not kopf["code"] and not _gleich_hinterlegt(s["_fuellung"], kopf["_fuellung"]):
                gruende.append("das Set hat keinen eigenen Code und die Bezeichnungen sind nicht gleich hinterlegt")
            if not gruende:
                positionen.setdefault(id(kopf), (kopf, []))[1].append(s)
                set_ende, set_zahl = s["_zeile"], zahl
                continue
            hinweis(s, f"sieht nach einer Stücklisten-Position von {_bezeichnung(kopf)} aus, aber "
                       f"{', '.join(gruende)} – als eigener Artikel übernommen")
            neue_sperre = f"schon {s['artikel_nr']} darüber wurde nicht zugeordnet"
        elif fortsetzung and direkt and zahl > set_zahl:
            hinweis(s, f"setzt die Nummern von {_bezeichnung(kopf)} fort, hat aber einen eigenen Code – als eigener "
                       "Artikel geführt, nicht als Stücklisten-Position")
            neue_sperre = f"{_bezeichnung(s)} darüber hat einen eigenen Code"
        elif (direkt and id(kopf) in positionen and not s["code"]
              and _gleich_hinterlegt(s["_fuellung"], kopf["_fuellung"])):
            hinweis(s, f"ist hinterlegt wie das Set {_bezeichnung(kopf)} darüber, die Artikelnummer setzt dessen "
                       "Nummern aber nicht fort – als eigener Artikel übernommen")
        # Eine Zeile ohne Präfix-Nummer (z. B. Movera) beendet nur die Nähe zum Set; der Kopf bleibt bekannt, damit
        # eine spätere Zeile mit seiner Nummer einen Hinweis bekommt statt still ein eigener Artikel zu werden
        if praefix is not None:
            kopf, kopf_praefix, sperre = s, praefix, neue_sperre
            set_ende, set_zahl = s["_zeile"], zahl

    # Derselbe Code mehrfach (etwa in zwei Fahrzeugabschnitten): in der Datenbank bleibt die letzte Zeile. Hat sie
    # selbst eine Stückliste, gilt nur die; sonst bleibt die Stückliste des früheren Vorkommens am Code hängen.
    gilt = {}
    for kopf, liste in positionen.values():
        gilt[kopf["sku"]] = (kopf, liste)
    entfallen = set()
    for kopf, liste in positionen.values():
        if gilt[kopf["sku"]][0] is not kopf:
            entfallen.update(id(p) for p in liste)
            lauf.hinweis(f"Blatt „{blatt}“, Zeile {kopf['_zeile']}: {kopf['sku']} steht mehrfach in der Liste – es "
                         f"gilt die Stückliste aus Zeile {gilt[kopf['sku']][0]['_zeile']}")
    if entfallen:
        saetze[:] = [s for s in saetze if id(s) not in entfallen]

    for kopf, liste in gilt.values():
        for p in liste:
            p["gehoert_zu"], p["menge"] = kopf["sku"], 1.0
            p["name"] = p["_text"] or p["name"]                 # die eigene Bezeichnung, nicht die der Warengruppe
            # Die Montage steckt in den AW des Sets; eine Position erbt keine AW/Minuten der Warengruppe
            p["aw"] = p["_aw_zeile"]
            p["install_minutes"] = None if p["_minuten_zeile"] is None else int(round(p["_minuten_zeile"]))
            # Der Preis einer Position steht in der Spalte Set-Preis (H), Einzelteil-VK und Preis brutto sind leer
            if p["vk_brutto"] is None and p["set_preis"] is not None:
                p["vk_brutto"], p["sales_net"] = p["set_preis"], round(p["set_preis"] / 1.19, 2)
    return len(gilt), sum(len(liste) for _, liste in gilt.values())


def _importiere_teileliste(lauf: _Lauf, pfad: str):
    bericht = lauf.bericht
    wb = oeffne_mappe(pfad)
    try:
        stamm = _stammblatt(wb)
        stamm_zeilen = 0
        if stamm is not None:
            stamm_zeilen = _lies_artikelstamm(lauf, stamm)
            bericht["blaetter"].append(stamm.title)
            lauf.hinweis(f"Artikelstamm: {stamm_zeilen} Artikel aus Blatt „{stamm.title}“")
        teile = _teileblatt(wb, stamm)
        saetze, abschnitte, gruppen = [], 0, 0
        if teile is not None:
            saetze, abschnitte, gruppen = _lies_teileliste(lauf, teile, Farbleser(wb))
            sets, positionen = _stuecklisten(lauf, saetze, teile.title)
            for s in saetze:
                for hilfsfeld in [k for k in s if k.startswith("_")]:
                    del s[hilfsfeld]
            lauf.leere("parts")
            spalten = list(dict.fromkeys(k for s in saetze for k in s))
            lauf.db.executemany(
                f"INSERT OR REPLACE INTO parts ({', '.join(spalten)}) VALUES ({', '.join('?' * len(spalten))})",
                [[s.get(f) for f in spalten] for s in saetze])
            bericht["blaetter"].append(teile.title)
            mit_code = sum(1 for s in saetze if s["code"])
            mit_zeit = sum(1 for s in saetze if s["install_minutes"])
            lauf.hinweis(f"Teileliste: {len(saetze)} Positionen aus Blatt „{teile.title}“ ({abschnitte} Abschnitte, "
                         f"{gruppen} Warengruppen; {mit_code} mit Code, {mit_zeit} mit Montagezeit"
                         + (f"; {sets} Sets mit zusammen {positionen} Stücklisten-Positionen" if sets else "") + ")")
            bericht["spalten_erkannt"].update({"code": "B", "artikel_nr": "C", "name": "D", "aw": "N",
                                               "install_minutes": "O", "purchase_net": "P"})
        bericht["zeilen_gelesen"] = len(saetze) + stamm_zeilen
        bericht["zeilen_geschrieben"] = len(saetze) + stamm_zeilen
        lauf.import_lauf("teileliste", teile.title if teile is not None else (stamm.title if stamm else ""),
                         len(saetze), len(saetze) + stamm_zeilen,
                         [f"{abschnitte} Abschnitte, {gruppen} Warengruppen, {stamm_zeilen} Artikelstammzeilen"])
        if not saetze and not stamm_zeilen:
            bericht["fehler"] = "Weder Teileliste noch Artikelstamm gefunden."
    finally:
        wb.close()


# ---------------------------------------------------------------------------------- Art erkennen ---

def _bewerte(blaetter: list) -> dict:
    """Je Zuordnung die beste Trefferzahl (verschiedene Spalten) über alle Blätter."""
    ergebnis = {}
    for name in MAPPINGS:
        mapping = lade_mapping(name)
        aliase = alle_aliase(mapping)
        beste = 0
        for b in blaetter:
            if len(b.zeilen) < 2:
                continue
            kopf = b.zeilen[finde_kopfzeile(b.zeilen, aliase)]
            zuordnungen, _ = ordne_spalten_zu(kopf, mapping)
            beste = max(beste, len({z.spalte for z in zuordnungen}))
        ergebnis[name] = beste
    return ergebnis


def _teileliste_am_namen(namen) -> bool:
    return any(re.search(r"teileliste|einbaukatalog", n, re.IGNORECASE) for n in namen or [])


def _erkenne(blaetter: list):
    namen = [b.name for b in blaetter]
    if _teileliste_am_namen(namen):
        return "teilepreise"
    if any(re.search(r"urlaub", n, re.IGNORECASE) for n in namen) or any(urlaub.hat_tageszeile(b) for b in blaetter):
        return "urlaubsplaner"
    punkte = _bewerte(blaetter)
    bankblaetter = [b for b in blaetter if blatt_info(b.name)["bank"] and not blatt_info(b.name)["ueberspringen"]]
    if bankblaetter and punkte["finanzierungen"] >= 2 and _bewerte(bankblaetter)["finanzierungen"] >= 2:
        return "finanzierungen"
    beste = max(MAPPINGS, key=lambda n: punkte[n])
    if punkte[beste] >= 2:
        return beste
    if any(re.search(r"^bestand\b", n, re.IGNORECASE) for n in namen):
        return "teilepreise"                 # nur der Artikelstamm
    return None


def _erkenne_datei(pfad):
    if _teileliste_am_namen(blattnamen(pfad)):
        return "teilepreise"                 # ohne die 50.000 Zeilen des Artikelstamms anzufassen
    return _erkenne(lies_arbeitsmappe(pfad, mit_farben=False, max_zeilen=40))


def erkenne_art(pfad):
    """Listentyp aus Blattnamen und Spaltenköpfen; None, wenn nichts passt oder die Datei nicht lesbar ist."""
    try:
        return _erkenne_datei(pfad)
    except Exception:
        return None


# ----------------------------------------------------------------------------------------- Einstieg ---

def importiere(db, pfad, art=None, anzeigename=None) -> dict:
    """
    Liest eine Excel-Liste in die Tabellen von `db`. Bericht:
    {"art", "datei", "blaetter", "zeilen_gelesen", "zeilen_geschrieben", "hinweise", "spalten_erkannt",
     "spalten_fehlen", "fehler"}. Schlechte Daten ergeben Hinweise; eine unlesbare Datei ergibt „fehler“.
    """
    quelle = anzeigename or os.path.basename(str(pfad))
    bericht = _neuer_bericht(art, quelle)
    if art is not None and art not in ARTEN:
        bericht["fehler"] = f"Unbekannter Listentyp „{art}“ (möglich: {', '.join(ARTEN)})."
        return bericht
    if not os.path.isfile(str(pfad)):
        bericht["fehler"] = "Datei nicht gefunden."
        return bericht
    if str(pfad).lower().endswith(".xls"):
        bericht["fehler"] = "Alte .xls-Dateien kann ODIN nicht lesen – bitte in Excel einmal als .xlsx speichern."
        return bericht
    lauf = _Lauf(db, quelle, bericht)
    db.execute("SAVEPOINT cockpit_import")
    try:
        if art is None:
            art = _erkenne_datei(pfad)
            bericht["art"] = art
            if art is None:
                bericht["fehler"] = ("Listentyp nicht erkannt – keine bekannten Spaltennamen gefunden. "
                                     "Den Aufbau (ohne Werte) über „Aufbau speichern“ weitergeben.")
        if art == "urlaubsplaner":
            urlaub.importiere_urlaub(db, pfad, quelle, bericht, lauf.hinweis)
            lauf.import_lauf("urlaubsplaner", ", ".join(bericht["blaetter"]), bericht["zeilen_gelesen"],
                             bericht["zeilen_geschrieben"], bericht["hinweise"])
        elif art == "teilepreise" and _gegliedert(pfad):
            _importiere_teileliste(lauf, pfad)
        elif art is not None:
            _importiere_liste(lauf, pfad, lade_mapping(art))
        lauf.abschliessen()
        db.execute("RELEASE cockpit_import")
    except Exception as e:                      # ein Fehler im Import darf ODIN nicht anhalten
        db.execute("ROLLBACK TO cockpit_import")
        db.execute("RELEASE cockpit_import")
        if isinstance(e, UnlesbareDatei):
            bericht["fehler"] = f"Die Datei ließ sich nicht als Excel-Mappe öffnen ({e})."
        elif isinstance(e, PermissionError):
            bericht["fehler"] = "Die Datei ist gerade gesperrt (z. B. von Excel oder OneDrive). Gleich nochmal versuchen."
        else:
            bericht["fehler"] = f"Import abgebrochen: {type(e).__name__}: {e}"
    if db.in_transaction:
        db.commit()
    return bericht


def _gegliedert(pfad) -> bool:
    namen = blattnamen(pfad)
    if namen is None:
        wb = oeffne_mappe(pfad)
        try:
            namen = wb.sheetnames
        finally:
            wb.close()
    return _ist_gegliederte_teileliste(namen)
