"""
Vororder und Linienplanung – übernommen aus dem muster Cockpit (lib/vororder.ts).

Ein kommendes Fahrzeug (bestellt, noch nicht da – unten im Linienblatt der Finanzaufstellung) belastet ab seinem
groben Termin die Linie seiner Bank. Frei wird eine Linie erst, wenn das Fahrzeug verkauft und übergeben ist oder wenn
wir uns entscheiden, es abzulösen – automatisch passiert das nicht. Genau deshalb rechnet dieses Modul aus, bis wann
wie viel Kapital bereitstehen muss.

Früher wurden Vorordern in ODIN von Hand eingetragen. Diese Einträge bleiben lesbar (Anlegen, Ändern, Löschen gibt
es weiter), zählen aber nicht mehr für die Linien: Der Inhaber pflegt die kommenden Fahrzeuge in der
Finanzaufstellung. Geplante Ablösungen erfasst ODIN weiterhin selbst.
"""

import datetime as dt
import unicodedata

from .auswertungen import _alle, _eine, cash_series, js_runden, stichtag_oder_heute
from .db import normalize_internal_id

# Zählt eine Vororder noch mit? Stornierte nicht, gelieferte stehen schon im Bestand.
AKTIV = "status IN ('geplant','bestellt')"
STATUS = ["geplant", "bestellt", "geliefert", "storniert"]
ANNAHMEN = ("streng", "faellig")

_FELDER = ["bezeichnung", "hersteller", "bank", "kategorie", "anzahl", "ek_netto", "liefertermin", "status",
           "internal_id", "bemerkung"]


def _jetzt() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def _text(wert):
    """Leerzeichen weg, leerer Text wird zu None – wie `?.trim() || null` im Original."""
    if wert is None:
        return None
    s = str(wert).strip()
    return s or None


def _betrag(wert):
    """EK aus Zahl oder Text; deutscher Text wie '58.900' oder '58.900,50' wird verstanden."""
    if wert is None or wert == "":
        return None
    if isinstance(wert, (int, float)):
        return float(wert)
    s = str(wert).strip().replace("€", "").replace(" ", "")
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    elif s.count(".") >= 1 and len(s.rsplit(".", 1)[1]) == 3:
        s = s.replace(".", "")          # Tausenderpunkt
    try:
        return float(s)
    except ValueError:
        return None


def _iso_datum(wert, fehlertext):
    s = _text(wert)
    if not s:
        raise ValueError(fehlertext)
    try:
        return dt.date.fromisoformat(s[:10]).isoformat()
    except ValueError:
        raise ValueError(f"„{s}“ ist kein Datum (erwartet JJJJ-MM-TT).") from None


def _monatsende(ym: str) -> str:
    jahr, monat = (int(x) for x in ym.split("-"))
    naechster = dt.date(jahr + monat // 12, monat % 12 + 1, 1)
    return (naechster - dt.timedelta(days=1)).isoformat()


def _monate_ab(stichtag: str, anzahl: int) -> list:
    jahr, monat = int(stichtag[:4]), int(stichtag[5:7])
    ergebnis = []
    for i in range(anzahl):
        j, m = divmod(monat - 1 + i, 12)
        ergebnis.append(f"{jahr + j:04d}-{m + 1:02d}")
    return ergebnis


def _de(s) -> tuple:
    """Sortierschlüssel wie localeCompare('de'): Umlaute wie Grundbuchstaben, Groß/klein egal."""
    s = str(s or "")
    grund = unicodedata.normalize("NFKD", s.replace("ß", "ss"))
    grund = "".join(c for c in grund if not unicodedata.combining(c)).casefold()
    return grund, s


# ----------------------------------------------------------------------------- Vororder


def vorordern(db, nur_aktive=False) -> list:
    return _alle(db, f"SELECT * FROM vororder {'WHERE ' + AKTIV if nur_aktive else ''} "
                     "ORDER BY liefertermin, hersteller, bank, id")


def vororder_anlegen(db, bezeichnung, hersteller, bank, ek_netto, liefertermin, kategorie=None, anzahl=1,
                     status=None, internal_id=None, bemerkung=None) -> dict:
    """Legt eine Vororder an; fehlt etwas, das die Linienrechnung braucht, gibt es einen ValueError mit Klartext."""
    if not _text(bezeichnung):
        raise ValueError("Ohne Bezeichnung lässt sich keine Vororder anlegen.")
    if not _text(hersteller):
        raise ValueError("Ohne Hersteller weiß das System nicht, welche Linie belastet wird.")
    if not _text(bank):
        raise ValueError("Ohne Bank weiß das System nicht, welche Linie belastet wird.")
    ek = _betrag(ek_netto)
    if not ek:
        raise ValueError("Der geplante EK netto fehlt.")
    termin = _iso_datum(liefertermin, "Ohne Liefertermin lässt sich der Bedarf nicht einplanen.")
    try:
        stueck = max(1, int(anzahl or 1))
    except (TypeError, ValueError):
        stueck = 1
    cur = db.execute("""
        INSERT INTO vororder (bezeichnung,hersteller,bank,kategorie,anzahl,ek_netto,liefertermin,status,internal_id,
                              bemerkung,angelegt_am)
        VALUES (:bezeichnung,:hersteller,:bank,:kategorie,:anzahl,:ek_netto,:liefertermin,:status,:internal_id,
                :bemerkung,:angelegt_am)""", {
        "bezeichnung": _text(bezeichnung), "hersteller": _text(hersteller), "bank": _text(bank),
        "kategorie": _text(kategorie), "anzahl": stueck, "ek_netto": ek, "liefertermin": termin,
        "status": _text(status) or "geplant",
        "internal_id": normalize_internal_id(internal_id) if _text(internal_id) else None,
        "bemerkung": _text(bemerkung), "angelegt_am": _jetzt(),
    })
    db.commit()
    return _eine(db, "SELECT * FROM vororder WHERE id = ?", (cur.lastrowid,))


def vororder_aendern(db, vororder_id: int, aenderung: dict):
    """Ändert nur die übergebenen Felder; leerer Text löscht ein Feld. None, wenn nichts zu ändern war."""
    felder, args = [], {"id": vororder_id}
    for feld in _FELDER:
        if feld not in aenderung:
            continue
        wert = aenderung[feld]
        if wert == "":
            wert = None
        if feld == "ek_netto" and wert is not None:
            wert = _betrag(wert)
            if not wert:
                raise ValueError("Der geplante EK netto fehlt.")
        if feld == "liefertermin":
            wert = _iso_datum(wert, "Ohne Liefertermin lässt sich der Bedarf nicht einplanen.")
        if feld == "anzahl" and wert is not None:
            wert = max(1, int(wert))
        if feld in ("bezeichnung", "hersteller", "bank") and not _text(wert):
            raise ValueError(f"Das Feld „{feld}“ darf nicht leer sein – sonst ist die Linie unklar.")
        felder.append(f"{feld} = :{feld}")
        args[feld] = wert
    if not felder:
        return None
    db.execute(f"UPDATE vororder SET {', '.join(felder)} WHERE id = :id", args)
    db.commit()
    return _eine(db, "SELECT * FROM vororder WHERE id = ?", (vororder_id,))


def vororder_loeschen(db, vororder_id: int) -> bool:
    geloescht = db.execute("DELETE FROM vororder WHERE id = ?", (vororder_id,)).rowcount > 0
    db.commit()
    return geloescht


# --------------------------------------------------------------------------- Ablösungen


def abloesungen(db) -> list:
    return _alle(db, "SELECT * FROM abloesungen WHERE erledigt = 0 ORDER BY geplant_am, vehicle_internal_id")


def abloesung_planen(db, vehicle_internal_id, geplant_am, betrag=None, bank=None, grund=None) -> dict:
    """Merkt eine Ablösung vor (je Fahrzeug eine; erneutes Planen ersetzt die alte)."""
    if not _text(vehicle_internal_id):
        raise ValueError("Ohne Fahrzeug geht das nicht.")
    tag = _iso_datum(geplant_am, "Ohne Datum lässt sich die Ablösung nicht einplanen.")
    # Normalisiert statt nur groß geschrieben: „detkw182“ soll dieselbe Finanzierung treffen
    fid = normalize_internal_id(vehicle_internal_id)
    db.execute("""
        INSERT INTO abloesungen (vehicle_internal_id,bank,geplant_am,betrag,grund,erledigt,angelegt_am)
        VALUES (:vehicle_internal_id,:bank,:geplant_am,:betrag,:grund,0,:angelegt_am)
        ON CONFLICT(vehicle_internal_id) DO UPDATE SET
          bank = excluded.bank, geplant_am = excluded.geplant_am, betrag = excluded.betrag,
          grund = excluded.grund, erledigt = 0""", {
        "vehicle_internal_id": fid, "bank": _text(bank), "geplant_am": tag,
        "betrag": _betrag(betrag), "grund": _text(grund), "angelegt_am": _jetzt(),
    })
    db.commit()
    return _eine(db, "SELECT * FROM abloesungen WHERE vehicle_internal_id = ?", (fid,))


def abloesung_loeschen(db, vehicle_internal_id) -> bool:
    geloescht = db.execute("DELETE FROM abloesungen WHERE vehicle_internal_id = ?",
                           (normalize_internal_id(vehicle_internal_id),)).rowcount > 0
    db.commit()
    return geloescht


# ------------------------------------------------------------------------------ Belegung


def belegungen(db, stichtag=None, annahme="streng") -> list:
    """Was belegt die Linien – heute und in Zukunft.

    `annahme` steuert, wie großzügig gerechnet wird:
      "streng"  – frei wird nur, was verkauft und übergeben ist oder wofür eine Ablösung geplant ist.
      "faellig" – zusätzlich gilt das späteste Ablösedatum der Bank als Freigabe.
    Jeder Posten: quelle, schluessel, bezeichnung, bank, hersteller, betrag, ab (None = schon jetzt),
    frei_ab (None = bleibt belegt, bis abgelöst wird), freigabe_grund, zins_pct, zinsfrei_bis, faellig_am.
    """
    if annahme not in ANNAHMEN:
        raise ValueError(f"Unbekannte Annahme „{annahme}“ (streng oder faellig).")
    jetzt = stichtag_oder_heute(stichtag)
    # Übergabe als Unterabfrage: mehrere Auslieferungszeilen je Fahrzeug würden sonst den Vertrag mehrfach zählen.
    # Gibt es mehrere, gilt der späteste Termin – für die Kapitalplanung die vorsichtige Annahme.
    bestand = _alle(db, """
        SELECT f.vehicle_internal_id AS id, f.bank, f.financed_amount AS betrag, f.interest_rate_pct AS zins,
               f.interest_free_until AS zinsfrei, f.due_date AS faellig, f.contract_no,
               v.brand, v.model, v.category, v.status, f.hersteller AS linien_hersteller,
               (SELECT MAX(COALESCE(d.actual_date, d.planned_date)) FROM deliveries d
                WHERE d.vehicle_internal_id = f.vehicle_internal_id) AS uebergabe,
               v.sold_date,
               a.geplant_am AS abloese_am
        FROM financings f
        JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        LEFT JOIN abloesungen a ON a.vehicle_internal_id = f.vehicle_internal_id AND a.erledigt = 0
        WHERE f.status = 'offen'
        ORDER BY f.id""")

    posten = []
    for r in bestand:
        verkauft = r["status"] in ("Verkauft", "Ausgeliefert")
        uebergabe = (r["uebergabe"] or r["sold_date"]) if verkauft else None
        frei, grund = None, "bleibt belegt, bis abgelöst wird"
        if r["abloese_am"]:
            frei, grund = r["abloese_am"], "Ablösung geplant"
        elif uebergabe:
            frei, grund = uebergabe, "verkauft, Übergabe geplant"
        elif annahme == "faellig" and r["faellig"]:
            frei, grund = r["faellig"], "spätestes Ablösedatum der Bank"
        # Eine bereits fällige Ablösung in der Vergangenheit hilft nicht mehr
        if frei and frei < jetzt:
            frei = jetzt
        posten.append({
            "quelle": "bestand", "schluessel": r["id"],
            "bezeichnung": f"{r['brand'] or ''} {r['model'] or ''}".strip() or r["id"],
            "bank": r["bank"],
            "hersteller": r["linien_hersteller"] or ("Gebrauchtfahrzeuge" if r["category"] == "Gebrauchtwagen"
                                                     else (r["brand"] or "ohne Hersteller")),
            "betrag": r["betrag"] or 0, "ab": None, "frei_ab": frei, "freigabe_grund": grund,
            "zins_pct": r["zins"], "zinsfrei_bis": r["zinsfrei"], "faellig_am": r["faellig"],
        })

    # Kommende Fahrzeuge aus der Finanzaufstellung belasten die Linie ab ihrem (groben) Termin, ohne Termin sofort.
    # Von Hand eingetragene Vorordern zählen nicht mehr – sie stehen jetzt unten im Linienblatt.
    for k in _alle(db, "SELECT * FROM kommende_fahrzeuge WHERE betrag > 0 ORDER BY id"):
        wer = k["kunde"] or k["kommission_art"]
        posten.append({
            "quelle": "kommend", "schluessel": f"K{k['id']}",
            "bezeichnung": (k["modell"] or "Fahrzeug") + (f" ({wer})" if wer else ""),
            "bank": k["bank"], "hersteller": k["hersteller"],
            "betrag": k["betrag"], "ab": k["termin_datum"], "frei_ab": None,
            "freigabe_grund": "kommt noch – bleibt belegt, bis verkauft oder abgelöst",
            "zins_pct": None, "zinsfrei_bis": None, "faellig_am": None,
        })
    return posten


def _aktiv(posten: dict, tag: str) -> bool:
    return (posten["ab"] is None or posten["ab"] <= tag) and (posten["frei_ab"] is None or posten["frei_ab"] > tag)


# ---------------------------------------------------------------------------- Projektion


def linien_projektion(db, stichtag=None, monate=12, annahme="streng") -> list:
    """Belegung je Linie (Bank × Hersteller) Monat für Monat und der erste Tag, an dem sie überzogen wäre.

    Je Linie: bank, hersteller, limit_betrag, zins_pct, heute_belegt, monate [{monat, belegt, bestand, kommend,
    frei, auslastung, fehlbetrag}], eng_ab, eng_betrag, posten. Enge Linien stehen vorn.
    """
    jetzt = stichtag_oder_heute(stichtag)
    posten = belegungen(db, jetzt, annahme)
    alle = {}
    for linie in _alle(db, "SELECT bank, hersteller, limit_betrag, zins_pct FROM bank_linien ORDER BY id"):
        alle[(linie["bank"], linie["hersteller"])] = linie
    # Linien, die nur durch Bestand oder kommende Fahrzeuge vorkommen, trotzdem zeigen
    for p in posten:
        alle.setdefault((p["bank"], p["hersteller"]),
                        {"bank": p["bank"], "hersteller": p["hersteller"], "limit_betrag": None, "zins_pct": None})

    monatsliste = _monate_ab(jetzt, int(monate))
    letzter_tag = _monatsende(monatsliste[-1])
    ergebnis = []
    for linie in alle.values():
        limit = linie["limit_betrag"]
        meine = [p for p in posten if p["bank"] == linie["bank"] and p["hersteller"] == linie["hersteller"]]

        def summe(tag, quelle=None, meine=meine):
            return sum(p["betrag"] for p in meine if (not quelle or p["quelle"] == quelle) and _aktiv(p, tag))

        zeilen = []
        for m in monatsliste:
            tag = _monatsende(m)
            belegt = summe(tag)
            frei = None if limit is None else limit - belegt
            zeilen.append({
                "monat": m, "belegt": belegt, "bestand": summe(tag, "bestand"), "kommend": summe(tag, "kommend"),
                "frei": frei, "auslastung": js_runden(belegt / limit * 100) if limit else None,
                "fehlbetrag": -frei if frei is not None and frei < 0 else 0,
            })

        # Tagesgenau: an welchem Tag kippt die Linie zum ersten Mal?
        eng_ab, eng_betrag = None, 0
        if limit:
            wechsel = sorted({d for p in meine for d in (p["ab"], p["frei_ab"]) if d and jetzt <= d <= letzter_tag})
            for tag in [jetzt, *wechsel]:
                belegt = summe(tag)
                if belegt > limit:
                    eng_ab, eng_betrag = tag, belegt - limit
                    break

        ergebnis.append({
            "bank": linie["bank"], "hersteller": linie["hersteller"], "limit_betrag": limit,
            "zins_pct": linie["zins_pct"], "heute_belegt": summe(jetzt), "monate": zeilen,
            "eng_ab": eng_ab, "eng_betrag": eng_betrag,
            "posten": sorted(meine, key=lambda p: (p["ab"] or "", -p["betrag"])),
        })
    ergebnis.sort(key=lambda l: (0 if l["eng_ab"] else 1, -l["eng_betrag"], _de(l["bank"]), _de(l["hersteller"])))
    return ergebnis


# ----------------------------------------------------------------------- Handlungsbedarf


def linien_bedarf(db, stichtag=None, monate=12, annahme="streng") -> list:
    """Wo wird es eng, wann, und womit ließe sich Platz schaffen?

    Vorschlag: zuerst ablösen, was bereits Zinsen kostet, dann das Teuerste – so viele Verträge, bis der
    Fehlbetrag gedeckt ist. Dazu Linien desselben Herstellers mit Luft und der Planungssaldo des Monats.
    """
    jetzt = stichtag_oder_heute(stichtag)
    projektion = linien_projektion(db, jetzt, monate, annahme)
    liquiditaet = cash_series(db, jetzt, 0, int(monate))

    ergebnis = []
    for linie in projektion:
        if not linie["eng_ab"]:
            continue
        tag = linie["eng_ab"]
        kandidaten = []
        for p in linie["posten"]:
            if p["quelle"] != "bestand" or not _aktiv(p, tag) or p["frei_ab"] is not None:
                continue
            verzinst = bool(p["zinsfrei_bis"] and p["zinsfrei_bis"] <= tag)
            kandidaten.append({**p, "laeuft_verzinst": verzinst,
                               "zinskosten_monat": (p["betrag"] * ((p["zins_pct"] or 0) / 100)) / 12 if verzinst
                               else 0})
        kandidaten.sort(key=lambda k: (-int(k["laeuft_verzinst"]), -k["zinskosten_monat"], -k["betrag"]))

        vorschlag, gedeckt = [], 0
        for k in kandidaten:
            if gedeckt >= linie["eng_betrag"]:
                break
            vorschlag.append(k)
            gedeckt += k["betrag"]

        ausweich = []
        for x in projektion:
            if x["hersteller"] != linie["hersteller"] or x["bank"] == linie["bank"] or not x["limit_betrag"]:
                continue
            frei = x["limit_betrag"] - sum(p["betrag"] for p in x["posten"] if _aktiv(p, tag))
            if frei > 0:
                ausweich.append({"bank": x["bank"], "frei": frei})
        ausweich.sort(key=lambda a: -a["frei"])

        liq = next((c for c in liquiditaet if c["monat"] == tag[:7]), None)
        saldo = None
        if liq:
            saldo = liq["saldo_ist"] if liq["saldo_ist"] is not None else liq["saldo_plan"]
        ergebnis.append({
            "bank": linie["bank"], "hersteller": linie["hersteller"], "stichtag": tag,
            "fehlbetrag": linie["eng_betrag"], "limit_betrag": linie["limit_betrag"],
            "kandidaten": vorschlag, "gedeckt": gedeckt, "kapitalbedarf": sum(k["betrag"] for k in vorschlag),
            "ausweichlinien": ausweich, "liquiditaet_monat": saldo,
        })
    return ergebnis


def kommend_kennzahlen(db, stichtag=None) -> dict:
    """Kurzfassung für die Übersicht: kommende Fahrzeuge, ihr Volumen, der nächste Termin und die engen Linien."""
    v = _eine(db, """SELECT COUNT(*) anzahl, COALESCE(SUM(betrag),0) volumen, MIN(termin_datum) naechster
                     FROM kommende_fahrzeuge""")
    bedarf = linien_bedarf(db, stichtag)
    return {
        **v,
        "enge_linien": len(bedarf),
        "fehlbetrag": sum(b["fehlbetrag"] for b in bedarf),
        "frueheste_enge": min((b["stichtag"] for b in bedarf), default=None),
    }
