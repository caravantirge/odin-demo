"""
Auswertungen des Cockpits – übernommen aus dem muster Cockpit (lib/queries.ts).

Jede Funktion bekommt die Datenbank (sqlite3 mit Zeilen als sqlite3.Row) und, wo „heute“ eine Rolle spielt, den
Stichtag als ISO-Datum. Ohne Stichtag gilt der heutige Tag. Das Original rechnete mit date('now') und der Uhrzeit;
hier zählt der Stichtag ab Mitternacht, damit Ergebnisse reproduzierbar sind und „noch 3 Tage“ ganze Kalendertage
meint. Rückgabe sind schlichte dicts und Listen, die sich direkt als JSON an die Oberfläche geben lassen.

Die SQL-Abfragen sind bewusst fast wörtlich übernommen: so lässt sich jede Zahl mit dem Original vergleichen.
"""

import datetime as dt
import math
import re

from .db import normalize_internal_id, parameter

IN_STOCK = "('Bestand','Reserviert','Verkauft')"          # noch nicht übergeben
# Nur Fahrzeuge, die wirklich auf dem Hof stehen – bestellte zählen nicht zum Bestandswert.
ANGELIEFERT = "(lieferstatus IS NULL OR lieferstatus = 'angeliefert')"


def heute() -> str:
    return dt.date.today().isoformat()


def stichtag_oder_heute(stichtag=None) -> str:
    """ISO-Datum des Stichtags; prüft das Format, damit kein Tippfehler still „heute“ ergibt."""
    if not stichtag:
        return heute()
    return dt.date.fromisoformat(str(stichtag)[:10]).isoformat()


def js_runden(x) -> int:
    """Math.round wie im Original: ,5 rundet immer aufwärts (Pythons round() rundet zur geraden Zahl)."""
    unten = math.floor(x)
    return int(unten + 1 if x - unten >= 0.5 else unten)


def _alle(db, sql: str, args=()) -> list:
    return [dict(r) for r in db.execute(sql, args).fetchall()]


def _eine(db, sql: str, args=()):
    r = db.execute(sql, args).fetchone()
    return dict(r) if r is not None else None


# ------------------------------------------------------------------------------ Fahrzeuge


def list_vehicles(db, status=None, brand=None, category=None, jahrgang=None, lieferstatus=None, kommission=None,
                  search=None, limit=500) -> list:
    where, args = [], {}
    if status == "bestand":
        where.append(f"status IN {IN_STOCK}")
    elif status:
        where.append("status = :status")
        args["status"] = status
    if brand:
        where.append("LOWER(brand) = LOWER(:brand)")
        args["brand"] = brand
    if category:
        where.append("LOWER(category) = LOWER(:category)")
        args["category"] = category
    if jahrgang:
        where.append("jahrgang = :jahrgang")
        args["jahrgang"] = jahrgang
    if lieferstatus:
        where.append("COALESCE(lieferstatus,'angeliefert') = :lieferstatus")
        args["lieferstatus"] = lieferstatus
    if kommission:
        where.append("COALESCE(kommission_art,'Lager') = :kommission")
        args["kommission"] = kommission
    if search:
        where.append("(internal_id LIKE :q OR model LIKE :q OR customer LIKE :q OR vin LIKE :q)")
        args["q"] = f"%{search}%"
    sql = (f"SELECT * FROM vehicles {'WHERE ' + ' AND '.join(where) if where else ''} "
           f"ORDER BY arrival_date DESC LIMIT {min(int(limit or 500), 2000)}")
    return _alle(db, sql, args)


def get_vehicle(db, internal_id_roh):
    """Fahrzeug mit Finanzierungen, letzter Auslieferung und Provision – oder None."""
    fid = normalize_internal_id(internal_id_roh)
    fahrzeug = _eine(db, "SELECT * FROM vehicles WHERE internal_id = ?", (fid,))
    if not fahrzeug:
        return None
    return {
        "vehicle": fahrzeug,
        "financings": _alle(db, "SELECT * FROM financings WHERE vehicle_internal_id = ? ORDER BY start_date DESC",
                            (fid,)),
        "delivery": _eine(db, "SELECT * FROM deliveries WHERE vehicle_internal_id = ? ORDER BY planned_date DESC "
                              "LIMIT 1", (fid,)),
        "commission": _eine(db, "SELECT * FROM commissions WHERE vehicle_internal_id = ? LIMIT 1", (fid,)),
    }


def standtage(fahrzeug: dict, stichtag=None):
    """Tage seit Eingang; bei ausgelieferten Fahrzeugen bis zum Verkauf."""
    if not fahrzeug.get("arrival_date"):
        return None
    ende = (fahrzeug.get("sold_date") if fahrzeug.get("status") == "Ausgeliefert" and fahrzeug.get("sold_date")
            else stichtag_oder_heute(stichtag))
    tage = (dt.date.fromisoformat(ende[:10]) - dt.date.fromisoformat(fahrzeug["arrival_date"][:10])).days
    return max(0, tage)


def inventory_kpis(db, stichtag=None) -> dict:
    tag = stichtag_oder_heute(stichtag)
    bestand = _eine(db, f"""
        SELECT COUNT(*) AS anzahl,
               COALESCE(SUM(purchase_net + COALESCE(extra_cost_net,0)),0) AS bestandswert,
               COALESCE(AVG(julianday(:tag) - julianday(arrival_date)),0) AS avg_standtage
        FROM vehicles WHERE status IN {IN_STOCK} AND {ANGELIEFERT}""", {"tag": tag})
    bestellt = _eine(db, f"""
        SELECT COUNT(*) AS anzahl, COALESCE(SUM(purchase_net),0) AS wert
        FROM vehicles WHERE status IN {IN_STOCK} AND lieferstatus = 'geplant'""")
    fin = _eine(db, f"""
        SELECT COALESCE(SUM(f.financed_amount),0) AS offen, COUNT(*) AS vertraege
        FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        WHERE f.status = 'offen' AND v.status IN {IN_STOCK}""")
    zins_risiko = _eine(db, f"""
        SELECT COUNT(*) AS anzahl, COALESCE(SUM(f.financed_amount),0) AS volumen
        FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        WHERE f.status = 'offen' AND v.status IN {IN_STOCK}
          AND date(f.interest_free_until) <= date(:tag,'+60 day')""", {"tag": tag})
    provisionen = _eine(db, "SELECT COALESCE(SUM(amount),0) AS offen FROM commissions WHERE status = 'offen'")
    marge = _eine(db, """
        SELECT COALESCE(SUM(sold_net - purchase_net - COALESCE(extra_cost_net,0)),0) AS db_summe, COUNT(*) AS anzahl
        FROM vehicles WHERE sold_date IS NOT NULL AND date(sold_date) >= date(:tag,'start of year')""", {"tag": tag})
    return {
        "bestellt_anzahl": bestellt["anzahl"],
        "bestellt_wert": bestellt["wert"],
        "bestand_anzahl": bestand["anzahl"],
        "bestandswert": bestand["bestandswert"],
        "avg_standtage": js_runden(bestand["avg_standtage"]),
        "finanzierung_offen": fin["offen"],
        "finanzierung_vertraege": fin["vertraege"],
        "zinsfrei_ablauf_60t_anzahl": zins_risiko["anzahl"],
        "zinsfrei_ablauf_60t_volumen": zins_risiko["volumen"],
        "provisionen_offen": provisionen["offen"],
        "db_ytd": marge["db_summe"],
        "verkauft_ytd": marge["anzahl"],
    }


def count_stock(db, brand=None, category=None) -> dict:
    where, args = [f"status IN {IN_STOCK}", ANGELIEFERT], {}
    if brand:
        where.append("LOWER(brand) LIKE LOWER(:brand)")
        args["brand"] = f"%{brand}%"
    if category:
        where.append("LOWER(category) LIKE LOWER(:category)")
        args["category"] = f"%{category}%"
    return _eine(db, f"""
        SELECT COUNT(*) AS anzahl, COALESCE(SUM(purchase_net + COALESCE(extra_cost_net,0)),0) AS wert
        FROM vehicles WHERE {' AND '.join(where)}""", args)


def category_breakdown(db) -> list:
    return _alle(db, f"""
        SELECT COALESCE(category,'ohne Angabe') AS kategorie,
               COUNT(*) AS anzahl,
               COALESCE(SUM(CASE WHEN {ANGELIEFERT} THEN 1 ELSE 0 END),0) AS angeliefert,
               COALESCE(SUM(CASE WHEN lieferstatus = 'geplant' THEN 1 ELSE 0 END),0) AS bestellt,
               COALESCE(SUM(CASE WHEN {ANGELIEFERT} THEN purchase_net + COALESCE(extra_cost_net,0) ELSE 0 END),0)
                 AS wert
        FROM vehicles WHERE status IN {IN_STOCK}
        GROUP BY category ORDER BY wert DESC""")


def marke_und_kategorie(db) -> list:
    """Kreuztabelle Hersteller × Fahrzeugart – die Sicht, die im Alltag am häufigsten gebraucht wird."""
    return _alle(db, f"""
        SELECT COALESCE(brand,'ohne Marke') AS marke, COALESCE(category,'ohne Angabe') AS kategorie,
               COUNT(*) AS anzahl, COALESCE(SUM(purchase_net + COALESCE(extra_cost_net,0)),0) AS wert
        FROM vehicles WHERE status IN {IN_STOCK} AND {ANGELIEFERT}
        GROUP BY brand, category ORDER BY marke, kategorie""")


def jahrgaenge(db) -> list:
    return _alle(db, f"""
        SELECT jahrgang, COUNT(*) AS anzahl FROM vehicles
        WHERE jahrgang IS NOT NULL AND status IN {IN_STOCK} GROUP BY jahrgang ORDER BY jahrgang DESC""")


def brand_breakdown(db) -> list:
    return _alle(db, f"""
        SELECT COALESCE(brand,'ohne Marke') AS brand, COUNT(*) AS anzahl,
               COALESCE(SUM(purchase_net + COALESCE(extra_cost_net,0)),0) AS wert
        FROM vehicles WHERE status IN {IN_STOCK} AND {ANGELIEFERT}
        GROUP BY brand ORDER BY wert DESC""")


AGING_KLASSEN = [("0–90", 0, 90), ("91–180", 91, 180), ("181–270", 181, 270), ("271–365", 271, 365),
                 ("> 365", 366, 99999)]


def aging_buckets(db, stichtag=None) -> list:
    zeilen = _alle(db, f"""
        SELECT CAST(julianday(:tag) - julianday(arrival_date) AS INTEGER) AS tage,
               purchase_net + COALESCE(extra_cost_net,0) AS wert
        FROM vehicles WHERE status IN {IN_STOCK} AND {ANGELIEFERT} AND arrival_date IS NOT NULL""",
                   {"tag": stichtag_oder_heute(stichtag)})
    ergebnis = []
    for label, minimum, maximum in AGING_KLASSEN:
        treffer = [r for r in zeilen if r["tage"] is not None and minimum <= r["tage"] <= maximum]
        ergebnis.append({"bucket": label, "anzahl": len(treffer), "wert": sum(r["wert"] or 0 for r in treffer)})
    return ergebnis


# --------------------------------------------------------------------------- Finanzierung


def interest_free_expiring(db, stichtag=None, tage=90) -> list:
    return _alle(db, f"""
        SELECT f.vehicle_internal_id, f.bank, f.contract_no, f.financed_amount, f.interest_free_until,
               f.interest_rate_pct, f.due_date, v.brand, v.model, v.status,
               CAST(julianday(f.interest_free_until) - julianday(:tag) AS INTEGER) AS tage_bis_ablauf
        FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        WHERE f.status = 'offen' AND v.status IN {IN_STOCK}
          AND date(f.interest_free_until) <= date(:tag, '+' || :tage || ' day')
        ORDER BY f.interest_free_until ASC""", {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})


def financing_by_bank(db) -> list:
    return _alle(db, f"""
        SELECT f.bank, COUNT(*) AS vertraege, COALESCE(SUM(f.financed_amount),0) AS volumen
        FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        WHERE f.status = 'offen' AND v.status IN {IN_STOCK}
        GROUP BY f.bank ORDER BY volumen DESC""")


def interest_free_by_month(db, stichtag=None, monate=9) -> list:
    """Auslaufendes zinsfreies Volumen je Monat – Basis für die Ablöse-Planung."""
    return _alle(db, f"""
        SELECT strftime('%Y-%m', f.interest_free_until) AS monat,
               COUNT(*) AS anzahl, COALESCE(SUM(f.financed_amount),0) AS volumen
        FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        WHERE f.status = 'offen' AND v.status IN {IN_STOCK}
          AND date(f.interest_free_until) BETWEEN date(:tag,'start of month')
                                              AND date(:tag,'start of month','+' || :monate || ' month')
        GROUP BY monat ORDER BY monat""", {"tag": stichtag_oder_heute(stichtag), "monate": int(monate)})


# ----------------------------------------------------------------------------- Liquidität


def cash_series(db, stichtag=None, monate_zurueck=6, monate_voraus=6) -> list:
    """Monatsreihe: Ist bis zum laufenden Monat, danach Plan, dazu der laufende Saldo."""
    tag = stichtag_oder_heute(stichtag)
    args = {"tag": tag, "back": int(monate_zurueck), "fwd": int(monate_voraus)}
    zeilen = _alle(db, """
        SELECT strftime('%Y-%m', entry_date) AS monat, kind, direction, SUM(amount) AS summe
        FROM cash_entries
        WHERE date(entry_date) BETWEEN date(:tag,'start of month','-' || :back || ' month')
                                   AND date(:tag,'start of month','+' || :fwd || ' month')
        GROUP BY monat, kind, direction ORDER BY monat""", args)
    monate = sorted({r["monat"] for r in zeilen})
    saldo = _eine(db, """
        SELECT COALESCE(SUM(CASE WHEN direction='ein' THEN amount ELSE -amount END),0) AS saldo
        FROM cash_entries WHERE kind='ist' AND date(entry_date) < date(:tag,'start of month','-' || :back || ' month')
        """, args)["saldo"]

    summen = {(r["monat"], r["kind"], r["direction"]): r["summe"] for r in zeilen}
    laufender_monat = tag[:7]
    reihe = []
    for m in monate:
        def wert(art, richtung, m=m):
            return summen.get((m, art, richtung)) or 0
        ist_monat = m <= laufender_monat
        art = "ist" if ist_monat else "plan"
        netto = wert(art, "ein") - wert(art, "aus")
        saldo += netto
        reihe.append({
            "monat": m, "ein": wert(art, "ein"), "aus": wert(art, "aus"), "netto": netto,
            "saldo_ist": saldo if ist_monat else None, "saldo_plan": None if ist_monat else saldo, "ist": ist_monat,
        })
    return reihe


def cash_by_category(db, stichtag=None, art="ist") -> list:
    return _alle(db, """
        SELECT category, direction, SUM(amount) AS summe FROM cash_entries
        WHERE kind = :art AND date(entry_date) >= date(:tag,'start of month','-2 month')
        GROUP BY category, direction ORDER BY summe DESC""", {"art": art, "tag": stichtag_oder_heute(stichtag)})


# ---------------------------------------------------------- Provisionen und Auslieferungen


def commissions(db, status=None) -> list:
    sql = f"""SELECT c.*, v.brand, v.model FROM commissions c
              LEFT JOIN vehicles v ON v.internal_id = c.vehicle_internal_id
              {'WHERE c.status = :status' if status else ''}
              ORDER BY c.sale_date DESC LIMIT 500"""
    return _alle(db, sql, {"status": status} if status else {})


def commissions_by_salesperson(db) -> list:
    return _alle(db, """
        SELECT salesperson,
               COUNT(*) AS faelle,
               COALESCE(SUM(amount),0) AS gesamt,
               COALESCE(SUM(CASE WHEN status='offen' THEN amount ELSE 0 END),0) AS offen
        FROM commissions GROUP BY salesperson ORDER BY gesamt DESC""")


def upcoming_deliveries(db, stichtag=None, tage=45) -> list:
    return _alle(db, """
        SELECT d.*, v.brand, v.model, v.status AS fahrzeug_status
        FROM deliveries d LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
        WHERE d.actual_date IS NULL
          AND date(d.planned_date) <= date(:tag,'+' || :tage || ' day')
        ORDER BY d.planned_date ASC""", {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})


def all_deliveries(db) -> list:
    return _alle(db, """
        SELECT d.*, v.brand, v.model FROM deliveries d
        LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
        ORDER BY COALESCE(d.actual_date, d.planned_date) DESC LIMIT 300""")


# ------------------------------------------------------------------- Teile und Montage


def search_parts(db, q=None) -> list:
    sql = f"""SELECT * FROM parts {'WHERE name LIKE :q OR sku LIKE :q OR category LIKE :q' if q else ''}
              ORDER BY category, name LIMIT 300"""
    return _alle(db, sql, {"q": f"%{q}%"} if q else {})


def mit_lohn(teil: dict) -> dict:
    """Teil mit Lohnanteil (Montagezeit × Stundensatz) und Gesamtpreis, beides netto."""
    lohn = ((teil.get("install_minutes") or 0) / 60) * (teil.get("hourly_rate") or 0)
    return {**teil, "lohn_net": lohn, "gesamt_net": (teil.get("sales_net") or 0) + lohn}


def install_quote(db, q) -> list:
    """Gesamtpreis eines Einbaus für die ersten fünf Treffer: Teil + Montagezeit × Stundensatz (netto)."""
    return [mit_lohn(teil) for teil in search_parts(db, q)[:5]]


def import_runs(db) -> list:
    return _alle(db, "SELECT * FROM import_runs ORDER BY ran_at DESC LIMIT 50")


# -------------------------------------------------------------------- Auslieferungs-Ampel

TEILE_GUT = ["alle im Fahrzeug", "geliefert"]
TEILE_MITTEL = ["bestellt", "teilweise geliefert", "teilweise im Fahrzeug"]

# Je Übergabe genau ein Auslieferungsauftrag der Werkstatt: der mit dem Termin am nächsten an der Übergabe.
# Das Original verband alle Aufträge des Fahrzeugs und zeigte eine Übergabe dann mehrfach.
# Gewählt wird der Auftrag mit dem Termin am nächsten an der Übergabe (bei Gleichstand der ältere).
# Bewusst über MIN statt ORDER BY: SQLite 3.45 (so liefert es Windows-Python mit) kennt Spalten der äußeren
# Abfrage im ORDER BY einer Unterabfrage nicht („no such column“).
_ABSTAND = "COALESCE(ABS(julianday({w}.termin) - julianday(dd.planned_date)), 1e9)"
_UEBERGABEN_MIT_AUFTRAG = f"""(
        SELECT dd.*, (
            SELECT w2.id FROM werkstattauftraege w2
            WHERE w2.vehicle_internal_id = dd.vehicle_internal_id AND w2.art = 'Auslieferung'
              AND {_ABSTAND.format(w="w2")} = (
                SELECT MIN({_ABSTAND.format(w="w3")}) FROM werkstattauftraege w3
                WHERE w3.vehicle_internal_id = dd.vehicle_internal_id AND w3.art = 'Auslieferung')
            ORDER BY w2.id LIMIT 1
        ) AS auftrag_id
        FROM deliveries dd) d"""
_AUSLIEFERUNGSAUFTRAG = "LEFT JOIN werkstattauftraege w ON w.id = d.auftrag_id"


def auslieferungs_ampel(db, stichtag=None, tage=45) -> list:
    """Eine Zeile je anstehender Übergabe mit sechs Prüfpunkten.

    Was in der Excel-Liste über Farben gelesen wird, ist hier zählbar: wie viele Übergaben hängen an Teilen,
    wie viele am Geld.
    """
    zeilen = _alle(db, f"""
        SELECT d.*, v.brand, v.model,
               w.teilestatus, w.tankstatus, w.geplante_minuten, w.arbeitskarte, w.monteur,
               (SELECT COUNT(*) FROM einbauten e WHERE e.vehicle_internal_id = d.vehicle_internal_id
                  AND e.status <> 'erledigt') AS einbauten_offen,
               (SELECT COUNT(*) FROM einbauten e WHERE e.vehicle_internal_id = d.vehicle_internal_id)
                 AS einbauten_gesamt
        FROM {_UEBERGABEN_MIT_AUFTRAG}
        LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
        {_AUSLIEFERUNGSAUFTRAG}
        WHERE d.actual_date IS NULL AND date(d.planned_date) <= date(:tag, '+' || :tage || ' day')
        ORDER BY d.planned_date, d.id""", {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})

    bank = bank_zahlt_aus(db)
    ergebnis = []
    for r in zeilen:
        teile = str(r["teilestatus"] if r["teilestatus"] is not None else "unbekannt")
        offen_einbau, gesamt_einbau = int(r["einbauten_offen"] or 0), int(r["einbauten_gesamt"] or 0)
        punkte = [
            {"label": "Teile",
             "status": "gut" if teile in TEILE_GUT else "warnung" if teile in TEILE_MITTEL else "kritisch",
             "text": teile},
            {"label": "Papiere",
             "status": "gut" if r["papiere_status"] == "beim Kunden"
             else "warnung" if r["papiere_status"] == "bei uns" else "kritisch",
             "text": str(r["papiere_text"] or r["papiere_status"] or "offen")},
            {"label": "Zahlung",
             "status": "gut" if r["zahlstatus"] == "bezahlt" else "warnung" if r["zahlstatus"] == "angezahlt"
             else "kritisch",
             "text": f"{r['zahlart'] or '–'}: {r['zahlstatus'] or 'offen'}"},
            {"label": "Werkszahlung", "status": "gut" if r["werk_bezahlt"] else "warnung",
             "text": "ans Werk bezahlt" if r["werk_bezahlt"] else "ans Werk offen"},
            {"label": "TÜV", "status": "kritisch" if r["tuev_faellig"] else "gut",
             "text": "vor Übergabe fällig" if r["tuev_faellig"] else "nicht nötig"},
            {"label": "Einbauten",
             "status": "gut" if offen_einbau == 0 else "warnung" if offen_einbau < gesamt_einbau else "kritisch",
             "text": "keine" if gesamt_einbau == 0 else f"{offen_einbau} von {gesamt_einbau} offen"},
        ]
        bank_offen = r["zahlstatus"] != "bezahlt" and r["id"] in bank
        if bank_offen:
            next(p for p in punkte if p["label"] == "Zahlung")["text"] += " · Bank zahlt noch aus"
        ergebnis.append({
            "id": r["id"], "vehicle_internal_id": str(r["vehicle_internal_id"]), "bank_zahlt_aus": bank_offen,
            "planned_date": str(r["planned_date"]), "customer": str(r["customer"] or "–"), "city": str(r["city"] or ""),
            "verkaeufer": r["verkaeufer"], "status": str(r["status"] or ""),
            "brand": r["brand"], "model": r["model"], "bemerkung": r["bemerkung"],
            "punkte": punkte, "offen": sum(1 for p in punkte if p["status"] != "gut"),
        })
    return ergebnis


def ampel_kennzahlen(db, stichtag=None, tage=45) -> dict:
    zeilen = auslieferungs_ampel(db, stichtag, tage)

    def zaehle(label):
        return sum(1 for z in zeilen if next(p for p in z["punkte"] if p["label"] == label)["status"] != "gut")

    return {
        "anzahl": len(zeilen),
        "ohne_befund": sum(1 for z in zeilen if z["offen"] == 0),
        "teile": zaehle("Teile"),
        "zahlung": zaehle("Zahlung"),
        "papiere": zaehle("Papiere"),
        "einbauten": zaehle("Einbauten"),
    }


# --------------------------------------------------------------------- Kalenderwochen


def montag_von(tag) -> dt.date:
    t = dt.date.fromisoformat(str(tag)[:10]) if not isinstance(tag, dt.date) else tag
    return t - dt.timedelta(days=t.weekday())


def kalenderwoche(tag) -> int:
    """ISO-Kalenderwoche."""
    t = dt.date.fromisoformat(str(tag)[:10]) if not isinstance(tag, dt.date) else tag
    return t.isocalendar()[1]


def abwesenheiten_kommend(db, stichtag=None, tage=56) -> list:
    return _alle(db, """
        SELECT mitarbeiter, MIN(datum) AS von, MAX(datum) AS bis, COUNT(*) AS tage, art
        FROM abwesenheiten
        WHERE art = 'Urlaub' AND datum BETWEEN date(:tag) AND date(:tag,'+' || :tage || ' day')
        GROUP BY mitarbeiter, art, strftime('%Y-%W', datum) ORDER BY von, mitarbeiter""",
                 {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})


# ------------------------------------------------------- Tilgungen und Zulassungsfristen


def tilgungen_faellig(db, stichtag=None, tage=90) -> list:
    return _alle(db, """
        SELECT t.*, v.brand, v.model, v.status AS fahrzeug_status,
               CAST(julianday(t.faellig_am) - julianday(:tag) AS INTEGER) AS tage_bis
        FROM tilgungen t LEFT JOIN vehicles v ON v.internal_id = t.vehicle_internal_id
        WHERE t.bezahlt_am IS NULL AND date(t.faellig_am) <= date(:tag,'+' || :tage || ' day')
        ORDER BY t.faellig_am, t.id""", {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})


def tilgungen_je_monat(db, stichtag=None, monate=9) -> list:
    return _alle(db, """
        SELECT strftime('%Y-%m', faellig_am) AS monat, COUNT(*) AS anzahl, COALESCE(SUM(betrag),0) AS betrag
        FROM tilgungen WHERE bezahlt_am IS NULL
          AND date(faellig_am) BETWEEN date(:tag,'start of month')
                                   AND date(:tag,'start of month','+' || :monate || ' month')
        GROUP BY monat ORDER BY monat""", {"tag": stichtag_oder_heute(stichtag), "monate": int(monate)})


def tilgungen_im_monat(db, monat: str) -> list:
    """Alle Raten eines Monats ('2026-10'), bezahlte eingeschlossen – für die Frage „Was ist im Oktober fällig?“."""
    return _alle(db, """
        SELECT t.*, v.brand, v.model, v.status AS fahrzeug_status
        FROM tilgungen t LEFT JOIN vehicles v ON v.internal_id = t.vehicle_internal_id
        WHERE strftime('%Y-%m', t.faellig_am) = :monat
        ORDER BY t.faellig_am, t.id""", {"monat": monat})


def zulassungsfristen(db, stichtag=None, tage=180) -> list:
    return _alle(db, f"""
        SELECT z.*, v.brand, v.model, v.status, v.purchase_net, v.lieferstatus,
               CAST(julianday(z.frist) - julianday(:tag) AS INTEGER) AS tage_bis
        FROM zulassungsfristen z JOIN vehicles v ON v.internal_id = z.vehicle_internal_id
        WHERE z.frist IS NOT NULL AND v.status IN {IN_STOCK}
          AND date(z.frist) <= date(:tag,'+' || :tage || ' day')
        ORDER BY z.frist, z.id""", {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})


def fahrzeug_zusatz(db, internal_id) -> dict:
    fid = normalize_internal_id(internal_id)
    return {
        "einbauten": _alle(db, "SELECT * FROM einbauten WHERE vehicle_internal_id = ? ORDER BY position", (fid,)),
        "tilgungen": _alle(db, "SELECT * FROM tilgungen WHERE vehicle_internal_id = ? ORDER BY faellig_am", (fid,)),
        "frist": _eine(db, "SELECT * FROM zulassungsfristen WHERE vehicle_internal_id = ?", (fid,)),
    }


# ------------------------------------------------------------ Auslieferungen als Raster
# Alle Felder einer Übergabe nebeneinander, so dicht wie in der Excel-Liste.


def auslieferungs_raster(db, stichtag=None, tage=60) -> list:
    def einbau(position, feld="status"):
        return (f"(SELECT {feld} FROM einbauten e WHERE e.vehicle_internal_id = d.vehicle_internal_id "
                f"AND e.position = '{position}')")

    zeilen = _alle(db, f"""
        SELECT d.id, d.vehicle_internal_id, d.planned_date, d.uhrzeit, d.status, d.customer, d.city, d.verkaeufer,
               d.termin_art, d.fahrzeugart, d.verfuegbarkeit, COALESCE(d.tuev_faellig,0) AS tuev_faellig,
               d.papiere_status, d.papiere_text, d.zahlart, d.zahlstatus, d.anzahlung,
               d.inzahlungnahme_fzg, d.inzahlungnahme_wert, d.inzahlungnahme_da,
               COALESCE(d.werk_bezahlt,0) AS werk_bezahlt, d.bemerkung, d.vertragsdatum,
               v.brand, v.model, v.category AS kategorie,
               w.arbeitskarte, w.geplante_minuten, w.teilestatus, w.tankstatus, w.monteur,
               {einbau('AHK starr')} AS ahk_starr,
               {einbau('AHK abnehmbar')} AS ahk_abnehmbar,
               {einbau('Unterboden & Hohlraum')} AS unterboden,
               {einbau('Sondereinbau')} AS sondereinbau,
               {einbau('Sondereinbau', 'beschreibung')} AS sondereinbau_text
        FROM {_UEBERGABEN_MIT_AUFTRAG}
        LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
        {_AUSLIEFERUNGSAUFTRAG}
        WHERE d.actual_date IS NULL AND date(d.planned_date) <= date(:tag,'+' || :tage || ' day')
        ORDER BY d.planned_date, d.id""", {"tag": stichtag_oder_heute(stichtag), "tage": int(tage)})
    bank = bank_zahlt_aus(db)
    for z in zeilen:
        z["bank_zahlt_aus"] = z["zahlstatus"] != "bezahlt" and z["id"] in bank
    return zeilen


# ------------------------------------------------------------ Zu erwartende Zahlungen
# Aus der Finanzaufstellung (erstes Blatt): Geld, das noch hereinkommt. Wichtig sind die Kundenfinanzierungen, bei
# denen die Bank noch nicht an uns ausgezahlt hat. Zur Übergabe gehört eine Zahlung über die interne Nummer oder den
# Kundennamen – die Finanzaufstellung nennt meist nur den Nachnamen, die Auslieferungsliste „Fam. Müller“.

_ANREDEN = {"fam", "familie", "herr", "frau", "hr", "fr", "kunde", "kd", "firma", "und", "gmbh"}


def _namensteile(text) -> set:
    return {w for w in re.findall(r"[a-zäöüß]{2,}", str(text or "").lower()) if w not in _ANREDEN}


def _gleiche_person(kunde, customer) -> bool:
    k, c = _namensteile(kunde), _namensteile(customer)
    return bool(k) and bool(c) and (k <= c or c <= k)


def _offene_uebergaben(db) -> list:
    return _alle(db, """
        SELECT d.id, d.vehicle_internal_id, d.planned_date, d.customer, d.zahlstatus, v.model
        FROM deliveries d LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
        WHERE d.actual_date IS NULL AND LOWER(COALESCE(d.status,'')) <> 'ausgeliefert'
        ORDER BY d.planned_date, d.id""")


def _uebergabe_zu(zahlung: dict, uebergaben: list):
    """Die offene Übergabe, zu der eine erwartete Zahlung gehört (oder None)."""
    if zahlung.get("internal_id"):
        treffer = [u for u in uebergaben if u["vehicle_internal_id"]
                   and normalize_internal_id(u["vehicle_internal_id"]) == zahlung["internal_id"]]
        if treffer:
            return treffer[0]
    treffer = [u for u in uebergaben if _gleiche_person(zahlung.get("kunde"), u["customer"])]
    if len(treffer) > 1 and zahlung.get("fahrzeug"):          # zwei Kunden gleichen Namens: das Modell entscheidet
        modell = _namensteile(zahlung["fahrzeug"])
        treffer = [u for u in treffer if modell & _namensteile(u["model"])] or treffer
    return treffer[0] if treffer else None


def erwartete_zahlungen(db, stichtag=None) -> list:
    """
    Alle zu erwartenden Zahlungen, offene zuerst, mit der passenden Übergabe. Zwei Regeln aus dem Betrieb:
    – Ist in der Auslieferungsliste die Zahlung grün (VDR bezahlt), gilt die Zahlung als eingegangen, auch wenn die
      Zeile in der Finanzaufstellung noch steht.
    – Steht kein Datum dabei, gilt das geplante Übergabedatum als „erwartet ab“ (die Bank zahlt um die Übergabe aus).
    """
    tag = stichtag_oder_heute(stichtag)
    zeilen = _alle(db, """
        SELECT id, kunde, fahrzeug, internal_id, art, bank, betrag, erwartet_am, erwartet_text, status, offen,
               bemerkung, source_sheet, zeile
        FROM erwartete_zahlungen
        ORDER BY offen DESC, erwartet_am IS NULL, erwartet_am, id""")
    uebergaben = _offene_uebergaben(db) if zeilen else []
    for z in zeilen:
        u = _uebergabe_zu(z, uebergaben)
        z["uebergabe"] = ({"vehicle_internal_id": u["vehicle_internal_id"], "planned_date": u["planned_date"],
                           "customer": u["customer"]} if u else None)
        if z["offen"] and u and u.get("zahlstatus") == "bezahlt":
            z["offen"], z["status"] = 0, "bezahlt (Auslieferungsliste grün)"
        z["erwartet_ab"] = None if z["erwartet_am"] else (u["planned_date"] if u and u.get("planned_date") else None)
        z["ueberfaellig"] = bool(z["offen"] and z["erwartet_am"] and z["erwartet_am"] < tag)
    zeilen.sort(key=lambda z: (not z["offen"], (z["erwartet_am"] or z["erwartet_ab"] or "9999"), z["id"]))
    return zeilen


def erwartete_kennzahlen(db, zeilen=None) -> dict:
    """Summen der offenen Zahlungen: alle und nur die Finanzierungen, die die Bank noch nicht ausgezahlt hat."""
    offen = [z for z in (zeilen if zeilen is not None else erwartete_zahlungen(db)) if z["offen"]]
    fin = [z for z in offen if z["art"] == "Finanzierung"]
    return {"anzahl": len(offen), "summe": sum(z["betrag"] or 0 for z in offen),
            "finanzierungen": len(fin), "finanzierung_summe": sum(z["betrag"] or 0 for z in fin)}


def bank_zahlt_aus(db) -> set:
    """Ids der offenen Übergaben, deren Zahlung über eine Finanzierung läuft, die die Bank noch nicht ausgezahlt hat."""
    offen = _alle(db, "SELECT kunde, fahrzeug, internal_id FROM erwartete_zahlungen "
                      "WHERE offen = 1 AND art = 'Finanzierung'")
    if not offen:
        return set()
    uebergaben = _offene_uebergaben(db)
    return {u["id"] for u in (_uebergabe_zu(z, uebergaben) for z in offen)
            if u and u.get("zahlstatus") != "bezahlt"}


# -------------------------------------------------------------------- Kreditlinien je Bank

# Für die Linien zählt der Hersteller; Gebrauchte laufen als eigene Gruppe. Kommt die Finanzierung aus einem
# Linienblatt der Finanzaufstellung, steht der Hersteller schon an ihr („Nord. Gebr.“ → Gebrauchtfahrzeuge).
HERSTELLER_AUSDRUCK = "CASE WHEN v.category = 'Gebrauchtwagen' THEN 'Gebrauchtfahrzeuge' ELSE v.brand END"
LINIEN_HERSTELLER = f"COALESCE(f.hersteller, {HERSTELLER_AUSDRUCK})"


def bank_linien(db) -> list:
    """
    Je Linie (Bank × Hersteller): Limit, genutzt (offene Finanzierungen), kommend (bestellte Fahrzeuge aus der
    Finanzaufstellung) und frei = Limit − genutzt − kommend (negativ = überzogen; ohne Limit None).
    """
    linien = _alle(db, f"""
        SELECT bl.bank, bl.hersteller, bl.linie, bl.konditionen, bl.zins_pct, bl.zinsfrei_monate, bl.limit_betrag,
               bl.hinweis,
               COALESCE((SELECT SUM(f.financed_amount) FROM financings f
                         JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
                         WHERE f.status = 'offen' AND f.bank = bl.bank
                           AND {LINIEN_HERSTELLER} = bl.hersteller), 0) AS genutzt,
               COALESCE((SELECT COUNT(*) FROM financings f
                         JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
                         WHERE f.status = 'offen' AND f.bank = bl.bank
                           AND {LINIEN_HERSTELLER} = bl.hersteller), 0) AS vertraege,
               COALESCE((SELECT SUM(k.betrag) FROM kommende_fahrzeuge k
                         WHERE k.bank = bl.bank AND k.hersteller = bl.hersteller), 0) AS kommend,
               (SELECT COUNT(*) FROM kommende_fahrzeuge k
                WHERE k.bank = bl.bank AND k.hersteller = bl.hersteller) AS kommend_anzahl
        FROM bank_linien bl ORDER BY bl.bank, bl.hersteller""")
    for linie in linien:
        limit = linie["limit_betrag"]
        linie["frei"] = None if limit is None else round(limit - linie["genutzt"] - linie["kommend"], 2)
    return linien


def linien_ohne_zuordnung(db) -> list:
    """Finanzierungen, die zu keiner hinterlegten Linie passen – sonst fallen sie unter den Tisch."""
    return _alle(db, f"""
        SELECT f.bank, {LINIEN_HERSTELLER} AS hersteller,
               COUNT(*) AS vertraege, COALESCE(SUM(f.financed_amount),0) AS genutzt
        FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
        WHERE f.status = 'offen'
          AND NOT EXISTS (SELECT 1 FROM bank_linien bl
                          WHERE bl.bank = f.bank AND bl.hersteller = {LINIEN_HERSTELLER})
        GROUP BY f.bank, hersteller ORDER BY genutzt DESC""")


def kommende_fahrzeuge(db) -> list:
    """Bestellte Fahrzeuge je Linie, nach grobem Termin (ohne Termin zuletzt)."""
    return _alle(db, """
        SELECT id, bank, hersteller, linie, kommission, kommission_art, kunde, internal_id, modell, termin_text,
               termin_datum, konditionen, betrag, ek_netto
        FROM kommende_fahrzeuge
        ORDER BY termin_datum IS NULL, termin_datum, bank, hersteller, id""")


# ---------------------------------------------------------------- Teile und Einbaukatalog


# Stücklisten-Positionen (parts.gehoert_zu) erscheinen im Katalog nur unter ihrem Set, nicht als eigene Einträge.
# Zeigt gehoert_zu ins Leere (Set fehlt oder ist selbst eine Position), bleibt die Zeile ein eigener Eintrag –
# verschwinden darf nichts.
_IM_KATALOG = """(p.gehoert_zu IS NULL OR NOT EXISTS (
    SELECT 1 FROM parts k WHERE k.sku = p.gehoert_zu AND k.gehoert_zu IS NULL))"""


def _stuecklisten(db, skus: list) -> dict:
    """sku des Sets → Positionen [{sku, code, artikel_nr, name, menge, ek, vk, bestand, movera_link}]."""
    if not skus:
        return {}
    ergebnis = {}
    for i in range(0, len(skus), 500):                   # SQLite kennt höchstens 999 Platzhalter je Abfrage
        teil = skus[i:i + 500]
        for r in db.execute(f"""
                SELECT p.gehoert_zu, p.sku, p.code, p.artikel_nr, p.name, p.menge, p.movera_link,
                       COALESCE(p.purchase_net, a.stamm_ek) AS ek, COALESCE(p.vk_brutto, a.stamm_vk) AS vk,
                       a.bestand
                FROM parts p LEFT JOIN artikelstamm a ON a.artikel_nr = p.artikel_nr
                WHERE p.gehoert_zu IN ({', '.join('?' * len(teil))})
                ORDER BY p.id""", teil):
            ergebnis.setdefault(r["gehoert_zu"], []).append({
                "sku": r["sku"], "code": r["code"], "artikel_nr": r["artikel_nr"], "name": r["name"],
                "menge": r["menge"] if r["menge"] is not None else 1, "ek": r["ek"], "vk": r["vk"],
                "bestand": r["bestand"], "movera_link": r["movera_link"]})
    return ergebnis


def _mit_stueckliste(teil: dict, positionen: list) -> dict:
    """
    Katalogeintrag mit Stückliste und Summen. Ohne Stückliste sind die Summen None. Die Datei rechnet die Eigenkosten
    nur aus dem EK des Set-Artikels (R = (P + Q) × 1,19) – die mitbestellten Positionen fehlen dort; set_ek und
    set_eigenkosten_brutto zählen sie mit.
    """
    teil.pop("gehoert_zu", None)
    teil.pop("menge", None)
    teil.pop("zeile", None)                     # Excel-Zeile braucht nur „In ODIN arbeiten“, nicht die Oberfläche
    teil["stueckliste"] = positionen
    if not positionen:
        teil.update(stueckliste_vk=None, set_ek=None, set_eigenkosten_brutto=None)
        return teil
    ek = sum(p["menge"] * (p["ek"] or 0) for p in positionen)
    eigener_ek = teil.get("purchase_net") if teil.get("purchase_net") is not None else teil.get("stamm_ek")
    set_ek = (eigener_ek or 0) + ek
    teil["stueckliste_vk"] = round(sum(p["menge"] * (p["vk"] or 0) for p in positionen), 2)
    teil["set_ek"] = round(set_ek, 2)
    teil["set_eigenkosten_brutto"] = round((set_ek + (teil.get("lohn_ek") or 0)) * parameter()["mwst"], 2)
    return teil


def teile_katalog(db, suche=None, warengruppe=None, fahrzeugtyp=None, nur_bestand=False) -> list:
    """
    Katalog mit Lagerbestand und Stammpreisen aus der Artikelverwaltung. Jeder Eintrag trägt seine Stückliste
    (leere Liste, wenn keine); die Suche findet ein Set auch über Name oder Nummer einer seiner Positionen.
    """
    where, args = [_IM_KATALOG], {}
    if suche:
        felder = ("name", "code", "artikel_nr")
        where.append("(p.name LIKE :q OR p.code LIKE :q OR p.artikel_nr LIKE :q OR p.warengruppe LIKE :q "
                     "OR p.produkt LIKE :q OR p.fahrzeugtyp LIKE :q OR EXISTS (SELECT 1 FROM parts s "
                     "WHERE s.gehoert_zu = p.sku AND (" + " OR ".join(f"s.{f} LIKE :q" for f in felder) + ")))")
        args["q"] = f"%{suche}%"
    if warengruppe:
        where.append("p.warengruppe = :wg")
        args["wg"] = warengruppe
    if fahrzeugtyp:
        where.append("p.fahrzeugtyp = :ft")
        args["ft"] = fahrzeugtyp
    if nur_bestand:
        where.append("COALESCE(a.bestand,0) > 0")
    teile = _alle(db, f"""
        SELECT p.*, a.bestand, a.stamm_ek, a.stamm_vk
        FROM parts p LEFT JOIN artikelstamm a ON a.artikel_nr = p.artikel_nr
        WHERE {' AND '.join(where)}
        ORDER BY p.id LIMIT 1200""", args)
    stuecklisten = _stuecklisten(db, [t["sku"] for t in teile if t["sku"] is not None])
    return [_mit_stueckliste(t, stuecklisten.get(t["sku"], [])) for t in teile]


def katalog_filter(db) -> dict:
    # Gleich häufige Gruppen in derselben Reihenfolge wie im Original (SQLite liefert sie dort absteigend).
    # Gezählt wird wie im Katalog: ein Set einmal, seine Positionen nicht mit.
    return {
        "gruppen": _alle(db, f"SELECT warengruppe, COUNT(*) n FROM parts p WHERE warengruppe IS NOT NULL "
                             f"AND {_IM_KATALOG} GROUP BY warengruppe ORDER BY n DESC, warengruppe DESC"),
        "typen": _alle(db, f"SELECT fahrzeugtyp, COUNT(*) n FROM parts p WHERE fahrzeugtyp IS NOT NULL "
                           f"AND {_IM_KATALOG} GROUP BY fahrzeugtyp ORDER BY n DESC, fahrzeugtyp DESC"),
    }


def katalog_kennzahlen(db) -> dict:
    teile = _eine(db, f"""
        SELECT COUNT(*) AS positionen,
               COUNT(DISTINCT warengruppe) AS gruppen,
               COUNT(DISTINCT COALESCE(typ_neu, fahrzeugtyp)) AS typen,
               COALESCE(AVG(hourly_rate),0) AS satz,
               COALESCE(SUM(install_minutes),0) AS minuten
        FROM parts p WHERE {_IM_KATALOG}""")
    stamm = _eine(db, """
        SELECT COUNT(*) AS artikel, COALESCE(SUM(CASE WHEN bestand > 0 THEN 1 ELSE 0 END),0) AS mit_bestand,
               COALESCE(SUM(bestand * COALESCE(stamm_ek,0)),0) AS lagerwert
        FROM artikelstamm""")
    return {**teile, **stamm}


# ---------------------------------------------------------------- Tages- und Wochenübersicht
# Alles, was zu tun ist und ein Datum hat, an einer Stelle: Übergaben, Bemerkungen dazu, Zulassungen, Fristen,
# To-dos, Cashback, wer fehlt – und für Finanz-Berechtigte Tilgungen, Zinsfrei-Enden, Ablösungen und Vororder.
# Werkstatttermine nicht: Werkstattaufträge laufen über CaraCamp.
# Der Zeitraum reicht von Montag dieser Woche bis Sonntag der nächsten, damit die Oberfläche zwischen „Heute“,
# „Diese Woche“ und „Nächste Woche“ umschalten kann, ohne neu zu rechnen. Überfälliges kommt getrennt dazu.

AGENDA_RUECKBLICK = 30      # so weit zurück zählt Unerledigtes als überfällig; Älteres ist meist nur nicht gepflegt
AGENDA_MIT_ERLEDIGT = ("uebergabe", "zulassung", "tilgung", "abloesung", "frist", "todo", "betrieb", "cashback",
                       "zahlung")
# Punkte mit Geldbeträgen der Finanzierung: nur für Personen, die Finanzzahlen sehen dürfen
AGENDA_FINANZEN = ("tilgung", "zinsfrei", "abloesung", "vororder", "zahlung")
# Freitexte aus der Auslieferungsliste: Beträge darin („Rest offen 17.380“) sehen nur Finanz-Berechtigte
AGENDA_FREITEXT = ("uebergabe", "bemerkung", "zulassung", "sonderfahrt", "hinweis", "lehrgang")
_BETRAG = re.compile(r"(?:€|EUR|Euro)\s*\d[\d.,]*"
                     r"|(?<![\w.,:/-])\d{1,3}(?:\.\d{3})+(?:,\d{1,2}|,-)?(?:\s*(?:€|EUR|Euro)\b|\s*€)?(?![\w.,]?\d)"
                     r"|(?<![\w.,:/-])\d+(?:,\d{1,2})?\s*(?:€|EUR\b|Euro\b|,-)"
                     r"|(?<![\w.,:/-])(?<!AK )(?<!Nr\. )(?<!Nr )(?!(?:19|20)\d{2}(?!\d|,\d))\d{4,}(?:,\d{1,2})?(?![\w.,:]?\d)(?![\w.])")


def betraege_ausblenden(text):
    """„Rest offen 17.380“ → „Rest offen …“. Daten („18.11.“), Uhrzeiten, Jahreszahlen und Fahrgestellnummern
    bleiben stehen."""
    return _BETRAG.sub("…", text) if isinstance(text, str) else text
ZULASSUNG_VORLAUF = 7       # so viele Tage vor der Übergabe erscheint „Zulassung besorgen“
BEMERKUNG_VORLAUF = 2       # so viele Tage vor der Übergabe erscheint ihre Bemerkung als eigener Punkt


def agenda_ohne_finanzen(g: dict) -> dict:
    """Dieselbe Übersicht ohne Tilgungen, Zinsfrei-Enden, Ablösungen und Vororder – und ohne Beträge in den
    Freitexten der Auslieferungsliste."""
    termine = []
    for p in g.get("termine") or []:
        if p.get("art") in AGENDA_FINANZEN:
            continue
        if p.get("art") in AGENDA_FREITEXT:
            p = {**p, "titel": betraege_ausblenden(p.get("titel")), "text": betraege_ausblenden(p.get("text"))}
        termine.append(p)
    return {**g, "termine": termine}


def papiere_fehlen(status, text) -> str:
    """Was für die Zulassung noch fehlt, oder "" wenn nichts. Die Auslieferungsliste färbt das Feld
    „Fahrzeugpapiere“: grün = beim Kunden (erledigt), gelb = bei uns (Zulassung machen), orange = im Werk
    (Brief anfordern). Ohne Farbe hilft der Text: „Brief Kunde 14.09.“ ist erledigt, „Brief wir“ nicht."""
    status = str(status or "").strip().lower()
    text = " ".join(str(text or "").split())
    if status == "beim kunden":
        return ""
    if status == "im werk":
        return "Brief noch im Werk" + (f" ({text})" if text else "")
    if status == "bei uns":
        return "Brief liegt bei uns" + (f" ({text})" if text else "")
    t = text.lower()
    if not t or re.search(r"\bkunde|\bkd\b|zugelassen|erledigt", t):
        return ""                                     # ohne Farbe und Text wissen wir es nicht – lieber nichts melden
    return text


def _fahrzeug_text(r: dict) -> str:
    return " ".join(str(x) for x in (r.get("brand"), r.get("model")) if x) or ""


def _punkt(datum, art, titel, text="", ton="", link="", fahrzeug=None, betrag=None, bis=None, ganze_woche=False) -> dict:
    """Ein Punkt für „Heute & Woche“. Mit 'bis' gilt er für jeden Tag bis dahin (Lehrgang), mit 'ganze_woche'
    für die Woche ohne festen Tag (Sonderfahrt „in KW 47“)."""
    return {"datum": str(datum)[:10], "art": art, "titel": titel, "text": text, "ton": ton, "link": link,
            "fahrzeug": str(fahrzeug) if fahrzeug else None, "betrag": betrag,
            "bis": str(bis)[:10] if bis else None, "ganze_woche": bool(ganze_woche)}


def _uebergaben(db, tag: str, von: str, bis: str) -> list:
    tage = (dt.date.fromisoformat(bis) - dt.date.fromisoformat(tag)).days
    punkte = []
    for r in auslieferungs_ampel(db, tag, max(tage, 0)):
        if r["planned_date"][:10] < von or str(r["status"]).lower() == "ausgeliefert":
            continue
        offen = [p["label"] for p in r["punkte"] if p["status"] == "kritisch"]
        text = " · ".join(x for x in (_fahrzeug_text(r), r["city"]) if x)
        if offen:
            text += " · offen: " + ", ".join(offen)
        if r.get("bemerkung"):
            text += " · Bemerkung: " + str(r["bemerkung"])
        punkte.append(_punkt(r["planned_date"], "uebergabe", "Übergabe " + r["customer"], text,
                             "krit" if offen else "warn" if r["offen"] else "", "#/auslieferungen",
                             r["vehicle_internal_id"]))
    return punkte


def _vor(datum, tage: int) -> str:
    return (dt.date.fromisoformat(str(datum)[:10]) - dt.timedelta(days=tage)).isoformat()


def _vor_uebergaben(db, frueh: str, bis: str) -> list:
    """Was vor einer Übergabe zu tun ist: Zulassung besorgen (Papiere fehlen noch) und die Bemerkung aus der
    Auslieferungsliste – je als eigener Punkt ein paar Tage vor dem Termin."""
    punkte = []
    for d in _alle(db, """
            SELECT d.vehicle_internal_id, d.planned_date, d.customer, d.papiere_status, d.papiere_text, d.bemerkung,
                   v.brand, v.model
            FROM deliveries d LEFT JOIN vehicles v ON v.internal_id = d.vehicle_internal_id
            WHERE d.actual_date IS NULL AND d.planned_date IS NOT NULL AND LOWER(COALESCE(d.status,'')) <> 'ausgeliefert'
              AND date(d.planned_date) BETWEEN date(:frueh) AND date(:bis, '+' || :vorlauf || ' day')
            ORDER BY d.planned_date, d.id""", {"frueh": frueh, "bis": bis, "vorlauf": ZULASSUNG_VORLAUF}):
        kunde = str(d["customer"] or "–")
        termin = "Übergabe " + d["planned_date"][8:10] + "." + d["planned_date"][5:7] + "."
        fehlt = papiere_fehlen(d["papiere_status"], d["papiere_text"])
        if fehlt:
            punkte.append(_punkt(_vor(d["planned_date"], ZULASSUNG_VORLAUF), "zulassung",
                                 "Zulassung besorgen: " + kunde,
                                 " · ".join(x for x in (termin, _fahrzeug_text(d), fehlt) if x),
                                 "krit" if str(d["papiere_status"] or "").lower() == "im werk" else "warn",
                                 "#/auslieferungen", d["vehicle_internal_id"]))
        bemerkung = " ".join(str(d["bemerkung"] or "").split())
        if bemerkung:
            punkte.append(_punkt(_vor(d["planned_date"], BEMERKUNG_VORLAUF), "bemerkung", bemerkung,
                                 " · ".join(x for x in (termin, kunde, _fahrzeug_text(d)) if x), "",
                                 "#/auslieferungen", d["vehicle_internal_id"]))
    return [p for p in punkte if frueh <= p["datum"] <= bis]


def agenda(db, stichtag=None) -> dict:
    tag = stichtag_oder_heute(stichtag)
    montag = montag_von(tag)
    von, bis = montag.isoformat(), (montag + dt.timedelta(days=13)).isoformat()
    frueh = (dt.date.fromisoformat(tag) - dt.timedelta(days=AGENDA_RUECKBLICK)).isoformat()
    args = {"von": von, "bis": bis, "tag": tag, "frueh": frueh}
    termine = _uebergaben(db, tag, frueh, bis) + _vor_uebergaben(db, frueh, bis)

    for s in _alle(db, """
            SELECT datum, bis, ganze_woche, kw, art, text, arbeitskarte, pruefen FROM sonderfahrten
            WHERE datum IS NOT NULL AND date(datum) <= date(:bis) AND date(COALESCE(bis, datum)) >= date(:frueh)
            ORDER BY datum, id""", args):
        art = s["art"] if s["art"] in ("sonderfahrt", "hinweis", "lehrgang") else "sonderfahrt"
        zusatz = [f"AK {s['arbeitskarte']}" if s["arbeitskarte"] else "",
                  f"ganze KW {s['kw']}" if s["ganze_woche"] and s["kw"] else "",
                  f"bis {s['bis'][8:10]}.{s['bis'][5:7]}." if s["bis"] and not s["ganze_woche"] else "",
                  "Datum bitte prüfen" if s["pruefen"] else ""]
        termine.append(_punkt(s["datum"], art, s["text"], " · ".join(x for x in zusatz if x),
                              "krit" if art == "hinweis" else "warn" if s["pruefen"] else "", "#/auslieferungen",
                              bis=s["bis"], ganze_woche=s["ganze_woche"]))

    for f in _alle(db, f"""
            SELECT f.vehicle_internal_id, f.bank, f.financed_amount, f.interest_free_until, v.brand, v.model
            FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
            WHERE f.status = 'offen' AND v.status IN {IN_STOCK}
              AND date(f.interest_free_until) BETWEEN date(:von) AND date(:bis)""", args):
        termine.append(_punkt(f["interest_free_until"], "zinsfrei", "Zinsfreiheit endet",
                              " · ".join(x for x in (_fahrzeug_text(f), f["bank"]) if x), "warn", "#/finanzierung",
                              f["vehicle_internal_id"], f["financed_amount"]))

    for t in _alle(db, """
            SELECT t.vehicle_internal_id, t.bank, t.faellig_am, t.betrag, v.brand, v.model
            FROM tilgungen t LEFT JOIN vehicles v ON v.internal_id = t.vehicle_internal_id
            WHERE t.bezahlt_am IS NULL AND date(t.faellig_am) BETWEEN date(:frueh) AND date(:bis)""", args):
        termine.append(_punkt(t["faellig_am"], "tilgung", "Tilgung fällig",
                              " · ".join(x for x in (_fahrzeug_text(t), t["bank"]) if x), "warn", "#/finanzierung",
                              t["vehicle_internal_id"], t["betrag"]))

    for a in _alle(db, """
            SELECT a.vehicle_internal_id, a.bank, a.geplant_am, a.betrag, a.grund, v.brand, v.model
            FROM abloesungen a LEFT JOIN vehicles v ON v.internal_id = a.vehicle_internal_id
            WHERE a.erledigt = 0 AND date(a.geplant_am) BETWEEN date(:frueh) AND date(:bis)""", args):
        termine.append(_punkt(a["geplant_am"], "abloesung", "Ablösung geplant",
                              " · ".join(x for x in (_fahrzeug_text(a), a["bank"], a["grund"]) if x), "",
                              "#/vororder", a["vehicle_internal_id"], a["betrag"]))

    # Kommende Fahrzeuge aus der Finanzaufstellung: erwarteter Termin (grob, z. B. Montag der KW) – nur als Hinweis,
    # dass die Linie belastet wird; der genaue Text („KW 49/2026“, „Okt/Nov“) steht dabei
    for v in _alle(db, """
            SELECT bank, hersteller, modell, kommission, termin_text, termin_datum, betrag FROM kommende_fahrzeuge
            WHERE termin_datum IS NOT NULL AND date(termin_datum) BETWEEN date(:von) AND date(:bis)""", args):
        termine.append(_punkt(v["termin_datum"], "vororder", "Kommt: " + (v["modell"] or "Fahrzeug"),
                              " · ".join(x for x in (v["kommission"], f"{v['bank']} · {v['hersteller']}",
                                                     v["termin_text"]) if x), "", "#/vororder", None, v["betrag"]))

    # Zu erwartende Zahlungen (Finanzaufstellung): mit Datum, sonst zum geplanten Übergabedatum; offen und im Zeitraum
    for e in erwartete_zahlungen(db, tag):
        wann = e["erwartet_am"] or e["erwartet_ab"]
        if not e["offen"] or not wann or not (args["frueh"] <= wann[:10] <= args["bis"]):
            continue
        finanzierung = e["art"] == "Finanzierung"
        termine.append(_punkt(wann, "zahlung",
                              ("Bank zahlt aus: " if finanzierung else "Zahlung erwartet: ") + (e["kunde"] or "–"),
                              " · ".join(x for x in (e["fahrzeug"], e["art"], e["bank"],
                                                     None if e["erwartet_am"] else "zur Übergabe") if x),
                              "", "#/liquiditaet", e["internal_id"], e["betrag"]))

    for z in _alle(db, f"""
            SELECT z.vehicle_internal_id, z.frist, z.ausnahme_art, v.brand, v.model
            FROM zulassungsfristen z JOIN vehicles v ON v.internal_id = z.vehicle_internal_id
            WHERE z.frist IS NOT NULL AND v.status IN {IN_STOCK}
              AND date(z.frist) BETWEEN date(:frueh) AND date(:bis)""", args):
        termine.append(_punkt(z["frist"], "frist", "Zulassungsfrist endet",
                              " · ".join(x for x in (_fahrzeug_text(z), z["ausnahme_art"]) if x), "krit",
                              "#/fahrzeug/" + str(z["vehicle_internal_id"]), z["vehicle_internal_id"]))

    for t in _alle(db, """
            SELECT id, text, bereich, bezug_id, faellig_am, prioritaet FROM todos
            WHERE erledigt = 0 AND faellig_am IS NOT NULL AND date(faellig_am) BETWEEN date(:frueh) AND date(:bis)""",
                   args):
        termine.append(_punkt(t["faellig_am"], "todo", t["text"], t["bereich"] or "",
                              "warn" if t["prioritaet"] == "hoch" else "", "#/todos", t["bezug_id"]))

    for f in _alle(db, """
            SELECT id, titel, kategorie, faellig_am, verantwortlich FROM betriebsfristen
            WHERE date(faellig_am) BETWEEN date(:frueh) AND date(:bis)""", args):
        termine.append(_punkt(f["faellig_am"], "betrieb", f["titel"],
                              " · ".join(x for x in (f["kategorie"], f["verantwortlich"]) if x), "warn", "#/fristen"))

    for c in _alle(db, """
            SELECT datum, titel, text, ton, betrag FROM cashback_termine
            WHERE date(datum) BETWEEN date(:frueh) AND date(:bis)""", args):
        termine.append(_punkt(c["datum"], "cashback", c["titel"], c["text"], c["ton"], "#/cashback", None, c["betrag"]))

    # Überfällig ist nur, was einen Erledigt-Zustand hat und ihn nicht erreicht hat. Eine Bemerkung oder das
    # Ende der Zinsfreiheit ist danach einfach vorbei.
    for p in termine:
        p["ueberfaellig"] = p["datum"] < tag and p["art"] in AGENDA_MIT_ERLEDIGT
    reihenfolge = {a: i for i, a in enumerate(("hinweis", "frist", "betrieb", "cashback", "uebergabe", "zulassung",
                                                "bemerkung", "sonderfahrt", "lehrgang", "zahlung", "tilgung", "zinsfrei", "abloesung", "vororder",
                                                "todo"))}
    termine.sort(key=lambda p: (p["datum"], reihenfolge.get(p["art"], 99), p["titel"]))

    abwesend = _alle(db, """
        SELECT datum, mitarbeiter, art FROM abwesenheiten
        WHERE art <> 'Feiertag' AND date(datum) BETWEEN date(:von) AND date(:bis)
        ORDER BY datum, mitarbeiter""", args)
    feiertage = {}
    try:
        from ..urlaub_antraege import feiertag_namen
        for jahr in {von[:4], bis[:4]}:
            feiertage.update({d: n for d, n in feiertag_namen(int(jahr)).items() if von <= d <= bis})
    except Exception:                       # ohne Namen trotzdem aus den eingelesenen Feiertagen
        feiertage = {r["datum"]: "Feiertag" for r in _alle(db, """
            SELECT DISTINCT datum FROM abwesenheiten
            WHERE art = 'Feiertag' AND date(datum) BETWEEN date(:von) AND date(:bis)""", args)}
    return {"heute": tag, "von": von, "bis": bis, "kw": kalenderwoche(tag),
            "termine": termine,
            "abwesend": abwesend,
            # als Liste, nicht als {Datum: Name}: so bleibt die Form der Daten unabhängig vom Zeitraum
            "feiertage": [{"datum": d, "name": n} for d, n in sorted(feiertage.items())]}
