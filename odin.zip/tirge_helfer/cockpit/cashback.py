"""
Cashback-Aktionen (Herstellergutschriften) aus den Aktionslisten im Ordner „GUTSCHRIFTEN Cashback Aktionen“.

- Je Hersteller eine Arbeitsdatei (HERSTELLER1_Aktionen_….xlsx, HERSTELLER3 Aktionen.xlsx …), je Jahr ein Blatt „Aktionen JJJJ“,
  je Fahrzeug eine Zeile. Das Einlesen schreibt nie; geschrieben wird in Excel – oder, nach Bestätigung, über die
  Aktionen „Gutschrift angefordert/erhalten“ (aktionen/weitere.py) mit Sicherung, Zeilenprüfung und Protokoll.
- Sicherungskopien („…_2026-11-02.xlsx“) tragen denselben Hersteller: gezählt wird je Hersteller nur die zuletzt
  gespeicherte Datei. Die Vorlage (Hersteller „HERSTELLER“) zählt nie.
- Spalten werden über die Überschrift gefunden, nicht über die Position: Hersteller3 hat ein anderes Blatt als Hersteller1,
  und eine zusätzliche Spalte am Ende stört nicht.
- Was die Liste selbst rechnet (Soll-Betrag, Einreichungsfrist aus dem Aktionskatalog), liest ODIN als gespeicherten
  Wert. Fehlt die Frist, sucht ODIN sie im Blatt „Aktionskatalog“. „Tage seit Anforderung“ rechnet ODIN selbst –
  der Wert in der Datei ist nur so frisch wie das letzte Speichern.
"""

import datetime as dt
import os
import re

BLATT = re.compile(r"^\s*aktionen\s+(\d{4})\s*$", re.I)
STATUS = ("Angelegt", "Angefordert", "Prüfen", "Erledigt", "Storniert")
STATUS_OFFEN = ("Angelegt", "Angefordert", "Prüfen")
VORLAGE = "HERSTELLER"
NACHFASSEN_STANDARD = 30
WARNEN_STANDARD = 14
AKTIONEN_VORSCHAU = 45            # Aktionen, deren Einreichungsfrist in so vielen Tagen endet, stehen oben
ENDUNGEN = (".xlsx", ".xlsm")

# Feld -> Überschriften (vereinfacht: klein, nur Buchstaben und Ziffern). „=“ heißt: genau so, sonst: beginnt mit.
SPALTEN = {
    "status": ("=status",),
    "kunde": ("kundenname",),
    "kundennr": ("kundennr",),
    "fin": ("fahrgestellnr", "fin"),
    "modell": ("=modell",),
    "baureihe": ("baureihe",),
    "auftrag": ("=auftrag",),
    "verkaufsdatum": ("verkaufsdatum",),
    "interne_id": ("interneid",),
    "aktion1": ("aktion1", "=aktion"),
    "aktion2": ("aktion2",),
    "aktionsbetrag": ("aktionsbetrag",),
    "soll": ("sollgsnetto", "erwartetnetto", "sollnetto"),
    "frist": ("einreichungsfrist",),
    "angefordert_am": ("gsangefordertam", "angefordertam"),
    "gs_nr": ("gsnr",),
    "gs_datum": ("gsdatum",),
    "gs_brutto": ("gsbrutto",),
    "gs_netto": ("gsnetto",),
    "differenz": ("differenz",),
    "pruefung": ("prüfung", "pruefung"),
    "anmerkung": ("anmerkung",),
}


class CashbackFehler(Exception):
    """Meldung für Menschen."""


def _norm(wert) -> str:
    return re.sub(r"[^a-z0-9äöüß]", "", str(wert or "").lower())


def _passt(kopf: str, muster: str) -> bool:
    return kopf == muster[1:] if muster.startswith("=") else kopf.startswith(muster)


def _text(wert, laenge=200) -> str:
    if wert is None:
        return ""
    if isinstance(wert, float) and wert.is_integer():
        wert = int(wert)
    return " ".join(str(wert).split())[:laenge]


def _datum(wert):
    if wert in (None, ""):
        return None
    if isinstance(wert, dt.datetime):
        return wert.date()
    if isinstance(wert, dt.date):
        return wert
    s = str(wert).strip()
    for muster in ("%d.%m.%Y", "%d.%m.%y", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(s[:10], muster).date()
        except ValueError:
            pass
    return None


def _betrag(wert):
    if wert in (None, ""):
        return None
    if isinstance(wert, bool):
        return None
    if isinstance(wert, (int, float)):
        return round(float(wert), 2)
    s = re.sub(r"[^\d,.\-]", "", str(wert))
    if not s or s in "-,.":
        return None
    if "," in s:                                   # deutsch: 1.500,00
        s = s.replace(".", "").replace(",", ".")
    try:
        return round(float(s), 2)
    except ValueError:
        return None


def _tage(wert, standard: int) -> int:
    m = re.search(r"\d+", str(wert or ""))
    return int(m.group()) if m else standard


def _status(wert) -> str:
    n = _norm(wert)
    for s in STATUS:
        if _norm(s) == n:
            return s
    return _text(wert, 30)


# ------------------------------------------------------------------ Lesen
def _kopfzeile(zeilen):
    """(Index der Überschriftenzeile, {feld: spalte}) – die Zeile mit „Status“ vorn und „Kundenname“ dahinter."""
    for i, zeile in enumerate(zeilen[:12]):
        koepfe = [_norm(z) for z in zeile]
        if not koepfe or koepfe[0] != "status" or not any(k.startswith("kundenname") for k in koepfe):
            continue
        spalten = {}
        for feld, muster in SPALTEN.items():
            for nr, kopf in enumerate(koepfe):
                if kopf and nr not in spalten.values() and any(_passt(kopf, m) for m in muster):
                    spalten[feld] = nr
                    break
        return i, spalten
    return None, {}


def _einstellungen(zeilen) -> dict:
    """Die Zeilen über der Tabelle: Hersteller, Jahr, „Nachfassen ab 30 Tage“, „Frist warnen ab 14 Tage“."""
    e = {}
    for zeile in zeilen:
        for nr, zelle in enumerate(zeile):
            k = _norm(zelle)
            danach = next((z for z in zeile[nr + 1:] if z not in (None, "")), None)
            if k == "hersteller" and danach is not None:
                e.setdefault("hersteller", _text(danach, 40))
            elif k == "jahr" and danach is not None:
                e.setdefault("jahr", _text(danach, 4))
            elif k.startswith("nachfassen"):
                e.setdefault("nachfassen", _tage(danach, NACHFASSEN_STANDARD))
            elif k.startswith("fristwarnen"):
                e.setdefault("warnen", _tage(danach, WARNEN_STANDARD))
    return e


def _katalog(ws) -> list:
    """Linker Teil des Aktionskatalogs: Aktion, Zeitraum, Einreichungsfrist, Bedingungen."""
    if hasattr(ws, "reset_dimensions"):
        ws.reset_dimensions()
    zeilen = [list(z) for z in ws.iter_rows(min_row=1, max_row=110, max_col=6, values_only=True)]
    start = None
    for i, z in enumerate(zeilen[:10]):
        if z and _norm(z[0]) == "aktion" and len(z) > 3 and _norm(z[3]).startswith("einreichungsfrist"):
            start = i + 1
            break
    if start is None:
        return []
    aktionen = []
    for z in zeilen[start:]:
        name = _text(z[0], 120) if z else ""
        if not name:
            continue
        aktionen.append({"aktion": name, "von": _iso(_datum(z[1])), "bis": _iso(_datum(z[2])),
                         "frist": _iso(_datum(z[3])), "bedingung": _text(z[4], 240) if len(z) > 4 else ""})
    return aktionen


def _iso(d):
    return d.isoformat() if d else None


def lies_datei(pfad: str) -> dict:
    """Eine Aktionsliste: Hersteller, Einstellungen, Vorgänge aller Jahresblätter, Aktionskatalog."""
    from openpyxl import load_workbook
    from ..sicher import blatt_zeilen, pruefe_xlsx
    pruefe_xlsx(pfad)
    wb = load_workbook(pfad, read_only=True, data_only=True)
    try:
        aus = {"datei": os.path.basename(pfad), "hersteller": "", "nachfassen": NACHFASSEN_STANDARD,
               "warnen": WARNEN_STANDARD, "jahre": [], "vorgaenge": [], "katalog": [], "hinweise": [],
               "je_jahr": {}}
        for ws in wb.worksheets[:40]:
            if _norm(ws.title) == "aktionskatalog":
                aus["katalog"] = _katalog(ws)
                continue
            m = BLATT.match(ws.title)
            if not m:
                continue
            zeilen = blatt_zeilen(ws, max_zeilen=5000, max_spalten=60)
            kopf, spalten = _kopfzeile(zeilen)
            if kopf is None:
                aus["hinweise"].append(f"Blatt „{ws.title}“: keine Überschriftenzeile mit „Status“ und „Kundenname“.")
                continue
            e = _einstellungen(zeilen[:kopf])
            if e.get("hersteller") and not aus["hersteller"]:
                aus["hersteller"] = e["hersteller"]
            # Jedes Jahresblatt hat seine eigenen Tage fürs Nachhaken und die Fristwarnung
            blatt = {"nachfassen": e.get("nachfassen", NACHFASSEN_STANDARD), "warnen": e.get("warnen", WARNEN_STANDARD)}
            aus["je_jahr"][m.group(1)] = blatt
            if int(m.group(1)) >= max([int(j) for j in aus["jahre"]] + [0]):   # zur Anzeige: das neueste Jahr
                aus["nachfassen"], aus["warnen"] = blatt["nachfassen"], blatt["warnen"]
            aus["jahre"].append(m.group(1))
            for nr, z in enumerate(zeilen[kopf + 1:], start=kopf + 2):
                wert = lambda feld: z[spalten[feld]] if feld in spalten and spalten[feld] < len(z) else None  # noqa: E731
                kunde, fin = _text(wert("kunde"), 80), _text(wert("fin"), 30)
                if not kunde and not fin:
                    continue
                aus["vorgaenge"].append({
                    "jahr": m.group(1), "zeile": nr, **blatt, "status": _status(wert("status")), "kunde": kunde, "fin": fin,
                    "kundennr": _text(wert("kundennr"), 20), "modell": _text(wert("modell"), 60),
                    "baureihe": _text(wert("baureihe"), 40), "auftrag": _text(wert("auftrag"), 20),
                    "interne_id": _text(wert("interne_id"), 20), "verkaufsdatum": _iso(_datum(wert("verkaufsdatum"))),
                    "aktion1": _text(wert("aktion1"), 120), "aktion2": _text(wert("aktion2"), 120),
                    "aktionsbetrag": _betrag(wert("aktionsbetrag")), "soll": _betrag(wert("soll")),
                    "frist": _iso(_datum(wert("frist"))), "angefordert_am": _iso(_datum(wert("angefordert_am"))),
                    "gs_nr": _text(wert("gs_nr"), 30), "gs_datum": _iso(_datum(wert("gs_datum"))),
                    "gs_brutto": _betrag(wert("gs_brutto")), "gs_netto": _betrag(wert("gs_netto")),
                    "differenz": _betrag(wert("differenz")), "pruefung": _text(wert("pruefung"), 80),
                    "anmerkung": _text(wert("anmerkung"), 300),
                })
        if not aus["jahre"]:
            aus["hinweise"].append("Kein Blatt „Aktionen JJJJ“ gefunden.")
        return aus
    finally:
        wb.close()


def dateien_im_ordner(ordner: str) -> list:
    """(pfad, Änderungszeit) aller Excel-Dateien direkt im Ordner – ohne Excel-Sperrdateien (~$…)."""
    if not ordner or not os.path.isdir(ordner):
        return []
    aus = []
    for name in sorted(os.listdir(ordner)):
        pfad = os.path.join(ordner, name)
        if name.startswith(("~$", ".")) or not name.lower().endswith(ENDUNGEN) or not os.path.isfile(pfad):
            continue
        try:
            aus.append((pfad, os.stat(pfad).st_mtime))
        except OSError:
            pass
    return aus


def stand(ordner: str):
    """Für den Zwischenspeicher: ändert sich, sobald eine Datei im Ordner gespeichert wird."""
    return tuple((os.path.basename(p), t) for p, t in dateien_im_ordner(ordner))


def lies_ordner(ordner: str, protokoll=None) -> dict:
    """Alle Aktionslisten im Ordner; je Hersteller zählt nur die zuletzt gespeicherte Datei."""
    if not ordner:
        return {"dateien": [], "listen": []}
    if not os.path.isdir(ordner):
        raise CashbackFehler("Der Cashback-Ordner ist nicht erreichbar – ist OneDrive gestartet?")
    gelesen = []
    dateien = []
    for pfad, zeit in dateien_im_ordner(ordner):
        info = {"datei": os.path.basename(pfad), "stand": dt.datetime.fromtimestamp(zeit).strftime("%d.%m.%Y %H:%M"),
                "hersteller": "", "gezaehlt": False, "grund": "", "vorgaenge": 0}
        try:
            liste = lies_datei(pfad)
        except PermissionError:
            info["grund"] = "gerade gesperrt – gleich nochmal versuchen"
            dateien.append(info)
            continue
        except Exception as e:                      # eine kaputte Datei hält die anderen nicht auf
            if protokoll:
                protokoll(f"Cashback: {pfad} nicht lesbar: {e!r}")
            info["grund"] = "nicht lesbar"
            dateien.append(info)
            continue
        info["hersteller"] = liste["hersteller"]
        info["vorgaenge"] = len(liste["vorgaenge"])
        if not liste["jahre"]:
            info["grund"] = "keine Aktionsliste"
        elif not liste["hersteller"] or liste["hersteller"].upper() == VORLAGE:
            info["grund"] = "Vorlage"
        else:
            gelesen.append((zeit, liste, info))
        dateien.append(info)
    neueste = {}
    for zeit, liste, info in gelesen:
        schluessel = liste["hersteller"].upper()
        if schluessel not in neueste or zeit > neueste[schluessel][0]:
            neueste[schluessel] = (zeit, liste, info)
    for zeit, liste, info in gelesen:
        if neueste[liste["hersteller"].upper()][2] is info:
            info["gezaehlt"] = True
        else:
            info["grund"] = "ältere Kopie von " + liste["hersteller"]
    listen = [neueste[k][1] for k in sorted(neueste)]
    return {"dateien": dateien, "listen": listen}


# ------------------------------------------------------------------ Auswerten
def _summe(werte) -> float:
    return round(sum(w for w in werte if w is not None), 2)


def _katalog_frist(liste: dict) -> dict:
    return {a["aktion"]: a["frist"] for a in liste["katalog"] if a.get("frist")}


def auswerten(gelesen: dict, heute: str, ordner: str = "") -> dict:
    """Alles für die Seite und für „Heute & Woche“: Kennzahlen, Fristen, Nachhaken, offene Vorgänge."""
    tag = dt.date.fromisoformat(heute)
    jahr = str(tag.year)
    vorgaenge, hersteller, aktionen = [], [], []
    for liste in gelesen.get("listen", []):
        fristen = _katalog_frist(liste)
        name = liste["hersteller"]
        anzeige = (liste.get("je_jahr") or {}).get(jahr) or {"nachfassen": liste["nachfassen"],
                                                            "warnen": liste["warnen"]}
        h = {"name": name, "datei": next((d["datei"] for d in gelesen["dateien"] if d["gezaehlt"]
                                          and d["hersteller"] == name), ""),
             "nachfassen": anzeige["nachfassen"], "warnen": anzeige["warnen"], "jahre": sorted(liste["jahre"]),
             "angelegt": 0, "angefordert": 0, "pruefen": 0, "offen": 0, "offen_netto": 0.0, "offen_endkunde": 0.0,
             "erhalten_jahr": 0.0, "erledigt_jahr": 0, "hinweise": liste["hinweise"]}
        for roh in liste["vorgaenge"]:
            v = {**roh, "hersteller": name, "aktion": " + ".join(a for a in (roh["aktion1"], roh["aktion2"]) if a)}
            warnen = roh.get("warnen", liste["warnen"])
            nachfassen = roh.get("nachfassen", liste["nachfassen"])
            if not v["frist"]:                       # Formel ohne gespeicherten Wert: Frist aus dem Katalog
                kandidaten = sorted(f for f in (fristen.get(roh["aktion1"]), fristen.get(roh["aktion2"])) if f)
                v["frist"] = kandidaten[0] if kandidaten else None
            v["offen"] = v["status"] in STATUS_OFFEN
            v["frist_tage"] = None
            v["lage"] = ""
            if v["status"] in ("Angelegt", "Prüfen") and v["frist"]:
                v["frist_tage"] = (dt.date.fromisoformat(v["frist"]) - tag).days
                if v["frist_tage"] < 0:
                    v["lage"] = "ueberfaellig"
                elif v["frist_tage"] <= warnen:
                    v["lage"] = "bald"
            v["tage_seit"] = None
            v["nachhaken_am"] = None
            if v["status"] == "Angefordert":
                if v["angefordert_am"]:
                    angefordert = dt.date.fromisoformat(v["angefordert_am"])
                    v["tage_seit"] = (tag - angefordert).days
                    v["nachhaken_am"] = (angefordert + dt.timedelta(days=nachfassen)).isoformat()
                    if v["tage_seit"] >= nachfassen:
                        v["lage"] = "nachhaken"
                else:
                    v["lage"] = "ohne_datum"
            v["abweichung"] = (v["status"] == "Erledigt" and v["differenz"] is not None and abs(v["differenz"]) >= 0.05)
            vorgaenge.append(v)
            if v["offen"]:
                h["offen"] += 1
                h[{"Angelegt": "angelegt", "Angefordert": "angefordert", "Prüfen": "pruefen"}[v["status"]]] += 1
                h["offen_netto"] += v["soll"] or 0
                h["offen_endkunde"] += v["aktionsbetrag"] or 0
            if v["status"] == "Erledigt" and (v["gs_datum"] or "")[:4] == jahr:
                h["erhalten_jahr"] += v["gs_netto"] or 0
                h["erledigt_jahr"] += 1
        h["offen_netto"] = round(h["offen_netto"], 2)
        h["offen_endkunde"] = round(h["offen_endkunde"], 2)
        h["erhalten_jahr"] = round(h["erhalten_jahr"], 2)
        hersteller.append(h)
        for a in liste["katalog"]:
            if not a.get("frist"):
                continue
            tage = (dt.date.fromisoformat(a["frist"]) - tag).days
            if 0 <= tage <= AKTIONEN_VORSCHAU:
                nutzen = [v for v in vorgaenge if v["hersteller"] == name and a["aktion"] in (v["aktion1"], v["aktion2"])]
                aktionen.append({**a, "hersteller": name, "tage": tage,
                                 "noch_einreichen": sum(1 for v in nutzen if v["status"] in ("Angelegt", "Prüfen")),
                                 "fahrzeuge": len(nutzen)})

    offen = [v for v in vorgaenge if v["offen"]]
    fristen = sorted([v for v in offen if v["lage"] in ("bald", "ueberfaellig")], key=lambda v: v["frist"])
    nachhaken = sorted([v for v in offen if v["lage"] in ("nachhaken", "ohne_datum")],
                       key=lambda v: -(v["tage_seit"] if v["tage_seit"] is not None else 10 ** 6))
    abweichungen = sorted([v for v in vorgaenge if v["abweichung"]], key=lambda v: v["gs_datum"] or "", reverse=True)
    rang = {"ueberfaellig": 0, "bald": 1, "nachhaken": 2, "ohne_datum": 3, "": 4}
    offen.sort(key=lambda v: (rang.get(v["lage"], 4), v["frist"] or v["nachhaken_am"] or "9999", v["kunde"]))
    kennzahlen = {
        "offen": len(offen),
        "offen_netto": _summe(v["soll"] for v in offen),
        "offen_ohne_betrag": sum(1 for v in offen if v["soll"] is None),
        "offen_endkunde": _summe(v["aktionsbetrag"] for v in offen),
        "angelegt": sum(1 for v in offen if v["status"] == "Angelegt"),
        "angefordert": sum(1 for v in offen if v["status"] == "Angefordert"),
        "pruefen": sum(1 for v in offen if v["status"] == "Prüfen"),
        "fristen_bald": sum(1 for v in fristen if v["lage"] == "bald"),
        "fristen_ueberfaellig": sum(1 for v in fristen if v["lage"] == "ueberfaellig"),
        "nachhaken": len(nachhaken),
        "erhalten_jahr": _summe(h["erhalten_jahr"] for h in hersteller),
        "abweichung_summe": _summe(v["differenz"] for v in abweichungen if (v["gs_datum"] or "")[:4] == jahr),
        "jahr": jahr,
    }
    kennzahlen["zaehler"] = kennzahlen["fristen_bald"] + kennzahlen["fristen_ueberfaellig"] + kennzahlen["nachhaken"]
    return {"eingerichtet": bool(ordner), "ordner": ordner, "ordner_name": os.path.basename(ordner.rstrip("/\\")),
            "dateien": gelesen.get("dateien", []), "hersteller": hersteller, "kennzahlen": kennzahlen,
            "fristen": fristen, "nachhaken": nachhaken, "offen": offen, "abweichungen": abweichungen[:30],
            "aktionen": sorted(aktionen, key=lambda a: a["frist"]), "fehler": ""}


def termine(auswertung: dict) -> list:
    """Für „Heute & Woche“: Einreichungsfristen offener Vorgänge und der Tag zum Nachhaken."""
    aus = []
    for v in auswertung.get("offen", []):
        wer = " · ".join(x for x in (v["kunde"], v["hersteller"]) if x)
        if v["status"] in ("Angelegt", "Prüfen") and v["frist"]:
            aus.append({"datum": v["frist"], "titel": "Cashback einreichen: " + (v["aktion"] or "Aktion"),
                        "text": wer, "ton": "krit" if v["lage"] == "ueberfaellig" else "warn",
                        "betrag": v["soll"] if v["soll"] is not None else v["aktionsbetrag"]})
        elif v["status"] == "Angefordert" and v["nachhaken_am"]:
            aus.append({"datum": v["nachhaken_am"], "titel": "Gutschrift nachhaken: " + (v["aktion"] or "Aktion"),
                        "text": wer + f" · angefordert am {_de(v['angefordert_am'])}", "ton": "warn",
                        "betrag": v["soll"]})
    return aus


def _de(iso) -> str:
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if iso else ""


# ------------------------------------------------------------------ Beispieldaten
def demo(heute: str) -> dict:
    """Erfundene Vorgänge für die Beispieldaten – Format wie die echten Listen."""
    t = dt.date.fromisoformat(heute)
    tag = lambda n: (t + dt.timedelta(days=n)).isoformat()     # noqa: E731

    def v(jahr, status, kunde, modell, aktion, soll, endkunde=None, frist=None, angefordert=None, gs=None,
          gs_datum=None, differenz=None, anmerkung=""):
        return {"jahr": jahr, "zeile": 0, "status": status, "kunde": kunde, "fin": "", "kundennr": "", "modell": modell,
                "baureihe": "", "auftrag": "", "interne_id": "", "verkaufsdatum": None, "aktion1": aktion,
                "aktion2": "", "aktionsbetrag": endkunde, "soll": soll, "frist": frist,
                "angefordert_am": angefordert, "gs_nr": "5200001" if gs else "", "gs_datum": gs_datum,
                "gs_brutto": round(gs * 1.19, 2) if gs else None, "gs_netto": gs, "differenz": differenz,
                "pruefung": "OK", "anmerkung": anmerkung}
    j = str(t.year)
    a = {"datei": "MARKE A_Aktionen.xlsx", "hersteller": "MARKE A", "nachfassen": 30, "warnen": 14, "jahre": [j],
         "hinweise": [], "katalog": [{"aktion": "Herbst-Aktion", "von": tag(-60), "bis": tag(5), "frist": tag(20),
                                      "bedingung": "Neufahrzeuge, Kaufvertrag im Aktionszeitraum"}],
         "vorgaenge": [
             v(j, "Angelegt", "Berg, Anna", "Kastenwagen 600", "Herbst-Aktion", 2521.0, 3000.0, tag(6)),
             v(j, "Angelegt", "Wagner, Tom", "Teilintegrierter 7", "Herbst-Aktion", 1680.67, 2000.0, tag(-2)),
             v(j, "Angefordert", "Krause, Mia", "Alkoven 6", "Messeaktion", 1500.0, 1500.0, tag(-20), tag(-41)),
             v(j, "Erledigt", "Albers, Lars", "Kastenwagen 540", "Messeaktion", 1500.0, 1500.0, None, tag(-90),
               1485.0, tag(-50), -15.0, "Gutschrift weicht vom Soll ab"),
             v(j, "Erledigt", "Muster, Erika", "Wohnwagen 500", "Messeaktion", 750.0, 750.0, None, tag(-80), 750.0,
               tag(-60), 0.0),
         ]}
    b = {"datei": "MARKE B Aktionen.xlsx", "hersteller": "MARKE B", "nachfassen": 30, "warnen": 14, "jahre": [j],
         "hinweise": [], "katalog": [],
         "vorgaenge": [
             v(j, "Angefordert", "Beispiel GmbH", "Campervan 600", "Last Edition", 5000.0, None, None, tag(-12)),
             v(j, "Prüfen", "Schmidt, Inga", "Campervan 540", "Gutschein", None, None, tag(30),
               anmerkung="Betrag beim Hersteller erfragen"),
         ]}
    dateien = [{"datei": x["datei"], "stand": "", "hersteller": x["hersteller"], "gezaehlt": True, "grund": "",
                "vorgaenge": len(x["vorgaenge"])} for x in (a, b)]
    return {"dateien": dateien, "listen": [a, b]}
