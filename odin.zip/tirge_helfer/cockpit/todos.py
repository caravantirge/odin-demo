"""
To-dos – übernommen aus dem muster Cockpit (lib/todos.ts und lib/todo-typen.ts).

Die erste Stelle, an der das Cockpit selbst schreibt: Excel bleibt Quelle für Fahrzeuge, Finanzierungen und
Preise – Aufgaben entstehen hier.
"""

import datetime as dt

from .auswertungen import _alle, _eine, stichtag_oder_heute
from .db import normalize_internal_id

BEREICHE = ["Allgemein", "Bestand", "Finanzierung", "Auslieferung", "Werkstatt", "Teile"]
PRIORITAETEN = ["hoch", "normal", "niedrig"]

_FELDER = ["text", "bereich", "bezug_id", "faellig_am", "prioritaet"]


def _text(wert):
    if wert is None:
        return None
    s = str(wert).strip()
    return s or None


def _datum(wert):
    """Fälligkeit als ISO-Datum oder None; ein unlesbares Datum wird abgewiesen statt still verworfen."""
    s = _text(wert)
    if not s:
        return None
    try:
        return dt.date.fromisoformat(s[:10]).isoformat()
    except ValueError:
        raise ValueError(f"„{s}“ ist kein Datum (erwartet JJJJ-MM-TT).") from None


def todos(db, erledigt=None, bereich=None, bezug_id=None, limit=200) -> list:
    """Offene zuerst, danach nach Fälligkeit und Priorität."""
    where, args = [], {}
    if erledigt is not None:
        where.append("erledigt = :erledigt")
        args["erledigt"] = 1 if erledigt else 0
    if bereich:
        where.append("bereich = :bereich")
        args["bereich"] = bereich
    if bezug_id:
        where.append("bezug_id = :bezug_id")
        args["bezug_id"] = normalize_internal_id(bezug_id)
    return _alle(db, f"""
        SELECT * FROM todos {'WHERE ' + ' AND '.join(where) if where else ''}
        ORDER BY erledigt ASC,
                 CASE WHEN faellig_am IS NULL THEN 1 ELSE 0 END, faellig_am ASC,
                 CASE prioritaet WHEN 'hoch' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END,
                 id DESC
        LIMIT {min(int(limit or 200), 500)}""", args)


def todo_kennzahlen(db, stichtag=None) -> dict:
    r = _eine(db, """
        SELECT COUNT(*) offen,
               SUM(CASE WHEN faellig_am IS NOT NULL AND date(faellig_am) < date(:tag) THEN 1 ELSE 0 END) ueberfaellig,
               SUM(CASE WHEN faellig_am IS NOT NULL AND date(faellig_am) <= date(:tag,'+7 day')
                         AND date(faellig_am) >= date(:tag) THEN 1 ELSE 0 END) diese_woche,
               SUM(CASE WHEN prioritaet = 'hoch' THEN 1 ELSE 0 END) hoch
        FROM todos WHERE erledigt = 0""", {"tag": stichtag_oder_heute(stichtag)})
    return {"offen": r["offen"], "ueberfaellig": r["ueberfaellig"] or 0, "diese_woche": r["diese_woche"] or 0,
            "hoch": r["hoch"] or 0}


def todo_anlegen(db, text, bereich=None, bezug_id=None, faellig_am=None, prioritaet=None,
                 angelegt_von=None) -> dict:
    inhalt = _text(text)
    if not inhalt:
        raise ValueError("Ohne Text lässt sich keine Aufgabe anlegen.")
    cur = db.execute("""
        INSERT INTO todos (text, bereich, bezug_id, faellig_am, prioritaet, erledigt, angelegt_von, angelegt_am)
        VALUES (:text, :bereich, :bezug_id, :faellig_am, :prioritaet, 0, :angelegt_von, :angelegt_am)""", {
        "text": inhalt,
        "bereich": _text(bereich) or "Allgemein",
        "bezug_id": normalize_internal_id(bezug_id) if _text(bezug_id) else None,
        "faellig_am": _datum(faellig_am),
        "prioritaet": _text(prioritaet) or "normal",
        "angelegt_von": _text(angelegt_von),
        "angelegt_am": dt.datetime.now().isoformat(timespec="seconds"),
    })
    db.commit()
    return _eine(db, "SELECT * FROM todos WHERE id = ?", (cur.lastrowid,))


def todo_aendern(db, todo_id: int, aenderung: dict, stichtag=None):
    """Ändert die übergebenen Felder; `erledigt` (bool) setzt zugleich das Erledigt-Datum. None, wenn nichts kam."""
    felder, args = [], {"id": todo_id}
    for feld in _FELDER:
        if feld not in aenderung:
            continue
        wert = _text(aenderung[feld])
        if feld == "text" and not wert:
            raise ValueError("Ohne Text lässt sich keine Aufgabe anlegen.")
        if feld == "bezug_id" and wert:
            wert = normalize_internal_id(wert)
        if feld == "faellig_am":
            wert = _datum(wert)
        felder.append(f"{feld} = :{feld}")
        args[feld] = wert
    if aenderung.get("erledigt") is not None:
        felder += ["erledigt = :erledigt", "erledigt_am = :erledigt_am"]
        args["erledigt"] = 1 if aenderung["erledigt"] else 0
        args["erledigt_am"] = stichtag_oder_heute(stichtag) if aenderung["erledigt"] else None
    if not felder:
        return None
    db.execute(f"UPDATE todos SET {', '.join(felder)} WHERE id = :id", args)
    db.commit()
    return _eine(db, "SELECT * FROM todos WHERE id = ?", (todo_id,))


def todo_loeschen(db, todo_id: int) -> bool:
    geloescht = db.execute("DELETE FROM todos WHERE id = ?", (todo_id,)).rowcount > 0
    db.commit()
    return geloescht
