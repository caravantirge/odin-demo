"""Cockpit: Bestand, Finanzen, Liquidität, Auslieferungen und Teile aus den Excel-Listen."""
