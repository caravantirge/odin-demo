"""
Daten für die Cockpit-Oberfläche – übernommen aus dem muster Cockpit (demo/export-demodaten.ts).

`daten_fuer_oberflaeche` liefert genau das Objekt `D`, das die Oberfläche (cockpit-v2.html) liest: dieselben
Schlüssel, dieselben Feldnamen, dieselben Einheiten (Beträge in Euro, Zeiten in Minuten, Datum als ISO-Text) und
dieselbe Sortierung. Einiges rechnet die Oberfläche selbst aus den Rohlisten (Kennzahlen, Linienprojektion,
Bedarf); deshalb stehen Fahrzeuge, Finanzierungen und Auslieferungen hier vollständig drin.
"""

from . import auswertungen as a
from .vororder import vorordern


def _alle(db, sql: str) -> list:
    return [dict(r) for r in db.execute(sql).fetchall()]


def daten_fuer_oberflaeche(db, stichtag=None) -> dict:
    tag = a.stichtag_oder_heute(stichtag)
    return {
        "stichtag": tag,
        # Das Original nahm nur die Demo-Fahrzeuge (source_file = 'seed-demo'); in ODIN zählt alles Eingelesene.
        "vehicles": _alle(db, """
            SELECT internal_id,vin,serien_nr,bestell_nr,brand,model,category,model_year,condition,status,
                   location,lieferblock,schluessel_nr,lieferstatus,kommission_art,kommission_name,jahrgang,
                   arrival_date,purchase_net,purchase_gross,extra_cost_net,list_price_gross,list_price_net,
                   internet_price,vk_min,sold_net,sold_date,customer,salesperson,notes,caracamp_objekt,
                   fin_bank,fin_vertrag,ausstattung,syscara
            FROM vehicles ORDER BY internal_id"""),
        # nur Verträge zu bekannten Fahrzeugen – sonst tauchen Linien „ohne Hersteller“ auf
        # Hersteller und Linie wie in der Finanzaufstellung; nächste offene Rate aus dem Tilgungsplan
        "financings": _alle(db, f"""
            SELECT f.vehicle_internal_id,f.bank,f.contract_no,f.financed_amount,f.start_date,
                   f.interest_free_until,f.interest_rate_pct,f.due_date,f.status,
                   {a.LINIEN_HERSTELLER} AS hersteller, f.linie,
                   (SELECT MIN(t.faellig_am) FROM tilgungen t WHERE t.vehicle_internal_id = f.vehicle_internal_id
                      AND t.bezahlt_am IS NULL) AS naechste_rate_am,
                   (SELECT t.betrag FROM tilgungen t WHERE t.vehicle_internal_id = f.vehicle_internal_id
                      AND t.bezahlt_am IS NULL ORDER BY t.faellig_am LIMIT 1) AS naechste_rate
            FROM financings f JOIN vehicles v ON v.internal_id = f.vehicle_internal_id
            ORDER BY f.id"""),
        "deliveries": _alle(db, """
            SELECT vehicle_internal_id,planned_date,actual_date,customer,city,status,checklist_open
            FROM deliveries ORDER BY id"""),
        "commissions": _alle(db, """
            SELECT vehicle_internal_id,salesperson,sale_date,basis_amount,rate_pct,amount,status,payout_date
            FROM commissions ORDER BY id"""),
        "parts": _alle(db, """
            SELECT sku,name,category,supplier,purchase_net,sales_net,install_minutes,hourly_rate
            FROM parts ORDER BY id"""),
        "cash": a.cash_series(db, tag, 6, 6),
        "cashKategorien": a.cash_by_category(db, tag, "ist"),
        "importRuns": a.import_runs(db),
        "ampel": a.auslieferungs_ampel(db, tag, 60),
        "ampelK": a.ampel_kennzahlen(db, tag, 60),
        "urlaub": a.abwesenheiten_kommend(db, tag, 56),
        "tilgungMonate": a.tilgungen_je_monat(db, tag, 9),
        "tilgungOffen": a.tilgungen_faellig(db, tag, 90),
        "fristen": a.zulassungsfristen(db, tag, 365),
        "mitarbeiter": _alle(db, """
            SELECT name, bereich, minuten_pro_tag, auslieferung FROM mitarbeiter ORDER BY bereich, name"""),
        "raster": a.auslieferungs_raster(db, tag, 60),
        "linien": a.bank_linien(db),
        "linienOffen": a.linien_ohne_zuordnung(db),
        "katalog": a.teile_katalog(db),
        "katalogFilter": a.katalog_filter(db),
        "katalogK": a.katalog_kennzahlen(db),
        "todos": _alle(db, """
            SELECT id,text,bereich,bezug_id,faellig_am,prioritaet,erledigt,erledigt_am FROM todos ORDER BY id"""),
        # Projektion und Bedarf rechnet die Oberfläche selbst – deshalb reichen hier die kommenden Fahrzeuge selbst.
        "kommend": a.kommende_fahrzeuge(db),
        # früher von Hand in ODIN eingetragene Vorordern: nur noch zum Nachlesen, sie zählen nicht mehr für die Linien
        "vorordern": vorordern(db),
        "agenda": a.agenda(db, tag),
        # Zu erwartende Zahlungen aus der Finanzaufstellung (vor allem Kundenfinanzierungen, die die Bank noch nicht
        # ausgezahlt hat) – nur für Finanz-Berechtigte; app.py nimmt sie für alle anderen heraus
        "erwartet": (erwartet := a.erwartete_zahlungen(db, tag)),
        "erwartetK": a.erwartete_kennzahlen(db, erwartet),
    }


# Interne Werte der Teile: Einkauf, Lohnkosten, Eigenkosten und daraus die Marge. Die Seite „Teile & Montage“ blendet
# sie nur auf Wunsch ein („Einkauf anzeigen“, je Rechner); im Browser (Handy & Tablet) kommen sie gar nicht erst mit.
# Echte Rechte (wer Einkauf sehen darf) kommen mit der Anmeldung.
EINKAUF_TEIL = ("purchase_net", "stamm_ek", "lohn_ek", "gesamt_ek_brutto", "set_ek", "set_eigenkosten_brutto")
EINKAUF_POSITION = ("ek", "purchase_net", "stamm_ek")


def ohne_einkauf(d):
    """Kopie des Datenpakets ohne Einkaufspreise und Eigenkosten der Teile (Katalog, Stücklisten, Teileliste,
    Lagerwert). Alles andere bleibt dasselbe Objekt."""
    if not isinstance(d, dict):
        return d
    aus = dict(d)
    if isinstance(d.get("katalog"), list):
        aus["katalog"] = [
            {**{k: v for k, v in t.items() if k not in EINKAUF_TEIL},
             "stueckliste": [{k: v for k, v in p.items() if k not in EINKAUF_POSITION}
                             for p in (t.get("stueckliste") or []) if isinstance(p, dict)]}
            if isinstance(t, dict) else t for t in d["katalog"]]
    if isinstance(d.get("parts"), list):
        aus["parts"] = [{k: v for k, v in t.items() if k not in EINKAUF_TEIL} if isinstance(t, dict) else t
                        for t in d["parts"]]
    if isinstance(d.get("katalogK"), dict):
        aus["katalogK"] = {k: v for k, v in d["katalogK"].items() if k != "lagerwert"}
    return aus
