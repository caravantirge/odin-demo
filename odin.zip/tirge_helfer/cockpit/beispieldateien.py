"""
Beispiel-Excel-Dateien im Aufbau der echten Listen – mit Farben, Titelzeilen, deutschen Zahlen und Datumsangaben.

Übernommen aus dem muster Cockpit (scripts/beispiel-excel.ts, beispiel-finanzaufstellung.ts,
beispiel-auslieferungsliste.ts) und ergänzt um die Bestandsliste im echten Aufbau (Ausstattungszeile unter jedem
Fahrzeug, Formeln in Spalte P), Finanzplanung, Provisionen, eine kleine Teileliste mit Artikelstamm und einen
Urlaubsplaner. Für die Tests und den Selbsttest von ODIN; echte Firmendaten stehen nicht drin.

Die Farben sind teils bewusst keine reinen RGB-Werte, sondern Design-Farben mit Aufhellung („Grün, Akzent 6,
heller 40 %“) und alte Palettenfarben – so, wie Excel sie wirklich speichert.
"""

import calendar
import os
import re
import shutil
import tempfile
import zipfile
from datetime import date, datetime, timedelta

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment, Color, Font, PatternFill
from openpyxl.writer.theme import theme_xml

# Office-Design ab Excel 2016 (openpyxl schreibt sonst das alte Design von 2007)
_OFFICE_FARBEN = {"dk2": "44546A", "lt2": "E7E6E6", "accent1": "4472C4", "accent2": "ED7D31", "accent3": "A5A5A5",
                  "accent4": "FFC000", "accent5": "5B9BD5", "accent6": "70AD47", "hlink": "0563C1",
                  "folHlink": "954F72"}
HELLER_80, HELLER_60, HELLER_40 = 0.7999816888943144, 0.5999938962981048, 0.3999755851924192
DUNKLER_25 = -0.249977111117893


def office_thema() -> bytes:
    xml = theme_xml
    for name, wert in _OFFICE_FARBEN.items():
        xml = re.sub(rf'(<a:{name}>\s*<a:srgbClr val=")[0-9A-Fa-f]{{6}}', rf"\g<1>{wert}", xml)
    return xml.encode("utf-8")


def fuellung(farbe) -> PatternFill:
    """'FF0000', Color(theme=…, tint=…) oder Color(indexed=…) als einfarbige Füllung."""
    return PatternFill("solid", fgColor=farbe if isinstance(farbe, Color) else Color(rgb="FF" + farbe[-6:]))


def design(index: int, tint: float = 0.0) -> Color:
    return Color(theme=index, tint=tint)


def palette(index: int) -> Color:
    return Color(indexed=index)


def _neue_mappe(erstes_blatt: str) -> Workbook:
    wb = Workbook()
    wb.active.title = erstes_blatt
    wb.loaded_theme = office_thema()
    return wb


def _breiten(ws, breite=17):
    for spalte in range(1, ws.max_column + 1):
        ws.column_dimensions[ws.cell(row=1, column=spalte).column_letter].width = breite


def _formelwerte_eintragen(pfad: str, werte: dict):
    """
    openpyxl speichert Formeln ohne Ergebnis; Excel speichert beides. Damit der Import (data_only) wie bei einer
    echten Datei Formelergebnisse sieht, werden sie hier nachgetragen. werte: {(Blattnummer, 'P3'): Wert}.
    """
    with zipfile.ZipFile(pfad) as alt:
        inhalte = {n: alt.read(n) for n in alt.namelist()}
    for (blatt, zelle), wert in werte.items():
        name = f"xl/worksheets/sheet{blatt}.xml"
        xml = inhalte[name].decode("utf-8")
        if isinstance(wert, str):
            ersatz = rf'<c r="{zelle}"\g<1> t="str"><f>\g<2></f><v>{wert}</v></c>'
        else:
            ersatz = rf'<c r="{zelle}"\g<1>><f>\g<2></f><v>{wert}</v></c>'
        xml, n = re.subn(rf'<c r="{zelle}"([^>]*)><f>(.*?)</f><v\s*/>\s*</c>', ersatz, xml)
        assert n == 1, (name, zelle)
        inhalte[name] = xml.encode("utf-8")
    tmp = pfad + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as neu:
        for n, inhalt in inhalte.items():
            neu.writestr(n, inhalt)
    os.replace(tmp, pfad)


def _flache_liste(pfad, blatt, titel, kopf, zeilen, kopfzeile=3):
    """Titelzeile, Leerzeile, Kopf, Daten – so sehen gewachsene Listen aus."""
    wb = _neue_mappe(blatt)
    ws = wb.active
    ws.append([titel])
    for _ in range(kopfzeile - 2):
        ws.append([])
    ws.append(kopf)
    for z in zeilen:
        ws.append(z)
    for c in ws[kopfzeile]:
        c.font = Font(bold=True)
    _breiten(ws, 18)
    wb.save(pfad)
    return pfad


# ------------------------------------------------------------------------- Bestandsliste (Original) ---

def schreibe_bestandsliste(ordner) -> str:
    """Port von beispiel-excel.ts: Titelzeile, Kopf in Zeile 2, Ausstattung als verbundene Zelle über die Breite."""
    kopf = ["Model", "Fahrgestellnummer", "Serien Nr.", "Bestell-Nr.", "Interne ID", "Schlüssel-Nr.", "Kommission",
            "VK Liste", "Internet", "EK Netto", "VK min.", "Finanziert", "Syscara"]
    blaetter = [
        ("2026", "Bestand Hersteller1 – Jahrgang 2026", [
            ["Linea 600 DR", "ZFA250009TG022785", "26 656 032", "1454291", "DETKW00191", "4417", "Lager",
             "72.400,00", "71.900,00", "58.900,00", None, "WF, 08977", "inseriert"],
            "Sondermodell-Paket, Markise 4,0 m, Solaranlage 150 Wp, Fahrerhaus-Klimaautomatik, Navigation, "
            "Rückfahrkamera, Fahrradträger, Alufelgen 16\", Dieselheizung, Fliegenschutztür",
            ["Linea 640 HR", "ZFA250004SMA82671", "25 545 020", "1454142", "DETKW00142", "4418",
             "Schou, DETKW00142", "76.900,00", None, "57.809,31", None, "WF, 08981", None],
            "Winterpaket, Truma Combi 6 D, Zusatzbatterie 95 Ah, Sat-Anlage Oyster 85, Motorrad-/Fahrradträger, "
            "Markise mit LED, Einparkhilfe vorn und hinten",
            ["Trend 7057 EBL", "WDET7788112299", "26 123 118", "1454312", "DRM00312", "B1", "Lager", "91.500,00",
             None, "74.300,00", None, "Nord., 21445", None],
            "Chassis-Paket Light, Aufbautür mit Fenster, Hubbett, Backofen, Truma Combi 6 E, Fußbodenheizung, "
            "Außendusche, Rückfahrkamera",
            ["c'way 495 QSK", "WDT13LEA2KS003790", "25 P26 019", "1454188", "DWWA00188", "2210",
             "J&A Automobile DWWA00188", "33.900,00", None, "20.768,42", None, "114490", None],
            "Mover, Markise 3,5 m, Fahrradträger Deichsel, Vorzelt, Antischlingerkupplung, Warmwasserboiler",
            ["Viator 560 FMK", "WDT15ETA9NT003891", "26 166 002", "1454194", "DWWA00194", "B2", "Lager",
             "38.400,00", None, "28.380,17", None, None, None],
            "Winterpaket, Fußbodenheizung, Truma Mover SE, Dachfenster Mini Heki, Außensteckdose, Alufelgen",
        ]),
        ("2027", "Bestand Hersteller1 – Jahrgang 2027", [
            ["Linea 540 DS Active", None, None, "1454354", "DETKW00238", "B3", "Lager", "62.283,00", None,
             "44.701,67", None, None, None],
            "Active-Paket, Markise, Dieselheizung, Fahrerhaus-Klimaanlage, Tempomat, Rückfahrkamera",
            ["Linea 600 ES Active", None, None, "1454353", "DETKW00237", "B3", "Lager", "60.855,00", None,
             "43.808,13", None, None, None],
            ["Linea 600 DS 95 Jahre", None, None, "1454307", "DETKW00211", "B1", "Lager", "81.333,00", None,
             "54.107,83", None, "WF, 09014", None],
            "Sondermodell 95 Jahre, Lackierung metallic, 16\"-Alufelgen, Markise mit LED-Band, Solaranlage 150 Wp, "
            "Multimedia-Paket, Schlafkomfort-Paket",
            ["Alto A 7820-2", "ZFA250009SMA76879", "25 558 009", "1454245", "DRM00245", "5512", "Schou, DRM00245",
             "164.900,00", None, "139.690,30", None, "CA, 60112", None],
            "Alto-Ausstattungslinie, Doppelboden beheizt, Hubbett, Garage mit Zurrsystem, Sat-Anlage, Markise 5,0 m, "
            "Rückfahrkamera, Einparkhilfe, Alufelgen 16\"",
        ]),
    ]
    wb = _neue_mappe(blaetter[0][0])
    for n, (name, titel, zeilen) in enumerate(blaetter):
        ws = wb.active if n == 0 else wb.create_sheet(name)
        ws.append([titel])
        ws.append(kopf)
        for z in zeilen:
            if isinstance(z, str):
                # Ausstattung: eine über die ganze Breite verbundene Zelle unter dem Fahrzeug
                ws.append([z])
                r = ws.max_row
                ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(kopf))
                ws.cell(row=r, column=1).alignment = Alignment(wrap_text=True, vertical="top")
                ws.cell(row=r, column=1).font = Font(size=9, italic=True)
                ws.row_dimensions[r].height = 28
            else:
                ws.append(z)
        for c in ws[2]:
            c.font = Font(bold=True)
        _breiten(ws)
    pfad = os.path.join(ordner, "Beispiel-Bestandsliste.xlsx")
    wb.save(pfad)
    return pfad


# -------------------------------------------------------------------- Bestandsliste (echter Aufbau) ---

KOPF_BESTAND = ["lfd. Nr.", "Model", "Fahrgestellnummer", "Seriennr.", "Auftragsnr.", "Interne ID",
                "Liefer-KW/\nSchlüsselnr.", "Kommission", "VK max.", "Internet", "EK Netto", "VK min.", "Finanziert",
                None, None, None]
_FRACHT = {"DETKW": 1290, "SLKW": 1290, "DRM": 1490, "DWWA": 690}

# lfd. Nr., Model, FIN, Seriennr., Auftragsnr., Interne ID, Liefer-KW/Schlüssel, Kommission, VK max., Internet,
# EK Netto, Finanziert, Ausstattung (None = leere Ausstattungszeile), Farbe der Schlüsselzelle
JAHRESBLAETTER = {
    "2026": [
        (1, "Linea 600 DR", "ZFA250009TG022785", "26 656 032", 1454291, "DETKW00191", 4417, None, 72400, 71900,
         58900, "WF, 08977", "Sondermodell-Paket, Markise 4,0 m, Solaranlage 150 Wp, Fahrerhaus-Klimaautomatik, "
         "Navigation, Rückfahrkamera, Dieselheizung", "frei"),
        (2, "Trend 7057 EBL", "WDET7788112299", "26 123 118", 1454312, "DRM00312", "KW 14", None, 91500, None, 74300,
         "Nord., 21445", "Chassis-Paket Light, Aufbautür mit Fenster, Hubbett, Truma Combi 6 E", "rot"),
        (3, "Viator 560 FMK", "WDT15ETA9NT003891", "26 166 002", 1454194, "DWWA00194", "B2", None, 38400, None,
         28380.17, None, None, "rot"),
        (4, "Linea 640 HR", "ZFA250004SMA82671", "25 545 020", 1454142, "DETKW00142", 4418, "Schou", 76900,
         None, "57.809,31", "WF, 08981", "Winterpaket, Truma Combi 6 D, Sat-Anlage Oyster 85, Markise mit LED",
         None),
        (5, "c'way 495 QSK", "WDT13LEA2KS003790", "25 P26 019", 1454188, "DWWA00188 AF", 2210, "J&A Automobile",
         33900, None, 20768.42, 114490, "Mover, Markise 3,5 m, Fahrradträger Deichsel, Vorzelt", None),
        (6, "Vento 600", "ZFA250004SMB11002", "26 780 114", 1454400, "NICHT BERECHNEN / SLKW00272", 12, "Müller",
         64900, None, 47100, None, "Markise", "rot"),
    ],
    "2027": [
        (1, "Linea 540 DS Active", None, None, 1454354, "DETKW00238", "B3", None, 62283, None, 44701.67, None,
         "Active-Paket, Markise, Dieselheizung, Fahrerhaus-Klimaanlage, Tempomat, Rückfahrkamera", "rot"),
        (2, "Alto A 7820-2", "ZFA250009SMA76879", "25 558 009", 1454245, "DRM00245", 5512, "Schou", 164900, None,
         139690.30, "CA, 60112", "Alto-Ausstattungslinie, Doppelboden beheizt, Hubbett, Garage mit Zurrsystem",
         None),
        (3, "Trend 6757 DBM", None, None, 1454401, None, "B3", None, 88900, None, 70100, None,
         "Ausstattung eines Fahrzeugs ohne Nummer – darf an keinem anderen Fahrzeug landen", "rot"),
    ],
}


def schreibe_bestandsliste_jahresblaetter(ordner) -> str:
    """
    Echter Aufbau: Kopf in Zeile 1, ein Blatt je Jahr, jedes Fahrzeug in jeder zweiten Zeile, darunter die
    Ausstattungszeile (Text in B, verbunden bis M) ohne lfd. Nr., Auftragsnr. und Interne ID. Spalte L und P sind
    Formeln mit gespeichertem Ergebnis; unverkaufte Fahrzeuge oben, verkaufte (mit Kommission) unten.
    """
    wb = _neue_mappe("2026")
    formelwerte = {}
    for n, (name, fahrzeuge) in enumerate(JAHRESBLAETTER.items(), start=1):
        ws = wb.active if n == 1 else wb.create_sheet(name)
        ws.append(KOPF_BESTAND)
        for c in ws[1]:
            c.font = Font(bold=True)
        for i, f in enumerate(fahrzeuge):
            lfd, model, fin, serie, auftrag, iid, schluessel, kommission, vk, internet, ek, finanziert, aus, farbe = f
            r = ws.max_row + 1
            ws.append([lfd, model, fin, serie, auftrag, iid, schluessel, kommission, vk, internet, ek,
                       None, finanziert, None, None, None])
            ek_zahl = ek if isinstance(ek, (int, float)) else float(ek.replace(".", "").replace(",", "."))
            praefix = re.sub(r"[^A-Z]", "", re.sub(r".*?([A-Z]{2,6})\d.*", r"\1", iid or "DETKW0"))
            ws.cell(row=r, column=12, value=f"=ROUND((K{r}+{_FRACHT.get(praefix, 1200)})*1.1,2)")
            ws.cell(row=r, column=16, value=f'=IF(I{r}="","",ROUND(I{r}/1.19-K{r},2))')
            if not (name == "2026" and lfd == 3):          # eine Formel ohne gespeichertes Ergebnis
                formelwerte[(n, f"L{r}")] = round((ek_zahl + _FRACHT.get(praefix, 1200)) * 1.1, 2)
            formelwerte[(n, f"P{r}")] = round(vk / 1.19 - ek_zahl, 2)
            if farbe == "rot":
                ws.cell(row=r, column=7).fill = fuellung("FF0000")
            elif farbe == "frei":
                ws.cell(row=r, column=7).fill = fuellung(design(9, HELLER_40))     # Grün, Akzent 6, heller 40 %
            # Ausstattungszeile: B verbunden bis M, in P die Formel der Datenzeile (Ergebnis leer oder 0)
            r += 1
            ws.cell(row=r, column=2, value=aus)
            ws.cell(row=r, column=16, value=f'=IF(F{r}="","",0)')
            formelwerte[(n, f"P{r}")] = "" if i % 2 == 0 else 0
            if i % 3 != 2:
                ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=13)
                ws.cell(row=r, column=2).alignment = Alignment(wrap_text=True, vertical="top")
        # Summenzeile am Ende: nur Zahlen, keine Nummer
        r = ws.max_row + 2
        ws.cell(row=r, column=11, value=f"=SUM(K2:K{r - 2})")
        formelwerte[(n, f"K{r}")] = 1
        _breiten(ws)
    wb.create_sheet("Tabelle1")
    pfad = os.path.join(ordner, "Beispiel-Bestandsliste-Jahresblaetter.xlsx")
    wb.save(pfad)
    _formelwerte_eintragen(pfad, formelwerte)
    return pfad


# ---------------------------------------------------------------------------------- Finanzierungen ---

def schreibe_finanzierungen(ordner) -> str:
    """Port der flachen Einkaufsfinanzierung aus beispiel-excel.ts (mit Bankspalte und Vertragsnummer)."""
    return _flache_liste(
        os.path.join(ordner, "Beispiel-Finanzierungen.xlsx"), "Einkaufsfinanzierung",
        "Einkaufsfinanzierung – Übersicht Banken",
        ["Interne Nr", "Bank", "Vertragsnummer", "Finanzierungsbetrag", "Beginn", "Zinsfrei bis", "Zinssatz",
         "Laufzeit Monate", "Ablösung bis", "Status"],
        [["DETKW 00191", "Ostbank", "Ostbank-2026-005512", "58.900,00", "07.08.2026", "05.04.2027", "7,9", 12, "05.08.2027",
          "offen"],
         ["DRM 00312", "Nordbank", "SCB-2026-3391", "74.300,00", "24.07.2026", "20.03.2027", "8,2", 12,
          "20.07.2027", "offen"],
         ["HYMWM 00518", "VR Bank Einkaufsfinanzierung", "VRB-2026-1180", "88.200,00", "16.03.2026", "11.12.2026",
          "8,5", 12, "11.06.2027", "offen"],
         ["BUEWW 00631", "Ostbank", "Ostbank-2026-004980", "26.400,00", "13.06.2026", "09.03.2027", "7,4", 12, "09.09.2027",
          "offen"],
         ["SUNKW 00822", "Sparkasse Kontokorrent", "SPK-2026-7742", "54.700,00", "31.08.2026", "28.02.2027", "9,1", 6,
          "28.08.2027", "offen"]])


KOPF_FINANZ = ["Kommission", "Rechnungsdatum", "Zinsfrei", "EK Netto", "Modell", "Seriennummer", "Fahrgestellnummer",
               "Finanzierung", "Abgelöst", "neu/gebraucht", "Ausnahmegenehmigung", "Tilgung", None, "Tilgung", None]

# je Bank und Hersteller ein Blatt, wie in der echten Mappe; rechts die Tilgungspaare (Datum, Betrag)
FINANZBLAETTER = [
    ("Nord. H1", [1, 2], [
        ["Lager, DETKW00182", "03.06.2026", "29.11.2026", "58.016,88", "Linea 600 ER", "26 656 024",
         "ZFA250009TG022785", "58.684,09", None, "neu", "Stellantis EURO 6 (EA) bis 30.06.2027",
         "01.03.2027", "−6.904,01 €", datetime(2027, 6, 1), -6904.01],
        ["Lager, DETKW00189", "16.06.2026", "12.12.2026", "55.503,86", "Linea 600 ER Iconic", "26 656 032",
         "ZFA250005SMC26714", "56.142,15", None, "neu", "keine Ausnahme", None, None, None, None],
        ["Schou, DRM00245", "18.06.2026", "14.12.2026", "139.690,30", "Alto A 7820-2", "25 558 009",
         "ZFA250009SMA76879", "141.200,00", "12.09.2026", "neu", "Stellantis GSRII Euro VI bis 31.12.2027",
         None, None, None, None],
    ]),
    ("Nord. SL", [], [
        ["Lager, SLKW00304", "11.07.2026", "07.01.2027", "44.900,00", "Vento 640", "26 780 114", "ZFA250004SMB11002",
         "45.300,00", None, "neu", "Stellantis EURO 6 (EA) bis 30.06.2027", None, None, None, None],
    ]),
    ("Nord. Gebr.", [], [
        ["Lager, GW00458", "04.07.2026", "31.12.2026", "34.900,00", "Hersteller4 Exsis-t 580", "24 118 771",
         "WMA5580041H229114", "35.400,00", None, "gebraucht", "keine Ausnahme", "15.01.2027", "-5.000,00", None,
         None],
    ]),
    ("CA H1", [], [
        ["Lager, DRM00307", "23.06.2026", "19.12.2026", "62.298,80", "GB Performance T 16", "27 100 020",
         "WV3ZZZSZ4T9028538", "74.135,57", None, "neu", "Stellantis EURO 6 (EA) bis 30.06.2027", None, None, None,
         None],
    ]),
    ("WF Hersteller3", [0], [
        ["J&A Automobile, DWWA00194", "29.04.2026", "25.10.2026", "28.380,17", "Viator 560 FMK", "26 166 002",
         "WDT15ETA9NT003891", "28.900,00", None, "neu", "keine Ausnahme", None, None, None, None],
    ]),
]


def _kommend(kommission, termin, zinsfrei, ek, modell, finanzierung) -> list:
    """Zeile eines kommenden Fahrzeugs im Aufbau von KOPF_FINANZ."""
    return [kommission, termin, zinsfrei, ek, modell, None, None, finanzierung, None, "neu", None, None, None, None,
            None]


# Unter den finanzierten Fahrzeugen: kommende Fahrzeuge (bestellt, noch nicht da), Summe, Limit, Konditionen.
# Alles erfunden. „summe“ ist das Formelergebnis, das Excel in der Datei speichern würde.
FINANZ_FUSS = {
    "Nord. H1": {
        "kommend": [_kommend("Lager, DRM00309", "KW 49/2026", "360 Tage", None, "Trend T 7057 EBL", "61.500,00"),
                    _kommend("Kunde Fernkorn", "Jan/Apr", "360 Tage", "58.400,00", "Linea 640 HR",
                             "58.900,00")],
        "summe": 376426.24, "limit": -750000,
        "konditionen": ["3,25 %=2,50 %", "plus Bereitstellung 0,40 % p. a."]},
    "Nord. SL": {
        "kommend": [_kommend("Lager", "Juni/Aug.", "360 Tage", None, "Vento 600 RT", "49.900,00"),
                    _kommend("Kunde Brandt", "Frühjahr", "360 Tage", None, "Vento 640", "45.300,00")],
        "limit": -250000, "konditionen": ["4,99 %"]},
    "CA H1": {   # mit dem kommenden Fahrzeug über dem Limit
        "kommend": [_kommend("Lager, DRM00311", "KW 3", "CA 360 Tage", None, "Lineo T 4", "68.000,00")],
        "limit": -100000, "konditionen": ["5,2 %"]},
    "WF Hersteller3": {
        "kommend": [_kommend("Sebald, DWWA0022", "Okt/Nov", "Westbank 180 Tage", None, "Strada R", "47.800,00"),
                    _kommend("Lager", "Juni/Aug.", "Westbank 1% Skonto", "41.200,00", "Monte Prime 600", None),
                    _kommend("Lager", None, None, None, "Hersteller12 600 L", None)],      # ohne Betrag: Hinweis
        "limit": -1250000, "konditionen": ["4,75 % ab Tag 181"]},
}

# Linienblätter mit anderem Kopf. Kopf, finanzierte Fahrzeuge (Spalte → Wert, „_tilgung“ = Paare rechts daneben),
# Fuß wie oben plus „finanzierung“ = Name der Finanzierungsspalte.
_KOPF_BANK = ["Kommission", "Rechnungsdatum", "Zinsfrei", "EK Netto", "Modell", "Nr", "Seriennummer",
              "Fahrgestellnummer", "Hersteller3", "Nordbank", "Abgelöst"]
_KOPF_SKREDIT = ["Kommission", "Rechnungsdatum", "Zinsfrei", "EK Netto", "Modell", "Nr", "Seriennummer",
                 "Fahrgestellnummer", "Hersteller3", "S-Kredit", "S-Kredit ist", "Tilgung", "Abgelöst"]
LINIEN_VARIANTEN = [
    ("Nord. Hersteller3", _KOPF_BANK,
     [{"Kommission": "Lager, DWWA00231", "Rechnungsdatum": "14.08.2026", "Zinsfrei": "09.02.2027",
       "EK Netto": "36.100,00", "Modell": "Monte 540", "Nr": 17, "Seriennummer": "26 900 117",
       "Fahrgestellnummer": "WF0XXXTTGXNA12345", "Hersteller3": "37.300,00", "Nordbank": "36.500,00",
       "_tilgung": ["01.12.2026", "-3.650,00"]}],
     {"finanzierung": "Nordbank", "limit": -300000, "limit_wort": "Limit", "konditionen": ["3,9 %"],
      "kommend": [{"Kommission": "Kunde Albers", "Rechnungsdatum": "KW 3", "Zinsfrei": "360 Tage",
                   "Modell": "Monte 600", "Nordbank": "38.900,00"}]}),
    ("DL Hersteller3", _KOPF_SKREDIT,
     [{"Kommission": "Kunde Wiese, DWWA00232", "Rechnungsdatum": "02.09.2026", "Zinsfrei": "01.03.2027",
       "EK Netto": "44.700,00", "Modell": "Strada R", "Nr": 4, "Hersteller3": "45.900,00", "S-Kredit": "45.000,00",
       "S-Kredit ist": "40.500,00", "Tilgung": "4.500,00"}],
     {"finanzierung": "S-Kredit", "limit": -500000,
      "konditionen": ["Euribor + 2,1 %", "plus Bereitstellung 0,25 % p. a."]}),
]


# Erstes Blatt der echten Finanzaufstellung (laufender Liquiditätsplan), alles erfunden: (Text, Betrag, Bemerkung).
# „… Finanzierung“ = die Bank hat noch nicht ausgezahlt; „Inz. … (Wert)“ mit 0 € und Kosten sind keine Kundenzahlung.
LIQUIDITAETSPLAN = [
    ("EC", 1250.0, None),
    ("Überweisung", 0.0, None),
    ("Tresor (12.000)", 0.0, None),
    ("Brockmann Vento 600 Finanzierung", 52400.0, None),
    ("Thiele Linea 600 ER Finanzierung Nordbank bis 12.12.", 61900.0, "Unterlagen bei der Bank"),
    ("Wessels Trend T 7057 Überweisung", 21800.0, None),
    ("Wessels Trend T 7057 Inz. Hersteller8 (28.000)", 0.0, None),
    ("Kaya Roadstar XT Überweisung", 19900.0, "bar bezahlt"),
    ("Pacht 25.11.", -1200.0, None),
    ("Löhne November ca.", -98000.0, None),
    ("Zinsen Nordbank 30.11. ca. (-1.900,00)", 0.0, None),
    ("03.11. Werk XY12345 Vento 600", 9800.0, None),
    ("Lorenz Monte 600 Finanzierung", None, "Betrag kommt von der Bank"),
]


def schreibe_finanzaufstellung(ordner) -> str:
    """
    Port von beispiel-finanzaufstellung.ts: Kommission und Nummer in einer Zelle, keine Bankspalte (die Bank steht
    im Blattnamen), grüne Zeile = verkauft, gelbe Zeile ohne Bedeutung, Ausnahmegenehmigung mit Frist, ein
    Gebrauchtwagen ohne Bestandsliste, ein Übersichtsblatt mit Dubletten und ein Auswertungsblatt. Neu: Tilgungspaare,
    unter den Fahrzeugen die kommenden (KW bzw. Zeitraum statt Rechnungsdatum), Summe, Limit und Konditionen, zwei
    Linienblätter mit anderem Kopf („Nordbank“ bzw. „S-Kredit“ als Finanzierungsspalte) und ein Hilfsblatt ohne Bank.
    Grün und Gelb sind Design-Farben („Grün, Akzent 6, heller 40 %“, „Gold, Akzent 4, heller 80 %“).
    """
    gruen = fuellung(design(9, HELLER_40))
    gelb = fuellung(design(7, HELLER_80))
    wb = _neue_mappe("Finanzaufstellung")

    def blatt(ws, zeilen, verkauft):
        ws.append([f"Finanzaufstellung – {ws.title}"])
        ws.append(KOPF_FINANZ)
        for c in ws[2]:
            c.font = Font(bold=True)
        for i, z in enumerate(zeilen):
            ws.append(z)
            r = ws.max_row
            for spalte in range(1, 12):
                ws.cell(row=r, column=spalte).fill = gruen if i in verkauft else gelb
            if z[10] and z[10] != "keine Ausnahme":
                ws.cell(row=r, column=11).font = Font(color="FFC00000")
        _breiten(ws, 20)

    def fuss(ws, spalte_fin, angaben, kommission_spalte=1):
        """Unter den Fahrzeugen: Leerzeile, kommende Fahrzeuge, Leerzeile, Summe, Limit, Rest, Konditionen."""
        if angaben.get("kommend"):
            ws.append([])
            for z in angaben["kommend"]:
                ws.append(z)
        bis = ws._current_row                    # Leerzeilen hinterlassen keine Zellen, max_row zählt sie nicht
        ws.append([])
        summe = ws._current_row + 1
        buchstabe = ws.cell(row=1, column=spalte_fin).column_letter
        zeile = [None] * spalte_fin
        zeile[spalte_fin - 1] = f"=SUM({buchstabe}3:{buchstabe}{bis})"
        ws.append(zeile)
        if angaben.get("limit") is not None:
            zeile = [None] * spalte_fin
            zeile[spalte_fin - 1] = angaben["limit"]
            if angaben.get("limit_wort"):
                zeile[kommission_spalte - 1] = angaben["limit_wort"]
            ws.append(zeile)
            zeile = [None] * spalte_fin
            zeile[spalte_fin - 1] = f"={buchstabe}{summe}+{buchstabe}{summe + 1}"
            ws.append(zeile)
        for text in angaben.get("konditionen", []):
            zeile = [None] * spalte_fin
            zeile[spalte_fin - 1] = text
            ws.append(zeile)
        return summe

    # Übersicht: dieselben Fahrzeuge noch einmal, ohne Bank
    uebersicht = [z for _, _, zeilen in FINANZBLAETTER for z in zeilen]
    blatt(wb.active, uebersicht, [2])
    formelwerte = {}
    for nr, (name, verkauft, zeilen) in enumerate(FINANZBLAETTER, start=2):
        ws = wb.create_sheet(name)
        blatt(ws, zeilen, verkauft)
        angaben = FINANZ_FUSS.get(name)
        if angaben:
            summe = fuss(ws, 8, angaben)
            if "summe" in angaben:                          # Formelergebnisse wie in einer echten Datei
                formelwerte[(nr, f"H{summe}")] = angaben["summe"]
                formelwerte[(nr, f"H{summe + 2}")] = angaben["summe"] + angaben["limit"]
    # Linienblätter mit anderem Kopf: Finanzierungsspalte heißt wie die Bank bzw. „S-Kredit“
    for name, kopf, fahrzeuge, angaben in LINIEN_VARIANTEN:
        ws = wb.create_sheet(name)
        ws.append([f"Finanzaufstellung – {name}"])
        ws.append(kopf)
        for c in ws[2]:
            c.font = Font(bold=True)
        for f in fahrzeuge:
            ws.append([f.get(k) for k in kopf] + f.get("_tilgung", []))
        kommend = [[f.get(k) for k in kopf] for f in angaben.get("kommend", [])]
        fuss(ws, kopf.index(angaben["finanzierung"]) + 1, {**angaben, "kommend": kommend})
        _breiten(ws, 18)
    # Liquiditätsplan wie das erste Blatt der echten Mappe: ohne Spaltenköpfe, Text in A, Betrag in B, laufende
    # Salden als Formeln, Bemerkung in G. Oben die zu erwartenden Zahlungen der Kunden (erfunden).
    ws = wb.create_sheet("Liquidität")
    ws.append([None, None, None, 500000])
    ws.append([])
    ws.append(["Formelzeile nicht belegen", None, 120000.0, "=SUM(C3+$D$1)"])
    for nr, (text, betrag, bemerkung) in enumerate(LIQUIDITAETSPLAN, start=4):
        ws.append([text, betrag, f"=SUM(C{nr - 1}+B{nr})", f"=SUM(C{nr}+$D$1)", None, None, bemerkung])
    _breiten(ws, 22)
    # Hilfsblatt ohne Bank (nur eine Liste) und Auswertungsblatt: beide muss der Import überspringen
    ws = wb.create_sheet("Hersteller3 360")
    ws.append(["Kommission", "Modell", "Finanzierung"])
    ws.append(["Lager, DWWA00299", "Monte Prime 600", "39.900,00"])
    ws = wb.create_sheet("WF HG Umsatz")
    ws.append(["Monat", "Umsatz", "Limit"])
    ws.append(["Juli 2026", "412.000,00", "600.000,00"])
    pfad = os.path.join(ordner, "Beispiel-Finanzaufstellung.xlsx")
    wb.save(pfad)
    if formelwerte:
        _formelwerte_eintragen(pfad, formelwerte)
    return pfad


# ------------------------------------------------------------------------------- Auslieferungsliste ---

# Farben absichtlich teils nicht exakt aus der Legende – der Import muss über den Farbabstand richtig deuten
AUSLIEFERUNGEN = [
    # Interne ID, Name, Schriftfarbe, Modell, Modellfarbe, Tanken, Tankfarbe, Arbeitskarte, AK-Farbe, Minuten,
    # Termin, Terminfarbe, Vertragsdatum, neu/gebraucht, TÜV-Farbe, Papiere, Papierfarbe, AB/VDR, Zahlfarbe,
    # Werkfarbe, AHKS, AHKA, UBHK, SON-Text, SON-Farbe, Bemerkung
    dict(id="DETKW00142", name="Schou", schrift="00B050", modell="Linea 640 HR", modellfarbe="92D050",
         tank="fertig getankt", tankfarbe="A9D18E", ak="692400", akfarbe="C00000", minuten=180,
         termin="Di. 13.10. 10:30", terminfarbe=None, vertrag=datetime(2026, 6, 10), art="neu", tuev=None,
         papiere="Brief Kunde 14.09.", papierfarbe="92D050", zahlart="VDR", zahlfarbe=design(9, HELLER_40),
         werk="92D050", ahks="FF0000", ahka=None, ubhk="FFFF00", son="Savico Vario LED", sonfarbe="A9D18E",
         bemerkung="Gutschein 250 € offen"),
    dict(id="DWWA00188", name="J&A Automobile", schrift=None, modell="c'way 495 QSK", modellfarbe="00B050",
         tank="in Arbeit tanken", tankfarbe="FFFF00", ak="692437", akfarbe=design(9), minuten=300,
         termin="Mi. 21.10.", terminfarbe="FFFF00", vertrag="03.07.2026", art="gebraucht", tuev="FF0000",
         papiere="Brief Hersteller1", papierfarbe="FFC000", zahlart="AB", zahlfarbe="FF0000", werk="FF0000",
         ahks=None, ahka="92D050", ubhk=None, son=None, sonfarbe=None, bemerkung=None),
    dict(id=None, name="Müller", schrift="7030A0", modell="Vento 600", modellfarbe="C00000",
         tank="in Arbeit tanken", tankfarbe="FF0000", ak="692474", akfarbe=palette(13), minuten=450,
         termin=datetime(2026, 11, 3), terminfarbe=None, vertrag=datetime(2026, 8, 12), art="neu", tuev=None,
         papiere="Brief/Ausnahme wir", papierfarbe="FFFF00", zahlart="VDR", zahlfarbe="FFC000", werk="92D050",
         ahks=None, ahka=None, ubhk="92D050", son=None, sonfarbe=None, bemerkung="Restzahlung bei Übergabe"),
    dict(id="DRM00245", name="Schou", schrift="00B050", modell="Alto A 7820-2", modellfarbe="92D050",
         tank="fertig getankt", tankfarbe="92D050", ak="692511", akfarbe="2E75B6", minuten=600,
         termin=datetime(2026, 12, 1, 14, 30), terminfarbe=None, vertrag="20.06.2026", art="neu", tuev=None,
         papiere="Brief Kunde 02.11.", papierfarbe="92D050", zahlart="VDR", zahlfarbe="92D050", werk="92D050",
         ahks=None, ahka="92D050", ubhk="92D050", son=None, sonfarbe=None, bemerkung=None),
    dict(id=None, name="Fam. Unbekannt", schrift=None, modell="Hersteller4 B 550", modellfarbe=None,
         tank=None, tankfarbe=None, ak=None, akfarbe=None, minuten=None, termin="Fr. 04.12.", terminfarbe=None,
         vertrag=None, art="gebraucht", tuev=None, papiere=None, papierfarbe=None, zahlart=None, zahlfarbe=None,
         werk=None, ahks=None, ahka=None, ubhk=None, son=None, sonfarbe=None, bemerkung="noch kein Fahrzeug"),
]
KOPF_AUSLIEFERUNG = ["Tanken", "Arbeitskarte", "Minuten", "Termin", "Name", "Modell", "Vertragsdatum",
                     "neu/gebraucht", "Fahrzeugpapiere", "AB/VDR", "Werk bezahlt", "AHKS", "AHKA", "UBHK", "SON",
                     "Bemerkung"]


def schreibe_auslieferungsliste(ordner, mit_id: bool = True, dateiname: str = None) -> str:
    """Port von beispiel-auslieferungsliste.ts mit festen Zeilen (passend zur Bestandsliste im echten Aufbau)."""
    wb = _neue_mappe("Auslieferungen 2026")
    ws = wb.active
    ws.append(["Auslieferungsliste – Beispiel mit Farben"])
    ws.append(KOPF_AUSLIEFERUNG + (["Interne ID"] if mit_id else []))
    for c in ws[2]:
        c.font = Font(bold=True)
    for a in AUSLIEFERUNGEN:
        ws.append([a["tank"], a["ak"], a["minuten"], a["termin"], a["name"], a["modell"], a["vertrag"], a["art"],
                   a["papiere"], a["zahlart"], None, None, None, None, a["son"], a["bemerkung"]]
                  + ([a["id"]] if mit_id else []))
        r = ws.max_row
        for spalte, farbe in ((1, a["tankfarbe"]), (2, a["akfarbe"]), (4, a["terminfarbe"]), (6, a["modellfarbe"]),
                              (8, a["tuev"]), (9, a["papierfarbe"]), (10, a["zahlfarbe"]), (11, a["werk"]),
                              (12, a["ahks"]), (13, a["ahka"]), (14, a["ubhk"]), (15, a["sonfarbe"])):
            if farbe is not None:
                ws.cell(row=r, column=spalte).fill = fuellung(farbe)
        if a["schrift"]:
            ws.cell(row=r, column=5).font = Font(color="FF" + a["schrift"])
        if isinstance(a["termin"], datetime):
            ws.cell(row=r, column=4).number_format = "DD.MM.YYYY"
        if isinstance(a["vertrag"], datetime):
            ws.cell(row=r, column=7).number_format = "DD.MM.YYYY"
    _breiten(ws, 16)
    pfad = os.path.join(ordner, dateiname or ("Beispiel-Auslieferungsliste.xlsx" if mit_id
                                              else "Beispiel-Auslieferungsliste-ohne-ID.xlsx"))
    wb.save(pfad)
    return pfad


# ---------------------------------------------------------------------- Finanzplanung, Provisionen ---

def schreibe_finanzplanung(ordner) -> str:
    return _flache_liste(
        os.path.join(ordner, "Beispiel-Finanzplanung.xlsx"), "Liquidität", "Liquiditätsplanung 2026/27",
        ["Datum", "Art", "Richtung", "Kategorie", "Betrag", "Konto", "Bezeichnung", "Interne ID"],
        [["01.10.2026", "Ist", "Ein", "Verkauf", "72.400,00", "Sparkasse", "Verkauf Linea 600 DR", "DETKW00191"],
         [datetime(2026, 10, 5), "Ist", "Aus", "Löhne", -48500, "Sparkasse", "Löhne Oktober", None],
         ["15.12.2026", "Plan", None, "Fahrzeugeinkauf", "-139.690,30 €", "Nordbank", "Ablösung Alto", "DRM 245"],
         ["2030-01-15", None, None, "Miete", -6500, "Sparkasse", "Miete Januar", None],
         [None, "Plan", "Ein", "Verkauf", 1000, None, "ohne Datum", None]])


def schreibe_provisionen(ordner) -> str:
    pfad = _flache_liste(
        os.path.join(ordner, "Beispiel-Provisionen.xlsx"), "Provisionen", "Provisionsliste 2026",
        ["Verkäufer", "Interne ID", "Verkaufsdatum", "Bemessungsgrundlage", "Satz", "Provision", "Status",
         "Auszahlungsdatum"],
        [["Jan", "DETKW00142", "12.06.2026", "6.500,00", "10 %", None, "offen", None],
         ["Uwe", "SLKW00272", datetime(2026, 8, 12), 4200, 0.08, 336, "ausgezahlt", "30.09.2026"],
         ["Kai", "DRM 245", "01.07.2026", 12000, 5, None, "ja", None]])
    return pfad


# ------------------------------------------------------------------------------------ Teilepreise ---

def schreibe_teilepreise(ordner) -> str:
    """Port der flachen Teile- und Einbaupreisliste aus beispiel-excel.ts."""
    return _flache_liste(
        os.path.join(ordner, "Beispiel-Teilepreise.xlsx"), "Preisliste",
        "Teile- und Einbaupreisliste inkl. Montagezeiten",
        ["Artikelnummer", "Bezeichnung", "Warengruppe", "Lieferant", "EK netto", "VK netto", "Montagezeit",
         "Stundensatz"],
        [["ZUB-2003", "Solaranlage 300 Wp inkl. MPPT-Regler", "Solar", "Büttner", "890,00", "1.490,00", 285, "119,00"],
         ["ZUB-3003", "Sat-Anlage Oyster 85 Vision", "Sat & TV", "Ten Haaft", "2.890,00", "3.790,00", 330, "119,00"],
         ["ZUB-6003", "Truma Combi 6 E Nachrüstung", "Heizung", "Truma", "2.150,00", "2.990,00", 480, None],
         ["ZUB-9004", "Reifendruckkontrollsystem 4 Sensoren", "Sicherheit", "Tiretronic", "240,00", "429,00", 75,
          "119,00"]])


# Teileliste: B Code, C Movera-Nr., D Bezeichnung, E Link, F Bestand, G Gewicht, H Set-Preis, I Preis brutto,
# J Einzelteil VK, K Kleinteile, L Lohn VK, M VK je AW, N AW, O Minuten, P Teil-EK netto, Q Lohn-EK, R Gesamt-EK brutto
TEILELISTE = [
    ("abschnitt", "Kastenwagen H2 Dach (Standard)"),
    ("gruppe", "Markisen", "Thule Omnistor 6300", 15, 90),
    ("teil", "SA00100", "0990012345", "weiß 4,05 m", 21.5, None, 1290.00, None, 5, 180, 12, None, None, 702.00,
     98.75, None),
    ("teil", "SA00101", "990012346", "silber 4,05 m", 21.5, None, 1310.00, None, 5, 180, 12, None, None, 718.80,
     98.75, None),
    ("teil", "SA00102", "990012347", "anthrazit 5,41 m", 28.0, None, 1590.00, None, 5, 180, 12, None, None, 843.60,
     98.75, None),
    ("gruppe", "Solar", "Solaranlage 150 Wp", None, None),
    ("anmerkung", "Beim Hersteller3 Vario wird zusätzlich ein Adapter benötigt"),
    ("teil", "SO00200", "990022001", "komplett mit Regler", 12.0, None, 890.00, None, 8, 240, 12, 20, 120, 512.00,
     133.00, None),
    ("teil", None, "4711", "Kabelsatz Solar (Fremdartikel)", None, None, 49.00, None, None, None, None, None, None,
     22.50, None, None),
    ("abschnitt", "Kastenwagen Linea auf VW Crafter"),
    ("gruppe", "AHK", "Anhängerkupplung", None, None),
    ("teil", "AH00300", "990033001", "starr", 31.0, None, 1190.00, None, 10, 360, 12, 30, 180, 640.00, 197.50,
     955.15),
    ("teil", "AH00301", "990033002", "abnehmbar", 33.0, None, 1390.00, None, 10, 360, 12, 30, 180, 760.00, 197.50,
     None),
    # Set mit Stückliste wie in der echten Liste: der Kopf hat einen Code, die Positionen darunter nur die
    # fortlaufende Artikelnummer; alle drei Bezeichnungen gleich grün hinterlegt. F ist der Lagerbestand
    # (in der echten Datei ein Verweis auf den Artikelstamm), der Preis einer Position steht in H, der rote Preis in I
    # ist Einzelteil-VK + Lohn + Kleinteile + Positionen.
    ("gruppe", "Elektronik", "Internet und WLAN", None, None),
    ("set", "SA09550", "Giba1", "GIBAnet 5G Premium 5G/LTE/WIFI Set", 4, "3,0 kg", 2190.00, 2222.00, 1499.00, 15,
     480, 12, 40, 240, 1045.52, 265, 1559.52),
    ("set", None, "Giba2", "Set Dachhalter-Montagekit für GIBAnet 5G", 2, None, 149.00, None, None, None, None, None,
     None, None, 98.92, None, None),
    ("set", None, "Giba3", "Set SMA Verlängerungen 1m für GIBAnet 5G", 4, None, 79.00, None, None, None, None, None,
     None, None, 52.45, None, None),
    ("abschnitt", "Reisemobil"),
    ("gruppe", "Sat & TV", "SAT-Anlage", None, None),
    ("teil", "SA03100", "990044001", "Caro Sidetrack 85 cm", 18.0, None, 2490.00, None, 10, 360, 12, 30, 180, 1690.00,
     197.50, None),
]
SET_FUELLUNG = design(9, HELLER_60)            # Grün, Akzent 6, heller 60 %
# Artikelstamm: Nummer, Bezeichnung, Bestand, Stamm-EK, Stamm-VK
STAMM_FEST = [
    ["0990012345", "Thule Omnistor 6300 weiß 4,05 m", 2, 702.0, 1290.0],
    [990022001, "Solaranlage 150 Wp komplett", 0, 512.0, 890.0],
    ["Giba1", "GIBAnet 5G Premium Set", 4, 1045.52, 1499.0],
    ["Giba2", "Dachhalter-Montagekit GIBAnet 5G", 2, 98.92, 149.0],
    ["Giba3", "SMA Verlängerungen 1 m GIBAnet 5G", 4, 52.45, 79.0],
]


def schreibe_teileliste(ordner, artikel: int = 300, dateiname: str = "Beispiel-Teile_und_Einbaupreise.xlsx") -> str:
    """
    Teileliste im Aufbau der echten Datei (gegliedert, Kopf in Zeile 1–5, Daten ab Zeile 6) plus Artikelstamm
    „Bestand (2)“ mit `artikel` Zeilen und dem kürzeren Doppel „M“, das der Import nicht lesen soll.
    Schreibt im write-only-Modus, damit auch 50.000 Artikel schnell gehen.
    """
    wb = Workbook(write_only=True)
    wb.loaded_theme = office_thema()
    ws = wb.create_sheet("Teileliste")
    fett = Font(bold=True)
    gruen = fuellung(SET_FUELLUNG)
    rot = Font(color="FFFF0000")

    def zeile(werte, fett_spalte=None, stile=None):
        zellen = []
        for i, w in enumerate(werte):
            c = WriteOnlyCell(ws, value=w)
            if fett_spalte is not None and i == fett_spalte:
                c.font = fett
            for attr, wert in (stile or {}).get(i, {}).items():
                setattr(c, attr, wert)
            zellen.append(c)
        ws.append(zellen)

    zeile(["Teile- und Einbaupreise"], 0)
    zeile([None, "VK je AW brutto", 12])
    zeile([None, "Lohn-EK je AW", 6.25])
    zeile([])
    zeile([None, "Code", "Artikel-Nr.", "Bezeichnung", "Link", "Bestand", "Gewicht", "Set-Preis", "Preis brutto",
           "Einzelteil VK", "Kleinteile", "Lohn VK", "VK/AW", "AW", "Minuten", "EK netto", "Lohn EK",
           "Gesamt EK brutto"])
    for t in TEILELISTE:
        if t[0] in ("abschnitt", "anmerkung"):
            zeile([None, None, None, t[1]], 3)
        elif t[0] == "gruppe":
            _, gruppe, produkt, aw, minuten = t
            zeile([None, gruppe, None, produkt, None, None, None, None, None, None, None, None, None, aw, minuten])
        elif t[0] == "set":
            _, code, nr, text, bestand, *rest = t
            stile = {3: {"fill": gruen}, 8: {"font": rot}} if code else {3: {"fill": gruen}}
            zeile([None, code, nr, text, None, bestand, *rest], stile=stile)
        else:
            _, code, nr, text, gewicht, set_preis, brutto, einzel, klein, lohn, vk_aw, aw, minuten, ek, lohn_ek, \
                gesamt = t
            link = '=HYPERLINK("https://www.movera.com/DE/de/product/"&C1,"Zum Artikel")' if nr else None
            zeile([None, code, nr, text, link, None, gewicht, set_preis, brutto, einzel, klein, lohn, vk_aw, aw,
                   minuten, ek, lohn_ek, gesamt])
    for name, anzahl in (("Bestand (2)", artikel), ("M", min(artikel, 50))):
        stamm = wb.create_sheet(name)
        stamm.append(["Artikelnummer", "Bezeichnung", "Bestand", "Stamm-EK", "Stamm-VK"])
        for fest in STAMM_FEST:
            stamm.append(fest)
        for i in range(max(0, anzahl - len(STAMM_FEST))):
            stamm.append([str(9910000000 + i), f"Artikel {i} – Zubehör", i % 7, round(10 + i % 300 * 1.5, 2),
                          round((10 + i % 300 * 1.5) * 1.6, 2)])
    pfad = os.path.join(ordner, dateiname)
    wb.save(pfad)
    return pfad


# ------------------------------------------------------------------------------------ Urlaubsplaner ---

FEIERTAGE_2026 = [date(2026, 1, 1), date(2026, 4, 3), date(2026, 4, 6), date(2026, 5, 1), date(2026, 5, 14),
                  date(2026, 5, 25), date(2026, 10, 3), date(2026, 12, 25), date(2026, 12, 26)]
URLAUB_FARBEN = {"Wochenende": "FFFF99", "Feiertag": "FF99CC", "Schulferien": "D9D9D9", "möglich": "92D050",
                 "möglich 2": "F8CBAD", "Shop möglich": "9BC2E6", "nicht möglich": "FF0000",
                 "belegt orange": "FFC000", "belegt gelb": "FFFF00"}


def _tage(von: date, bis: date, nur_werktage=True):
    d = von
    while d <= bis:
        if not nur_werktage or d.weekday() < 5:
            yield d
        d += timedelta(days=1)


# Werkstattblatt: Zeile → {Tag: (Text, Farbe)}
def _eintraege_werkstatt():
    e = {"Werkstatt": {}, "Waschplatz": {}, "Shop": {}}
    for d in _tage(date(2026, 8, 10), date(2026, 8, 14)):
        e["Werkstatt"][d] = ("Paul", "belegt orange")
    for d in _tage(date(2026, 8, 17), date(2026, 8, 21)):
        e["Werkstatt"][d] = ("Emre", "belegt gelb")
    for d in (date(2026, 12, 28), date(2026, 12, 29)):
        e["Werkstatt"][d] = ("Paul/Emre", "belegt orange")
    e["Werkstatt"][date(2026, 11, 13)] = ("Ole ½", "belegt orange")
    e["Werkstatt"][date(2026, 6, 15)] = ("x", "belegt gelb")              # Kürzel in einer Team-Zeile: unklar
    for d in _tage(date(2026, 7, 6), date(2026, 7, 7)):
        e["Waschplatz"][d] = ("Timo", "belegt orange")
    for d in _tage(date(2026, 10, 26), date(2026, 10, 30)):
        e["Shop"][d] = ("Rita", "belegt gelb")
    e["Shop"][date(2026, 11, 2)] = (None, "belegt orange")               # belegt, aber ohne Namen
    return e


def _eintraege_vorne():
    e = {"Kai/Uwe/Jan": {}, "Jan/Ben/Finn": {}, "Sina": {}, "Nora": {}}
    for d in _tage(date(2026, 8, 3), date(2026, 8, 7)):
        e["Kai/Uwe/Jan"][d] = ("Kai", "belegt gelb")
    e["Kai/Uwe/Jan"][date(2026, 12, 2)] = ("uwe", "belegt gelb")
    for d in _tage(date(2026, 8, 24), date(2026, 8, 28)):
        e["Jan/Ben/Finn"][d] = ("Jan", "belegt orange")
    for d in (date(2026, 10, 22), date(2026, 10, 23)):
        e["Sina"][d] = ("x", "belegt orange")                          # Einzelperson: „x“ heißt Sina
    e["Nora"][date(2026, 11, 16)] = ("Nora", "belegt gelb")
    return e


def _hintergrund(d: date, zeile: str):
    """Farbe einer Tageszelle ohne Eintrag: Wochenende, Feiertag, Schulferien, Sperre, möglich."""
    if d in FEIERTAGE_2026:
        return "Feiertag"
    if d.weekday() >= 5:
        return "Wochenende"
    if zeile == "Werkstatt" and d.month == 3:
        return "nicht möglich"                                  # Hauptsaison: Urlaub nicht möglich
    if date(2026, 7, 30) <= d <= date(2026, 9, 12):
        return "Schulferien"
    if d.month == 11:
        return "Shop möglich" if zeile == "Shop" else "möglich"
    if d.month == 1 and zeile == "Werkstatt":
        return "möglich 2"
    return None


def schreibe_urlaubsplaner(ordner) -> str:
    """
    Urlaubsplaner nach dem Lastenheft (die echte Datei kennen wir nicht): „2026 Werkstatt“ mit 12 Monatsblöcken
    nebeneinander (Monat über 31 Spalten verbunden, Tageszahlen darunter, Wochentage, Zeilen Werkstatt/Waschplatz/
    Shop, Legende unten) und „2026 Vorne“ mit Monatsblöcken untereinander (Monat links, Teams als Zeilen).
    """
    wb = _neue_mappe("2026 Werkstatt")
    ws = wb.active
    ws.cell(row=1, column=1, value="Urlaubsplaner 2026 – Werkstatt").font = Font(bold=True, size=14)
    zeilen = ["Werkstatt", "Waschplatz", "Shop"]
    eintraege = _eintraege_werkstatt()
    for i, name in enumerate(zeilen):
        ws.cell(row=5 + i, column=1, value=name).font = Font(bold=True)
    for monat in range(1, 13):
        start = 2 + (monat - 1) * 31
        kopf = ws.cell(row=2, column=start)
        if monat == 3:
            kopf.value = datetime(2026, 3, 1)                     # Monatskopf als Datum, angezeigt als „März“
            kopf.number_format = "MMMM"
        else:
            kopf.value = ("Januar 2026" if monat == 1 else
                          ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September",
                           "Oktober", "November", "Dezember"][monat - 1])
        ws.merge_cells(start_row=2, start_column=start, end_row=2, end_column=start + 30)
        for tag in range(1, calendar.monthrange(2026, monat)[1] + 1):
            d = date(2026, monat, tag)
            spalte = start + tag - 1
            ws.cell(row=3, column=spalte, value=f"{tag}." if monat == 4 else tag)
            ws.cell(row=4, column=spalte, value=["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"][d.weekday()])
            for r in (3, 4):
                if d in FEIERTAGE_2026 or d.weekday() >= 5:
                    ws.cell(row=r, column=spalte).fill = fuellung(URLAUB_FARBEN[_hintergrund(d, "")])
            for i, name in enumerate(zeilen):
                c = ws.cell(row=5 + i, column=spalte)
                text, farbe = eintraege[name].get(d, (None, _hintergrund(d, name)))
                c.value = text
                if farbe:
                    c.fill = fuellung(URLAUB_FARBEN[farbe])
    # Legende unter dem Plan: Farbe in A, Text in B (B ist zugleich die Spalte des 1. Januar)
    ws.cell(row=10, column=1, value="Legende").font = Font(bold=True)
    for i, (text, farbe) in enumerate((("Wochenende", "Wochenende"), ("Feiertag", "Feiertag"),
                                       ("Schulferien", "Schulferien"), ("Urlaub möglich", "möglich"),
                                       ("Urlaub nicht möglich", "nicht möglich"), ("Urlaub belegt", "belegt gelb"))):
        ws.cell(row=11 + i, column=1).fill = fuellung(URLAUB_FARBEN[farbe])
        ws.cell(row=11 + i, column=2, value=text)
    ws.column_dimensions["A"].width = 14

    # Blatt „Vorne“: Monatsblöcke untereinander
    wv = wb.create_sheet("2026 Vorne")
    wv.cell(row=1, column=1, value="Urlaubsplaner Vorne").font = Font(bold=True, size=14)
    teams = list(_eintraege_vorne())
    eintraege = _eintraege_vorne()
    r = 3
    for monat in range(1, 13):
        wv.cell(row=r, column=1, value=("Januar 2026" if monat == 1 else
                                        ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August",
                                         "September", "Oktober", "November", "Dezember"][monat - 1])).font = Font(
            bold=True)
        for tag in range(1, calendar.monthrange(2026, monat)[1] + 1):
            d = date(2026, monat, tag)
            wv.cell(row=r + 1, column=1 + tag, value=tag)
            for i, team in enumerate(teams):
                c = wv.cell(row=r + 2 + i, column=1 + tag)
                text, farbe = eintraege[team].get(d, (None, None))
                if farbe is None and (d in FEIERTAGE_2026 or d.weekday() >= 5):
                    farbe = _hintergrund(d, "")
                c.value = text
                if farbe:
                    c.fill = fuellung(URLAUB_FARBEN[farbe])
        for i, team in enumerate(teams):
            wv.cell(row=r + 2 + i, column=1, value=team)
        r += 2 + len(teams) + 1
    wv.column_dimensions["A"].width = 20
    pfad = os.path.join(ordner, "Beispiel-Urlaubsplaner.xlsx")
    wb.save(pfad)
    return pfad


# Echter Jahresplaner (nach dem Bildschirmfoto des Inhabers). Die Töne sind bewusst nicht die aus farben.json:
# der Leser muss sie aus der Legende im Blatt lernen. Gelb heißt wie im Original Wochenende UND belegt.
ECHT_FARBEN = {"Wochenende": "FFFF00", "Feiertag": "FFCCFF", "Schulferien": "BFBFBF", "möglich": "00B050",
               "möglich 2": "C4BD97", "Shop möglich": "9DC3E6", "nicht möglich": "FF0000", "belegt orange": "FFC000",
               "belegt gelb": "FFFF00"}
ECHT_MONATE = ("Jan", "Feb", "Mrz", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez")
ECHT_REGELTEXT = ["Bei der Urlaubsplanung bitten wir folgendes zu berücksichtigen.",
                  "Aus folgenden Gruppen kann immer nur eine Person gleichzeitig Urlaub machen:",
                  "1. M. Albers-Christoph-Brandt-Wessels", "2. Brandt-Kruse-Lange", "3. Meyer-T. Albers-Ohlsen",
                  "Während Hausmesse 19.04. bis 28.04. kein Urlaub"]


def _feiertage_echt(jahr):
    from .demo import feiertage
    return set(feiertage(jahr))


def _jahresplaner_blatt(ws, jahr, zeilen, eintraege, notizen, monate=range(1, 13), rot=()):
    """
    Ein Blatt im Aufbau des echten Jahresplaners: Titel und Betriebsurlaub-Text in Zeile 1, Legende in Zeile 2,
    Tageszahlen 1–31 nur einmal in Zeile 4, darunter je Monat: Monatszeile („Jan“, „Fr“, „Sa“, „Mo 1“),
    Notizzeile, Bereichszeilen. `zeilen`: Monat → Zeilennamen („Werkstatt 1“ … – Nummer fällt in Spalte A weg),
    `eintraege`: (Zeilenname, Datum) → (Text, Farbe), `rot`: (Monat, Zeilenname, „schrift“/„fuellung“).
    Gibt die nächste freie Zeile zurück.
    """
    feiertage = _feiertage_echt(jahr)
    ws.cell(row=1, column=1, value=f"Jahresplaner {jahr}").font = Font(bold=True, size=14)
    # Tippfehler im Jahr wie im Original – der Leser darf sich darauf nicht verlassen
    c = ws.cell(row=1, column=12, value=f"Urlaub für 24.12.{jahr % 100} bis 31.12.{(jahr - 1) % 100} (5 Tage)")
    c.fill = fuellung(ECHT_FARBEN["belegt gelb"])
    ws.cell(row=2, column=1, value="Legende:").font = Font(bold=True)
    # Farbe mit Text darin; Khaki und Orange ohne Text (zweiter Ton derselben Bedeutung wie der Nachbar)
    for spalte, text, farbe in ((2, "Wochenende", "Wochenende"), (5, "Feiertag", "Feiertag"),
                                (8, "Schulferien", "Schulferien"),
                                (11, "Urlaub Werkstatt/Waschplatz möglich", "möglich"), (12, None, "möglich 2"),
                                (15, "Urlaub Shop möglich", "Shop möglich"),
                                (18, "Urlaub nicht möglich", "nicht möglich"), (20, None, "belegt orange"),
                                (21, "Urlaub belegt", "belegt gelb")):
        c = ws.cell(row=2, column=spalte, value=text)
        c.fill = fuellung(ECHT_FARBEN[farbe])
    for tag in range(1, 32):
        ws.cell(row=4, column=1 + tag, value=tag).font = Font(bold=True)
    r = 5
    for monat in monate:
        tage_im_monat = calendar.monthrange(jahr, monat)[1]
        ws.cell(row=r, column=1, value=ECHT_MONATE[monat - 1]).font = Font(bold=True)
        for tag in range(1, tage_im_monat + 1):
            d = date(jahr, monat, tag)
            kurz = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"][d.weekday()]
            c = ws.cell(row=r, column=1 + tag, value=f"Mo {d.isocalendar()[1]}" if kurz == "Mo" else kurz)
            if d in feiertage:
                c.fill = fuellung(ECHT_FARBEN["Feiertag"])
            elif d.weekday() >= 5:
                c.fill = fuellung(ECHT_FARBEN["Wochenende"])
            if d in notizen:
                ws.cell(row=r + 1, column=1 + tag, value=notizen[d])
        namen = zeilen[monat]
        for i, zeile in enumerate(namen):
            zr = r + 2 + i
            bezeichnung = zeile.rstrip(" 0123456789")
            if not (zeile.startswith("Werkstatt") and i > 0 and monat == 12):
                ws.cell(row=zr, column=1, value=bezeichnung)
            for m, z, art in rot:
                if (m, z) == (monat, zeile):
                    if art == "schrift":
                        ws.cell(row=zr, column=1).font = Font(color="FFFF0000")
                    else:
                        ws.cell(row=zr, column=1).fill = fuellung(ECHT_FARBEN["nicht möglich"])
            for tag in range(1, tage_im_monat + 1):
                d = date(jahr, monat, tag)
                c = ws.cell(row=zr, column=1 + tag)
                text, farbe = eintraege.get((zeile, d), (None, None))
                c.value = text
                if farbe is None:
                    farbe = ("Feiertag" if d in feiertage else "Wochenende" if d.weekday() >= 5 else
                             "nicht möglich" if date(jahr, 4, 19) <= d <= date(jahr, 4, 28) else
                             "Schulferien" if monat in (7, 8) else
                             ("Shop möglich" if zeile == "Shop" else "möglich") if monat == 1 else
                             "möglich 2" if monat == 2 and zeile.startswith("Werkstatt") else None)
                if farbe:
                    c.fill = fuellung(ECHT_FARBEN[farbe])
        if monat == 12 and sum(z.startswith("Werkstatt") for z in namen) > 1:
            # „Werkstatt“ über alle Werkstattzeilen verbunden – Spalte A ist dann nur in der ersten gefüllt
            anzahl = sum(z.startswith("Werkstatt") for z in namen)
            ws.merge_cells(start_row=r + 2, start_column=1, end_row=r + 1 + anzahl, end_column=1)
        r += 2 + len(namen)
    ws.column_dimensions["A"].width = 12
    for tag in range(1, 32):
        ws.column_dimensions[ws.cell(row=4, column=1 + tag).column_letter].width = 6
    return r


def _textfeld_einfuegen(pfad: str, blatt: int, zeilen: list, ab_zeile: int):
    """
    Ein Textfeld (Zeichnungsebene) wie im echten Plan nachträglich in die Datei setzen – openpyxl kann keine
    Textfelder schreiben. `blatt`: Nummer des Blatts (1 = erstes), `ab_zeile`: Excel-Zeile der linken oberen Ecke.
    """
    with zipfile.ZipFile(pfad) as alt:
        inhalte = {n: alt.read(n) for n in alt.namelist()}
    absaetze = "".join(
        f'<a:p><a:r><a:rPr lang="de-DE" b="1"><a:solidFill><a:srgbClr val="FF0000"/></a:solidFill></a:rPr>'
        f'<a:t>{z.replace("&", "&amp;").replace("<", "&lt;")}</a:t></a:r></a:p>' for z in zeilen)
    inhalte["xl/drawings/drawing1.xml"] = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><xdr:twoCellAnchor>'
        f'<xdr:from><xdr:col>1</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>{ab_zeile - 1}</xdr:row>'
        '<xdr:rowOff>0</xdr:rowOff></xdr:from>'
        f'<xdr:to><xdr:col>24</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>{ab_zeile + 5}</xdr:row>'
        '<xdr:rowOff>0</xdr:rowOff></xdr:to>'
        '<xdr:sp macro="" textlink=""><xdr:nvSpPr><xdr:cNvPr id="2" name="Textfeld 1"/><xdr:cNvSpPr txBox="1"/>'
        '</xdr:nvSpPr><xdr:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="FFFF00"/></a:solidFill>'
        '<a:ln><a:solidFill><a:srgbClr val="FF0000"/></a:solidFill></a:ln></xdr:spPr>'
        f'<xdr:txBody><a:bodyPr wrap="square"/><a:lstStyle/>{absaetze}</xdr:txBody></xdr:sp><xdr:clientData/>'
        '</xdr:twoCellAnchor></xdr:wsDr>').encode("utf-8")
    rels = f"xl/worksheets/_rels/sheet{blatt}.xml.rels"
    verweis = ('<Relationship Id="rIdTextfeld1" Target="../drawings/drawing1.xml" '
               'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing"/>')
    if rels in inhalte:
        inhalte[rels] = inhalte[rels].replace(b"</Relationships>", verweis.encode() + b"</Relationships>")
    else:
        inhalte[rels] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships '
                         'xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                         f'{verweis}</Relationships>').encode("utf-8")
    name = f"xl/worksheets/sheet{blatt}.xml"
    inhalte[name] = inhalte[name].replace(
        b"</worksheet>", b'<drawing xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
                         b'r:id="rIdTextfeld1"/></worksheet>')
    inhalte["[Content_Types].xml"] = inhalte["[Content_Types].xml"].replace(
        b"</Types>", b'<Override PartName="/xl/drawings/drawing1.xml" '
                     b'ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>')
    tmp = pfad + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as neu:
        for n, inhalt in inhalte.items():
            neu.writestr(n, inhalt)
    os.replace(tmp, pfad)


def schreibe_urlaubsplaner_echt(ordner) -> str:
    """
    Nachbau des echten Jahresplaners (Aufbau aus dem Bildschirmfoto, Namen erfunden):
    - „2027 Werkstatt“: alle zwölf Monate untereinander unter einer Tageszeile, Notizzeile mit Feiertagen, Hausmesse,
      ABF, DüDo; „Alle“ im Dezember (Betriebsurlaub); rot markierte Beschriftungen in Spalte A (Zeile 31, 49 und 50);
      die Regeln stehen in einem Textfeld unten (Zeichnungsebene, nicht in Zellen).
    - „2027 Vorne“: Januar bis März und Dezember, Teams als Zeilen, Regeln in einer verbundenen Zelle.
    - „2026 Werkstatt“: Januar und Dezember, Regeln Zeile für Zeile in Zellen.
    Nicht in schreibe_alle(): dort prüfen Tests die genaue Liste der Beispieldateien.
    """
    wb = _neue_mappe("2027 Werkstatt")
    ws = wb.active
    normal = ["Werkstatt 1", "Werkstatt 2", "Waschplatz", "Shop"]
    zeilen = {m: list(normal) for m in range(1, 13)}
    zeilen[12] = ["Werkstatt 1", "Werkstatt 2", "Werkstatt 3", "Waschplatz", "Shop"]
    e = {}
    for d in _tage(date(2027, 1, 4), date(2027, 1, 8)):
        e[("Werkstatt 1", d)] = ("Lars", "belegt orange")
    for d in (date(2027, 1, 11), date(2027, 1, 12)):
        e[("Werkstatt 2", d)] = ("Timo", "belegt gelb")
    e[("Waschplatz", date(2027, 1, 18))] = ("Ole", "belegt gelb")
    for d in (date(2027, 1, 20), date(2027, 1, 21)):
        e[("Shop", d)] = ("Anke", "belegt orange")
    e[("Werkstatt 1", date(2027, 2, 15))] = ("Nico/Jonas", "belegt orange")
    e[("Werkstatt 2", date(2027, 2, 19))] = ("Malte ½", "belegt gelb")
    for d in _tage(date(2027, 3, 22), date(2027, 3, 25)):
        e[("Werkstatt 1", d)] = ("Bernd", "belegt orange")
    e[("Werkstatt 1", date(2027, 8, 26))] = ("DüDo", "belegt gelb")           # Messe: steht auch in der Notizzeile
    for d in _tage(date(2027, 12, 20), date(2027, 12, 23)):
        e[("Werkstatt 3", d)] = ("Karsten", "belegt orange")                # Zeile ohne eigene Beschriftung
    for d in (date(2027, 12, 24), date(2027, 12, 27), date(2027, 12, 28), date(2027, 12, 29), date(2027, 12, 30),
              date(2027, 12, 31)):
        e[("Werkstatt 1", d)] = ("Alle", "belegt gelb")
        e[("Shop", d)] = ("Alle", "belegt gelb")
    notizen = {date(2027, 1, 1): "Neujahr", date(2027, 1, 29): "ABF", date(2027, 3, 26): "Karfreit.",
               date(2027, 3, 29): "Ostermon.", date(2027, 4, 19): "Hausmesse", date(2027, 5, 6): "Christi",
               date(2027, 5, 17): "Pfingst.", date(2027, 8, 26): "DüDo", date(2027, 10, 3): "Dt.Einh",
               date(2027, 10, 31): "Reformtag", date(2027, 12, 24): "Heil.Ab.", date(2027, 12, 25): "Weihn",
               date(2027, 12, 31): "Silvester"}
    rot = [(5, "Werkstatt 1", "schrift"), (8, "Werkstatt 1", "fuellung"), (8, "Werkstatt 2", "fuellung")]
    ende = _jahresplaner_blatt(ws, 2027, zeilen, e, notizen, rot=rot)

    wv = wb.create_sheet("2027 Vorne")
    teams = ["Kai/Uwe/Jan", "Sina"]
    ev = {}
    for d in _tage(date(2027, 1, 11), date(2027, 1, 15)):
        ev[("Kai/Uwe/Jan", d)] = ("Kai", "belegt gelb")
    ev[("Sina", date(2027, 2, 3))] = ("x", "belegt orange")
    for d in (date(2027, 12, 24), date(2027, 12, 27), date(2027, 12, 28), date(2027, 12, 29), date(2027, 12, 30),
              date(2027, 12, 31)):
        ev[("Kai/Uwe/Jan", d)] = ("Alle", "belegt gelb")
    monate = (1, 2, 3, 12)
    r = _jahresplaner_blatt(wv, 2027, {m: list(teams) for m in monate}, ev, {date(2027, 1, 1): "Neujahr"}, monate)
    wv.cell(row=r + 3, column=2, value="\n".join(ECHT_REGELTEXT)).fill = fuellung(ECHT_FARBEN["belegt gelb"])
    wv.merge_cells(start_row=r + 3, start_column=2, end_row=r + 5, end_column=25)

    w26 = wb.create_sheet("2026 Werkstatt")
    e26 = {}
    for d in _tage(date(2026, 12, 14), date(2026, 12, 18)):
        e26[("Werkstatt 1", d)] = ("Lars", "belegt orange")
    for d in (date(2026, 12, 24), date(2026, 12, 28), date(2026, 12, 29), date(2026, 12, 30), date(2026, 12, 31)):
        e26[("Werkstatt 1", d)] = ("Alle", "belegt gelb")
    z26 = {1: list(normal), 12: ["Werkstatt 1", "Werkstatt 2", "Waschplatz", "Shop"]}
    r = _jahresplaner_blatt(w26, 2026, z26, e26, {date(2026, 12, 25): "Weihn"}, (1, 12))
    for i, text in enumerate(ECHT_REGELTEXT):
        w26.cell(row=r + 2 + i, column=2, value=text).font = Font(bold=True, color="FFFF0000")

    pfad = os.path.join(ordner, "Beispiel-Jahresplaner-echt.xlsx")
    wb.save(pfad)
    _textfeld_einfuegen(pfad, 1, ECHT_REGELTEXT, ende + 6)
    return pfad


# ----------------------------------------------------------------------------------------- Alle ---

def schreibe_alle(ordner, artikel: int = 300) -> dict:
    """Alle Beispieldateien in `ordner`; Listentyp → Pfad (plus Varianten mit eigenem Schlüssel)."""
    os.makedirs(ordner, exist_ok=True)
    return {
        "bestandsliste": schreibe_bestandsliste_jahresblaetter(ordner),
        "bestandsliste_alt": schreibe_bestandsliste(ordner),
        "finanzierungen": schreibe_finanzaufstellung(ordner),
        "finanzierungen_flach": schreibe_finanzierungen(ordner),
        "auslieferungen": schreibe_auslieferungsliste(ordner),
        "auslieferungen_ohne_id": schreibe_auslieferungsliste(ordner, mit_id=False),
        "finanzplanung": schreibe_finanzplanung(ordner),
        "provisionen": schreibe_provisionen(ordner),
        "teilepreise": schreibe_teileliste(ordner, artikel),
        "teilepreise_flach": schreibe_teilepreise(ordner),
        "urlaubsplaner": schreibe_urlaubsplaner(ordner),
    }


def selbsttest(ordner=None) -> dict:
    """Beispieldateien schreiben und in eine leere Datenbank einlesen – für ODINs Selbsttest. Zeilen je Liste."""
    from .db import neue_db
    from .importer import importiere
    eigener = ordner is None
    ordner = ordner or tempfile.mkdtemp(prefix="odin-cockpit-")
    try:
        dateien = schreibe_alle(ordner)
        db = neue_db()
        ergebnis = {}
        for art in ("bestandsliste", "finanzierungen", "auslieferungen", "finanzplanung", "provisionen",
                    "teilepreise", "urlaubsplaner"):
            bericht = importiere(db, dateien[art])
            assert not bericht["fehler"], (art, bericht["fehler"])
            assert bericht["art"] == art, (art, bericht["art"])
            assert bericht["zeilen_geschrieben"] > 0, art
            ergebnis[art] = bericht["zeilen_geschrieben"]
        db.close()
        return ergebnis
    finally:
        if eigener:
            shutil.rmtree(ordner, ignore_errors=True)
