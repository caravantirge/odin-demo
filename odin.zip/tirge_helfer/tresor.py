"""
Anmeldung in ODIN („Tresor“): erst die Person wählen, dann ihre PIN – erst danach ist man diese Person.

- Wer „ich“ ist, setzt nur noch dieser Ablauf (anmelden mit PIN, PIN festlegen beim ersten Mal) oder die
  Microsoft-Anmeldung, wenn die Person mit dem Microsoft-Konto verknüpft ist (die ist stärker und ersetzt die PIN).
  Ein freies „ich bin jetzt Anna“ gibt es an der Oberfläche nicht mehr.
- Am Rechner gilt die Anmeldung im Arbeitsspeicher von ODIN. „Angemeldet bleiben“ (Standard, je Rechner abschaltbar)
  merkt sie sich zusätzlich verschlüsselt und an diesen Rechner gebunden (Windows: DPAPI, Mac: Schlüsselbund – wie
  die Microsoft-Anmeldung, microsoft.TokenSpeicher). Ohne sicheren Speicher gilt sie nur bis zum Schließen. Eine
  gemerkte Anmeldung verfällt, sobald die PIN der Person geändert oder zurückgesetzt wurde.
- Im Browser (web.py) gilt die Anmeldung für die Sitzung des Geräts; Fehlversuche zählen je Gerät (IP).
- PIN zurücksetzen dürfen nur Verwalter (die Urlaubs-Genehmiger) und nur am Rechner – danach legt die Person beim
  nächsten Anmelden eine neue PIN fest und sieht, wer sie wann zurückgesetzt hat.
"""

import datetime as dt
import json
import os
import time

from .microsoft import TokenSpeicher
from .pin import PIN_MAX, PIN_MIN, Fehlversuche, PinFehler, hash_vergleichen, pin_pruefen_form
from .projekte import ProjektFehler

SPERRE_MINUTEN = (0, 5, 15, 30, 60)            # automatische Sperre nach Inaktivität (0 = aus)


class GemerkteAnmeldung(TokenSpeicher):
    """„Angemeldet bleiben“: wer an diesem Rechner angemeldet ist – verschlüsselt wie die Microsoft-Anmeldung, nie als
    lesbare Person-ID in einer Datei."""

    def __init__(self, ordner: str, plattform: str = None):
        super().__init__(ordner, plattform, dienst="ODIN Anmeldung")

    @property
    def pfad(self) -> str:
        return os.path.join(self.ordner, "anmeldung-gemerkt.json")


def _minuten(sekunden: int) -> str:
    m = max(1, round(sekunden / 60))
    return "1 Minute" if m == 1 else f"{m} Minuten"


class Tresor:
    """'projekte': Projekte (mit .pins), 'geraet()': „rechner“ oder „web:<ip>“, 'im_web()': läuft gerade eine Anfrage
    aus dem Browser, 'verwalter()': ist die angemeldete Person Verwalter, 'einstellungen'/'speichere': Einstellungen
    dieses Rechners, 'gemerkt': GemerkteAnmeldung (oder None), 'uhr': Sekunden seit 1970 (für Tests)."""

    AKTIONEN = {"status", "anmelden", "pin_festlegen", "pin_aendern", "pin_zuruecksetzen", "pin_uebersicht",
                "abmelden", "einstellungen_speichern"}

    def __init__(self, projekte, geraet=lambda: "rechner", im_web=lambda: False, verwalter=lambda: False,
                 einstellungen=None, speichere=None, gemerkt=None, sperr_datei: str = "", uhr=time.time, protokoll=None):
        self.p = projekte
        self.pins = projekte.pins
        self._geraet = geraet
        self._im_web = im_web
        self._verwalter = verwalter
        self._einst = einstellungen if einstellungen is not None else {}
        self._speichere = speichere or (lambda k, v: self._einst.__setitem__(k, v))
        self._gemerkt = gemerkt
        self._uhr = uhr
        self._protokoll = protokoll or (lambda text: None)
        self.fehl = Fehlversuche(sperr_datei or os.path.join(projekte._ersatz, "pin-sperren.json"), uhr)
        self._rechner_ich = None               # None: gemerkte Anmeldung noch nicht gelesen

    # ---------------- Einstellungen dieses Rechners ----------------
    def bleiben(self) -> bool:
        return self._einst.get("anmeldung_bleiben", True) is not False

    def sperre_minuten(self) -> int:
        wert = self._einst.get("anmeldung_sperre_minuten", 0)
        return wert if wert in SPERRE_MINUTEN else 0

    def einstellungen_speichern(self, bleiben=True, sperre_minuten=0) -> dict:
        if self._im_web():
            raise PinFehler("Das geht nur am Rechner in ODIN.")
        if sperre_minuten not in SPERRE_MINUTEN:
            raise PinFehler("Unbekannte Zeit für die automatische Sperre.")
        self._speichere("anmeldung_bleiben", bool(bleiben))
        self._speichere("anmeldung_sperre_minuten", int(sperre_minuten))
        ich = self.rechner_ich()
        self._merken(ich if bleiben else "")
        return {**self.status(), "meldung": "Gespeichert – gilt für diesen Rechner."}

    # ---------------- Wer ist an diesem Rechner angemeldet ----------------
    def rechner_ich(self) -> str:
        """Die angemeldete Person am Rechner (ohne Microsoft). Beim ersten Mal: gemerkte Anmeldung prüfen."""
        if self._rechner_ich is None:
            self._rechner_ich = ""
            if self._gemerkt is not None and self.bleiben():
                try:
                    daten = json.loads(self._gemerkt.lade() or "{}")
                    pid = str(daten.get("person") or "")
                    gueltig = (pid and any(p["id"] == pid for p in self.p.personen())
                               and daten.get("stand") == self.pins.stand(self.pins.eintrag(pid)))
                except (ValueError, TypeError, AttributeError, ProjektFehler):
                    pid, gueltig = "", False
                if gueltig:
                    self._rechner_ich = pid
                elif self._gemerkt.vorhanden():
                    self._gemerkt.loesche()                # PIN geändert/zurückgesetzt oder Person weg: neu anmelden
        return self._rechner_ich

    def rechner_setzen(self, person_id: str):
        """Nur über anmelden/PIN festlegen/Microsoft – nie direkt aus der Oberfläche."""
        self._rechner_ich = person_id or ""
        self._merken(self._rechner_ich if self.bleiben() else "")
        return True

    def _merken(self, person_id: str):
        if self._gemerkt is None:
            return
        try:
            if person_id:
                stand = self.pins.stand(self.pins.eintrag(person_id))
                self._gemerkt.speichere(json.dumps({"person": person_id, "stand": stand,
                                                    "seit": dt.datetime.fromtimestamp(self._uhr()).isoformat(timespec="seconds")}))
            else:
                self._gemerkt.loesche()
        except (OSError, ProjektFehler) as e:            # merken ist Komfort – die Anmeldung gilt trotzdem
            self._protokoll(f"Anmeldung merken: {e!r}")

    # ---------------- Hilfen ----------------
    def _person(self, person_id) -> dict:
        person = next((p for p in self.p.personen() if p["id"] == person_id and p.get("aktiv", True)), None)
        if not person:
            raise PinFehler("Diese Person gibt es nicht.")
        return person

    def _schluessel(self, person_id: str) -> str:
        return f"{person_id}|{self._geraet() or 'rechner'}"

    def _ms_pruefen(self, person_id: str):
        """Wer mit Microsoft angemeldet (und verknüpft) ist, bleibt diese Person, bis er sich dort abmeldet."""
        if self.p._ich_fest():
            fest = self.p.ich()
            if fest and fest != person_id:
                raise PinFehler("Du bist mit Microsoft angemeldet – zum Wechseln zuerst abmelden.")

    @staticmethod
    def _gesperrt_meldung(warten: int) -> str:
        return f"Zu viele falsche Versuche. Wieder möglich in {_minuten(warten)}."

    def _pruefen(self, person_id: str, pin) -> dict:
        """PIN prüfen und Fehlversuche zählen. {"ok": bool, "grund", "rest", "warten", "meldung"}."""
        schluessel = self._schluessel(person_id)
        warten = self.fehl.warten(schluessel)
        if warten:
            return {"ok": False, "grund": "gesperrt", "warten": warten, "rest": 0, "meldung": self._gesperrt_meldung(warten)}
        eintrag = self.pins.eintrag(person_id)
        if not self.pins.hat_pin(eintrag):
            return {"ok": False, "grund": "pin_fehlt", "warten": 0, "rest": 0,
                    "meldung": "Für dich gibt es noch keine PIN – bitte zuerst eine festlegen."}
        if isinstance(pin, str) and len(pin) <= 64 and hash_vergleichen(pin, eintrag):
            self.fehl.erfolg(schluessel)
            return {"ok": True}
        r = self.fehl.fehler(schluessel)
        if r["warten"]:
            name = next((p["name"] for p in self.p.personen() if p["id"] == person_id), person_id)
            self._protokoll(f"Anmeldung: {name} nach falschen PINs gesperrt ({self._geraet()})")
            return {"ok": False, "grund": "gesperrt", "warten": r["warten"], "rest": 0, "meldung": self._gesperrt_meldung(r["warten"])}
        rest = r["rest"]
        return {"ok": False, "grund": "falsch", "warten": 0, "rest": rest,
                "meldung": "PIN stimmt nicht – noch " + ("1 Versuch." if rest == 1 else f"{rest} Versuche.")}

    def pin_bestaetigen(self, person_id: str, pin) -> bool:
        """Für die Microsoft-Verknüpfung mit einer anderen Person: hat sie eine PIN, muss sie stimmen (zählt als
        Fehlversuch). Ohne PIN: True."""
        if not self.pins.hat_pin(self.pins.eintrag(person_id)):
            return True
        r = self._pruefen(person_id, pin)
        if not r["ok"]:
            raise PinFehler(r["meldung"] if pin else "Für diese Person gilt eine PIN – bitte eingeben.")
        return True

    # ---------------- Oberfläche ----------------
    def status(self) -> dict:
        ich = self.p.ich()
        personen = []
        for p in self.p.personen():
            if not p.get("aktiv", True):
                continue
            try:
                eintrag = self.pins.eintrag(p["id"])
            except PinFehler:
                eintrag = {"hash": "?", "salz": "?"}          # nicht lesbar: lieber nach der PIN fragen
            schluessel = self._schluessel(p["id"])
            z = eintrag.get("zurueckgesetzt") if not self.pins.hat_pin(eintrag) else None
            personen.append({k: p.get(k) for k in ("id", "name", "kuerzel", "farbe", "email")} | {
                "pin": self.pins.hat_pin(eintrag), "warten": self.fehl.warten(schluessel), "rest": self.fehl.rest(schluessel),
                "zurueckgesetzt": {"am": z.get("am", ""), "von_name": z.get("von_name", "")} if isinstance(z, dict) else None})
        web = bool(self._im_web())
        meine = next((x for x in personen if x["id"] == ich), None)
        verwalter = False
        if ich and not web:
            try:
                verwalter = bool(self._verwalter())
            except Exception:                                  # noqa: BLE001 – dann eben ohne Verwalter-Teil
                verwalter = False
        gesetzt_am = ""
        if meine and meine["pin"]:
            try:
                gesetzt_am = self.pins.eintrag(ich).get("gesetzt_am", "")
            except PinFehler:
                pass
        return {"ich": ich, "ich_fest": bool(ich and self.p._ich_fest()), "personen": personen, "web": web,
                "meine_pin": bool(meine and meine["pin"]), "pin_gesetzt_am": gesetzt_am, "verwalter": verwalter,
                "pin_min": PIN_MIN, "pin_max": PIN_MAX,
                "einstellungen": None if web else {"bleiben": self.bleiben(), "sperre_minuten": self.sperre_minuten(),
                                                   "sperre_moeglich": list(SPERRE_MINUTEN),
                                                   "sicher": getattr(self._gemerkt, "plattform", "") in ("win32", "darwin")}}

    def anmelden(self, person_id="", pin="") -> dict:
        person = self._person(person_id)
        self._ms_pruefen(person["id"])
        r = self._pruefen(person["id"], pin)
        if not r["ok"]:
            return {"angemeldet": False, **{k: r[k] for k in ("grund", "rest", "warten", "meldung")}}
        self.p._setze_ich(person["id"])
        return {"angemeldet": True, "ich": person["id"], "person": person}

    def pin_festlegen(self, person_id="", pin="", wiederholung="") -> dict:
        """Beim ersten Anmelden (oder nach einer Zurücksetzung): PIN festlegen und damit anmelden."""
        person = self._person(person_id)
        self._ms_pruefen(person["id"])
        if self.pins.hat_pin(self.pins.eintrag(person["id"])):
            raise PinFehler(f"Für {person['name']} gibt es schon eine PIN.")
        pin = pin_pruefen_form(pin)
        if pin != str(wiederholung or ""):
            raise PinFehler("Die beiden Eingaben sind verschieden – bitte noch einmal.")
        self.pins.setzen(person["id"], pin, von=person["id"], wie="Browser" if self._im_web() else "Rechner")
        self.fehl.erfolg(self._schluessel(person["id"]))
        self.p._setze_ich(person["id"])
        return {"angemeldet": True, "ich": person["id"], "person": person}

    def pin_aendern(self, alt="", neu="", wiederholung="") -> dict:
        ich = self.p._ich_pflicht()
        if self.pins.hat_pin(self.pins.eintrag(ich)):
            r = self._pruefen(ich, alt)
            if not r["ok"]:
                raise PinFehler(r["meldung"].replace("PIN stimmt nicht", "Die bisherige PIN stimmt nicht"))
            if str(neu) == str(alt):
                raise PinFehler("Die neue PIN ist dieselbe wie die bisherige.")
        neu = pin_pruefen_form(neu)
        if neu != str(wiederholung or ""):
            raise PinFehler("Die beiden Eingaben der neuen PIN sind verschieden.")
        self.pins.setzen(ich, neu, von=ich, wie="Browser" if self._im_web() else "Rechner")
        if not self._im_web() and self._rechner_ich == ich:
            self._merken(ich if self.bleiben() else "")           # gemerkte Anmeldung gehört zur neuen PIN
        return {**self.status(), "meldung": "PIN geändert."}

    def _verwalter_pflicht(self) -> str:
        ich = self.p._ich_pflicht()
        if self._im_web():
            raise PinFehler("Das geht nur am Rechner in ODIN.")
        if not self._verwalter():
            raise PinFehler("Das dürfen nur Verwalter (die Urlaubs-Genehmiger).")
        return ich

    def pin_uebersicht(self) -> list:
        self._verwalter_pflicht()
        liste = []
        for p in self.p.personen():
            if not p.get("aktiv", True):
                continue
            try:
                e = self.pins.eintrag(p["id"])
            except PinFehler:
                e = {}
            z = e.get("zurueckgesetzt") or e.get("zuletzt_zurueckgesetzt") or {}
            liste.append({"id": p["id"], "name": p.get("name", ""), "kuerzel": p.get("kuerzel", ""), "farbe": p.get("farbe"),
                          "pin": self.pins.hat_pin(e), "gesetzt_am": e.get("gesetzt_am", ""),
                          "zurueckgesetzt": {"am": z.get("am", ""), "von_name": z.get("von_name", "")} if isinstance(z, dict) and z else None})
        return liste

    def pin_zuruecksetzen(self, person_id="") -> dict:
        ich = self._verwalter_pflicht()
        person = self._person(person_id)
        if person["id"] == ich:
            raise PinFehler("Deine eigene PIN änderst du mit der bisherigen PIN.")
        namen = {p["id"]: p.get("name", "") for p in self.p.personen()}
        self.pins.zuruecksetzen(person["id"], von=ich, von_name=namen.get(ich, ""))
        self.fehl.vergessen(person["id"] + "|")
        self._protokoll(f"Anmeldung: PIN von {person['name']} zurückgesetzt durch {namen.get(ich, ich)}")
        return {"uebersicht": self.pin_uebersicht(),
                "meldung": f"PIN von {person['name']} zurückgesetzt – beim nächsten Anmelden legt "
                           f"{person['name'].split()[0]} eine neue fest."}

    def abmelden(self) -> dict:
        self.p.abmelden()
        return self.status()
