"""
PDF-Anhänge aus gespeicherten Mails lesen – und für die Rechtsfälle die ganze Mail (Absender, Empfänger, Text,
alle Anhänge).

Zieht man in Outlook Mails in einen Ordner, entstehen je nach Outlook:
- .msg  (Outlook unter Windows) – ein Microsoft-Containerformat, gelesen mit olefile
- .eml  (Outlook für Mac, neues Outlook) – normales Mailformat, gelesen mit Pythons email-Modul

Weitergeleitete Mails (Mail als Anhang) werden mit durchsucht.
"""

import datetime as dt
import html
import os
import re
import struct
from dataclasses import dataclass, field
from email import policy
from email.parser import BytesParser
from email.utils import parsedate_to_datetime

import olefile

MAIL_ENDUNGEN = (".msg", ".eml")


@dataclass
class Mail:
    datei: str
    betreff: str = ""
    datum: str = ""                                   # Eingang als ISO-Zeit, "" wenn unbekannt
    pdfs: list = field(default_factory=list)          # [(Dateiname, Bytes)]
    fehler: str = ""


def ist_mail(pfad: str) -> bool:
    return pfad.lower().endswith(MAIL_ENDUNGEN)


def ist_pdf(daten: bytes) -> bool:
    return bool(daten) and b"%PDF" in daten[:1024]


def lies_mail(pfad: str) -> Mail:
    mail = Mail(os.path.basename(pfad))
    try:
        with open(pfad, "rb") as f:
            daten = f.read()
        if daten.startswith(olefile.MAGIC):
            _lies_msg(daten, mail)
        else:
            _lies_eml(daten, mail)
    except Exception as e:   # beschädigte oder unbekannte Datei: melden statt abbrechen
        mail.fehler = f"Mail nicht lesbar ({type(e).__name__})"
    return mail


# ---------------- .eml ----------------

def _lies_eml(daten: bytes, mail: Mail, oberste=True):
    nachricht = BytesParser(policy=policy.default).parsebytes(daten)
    if oberste:
        mail.betreff = str(nachricht.get("subject", "") or "").strip()
        try:
            datum = parsedate_to_datetime(str(nachricht.get("date", "")))
            if datum.tzinfo:
                datum = datum.astimezone().replace(tzinfo=None)
            mail.datum = datum.isoformat(timespec="seconds")
        except (TypeError, ValueError):
            pass
    for teil in nachricht.walk():                      # geht auch in weitergeleitete Mails hinein
        if teil.is_multipart():
            continue
        name = teil.get_filename() or ""
        typ = teil.get_content_type()
        if not (name or typ in ("application/pdf", "application/octet-stream")):
            continue                                   # Mailtext
        inhalt = teil.get_payload(decode=True) or b""
        if ist_pdf(inhalt):
            mail.pdfs.append((name or "Anhang.pdf", inhalt))
        elif inhalt.startswith(olefile.MAGIC):         # .msg als Anhang
            _lies_msg(inhalt, mail, oberste=False)


# ---------------- .msg ----------------

def _filetime(wert: int) -> str:
    if not wert:
        return ""
    utc = dt.datetime(1601, 1, 1, tzinfo=dt.timezone.utc) + dt.timedelta(microseconds=wert // 10)
    return utc.astimezone().replace(tzinfo=None).isoformat(timespec="seconds")


def _lies_msg(daten: bytes, mail: Mail, oberste=True):
    ole = olefile.OleFileIO(daten)
    try:
        if oberste:
            mail.betreff = _text(ole, [], "0037")
            mail.datum = _msg_datum(ole)
        _msg_anhaenge(ole, [], mail)
    finally:
        ole.close()


def _text(ole, pfad: list, kennung: str) -> str:
    for typ, kodierung in (("001F", "utf-16-le"), ("001E", "cp1252")):
        strom = "/".join(pfad + [f"__substg1.0_{kennung}{typ}"])
        if ole.exists(strom):
            return ole.openstream(strom).read().decode(kodierung, "replace").rstrip("\x00").strip()
    return ""


def _msg_datum(ole) -> str:
    """Zustellzeit (PR_MESSAGE_DELIVERY_TIME), sonst Sendezeit (PR_CLIENT_SUBMIT_TIME)."""
    if not ole.exists("__properties_version1.0"):
        return ""
    roh = ole.openstream("__properties_version1.0").read()
    werte = {}
    for i in range(32, len(roh) - 15, 16):            # 32 Byte Kopf, dann je 16 Byte pro Eigenschaft
        typ, kennung, _ = struct.unpack_from("<HHI", roh, i)
        if typ == 0x0040:                              # Datum/Zeit
            werte[kennung] = struct.unpack_from("<Q", roh, i + 8)[0]
    return _filetime(werte.get(0x0E06) or werte.get(0x0039) or 0)


def _msg_anhaenge(ole, pfad: list, mail: Mail):
    tiefe = len(pfad)
    anhaenge = sorted({e[tiefe] for e in ole.listdir(streams=True, storages=True)
                       if len(e) > tiefe and e[:tiefe] == pfad and e[tiefe].lower().startswith("__attach_version1.0_")})
    for anhang in anhaenge:
        a = pfad + [anhang]
        daten_strom = "/".join(a + ["__substg1.0_37010102"])
        if ole.exists(daten_strom) and ole.get_type(daten_strom) == olefile.STGTY_STREAM:
            inhalt = ole.openstream(daten_strom).read()
            if ist_pdf(inhalt):
                mail.pdfs.append((_text(ole, a, "3707") or _text(ole, a, "3704") or "Anhang.pdf", inhalt))
            elif inhalt.startswith(olefile.MAGIC):     # .msg-Datei als Anhang
                _lies_msg(inhalt, mail, oberste=False)
        eingebettet = a + ["__substg1.0_3701000D"]     # weitergeleitete Mail als Element
        if ole.exists("/".join(eingebettet)):
            _msg_anhaenge(ole, eingebettet, mail)


# ---------------- Ganze Mail (für die Rechtsfälle) ----------------

BILD_ENDUNGEN = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp")
KLEINBILD_BYTES = 15 * 1024                # kleinere Bilder sind fast immer Logos aus der Signatur
TEXT_MAX = 200_000


@dataclass
class MailInhalt:
    datei: str
    betreff: str = ""
    absender: str = ""
    an: str = ""
    datum: str = ""                                   # ISO-Zeit, "" wenn unbekannt
    text: str = ""
    anhaenge: list = field(default_factory=list)      # [(Dateiname, Bytes)] – alle, auch weitergeleitete Mails
    kleinbilder: int = 0                              # übersprungene Signatur-Logos
    fehler: str = ""


def html_zu_text(roh: str) -> str:
    """Mailtext aus HTML: Absätze bleiben, Formatierung fällt weg."""
    roh = (roh or "")[:2_000_000]                              # ein Mailtext ist nie größer – alles darüber ist Last
    if roh.count("<") > 200_000:                             # nur Klammern: nichts zu lesen, aber teuer
        return ""
    t = roh
    for marke in ("script", "style", "head"):               # Blöcke von Hand schneiden: kein Muster, das bei nie
        klein, teile, stelle = t.lower(), [], 0             # geschlossenen Blöcken immer wieder von vorn sucht
        while True:
            anfang = klein.find("<" + marke, stelle)
            if anfang < 0:
                teile.append(t[stelle:])
                break
            ende = klein.find("</" + marke, anfang)
            teile.append(t[stelle:anfang])
            if ende < 0:                                    # nie geschlossen: der Rest gehört zum Block
                break
            schluss = klein.find(">", ende)
            stelle = len(t) if schluss < 0 else schluss + 1
            teile.append(" ")
        t = "".join(teile)
    t = re.sub(r"(?i)<br\s*/?>", "\n", t)
    t = re.sub(r"(?i)</(p|div|tr|li|h[1-6]|table|blockquote)>", "\n", t)
    t = re.sub(r"(?s)<[^<>]{0,5000}>", "", t)
    t = html.unescape(t).replace("\xa0", " ")
    zeilen = [" ".join(z.split()) for z in t.splitlines()]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(zeilen)).strip()


def _kleinbild(name: str, daten: bytes) -> bool:
    return name.lower().endswith(BILD_ENDUNGEN) and len(daten) < KLEINBILD_BYTES


def lies_mail_inhalt(pfad: str) -> MailInhalt:
    """Betreff, Absender, Empfänger, Datum, Text und alle Anhänge einer gespeicherten Mail (.msg oder .eml)."""
    inhalt = MailInhalt(os.path.basename(pfad))
    try:
        with open(pfad, "rb") as f:
            daten = f.read()
        if daten.startswith(olefile.MAGIC):
            _inhalt_msg(daten, inhalt)
        else:
            _inhalt_eml(daten, inhalt)
    except Exception as e:   # beschädigte oder unbekannte Datei: melden statt abbrechen
        inhalt.fehler = f"Mail nicht lesbar ({type(e).__name__})"
    inhalt.text = str(inhalt.text or "").replace("\r\n", "\n").strip()[:TEXT_MAX]
    return inhalt


def _inhalt_eml(daten: bytes, inhalt: MailInhalt):
    nachricht = BytesParser(policy=policy.default).parsebytes(daten)
    inhalt.betreff = " ".join(str(nachricht.get("subject", "") or "").split())
    inhalt.absender = " ".join(str(nachricht.get("from", "") or "").split())
    inhalt.an = " ".join(str(nachricht.get("to", "") or "").split())
    try:
        datum = parsedate_to_datetime(str(nachricht.get("date", "")))
        if datum.tzinfo:
            datum = datum.astimezone().replace(tzinfo=None)
        inhalt.datum = datum.isoformat(timespec="seconds")
    except (TypeError, ValueError):
        pass
    if not (inhalt.betreff or inhalt.absender or inhalt.datum or nachricht.get_payload()):
        raise ValueError("keine Mail")
    koerper = nachricht.get_body(preferencelist=("plain", "html"))
    if koerper is not None:
        text = koerper.get_content()
        inhalt.text = html_zu_text(text) if koerper.get_content_type() == "text/html" else text
    _eml_anhaenge(nachricht, inhalt)


def _eml_anhaenge(nachricht, inhalt: MailInhalt):
    for teil in nachricht.iter_attachments():
        name = os.path.basename(str(teil.get_filename() or "").replace("\\", "/"))
        if teil.get_content_type() == "message/rfc822":          # weitergeleitete Mail als Anhang
            innen = teil.get_payload()[0] if isinstance(teil.get_payload(), list) else teil.get_content()
            betreff = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", " ".join(str(innen.get("subject", "") or "").split()))[:120]
            inhalt.anhaenge.append((name or f"{betreff or 'Weitergeleitete Mail'}.eml", bytes(innen)))
            _eml_anhaenge(innen, inhalt)
            continue
        daten = teil.get_payload(decode=True) or b""
        if not daten:
            continue
        if not name:
            endung = {"application/pdf": ".pdf", "image/jpeg": ".jpg", "image/png": ".png"}.get(teil.get_content_type(), "")
            name = f"Anhang{endung}"
        if _kleinbild(name, daten):
            inhalt.kleinbilder += 1
            continue
        inhalt.anhaenge.append((name, daten))


def _inhalt_msg(daten: bytes, inhalt: MailInhalt):
    ole = olefile.OleFileIO(daten)
    try:
        _msg_kopf(ole, [], inhalt)
        inhalt.datum = _msg_datum(ole)
        _msg_alle_anhaenge(ole, [], inhalt)
    finally:
        ole.close()


def _msg_kopf(ole, pfad: list, inhalt: MailInhalt):
    """Betreff, Absender, Empfänger und Text aus einer Mail (oder einer eingebetteten Mail unter 'pfad')."""
    inhalt.betreff = " ".join(_text(ole, pfad, "0037").split())
    name = _text(ole, pfad, "0C1A") or _text(ole, pfad, "0042")
    adresse = _text(ole, pfad, "5D01") or _text(ole, pfad, "0C1F") or _text(ole, pfad, "0065")
    if adresse and "@" not in adresse:                # Exchange-interne Adresse – ohne Aussagekraft
        adresse = ""
    inhalt.absender = f"{name} <{adresse}>" if name and adresse and adresse not in name else (name or adresse)
    inhalt.an = " ".join(_text(ole, pfad, "0E04").split())
    inhalt.text = _text(ole, pfad, "1000")
    if not inhalt.text:
        strom = "/".join(pfad + ["__substg1.0_10130102"])
        if ole.exists(strom):
            roh = ole.openstream(strom).read()
            try:
                inhalt.text = html_zu_text(roh.decode("utf-8"))
            except UnicodeDecodeError:
                inhalt.text = html_zu_text(roh.decode("cp1252", "replace"))


def _msg_alle_anhaenge(ole, pfad: list, inhalt: MailInhalt):
    tiefe = len(pfad)
    anhaenge = sorted({e[tiefe] for e in ole.listdir(streams=True, storages=True)
                       if len(e) > tiefe and e[:tiefe] == pfad and e[tiefe].lower().startswith("__attach_version1.0_")})
    for anhang in anhaenge:
        a = pfad + [anhang]
        name = os.path.basename((_text(ole, a, "3707") or _text(ole, a, "3704") or _text(ole, a, "3001")).replace("\\", "/"))
        daten_strom = "/".join(a + ["__substg1.0_37010102"])
        if ole.exists(daten_strom) and ole.get_type(daten_strom) == olefile.STGTY_STREAM:
            daten = ole.openstream(daten_strom).read()
            if not daten:
                continue
            name = name or "Anhang"
            if _kleinbild(name, daten):
                inhalt.kleinbilder += 1
                continue
            inhalt.anhaenge.append((name, daten))
            continue
        eingebettet = a + ["__substg1.0_3701000D"]     # weitergeleitete Mail als Element: als Textdatei ablegen
        if ole.exists("/".join(eingebettet)):
            innen = MailInhalt(name)
            _msg_kopf(ole, eingebettet, innen)
            kopf = [("Betreff", innen.betreff), ("Von", innen.absender), ("An", innen.an)]
            text = "\n".join(f"{k}: {v}" for k, v in kopf if v) + "\n\n" + innen.text
            titel = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", innen.betreff or name or "Weitergeleitete Mail")[:120].strip(" .")
            inhalt.anhaenge.append((f"{titel or 'Weitergeleitete Mail'}.txt", text.encode("utf-8")))
            _msg_alle_anhaenge(ole, eingebettet, inhalt)
