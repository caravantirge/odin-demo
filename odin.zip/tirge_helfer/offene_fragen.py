"""
Offene Fragen: was der Fragen-Assistent nicht verstanden hat – als Liste für die Verantwortlichen.

Der Assistent notiert jede nicht verstandene Frage in „fragen-unverstanden.json“ (cockpit/daten.py, im Ordner
„Fahrzeuge“ unter _ODIN/, ohne verbundenen Ordner im Einstellungsordner). Mit „Lücke melden“ markiert jemand eine
Frage ausdrücklich. Hier wird daraus eine Liste: gleiche Fragen zusammengefasst, mit Häufigkeit und „zuletzt“.

Vor der Anzeige werden mögliche Kundendaten entfernt (Namen nach Anrede, Telefonnummern, E-Mail-Adressen, IBAN,
Fahrgestellnummern). Interne Fahrzeugnummern (z. B. DETKW00182) bleiben – sie helfen beim Nachvollziehen.

„Erledigt“ steht in „fragen-erledigt.json“ daneben ({schlüssel: {"am", "von"}}). Wird eine erledigte Frage danach
wieder gestellt, taucht sie wieder auf. Nichts verlässt den Rechner bzw. den gemeinsamen Ordner.
"""

import datetime as dt
import hashlib
import json
import os
import re

DATEI = "fragen-unverstanden.json"
ERLEDIGT = "fragen-erledigt.json"
MAX_ANZEIGE = 200
SCHLUESSEL = re.compile(r"[0-9a-f]{16}")

_EMAIL = re.compile(r"[\w.+-]+@[\w-]+(\.[\w-]+)+")
_IBAN = re.compile(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){3,7}(?: ?[A-Z0-9]{1,3})?\b")
# Fahrgestellnummer: 17 Zeichen ohne I, O, Q – mit Ziffern und Buchstaben
_FIN = re.compile(r"\b(?=[A-HJ-NPR-Z0-9]*\d)(?=[A-HJ-NPR-Z0-9]*[A-HJ-NPR-Z])[A-HJ-NPR-Z0-9]{17}\b", re.IGNORECASE)
# Telefon: beginnt mit + oder 0, mindestens 6 Ziffern, Trenner Leerzeichen / - ( ) .
_TELEFON = re.compile(r"(?<![\w])(?:\+|0)[\d][\d\s/().-]{4,}\d(?![\w])")
_DATUM = re.compile(r"\d{1,2}\.\d{1,2}\.(\d{2}|\d{4})?")
_ANREDE = re.compile(r"\b(Herrn?|Frau|Fr\.|Hr\.|Familie|Fam\.|Kundin|Kunden?|Ehepaar)\s+"
                     r"((?:[A-ZÄÖÜ][\wäöüß'-]+)(?:[\s-]+[A-ZÄÖÜ][\wäöüß'-]+){0,2})")
_NICHT_NAME = {"Ich", "Wir", "Sie", "Er", "Es", "Der", "Die", "Das", "Den", "Dem", "Mit", "Und", "Oder", "Wie", "Was",
               "Wo", "Wann", "Warum", "Ist", "Hat", "Will", "Möchte", "Sagt", "Fragt", "Kann", "Darf"}


def bereinigen(text) -> str:
    """Mögliche Kundendaten aus einer Frage entfernen. Interne Fahrzeugnummern bleiben."""
    t = " ".join(str(text or "").split())[:500]
    t = _EMAIL.sub("[E-Mail]", t)
    t = _IBAN.sub("[IBAN]", t)
    t = _FIN.sub(lambda m: m.group(0) if _interne_id(m.group(0)) else "[FIN]", t)
    t = _TELEFON.sub(lambda m: m.group(0) if _DATUM.fullmatch(m.group(0).strip())
                     or sum(c.isdigit() for c in m.group(0)) < 6 else "[Telefon]", t)

    def name(m):
        erstes = m.group(2).split()[0]
        if erstes in _NICHT_NAME:
            return m.group(0)
        return f"{m.group(1)} [Name]"
    return _ANREDE.sub(name, t)


def _interne_id(wert: str) -> bool:
    """Interne Fahrzeugnummern (Präfix aus Buchstaben, dann Ziffern) sind keine Kundendaten."""
    return bool(re.fullmatch(r"[A-Za-z]{2,8}\d{3,9}", wert))


def _norm(text: str) -> str:
    return re.sub(r"[\s?!.,;:]+$", "", " ".join(text.casefold().split()))


def schluessel(text: str) -> str:
    return hashlib.sha1(_norm(bereinigen(text)).encode("utf-8")).hexdigest()[:16]


def _lies(pfad: str):
    try:
        with open(pfad, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _schreibe(pfad: str, daten):
    os.makedirs(os.path.dirname(pfad), exist_ok=True)
    tmp = pfad + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(daten, f, ensure_ascii=False, indent=1)
    os.replace(tmp, pfad)


def _zeit(wert) -> str:
    return wert if isinstance(wert, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?", wert) else ""


def _erledigt(ordner: str) -> dict:
    roh = _lies(os.path.join(ordner, ERLEDIGT))
    if not isinstance(roh, dict):
        return {}
    return {k: {"am": _zeit(v.get("am")), "von": str(v.get("von") or "")[:40]} for k, v in roh.items()
            if SCHLUESSEL.fullmatch(str(k)) and isinstance(v, dict) and _zeit(v.get("am"))}


def liste(ordner: list) -> dict:
    """Offene Fragen aus allen genannten Ordnern (der gemeinsame zuerst). Gleiche Fragen (nach dem Bereinigen)
    zusammengefasst: {"fragen": [{"schluessel", "frage", "anzahl", "gemeldet", "erstmals", "zuletzt"}], "erledigt": n}."""
    gruppen = {}
    for o in ordner:
        roh = _lies(os.path.join(o, DATEI))
        for e in roh if isinstance(roh, list) else []:
            if not isinstance(e, dict) or not isinstance(e.get("frage"), str) or not e["frage"].strip():
                continue
            am = _zeit(e.get("am"))
            frage = bereinigen(e["frage"])
            k = hashlib.sha1(_norm(frage).encode("utf-8")).hexdigest()[:16]
            g = gruppen.setdefault(k, {"schluessel": k, "frage": frage, "anzahl": 0, "gemeldet": 0,
                                       "erstmals": am, "zuletzt": am})
            g["anzahl"] += 1
            g["gemeldet"] += 1 if e.get("gemeldet") is True else 0
            if am and (not g["zuletzt"] or am >= g["zuletzt"]):
                g["zuletzt"], g["frage"] = am, frage
            if am and (not g["erstmals"] or am < g["erstmals"]):
                g["erstmals"] = am
    erledigt = _erledigt(ordner[0]) if ordner else {}
    offen = [g for g in gruppen.values() if g["schluessel"] not in erledigt
             or (g["zuletzt"] and g["zuletzt"] > erledigt[g["schluessel"]]["am"])]
    offen.sort(key=lambda g: (g["gemeldet"] > 0, g["zuletzt"], g["anzahl"]), reverse=True)
    return {"fragen": offen[:MAX_ANZEIGE], "erledigt": len(gruppen) - len(offen), "gesamt": len(offen)}


def erledigen(ordner: str, k, von: str, jetzt=None, rueckgaengig: bool = False) -> bool:
    """Frage als erledigt markieren (oder das zurücknehmen). Nur Schlüssel aus 16 Hex-Zeichen."""
    if not isinstance(k, str) or not SCHLUESSEL.fullmatch(k):
        raise ValueError("Diese Frage gibt es nicht.")
    daten = _erledigt(ordner)
    if rueckgaengig:
        daten.pop(k, None)
    else:
        daten[k] = {"am": (jetzt or dt.datetime.now()).isoformat(timespec="seconds"), "von": str(von or "")[:40]}
    if len(daten) > 2000:                                     # die ältesten fallen weg
        daten = dict(sorted(daten.items(), key=lambda x: x[1]["am"])[-2000:])
    _schreibe(os.path.join(ordner, ERLEDIGT), daten)
    return True
