"""
Gemeinsame JSON-Dateien robust lesen. Die Dateien liegen im geteilten Ordner – jeder mit Schreibzugriff (oder ein
Synchronisationsfehler) kann sie verändern. Ein kaputter Wert darf deshalb nie das Programm bei allen lahmlegen:
zu große oder zu tief verschachtelte Dateien gelten als „nicht lesbar“, falsche Typen werden beim Lesen aussortiert.
"""

import json
import os
import re

MAX_JSON = 30 * 1024 * 1024
ID = re.compile(r"[A-Za-z0-9_-]{1,40}")
FARBE = re.compile(r"#[0-9A-Fa-f]{3,8}")


def _keine_sonderzahl(name):
    raise ValueError(f"ungültige Zahl ({name})")          # NaN, Infinity: kann die Oberfläche nicht lesen


def _endliche_zahl(text):
    zahl = float(text)
    if zahl != zahl or zahl in (float("inf"), float("-inf")):     # 1e999 wird sonst still zu „unendlich“
        raise ValueError("ungültige Zahl")
    return zahl


def lies_json(pfad: str):
    """Inhalt der Datei. FileNotFoundError bleibt; alles andere Unlesbare wird ValueError/OSError."""
    if os.path.getsize(pfad) > MAX_JSON:
        raise ValueError("Datei ist ungewöhnlich groß")
    try:
        with open(pfad, encoding="utf-8") as f:
            return json.load(f, parse_constant=_keine_sonderzahl, parse_float=_endliche_zahl)
    except RecursionError:
        raise ValueError("Datei ist zu tief verschachtelt") from None
    except UnicodeDecodeError:
        raise ValueError("Datei ist kein lesbarer Text") from None


def text(wert, standard: str = "") -> str:
    return wert if isinstance(wert, str) else standard


def liste_von(wert, pruefe) -> list:
    return [x for x in wert if pruefe(x)] if isinstance(wert, list) else []


def ist_id(wert) -> bool:
    return isinstance(wert, str) and bool(ID.fullmatch(wert))


def personen_form(daten) -> dict:
    """personen.json in fester Form: nur Einträge mit Text-ID und Text-Namen; alles andere fällt weg."""
    if not isinstance(daten, dict):
        return {"version": 1, "personen": []}
    personen = []
    for p in daten.get("personen") if isinstance(daten.get("personen"), list) else []:
        if not isinstance(p, dict) or not ist_id(p.get("id")) or not isinstance(p.get("name"), str) or not p["name"].strip():
            continue
        for feld in ("kuerzel", "farbe", "email", "angelegt_am"):
            if feld in p and not isinstance(p[feld], str):
                del p[feld]
        if "farbe" in p and not FARBE.fullmatch(p["farbe"]):      # landet in style="…" – nur eine echte Farbe
            del p["farbe"]
        personen.append(p)
    daten["personen"] = personen
    return daten


def projekt_form(p):
    """Eine Projektdatei in fester Form – oder None, wenn sie kein Projekt (mehr) ist."""
    if not isinstance(p, dict) or not ist_id(p.get("id")):
        return None
    p["name"] = text(p.get("name")).strip() or "Ohne Namen"
    if not (isinstance(p.get("farbe"), str) and FARBE.fullmatch(p["farbe"])):
        p["farbe"] = "#2F6DB3"
    for feld in ("mitglieder",):
        p[feld] = liste_von(p.get(feld), ist_id)
    p["spalten"] = liste_von(p.get("spalten"), lambda s: isinstance(s, dict) and ist_id(s.get("id")))
    for s in p["spalten"]:
        s["name"] = text(s.get("name")) or "Spalte"
    p["aufgaben"] = liste_von(p.get("aufgaben"), lambda a: isinstance(a, dict) and ist_id(a.get("id")))
    for a in p["aufgaben"]:
        a["titel"] = text(a.get("titel")) or "Aufgabe"
        a["zustaendig"] = liste_von(a.get("zustaendig"), ist_id)
        for feld in ("punkte", "kommentare"):
            if feld in a:
                a[feld] = liste_von(a.get(feld), lambda x: isinstance(x, dict))
        for feld in ("faellig", "spalte", "prioritaet", "beschreibung"):
            if feld in a and a[feld] is not None and not isinstance(a[feld], str):
                a[feld] = None
    for feld in ("farbe", "beschreibung", "besitzer", "angelegt_von", "angelegt_am", "quartalsziel", "ziel_status",
                 "ziel_erledigt_heisst"):
        if feld in p and p[feld] is not None and not isinstance(p[feld], str):
            p[feld] = None
    return p
