"""
Tägliche Erinnerungsmail an sich selbst – über das eigene Postfach (Microsoft Graph, /me/sendMail).

- Je Benutzer und Rechner einschaltbar, Uhrzeit wählbar (Standard 7:30). Höchstens eine Mail am Tag.
- Läuft ODIN, schaut ein Hintergrund-Faden alle 10 Minuten nach; startet ODIN erst nach der Uhrzeit, kommt die Mail
  kurz nach dem Start.
- Gesendet wird nur, wenn etwas ansteht:
  • Cashback, wenn man in den Cashback-Einstellungen als zuständig eingetragen ist (Fristen, Nachhaken, Aktionen),
  • Fristen im Betrieb, bei denen man verantwortlich ist (überfällig oder bald),
  • eigene Projektaufgaben, die heute fällig oder überfällig sind.
- Schlichtes HTML mit Textteil, ohne Logo und ohne Bilder.
"""

import datetime as dt
import html
import json
import os
import re
import threading
import time
import traceback

from .microsoft import MicrosoftFehler, NeuAnmelden

DATEI = "erinnerungsmail.json"
STANDARD_UHRZEIT = "07:30"
PRUEF_ABSTAND = 600                 # Sekunden zwischen zwei Blicken auf die Uhr
UHRZEIT = re.compile(r"([01]\d|2[0-3]):[0-5]\d")
WOCHENTAGE = ("Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag")

ROT = "#D0141C"
GRAU = "#6F6A6B"


class ErinnerungFehler(MicrosoftFehler):
    """Vorübergehend (z. B. OneDrive nicht erreichbar): später noch einmal versuchen."""


# ---------------- wer ist gemeint? ----------------

def _norm(text) -> str:
    return " ".join(str(text or "").split()).casefold()


def _namen(feld) -> list:
    """„Anna Muster, Ben“ / „Anna & Ben“ / „Anna und Ben“ → einzelne Namen."""
    return [n for n in (_norm(t) for t in re.split(r"[,;/&+]|\bund\b", str(feld or ""), flags=re.I)) if n]


def passt_zu_person(feld, person: dict, personen=()) -> bool:
    """Steht die Person im Feld „verantwortlich“? Voller Name oder E-Mail; ein einzelner Vorname zählt, wenn ihn
    unter allen Personen nur diese eine trägt."""
    if not person:
        return False
    name, email = _norm(person.get("name")), _norm(person.get("email"))
    vorname = name.split(" ")[0] if name else ""
    for n in _namen(feld):
        if (name and n == name) or (email and n == email):
            return True
        if vorname and n == vorname and " " not in n:
            gleiche = [p for p in personen if _norm(p.get("name")).split(" ")[0] == vorname] if personen else [person]
            if len(gleiche) == 1:
                return True
    return False


# ---------------- Inhalt ----------------

def inhalt_sammeln(person: dict, daten, aufgaben, heute: str, personen=()) -> dict:
    """Was heute für diese Person ansteht. 'daten' ist das Cockpit-Datenpaket (oder None), 'aufgaben' die offenen
    Projektaufgaben der Person. Beispieldaten zählen nie."""
    daten = daten if isinstance(daten, dict) else {}
    beispiel = daten.get("quelle") == "beispiel"
    cashback = None
    c = daten.get("cashback")
    if isinstance(c, dict) and not c.get("beispiel") and not c.get("fehler") and \
            passt_zu_person(c.get("verantwortlich"), person, personen):
        aktionen = [a for a in c.get("aktionen") or [] if a.get("noch_einreichen")]
        if c.get("fristen") or c.get("nachhaken") or aktionen:
            cashback = {"kennzahlen": c.get("kennzahlen") or {}, "fristen": list(c.get("fristen") or []),
                        "nachhaken": list(c.get("nachhaken") or []), "aktionen": aktionen}
    fristen = [] if beispiel else [
        f for f in daten.get("fristen") or []
        if f.get("zustand") in ("ueberfaellig", "bald") and passt_zu_person(f.get("verantwortlich"), person, personen)]
    faellig = [a for a in aufgaben or [] if a.get("faellig") and str(a["faellig"])[:10] <= heute]
    return {"cashback": cashback, "fristen": fristen, "aufgaben": faellig}


def ist_leer(inhalt: dict) -> bool:
    return not (inhalt.get("cashback") or inhalt.get("fristen") or inhalt.get("aufgaben"))


def anzahl(inhalt: dict) -> int:
    c = inhalt.get("cashback") or {}
    return (len(c.get("fristen") or []) + len(c.get("nachhaken") or []) + len(c.get("aktionen") or [])
            + len(inhalt.get("fristen") or []) + len(inhalt.get("aufgaben") or []))


def _eur(betrag) -> str:
    if betrag is None:
        return "–"
    return f"{round(float(betrag)):,}".replace(",", ".") + " €"


def _datum(iso) -> str:
    """„2026-11-23“ → „23.11.2026“."""
    iso = str(iso or "")[:10]
    return f"{iso[8:10]}.{iso[5:7]}.{iso[:4]}" if len(iso) == 10 else ""


def _kurz(iso) -> str:
    """„2026-11-23“ → „23.11.26“ (wie auf der Cashback-Seite)."""
    iso = str(iso or "")[:10]
    return f"{iso[8:10]}.{iso[5:7]}.{iso[2:4]}" if len(iso) == 10 else ""


def _tage(n: int) -> str:
    n = abs(int(n))
    return f"{n} Tag" if n == 1 else f"{n} Tagen"


def _ab(teile) -> str:
    return ", ".join(t for t in teile if t)


def _abschnitte(inhalt: dict, heute: str) -> list:
    """[(Überschrift, Untertitel, [(Text, warnen?)…], [(Zwischenüberschrift, [(Text, warnen?)…])…])] – für Text und HTML."""
    teile = []
    c = inhalt.get("cashback")
    if c:
        k = c["kennzahlen"]
        n = int(k.get("offen") or 0)
        offen = f"Offen: {n} {'Vorgang' if n == 1 else 'Vorgänge'}, {_eur(k.get('offen_netto'))} netto erwartet" + \
            (f" ({k['offen_ohne_betrag']} ohne Betrag)" if k.get("offen_ohne_betrag") else "")
        gruppen = []
        if c["fristen"]:
            gruppen.append(("Einreichen (Frist)", [
                (_ab((v.get("kunde"), v.get("modell"), v.get("aktion"), v.get("hersteller"))) + ": " +
                 ("Frist abgelaufen am " if v.get("lage") == "ueberfaellig" else "bis ") + _kurz(v.get("frist")),
                 v.get("lage") == "ueberfaellig") for v in c["fristen"]]))
        if c["nachhaken"]:
            gruppen.append(("Nachhaken (Gutschrift angefordert)", [
                (_ab((v.get("kunde"), v.get("aktion"), v.get("hersteller"))) + ": " +
                 (f"seit {v['tage_seit']} Tagen angefordert" if v.get("tage_seit") is not None
                  else "Anforderungsdatum fehlt"), False) for v in c["nachhaken"]]))
        if c["aktionen"]:
            gruppen.append(("Aktionen mit Einreichungsfrist", [
                (f"{a.get('aktion')} ({a.get('hersteller')}): bis {_kurz(a.get('frist'))}, "
                 f"noch {a['noch_einreichen']} einzureichen", False) for a in c["aktionen"]]))
        teile.append(("Cashback", "Du bist in ODIN als zuständig eingetragen. " + offen + ".", [], gruppen))
    if inhalt.get("fristen"):
        zeilen = []
        for f in inhalt["fristen"]:
            rest = int(f.get("tage_bis") or 0)
            wann = (f"seit {_tage(rest)} überfällig (fällig am {_datum(f.get('faellig_am'))})" if rest < 0 else
                    "heute fällig" if rest == 0 else f"fällig in {_tage(rest)} (am {_datum(f.get('faellig_am'))})")
            titel = f.get("titel") or "Frist"
            zeilen.append((titel + (f" ({f['kategorie']})" if f.get("kategorie") else "") + ": " + wann, rest < 0))
        teile.append(("Fristen im Betrieb", "Du bist dort als verantwortlich eingetragen.", zeilen, []))
    if inhalt.get("aufgaben"):
        zeilen = []
        tag = dt.date.fromisoformat(heute)
        for a in inhalt["aufgaben"]:
            faellig = str(a.get("faellig"))[:10]
            rest = (dt.date.fromisoformat(faellig) - tag).days
            wann = "heute fällig" if rest == 0 else f"seit {_tage(rest)} überfällig ({_datum(faellig)})"
            zusatz = " · Priorität hoch" if a.get("prioritaet") == "hoch" else ""
            zeilen.append((f"{a.get('titel') or 'Aufgabe'} – Projekt „{a.get('projekt') or '?'}“: {wann}{zusatz}", rest < 0))
        teile.append(("Deine Aufgaben", "Heute fällig oder überfällig, aus allen Projekten.", zeilen, []))
    return [(titel, unter, [(_ohne_link(z), w) for z, w in zeilen], [(g, [(_ohne_link(z), w) for z, w in gz]) for g, gz in gruppen])
            for titel, unter, zeilen, gruppen in teile]


# Alles, was wie eine Adresse aussieht: Schema, \\\\Server, Mailadresse, IP oder „wort.wort“ mit Pfad bzw. bekannter Endung
_ADRESSE = re.compile(r"(?i)\b[a-z][a-z0-9+.-]{1,12}://\S+|\\\\\S+|\S+@\S+\.\S+|\bwww\.\S+|\b\d{1,3}(?:\.\d{1,3}){3}\S*"
                      r"|\b[\w-]+(?:\.[\w-]+)*\.[a-z]{2,24}(?:/\S*|\b(?=\s|$|[,;:!?)]))")


def _ohne_link(text: str) -> str:
    """Titel von Aufgaben und Fristen schreiben auch Kollegen. In einer Mail, die nach ODIN aussieht, wäre eine
    Adresse darin ein bequemer Weg für Phishing – deshalb erscheinen Adressen dort nie anklickbar."""
    text = " ".join(str(text or "").split())                 # auch Zeilenumbrüche: keine gefälschten Mailzeilen
    return _ADRESSE.sub("[Adresse entfernt – in ODIN nachsehen]", text)[:300]


def baue_mail(inhalt: dict, person: dict, heute: str, test: bool = False) -> dict:
    """{"betreff", "text", "html"} – auf Deutsch, in Du-Form, ohne Logo."""
    tag = dt.date.fromisoformat(heute)
    stand = f"{WOCHENTAGE[tag.weekday()]}, {_datum(heute)}"
    vorname = (str((person or {}).get("name") or "").split() or [""])[0]
    n = anzahl(inhalt)
    if test:
        betreff = "ODIN · Test-Mail" + ("" if n else " – heute steht nichts an")
    else:
        betreff = f"ODIN · {n} {'Punkt' if n == 1 else 'Punkte'} für heute ({WOCHENTAGE[tag.weekday()][:2]}., {_datum(heute)[:6]})"
    gruss = f"Hallo {vorname}," if vorname else "Hallo,"
    einleitung = (f"das steht heute für dich an (Stand {stand}):" if n else
                  f"heute steht nichts für dich an (Stand {stand}). Die tägliche Erinnerung kommt nur an Tagen, "
                  "an denen etwas ansteht.")
    test_hinweis = "Dies ist eine Test-Mail aus ODIN – so sieht deine tägliche Erinnerung aus." if test else ""
    fuss = ("Diese Mail schickt ODIN dir über dein eigenes Postfach, nur an dich. Abschalten oder die Uhrzeit ändern: "
            "in ODIN unter Datenquellen → Konto & Anmeldung.")
    abschnitte = _abschnitte(inhalt, heute)

    # Textteil
    t = [gruss, ""]
    if test_hinweis:
        t += [test_hinweis, ""]
    t += [einleitung]
    for titel, unter, zeilen, gruppen in abschnitte:
        t += ["", titel, "-" * len(titel), unter]
        t += [f"- {z}" for z, _ in zeilen]
        for g_titel, g_zeilen in gruppen:
            t += ["", g_titel + ":"] + [f"- {z}" for z, _ in g_zeilen]
    t += ["", "--", fuss]
    text = "\n".join(t) + "\n"

    # HTML-Teil: schlicht, alles maskiert
    e = html.escape

    def zeile(z, warn):
        inhalt = f'<b style="color:{ROT}">{e(z)}</b>' if warn else e(z)
        return f'<li style="margin:2px 0">{inhalt}</li>'

    def liste(zeilen):
        return '<ul style="margin:4px 0 0;padding-left:20px">' + "".join(zeile(z, w) for z, w in zeilen) + "</ul>"

    h = ['<!doctype html><html lang="de"><head><meta charset="utf-8"><title>ODIN</title></head>',
         '<body style="margin:0;padding:20px;font-family:\'Segoe UI\',Arial,Helvetica,sans-serif;font-size:14px;'
         'line-height:1.5;color:#231F20;background:#ffffff">',
         f'<p style="margin:0 0 12px">{e(gruss)}</p>']
    if test_hinweis:
        h.append(f'<p style="margin:0 0 12px;color:{GRAU}">{e(test_hinweis)}</p>')
    h.append(f'<p style="margin:0 0 12px">{e(einleitung)}</p>')
    for titel, unter, zeilen, gruppen in abschnitte:
        h.append(f'<h2 style="font-size:16px;margin:22px 0 2px">{e(titel)}</h2>')
        h.append(f'<p style="margin:0 0 4px;color:{GRAU}">{e(unter)}</p>')
        if zeilen:
            h.append(liste(zeilen))
        for g_titel, g_zeilen in gruppen:
            h.append(f'<p style="margin:12px 0 0;font-weight:600">{e(g_titel)}</p>' + liste(g_zeilen))
    h.append(f'<p style="margin:28px 0 0;padding-top:10px;border-top:1px solid #E2E1E1;font-size:12px;color:{GRAU}">'
             f'{e(fuss)}</p></body></html>')
    return {"betreff": betreff, "text": text, "html": "".join(h)}


# ---------------- Zeitplan ----------------

class Erinnerung:
    """Einstellungen (an/aus, Uhrzeit) und der tägliche Versand. 'anmeldung' braucht angemeldet() und
    mail_an_mich(betreff, text, html); 'inhalt_holen(heute)' liefert (person, inhalt)."""

    def __init__(self, ordner: str, anmeldung, inhalt_holen, protokoll=None):
        self.ordner = ordner
        self._anmeldung = anmeldung
        self._inhalt_holen = inhalt_holen
        self._protokoll = protokoll or (lambda text: None)
        self._sperre = threading.Lock()           # nie zwei Versände gleichzeitig
        self._datei_sperre = threading.Lock()
        self._stopp = threading.Event()
        self._faden = None

    @property
    def _pfad(self) -> str:
        return os.path.join(self.ordner, DATEI)

    def einstellungen(self) -> dict:
        werte = {"an": False, "uhrzeit": STANDARD_UHRZEIT, "gesendet_am": "", "erledigt_am": "", "meldung": "",
                 "fehler": ""}
        try:
            with open(self._pfad, encoding="utf-8") as f:
                gelesen = json.load(f)
        except (OSError, ValueError):
            return werte
        if isinstance(gelesen, dict):
            werte.update({k: v for k, v in gelesen.items() if k in werte and isinstance(v, type(werte[k]))})
        if not UHRZEIT.fullmatch(werte["uhrzeit"]):
            werte["uhrzeit"] = STANDARD_UHRZEIT
        return werte

    def _merke(self, **felder) -> dict:
        with self._datei_sperre:
            werte = {**self.einstellungen(), **felder}
            os.makedirs(self.ordner, exist_ok=True)
            tmp = self._pfad + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(werte, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self._pfad)
            return werte

    def setzen(self, an, uhrzeit) -> dict:
        uhrzeit = str(uhrzeit or STANDARD_UHRZEIT).strip()
        if re.fullmatch(r"\d:[0-5]\d", uhrzeit):
            uhrzeit = "0" + uhrzeit
        if not UHRZEIT.fullmatch(uhrzeit):
            raise MicrosoftFehler("Bitte eine Uhrzeit wie 07:30 wählen.")
        return self._merke(an=bool(an), uhrzeit=uhrzeit, fehler="")

    def pruefen(self, jetzt: dt.datetime = None) -> str:
        """Ist heute die Mail dran? „gesendet“, „nichts“ (nichts stand an), „fehler“ oder „nicht_faellig“."""
        jetzt = jetzt or dt.datetime.now()
        heute = jetzt.date().isoformat()
        with self._sperre:
            e = self.einstellungen()
            if not e["an"] or e["erledigt_am"] == heute or jetzt.strftime("%H:%M") < e["uhrzeit"]:
                return "nicht_faellig"
            if not self._anmeldung.angemeldet():
                return "nicht_faellig"
            try:
                person, inhalt = self._inhalt_holen(heute)
                if ist_leer(inhalt):
                    self._merke(erledigt_am=heute, fehler="",
                                meldung=f"{_datum(heute)}: Es stand nichts an – keine Mail.")
                    return "nichts"
                mail = baue_mail(inhalt, person, heute)
                self._anmeldung.mail_an_mich(mail["betreff"], mail["text"], mail["html"])
                self._merke(gesendet_am=heute, erledigt_am=heute, fehler="",
                            meldung=f"Gesendet am {_datum(heute)} um {jetzt:%H:%M} Uhr.")
                return "gesendet"
            except NeuAnmelden as f:                  # heute nicht weiter versuchen – erst nach neuer Anmeldung
                self._merke(erledigt_am=heute, fehler=str(f))
                return "fehler"
            except MicrosoftFehler as f:              # z. B. keine Verbindung: in 10 Minuten noch einmal
                self._merke(fehler=str(f))
                return "fehler"
            except Exception:                         # noqa: BLE001 – ein Fehler im Inhalt hält ODIN nicht auf
                self._protokoll(f"Erinnerungsmail: {traceback.format_exc()}")
                self._merke(erledigt_am=heute, fehler="Die Erinnerung ließ sich heute nicht zusammenstellen – "
                                                      "Details stehen im Protokoll.")
                return "fehler"

    def test_senden(self, jetzt: dt.datetime = None) -> dict:
        """Sofort eine Mail an mich – auch wenn nichts ansteht (dann mit Hinweis). Zählt nicht als tägliche Mail."""
        heute = (jetzt or dt.datetime.now()).date().isoformat()
        with self._sperre:
            if time.monotonic() - getattr(self, "_letzte_testmail", -1e9) < 60:
                return {"meldung": "Gerade erst gesendet – bitte eine Minute warten."}
            self._letzte_testmail = time.monotonic()
            person, inhalt = self._inhalt_holen(heute)
            mail = baue_mail(inhalt, person, heute, test=True)
            self._anmeldung.mail_an_mich(mail["betreff"], mail["text"], mail["html"])
        n = anzahl(inhalt)
        return {"meldung": "Test-Mail gesendet – schau in dein Postfach." +
                ("" if n else " Heute stand nichts an, deshalb steht das in der Mail.")}

    def starten(self, abstand: int = PRUEF_ABSTAND, verzoegerung: float = 20) -> threading.Thread:
        """Hintergrund-Faden: kurz nach dem Start einmal (Nachholen), dann alle 'abstand' Sekunden."""
        if self._faden is not None and self._faden.is_alive():
            return self._faden
        self._stopp.clear()

        def lauf():
            if self._stopp.wait(verzoegerung):
                return
            while True:
                try:
                    self.pruefen()
                except Exception:                     # noqa: BLE001 – der Faden läuft weiter
                    self._protokoll(f"Erinnerungsmail: {traceback.format_exc()}")
                if self._stopp.wait(abstand):
                    return

        self._faden = threading.Thread(target=lauf, name="ODIN-Erinnerung", daemon=True)
        self._faden.start()
        return self._faden

    def stoppen(self):
        self._stopp.set()
