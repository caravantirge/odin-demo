"""Mehr erfundene Daten für die Web-Demo: stockt die Beispiel-Listen auf (Bestand, Finanzaufstellung, Auslieferungen,
Liquidität, Provisionen), alle Termine relativ zu heute. Wird nur in der Demo vor dem Schreiben der Listen geladen."""
import random
from datetime import date, datetime, timedelta

from tirge_helfer.cockpit import beispieldateien as B

Z = random.Random(20261125)
HEUTE = date.today()


def _d(tage):
    return HEUTE + timedelta(days=tage)


def _s(tage):
    return _d(tage).strftime("%d.%m.%Y")


def _geld(x):
    return f"{x:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


MODELLE = [  # Präfix, Modell, EK von-bis, Ausstattung
    ("DETKW", ["Linea 600 DR", "Linea 640 HR", "Linea 600 ES Active", "Linea 540 DS Active"],
     (43000, 62000), "Markise 4,0 m, Solaranlage 150 Wp, Dieselheizung, Rückfahrkamera, Fahrradträger"),
    ("DRM", ["Trend 7057 EBL", "Just 90 T 7052 EB", "Puls Classic T 7051", "Lineo I 6", "Alto A 7820-2"],
     (62000, 142000), "Chassis-Paket Light, Hubbett, Truma Combi 6 E, Fußbodenheizung, Außendusche"),
    ("DWWA", ["Viator 560 FMK", "c'way 495 QSK", "Camper 470 ER", "Sahra Scandinavia 650"],
     (19000, 41000), "Mover, Markise 3,5 m, Vorzelt, Antischlingerkupplung"),
    ("SLKW", ["Vento 640", "Vento 600", "Vento 540"], (41000, 56000), "Markise, Solaranlage, Navigation, Tempomat"),
    ("SLRM", ["T 68", "A 72", "T 60"], (52000, 74000), "Winterpaket, Sat-Anlage, Hubbett, Alufelgen"),
]
KUNDEN = ["Albers", "Fernkorn", "Hansen", "Meier", "Brandt", "Lorenz", "Schulte", "Vogel", "Kaiser", "Peters",
          "Berger", "Winter", "Sommer", "Krüger", "Haas", "Roth", "Fuchs", "Lange"]
TANK = [("fertig getankt", "92D050"), ("in Arbeit tanken", "FFFF00"), (None, None)]
PAPIERE = [("Brief Kunde", "92D050"), ("Brief/Ausnahme wir", "FFFF00"), ("Brief Hersteller", "FFC000")]


def aufstocken(anzahl=34):
    # Linien passend zur größeren Menge – eine bleibt knapp, damit die Warnung „Linie wird eng“ etwas zu zeigen hat
    for blatt, limit in (("Nord. H1", -1900000), ("Nord. SL", -900000), ("CA H1", -420000), ("WF Hersteller3", -1250000)):
        B.FINANZ_FUSS[blatt]["limit"] = limit
        B.FINANZ_FUSS[blatt].pop("summe", None)
    fahrzeuge = []
    nr = {"2026": len(B.JAHRESBLAETTER["2026"]), "2027": len(B.JAHRESBLAETTER["2027"])}
    blaetter = {name: zeilen for name, _, zeilen in B.FINANZBLAETTER}
    for i in range(anzahl):
        praefix, modelle, (ek_min, ek_max), aus = MODELLE[i % len(MODELLE)]
        jahr = "2026" if i % 3 else "2027"
        modell = Z.choice(modelle)
        ek = round(Z.uniform(ek_min, ek_max), -2)
        vk = round(ek * Z.uniform(1.18, 1.32), -2)
        iid = f"{praefix}{300 + i:05d}"
        verkauft = Z.random() < 0.4
        kunde = Z.choice(KUNDEN) if verkauft else None
        da = Z.random() < 0.75 or verkauft                          # angeliefert (mit Fahrgestellnummer)
        fin = f"ZFA25{Z.randint(10**11, 10**12 - 1)}" if da else None
        serie = f"{jahr[2:]} {Z.randint(100, 999)} {Z.randint(100, 999):03d}" if da else None
        bank = Z.choice(["Nord.", "Nord.", "CA", "WF"]) if da else None
        vertrag = f"{Z.randint(1000, 99999):05d}" if bank else None
        farbe = Z.choice(["frei", "rot", None]) if not verkauft else None
        nr[jahr] += 1
        B.JAHRESBLAETTER[jahr].append((nr[jahr], modell, fin, serie, 1455000 + i, iid, Z.randint(4400, 4999),
                                       kunde, vk, vk - 500 if Z.random() < 0.5 else None, ek,
                                       f"{bank}, {vertrag}" if bank else None, aus, farbe))
        fahrzeuge.append(dict(iid=iid, modell=modell, ek=ek, vk=vk, kunde=kunde, fin=fin, serie=serie, bank=bank,
                              praefix=praefix, da=da))
        if bank:                                                   # Finanzaufstellung: je Bank × Hersteller ein Blatt
            marke = "SL" if praefix.startswith("SL") else "H1"
            blatt = f"{bank} {marke}" if f"{bank} {marke}" in blaetter else ("Nord. SL" if marke == "SL" else "Nord. H1")
            seit = -Z.randint(10, 260)
            blaetter[blatt].append([f"{kunde or 'Lager'}, {iid}", _s(seit), _s(seit + 180), _geld(ek), modell, serie, fin,
                                    _geld(ek * 1.01), None, "neu", "keine Ausnahme", None, None, None, None])
    # Auslieferungen der nächsten Wochen
    for n, f in enumerate([f for f in fahrzeuge if f["kunde"]][:12]):
        tank, tankfarbe = Z.choice(TANK)
        pap, papfarbe = Z.choice(PAPIERE)
        termin = datetime.combine(_d(Z.randint(-2, 24)), datetime.min.time()).replace(hour=Z.choice([9, 10, 11, 14, 15]),
                                                                                      minute=Z.choice([0, 30]))
        B.AUSLIEFERUNGEN.append(dict(
            id=f["iid"], name=f["kunde"], schrift=None, modell=f["modell"], modellfarbe="92D050" if f["da"] else "C00000",
            tank=tank, tankfarbe=tankfarbe, ak=str(692600 + n), akfarbe=None, minuten=Z.choice([120, 180, 240, 300]),
            termin=termin, terminfarbe=None, vertrag=datetime.combine(_d(-Z.randint(20, 120)), datetime.min.time()),
            art="neu", tuev=None, papiere=pap, papierfarbe=papfarbe, zahlart=Z.choice(["VDR", "AB", "Bar", "Finanzierung"]),
            zahlfarbe=Z.choice(["92D050", "FF0000", "FFC000"]), werk=Z.choice(["92D050", "FF0000"]), ahks=None, ahka=None,
            ubhk=None, son=None, sonfarbe=None, bemerkung=Z.choice([None, None, "Gutschein 250 € offen",
                                                                   "Restzahlung bei Übergabe", "Einweisung 1 Std."])))
    _finanzplanung(fahrzeuge)
    _provisionen(fahrzeuge)


def _finanzplanung(fahrzeuge):
    zeilen = []
    for m in range(-3, 10):                                          # Monate rund um heute
        erster = (HEUTE.replace(day=1) + timedelta(days=32 * m)).replace(day=1)
        art = "Ist" if m < 0 else "Plan"
        zeilen += [
            [erster.replace(day=5), art, "Aus", "Löhne", -Z.randint(46000, 52000), "Hausbank", "Löhne", None],
            [erster.replace(day=3), art, "Aus", "Miete", -6500, "Hausbank", "Miete", None],
            [erster.replace(day=15), art, "Ein", "Werkstatt", Z.randint(28000, 45000), "Hausbank", "Werkstatt-Umsatz", None],
            [erster.replace(day=20), art, "Ein", "Teile", Z.randint(9000, 18000), "Hausbank", "Teile & Zubehör", None],
            [erster.replace(day=25), art, "Aus", "Sonstiges", -Z.randint(8000, 15000), "Hausbank", "Strom, Versicherung, Werbung", None],
        ]
    for f in fahrzeuge:
        if f["kunde"]:
            zeilen.append([_d(Z.randint(-60, 90)), "Plan", "Ein", "Verkauf", f["vk"], "Hausbank", f"Verkauf {f['modell']}", f["iid"]])
        if f["bank"] and Z.random() < 0.5:
            zeilen.append([_d(Z.randint(10, 200)), "Plan", "Aus", "Fahrzeugeinkauf", -f["ek"], "Nord.", f"Ablösung {f['modell']}", f["iid"]])
    zeilen.sort(key=lambda z: z[0])

    def schreibe_finanzplanung(ordner):
        import os
        return B._flache_liste(os.path.join(ordner, "Beispiel-Finanzplanung.xlsx"), "Liquidität", "Liquiditätsplanung",
                               ["Datum", "Art", "Richtung", "Kategorie", "Betrag", "Konto", "Bezeichnung", "Interne ID"],
                               [[datetime.combine(z[0], datetime.min.time()), *z[1:]] for z in zeilen])
    B.schreibe_finanzplanung = schreibe_finanzplanung


def _provisionen(fahrzeuge):
    verkaeufer = ["Jan", "Uwe", "Kai", "Ben"]
    zeilen = []
    for f in fahrzeuge:
        if f["kunde"]:
            basis = round(f["vk"] / 1.19 - f["ek"], -1)
            satz = Z.choice([0.05, 0.08, 0.1])
            bezahlt = Z.random() < 0.4
            zeilen.append([Z.choice(verkaeufer), f["iid"], _d(-Z.randint(5, 150)).strftime("%d.%m.%Y"), basis, satz,
                           round(basis * satz, 2), "ausgezahlt" if bezahlt else "offen",
                           _d(-Z.randint(1, 30)).strftime("%d.%m.%Y") if bezahlt else None])

    def schreibe_provisionen(ordner):
        import os
        return B._flache_liste(os.path.join(ordner, "Beispiel-Provisionen.xlsx"), "Provisionen", "Provisionsliste",
                               ["Verkäufer", "Interne ID", "Verkaufsdatum", "Bemessungsgrundlage", "Satz", "Provision",
                                "Status", "Auszahlungsdatum"], zeilen)
    B.schreibe_provisionen = schreibe_provisionen
