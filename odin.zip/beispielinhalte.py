"""Erfundene Beispielinhalte für Demo und Testmodus der App: Personen (PIN 1234), Projekte, Besprechung, To-dos."""
import datetime as dt

DEMO_PIN = "1234"


def _versuch(was, f):
    try:
        return f()
    except Exception as e:  # noqa: BLE001 – fehlende Beispielinhalte sind kein Abbruch
        print("Beispiel", was, repr(e))


def fuellen(api):
    P = lambda a, *x: api.projekte_aufruf(a, list(x))["daten"]          # noqa: E731
    heute = dt.date.today()
    tag = lambda n: (heute + dt.timedelta(days=n)).isoformat()            # noqa: E731
    for name in ("Anna Berg", "Lars Albers", "Mia Krause", "Tom Wagner", "Jonas Peters", "Lea Hoffmann"):
        P("person_anlegen", {"name": name})
    pers = {p["name"]: p["id"] for p in P("personen")}
    for pid in pers.values():
        try:
            api._tresor.pins.setzen(pid, DEMO_PIN, von=pid, wie="Rechner")
        except Exception as e:  # noqa: BLE001
            print("pin", e)


    def projekt(name, beschreibung, farbe, mitglieder, aufgaben, ziel=None):
        p = P("projekt_anlegen", {"name": name, "beschreibung": beschreibung, "farbe": farbe})
        for m in mitglieder:
            _versuch("mitglied", lambda: P("mitglied_hinzufuegen", p["id"], pers[m]))
        for titel, wer, tage, prio in aufgaben:
            _versuch("aufgabe", lambda: P("aufgabe_anlegen", p["id"], {
                "titel": titel, "zustaendig": [pers[wer]], "faellig": tag(tage) if tage is not None else None,
                "prioritaet": prio}))
        if ziel:
            _versuch("ziel", lambda: P("projekt_aendern", p["id"], ziel))


    api._tresor.rechner_setzen(pers["Anna Berg"])
    q = f"{heute.year}-Q{(heute.month - 1) // 3 + 1}"
    _versuch("projekte", lambda: (
        projekt("Hausmesse", "Frühjahrs-Hausmesse: Fahrzeuge, Catering, Werbung.", "#2F6DB3",
                ["Lars Albers", "Mia Krause", "Jonas Peters"], [
                    ("Fahrzeugliste für die Ausstellung festlegen", "Anna Berg", 3, "hoch"),
                    ("Catering anfragen", "Mia Krause", 10, "normal"),
                    ("Anzeige Tageszeitung buchen", "Anna Berg", 0, "normal"),
                    ("Flyer drucken lassen", "Mia Krause", 14, "normal"),
                    ("Probefahrt-Route festlegen", "Jonas Peters", 6, "niedrig")],
                {"quartalsziel": q, "ziel_status": "auf Kurs", "ziel_erledigt_heisst": "Messe geplant, Einladungen raus"}),
        projekt("Werkstatt umbauen", "Zweite Hebebühne und neue Teile-Ausgabe.", "#0F8F78",
                ["Lars Albers", "Tom Wagner"], [
                    ("Angebote Hebebühne vergleichen", "Lars Albers", 5, "hoch"),
                    ("Elektriker beauftragen", "Tom Wagner", 12, "normal"),
                    ("Regale Teile-Ausgabe bestellen", "Anna Berg", -2, "normal")],
                {"quartalsziel": q, "ziel_status": "nicht auf Kurs"}),
        projekt("Neue Website", "Fahrzeugsuche mit Anbindung an das Fahrzeugsystem.", "#D0141C", ["Mia Krause", "Lea Hoffmann"], [
            ("Texte für die Startseite", "Mia Krause", 20, "niedrig"),
            ("Fotos der Ausstellungsfahrzeuge", "Lea Hoffmann", 8, "normal")]),
    ))
    B = lambda a, *x: api.besprechungen_aufruf(a, list(x))                # noqa: E731


    def _besprechung():
        b = B("anlegen", {"art": "lieferant", "titel": "Jahresgespräch Hersteller1", "datum": tag(-3),
                          "teilnehmer": [pers["Anna Berg"], pers["Lars Albers"]]})["daten"]
        B("thema_anlegen", b["id"], {"titel": "Liefertermine Frühjahr absichern"})
        B("beschluss_anlegen", b["id"], {"text": "Vororder für 6 Kastenwagen bis 15.12. bestätigen",
                                         "grund": "Messefahrzeuge rechtzeitig auf dem Hof"})


    _versuch("besprechung", _besprechung)
    for text, bereich, tage, prio in [
            ("Zulassungsbescheinigung Teil II nachfordern", "Auslieferung", 1, "hoch"),
            ("Langsteher für die Herbstaktion auspreisen", "Bestand", 6, "normal"),
            ("Ablösung der zinsfreien Verträge mit der Bank besprechen", "Finanzierung", 3, "hoch"),
            ("Fotos für die Fahrzeugbörse nachreichen", "Bestand", 2, "normal"),
            ("Einweisungstermin mit Kunde Hansen bestätigen", "Auslieferung", 0, "hoch"),
            ("Messe-Fahrzeuge reservieren lassen", "Messe", 14, "niedrig")]:
        _versuch("todo", lambda: api.cockpit.todo_anlegen({"text": text, "bereich": bereich, "faellig_am": tag(tage),
                                                           "prioritaet": prio}))
    api._tresor.rechner_setzen("")

