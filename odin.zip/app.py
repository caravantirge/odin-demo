"""ODIN – Fensterprogramm von Caravan Muster. Die Oberfläche liegt in ui/, die Logik in tirge_helfer/."""

import atexit
import base64
import datetime as dt
import functools
import io
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
from dataclasses import asdict


def protokollordner() -> str:
    """Wie einstellungen.einstellungsordner(), aber ohne Abhängigkeiten – auch für Fehler beim Laden."""
    if sys.platform == "win32":
        basis = os.environ.get("APPDATA") or os.path.expanduser("~")
    elif sys.platform == "darwin":
        basis = os.path.expanduser("~/Library/Application Support")
    else:
        basis = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(basis, "ODIN")


def protokolliere(text: str):
    """Fehler in fehler.log (Windows: %APPDATA%\\ODIN, Mac: ~/Library/Application Support/ODIN); ab 1 MB neu."""
    try:
        os.makedirs(protokollordner(), exist_ok=True)
        pfad = os.path.join(protokollordner(), "fehler.log")
        if os.path.exists(pfad) and os.path.getsize(pfad) > 1_000_000:
            os.replace(pfad, pfad + ".alt")
        with open(pfad, "a", encoding="utf-8") as f:
            f.write(f"--- {dt.datetime.now():%d.%m.%Y %H:%M:%S} · {sys.platform} · Version {VERSION}\n{text}\n")
    except OSError:
        pass


try:   # schon ein Fehler beim Laden (z. B. eine Bibliothek passt nicht zur macOS-Version) landet im Protokoll
    from tirge_helfer.version import VERSION
    import pyperclip
    import webview

    from tirge_helfer.ab_lesen import lies_ab
    from tirge_helfer.ab_vergleich import INFO, WICHTIG, kurztext, vergleiche, wortdiff
    from tirge_helfer.berichte import exportiere_uebersicht, schreibe_mailbericht, schreibe_vergleich_pdf
    from tirge_helfer.einstellungen import EINSTELLUNGEN, einstellungsordner, speichere
    from tirge_helfer.excel_export import exportiere
    from tirge_helfer.fahrzeugablage import HERSTELLER, UNERLAUBT, Fahrzeugablage, eingegebene_auftragsnummer, finde_einlesbare
    from tirge_helfer.fliesstext import Ergebnis, lies_preisschild, lies_preisschilder
    from tirge_helfer.mails import ist_mail, lies_mail
    from tirge_helfer import syscara_api, zugang
    from tirge_helfer.cockpit.daten import LISTEN as COCKPIT_LISTEN, Cockpit, CockpitFehler
    from tirge_helfer.projekte import ProjektFehler, Projekte
    from tirge_helfer.konto import Konto
    from tirge_helfer.tresor import GemerkteAnmeldung, Tresor
    from tirge_helfer.microsoft import MicrosoftFehler
except Exception:
    VERSION = globals().get("VERSION", "?")
    protokolliere(traceback.format_exc())
    raise

# Diese Dateien darf „öffnen“ an das Betriebssystem geben (nie Programme, Verknüpfungen o. Ä.)
# Kein .xls (Makros), kein .csv (Formeln beim Öffnen in Excel)
OEFFNEN_ERLAUBT = {".pdf", ".xlsx", ".html", ".htm", ".msg", ".eml", ".txt", ".json"}
RESERVIERT = re.compile(r"^(con|prn|aux|nul|com[0-9¹²³]|lpt[0-9¹²³])$", re.I)
UNSICHTBAR = re.compile(r"[\x00-\x1f\x7f\u200b-\u200f\u202a-\u202e\u2066-\u2069]")   # Steuer- und Richtungszeichen


def _in_ordner(pfad: str, ordner: str) -> bool:
    """Liegt pfad in ordner (oder ist er es)? Rein nach dem Text der Pfade – ohne das Dateisystem zu fragen, damit
    ein fremder Netzwerkpfad gar nicht erst angefasst wird."""
    if not pfad or not ordner:
        return False
    p = os.path.normcase(os.path.abspath(pfad))
    o = os.path.normcase(os.path.abspath(ordner)).rstrip("\\/")
    return p == o or p.startswith(o + os.sep)


def ressource(*teile) -> str:
    basis = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(basis, *teile)


def als_dict(e: Ergebnis) -> dict:
    d = asdict(e)
    d["status"] = e.status
    return d


def aenderungen_dict(aenderungen) -> list:
    ergebnis = []
    for a in aenderungen:
        links, rechts = wortdiff(a.alt, a.neu)
        ergebnis.append({**asdict(a), "alt_w": links, "neu_w": rechts, "kurz": kurztext(a)})
    return ergebnis


def sicherer_name(name: str) -> str:
    """Dateiname aus einer Mail oder vom Ziehen: ohne Pfad und ohne Zeichen, die Windows nicht erlaubt (:<>?*|")."""
    name = os.path.basename((name or "").replace("\\", "/"))
    name = UNERLAUBT.sub("_", UNSICHTBAR.sub("", name)).strip(" .")[:150]
    if RESERVIERT.match(name.split(".")[0].strip()):          # CON.pdf, nul.tar.gz … sind unter Windows Geräte
        name = "_" + name
    return name


def eingang_dict(e) -> dict:
    return {"datei": e.datei, "status": e.status, "meldung": e.meldung, "neue_datei": e.neue_datei,
            "fahrzeug": e.fahrzeug.als_dict() if e.fahrzeug else None,
            "pruefung": e.pruefung, "stand": e.stand, "ordner_neu": e.ordner_neu}


def _ich_lesen(fest=None, rechner=None) -> str:
    """Wer bin ich? Im Browser gilt die Anmeldung der Sitzung des Geräts. Im Programm gilt die Person aus der
    Microsoft-Anmeldung ('fest()'), sonst die Anmeldung mit PIN an diesem Rechner ('rechner()', tresor.py)."""
    from tirge_helfer.web import ich_im_web
    aktiv, ich = ich_im_web()
    if aktiv:
        return ich or ""
    return (fest() if fest else "") or (rechner() if rechner else "")


def _ich_speichern(person_id: str, rechner_setzen=None):
    """Nur nach geprüfter PIN oder Microsoft-Anmeldung (tresor.py, konto.py) – und beim Abmelden ("")."""
    from tirge_helfer.web import ich_im_web, ich_im_web_setzen
    if ich_im_web()[0]:
        ich_im_web_setzen(person_id)
        return True
    return rechner_setzen(person_id) if rechner_setzen else False


def gemeinsam(ohne_sperre=(), sperren=True):
    """Für die *_aufruf-Schnittstellen: Aktion muss Text sein, Angaben eine Liste. Aufrufe laufen nacheinander
    (Fenster und Browser-Geräte schreiben dieselben Dateien – gleichzeitig gingen Einträge verloren). Unerwartete
    Fehler, z. B. durch eine von Hand veränderte gemeinsame Datei, enden als Meldung statt als Absturz."""
    def deko(funktion):
        @functools.wraps(funktion)
        def aufruf(self, aktion, argumente=None):
            if not isinstance(aktion, str):
                return {"ok": False, "fehler": "Unbekannte Aktion."}
            if argumente is not None and not isinstance(argumente, list):
                return {"ok": False, "fehler": "Ungültige Angaben."}
            try:
                if not sperren or aktion in ohne_sperre:
                    return funktion(self, aktion, argumente)
                if not self._speicher_sperre.acquire(timeout=SPERRE_WARTEN):
                    return {"ok": False, "fehler": "ODIN wartet gerade auf eine Datei im gemeinsamen Ordner (OneDrive?). "
                                                   "Bitte gleich noch einmal versuchen."}
                try:
                    return funktion(self, aktion, argumente)
                finally:
                    self._speicher_sperre.release()
            except Exception:                                   # noqa: BLE001
                protokolliere(f"{funktion.__name__} {aktion}: {traceback.format_exc()}")
                return {"ok": False, "fehler": "Das hat nicht geklappt. Möglicherweise ist eine gemeinsame Datei "
                                               "beschädigt – Details stehen im Protokoll."}
        return aufruf
    return deko


SPERRE_WARTEN = 15          # Sekunden – hängt ein Dateizugriff, bekommen die anderen eine Meldung statt mitzuhängen
FENSTER_AKTIONEN = {"protokoll_waehlen", "dokumente_hinzufuegen", "dokument_oeffnen", "ordner_oeffnen",
                    "ablage_waehlen", "ablage_zuruecksetzen"}


class Api:
    """Alles, was die Oberfläche über window.pywebview.api aufrufen kann."""

    _speicher_sperre = threading.RLock()         # gemeinsame Dateien: ein Aufruf nach dem anderen

    def __init__(self):
        self.fenster = None
        self._gewaehlt = set()                   # Pfade, die ein Mensch in einem Dateidialog gewählt hat
        self._sperre = threading.Lock()          # Eingang prüfen und Einlesen nie gleichzeitig
        self._schild_sperre = threading.Lock()
        self._einlesen = {"laeuft": False}
        self._einlesen_stopp = False
        self._syscara_roh = None                 # letzte Antwort der Syscara-Schnittstelle (für „Rohdaten speichern“)
        self.projekte = Projekte(lambda: EINSTELLUNGEN.get("fahrzeuge_ordner", ""),
                                 lambda: _ich_lesen(self._ich_fest, self._tresor.rechner_ich),
                                 self._ich_wechseln, einstellungsordner(), ich_fest=lambda: bool(self._ich_fest()))
        # Anmeldung mit PIN (Anmeldebildschirm „Tresor“) – privat, erreichbar nur über tresor_aufruf
        from tirge_helfer.web import geraet_im_web, ich_im_web
        self._tresor = Tresor(self.projekte, geraet=geraet_im_web, im_web=lambda: ich_im_web()[0],
                              verwalter=lambda: self._urlaub().ist_genehmiger(), einstellungen=EINSTELLUNGEN,
                              speichere=speichere, gemerkt=GemerkteAnmeldung(einstellungsordner()), protokoll=protokolliere)
        if EINSTELLUNGEN.get("projekte_ich"):           # früher: Person im Klartext – gilt nicht mehr als Anmeldung
            speichere("projekte_ich", "")
        self._web = None
        self.cockpit = Cockpit(EINSTELLUNGEN, speichere, einstellungsordner(), zugang_laden=zugang.lade,
                               protokoll=protokolliere, urlaub=self._urlaub, wissen=self._wissen_stichworte)
        # privat (Unterstrich): pywebview reicht öffentliche Unterobjekte samt Methoden an die Oberfläche weiter –
        # an die Anmeldung (Schlüssel, Mails) kommt die Oberfläche nur über konto_aufruf mit seiner Allowlist.
        self._konto = Konto(einstellungsordner(), self.projekte, self.cockpit, EINSTELLUNGEN, speichere,
                            ich_speichern=self._tresor.rechner_setzen, protokoll=protokolliere,
                            pin_bestaetigen=self._tresor.pin_bestaetigen,
                            dateien=lambda: bool((EINSTELLUNGEN.get("aktionen") or {}).get("excel_online")))
        self.cockpit.bei_neuen_daten = self._fenster_anstossen
        self._aktionen_obj = None

    # ---------------- Wer bin ich (Microsoft-Anmeldung oder Auswahl von Hand) ----------------
    def _ich_fest(self) -> str:
        """Person aus der Microsoft-Anmeldung – nur im Programm, nie für Anfragen aus dem Browser."""
        from tirge_helfer.web import ich_im_web
        if ich_im_web()[0] or getattr(self, "_konto", None) is None:
            return ""
        try:
            return self._konto.ich_fest()
        except Exception as e:                    # noqa: BLE001 – dann gilt die Auswahl von Hand
            protokolliere(f"Konto: wer bin ich? {e!r}")
            return ""

    def _ich_wechseln(self, person_id: str):
        """Auswahl von Hand – solange niemand mit Microsoft angemeldet (und verknüpft) ist."""
        fest = self._ich_fest()
        if fest and person_id != fest and any(p["id"] == fest for p in self.projekte.personen()):
            raise ProjektFehler("Du bist mit Microsoft angemeldet – wer du in ODIN bist, steht unter „Datenquellen“ → "
                                "„Konto & Anmeldung“. Dort lässt es sich ändern.")
        return _ich_speichern(person_id, self._tresor.rechner_setzen)

    # ---------------- Allgemein ----------------
    def design(self, wert=None):
        """Hell/Dunkel/Automatisch lesen oder speichern."""
        if wert in ("auto", "hell", "dunkel"):
            speichere("design", wert)
        return EINSTELLUNGEN.get("design", "auto")

    def stil(self, wert=None):
        """Gestaltung ODIN 2 / ODIN 3 lesen oder speichern."""
        if wert in ("v2", "v3"):
            speichere("stil", wert)
        return EINSTELLUNGEN.get("stil", "v3")

    def oberflaeche(self, schluessel, wert=None):
        """Persönliche Ansicht lesen oder speichern (z. B. „dashboard“: Anordnung und ausgeblendete Kacheln).
        Das Fenster läuft ohne dauerhaften Browserspeicher – deshalb liegt so etwas in den Einstellungen."""
        if not isinstance(schluessel, str) or not re.fullmatch(r"[a-z_-]{1,40}", schluessel):
            return None
        alle = dict(EINSTELLUNGEN.get("oberflaeche") or {})
        if wert is not None:
            if len(json.dumps(wert)) > 20000 or (schluessel not in alle and len(alle) >= 60):
                return None
            alle[schluessel] = wert
            speichere("oberflaeche", alle)
        return alle.get(schluessel)

    def _merke(self, *pfade):
        """Pfade aus einem Dateidialog: nur solche nimmt ODIN später von der Oberfläche wieder an."""
        for pfad in pfade:
            if isinstance(pfad, str) and pfad:
                self._gewaehlt.add(os.path.normcase(os.path.abspath(pfad)))
        if len(self._gewaehlt) > 5000:
            self._gewaehlt.clear()

    def _wurde_gewaehlt(self, pfad) -> bool:
        return isinstance(pfad, str) and bool(pfad) and os.path.normcase(os.path.abspath(pfad)) in self._gewaehlt

    def _eigene_orte(self) -> list:
        """Ordner und Dateien, mit denen ODIN arbeitet – nur dort darf die Oberfläche etwas öffnen lassen."""
        orte = [EINSTELLUNGEN.get("fahrzeuge_ordner", ""), EINSTELLUNGEN.get("rechtsfaelle_ordner", ""),
                EINSTELLUNGEN.get("cashback_ordner", ""), einstellungsordner()]
        orte += list((EINSTELLUNGEN.get("cockpit_quellen") or {}).values())
        return [o for o in orte if isinstance(o, str) and o]

    def oeffne(self, pfad):
        """Datei oder Ordner öffnen – nur an ODINs eigenen Orten oder was vorher im Dialog gewählt wurde."""
        if not isinstance(pfad, str) or not pfad:
            return False
        if not (self._wurde_gewaehlt(pfad) or any(_in_ordner(pfad, ort) for ort in self._eigene_orte())):
            protokolliere(f"Öffnen abgelehnt (außerhalb der ODIN-Ordner): {pfad[:200]!r}")
            return False
        if not os.path.exists(pfad):
            return False
        echt = os.path.realpath(pfad)                         # Verknüpfung, die aus den ODIN-Ordnern hinausführt?
        if not (self._wurde_gewaehlt(pfad) or any(_in_ordner(echt, os.path.realpath(ort)) for ort in self._eigene_orte())):
            return False
        endung = os.path.splitext(pfad)[1].lower()
        if not os.path.isdir(pfad) and endung not in OEFFNEN_ERLAUBT:
            return False
        if endung in (".html", ".htm"):                       # HTML nur, wo ODIN es selbst schreibt (Mailberichte)
            berichte = os.path.join(EINSTELLUNGEN.get("fahrzeuge_ordner", "") or os.sep, "_Mailberichte")
            if not _in_ordner(echt, os.path.realpath(berichte)):
                return False
        return self._starte(pfad)

    @staticmethod
    def _starte(pfad):
        """Datei oder Ordner mit dem passenden Programm des Betriebssystems öffnen (Prüfung macht der Aufrufer)."""
        try:
            if sys.platform == "win32":
                os.startfile(pfad)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", pfad])
            else:
                subprocess.Popen(["xdg-open", pfad])
        except OSError:
            return False                           # kein Programm zum Öffnen – die Oberfläche meldet es
        return True

    def _speichern_unter(self, vorschlag, typ):
        ziel = self.fenster.create_file_dialog(webview.FileDialog.SAVE, save_filename=vorschlag, file_types=(typ,))
        if not ziel:
            return None
        pfad = ziel if isinstance(ziel, str) else ziel[0]
        endung = os.path.splitext(vorschlag)[1]
        return pfad if pfad.lower().endswith(endung) else pfad + endung

    # ---------------- Preisschilder ----------------
    def dateien_waehlen(self):
        pfade = self.fenster.create_file_dialog(
            webview.FileDialog.OPEN, allow_multiple=True, file_types=("PDF (*.pdf)",))
        self._merke(*(pfade or []))
        return list(pfade or [])

    def ordner_waehlen(self):
        ordner = self.fenster.create_file_dialog(webview.FileDialog.FOLDER)
        if not ordner:
            return None                            # abgebrochen
        ordner = ordner[0]
        pfade = [os.path.join(ordner, f) for f in sorted(os.listdir(ordner)) if f.lower().endswith(".pdf")]
        self._merke(*pfade)
        return pfade

    def lies_pfad(self, pfad):
        """Liste, weil eine PDF mehrere Preisschilder enthalten kann. Nur Dateien aus dem Dateidialog."""
        if not self._wurde_gewaehlt(pfad) or not str(pfad).lower().endswith(".pdf"):
            raise ValueError("Diese Datei wurde nicht über „Dateien wählen“ ausgesucht.")
        return [{**als_dict(e), "pfad": pfad} for e in lies_preisschilder(pfad)]

    def lies_upload(self, name, inhalt_base64):
        """Hineingezogene PDF: eine Kopie in einem temporären Ordner, damit sie sich öffnen lässt."""
        daten = base64.b64decode(inhalt_base64)
        pfad = ""
        try:
            with self._schild_sperre:
                if not getattr(self, "_schild_ordner", None):
                    self._schild_ordner = tempfile.mkdtemp(prefix="ODIN-Preisschilder-")
                    atexit.register(shutil.rmtree, self._schild_ordner, True)
            basis, endung = os.path.splitext(sicherer_name(name) or "Preisschild.pdf")
            pfad = Fahrzeugablage.schreibe_neu(self._schild_ordner, basis, ".pdf", daten)   # nie eine andere Endung
            self._merke(pfad)
        except OSError:
            pfad = ""                              # Öffnen geht dann nicht, Lesen trotzdem
        return [{**als_dict(e), "pfad": pfad} for e in lies_preisschilder(io.BytesIO(daten), datei=name)]

    def werbetext(self, optionen, modell="", gewaehlt=None):
        """mobile.de-Text neu bauen (anderes Modell, Merkmale an/aus). gewaehlt=None: automatisch."""
        from tirge_helfer.werbetext import baue
        return baue(optionen or [], modell or "", gewaehlt)

    def kopiere(self, text):
        try:
            pyperclip.copy(text)
        except Exception as e:
            raise RuntimeError("Kopieren in die Zwischenablage hat nicht geklappt – bitte noch einmal versuchen.") from e
        return True

    def exportiere(self, zeilen):
        pfad = self._speichern_unter("Fliesstexte.xlsx", "Excel (*.xlsx)")
        if not pfad:
            return {"ok": False, "abgebrochen": True}
        felder = Ergebnis.__dataclass_fields__
        ergebnisse = [Ergebnis(**{k: v for k, v in z.items() if k in felder}) for z in zeilen]
        try:
            exportiere(ergebnisse, pfad)
        except PermissionError:
            return {"ok": False, "fehler": "Die Datei ist gerade geöffnet. Bitte schließen und erneut versuchen."}
        return {"ok": True, "pfad": pfad}

    # ---------------- Syscara-Schnittstelle (Fließtexte ohne Preisschild) ----------------
    def syscara_zugang(self):
        """Ist ein Zugang gespeichert? Das Passwort geht nie an die Oberfläche."""
        st = zugang.status()
        return {"benutzer": zugang.benutzer(), "hinweis": st["hinweis"], "warnung": st["warnung"]}

    def syscara_zugang_speichern(self, benutzer, passwort):
        """Erst testen, dann speichern – ein falscher Zugang wird gar nicht erst abgelegt."""
        try:
            syscara_api.teste_zugang((benutzer or "").strip(), passwort or "")
            wie = zugang.speichere(benutzer, passwort)
        except (syscara_api.SyscaraFehler, ValueError, OSError) as e:
            return {"ok": False, "fehler": str(e)}
        return {"ok": True, "benutzer": (benutzer or "").strip(), "wie": wie, "hinweis": zugang.status()["hinweis"]}

    def syscara_zugang_loeschen(self):
        zugang.loesche()
        return True

    def syscara_fliesstexte(self, ids_text="", tage=14):
        """Fahrzeuge aus Syscara holen und wie Preisschilder auswerten: die genannten Internen IDs oder alle,
        die in den letzten 'tage' Tagen in Syscara geändert wurden."""
        daten = zugang.lade()
        if not daten:
            return {"ok": False, "fehler": "Kein Syscara-Zugang gespeichert.", "zugang_fehlt": True}
        ids = syscara_api.ids_aus_text(ids_text)
        seit = "" if ids else (dt.date.today() - dt.timedelta(days=max(1, int(tage or 14)))).isoformat()
        try:
            r = syscara_api.hole_fahrzeuge(*daten, interne_ids=ids, seit=seit)
        except syscara_api.SyscaraFehler as e:
            return {"ok": False, "fehler": str(e)}
        self._syscara_roh = r["roh"]
        ergebnisse = []
        for fz in r["fahrzeuge"]:
            try:
                ergebnisse.append(als_dict(syscara_api.ergebnis_aus(fz)))
            except Exception as e:                # ein ungewöhnliches Fahrzeug darf die anderen nicht aufhalten
                protokolliere(f"Syscara-Fahrzeug {fz.get('id')}: {traceback.format_exc()}")
                ergebnisse.append(als_dict(Ergebnis(datei=f"Syscara · {fz.get('id', '')}",
                                                    fehler=f"Nicht auswertbar: {e}")))
        return {"ok": True, "ergebnisse": ergebnisse, "nicht_gefunden": r["nicht_gefunden"], "seit": seit}

    def syscara_rohdaten_speichern(self):
        """Die zuletzt geholten Daten als Datei – für Rückfragen, ohne Zugangsdaten."""
        if not self._syscara_roh:
            return {"ok": False, "fehler": "Noch nichts aus Syscara geholt."}
        pfad = self._speichern_unter(f"Syscara-Daten_{dt.date.today().isoformat()}.json", "JSON (*.json)")
        if not pfad:
            return {"ok": False, "abgebrochen": True}
        with open(pfad, "w", encoding="utf-8") as f:
            json.dump(self._syscara_roh, f, ensure_ascii=False, indent=1)
        return {"ok": True, "pfad": pfad}

    # ---------------- Cockpit (Excel-Listen, To-dos, Vorordern) ----------------
    def cockpit_daten(self, neu=False):
        d = self.cockpit.daten(bool(neu))
        if not isinstance(d, dict):
            return d
        # Das Datenpaket ist für alle dasselbe; was nur Finanz-Berechtigte sehen, fällt hier je Person heraus
        from tirge_helfer.cockpit.auswertungen import agenda_ohne_finanzen, betraege_ausblenden
        darf, liste, aendern = self._assistent_finanzen_stand()
        d = {**d, "finanzen": darf, "assistentFinanzen": {"personen": liste, "aendern": aendern}}
        if not darf:
            if isinstance(d.get("agenda"), dict):
                d["agenda"] = agenda_ohne_finanzen(d["agenda"])
            for liste in ("raster", "ampel"):              # Bemerkungen der Auslieferungsliste: „Rest offen 17.380“
                if isinstance(d.get(liste), list):
                    d[liste] = [{**z, "bemerkung": betraege_ausblenden(z.get("bemerkung"))} if isinstance(z, dict)
                                and z.get("bemerkung") else z for z in d[liste]]
            if isinstance(d.get("beispielfragen"), list):
                d["beispielfragen"] = [g for g in d["beispielfragen"] if not (isinstance(g, dict) and g.get("finanzen"))]
            # Zu erwartende Zahlungen: Wer ausliefert, muss sehen, ob das Geld da ist (Wunsch des Inhabers) – ohne
            # Finanzrecht aber ohne Beträge und ohne Bemerkungen (dort stehen oft Beträge)
            if isinstance(d.get("erwartet"), list):
                d["erwartet"] = [{k: v for k, v in z.items() if k not in ("betrag", "bemerkung")}
                                 for z in d["erwartet"] if isinstance(z, dict)]
            d["erwartetK"] = None
        return d

    def _assistent_finanzen_stand(self):
        """(darf, liste, aendern): Darf die Person hier Finanzzahlen im Assistenten und in „Heute & Woche“ sehen?
        Nur am Rechner (im Browser weiß ODIN nicht sicher, wer am Gerät sitzt) und nur, wer in der Liste steht.
        Ändern darf die Liste jede Person am Rechner, solange sie leer ist – danach nur, wer darin steht."""
        from tirge_helfer.web import ich_im_web
        liste = self.cockpit.assistent_finanzen()
        if ich_im_web()[0]:
            return False, liste, False
        try:
            ich = self.projekte.ich()
        except Exception:                                   # z. B. Ordner „Fahrzeuge“ gerade nicht erreichbar
            ich = ""
        return bool(ich and ich in liste), liste, bool(ich) and (not liste or ich in liste)

    @staticmethod
    def _cockpit_aufruf(funktion, *argumente):
        """Fehler für Menschen gehen als {"fehler": …} an die Oberfläche, alles andere ins Protokoll."""
        try:
            return funktion(*argumente)
        except CockpitFehler as e:
            return {"ok": False, "fehler": str(e)}

    def cockpit_quelle_waehlen(self, art):
        name = next((l["name"] for l in COCKPIT_LISTEN if l["art"] == art), None)
        if not name:
            return {"fehler": "Unbekannte Liste."}
        pfade = self.fenster.create_file_dialog(webview.FileDialog.OPEN, file_types=("Excel (*.xlsx;*.xlsm)",))
        if not pfade:
            return None                                       # abgebrochen
        pfad = pfade if isinstance(pfade, str) else pfade[0]
        try:
            r = self.cockpit.pruefe_datei(art, pfad)
        except CockpitFehler as e:
            return {"meldung": str(e), "fehler": True}
        except Exception as e:
            protokolliere(f"Cockpit: {pfad} als {art}: {traceback.format_exc()}")
            return {"meldung": f"{name}: Die Datei ließ sich nicht lesen ({e}).", "fehler": True}
        self.cockpit.quelle_setzen(art, pfad)
        return r

    def cockpit_quelle_entfernen(self, art):
        return self._cockpit_aufruf(self.cockpit.quelle_setzen, art, "")

    def cockpit_quelle_oeffnen(self, art):
        return self.oeffne(self.cockpit.quellen().get(art, ""))

    def cockpit_struktur_speichern(self, art):
        """Aufbau einer Liste (Blätter, Spaltennamen, Farben – keine Werte) als Datei zum Weitergeben."""
        from tirge_helfer.cockpit.struktur import struktur
        pfad = self.cockpit.quellen().get(art, "")
        if not pfad or not os.path.exists(pfad):
            return {"meldung": "Die Datei ist nicht (mehr) da.", "fehler": True}
        try:
            bericht = struktur(pfad)
        except Exception as e:
            protokolliere(f"Cockpit-Struktur {pfad}: {traceback.format_exc()}")
            return {"meldung": f"Aufbau nicht lesbar: {e}", "fehler": True}
        name = os.path.splitext(os.path.basename(pfad))[0]
        ziel = self._speichern_unter(f"Aufbau_{sicherer_name(name)}_{dt.date.today().isoformat()}.json", "JSON (*.json)")
        if not ziel:
            return None
        with open(ziel, "w", encoding="utf-8") as f:
            json.dump(bericht, f, ensure_ascii=False, indent=1)
        return {"meldung": f"Gespeichert: {os.path.basename(ziel)} – enthält nur Spaltennamen und Farben, keine Werte.",
                "fehler": False}

    def cockpit_frage(self, text, kontext=None):
        return self.cockpit.frage(text, kontext, finanzen=self._assistent_finanzen_stand()[0])

    def cockpit_syscara_abgleich(self):
        try:
            return self.cockpit.syscara_abgleich()
        except (CockpitFehler, syscara_api.SyscaraFehler) as e:
            return {"meldung": str(e), "fehler": True}

    def cockpit_todo_anlegen(self, eingabe):
        return self._cockpit_aufruf(self.cockpit.todo_anlegen, eingabe)

    def cockpit_todo_umschalten(self, todo_id):
        return self._cockpit_aufruf(self.cockpit.todo_umschalten, todo_id)

    def cockpit_todo_loeschen(self, todo_id):
        return self._cockpit_aufruf(self.cockpit.todo_loeschen, todo_id)

    def cockpit_vororder_anlegen(self, eingabe):
        return self._cockpit_aufruf(self.cockpit.vororder_anlegen, eingabe)

    def cockpit_vororder_loeschen(self, vororder_id):
        return self._cockpit_aufruf(self.cockpit.vororder_loeschen, vororder_id)

    def cockpit_abloesung_planen(self, internal_id, datum):
        return self._cockpit_aufruf(self.cockpit.abloesung_planen, internal_id, datum)

    def cockpit_abloesung_loeschen(self, internal_id):
        return self._cockpit_aufruf(self.cockpit.abloesung_loeschen, internal_id)

    # ---------------- Führung im Cockpit (Scorecard, Fristen, Bonus, Einstellungen) ----------------
    COCKPIT_AKTIONEN = {"scorecard_speichern", "scorecard_wert", "frist_speichern", "frist_erledigt", "frist_loeschen",
                        "bonus_speichern", "bonus_loeschen", "fuehrung_einstellungen", "cashback_verantwortlich",
                        "fahrzeugtyp_zuordnen", "assistent_finanzen", "luecke_melden", "live_stand"}

    def cashback_ordner_waehlen(self):
        """Ordner mit den Cashback-Aktionslisten wählen (z. B. „GUTSCHRIFTEN Cashback Aktionen“ in OneDrive)."""
        ordner = self.fenster.create_file_dialog(webview.FileDialog.FOLDER)
        if not ordner:
            return None
        ordner = ordner if isinstance(ordner, str) else ordner[0]
        try:
            return self.cockpit.cashback_ordner_setzen(ordner)
        except CockpitFehler as e:
            return {"ok": False, "fehler": str(e)}
        except Exception as e:
            protokolliere(f"Cashback: {ordner}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Der Ordner ließ sich nicht lesen ({e})."}

    def cashback_ordner_entfernen(self):
        return self._cockpit_aufruf(self.cockpit.cashback_ordner_setzen, "")

    def cashback_oeffnen(self, datei=""):
        """Den Cashback-Ordner oder eine Liste darin öffnen (nur Dateien direkt in diesem Ordner)."""
        ordner = self.cockpit.cashback_ordner()
        if not ordner or not os.path.isdir(ordner):
            return {"ok": False, "fehler": "Der Cashback-Ordner ist nicht erreichbar."}
        if not datei:
            return {"ok": bool(self._starte(ordner))}
        name = os.path.basename(str(datei))
        pfad = os.path.join(ordner, name)
        if name != str(datei) or not os.path.isfile(pfad):
            return {"ok": False, "fehler": "Datei nicht gefunden."}
        if os.path.islink(pfad) or not _in_ordner(os.path.realpath(pfad), os.path.realpath(ordner)):
            return {"ok": False, "fehler": "Das ist eine Verknüpfung nach außerhalb des Ordners."}
        if not name.lower().endswith(".xlsx"):                # keine Mappe mit Makros per Klick aus ODIN
            return {"ok": False, "fehler": "Aus ODIN lassen sich nur .xlsx-Listen öffnen."}
        return {"ok": bool(self._starte(pfad))}

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN | {"live_stand"})     # Live-Abfrage wartet nie auf eine laufende Aktion
    def cockpit_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für die neueren Cockpit-Bereiche; Antwort wie bei den To-dos ({"ok"} oder {"fehler"})."""
        if aktion not in self.COCKPIT_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        if aktion == "assistent_finanzen":
            # Wer ändert, bestimmt ODIN selbst (Person am Rechner) – nie aus den Angaben der Oberfläche
            from tirge_helfer.web import ich_im_web
            if ich_im_web()[0]:
                return {"ok": False, "fehler": "Das geht nur am Rechner in ODIN."}
            try:
                ich = self.projekte.ich()
                bekannte = [p["id"] for p in self.projekte.personen()]
            except Exception:
                return {"ok": False, "fehler": "Die Personenliste ist gerade nicht lesbar."}
            return self._cockpit_aufruf(self.cockpit.assistent_finanzen_setzen, (argumente or [None])[0], ich, bekannte)
        try:
            return self._cockpit_aufruf(getattr(self.cockpit, aktion), *(argumente or []))
        except TypeError as e:
            protokolliere(f"Cockpit {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- In ODIN arbeiten (Aktionen: Satz → Vorschau → Excel und ODIN) ----------------
    AKTIONEN_AUFRUFE = {"verstehen", "ausfuehren", "abbrechen", "rueckgaengig", "liste", "katalog",
                        "einstellungen_speichern"}

    def _aktionen(self):
        if self._aktionen_obj is None:
            from tirge_helfer.aktionen.dienst import Aktionsdienst
            self._aktionen_obj = Aktionsdienst(
                self.cockpit, projekte=self.projekte, urlaub=self._urlaub, messe=self._messe, tickets=self._tickets,
                anmeldung=lambda: self._konto.anmeldung, einstellungen=EINSTELLUNGEN, speichere=speichere,
                protokoll=protokolliere, einstellungsordner=einstellungsordner())
        return self._aktionen_obj

    def _wer(self):
        """(Personen-ID, Name) der fragenden Person – im Browser die des Geräts."""
        try:
            ich = self.projekte.ich()
            name = next((p.get("name") for p in self.projekte.personen() if p.get("id") == ich), "") if ich else ""
        except Exception:                                   # noqa: BLE001 – Ordner gerade nicht erreichbar
            ich, name = "", ""
        return ich or "", name or ""

    def _fenster_anstossen(self):
        """Neue Daten aus der Überwachung: die Oberfläche im Fenster sofort auffrischen (im Browser fragt sie selbst)."""
        if self.fenster is not None:
            try:
                self.fenster.evaluate_js("window.odinLive && window.odinLive()")
            except Exception:                               # noqa: BLE001 – Fenster gerade zu
                pass

    @gemeinsam()
    def aktionen_aufruf(self, aktion, argumente=None):
        """In ODIN arbeiten: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}. Rechte prüft der Dienst selbst
        (Finanzrecht, Browser) – nie aus den Angaben der Oberfläche."""
        from tirge_helfer.aktionen.basis import AktionsFehler
        from tirge_helfer.web import ich_im_web
        if aktion not in self.AKTIONEN_AUFRUFE:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        a = list(argumente or [])
        dienst = self._aktionen()
        finanzen = self._assistent_finanzen_stand()[0]
        im_web = ich_im_web()[0]
        ich, name = self._wer()
        try:
            if aktion == "verstehen":
                daten = dienst.verstehen(a[0] if a else "", a[1] if len(a) > 1 else None, finanzen, im_web, ich, name)
            elif aktion == "ausfuehren":
                daten = dienst.ausfuehren(a[0] if a else "", bool(a[1]) if len(a) > 1 else False, finanzen, im_web, ich, name)
                if not daten.get("ok"):
                    return {"ok": False, "fehler": daten.get("fehler"), "geaendert": daten.get("geaendert", False)}
            elif aktion == "abbrechen":
                daten = dienst.abbrechen(a[0] if a else "")
            elif aktion == "rueckgaengig":
                daten = dienst.rueckgaengig(a[0] if a else "", finanzen, im_web, ich, name)
                if not daten.get("ok"):
                    return {"ok": False, "fehler": daten.get("fehler")}
            elif aktion == "liste":
                daten = dienst.liste(a[0] if a else None, finanzen)
            elif aktion == "katalog":
                daten = {**dienst.katalog(finanzen), "im_browser": im_web, "finanzen": finanzen}
            else:
                if im_web:
                    return {"ok": False, "fehler": "Das geht nur am Rechner in ODIN."}
                daten = dienst.einstellungen_speichern(a[0] if a else None)
        except AktionsFehler as e:
            return {"ok": False, "fehler": str(e)}
        return {"ok": True, "daten": daten}

    # ---------------- ODIN im Browser (Handy & Tablet im Firmennetz) ----------------
    def _web_server(self):
        if self._web is None:
            from tirge_helfer.web import WebServer
            port = EINSTELLUNGEN.get("web_port") or 8765
            self._web = WebServer(self, ressource("ui"), port=int(port), protokoll=protokolliere)
        return self._web

    def _web_status(self) -> dict:
        st = self._web_server().status() if self._web is not None else {"laeuft": False, "adressen": [], "code": ""}
        if st.get("laeuft") and st.get("adressen"):
            try:
                import segno
                st["qr"] = segno.make(f"{st['adressen'][0]}/?code={st['code']}", error="m").svg_inline(
                    scale=5, dark="#231F20", light="#FFFFFF", border=2)
            except Exception as e:                      # QR ist Komfort – ohne geht es auch
                protokolliere(f"QR-Code: {e!r}")
        return st

    def web_status(self):
        return self._web_status()

    def web_freigeben(self):
        """Startet ODIN im Browser. Nur hier im Programm aufrufbar, nie aus dem Browser."""
        try:
            self._web_server().start()
        except OSError as e:
            return {"laeuft": False, "fehler": f"Der Anschluss {self._web_server().port} ist belegt oder gesperrt ({e})."}
        return self._web_status()

    def web_beenden(self):
        if self._web is not None:
            self._web.stopp()
        return self._web_status()

    # ---------------- Projekte ----------------
    PROJEKT_AKTIONEN = {
        "start", "personen", "person_anlegen", "abmelden", "projekt", "meine_aufgaben", "projekt_anlegen",
        "projekt_aendern", "projekt_loeschen", "mitglied_hinzufuegen", "mitglied_entfernen", "spalte_anlegen",
        "spalte_umbenennen", "spalte_loeschen", "aufgabe_anlegen", "aufgabe_aendern", "aufgabe_verschieben",
        "aufgabe_erledigen", "aufgabe_loeschen", "punkt_anlegen", "punkt_umschalten", "punkt_loeschen",
        "kommentar_anlegen", "kommentar_loeschen", "ziele",
    }

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN)
    def projekte_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für alles rund um Projekte: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}."""
        if aktion not in self.PROJEKT_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        try:
            return {"ok": True, "daten": getattr(self.projekte, aktion)(*(argumente or []))}
        except ProjektFehler as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Projekte {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Anmeldung mit PIN (Tresor) ----------------
    TRESOR_AKTIONEN = Tresor.AKTIONEN

    @gemeinsam()
    def tresor_aufruf(self, aktion, argumente=None):
        """Personenwahl mit PIN, PIN ändern/zurücksetzen, Abmelden, Einstellungen dieses Rechners:
        {"ok": True, "daten": …} oder {"ok": False, "fehler": …}."""
        if aktion not in self.TRESOR_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        try:
            return {"ok": True, "daten": getattr(self._tresor, aktion)(*(argumente or []))}
        except ProjektFehler as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Anmeldung {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Urlaub ----------------
    URLAUB_AKTIONEN = {"start", "regeln", "regeln_speichern", "antrag_stellen", "antrag_pruefen", "antrag",
                       "antrag_zurueckziehen", "entscheiden", "antraege", "kalender", "konto", "konten",
                       "ist_genehmiger"}

    def _urlaub(self):
        if getattr(self, "_urlaub_obj", None) is None:
            from tirge_helfer.urlaub_antraege import Urlaub
            self._urlaub_obj = Urlaub(self.projekte)
        return self._urlaub_obj

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN)
    def urlaub_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für Urlaubsanträge: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}."""
        from tirge_helfer.urlaub_antraege import UrlaubFehler
        try:
            if aktion == "planer_vorschlag":                  # Regeln aus dem Excel-Urlaubsplaner vorschlagen
                pfad = self.cockpit.quellen().get("urlaubsplaner", "")
                if not pfad:
                    return {"ok": False, "fehler": "Unter „Datenquellen“ ist noch kein Urlaubsplaner gewählt."}
                return {"ok": True, "daten": self._urlaub().planer_vorschlag(pfad)}
            if aktion not in self.URLAUB_AKTIONEN:
                return {"ok": False, "fehler": "Unbekannte Aktion."}
            return {"ok": True, "daten": getattr(self._urlaub(), aktion)(*(argumente or []))}
        except (UrlaubFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Urlaub {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Tagesfragen ----------------
    TAGESFRAGEN_AKTIONEN = {"start", "heute", "antworten", "ueberspringen", "stand", "team", "offen", "fragen_liste",
                            "frage_speichern", "frage_aktiv", "frage_vorschlagen", "vorschlaege",
                            "vorschlag_entscheiden", "einstellungen_speichern", "verlosung", "verlosen"}

    def _tagesfragen(self):
        if getattr(self, "_tagesfragen_obj", None) is None:
            from tirge_helfer.tagesfragen import Tagesfragen
            self._tagesfragen_obj = Tagesfragen(self.projekte, self._urlaub, self.cockpit, protokoll=protokolliere)
        return self._tagesfragen_obj

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN)
    def tagesfragen_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für die Tagesfragen: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}."""
        from tirge_helfer.tagesfragen import TagesfragenFehler
        from tirge_helfer.urlaub_antraege import UrlaubFehler
        if aktion not in self.TAGESFRAGEN_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        try:
            return {"ok": True, "daten": getattr(self._tagesfragen(), aktion)(*(argumente or []))}
        except (TagesfragenFehler, UrlaubFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Tagesfragen {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Messe-Personal (ABF, Hausmesse) ----------------
    MESSE_AKTIONEN = {"start", "anlegen", "aendern", "entfernen", "csv", "bearbeiter_setzen"}

    def _messe(self):
        if getattr(self, "_messe_obj", None) is None:
            from tirge_helfer.messe import MessePersonal
            self._messe_obj = MessePersonal(self.projekte, self._urlaub)
        return self._messe_obj

    def _messe_csv_speichern(self, argumente):
        """CSV über den Speichern-Dialog (nur im Fenster) – UTF-8 mit BOM, damit Excel die Umlaute erkennt."""
        export = self._messe().csv(*(argumente or [])[:1])
        pfad = self._speichern_unter(export["name"], "CSV für Excel (*.csv)")
        if not pfad:
            return {"ok": False, "abgebrochen": True}
        try:
            with open(pfad, "w", encoding="utf-8-sig", newline="") as f:
                f.write(export["text"])
        except PermissionError:
            return {"ok": False, "fehler": "Die Datei ist gerade geöffnet. Bitte schließen und erneut versuchen."}
        return {"ok": True, "daten": {"pfad": pfad}}

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN | {"csv_speichern"})
    def messe_aufruf(self, aktion, argumente=None):
        """Messe-Personalplanung: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}. Rechte prüft messe.py."""
        from tirge_helfer.messe import MesseFehler
        try:
            if aktion == "csv_speichern":
                return self._messe_csv_speichern(argumente)
            if aktion not in self.MESSE_AKTIONEN:
                return {"ok": False, "fehler": "Unbekannte Aktion."}
            return {"ok": True, "daten": getattr(self._messe(), aktion)(*(argumente or []))}
        except (MesseFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Messe {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Tickets ----------------
    TICKET_AKTIONEN = {"start", "liste", "ticket", "zaehler", "hinweise", "anlegen", "kommentieren",
                       "status_setzen", "fuer_claude"}

    def _tickets(self):
        """Bewusst kein öffentliches Attribut (pywebview reicht öffentliche Unterobjekte ans Fenster durch)."""
        if getattr(self, "_tickets_obj", None) is None:
            from tirge_helfer.tickets import Tickets
            from tirge_helfer.web import ich_im_web
            self._tickets_obj = Tickets(self.projekte, self._urlaub, self._wissen,
                                        lambda: os.path.join(protokollordner(), "fehler.log"),
                                        lambda: ich_im_web()[0], VERSION)
        return self._tickets_obj

    @gemeinsam()
    def tickets_aufruf(self, aktion, argumente=None):
        """Tickets: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}. Melden und eigene Tickets für alle (auch
        im Browser); alle sehen, Status setzen und „Für Claude“ nur Verwalter am Rechner."""
        from tirge_helfer.tickets import TicketFehler
        if aktion not in self.TICKET_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        try:
            return {"ok": True, "daten": getattr(self._tickets(), aktion)(*(argumente or [])[:3])}
        except (TicketFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Tickets {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Besprechungen & Protokolle ----------------
    BESPRECHUNG_AKTIONEN = {
        "start", "liste", "besprechung", "anlegen", "aendern", "loeschen", "abschnitt_anlegen", "abschnitt_loeschen",
        "thema_anlegen", "thema_aendern", "thema_loeschen", "beschluss_anlegen", "beschluss_aendern",
        "beschluss_loeschen", "aufgabe_anlegen", "aufgabe_erledigen", "aufgabe_loeschen", "bewerten", "beschluesse",
    }

    def _besprechungen(self):
        if getattr(self, "_besprechungen_obj", None) is None:
            from tirge_helfer.besprechungen import Besprechungen
            self._besprechungen_obj = Besprechungen(self.projekte)
        return self._besprechungen_obj

    def _protokoll_aufruf(self, aktion, argumente):
        """Protokoll aus der Protokoll-App: Datei wählen (mit Vorschau), dann übernehmen – nur die gewählte Datei."""
        if aktion == "protokoll_waehlen":
            pfade = self.fenster.create_file_dialog(
                webview.FileDialog.OPEN, allow_multiple=False, file_types=("Protokoll (*.json)", "Alle Dateien (*.*)"))
            if not pfade:
                return None                                       # abgebrochen
            pfad = pfade if isinstance(pfade, str) else pfade[0]
            vorschau = self._besprechungen().protokoll_vorschau(pfad)
            self._protokoll_pfad = pfad
            return {**vorschau, "datei": os.path.basename(pfad)}
        pfad = getattr(self, "_protokoll_pfad", "")
        if not pfad:
            from tirge_helfer.besprechungen import BesprechungFehler
            raise BesprechungFehler("Bitte zuerst die Datei aus der Protokoll-App wählen.")
        ergebnis = self._besprechungen().protokoll_uebernehmen(pfad, *(argumente or [])[:1])
        self._protokoll_pfad = ""
        return ergebnis

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN)
    def besprechungen_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für Besprechungen: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}."""
        from tirge_helfer.besprechungen import BesprechungFehler
        if aktion not in self.BESPRECHUNG_AKTIONEN | {"protokoll_waehlen", "protokoll_uebernehmen"}:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        try:
            if aktion.startswith("protokoll_"):
                return {"ok": True, "daten": self._protokoll_aufruf(aktion, argumente)}
            return {"ok": True, "daten": getattr(self._besprechungen(), aktion)(*(argumente or []))}
        except (BesprechungFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Besprechungen {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Rechtsfälle ----------------
    RECHTSFALL_AKTIONEN = {
        "start", "liste", "akte", "anlegen", "aendern", "phase_setzen", "loeschen", "frist_anlegen", "frist_aendern",
        "frist_loeschen", "frist_rechnen", "ereignis_anlegen", "ereignis_aendern", "ereignis_loeschen",
        "dokument_aendern", "dokument_entfernen", "vorschau", "beleg_anlegen", "beleg_aendern", "beleg_loeschen",
        "schritt_abhaken", "entwurf", "dossier", "dossier_speichern", "zaehler", "agenda",
    }
    # Diese brauchen das Fenster oder das Betriebssystem; Pfade kommen nur aus dem Dialog oder aus der Akte
    RECHTSFALL_FENSTER = {"dokumente_hinzufuegen", "dokument_oeffnen", "ordner_oeffnen", "ablage_waehlen",
                          "ablage_zuruecksetzen"}

    def _rechtsfaelle(self):
        if getattr(self, "_rechtsfaelle_obj", None) is None:
            from tirge_helfer.rechtsfaelle import Rechtsfaelle
            self._rechtsfaelle_obj = Rechtsfaelle(self.projekte, lambda: EINSTELLUNGEN.get("rechtsfaelle_ordner", ""))
        return self._rechtsfaelle_obj

    def _rechtsfall_fenster(self, aktion, argumente):
        from tirge_helfer.rechtsfaelle import OEFFNEN_ZUSATZ, RechtsfallFehler
        rf, a = self._rechtsfaelle(), list(argumente or [])
        if aktion in ("dokumente_hinzufuegen", "ablage_waehlen") and not self.fenster:
            raise RechtsfallFehler("Dateien und Ordner wählen geht nur im ODIN-Fenster, nicht im Browser.")
        if aktion == "dokumente_hinzufuegen":
            pfade = self.fenster.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=True,
                                                    file_types=("Alle Dateien (*.*)",))
            if not pfade:
                return None                                       # abgebrochen
            return rf.dokumente_importieren(str(a[0]) if a else "", [pfade] if isinstance(pfade, str) else list(pfade))
        if aktion == "dokument_oeffnen":
            pfad = rf.dokument_pfad(*[str(x) for x in a[:2]])
            if os.path.splitext(pfad)[1].lower() not in OEFFNEN_ERLAUBT | OEFFNEN_ZUSATZ:
                raise RechtsfallFehler("Diese Art Datei öffnet ODIN nicht direkt – bitte über „Ordner öffnen“.")
            if not self._starte(pfad):
                raise RechtsfallFehler("Kein Programm zum Öffnen dieser Datei gefunden.")
            return True
        if aktion == "ordner_oeffnen":
            if a and a[0]:
                pfad = rf.fallordner_pfad(str(a[0]))
            else:                                                 # der ganze Ablageort
                ablage = rf.ablage()
                if ablage["fehler"]:
                    raise RechtsfallFehler(ablage["fehler"])
                pfad = ablage["ordner"]
                os.makedirs(pfad, exist_ok=True)
            if not self._starte(pfad):
                raise RechtsfallFehler("Der Ordner ließ sich nicht öffnen.")
            return True
        if aktion == "ablage_waehlen":
            ordner = self.fenster.create_file_dialog(webview.FileDialog.FOLDER)
            if not ordner:
                return None
            ordner = ordner if isinstance(ordner, str) else ordner[0]
            rf.ablage_pruefen(ordner)
            speichere("rechtsfaelle_ordner", ordner)
            return rf.start()
        speichere("rechtsfaelle_ordner", "")                      # ablage_zuruecksetzen
        return rf.start()

    @gemeinsam(ohne_sperre=FENSTER_AKTIONEN)
    def rechtsfaelle_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für die Rechtsfälle: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}."""
        from tirge_helfer.rechtsfaelle import RechtsfallFehler
        if aktion not in self.RECHTSFALL_AKTIONEN | self.RECHTSFALL_FENSTER:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        try:
            if aktion in self.RECHTSFALL_FENSTER:
                return {"ok": True, "daten": self._rechtsfall_fenster(aktion, argumente)}
            return {"ok": True, "daten": getattr(self._rechtsfaelle(), aktion)(*(argumente or []))}
        except (RechtsfallFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except TypeError as e:
            protokolliere(f"Rechtsfälle {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({e})."}

    # ---------------- Konto & Anmeldung (Microsoft) ----------------
    KONTO_AKTIONEN = Konto.AKTIONEN

    @gemeinsam(sperren=False)                 # Anmelden wartet auf den Browser – nie die Sperre halten
    def konto_aufruf(self, aktion, argumente=None):
        """Microsoft-Anmeldung, Verknüpfung mit der Person und Erinnerungsmail: {"ok": True, "daten": …} oder
        {"ok": False, "fehler": …}. Nur im Programm – im Browser (Handy & Tablet) gibt es das nicht."""
        from tirge_helfer.web import ich_im_web
        if aktion not in self.KONTO_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        if ich_im_web()[0]:
            return {"ok": False, "fehler": "Anmelden geht nur am Rechner in ODIN, nicht im Browser."}
        try:
            return {"ok": True, "daten": getattr(self._konto, aktion)(*(argumente or []))}
        except (MicrosoftFehler, ProjektFehler, CockpitFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except Exception as e:                    # noqa: BLE001 – an der Anmeldung darf ODIN nie hängen bleiben
            protokolliere(f"Konto {aktion}: {type(e).__name__}\n{traceback.format_exc()}")
            return {"ok": False, "fehler": "Das hat nicht geklappt – Details stehen im Protokoll."}
    # ---------------- Wissen & Einarbeitung ----------------
    WISSEN_AKTIONEN = {
        "start", "ablauf", "ablauf_speichern", "ablauf_loeschen", "pruefen", "durchlauf_starten", "durchlauf",
        "durchlauf_schritt", "durchlauf_abschliessen", "durchlauf_loeschen", "anleitung", "anleitung_speichern",
        "anleitung_loeschen", "suche", "system_anlegen", "system_loeschen", "plan", "plan_speichern", "plan_loeschen",
        "einarbeitung_starten", "einarbeitung", "einarbeitung_schritt", "einarbeitung_abschliessen",
        "einarbeitung_loeschen", "agenda", "wer_weiss_was", "offene_fragen", "offene_frage_erledigt",
    }

    def _wissen(self):
        """Bewusst kein öffentliches Attribut: pywebview reicht öffentliche Unterobjekte der Api ans Fenster durch –
        erreichbar ist das Wissen nur über wissen_aufruf mit seiner festen Liste von Aktionen."""
        if getattr(self, "_wissen_obj", None) is None:
            from tirge_helfer.wissen import Wissen
            self._wissen_obj = Wissen(self.projekte)
        return self._wissen_obj

    def _wissen_stichworte(self) -> list:
        """Abläufe und Anleitungen für den Fragen-Assistenten – nur am Rechner: im Browser (Handy) bleibt das Wissen
        zu, solange wissen_aufruf dort nicht freigegeben ist."""
        from tirge_helfer.web import ich_im_web
        if ich_im_web()[0]:
            return []
        try:
            return self._wissen().stichworte()
        except Exception:                                         # der Assistent antwortet dann ohne das Wissen
            protokolliere(f"Wissen für den Assistenten: {traceback.format_exc()}")
            return []

    def _wissen_markdown_speichern(self, argumente):
        """Ablauf oder Anleitung als Markdown-Datei – der Ort kommt nur aus dem Speichern-Dialog."""
        from tirge_helfer.wissen import WissenFehler
        if not self.fenster:
            raise WissenFehler("Speichern geht nur im ODIN-Fenster, nicht im Browser.")
        export = self._wissen().markdown(*argumente[:2])
        pfad = self._speichern_unter(sicherer_name(export["dateiname"]), "Markdown (*.md)")
        if not pfad:
            return None                                           # abgebrochen
        try:
            with open(pfad, "w", encoding="utf-8", newline="\n") as f:
                f.write(export["text"])
        except OSError as e:
            raise WissenFehler(f"Speichern hat nicht geklappt ({e}).") from None
        return {"datei": os.path.basename(pfad)}

    @gemeinsam(ohne_sperre={"markdown_speichern"})
    def wissen_aufruf(self, aktion, argumente=None):
        """Eine Schnittstelle für Wissen & Einarbeitung: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}.
        Nur Aktionen aus der festen Liste; Argumente sind Daten (IDs, Texte), nie Pfade."""
        from tirge_helfer.wissen import WissenFehler
        if not isinstance(aktion, str) or aktion not in self.WISSEN_AKTIONEN | {"markdown_speichern"}:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        argumente = list(argumente)[:4] if isinstance(argumente, (list, tuple)) else []
        try:
            if aktion == "markdown_speichern":
                return {"ok": True, "daten": self._wissen_markdown_speichern(argumente)}
            return {"ok": True, "daten": getattr(self._wissen(), aktion)(*argumente)}
        except (WissenFehler, ProjektFehler) as e:
            return {"ok": False, "fehler": str(e)}
        except Exception as e:                                    # nichts Internes an die Oberfläche
            protokolliere(f"Wissen {aktion}: {traceback.format_exc()}")
            return {"ok": False, "fehler": f"Interner Fehler ({type(e).__name__})."}

    # ---------------- Beirat & Coaching ----------------
    BEIRAT_AKTIONEN = {"start", "suche", "impuls"}

    @gemeinsam(sperren=False)                 # nur mitgelieferte Inhalte lesen – keine gemeinsame Datei
    def beirat_aufruf(self, aktion, argumente=None):
        """Beirat & Coaching: {"ok": True, "daten": …} oder {"ok": False, "fehler": …}. Nur lesen, für alle – auch im
        Browser. Angaben sind Texte (Suche) oder ein Datum, sonst nichts."""
        from tirge_helfer import beirat
        if aktion not in self.BEIRAT_AKTIONEN:
            return {"ok": False, "fehler": "Unbekannte Aktion."}
        argumente = [a if isinstance(a, str) else "" for a in list(argumente or [])[:1]]
        return {"ok": True, "daten": getattr(beirat, aktion)(*argumente)}

    # ---------------- Fahrzeugordner und ABs ----------------
    def _ablage(self) -> Fahrzeugablage:
        return Fahrzeugablage(EINSTELLUNGEN.get("fahrzeuge_ordner", ""))

    def ablage_status(self):
        a = self._ablage()
        gueltig = bool(a.wurzel) and os.path.isdir(a.wurzel)
        return {"ordner": a.wurzel, "gueltig": gueltig, "im_eingang": len(a.neue_abs()) if gueltig else 0,
                "hersteller": HERSTELLER, "jahr_vorschlag": self._jahr_vorschlag()}

    @staticmethod
    def _jahr_vorschlag() -> int:
        heute = dt.date.today()
        return heute.year + 1 if heute.month >= 7 else heute.year   # ab Sommer wird fürs nächste Modelljahr bestellt

    def ablage_waehlen(self):
        ordner = self.fenster.create_file_dialog(webview.FileDialog.FOLDER)
        if not ordner:
            return self.ablage_status()
        self._merke(ordner[0])
        if not self._sieht_aus_wie_fahrzeuge(ordner[0]):
            return {**self.ablage_status(), "frage": ordner[0]}     # erst nachfragen, nichts anlegen
        return self.ablage_setzen(ordner[0])

    def ablage_setzen(self, ordner):
        if not self._wurde_gewaehlt(ordner):                  # nur ein Ordner aus dem Dialog, nie ein freier Pfad
            raise ValueError("Bitte den Ordner über „Ordner wählen“ aussuchen.")
        speichere("fahrzeuge_ordner", ordner)
        Fahrzeugablage(ordner).pruefe_wurzel()        # legt AB-Eingang und _Mailberichte an, falls sie fehlen
        return self.ablage_status()

    @staticmethod
    def _sieht_aus_wie_fahrzeuge(ordner) -> bool:
        try:
            inhalt = os.listdir(ordner)
        except OSError:
            return False
        name = os.path.basename(os.path.normpath(ordner)).casefold()
        return name == "fahrzeuge" or "AB-Eingang" in inhalt or any(re.fullmatch(r"\d{4}", n) for n in inhalt)

    def eingang_pruefen(self):
        a = self._ablage()
        a.pruefe_wurzel()
        if not self._sperre.acquire(blocking=False):
            return []                              # Einlesen läuft gerade
        try:
            ergebnisse = a.verarbeite_eingang(schreibe_vergleich_pdf, schreibe_mailbericht)
        finally:
            self._sperre.release()
        return [eingang_dict(e) for e in ergebnisse]

    # ---------------- ABs nachträglich einlesen ----------------
    def einlesen_ordner_waehlen(self):
        ordner = self.fenster.create_file_dialog(webview.FileDialog.FOLDER)
        if not ordner:
            return None
        self._merke(ordner[0])
        dateien = finde_einlesbare(ordner[0])
        mails = sum(ist_mail(d) for d in dateien)
        return {"ordner": ordner[0], "mails": mails, "pdfs": len(dateien) - mails}

    def einlesen_starten(self, ordner, basis_ordner=""):
        """ordner: noch nicht bearbeitete ABs (Posteingang); basis_ordner: schon bearbeitete (nur zum Vergleichen)."""
        if self._einlesen.get("laeuft"):
            return {"ok": False, "fehler": "Das Einlesen läuft bereits."}
        if not self._wurde_gewaehlt(ordner) or (basis_ordner and not self._wurde_gewaehlt(basis_ordner)):
            return {"ok": False, "fehler": "Bitte die Ordner über „Ordner wählen“ aussuchen."}
        a = self._ablage()
        a.pruefe_wurzel()
        self._einlesen_stopp = False
        self._einlesen = {"laeuft": True, "phase": "start", "i": 0, "n": 0, "text": "", "ergebnis": None, "fehler": ""}

        def fortschritt(phase, i, n, text):
            self._einlesen.update(phase=phase, i=i, n=n, text=text)

        def lauf():
            with self._sperre:
                try:
                    erg = a.importiere(ordner or "", basis_ordner or "", schreibe_vergleich_pdf, fortschritt,
                                       lambda: self._einlesen_stopp)
                    self._einlesen["ergebnis"] = erg
                except Exception as e:
                    self._einlesen["fehler"] = str(e)
                    protokolliere(traceback.format_exc())
                finally:
                    self._einlesen["laeuft"] = False

        threading.Thread(target=lauf, daemon=True).start()
        return {"ok": True}

    def einlesen_stand(self):
        return dict(self._einlesen)

    def einlesen_abbrechen(self):
        self._einlesen_stopp = True
        return True

    def ab_uebersicht(self):
        a = self._ablage()
        if not (a.wurzel and os.path.isdir(a.wurzel)):
            return []
        try:
            a.bereinige_ordnernamen()
        except Exception:
            pass                       # z. B. ein gerade gesperrter Ordner – die Liste trotzdem zeigen
        zeilen = a.uebersicht()
        self._uebersprungen = a.uebersprungen
        return zeilen

    def syscara_uebersicht(self):
        """Reiter „Ausstattungsvergleich“: alle Fahrzeuge aus Syscara mit dem Ergebnis des Abgleichs."""
        a = self._ablage()
        if not (a.wurzel and os.path.isdir(a.wurzel)):
            return {"fahrzeuge": [], "export": None}
        erg = a.syscara_uebersicht()
        self._uebersprungen = a.uebersprungen
        return erg

    def ab_uebersprungen(self):
        """Fahrzeuge, die beim letzten Laden der Liste gerade nicht lesbar waren (z. B. von OneDrive gesperrt)."""
        return list(getattr(self, "_uebersprungen", []))

    def ab_details(self, fahrzeug_pfad, datei=None, gegen=None):
        """Ohne datei/gegen: Gesamtprüfung des Fahrzeugs; sonst freier Vergleich."""
        d = self._ablage().details(fahrzeug_pfad, datei or None, gegen)
        d["aenderungen"] = aenderungen_dict(d["aenderungen"])
        return d

    def ab_status(self, fahrzeug_pfad, status=None, notiz=None, datei=None):
        """Status des Fahrzeugs setzen; datei = die neueste AB, die gerade angezeigt wird."""
        return self._ablage().setze_status(fahrzeug_pfad, status or None, notiz, datei or None)

    def ab_abhaken(self, fahrzeug_pfad, datei, geprueft):
        """Einzelne AB als geprüft abhaken oder den Haken entfernen; gibt die neue Zeile zurück."""
        return self._ablage().hake_ab(fahrzeug_pfad, datei, geprueft)

    def ab_stumm(self, fahrzeug_pfad, bereich, art, titel="", beispiel=""):
        """Diese Art Änderung zählt beim Hersteller des Fahrzeugs künftig nicht mehr als wichtig."""
        return self._ablage().schalte_stumm(fahrzeug_pfad, bereich, art, titel, beispiel)

    def ab_laut(self, regel_id="", fahrzeug_pfad="", bereich="", art=""):
        """Regel entfernen (über ID oder über Fahrzeug + Bereich + Art)."""
        return self._ablage().schalte_laut(regel_id, fahrzeug_pfad, bereich, art)

    def ab_regeln(self):
        return self._ablage().regeln()

    # ---------------- Syscara ----------------
    def syscara_datei_waehlen(self):
        pfade = self.fenster.create_file_dialog(
            webview.FileDialog.OPEN, allow_multiple=False, file_types=("Syscara Export (*.xlsx;*.csv)", "Alle Dateien (*.*)"))   # pywebview: kein „-“ im Namen
        self._merke(*(pfade or []))
        return pfade[0] if pfade else None

    def syscara_einlesen(self, pfad=None, name="", inhalt_base64=None):
        """Syscara-Export einlesen (Pfad aus dem Dateidialog oder per Drag & Drop als Base64)."""
        a = self._ablage()
        if not inhalt_base64 and pfad and not self._wurde_gewaehlt(pfad):     # nie ein freier Pfad aus der Oberfläche
            return {"ok": False, "fehler": "Bitte die Datei über „Datei wählen“ aussuchen."}
        quelle = base64.b64decode(inhalt_base64) if inhalt_base64 else pfad
        if not quelle:
            return {"ok": False, "fehler": "Keine Datei gewählt."}
        if not self._sperre.acquire(timeout=60):
            return {"ok": False, "fehler": "Gerade läuft noch ein Einlesen – bitte gleich noch einmal versuchen."}
        try:
            return {"ok": True, **a.syscara_einlesen(quelle, name or os.path.basename(str(pfad or "")))}
        except (ValueError, OSError) as e:
            return {"ok": False, "fehler": str(e)}
        finally:
            self._sperre.release()

    def syscara_zuordnen(self, fahrzeug_pfad, name, positionen):
        """Syscara-Ausstattung = diese AB-Positionen (leere Liste: steht nie in der AB). Gilt für den ganzen Hersteller."""
        return self._ablage().syscara_zuordnen(fahrzeug_pfad, name, positionen or [])

    def syscara_nur_ab(self, fahrzeug_pfad, pos):
        """Diese AB-Position steht beim Hersteller nie in Syscara."""
        return self._ablage().syscara_nur_ab(fahrzeug_pfad, pos)

    def syscara_zuordnungen(self):
        return self._ablage().zuordnungen()

    def syscara_zuordnung_entfernen(self, regel_id):
        return self._ablage().zuordnung_entfernen(regel_id)

    def ab_bericht(self, fahrzeug_pfad, datei, gegen):
        """Vergleich als PDF im Fahrzeugordner erzeugen (falls nötig) und öffnen."""
        return self.oeffne(self._ablage().bericht(fahrzeug_pfad, datei, gegen, schreibe_vergleich_pdf))

    def ab_uebersicht_exportieren(self, zeilen):
        pfad = self._speichern_unter(f"AB-Uebersicht_{dt.date.today().isoformat()}.xlsx", "Excel (*.xlsx)")
        if not pfad:
            return {"ok": False, "abgebrochen": True}
        try:
            exportiere_uebersicht(pfad, zeilen)
        except PermissionError:
            return {"ok": False, "fehler": "Die Datei ist gerade geöffnet. Bitte schließen und erneut versuchen."}
        return {"ok": True, "pfad": pfad}

    def ab_hinzufuegen(self, name, inhalt_base64):
        """Per Drag & Drop hereingezogene AB (PDF oder gespeicherte Mail) in den Eingang legen.
        Gibt zurück, wie viele PDFs im Eingang gelandet sind."""
        a = self._ablage()
        a.pruefe_wurzel()
        daten = base64.b64decode(inhalt_base64)
        if not ist_mail(name):          # mehrere gleichnamige gleichzeitig: keine darf verloren gehen
            if lies_ab(io.BytesIO(daten)).fehler and any(
                    e.interne_id and e.fliesstext for e in lies_preisschilder(io.BytesIO(daten), name)):
                raise ValueError(f"„{name}“ sieht nach einem Preisschild aus, nicht nach einer AB – Preisschilder bitte "
                                 "im Reiter „Preisschilder“ ablegen.")
            if not daten.lstrip()[:5] == b"%PDF-":
                raise ValueError(f"„{sicherer_name(name)}“ ist keine PDF – in den AB-Eingang kommen nur PDFs und Mails.")
            basis, _ = os.path.splitext(sicherer_name(name))
            Fahrzeugablage.schreibe_neu(a.eingang, basis or "AB", ".pdf", daten)     # in den Eingang nur als PDF
            return 1
        with tempfile.TemporaryDirectory() as tmp:          # aus der Mail nur die AB-Anhänge
            pfad = os.path.join(tmp, os.path.basename(name))
            with open(pfad, "wb") as f:
                f.write(daten)
            anzahl = 0
            for anhang, inhalt in lies_mail(pfad).pdfs:
                if lies_ab(io.BytesIO(inhalt)).fehler:
                    continue
                basis, _ = os.path.splitext(sicherer_name(anhang))
                Fahrzeugablage.schreibe_neu(a.eingang, basis or "AB", ".pdf", inhalt)
                anzahl += 1
        return anzahl

    def abs_vergleichen(self, dateien):
        """Freier Vergleich zweier AB-PDFs (ohne Ablage). dateien: [{name, b64}, {name, b64}].
        Die ältere Fassung (nach Datum und Ausfertigung) wird automatisch als 'vorher' genommen."""
        with tempfile.TemporaryDirectory() as tmp:
            abs_ = []
            for i, d in enumerate(dateien[:2]):
                pfad = os.path.join(tmp, f"{i}.pdf")
                with open(pfad, "wb") as f:
                    f.write(base64.b64decode(d["b64"]))
                Fahrzeugablage.repariere_base64(pfad)
                ab = lies_ab(pfad, datei=d["name"])
                if ab.fehler:
                    return {"ok": False, "fehler": f"{d['name']}: {ab.fehler}"}
                abs_.append(ab)
        alt, neu = sorted(abs_, key=lambda ab: (ab.iso_datum, ab.fassung))
        aenderungen = vergleiche(alt, neu)
        hinweis = ""
        nummern_alt, nummern_neu = {alt.interne_id, alt.auftragsnummer} - {""}, {neu.interne_id, neu.auftragsnummer} - {""}
        if nummern_alt and nummern_neu and not nummern_alt & nummern_neu:
            hinweis = "Achtung: Die beiden ABs gehören offenbar zu verschiedenen Fahrzeugen."
        return {"ok": True, "hinweis": hinweis,
                "alt": {"datei": alt.datei, "datum": alt.datum, "belegart": alt.belegart, "id": alt.interne_id},
                "neu": {"datei": neu.datei, "datum": neu.datum, "belegart": neu.belegart, "id": neu.interne_id},
                "wichtig": sum(a.stufe == WICHTIG for a in aenderungen),
                "info": sum(a.stufe == INFO for a in aenderungen),
                "aenderungen": aenderungen_dict(aenderungen)}

    def fahrzeuge(self):
        a = self._ablage()
        if not (a.wurzel and os.path.isdir(a.wurzel)):
            return []
        return a.fahrzeug_zusammenfassung()

    def fahrzeug_anlegen(self, daten):
        a = self._ablage()
        try:
            a.pruefe_wurzel()
            if not isinstance(daten, dict):
                raise ValueError("Ungültige Angaben.")
            hersteller = str(daten.get("hersteller", ""))
            if hersteller not in HERSTELLER:                  # nie ein freier Text: er wird zum Ordnernamen
                raise ValueError("Bitte einen Hersteller aus der Liste wählen.")
            if not re.fullmatch(r"\d{4}", str(daten.get("jahr", ""))):
                raise ValueError("Bitte das Jahr vierstellig angeben.")
            fz, neu = a.lege_an(hersteller, str(daten.get("jahr", "")), daten.get("interne_id", ""),
                                eingegebene_auftragsnummer(daten.get("auftragsnummer", "")))
            if not _in_ordner(fz.pfad, a.wurzel):
                raise ValueError("Der Fahrzeugordner läge außerhalb der Ablage.")
            if daten.get("datei_b64"):
                endung = os.path.splitext(str(daten.get("datei_name", "")))[1].lower() or ".pdf"
                if endung not in (".pdf", ".msg", ".eml"):
                    raise ValueError("Als Bestellung bitte eine PDF oder eine gespeicherte Mail (.msg, .eml) ablegen.")
                if endung == ".pdf" and not base64.b64decode(daten["datei_b64"][:64] + "=" * 3)[:1024].lstrip()[:5] == b"%PDF-":
                    raise ValueError("Die Datei ist keine PDF.")
                ziel = a._freier_name(fz.pfad, f"{dt.date.today().isoformat()}_Bestellung", endung)
                with open(ziel, "wb") as f:
                    f.write(base64.b64decode(daten["datei_b64"]))
        except (ValueError, OSError) as e:
            return {"ok": False, "fehler": str(e)}
        return {"ok": True, "neu": neu, "fahrzeug": fz.als_dict()}


def main():
    api = Api()
    logging.getLogger("pywebview").addHandler(ProtokollHandler())   # Fehler aus der Oberfläche ins Protokoll
    # Neue Fenster/Links gibt pywebview an den Standardbrowser (unter Windows: os.startfile). Dorthin gehen nur
    # Webadressen – nie Programm- oder Dateiaufrufe wie „ms-excel:“ oder „file:“.
    import webbrowser
    browser_oeffnen = webbrowser.open
    webbrowser.open = lambda url, *a, **k: (browser_oeffnen(url, *a, **k)
                                            if re.match(r"https?://[^\s]+$", str(url), re.I) else False)
    # Die Oberfläche bekommt nie die Api selbst, nur eine Fassade mit den öffentlichen Methoden (tirge_helfer/bruecke.py)
    from tirge_helfer import bruecke
    bruecke.riegel_setzen(bruecke.oeffentliche_namen(api), protokolliere)
    api.fenster = webview.create_window(
        "ODIN" if VERSION == "dev" else f"ODIN · Version {VERSION}", ressource("ui", "index.html"),
        js_api=bruecke.oberflaeche(api),
        width=1360, height=860, min_size=(1000, 640), text_select=True, background_color="#FFFFFF")
    bruecke.fenster_sichern(api.fenster, protokolliere)   # nur die eigene Oberfläche darf im Fenster stehen
    api._konto.erinnerung.starten()               # tägliche Erinnerungsmail: kurz nach dem Start, dann alle 10 Minuten
    webview.start()


def selbsttest():
    """Erzeugt Test-PDFs und schickt sie durch alle Schritte (läuft nach jedem Build)."""
    from reportlab.pdfgen import canvas

    def pdf(pfad, text):
        c = canvas.Canvas(pfad)
        for i, zeile in enumerate(text.split("\n")):
            c.drawString(40, 800 - 14 * i, zeile)
        c.save()

    for teil in (("ui", "index.html"), ("ui", "app.js"), ("ui", "abs.js"), ("ui", "ausstattung.js"), ("ui", "app.css"), ("ui", "cockpit.js"), ("ui", "cockpit.css"), ("ui", "v3.css"), ("ui", "projekte.js"), ("ui", "projekte.css"), ("ui", "urlaub.js"), ("ui", "urlaub.css"), ("ui", "tagesfragen.js"), ("ui", "tagesfragen.css"), ("ui", "besprechungen.js"), ("ui", "besprechungen.css"), ("ui", "rechtsfaelle.js"), ("ui", "rechtsfaelle.css"), ("ui", "wissen.js"), ("ui", "wissen.css"), ("ui", "beirat.js"), ("ui", "beirat.css"), ("ui", "messe.js"), ("ui", "messe.css"), ("ui", "wissen-bilder", "HG-Portal-Einsteiger_01.png"), ("ui", "img", "odin-signet.svg"),
                 ("ui", "img", "muster-logo.svg"), ("ui", "fonts", "inter-latin-400-normal.woff2")):
        assert os.path.exists(ressource(*teil)), f"fehlt im Programm: {'/'.join(teil)}"
    for teil in (("ui", "tickets.js"), ("ui", "tickets.css")):
        assert os.path.exists(ressource(*teil)), f"fehlt im Programm: {'/'.join(teil)}"
    if getattr(sys, "frozen", False):          # im fertigen Programm: ist die Fenster-Bibliothek mit eingepackt?
        if sys.platform == "darwin":
            import webview.platforms.cocoa  # noqa: F401
        elif sys.platform == "win32":
            import webview.platforms.winforms  # noqa: F401
    with tempfile.TemporaryDirectory() as tmp:
        schild = os.path.join(tmp, "schild.pdf")
        pdf(schild, "Hersteller1\nTestmodell\nTechnische Daten\nBasisfahrzeug Fiat Ducato Leistung 103 kW / 140 PS "
                    "Interne ID DETKW00001\nSonderausstattungen 1.000 €\n+ Markise 1.000 €\n+ Weiß\nWeitere Sonderausstattung")
        e = lies_preisschild(schild)
        assert e.interne_id == "DETKW00001" and "Markise" in e.fliesstext, e
        assert "Markise" in e.werbetext and len(e.werbetext) <= 48, e.werbetext          # mobile.de-Text
        exportiere([e], os.path.join(tmp, "export.xlsx"))

        wurzel = os.path.join(tmp, "Fahrzeuge")
        os.makedirs(os.path.join(wurzel, "AB-Eingang"))
        ab_text = ("Hersteller1 GmbH & Co. KG\nAuftragsbestätigung\nNr 1234567\nBestelltext VFW/b1/DRM00001\n"
                   "Pos Artikel Konzern-ID Menge Einzelpreis % Gesamtpreis\n10 SM.TEST1 1Stück 10,00 10,00\n"
                   "Testposition\nSumme 10,00\nZahlung sofort\nAlle Kaufgegenstände\nDruckdatum 02.01.26")
        ablage = Fahrzeugablage(wurzel)
        pdf(os.path.join(wurzel, "AB-Eingang", "neu.pdf"), ab_text.replace("10,00 10,00", "12,00 12,00"))
        ergebnisse = ablage.verarbeite_eingang(schreibe_vergleich_pdf, schreibe_mailbericht)
        pdf(os.path.join(wurzel, "AB-Eingang", "alt.pdf"), ab_text.replace("02.01.26", "01.01.26"))
        ergebnisse += ablage.verarbeite_eingang(schreibe_vergleich_pdf, schreibe_mailbericht)
        assert [x.status for x in ergebnisse] == ["Eingeordnet", "Eingeordnet"], ergebnisse
        assert ergebnisse[1].neu_geprueft == ["2026-01-02_AB.pdf"], ergebnisse[1]   # nachträglich ältere AB
        [zeile] = ablage.uebersicht()                       # ein Eintrag pro Fahrzeug, neueste AB
        assert (zeile["status"], zeile["datei"], zeile["ergebnis"], zeile["fahrzeug"]["name"]) == \
            ("offen", "2026-01-02_AB.pdf", "erste", "DRM00001_1234567"), zeile
        zeile = ablage.setze_status(zeile["fahrzeug"]["pfad"], "erledigt", datei=zeile["datei"])
        assert zeile["status"] == "erledigt", zeile
        exportiere_uebersicht(os.path.join(tmp, "uebersicht.xlsx"), [zeile])
        assert os.listdir(os.path.join(wurzel, "_Mailberichte"))

        # gespeicherte Outlook-Mail nachträglich einlesen
        from email.message import EmailMessage
        post = os.path.join(tmp, "Posteingang")
        os.makedirs(post)
        pdf(os.path.join(tmp, "ab3.pdf"), ab_text.replace("02.01.26", "05.01.26").replace("10,00 10,00", "14,00 14,00"))
        mail = EmailMessage()
        mail["Subject"], mail["Date"] = "Auftragsbestätigung", "Mon, 05 Jan 2026 08:00:00 +0100"
        mail.set_content("Anbei")
        with open(os.path.join(tmp, "ab3.pdf"), "rb") as f:
            mail.add_attachment(f.read(), maintype="application", subtype="pdf", filename="AB.pdf")
        with open(os.path.join(post, "ab.eml"), "wb") as f:
            f.write(bytes(mail))
        with open(os.path.join(post, "kaputt.msg"), "wb") as f:
            f.write(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"x" * 2000)
        erg = ablage.importiere(post, bericht_schreiben=schreibe_vergleich_pdf)
        assert erg["eingeordnet"] == 1 and erg["offen"] == 1 and len(erg["fehler"]) == 1, erg
        [zeile] = ablage.uebersicht()                       # neueste gegen den geprüften Stand
        assert (zeile["datei"], zeile["gegen"], zeile["status"]) == ("2026-01-05_AB.pdf", "2026-01-02_AB.pdf", "offen"), zeile
        assert zeile["wichtig"] > 0 and ablage.details(zeile["fahrzeug"]["pfad"])["aenderungen"], zeile

        # Syscara-Export (Excel und CSV): Ausstattung gegen die neueste AB
        from openpyxl import Workbook
        wb = Workbook()
        wb.active.append(["SYSCARA EXPORT"])
        wb.active.append(["#", "Hersteller", "Baureihe", "Modell", "Interne ID", "Bestellnummer", "Testposition", "Markise"])
        wb.active.append([1, "Hersteller1", "", "", "DRM00001", "1234567", "Testposition", None])
        wb.save(os.path.join(tmp, "export.xlsx"))
        erg = ablage.syscara_einlesen(os.path.join(tmp, "export.xlsx"))
        assert erg["mit_ab"] == 1 and erg["passt"] == 1, erg
        [zeile] = ablage.uebersicht()
        assert zeile["syscara"]["ok"] and zeile["status"] == "offen", zeile      # wichtige Änderung bleibt offen
        with open(os.path.join(tmp, "export.csv"), "w", encoding="cp1252") as f:
            f.write("Interne ID;Bestellnummer;Testposition;Markise\nDRM00001;1234567;x;Markise\n")
        ablage.syscara_einlesen(os.path.join(tmp, "export.csv"))
        [zeile] = ablage.uebersicht()
        assert zeile["syscara"]["kurz"] == ["Fehlt in AB: Markise"], zeile["syscara"]
        [eintrag] = ablage.syscara_uebersicht()["fahrzeuge"]
        assert eintrag["gruppe"] == "abweichung", eintrag

        # Syscara-Schnittstelle: Abfrage mit Zugang (Testserver), Fließtext daraus, Zugang sicher ablegen
        wie = selbsttest_syscara_api(tmp)
        cockpit = selbsttest_cockpit(tmp)
        aktionen = selbsttest_aktionen(tmp)
        ms = selbsttest_microsoft(tmp)
    for warnung in selbsttest_ablage_warnungen():
        print(f"WARNUNG: {warnung}")
    print(f"Selbsttest ok (Version {VERSION}): Preisschild, Excel, AB-Eingang, Reihenfolge, Vergleich, PDF-Bericht, Mailbericht, Mail-Import, "
          f"Syscara-Abgleich, Ausstattungsvergleich, Syscara-Schnittstelle (Zugang: {wie}), Cockpit ({cockpit}), Projekte, Besprechungen, "
          f"Rechtsfälle, Cashback, Wissen, Beirat & Coaching, Hausregeln, In ODIN arbeiten ({aktionen}), Microsoft-Anmeldung ({ms})")


def selbsttest_ablage_warnungen(ordner: str = None) -> list:
    """Liegt auf diesem Rechner noch ein Zugang oder eine Anmeldung in einer älteren, nur kodierten Datei?"""
    from tirge_helfer import microsoft
    ordner = ordner or einstellungsordner()
    warnungen = []
    if zugang.status(ordner)["warnung"]:
        warnungen.append("Syscara-Zugang: " + zugang.HINWEIS_ALTDATEI)
    st = microsoft.TokenSpeicher(ordner).sicherheit()
    if st["warnung"]:
        warnungen.append("Microsoft-Anmeldung: " + st["hinweis"])
    return warnungen


def selbsttest_microsoft(tmp: str) -> str:
    """Microsoft-Anmeldung ohne Netzwerk: MSAL eingepackt? Anmeldung sicher ablegen und lesen, Erinnerungsmail bauen."""
    import msal
    import requests  # noqa: F401 – braucht MSAL; im fertigen Programm mit eingepackt?
    from tirge_helfer import erinnerung, microsoft
    assert microsoft.guid("{1A2B3C4D-1234-5678-9ABC-1234567890AB}") == "1a2b3c4d-1234-5678-9abc-1234567890ab"
    assert msal.SerializableTokenCache().serialize() is not None
    speicher = microsoft.TokenSpeicher(os.path.join(tmp, "microsoft"), dienst="ODIN Selbsttest Microsoft")
    probe = json.dumps({"Selbsttest": "geh€im"})
    wie = speicher.speichere(probe)
    assert speicher.lade() == probe, wie
    if wie == "verschlüsselt":
        with open(speicher.pfad, encoding="utf-8") as f:
            assert "Selbsttest" not in f.read(), "Anmeldung liegt unverschlüsselt"
    speicher.loesche()
    assert speicher.lade() == "" and not speicher.vorhanden()
    heute = dt.date.today().isoformat()
    person = {"id": "p1", "name": "Selbst Test", "email": "selbst.test@example.org"}
    daten = {"quelle": "excel",
             "cashback": {"verantwortlich": "Selbst Test", "kennzahlen": {"offen": 1, "offen_netto": 1000.0},
                          "fristen": [{"kunde": "Test, Tina", "aktion": "Testaktion", "hersteller": "TEST", "frist": heute,
                                       "lage": "bald"}], "nachhaken": [], "aktionen": []},
             "fristen": [{"titel": "Prüfung Hebebühnen", "faellig_am": heute, "tage_bis": 0, "zustand": "bald",
                          "verantwortlich": "selbst.test@example.org"}]}
    inhalt = erinnerung.inhalt_sammeln(person, daten, [{"titel": "Prüfen", "projekt": "Selbsttest", "faellig": heute}], heute)
    mail = erinnerung.baue_mail(inhalt, person, heute)
    assert erinnerung.anzahl(inhalt) == 3 and "Cashback" in mail["text"] and "Hebebühnen" in mail["html"], mail["text"]
    assert b"multipart/alternative" in microsoft.mime_nachricht(person["email"], mail["betreff"], mail["text"], mail["html"])
    assert erinnerung.ist_leer(erinnerung.inhalt_sammeln(person, {**daten, "quelle": "beispiel", "cashback": None}, [], heute))
    return f"MSAL {msal.__version__}, Anmeldung {wie}"


def selbsttest_aktionen(tmp: str) -> str:
    """In ODIN arbeiten: Satz → Vorschau → in die Excel-Liste schreiben → in ODIN sichtbar → rückgängig."""
    from tirge_helfer.aktionen.dienst import KATALOG, Aktionsdienst
    from tirge_helfer.cockpit import beispieldateien
    ordner = os.path.join(tmp, "aktionen")
    os.makedirs(os.path.join(ordner, "Fahrzeuge"), exist_ok=True)
    teile = beispieldateien.schreibe_teileliste(ordner, artikel=20)

    class E(dict):
        def speichere(self, k, v):
            self[k] = v
            return True
    e = E(cockpit_quellen={"teilepreise": teile}, fahrzeuge_ordner=os.path.join(ordner, "Fahrzeuge"))
    c = Cockpit(e, e.speichere, os.path.join(ordner, "einst"))
    d = Aktionsdienst(c, einstellungen=e, speichere=e.speichere, einstellungsordner=os.path.join(ordner, "einst"))
    r = d.verstehen("Arbeitszeit SAT-Anlage Caro Sidetrack 2 Stunden mehr", finanzen=True)
    assert r["art"] == "vorschau" and r["ausfuehrbar"], r
    erg = d.ausfuehren(r["id"], True, finanzen=True)
    assert erg["ok"], erg
    teil = next(t for t in c.daten()["katalog"] if t["sku"] == "SA03100")
    assert teil["install_minutes"] == 300, teil
    assert d.rueckgaengig(erg["eintrag"], finanzen=True)["ok"]
    assert next(t for t in c.daten()["katalog"] if t["sku"] == "SA03100")["install_minutes"] == 180
    assert d.verstehen("Ist SA03100 auf Lager?")["art"] == "keine"
    return f"{len(KATALOG)} Aktionen"


def selbsttest_cockpit(tmp: str) -> str:
    """Beispiel-Listen schreiben und einlesen (alle sieben Arten), Datenpaket bauen, Projekte einmal durchspielen."""
    from tirge_helfer.cockpit import beispieldateien
    from tirge_helfer.cockpit.db import lade_vorlage
    lade_vorlage("praefixe")                                  # Vorlagen mit eingepackt?
    ordner = os.path.join(tmp, "cockpit")
    gelesen = beispieldateien.selbsttest(ordner)
    assert all(gelesen.values()), gelesen
    pfade = beispieldateien.schreibe_alle(os.path.join(ordner, "quellen"), artikel=50)
    werte = {"cockpit_quellen": {a: pfade[a] for a in ("bestandsliste", "finanzierungen", "auslieferungen", "finanzplanung",
                                                        "provisionen", "teilepreise", "urlaubsplaner")}, "fahrzeuge_ordner": ""}
    c = Cockpit(werte, werte.__setitem__, os.path.join(tmp, "cockpit-einstellungen"))
    d = c.daten()
    assert d["quelle"] == "excel" and d["vehicles"] and d["financings"] and not any(q["fehler"] for q in d["quellen"]), d["quellen"]
    c.todo_anlegen({"text": "Selbsttest"})
    assert any(t["text"] == "Selbsttest" for t in c.daten()["todos"])
    beispiel = Cockpit({}, lambda *a: None, os.path.join(tmp, "cockpit-beispiel")).daten()
    assert beispiel["quelle"] == "beispiel" and beispiel["vehicles"]

    zustand = {"ich": ""}
    pr = Projekte(lambda: os.path.join(tmp, "Fahrzeuge"), lambda: zustand["ich"], lambda i: zustand.__setitem__("ich", i), tmp)
    ich = pr.person_anlegen({"name": "Selbst Test"})
    tr = Tresor(pr, sperr_datei=os.path.join(tmp, "pin-sperren.json"))       # Anmeldung mit PIN (scrypt/PBKDF2)
    assert tr.pin_festlegen(ich["id"], "482915", "482915")["angemeldet"] and pr.ich() == ich["id"]
    zustand["ich"] = ""
    assert not tr.anmelden(ich["id"], "482916")["angemeldet"] and tr.anmelden(ich["id"], "482915")["angemeldet"]
    projekt = pr.projekt_anlegen({"name": "Selbsttest"})
    projekt = pr.aufgabe_anlegen(projekt["id"], {"titel": "Prüfen", "zustaendig": [ich["id"]]})
    assert pr.meine_aufgaben()[0]["titel"] == "Prüfen"
    from tirge_helfer.besprechungen import Besprechungen
    runde = Besprechungen(pr).anlegen({"art": "wochenrunde"})
    runde = Besprechungen(pr).aufgabe_anlegen(runde["id"], {"titel": "Aus der Runde", "zustaendig": ich["id"]})
    assert runde["minuten"] == 90 and {a["titel"] for a in pr.meine_aufgaben()} == {"Prüfen", "Aus der Runde"}
    from tirge_helfer.rechtsfaelle import Rechtsfaelle           # Rechtsfälle: Akte, Mail-Import, Dossier
    rf = Rechtsfaelle(pr)
    akte = rf.anlegen({"titel": "Selbsttest", "falltyp": "reklamation", "rolle": "gegen_uns"})
    from email.message import EmailMessage
    mail = EmailMessage()
    mail["Subject"], mail["From"], mail["Date"] = "Reklamation", "kunde@example.org", "Mon, 05 Jan 2026 08:00:00 +0100"
    mail.set_content("Die Markise klemmt.")
    mail.add_attachment(b"%PDF-1.4 Test", maintype="application", subtype="pdf", filename="Kaufvertrag.pdf")
    with open(os.path.join(tmp, "reklamation.eml"), "wb") as f:
        f.write(bytes(mail))
    erg = rf.dokumente_importieren(akte["aktenzeichen"], [os.path.join(tmp, "reklamation.eml")])
    assert erg["bericht"]["mails"] == 1 and len(erg["akte"]["dokumente"]) == 2 and erg["akte"]["ereignisse"], erg["bericht"]
    assert "Die Markise klemmt" in rf.dossier(akte["aktenzeichen"])["text"]

    # Wissen & Einarbeitung: Startinhalte, Durchlauf mit kopierten Schritten, Einarbeitung mit Terminen, kein HTML
    from tirge_helfer.wissen import Wissen, bloecke
    ws_ = Wissen(pr)
    w_start = ws_.start()
    assert w_start["ablaeufe"] and w_start["anleitungen"] and w_start["plaene"], "Startinhalte fehlen"
    assert all(x["entwurf"] for x in w_start["ablaeufe"] + w_start["anleitungen"]), "Startinhalte müssen Entwürfe sein"
    lauf = ws_.durchlauf_starten(w_start["ablaeufe"][0]["id"], {"fahrzeug": "SELBST1"})
    lauf = ws_.durchlauf_schritt(lauf["id"], lauf["schritte"][0]["id"], {"erledigt": True, "notiz": "ok"})
    assert lauf["fertig"] == 1 and lauf["schritte"][0]["erledigt_von"] == ich["id"]
    neuer = pr.person_anlegen({"name": "Neu Selbsttest"})
    ein = ws_.einarbeitung_starten({"person": neuer["id"], "pate": ich["id"], "plan_id": w_start["plaene"][0]["id"],
                                    "start": dt.date.today().isoformat()})
    assert ein["gesamt"] > 2 and sum(1 for x in ein["schritte"] if x["gespraech"]) == 2 and ws_.agenda()
    assert bloecke("<script>x</script>")[0]["zeilen"][0][0]["t"] == "<script>x</script>"   # bleibt Text
    assert Api.wissen_aufruf(Api.__new__(Api), "_pfad", ["ablauf", "x"]) == {"ok": False, "fehler": "Unbekannte Aktion."}

    # Beirat & Coaching: Inhalte stimmig, Suche findet „zu teuer“, Assistent zeigt den Weg, Tagesfragen dabei
    from tirge_helfer import beirat
    from tirge_helfer.tagesfragen import BEIRAT_FRAGEN
    assert not beirat.pruefen(), beirat.pruefen()
    assert beirat.suche("Kunde sagt: zu teuer")["situationen"][0]["id"] == "zuteuer"
    assert (beirat.assistent_antwort("Was würde Buffett sagen?") or {}).get("werkzeug") == "beirat"
    assert len(BEIRAT_FRAGEN) >= 30 and Api.beirat_aufruf(Api.__new__(Api), "start", [])["ok"]
    assert Api.beirat_aufruf(Api.__new__(Api), "_alles", []) == {"ok": False, "fehler": "Unbekannte Aktion."}
    # Hausregeln: stimmig, der Assistent nennt sie vor dem Beirat
    from tirge_helfer import hausregeln
    assert not hausregeln.pruefen(), hausregeln.pruefen()
    assert (hausregeln.assistent_antwort("Kann ich den Neuwagen reservieren?") or {}).get("werkzeug") == "hausregel"

    # Tickets: Bereinigen entfernt Benutzernamen, Adressen und Passwörter; Hinweise finden „Excel-Liste“
    from tirge_helfer import tickets as tk
    sauber = tk.bereinigen("C:\\Users\\anna\\x.py anna@beispiel.example passwort=geheim123")
    assert "anna" not in sauber and "geheim123" not in sauber, sauber
    assert tk.Tickets.hinweise.__doc__ and tk.BEKANNTE_PROBLEME[0]["id"] == "excel"
    assert Api.tickets_aufruf(Api.__new__(Api), "_alle", []) == {"ok": False, "fehler": "Unbekannte Aktion."}

    # Cashback: eine Aktionsliste im Format der echten Listen, Frist läuft bald ab
    from openpyxl import Workbook
    from tirge_helfer.cockpit import cashback as cb
    cb_ordner = os.path.join(tmp, "cashback")
    os.makedirs(cb_ordner)
    wb = Workbook()
    ws = wb.active
    ws.title = "Aktionen 2026"
    ws.append(["TEST – Verkauf Preis/Aktionen 2026"])
    ws.append(["Hersteller", "TEST", "Jahr", 2026, "Nachfassen ab", "30 Tage", "Frist warnen ab", "14 Tage"])
    ws.append([])
    ws.append([])
    ws.append(["Status", "Kundenname", "Modell", "Aktion 1", "Soll GS netto (€)", "Einreichungs-frist"])
    ws.append(["Angelegt", "Test, Tina", "Kastenwagen", "Testaktion", 1000, dt.date.today() + dt.timedelta(days=3)])
    wb.save(os.path.join(cb_ordner, "TEST_Aktionen.xlsx"))
    aus = cb.auswerten(cb.lies_ordner(cb_ordner), dt.date.today().isoformat(), cb_ordner)
    assert aus["kennzahlen"]["fristen_bald"] == 1 and aus["kennzahlen"]["offen_netto"] == 1000, aus["kennzahlen"]
    return f"{len(d['vehicles'])} Fahrzeuge, {sum(gelesen.values())} Zeilen aus 7 Listen"


def selbsttest_syscara_api(tmp: str) -> str:
    import http.server
    fahrzeug = {"id": 1, "identifier": {"internal": "DRM00002"},
                "model": {"producer": "Hersteller1", "series": "Lineo", "model": "I 6"},
                "engine": {"ps": 140, "kw": 103, "chassis": "Fiat", "gear": "Automatik"}, "weights": {"total": 3500},
                "equipment": [{"name": "Markise (4,0 m)", "price": 1000},
                              {"name": "Lounge Paket (Klimaanlage Fahrerhaus Automatik, Isolierte Thermomatten)", "price": 990}]}
    richtig = "Basic " + base64.b64encode(b"test:geheim").decode()

    class Testserver(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            ok = self.headers.get("Authorization") == richtig
            self.send_response(200 if ok else 401)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            if ok:
                self.wfile.write(json.dumps({"1": fahrzeug}).encode())

        def log_message(self, *argumente):
            pass

    server = http.server.HTTPServer(("127.0.0.1", 0), Testserver)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        basis = f"http://127.0.0.1:{server.server_port}"
        r = syscara_api.hole_fahrzeuge("test", "geheim", ["DRM00002"], basis=basis)
        e = syscara_api.ergebnis_aus(r["fahrzeuge"][0])
        assert e.fliesstext == ("Fiat (140 PS / 103 kW), 3.500 kg zul. Gesamtgewicht, Automatikgetriebe, "
                                "Markise (4,0 m), Lounge Paket"), e.fliesstext
        try:
            syscara_api.hole_fahrzeuge("test", "falsch", ["DRM00002"], basis=basis)
            raise AssertionError("falscher Syscara-Zugang wurde angenommen")
        except syscara_api.SyscaraFehler:
            pass
    finally:
        server.shutdown()
        server.server_close()
    if getattr(sys, "frozen", False):          # Zertifikate für https://api.syscara.com mit eingepackt?
        import certifi
        assert os.path.exists(certifi.where()), "certifi fehlt"
        syscara_api._ssl_kontext()
    if os.environ.get("ODIN_NETZTEST"):         # im Build: klappt HTTPS zu Syscara (Zertifikate)? Ohne Zugang: Ablehnung
        try:
            syscara_api.teste_zugang("odin-selbsttest", "falsch")
            raise AssertionError("Syscara hat einen falschen Zugang angenommen")
        except syscara_api.SyscaraFehler as e:
            assert "lehnt den Zugang ab" in str(e), f"Verbindung zu Syscara: {e}"
    if sys.platform == "win32":
        assert zugang._dpapi(zugang._dpapi("geh€im".encode(), True), False) == "geh€im".encode()
    wie = zugang.speichere("test", "geh€im", ordner=tmp, dienst="ODIN Selbsttest")
    assert zugang.lade(tmp, "ODIN Selbsttest") == ("test", "geh€im"), wie
    zugang.loesche(tmp, "ODIN Selbsttest")
    assert zugang.lade(tmp, "ODIN Selbsttest") is None
    return wie


class ProtokollHandler(logging.Handler):
    def __init__(self):
        super().__init__(logging.ERROR)

    def emit(self, record):
        protokolliere(self.format(record))


def main_mit_protokoll():
    """Fehler beim Start in eine Logdatei schreiben (Windows: %APPDATA%\\ODIN, Mac: ~/Library/Application Support/ODIN)."""
    if "--selbsttest" in sys.argv:   # für den Build: einmal alles durchspielen, ohne Fenster
        try:
            selbsttest()
        except BaseException:          # kein Fehlerfenster, das den Build blockiert – nur Exit-Code
            traceback.print_exc()
            sys.exit(1)
        return
    try:
        main()
    except Exception:
        protokolliere(traceback.format_exc())
        raise


if __name__ == "__main__":
    main_mit_protokoll()
